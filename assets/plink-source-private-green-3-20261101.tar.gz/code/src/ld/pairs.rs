use super::moments::{self, Correlation};
use super::{Prepared, Resources, VariantCache, VariantData, check_outputs, output_parent};
use crate::dataset::chrom::Chromosome;
use crate::dataset::metadata::Variant;
use crate::dataset::sibling;
use crate::execution::Execution;
use crate::make::Selection;
use crate::numeric::six_significant;
use crate::{Result, invalid};
use rayon::prelude::*;
use rsomics_common::AtomicFile;
use serde::Serialize;
use std::collections::BTreeSet;
use std::fs::File;
use std::io::{BufWriter, Seek, SeekFrom, Write};
use std::mem::size_of;
use std::ops::Range;
use std::path::{Path, PathBuf};

#[derive(Clone, Debug)]
pub(crate) struct PairConfig {
    pub pfile: PathBuf,
    pub out: PathBuf,
    pub selection: Selection,
    pub window_variants: usize,
    pub window_bp: u64,
    pub min_r2: f64,
    pub allow_small_founders: bool,
}

impl Default for PairConfig {
    fn default() -> Self {
        Self {
            pfile: PathBuf::new(),
            out: PathBuf::new(),
            selection: Selection::default(),
            window_variants: 1_000_000,
            window_bp: 500_000,
            min_r2: -1.0,
            allow_small_founders: false,
        }
    }
}

#[derive(Default, Serialize)]
pub(crate) struct PairReport {
    pub selected_samples: usize,
    pub founders: usize,
    pub variants: usize,
    pub evaluated_pairs: u64,
    pub emitted_pairs: u64,
    pub no_overlap_pairs: u64,
    pub zero_variance_pairs: u64,
    pub requested_workers: usize,
    pub effective_workers: usize,
    pub writer_workers: usize,
}

struct Task {
    rows: Range<usize>,
    chromosome_end: usize,
    pairs: u64,
}

fn partitions(tasks: &[Task], workers: usize) -> Vec<Range<usize>> {
    let count = workers.saturating_mul(2).min(tasks.len());
    if count == 0 {
        return Vec::new();
    }
    let cost = tasks
        .iter()
        .map(|task| u128::from(task.pairs))
        .sum::<u128>();
    let weighted = cost != 0;
    let total = if weighted { cost } else { tasks.len() as u128 };
    let mut output = Vec::with_capacity(count);
    let mut cumulative = 0;
    let mut start = 0;
    for (index, task) in tasks.iter().enumerate() {
        cumulative += if weighted { u128::from(task.pairs) } else { 1 };
        let remaining = count - output.len() - 1;
        if remaining != 0
            && (cumulative >= total * (output.len() + 1) as u128 / count as u128
                || tasks.len() - index - 1 == remaining)
        {
            output.push(start..index + 1);
            start = index + 1;
        }
    }
    output.push(start..tasks.len());
    output
}

struct Part {
    file: File,
    evaluated: u64,
    emitted: u64,
    no_overlap: u64,
    zero_variance: u64,
    worker: usize,
}

pub(crate) fn pairs(config: &PairConfig, execution: &Execution) -> Result<PairReport> {
    if config.window_variants < 2 || !config.min_r2.is_finite() || config.min_r2 > 1.0 {
        return Err(invalid(
            "LD pair window must be at least 2 and minimum r2 must be finite and no greater than 1",
        ));
    }
    check_outputs(&config.pfile, &config.selection, &config.out, &["vcor"])?;
    let input = Prepared::open(
        &config.pfile,
        &config.selection,
        if config.allow_small_founders { 2 } else { 50 },
    )?;
    let mut tasks = Vec::new();
    for chromosome in &input.chromosomes {
        let mut endpoint = chromosome.start;
        for start in (chromosome.start..chromosome.end.saturating_sub(1)).step_by(16) {
            let stop = (start + 16).min(chromosome.end - 1);
            let mut pairs = 0;
            for row in start..stop {
                endpoint = endpoint.max(row + 1);
                let end = row
                    .saturating_add(config.window_variants)
                    .min(chromosome.end);
                let a = &input.dataset.metadata.variants[input.variants[row]];
                while endpoint < end {
                    let b = &input.dataset.metadata.variants[input.variants[endpoint]];
                    if b.position - a.position > config.window_bp {
                        break;
                    }
                    endpoint += 1;
                }
                pairs += (endpoint - row - 1) as u64;
            }
            tasks.push(Task {
                rows: start..stop,
                chromosome_end: chromosome.end,
                pairs,
            });
        }
    }
    let maximum_partitions = execution
        .requested_workers
        .min(execution.pool.current_num_threads())
        .saturating_mul(2)
        .min(tasks.len());
    let resources = Resources::new(
        &input,
        execution,
        tasks.len(),
        tasks.capacity() * size_of::<Task>() + maximum_partitions * size_of::<Range<usize>>(),
    )?;
    let partitions = partitions(&tasks, resources.workers);
    let mut output = AtomicFile::new(sibling(&config.out, "vcor"))?;
    let mut report = PairReport {
        selected_samples: input.selected_samples,
        founders: input.founders.indices.len(),
        variants: input.variants.len(),
        requested_workers: execution.requested_workers,
        writer_workers: 1,
        ..PairReport::default()
    };
    let mut workers = BTreeSet::new();
    {
        let mut writer = BufWriter::with_capacity(65_536, output.file_mut());
        writeln!(
            writer,
            "#CHROM_A\tPOS_A\tID_A\tREF_A\tALT_A\tPROVISIONAL_REF_A?\tMAJ_A\tNONMAJ_A\tNONMAJ_FREQ_A\tCHROM_B\tPOS_B\tID_B\tREF_B\tALT_B\tPROVISIONAL_REF_B?\tMAJ_B\tNONMAJ_B\tNONMAJ_FREQ_B\tUNPHASED_R2"
        )?;
        for batch in partitions.chunks(resources.workers) {
            let parts: Vec<Result<Part>> = execution.pool.install(|| {
                batch
                    .par_iter()
                    .map(|partition| {
                        calculate(
                            &input,
                            &resources,
                            config,
                            &tasks[partition.clone()],
                            output_parent(&config.out),
                        )
                    })
                    .collect()
            });
            for part in parts {
                let mut part = part?;
                part.file.seek(SeekFrom::Start(0))?;
                std::io::copy(&mut part.file, &mut writer)?;
                report.evaluated_pairs += part.evaluated;
                report.emitted_pairs += part.emitted;
                report.no_overlap_pairs += part.no_overlap;
                report.zero_variance_pairs += part.zero_variance;
                workers.insert(part.worker);
            }
        }
        writer.flush()?;
    }
    report.effective_workers = workers.len();
    AtomicFile::commit_all(vec![output])?;
    Ok(report)
}

fn calculate(
    input: &Prepared,
    resources: &Resources,
    config: &PairConfig,
    tasks: &[Task],
    directory: &Path,
) -> Result<Part> {
    let mut cache = VariantCache::open(input, resources)?;
    let mut part = Part {
        file: tempfile::tempfile_in(directory)?,
        evaluated: 0,
        emitted: 0,
        no_overlap: 0,
        zero_variance: 0,
        worker: rayon::current_thread_index().unwrap_or(0),
    };
    {
        let mut writer = BufWriter::with_capacity(65_536, &mut part.file);
        for task in tasks {
            for row in task.rows.clone() {
                let a_index = input.variants[row];
                let a = &input.dataset.metadata.variants[a_index];
                cache.ensure(a_index, None)?;
                let end = row
                    .saturating_add(config.window_variants)
                    .min(task.chromosome_end);
                for &b_index in &input.variants[row + 1..end] {
                    let b = &input.dataset.metadata.variants[b_index];
                    if b.position - a.position > config.window_bp {
                        break;
                    }
                    cache.ensure(b_index, Some(a_index))?;
                    let a_data = cache.get(a_index);
                    let b_data = cache.get(b_index);
                    let moments = if a_data.raw.dosages.is_empty() && b_data.raw.dosages.is_empty()
                    {
                        resources.kernel.moments(&a_data.hard, &b_data.hard)
                    } else {
                        moments::dosage_moments(&a_data.raw, &b_data.raw, &input.founders)
                    };
                    part.evaluated += 1;
                    let value = match moments.correlation() {
                        Correlation::Defined(value) => Some(value),
                        Correlation::NoOverlap => {
                            part.no_overlap += 1;
                            None
                        }
                        Correlation::ZeroVariance => {
                            part.zero_variance += 1;
                            None
                        }
                    };
                    if config.min_r2 >= 0.0 && value.is_none_or(|value| value < config.min_r2) {
                        continue;
                    }
                    write_variant(&mut writer, a, a_data)?;
                    write!(writer, "\t")?;
                    write_variant(&mut writer, b, b_data)?;
                    writeln!(
                        writer,
                        "\t{}",
                        value
                            .map(six_significant)
                            .unwrap_or_else(|| "nan".to_owned())
                    )?;
                    part.emitted += 1;
                }
            }
        }
        writer.flush()?;
    }
    cache.close()?;
    Ok(part)
}

fn write_variant(writer: &mut impl Write, variant: &Variant, data: &VariantData) -> Result<()> {
    let Chromosome::Autosome(chromosome) = variant.chromosome else {
        return Err(invalid("ineligible chromosome reached LD writer"));
    };
    write!(
        writer,
        "{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}",
        chromosome,
        variant.position,
        variant.id,
        variant.alleles[0],
        variant.alleles[1],
        if variant.provisional_ref { "Y" } else { "N" },
        variant.alleles[data.major],
        variant.alleles[1 - data.major],
        six_significant(1.0 - data.major_frequency)
    )?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::six_significant;

    #[test]
    fn source_table_numeric_precision_keeps_tiny_values() {
        assert_eq!(six_significant(0.0), "0");
        assert_eq!(six_significant(0.2581967213114754), "0.258197");
        assert_eq!(six_significant(2.762004e-7), "2.762e-07");
        assert_eq!(six_significant(0.00009999999), "0.0001");
        assert_eq!(six_significant(0.99999999), "1");
        assert_eq!(six_significant(0.9096875), "0.909688");
    }
}
