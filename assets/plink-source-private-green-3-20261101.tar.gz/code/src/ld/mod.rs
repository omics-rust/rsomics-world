mod moments;
mod pairs;
mod prune;

pub(crate) use pairs::{PairConfig, PairReport, pairs};
pub(crate) use prune::{PruneConfig, PruneReport, PruneWindow, prune};

use crate::dataset::genotypes::Genotypes;
use crate::dataset::{Dataset, GenotypeReader, ImportProfile, InputSpec, VariantId, sibling};
use crate::execution::Execution;
use crate::make::{self, Selection};
use crate::{Result, invalid};
use moments::{Founders, HardCallKernel, HardCalls};
use rsomics_common::reject_output_alias;
use std::collections::{HashMap, VecDeque};
use std::mem::{size_of, size_of_val};
use std::ops::Range;
use std::path::{Path, PathBuf};

const IO_BYTES: usize = 196_608;

struct Prepared {
    dataset: Dataset,
    variants: Vec<usize>,
    founders: Founders,
    selected_samples: usize,
    chromosomes: Vec<Range<usize>>,
}

impl Prepared {
    fn open(prefix: &Path, selection: &Selection, minimum_founders: usize) -> Result<Self> {
        let dataset = Dataset::open(InputSpec::Pgen(prefix.to_owned()), ImportProfile::default())?;
        let (samples, variants) = make::select(&dataset, selection)?;
        let indices: Vec<_> = samples
            .iter()
            .copied()
            .filter(|&i| dataset.metadata.samples[i].founder())
            .collect();
        if indices.len() < minimum_founders {
            return Err(invalid(format!(
                "LD requires at least {minimum_founders} selected founders; found {}",
                indices.len()
            )));
        }
        let mut mask = vec![0; dataset.metadata.samples.len().div_ceil(64)];
        for &index in &indices {
            mask[index / 64] |= 1 << (index % 64);
        }
        let mut chromosomes = Vec::new();
        let mut start = 0;
        for (ordinal, &index) in variants.iter().enumerate() {
            let variant = &dataset.metadata.variants[index];
            if !variant.chromosome.is_autosome() || variant.alleles.len() != 2 {
                return Err(invalid(format!(
                    "initial LD workflow requires autosomal biallelic variants; {} is not eligible (select --autosome --max-alleles 2)",
                    variant.id
                )));
            }
            if ordinal != 0 {
                let previous = &dataset.metadata.variants[variants[ordinal - 1]];
                if previous.chromosome == variant.chromosome {
                    if previous.position > variant.position {
                        return Err(invalid(
                            "LD requires variants in nondecreasing position order within each chromosome",
                        ));
                    }
                } else {
                    if chromosomes.iter().any(|range: &Range<usize>| {
                        dataset.metadata.variants[variants[range.start]].chromosome
                            == variant.chromosome
                    }) {
                        return Err(invalid(
                            "LD requires each chromosome to occupy one contiguous block",
                        ));
                    }
                    chromosomes.push(start..ordinal);
                    start = ordinal;
                }
            }
        }
        chromosomes.push(start..variants.len());
        Ok(Self {
            selected_samples: samples.len(),
            dataset,
            variants,
            founders: Founders { indices, mask },
            chromosomes,
        })
    }

    fn indexed_bytes(&self) -> usize {
        let string_bytes = |values: &[String]| {
            values.iter().map(String::capacity).sum::<usize>() + size_of_val(values)
        };
        let metadata = &self.dataset.metadata;
        let samples = metadata
            .samples
            .iter()
            .map(|sample| {
                size_of_val(sample)
                    + sample.fid.capacity()
                    + sample.iid.capacity()
                    + sample.sid.capacity()
                    + sample.paternal.capacity()
                    + sample.maternal.capacity()
                    + string_bytes(&sample.fields)
            })
            .sum::<usize>();
        let variants = metadata
            .variants
            .iter()
            .map(|variant| {
                size_of_val(variant)
                    + variant.id.capacity()
                    + string_bytes(&variant.alleles)
                    + string_bytes(&variant.fields)
            })
            .sum::<usize>();
        samples
            + variants
            + string_bytes(&metadata.sample_header)
            + string_bytes(&metadata.variant_header)
            + string_bytes(&metadata.sample_preamble)
            + string_bytes(&metadata.variant_preamble)
            + (self.variants.capacity() + self.founders.indices.capacity()) * size_of::<usize>()
            + self.founders.mask.capacity() * size_of::<u64>()
            + self.chromosomes.capacity() * size_of::<Range<usize>>()
    }
}

struct Resources {
    workers: usize,
    workspace: usize,
    variant_reserve: usize,
    cache_bytes: usize,
    kernel: HardCallKernel,
}

impl Resources {
    fn new(
        input: &Prepared,
        execution: &Execution,
        tasks: usize,
        additional_bytes: usize,
    ) -> Result<Self> {
        let probe = input.dataset.reader()?;
        let workspace = probe.workspace_bytes();
        probe.close()?;
        let variant_reserve = input
            .dataset
            .metadata
            .samples
            .len()
            .checked_mul(32)
            .and_then(|value| value.checked_add(8192))
            .ok_or_else(|| invalid("LD variant memory estimate overflow"))?;
        let indexed = input
            .indexed_bytes()
            .checked_add(additional_bytes)
            .and_then(|value| value.checked_add(IO_BYTES))
            .ok_or_else(|| invalid("LD index memory estimate overflow"))?;
        let available = execution
            .memory_bytes
            .checked_sub(indexed)
            .ok_or_else(|| invalid("LD metadata and indexes exceed the memory budget"))?;
        let minimum = workspace
            .checked_add(IO_BYTES)
            .and_then(|value| value.checked_add(3 * variant_reserve))
            .ok_or_else(|| invalid("LD worker memory estimate overflow"))?;
        let workers = execution
            .requested_workers
            .min(execution.pool.current_num_threads())
            .min(tasks.max(1))
            .min(available / minimum);
        if workers == 0 {
            return Err(invalid(
                "LD memory budget cannot hold one reader and two packed variants",
            ));
        }
        let cache_bytes = available / workers - workspace - IO_BYTES - variant_reserve;
        Ok(Self {
            workers,
            workspace,
            variant_reserve,
            cache_bytes,
            kernel: HardCallKernel::detect(),
        })
    }
}

struct VariantData {
    raw: Genotypes,
    hard: HardCalls,
    major: usize,
    major_frequency: f64,
    bytes: usize,
}

struct VariantCache<'a> {
    reader: Box<dyn GenotypeReader>,
    founders: &'a Founders,
    resources: &'a Resources,
    values: HashMap<usize, Box<VariantData>>,
    order: VecDeque<usize>,
    used: usize,
}

impl<'a> VariantCache<'a> {
    fn open(input: &'a Prepared, resources: &'a Resources) -> Result<Self> {
        let reader = input.dataset.reader()?;
        if reader.workspace_bytes() > resources.workspace {
            return Err(invalid("LD reader workspace exceeds preflight reservation"));
        }
        Ok(Self {
            reader,
            founders: &input.founders,
            resources,
            values: HashMap::new(),
            order: VecDeque::new(),
            used: 0,
        })
    }

    fn ensure(&mut self, variant: usize, pinned: Option<usize>) -> Result<()> {
        if self.values.contains_key(&variant) {
            return Ok(());
        }
        while self.used + self.resources.variant_reserve > self.resources.cache_bytes {
            let old = self
                .order
                .pop_front()
                .ok_or_else(|| invalid("LD packed cache reservation exhausted"))?;
            if Some(old) == pinned {
                self.order.push_back(old);
                continue;
            }
            if let Some(value) = self.values.remove(&old) {
                self.used -= value.bytes;
            }
        }
        let raw = self.reader.read(VariantId(variant))?;
        let hard = HardCalls::new(&raw, self.founders);
        let (major, major_frequency) = moments::major_frequency(&raw, self.founders);
        let bytes = raw.bytes() + hard.bytes() + size_of::<VariantData>() + 256;
        if bytes > self.resources.variant_reserve {
            return Err(invalid("LD packed variant exceeds reserved memory"));
        }
        self.values.insert(
            variant,
            Box::new(VariantData {
                raw,
                hard,
                major,
                major_frequency,
                bytes,
            }),
        );
        self.order.push_back(variant);
        self.used += bytes;
        Ok(())
    }

    fn get(&self, variant: usize) -> &VariantData {
        &self.values[&variant]
    }

    fn close(self) -> Result<()> {
        self.reader.close()
    }
}

fn output_parent(prefix: &Path) -> &Path {
    prefix
        .parent()
        .filter(|path| !path.as_os_str().is_empty())
        .unwrap_or_else(|| Path::new("."))
}

fn check_outputs(
    prefix: &Path,
    selection: &Selection,
    output: &Path,
    extensions: &[&str],
) -> Result<()> {
    let mut inputs: Vec<PathBuf> = ["pgen", "pvar", "psam", "rsomics.json"]
        .iter()
        .map(|extension| sibling(prefix, extension))
        .collect();
    inputs.extend(
        [
            &selection.keep,
            &selection.remove,
            &selection.extract,
            &selection.exclude,
        ]
        .into_iter()
        .filter_map(|path| path.clone()),
    );
    for extension in extensions {
        reject_output_alias(
            &sibling(output, extension),
            inputs.iter().map(PathBuf::as_path),
        )?;
    }
    Ok(())
}
