import json
import os
from pathlib import Path
import subprocess
import tempfile

from compare_workflow import compare_metadata, compare_report, sha256, snapshot, table, verify_expected

ROOT = Path(__file__).resolve().parents[1]
INPUTS = ROOT / 'tests/fixtures/inputs'
EXPECTED = ROOT / 'tests/fixtures/expected'
LANES = ('gt', 'bed', 'pgen', 'ds', 'hds', 'rich')
SHAPES = {'gt': ((72, 64), (69, 58), (69, 5)), 'bed': ((72, 64), (69, 58), (69, 5)),
          'pgen': ((72, 64), (69, 58), (69, 5)), 'ds': ((72, 24), (70, 24), (70, 2)),
          'hds': ((72, 24), (70, 24), (70, 2)), 'rich': ((72, 24), (70, 24), (70, 1))}


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def main():
    binary = Path(os.environ['RSOMICS_PLINK_BIN']).resolve(strict=True)
    output = Path(os.environ.get('RSOMICS_PLINK_WORKFLOW_DIR') or tempfile.mkdtemp(prefix='plink-whole-workflow-')).resolve(strict=True)
    verify_expected(EXPECTED)
    policy_sha = sha256(ROOT / 'tests/COMPARISON.md')
    assert policy_sha == '4b99373876681ecc7379e0653d26eff696a6c2f7dbc97482c57a31b7c3caf806', 'comparison policy changed after freeze'
    save(output / 'identity.json', dict(binary=str(binary), binary_sha256=sha256(binary),
         comparison_policy_sha256=policy_sha, expected_manifest_sha256=sha256(EXPECTED / 'SOURCE.json')))
    generations, reports, summaries = [], {}, {}
    rounding_input = output / 'rounding.vcf'
    rounding_counts = ((636, 202, 42), (665, 211, 44), (155, 449, 316))
    with rounding_input.open('x') as stream:
        stream.write('##fileformat=VCFv4.3\n##contig=<ID=1,length=1000>\n')
        stream.write('#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\t' +
                     '\t'.join(f'sample{i}' for i in range(920)) + '\n')
        for i, (hom_ref, het, hom_alt) in enumerate(rounding_counts, 1):
            calls = ['0/0'] * hom_ref + ['0/1'] * het + ['1/1'] * hom_alt
            calls += ['./.'] * (920 - len(calls))
            stream.write(f'1\t{i}\trounding{i}\tA\tC\t.\tPASS\t.\tGT\t' + '\t'.join(calls) + '\n')

    def run(workers, name, *args):
        logs = output / str(workers) / 'calls' / name
        logs.mkdir(parents=True, exist_ok=False)
        argv = [str(binary), '--json', '--threads', str(workers), *map(str, args)]
        save(logs / 'request.json', dict(argv=argv))
        result = subprocess.run(argv, text=True, capture_output=True)
        (logs / 'stdout.txt').write_text(result.stdout)
        (logs / 'stderr.txt').write_text(result.stderr)
        save(logs / 'result.json', dict(returncode=result.returncode, stdout_sha256=sha256(logs / 'stdout.txt'), stderr_sha256=sha256(logs / 'stderr.txt')))
        assert result.returncode == 0, f'{name}: {argv}\n{result.stdout}\n{result.stderr}\nretained at {output}'
        report = json.loads(result.stdout)
        assert report['status'] == 'ok', report
        return report['result']

    for workers in (1, 4):
        case = output / str(workers)
        case.mkdir()
        principal = {}
        for lane in LANES:
            prefixes = {stage: case / f'{lane}.{stage}' for stage in ('I', 'F', 'P')}
            if lane == 'bed':
                source = ['--bfile', INPUTS / 'baseline']
            elif lane == 'pgen':
                source = ['--pfile', case / 'gt.I']
            else:
                source = ['--vcf', INPUTS / ('baseline.vcf' if lane == 'gt' else f'{lane}.vcf'), '--psam', INPUTS / 'baseline.psam']
                if lane in ('ds', 'hds'):
                    source += ['--dosage', lane]
                if lane == 'rich':
                    source += ['--split-par', 'b37']
            run(workers, f'{lane}.I.make', 'make', *source, '--out', prefixes['I'])
            initial_hashes = snapshot(prefixes['I'])
            filtering = ['--keep', INPUTS / 'keep.id', '--remove', INPUTS / 'remove.id']
            if lane in ('gt', 'bed', 'pgen'):
                filtering += ['--extract', INPUTS / 'selection.ids', '--exclude', INPUTS / 'exclusion.ids',
                              '--autosome', '--max-alleles', '2', '--mind', '0.125', '--geno', '0.125',
                              '--maf', '0.05', '--hwe', '0.000001']
            run(workers, f'{lane}.F.make', 'make', '--pfile', prefixes['I'], '--out', prefixes['F'], *filtering)
            filtered_hashes = snapshot(prefixes['F'])
            eligible = ['--autosome', '--max-alleles', '2'] if lane == 'rich' else []
            run(workers, f'{lane}.F.pairs', 'ld', 'pairs', '--pfile', prefixes['F'], '--out', case / f'{lane}.F.ld',
                '--window-variants', '1000000', '--window-bp', '500000', '--min-r2', '-1', *eligible)
            run(workers, f'{lane}.F.prune', 'ld', 'prune', '--pfile', prefixes['F'], '--out', case / f'{lane}.F.prune',
                '--window-bp', '500000', '--step', '1', '--r2', '0.2', *eligible)
            keep = Path(f'{case}/{lane}.F.prune.prune.in')
            drop = Path(f'{case}/{lane}.F.prune.prune.out')
            assert keep.read_text().splitlines() == (EXPECTED / lane / 'F/prune.prune.in').read_text().splitlines(), f'{lane}: ordered prune.in'
            assert drop.read_text().splitlines() == (EXPECTED / lane / 'F/prune.prune.out').read_text().splitlines(), f'{lane}: ordered prune.out'
            principal[f'{lane}.prune.in'] = keep
            principal[f'{lane}.prune.out'] = drop
            pair_path = Path(f'{case}/{lane}.F.ld.vcor')
            compare_report(pair_path, EXPECTED / lane / 'F/pairs.vcor')
            principal[f'{lane}.pairs'] = pair_path
            run(workers, f'{lane}.P.make', 'make', '--pfile', prefixes['F'], '--extract', keep, '--out', prefixes['P'])
            for stage in ('F', 'P'):
                qc = case / f'{lane}.{stage}.qc'
                report = run(workers, f'{lane}.{stage}.stats', 'stats', '--pfile', prefixes[stage], '--out', qc)
                summaries[f'{workers}/{lane}/{stage}'] = report
                for ext in ('acount', 'gcount', 'scount', 'smiss', 'vmiss', 'het') + (() if lane == 'rich' else ('hardy',)):
                    path = Path(f'{qc}.{ext}')
                    compare_report(path, EXPECTED / lane / stage / f'qc.{ext}')
                    principal[f'{lane}.{stage}.{ext}'] = path
                path = Path(f'{qc}.hwe-log.hardy')
                compare_report(path, EXPECTED / lane / stage / 'hwe-log.hardy')
                principal[f'{lane}.{stage}.log-hardy'] = path
            for index, stage in enumerate(('I', 'F', 'P')):
                metadata = compare_metadata(prefixes[stage], EXPECTED / lane / stage / 'data')
                shape = len(metadata['samples']), len(metadata['variants'])
                assert shape == SHAPES[lane][index], f'{lane}.{stage}: {shape} != {SHAPES[lane][index]}'
                generations.append(dict(workers=workers, lane=lane, stage=stage, prefix=str(prefixes[stage]),
                                        expected=str(EXPECTED / lane / stage / 'raw.jsonl'), shape=shape))
            assert snapshot(prefixes['I']) == initial_hashes, f'{lane}: native I mutated by descendants'
            assert snapshot(prefixes['F']) == filtered_hashes, f'{lane}: native F mutated by descendants'
            _, fvariants = table(f"{prefixes['F']}.pvar")
            _, pvariants = table(f"{prefixes['P']}.pvar")
            wanted = set(keep.read_text().splitlines())
            assert pvariants == [row for row in fvariants if row['ID'] in wanted], f'{lane}: native P metadata is not ordered F extraction'
            assert Path(f"{prefixes['P']}.psam").read_bytes() == Path(f"{prefixes['F']}.psam").read_bytes(), f'{lane}: native P sample metadata changed'
        tail = case / 'tail'
        run(workers, 'tail.stats', 'stats', '--pfile', case / 'gt.I', '--keep', INPUTS / 'founders64.id', '--out', tail)
        compare_report(Path(f'{tail}.hardy'), EXPECTED / 'tail/raw.hardy', projection=True)
        compare_report(Path(f'{tail}.hwe-log.hardy'), EXPECTED / 'tail/log.hardy', projection=True)
        principal['tail.raw'] = Path(f'{tail}.hardy')
        principal['tail.log'] = Path(f'{tail}.hwe-log.hardy')
        rounding = case / 'rounding'
        run(workers, 'rounding.make', 'make', '--vcf', rounding_input, '--out', rounding)
        run(workers, 'rounding.stats', 'stats', '--pfile', rounding, '--out', case / 'rounding.qc')
        for extension in ('hardy', 'hwe-log.hardy'):
            path = case / f'rounding.qc.{extension}'
            _, rows = table(path)
            assert [row['E(HET_A1)'] for row in rows] == ['0.272188', '0.272188', '0.484688']
            assert [tuple(int(row[key]) for key in ('HOM_A1_CT', 'HET_A1_CT', 'TWO_AX_CT'))
                    for row in rows] == list(rounding_counts)
            principal[f'rounding.{extension}'] = path
        reports[workers] = principal

    for key in reports[1]:
        assert reports[1][key].read_bytes() == reports[4][key].read_bytes(), f'worker1/4 report difference: {key}'
    save(output / 'native-graph.json', dict(status='reports_metadata_lists_passed_raw_pending',
         generations=generations, summaries=summaries, principal_report_files=len(reports[1]),
         note='test-only Rust inspector must compare all new native raw states before complete acceptance'))
    print(f'All source principal rows/lists/metadata passed; raw-state inspector pending: {output}')


if __name__ == '__main__':
    main()
