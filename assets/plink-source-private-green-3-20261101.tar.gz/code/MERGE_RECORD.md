# First-workflow implementation provenance

- Historical rsomics-pgen is BED/BIM/FAM-only, not a PGEN codec. Its disposition
  remains refactor/fixture material. This first native reader is a product-local
  typed implementation of the BED format, without reviving that repository or
  depending on the historical public crate.
- The real compressed PGEN reader/writer is the exact external pinned pgenlib
  codec. Source identity and component terms are recorded in vendor/SOURCE.json,
  LICENSES.md and THIRD_PARTY_NOTICES.md. It is not an all-Rust codec.
- VCF ingestion uses external noodles-vcf 0.90.0 Record/header/GT parsing and
  its BGZF reader. Dosage tokens are retained as f64 lexical numbers so f32
  conversion does not alter the adopted 16384ths quantization. Rust explicitly
  implements import selection, strict invalid-input cardinality, typed sample
  identities, chromosome metadata and phased/dosage policy from primary sources.
- Accepted source run41221033473 supplies engineering input, report, metadata
  and raw-state comparison fixtures. Expected F/P files never feed native
  descendants. Local native tests call the Rust product/pgenlib codec, never
  the upstream PLINK CLI, Python/R science or a source-runtime process.
- Rust output transactions and CLI UX consume published rsomics-common0.12.3
  and rsomics-help0.4.0. No LayerB/path/new public-foundation dependency is used.

- Historical team-owned rsomics-plink-hardy/src/lib.rs was inspected as a
  recurrence seed, not a direct command merge. Its PLINK1 groups/phenotypes and
  approximate tie rule are excluded. Private stats/hwe uses a log recurrence
  with exact integer near-tie likelihood comparison. The preflight frequency,
  freqx, heterozygosity and missingness assets remain formula/fixture material;
  their duplicate readers/defaults were not carried into this product.
- Historical rsomics-plink-ld at fbe04835ea2df60c1483dca06077aaf3d2e4739d and
  rsomics-plink-prune at d7ab7d45749118598a1583e67b270ecbeb0645e0 were inspected
  as formula/refactor seeds. Private LD uses packed founder pairwise-complete
  integer moments, streaming explicit dosages, bounded caches and source-bound
  backward order2 pruning. No whole-cohort matrix, per-pair sample vectors,
  missing-to-zero result or forward-only pruning policy was migrated.
- QC owns concrete report-specific populations, not a generic ploidy helper.
  All eight QC files are one recoverable output group. The one shared numeric
  constant is private exact2^-44, from the verified pinned source definition.

The full compact own-native I/F/QC/LD/prune/P/reload graph now matches accepted
principal reports, ordered lists, metadata/shapes and every raw state at1/4
workers. This is prepared engineering evidence, not a biological or performance
result. The private a1c50116 baseline subsequently passed native Linux/macOS
x86_64/aarch64 debug/release and same-output upstream reads in run41237806705,
then private Linux offline rebuild/codec replacement in run41241225963.
Those baseline receipts do not qualify a later source revision or public
distribution. A genuine representative cohort advantage and final public
source/install/release gates remain root-owned. Association/PCA/score/
relatedness/phasedLD/BCF remain excluded; no speculative component was introduced.

The product still pins immutable published common0.12.3/help0.4.0. A newer
common source fix or its CI does not retroactively update the registry consumer;
no local path patch or unverified consumer upgrade is claimed here.

The one adopted whole-review material wave reconciles header/PVAR REF at the
dataset boundary, admits complete make live workspace, removes the shim-owned
offset type alias violation and replaces quadratic sample projection with
linear cursors. A narrow process lock serializes only codec reader allocation/
initialization, not reads/compute. All original vendor and captured-answer
bodies are unchanged; the private adapter ABI is2. See IMPLEMENTATION.md for
the actual RED/whole-suite/production-entrypoint receipts and remaining gates.

Build storage policy is development-local: the wrapper still enforces our
Mac-mini external-disk paths, while build.rs checks canonical OUT_DIR containment
only when RSOMICS_GUARDED_TARGET_DIR is explicitly supplied. Ordinary downstream
source builds do not require our SSD paths or a fabricated Actions environment.
This build-policy-only revision changes no algorithm, FFI, CLI, dependency,
vendor body or captured answer. Its new final source binding and four-native
exact-head checks remain pending; one local Mac arm64 build does not qualify
Mac x86_64 installation or a public release.

Real HGDP qualification run41250502140 exposed three decimal half-boundary
cases in both Hardy reports. Private stats/numeric now follows the pinned
source dtoa_g decimal scaling and even-rounding window; Hardy expectations
also preserve its reciprocal-multiplication order. The arithmetic provenance
is plink2_misc.cc HardyReport and include/plink2_string.cc BankerRoundD/dtoa_g
in the already captured PLINK2 source. No upstream formatting routine is
linked, no scientific tolerance is relaxed, and LD implementation is unchanged.
The existing connected CLI test includes these three count cases. Local Mac
arm64 QC at1/4 workers additionally matches all16 complete retained HGDP source
tables, with worker outputs byte-identical. This narrow result does not replace
the failed original campaign, qualify a later four-native snapshot, or establish
a performance or publication gate.

The retained full HGDP pair table subsequently exposed source-major labels at
three exact50/50 allele-count cases and one further six-significant R2 boundary.
LD now shares the same product-private numeric formatter as QC, and computes
reference frequency in the pinned ComputeAlleleFreqs arithmetic order. Pair
work remains row-ordered but groups contiguous16-row Tasks into a few
pair-weighted partitions; each active partition owns its admitted reader/cache
instead of reopening and rebuilding overlapping windows per Task. The exact
integer moments loop is shared by portable and runtime-gated x86 POPCNT kernels;
dosage fallback, thresholds, traversal order and cache budget are unchanged.

Local Mac arm64 baseline/candidate pairs at1/4 workers retain all33,780,398
evaluations and2,527,798 emitted rows. Candidate pair tables match the complete
original source body exactly, and both candidate prune lists match at1/4.
Single diagnostic wall observations improved31.783→6.018s and10.890→2.712s;
maximum process RSS increased26.25→49.23MB and45.69→56.84MB with longer cache
lifetimes. These are same-Mac observations, not an upstream five-pair gate,
Linux/x86 kernel execution, four-native qualification or release authorization.
