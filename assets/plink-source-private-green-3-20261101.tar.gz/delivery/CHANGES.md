# Private delivery component history

2026-11-01: original pinned pgenlib/SIMDe vendor bodies remain unchanged.
The product's LGPL ABI2 adapter is team-authored and tracked separately;
its current exact body and every vendor original are bound by bundle.json.

2026-11-01: source delivery adds offline Cargo source-replacement configuration,
complete locked dependency closure and separately attributed original notice
supplements. Application/source checksums are not relabelled or rewritten.

2026-11-01: private-green-2 binds owning revision1d199b54 with the ordinary
macOS guard-policy correction. The historical private-green-1 delivery and its
original instructions remain preserved in that immutable archive.

The hosted replacement experiment, when authorized and actually executed,
records its distinct dated PgrInit-only derivative and build/output identities
in replacement.json. No such successful experiment is asserted by this file.

2026-11-01: private-green-3 binds owning revision00ce7b39f8decbeab40ed7f92f1191a304827b74 and its accepted native/source gate41258923590. It includes the shared private QC/LD numeric formatter, reference-frequency arithmetic, bounded pair-weighted cache partitions and runtime-gated x86 POPCNT with portable fallback. All85 locked dependencies and original pgenlib/SIMDe terms/bodies remain unchanged. Snapshot authority README status describes capture time; the new offline replacement proof remains pending and earlier bundle proofs do not qualify this revision.
