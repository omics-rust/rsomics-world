# Frozen supplied-expression inputs, 2026-10-31

This is an input-only archive. It contains no expected fit, moderation,
discovery or result output. Source outcomes will be captured separately.

`real/expression.tsv` is a byte-for-byte copy of the accepted source
run40606516204 workflow/results/logCPM.tsv (8066 features by7 samples).
The three other real files copy workflow/inputs/model-matrix.tsv,
samples.tsv and contrasts.tsv without changing bytes. Original run head:
d5e136a87c681e53095293638441a5a26c4dc503; source artifact12780957275,
archive SHA256 fac61c690c3f742335446c141ac2ad78c84fe3df33d20df8e0181cc31e43f5a2,
manifest SHA256 af682fed901644550411e6ae74e22b6bda45a7e567ca15e2dddc2c6b17027e97.
That source used edgeR4.10.7/current voomLmFit on DESeq2's shipped raw pasilla
carrier: filterByExpr/design, postfilter libraries and TMM produced this E.
It is now supplied already-logged E for ordinary unweighted lmFit, not a new
microarray cohort, raw counts, independent biological validation or the old
weighted fit's expected answer. No count processing is rerun. Metadata type
describes sequencing layout, not donors or a pairing declaration.

`equalvar` E/design copy original equalvar_expr.tsv/equalvar_design.tsv;
`constvar` E/design copy constvar_expr.tsv/constvar_design.tsv from team-owned
/Volumes/KIOXIA/Documents/omics-rust/rsomics-limma-ebayes/tests/golden/.
The historical dossier anchor is8fbfa0b8fcb9444dcf5740a4c4feab7a398e9c30.
These synthetic inputs are seeds; their old limma3.62.1 result goldens are
deliberately excluded. Their origin-only sample metadata and fully named
forward/reverse/mixed contrasts were authored now, not taken as old answers.

`two-row` and `one-zero` are nonrandom authored synthetic probes fixed in the
parent plan before any results. Two-row E is [[0,1,3,5],[-3,-1,0,1]]; one-zero
E is [[0,0,0,0]]. Their four samples use intercept plus group[0,0,1,1] and
contrast[0,1]. Authored metadata and design rows are deliberately reordered
to exercise exact identity joins. No data were tuned after source output.

All input files, including this note, are SHA256-bound in manifest.tsv.
