use crate::{fit::FittedAnalysis, results::Results};
use anyhow::Result;
use rsomics_common::{RsomicsError, write_atomic, write_output};
use std::{io::BufReader, path::Path};

pub fn save(path: &Path, fit: &FittedAnalysis) -> Result<()> {
    fit.validate()?;
    anyhow::ensure!(
        fit.initial_results.is_some(),
        "cannot save an incomplete analysis without initial contrast results"
    );
    anyhow::ensure!(path != Path::new("-"), "a named bundle path is required");
    write_output(Some(path), |file| {
        serde_json::to_writer(file, fit).map_err(crate::cli::json_error)
    })?;
    Ok(())
}

pub fn load(path: &Path) -> Result<FittedAnalysis> {
    let fit: FittedAnalysis = serde_json::from_reader(BufReader::new(std::fs::File::open(path)?))
        .map_err(|error: serde_json::Error| {
        if error.is_io() {
            crate::cli::json_error(error)
        } else {
            RsomicsError::InvalidInput(format!(
                "cannot read fitted bundle; schema {} is required: {error}",
                crate::fit::SCHEMA
            ))
        }
    })?;
    fit.validate()?;
    anyhow::ensure!(
        fit.initial_results.is_some(),
        "incomplete analysis: missing initial contrast results"
    );
    Ok(fit)
}

pub fn results(path: &Path, fit: &FittedAnalysis, result: &Results) -> Result<()> {
    anyhow::ensure!(path != Path::new("-"), "a named result path is required");
    write_atomic(path, |file| {
        let mut writer = csv::WriterBuilder::new().delimiter(b'\t').from_writer(file);
        let mut operation = || -> Result<()> {
            writer.write_record([
                "gene",
                "baseMean",
                "log2FoldChange",
                "lfcSE",
                "stat",
                "pvalue",
                "padj",
            ])?;
            for (gene, row) in fit.dataset.counts.genes.iter().zip(&result.rows) {
                writer.write_record([
                    gene.clone(),
                    row.base_mean.to_string(),
                    number(row.log2_fold_change),
                    number(row.lfc_se),
                    number(row.stat),
                    number(row.pvalue),
                    number(row.padj),
                ])?;
            }
            writer.flush()?;
            Ok(())
        };
        operation().map_err(crate::cli::process_error)
    })?;
    Ok(())
}

pub fn transform(path: &Path, fit: &FittedAnalysis, vst: bool) -> Result<()> {
    anyhow::ensure!(path != Path::new("-"), "a named transform path is required");
    write_atomic(path, |file| {
        let mut writer = csv::WriterBuilder::new().delimiter(b'\t').from_writer(file);
        let mut operation = || -> Result<()> {
            writer.write_record(
                std::iter::once("gene")
                    .chain(fit.dataset.counts.samples.iter().map(String::as_str)),
            )?;
            for (g, gene) in fit.dataset.counts.genes.iter().enumerate() {
                writer.write_record(
                    std::iter::once(gene.clone()).chain(
                        (0..fit.dataset.counts.n_samples)
                            .map(|j| {
                                if vst {
                                    fit.vst(g, j)
                                } else {
                                    fit.normalized(g, j)
                                }
                            })
                            .map(|v| v.to_string()),
                    ),
                )?;
            }
            writer.flush()?;
            Ok(())
        };
        operation().map_err(crate::cli::process_error)
    })?;
    Ok(())
}

pub fn inspect(path: &Path, fit: &FittedAnalysis, queries: &Path) -> Result<()> {
    anyhow::ensure!(
        path != Path::new("-"),
        "a named inspection path is required"
    );
    let mut reader = csv::ReaderBuilder::new()
        .delimiter(b'\t')
        .from_path(queries)?;
    anyhow::ensure!(
        reader.headers()?.iter().eq(["query", "mean"]),
        "trend queries require query and mean columns"
    );
    let mut identities = std::collections::HashSet::new();
    let values = reader
        .records()
        .map(|row| -> Result<_> {
            let row = row?;
            anyhow::ensure!(
                !row[0].is_empty() && identities.insert(row[0].to_owned()),
                "empty or duplicate trend query identity"
            );
            let mean = row[1].trim().parse::<f64>()?;
            anyhow::ensure!(
                mean.is_finite() && mean > 0.0,
                "trend query means must be finite and positive"
            );
            let dispersion = fit.dispersions.trend.value(mean);
            anyhow::ensure!(
                dispersion.is_finite() && dispersion > 0.0,
                "non-finite or non-positive saved trend prediction"
            );
            Ok([row[0].to_owned(), mean.to_string(), dispersion.to_string()])
        })
        .collect::<Result<Vec<_>>>()?;
    anyhow::ensure!(!values.is_empty(), "trend queries have no data rows");
    write_output(Some(path), |file| {
        let operation = || -> Result<()> {
            let mut writer = csv::WriterBuilder::new().delimiter(b'\t').from_writer(file);
            writer.write_record(["query", "mean", "dispersion"])?;
            for row in &values {
                writer.write_record(row)?;
            }
            writer.flush()?;
            Ok(())
        };
        operation().map_err(crate::cli::process_error)
    })?;
    Ok(())
}

fn number(value: Option<f64>) -> String {
    value.map(|v| v.to_string()).unwrap_or_else(|| "NA".into())
}
