use crate::{dataset::Dataset, dispersion::Trend, normalization::Normalization};
use anyhow::{Result, ensure};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum Transform {
    Analytic,
    Local(LocalTransform),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum FactorSource {
    ExistingSizeFactors,
    NormalizationGeometricAllRows,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LocalTransform {
    pub factor_source: FactorSource,
    pub size_factors: Vec<f64>,
    pub xim: f64,
    pub max_normalized: f64,
    pub h1: f64,
    pub h2: f64,
    pub eta: f64,
    pub xi: f64,
    pub spline: Fmm,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Fmm {
    pub x: Vec<f64>,
    pub y: Vec<f64>,
    pub b: Vec<f64>,
    pub c: Vec<f64>,
    pub d: Vec<f64>,
}

impl Transform {
    pub(crate) fn fit(dataset: &Dataset, trend: &Trend, means: &[f64]) -> Result<Self> {
        if !matches!(trend, Trend::Local { .. }) {
            return Ok(Self::Analytic);
        }
        let counts = &dataset.counts;
        let n = counts.n_samples;
        let (factor_source, size_factors) = match &dataset.normalization {
            Normalization::Ratio { factors } | Normalization::SuppliedSize { factors } => {
                (FactorSource::ExistingSizeFactors, factors.clone())
            }
            Normalization::SuppliedMatrix {
                size_factors: Some(factors),
                ..
            } => (FactorSource::ExistingSizeFactors, factors.clone()),
            Normalization::SuppliedMatrix {
                factors,
                size_factors: None,
            } => (
                FactorSource::NormalizationGeometricAllRows,
                (0..n)
                    .map(|j| {
                        ((0..counts.n_genes)
                            .map(|g| factors[g * n + j].ln())
                            .sum::<f64>()
                            / counts.n_genes as f64)
                            .exp()
                    })
                    .collect(),
            ),
        };
        let xim = size_factors.iter().map(|s| 1.0 / s).sum::<f64>() / n as f64;
        let max_normalized = (0..counts.n_genes)
            .flat_map(|g| {
                counts
                    .row(g)
                    .iter()
                    .zip(dataset.normalization.row(g, n))
                    .map(|(y, s)| y / s)
            })
            .fold(0.0, f64::max);
        ensure!(
            max_normalized.is_finite() && max_normalized > 0.0 && xim.is_finite() && xim > 0.0,
            "undefined local VST range or normalization"
        );
        let step = max_normalized.asinh() / 999.0;
        let grid = (1..=999)
            .map(|i| (i as f64 * step).sinh())
            .collect::<Vec<_>>();
        let integrand = grid
            .iter()
            .map(|q| 1.0 / (trend.value(*q) * q * q + xim * q).sqrt())
            .collect::<Vec<_>>();
        ensure!(
            integrand.iter().all(|v| v.is_finite() && *v > 0.0),
            "non-finite local VST integrand"
        );
        let mut integral = 0.0;
        let mut x = Vec::with_capacity(998);
        let mut y = Vec::with_capacity(998);
        for i in 1..grid.len() {
            x.push(((grid[i] + grid[i - 1]) / 2.0).asinh());
            integral += (grid[i] - grid[i - 1]) * (integrand[i] + integrand[i - 1]) / 2.0;
            y.push(integral);
        }
        let spline = Fmm::fit(x, y)?;
        let mut means = means.to_vec();
        means.sort_by(f64::total_cmp);
        let quantile = |p: f64| {
            let index = (means.len() - 1) as f64 * p;
            let lo = index.floor() as usize;
            let fraction = index - lo as f64;
            (1.0 - fraction) * means[lo] + fraction * means[index.ceil() as usize]
        };
        let h1 = quantile(0.95);
        let h2 = quantile(0.999);
        let eta = (h2.log2() - h1.log2()) / (spline.value(h2.asinh()) - spline.value(h1.asinh()));
        let xi = h1.log2() - eta * spline.value(h1.asinh());
        let transform = Self::Local(LocalTransform {
            factor_source,
            size_factors,
            xim,
            max_normalized,
            h1,
            h2,
            eta,
            xi,
            spline,
        });
        transform.validate(dataset, trend)?;
        Ok(transform)
    }

    pub(crate) fn validate(&self, dataset: &Dataset, trend: &Trend) -> Result<()> {
        match (self, trend) {
            (Self::Local(local), Trend::Local { .. }) => {
                ensure!(
                    local.size_factors.len() == dataset.counts.n_samples
                        && local.size_factors.iter().all(|x| x.is_finite() && *x > 0.0)
                        && [
                            local.xim,
                            local.max_normalized,
                            local.h1,
                            local.h2,
                            local.eta
                        ]
                        .iter()
                        .all(|x| x.is_finite() && *x > 0.0)
                        && local.xi.is_finite()
                        && local.h2 > local.h1,
                    "invalid saved local VST calibration"
                );
                local.spline.validate()?;
                ensure!(local.spline.x.len() == 998, "invalid local VST grid size");
                let expected = match &dataset.normalization {
                    Normalization::Ratio { factors } | Normalization::SuppliedSize { factors } => {
                        Some(factors)
                    }
                    Normalization::SuppliedMatrix { size_factors, .. } => size_factors.as_ref(),
                };
                ensure!(
                    match (&local.factor_source, expected) {
                        (FactorSource::ExistingSizeFactors, Some(factors)) =>
                            factors == &local.size_factors,
                        (FactorSource::NormalizationGeometricAllRows, None) => true,
                        _ => false,
                    },
                    "local VST factor provenance differs from normalization"
                );
            }
            (Self::Analytic, Trend::Parametric { .. } | Trend::Mean { .. }) => {}
            _ => anyhow::bail!("saved VST differs from actual trend policy"),
        }
        Ok(())
    }
}

impl Fmm {
    fn fit(x: Vec<f64>, y: Vec<f64>) -> Result<Self> {
        let n = x.len();
        ensure!(
            n >= 4 && y.len() == n && x.windows(2).all(|v| v[1] > v[0]),
            "invalid FMM knots"
        );
        let h = x.windows(2).map(|v| v[1] - v[0]).collect::<Vec<_>>();
        let slopes = y
            .windows(2)
            .zip(&h)
            .map(|(v, h)| (v[1] - v[0]) / h)
            .collect::<Vec<_>>();
        let third = |i: usize| {
            ((slopes[i + 2] - slopes[i + 1]) / (x[i + 3] - x[i + 1])
                - (slopes[i + 1] - slopes[i]) / (x[i + 2] - x[i]))
                / (x[i + 3] - x[i])
        };
        let mut diagonal = vec![0.0; n];
        let mut upper = vec![0.0; n];
        let mut lower = vec![0.0; n];
        let mut second = vec![0.0; n];
        diagonal[0] = -1.0;
        upper[0] = 1.0;
        second[0] = 6.0 * third(0) * h[0];
        for i in 1..n - 1 {
            lower[i] = h[i - 1];
            diagonal[i] = 2.0 * (h[i - 1] + h[i]);
            upper[i] = h[i];
            second[i] = 6.0 * (slopes[i] - slopes[i - 1]);
        }
        lower[n - 1] = -1.0;
        diagonal[n - 1] = 1.0;
        second[n - 1] = 6.0 * third(n - 4) * h[n - 2];
        for i in 1..n {
            let ratio = lower[i] / diagonal[i - 1];
            diagonal[i] -= ratio * upper[i - 1];
            second[i] -= ratio * second[i - 1];
        }
        second[n - 1] /= diagonal[n - 1];
        for i in (0..n - 1).rev() {
            second[i] = (second[i] - upper[i] * second[i + 1]) / diagonal[i];
        }
        let mut b = vec![0.0; n];
        let c = second.iter().map(|m| m / 2.0).collect::<Vec<_>>();
        let mut d = vec![0.0; n];
        for i in 0..n - 1 {
            b[i] = slopes[i] - h[i] * (2.0 * second[i] + second[i + 1]) / 6.0;
            d[i] = (second[i + 1] - second[i]) / (6.0 * h[i]);
        }
        b[n - 1] = slopes[n - 2] + h[n - 2] * (second[n - 2] + 2.0 * second[n - 1]) / 6.0;
        d[n - 1] = d[n - 2];
        let spline = Self { x, y, b, c, d };
        spline.validate()?;
        Ok(spline)
    }

    fn validate(&self) -> Result<()> {
        let n = self.x.len();
        ensure!(
            n >= 4
                && [&self.y, &self.b, &self.c, &self.d]
                    .iter()
                    .all(|v| v.len() == n)
                && [&self.x, &self.y, &self.b, &self.c, &self.d]
                    .iter()
                    .all(|v| v.iter().all(|x| x.is_finite()))
                && self.x.windows(2).all(|v| v[0] < v[1]),
            "invalid saved FMM coefficients"
        );
        Ok(())
    }

    pub(crate) fn value(&self, x: f64) -> f64 {
        let i = self.x.partition_point(|k| *k <= x).saturating_sub(1);
        let dx = x - self.x[i];
        self.y[i] + dx * (self.b[i] + dx * (self.c[i] + dx * self.d[i]))
    }
}
