use crate::{
    dataset::{Dataset, DesignInput},
    design::{self, DesignSource},
    normalization::Normalization,
};

fn metadata() -> Vec<Vec<String>> {
    let mut rows = Vec::new();
    for group in ["A", "B", "C"] {
        for batch in ["b1", "b2"] {
            for x in [-1, 0, 1] {
                rows.push(vec![batch.into(), group.into(), x.to_string()]);
            }
        }
    }
    rows
}

#[test]
fn formula_terms_and_coding_preserve_general_design() {
    let columns = vec!["batch".into(), "group".into(), "x".into()];
    let factors = vec!["group=A,B,C".into(), "batch=b1,b2".into()];
    let (matrix, source) = design::from_metadata(
        "~batch*group + group*x",
        &["x".into()],
        &factors,
        &columns,
        &metadata(),
    )
    .unwrap();
    assert_eq!(
        matrix.names,
        [
            "(Intercept)",
            "batchb2",
            "groupB",
            "groupC",
            "x",
            "batchb2:groupB",
            "batchb2:groupC",
            "groupB:x",
            "groupC:x"
        ]
    );
    assert_eq!(matrix.rowvec(17), [1., 1., 0., 1., 1., 0., 1., 0., 1.]);
    source.validate(&matrix, &columns, &metadata()).unwrap();
    let DesignSource::Formula(model) = source else {
        panic!()
    };
    assert_eq!(model.assign, [0, 1, 2, 2, 3, 4, 4, 5, 5]);
    assert_eq!(
        model.coefficient_names,
        [
            "Intercept",
            "batch_b2_vs_b1",
            "group_B_vs_A",
            "group_C_vs_A",
            "x",
            "batchb2.groupB",
            "batchb2.groupC",
            "groupB.x",
            "groupC.x"
        ]
    );
    let (no_intercept, _) = design::from_metadata(
        "~0+group+batch+x",
        &["x".into()],
        &factors,
        &columns,
        &metadata(),
    )
    .unwrap();
    assert_eq!(
        no_intercept.names,
        ["groupA", "groupB", "groupC", "batchb2", "x"]
    );
    assert_eq!(no_intercept.rowvec(17), [0., 0., 1., 1., 1.]);
    let (slopes, _) = design::from_metadata(
        "~group:x",
        &["x".into()],
        &["group=A,B,C".into()],
        &columns,
        &metadata(),
    )
    .unwrap();
    assert_eq!(
        slopes.names,
        ["(Intercept)", "groupA:x", "groupB:x", "groupC:x"]
    );
    let (dropped, origin) = design::from_metadata(
        "~group+x",
        &["x".into()],
        &["group=unused,A,B,C".into()],
        &columns,
        &metadata(),
    )
    .unwrap();
    assert_eq!(dropped.names, ["(Intercept)", "groupB", "groupC", "x"]);
    origin.validate(&dropped, &columns, &metadata()).unwrap();
    let (parentheses, _) = design::from_metadata(
        "~batch*(group+x)",
        &["x".into()],
        &factors,
        &columns,
        &metadata(),
    )
    .unwrap();
    assert_eq!(
        parentheses.names,
        [
            "(Intercept)",
            "batchb2",
            "groupB",
            "groupC",
            "x",
            "batchb2:groupB",
            "batchb2:groupC",
            "batchb2:x"
        ]
    );
    for formula in ["~log(x)", "~x^2", "~offset(x)", "~.", "~x y", "~x - group"] {
        assert!(
            design::from_metadata(formula, &["x".into()], &[], &columns, &metadata()).is_err(),
            "{formula}"
        );
    }
    let constant = vec![vec!["1".to_owned()]; 8];
    assert!(design::from_metadata("~0+x", &["x".into()], &[], &["x".into()], &constant).is_err());
    let (_, intercept) = design::from_metadata("~1", &[], &[], &["x".into()], &constant).unwrap();
    let (_, expanded) =
        design::from_metadata("~1+0+1", &[], &[], &["x".into()], &constant).unwrap();
    assert!(intercept.intercept_shortcut());
    assert!(!expanded.intercept_shortcut());
}

#[test]
fn identity_joined_factors_keep_nf_priority_and_unscaled_sf() {
    let dir = tempfile::tempdir().unwrap();
    let counts = dir.path().join("counts.tsv");
    let samples = dir.path().join("samples.tsv");
    let sf = dir.path().join("sf.tsv");
    let nf = dir.path().join("nf.tsv");
    let ids = (0..18).map(|j| format!("s{j}")).collect::<Vec<_>>();
    std::fs::write(
        &counts,
        format!(
            "gene\t{}\nzero\t{}\nexpressed\t{}\n",
            ids.join("\t"),
            vec!["0"; 18].join("\t"),
            (1..=18)
                .map(|j| (2 * j).to_string())
                .collect::<Vec<_>>()
                .join("\t")
        ),
    )
    .unwrap();
    std::fs::write(
        &samples,
        format!(
            "sample\tbatch\tgroup\tx\n{}",
            metadata()
                .iter()
                .enumerate()
                .rev()
                .map(|(j, row)| format!("s{j}\t{}\n", row.join("\t")))
                .collect::<String>()
        ),
    )
    .unwrap();
    std::fs::write(
        &sf,
        format!(
            "sample\tfactor\n{}",
            (0..18)
                .rev()
                .map(|j| format!("s{j}\t{}\n", 3 + j))
                .collect::<String>()
        ),
    )
    .unwrap();
    std::fs::write(
        &nf,
        format!(
            "gene\t{}\nexpressed\t{}\nzero\t{}\n",
            ids.iter().rev().cloned().collect::<Vec<_>>().join("\t"),
            (1..=18)
                .rev()
                .map(|j| (2 * j).to_string())
                .collect::<Vec<_>>()
                .join("\t"),
            vec!["200"; 18].join("\t")
        ),
    )
    .unwrap();
    let data = Dataset::read_inputs(
        &counts,
        &samples,
        DesignInput::Formula {
            formula: "~batch*group+group*x",
            numeric: &["x".into()],
            factors: &["batch=b1,b2".into(), "group=A,B,C".into()],
        },
        Some(&sf),
        Some(&nf),
    )
    .unwrap();
    assert_eq!(data.design.rowvec(17), [1., 1., 0., 1., 1., 0., 1., 0., 1.]);
    assert_eq!(data.normalization.row(1, 18)[0], 2.0);
    assert_eq!(data.normalization.row(1, 18)[17], 36.0);
    assert!(
        data.counts
            .row(1)
            .iter()
            .zip(data.normalization.row(1, 18))
            .all(|(y, n)| y / n == 1.0)
    );
    assert!((data.normalization.moments_scale(&data.counts) - 0.09708633550545315).abs() < 1e-15);
    assert!(
        matches!(&data.normalization, Normalization::SuppliedMatrix { size_factors: Some(values), .. } if values[0] == 3.0 && values[17] == 20.0)
    );
    let loaded: Dataset = serde_json::from_slice(&serde_json::to_vec(&data).unwrap()).unwrap();
    loaded.validate().unwrap();
    assert!(loaded.input_sha256.contains_key("normalization_factors"));
    assert!(loaded.input_sha256.contains_key("size_factors"));
}
