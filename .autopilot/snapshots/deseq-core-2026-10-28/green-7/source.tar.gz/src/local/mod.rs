mod config;
mod error;
mod kernel;
mod local_fit;
mod wls;

use anyhow::{Result, ensure};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Knot {
    pub x: f64,
    pub value: f64,
    pub slope: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Curve {
    pub method: CurveMethod,
    pub knots: Vec<Knot>,
    pub boundary_curvature: Option<f64>,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CurveMethod {
    RcompatLocfit015GeneralHermite,
}

impl Curve {
    pub(crate) fn fit(selected: &[(f64, f64)]) -> Result<Self> {
        ensure!(
            selected
                .iter()
                .all(|(m, d)| m.is_finite() && *m > 0.0 && d.is_finite() && *d > 0.0),
            "local trend requires finite positive means and dispersions"
        );
        let x = selected.iter().map(|(m, _)| m.ln()).collect::<Vec<_>>();
        let y = selected.iter().map(|(_, d)| d.ln()).collect::<Vec<_>>();
        let weights = selected.iter().map(|(m, _)| *m).collect::<Vec<_>>();
        let model = local_fit::LocalFit::fit(
            &x,
            &y,
            Some(&weights),
            config::LocalRegressionConfig {
                prediction_method: config::PredictionMethod::LocfitHermiteApprox,
                ..Default::default()
            },
        )?;
        let curve = model.into_curve()?;
        curve.validate()?;
        Ok(curve)
    }

    pub(crate) fn validate(&self) -> Result<()> {
        ensure!(
            self.knots.len() >= 2
                && self
                    .knots
                    .iter()
                    .all(|k| k.x.is_finite() && k.value.is_finite() && k.slope.is_finite())
                && self.knots.windows(2).all(|k| k[0].x < k[1].x)
                && self.boundary_curvature.is_none_or(f64::is_finite),
            "invalid saved local trend curve"
        );
        Ok(())
    }

    pub(crate) fn log_value(&self, x: f64) -> f64 {
        let upper = self.knots.partition_point(|k| k.x <= x);
        let boundary = if upper == 0 {
            Some(&self.knots[0])
        } else if upper >= self.knots.len() {
            self.knots.last()
        } else {
            None
        };
        if let (Some(k), Some(curvature)) = (boundary, self.boundary_curvature) {
            let dx = x - k.x;
            return (0.5 * curvature).mul_add(dx, k.slope).mul_add(dx, k.value);
        }
        let left = upper.saturating_sub(1).min(self.knots.len() - 2);
        let (a, b) = (&self.knots[left], &self.knots[left + 1]);
        let h = b.x - a.x;
        let t = (x - a.x) / h;
        let cubic = 2.0 * (a.value - b.value) + h * (a.slope + b.slope);
        let quadratic = 3.0 * (b.value - a.value) - h * (2.0 * a.slope + b.slope);
        cubic
            .mul_add(t, quadratic)
            .mul_add(t, h * a.slope)
            .mul_add(t, a.value)
    }
}
