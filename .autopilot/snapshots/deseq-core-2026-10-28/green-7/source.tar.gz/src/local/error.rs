// Adapted from rcompat-locfit 0.1.5, Copyright (c) 2026 Denis Demin.
// MIT license: ../../LICENSES/rcompat-locfit-MIT.txt.
use std::fmt;

#[derive(Debug, Clone, PartialEq)]
pub enum LocfitError {
    LengthMismatch {
        x: usize,
        y: usize,
        weights: Option<usize>,
    },
    EmptyInput,
    NotEnoughFinitePoints {
        required: usize,
        actual: usize,
    },
    InvalidConfig(String),
    InvalidInput(String),
    SingularFit,
}

impl fmt::Display for LocfitError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::LengthMismatch { x, y, weights } => {
                write!(f, "input length mismatch: x={x}, y={y}")?;
                if let Some(weights) = weights {
                    write!(f, ", weights={weights}")?;
                }
                Ok(())
            }
            Self::EmptyInput => write!(f, "input is empty"),
            Self::NotEnoughFinitePoints { required, actual } => write!(
                f,
                "not enough finite positively weighted points: required {required}, got {actual}"
            ),
            Self::InvalidConfig(message) => write!(f, "invalid config: {message}"),
            Self::InvalidInput(message) => write!(f, "invalid input: {message}"),
            Self::SingularFit => write!(f, "local fit is singular"),
        }
    }
}

impl std::error::Error for LocfitError {}
