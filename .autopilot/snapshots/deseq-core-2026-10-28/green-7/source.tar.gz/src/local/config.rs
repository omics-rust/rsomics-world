// Adapted from rcompat-locfit 0.1.5, Copyright (c) 2026 Denis Demin.
// MIT license: ../../LICENSES/rcompat-locfit-MIT.txt.
use super::error::LocfitError;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Kernel {
    Tricube,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PredictionMethod {
    Direct,
    LocfitHermiteApprox,
}

#[derive(Clone, Debug)]
pub struct LocalRegressionConfig {
    pub alpha: f64,
    pub degree: usize,
    pub kernel: Kernel,
    pub min_points: usize,
    pub allow_degree_downgrade: bool,
    pub prediction_method: PredictionMethod,
}

impl Default for LocalRegressionConfig {
    fn default() -> Self {
        Self {
            alpha: 0.7,
            degree: 2,
            kernel: Kernel::Tricube,
            min_points: 3,
            allow_degree_downgrade: true,
            prediction_method: PredictionMethod::Direct,
        }
    }
}

impl LocalRegressionConfig {
    pub(crate) fn validate(&self) -> Result<(), LocfitError> {
        if !self.alpha.is_finite() || self.alpha <= 0.0 {
            return Err(LocfitError::InvalidConfig(
                "alpha must be finite and greater than zero".to_string(),
            ));
        }
        if self.alpha > 1.0 {
            return Err(LocfitError::InvalidConfig(
                "alpha values greater than 1 are not supported yet".to_string(),
            ));
        }
        if self.degree > 2 {
            return Err(LocfitError::InvalidConfig(
                "degree must be 0, 1, or 2".to_string(),
            ));
        }
        if self.min_points == 0 {
            return Err(LocfitError::InvalidConfig(
                "min_points must be greater than zero".to_string(),
            ));
        }
        Ok(())
    }
}
