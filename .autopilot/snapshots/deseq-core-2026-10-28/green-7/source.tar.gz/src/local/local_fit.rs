// Adapted from rcompat-locfit 0.1.5, Copyright (c) 2026 Denis Demin.
// MIT license: ../../LICENSES/rcompat-locfit-MIT.txt.
use super::config::{LocalRegressionConfig, PredictionMethod};
use super::error::LocfitError;
use super::kernel;
use super::wls;

#[derive(Clone, Debug)]
struct Point {
    x: f64,
    y: f64,
    weight: f64,
    original_index: usize,
}

#[derive(Clone, Debug)]
pub struct LocalFit {
    points: Vec<Point>,
    config: LocalRegressionConfig,
    evaluation_points: Option<Vec<EvaluationPoint>>,
    boundary_curvature: Option<f64>,
}

impl LocalFit {
    pub fn fit(
        x: &[f64],
        y: &[f64],
        weights: Option<&[f64]>,
        config: LocalRegressionConfig,
    ) -> Result<Self, LocfitError> {
        config.validate()?;

        if x.len() != y.len() || weights.is_some_and(|w| w.len() != x.len()) {
            return Err(LocfitError::LengthMismatch {
                x: x.len(),
                y: y.len(),
                weights: weights.map(<[f64]>::len),
            });
        }
        if x.is_empty() {
            return Err(LocfitError::EmptyInput);
        }

        let mut points = Vec::with_capacity(x.len());
        for index in 0..x.len() {
            let weight = weights.map_or(1.0, |w| w[index]);
            if x[index].is_finite() && y[index].is_finite() && weight.is_finite() && weight > 0.0 {
                points.push(Point {
                    x: x[index],
                    y: y[index],
                    weight,
                    original_index: index,
                });
            } else {
                return Err(LocfitError::InvalidInput("local fitting requires finite predictors/responses and positive finite weights".into()));
            }
        }

        let required = config.min_points.max(1);
        if points.len() < required {
            return Err(LocfitError::NotEnoughFinitePoints {
                required,
                actual: points.len(),
            });
        }

        let mut fit = Self {
            points,
            config,
            evaluation_points: None,
            boundary_curvature: None,
        };
        fit.evaluation_points = fit.build_evaluation_points()?;
        fit.boundary_curvature = fit.global_quadratic_curvature();

        Ok(fit)
    }

    pub(super) fn into_curve(self) -> Result<super::Curve, LocfitError> {
        let knots = self.evaluation_points.ok_or_else(|| {
            LocfitError::InvalidInput("degenerate local grid is not supported".into())
        })?;
        Ok(super::Curve {
            method: super::CurveMethod::RcompatLocfit015GeneralHermite,
            knots,
            boundary_curvature: self.boundary_curvature,
        })
    }

    fn predict_direct_with_derivative(&self, x0: f64) -> Result<(f64, f64), LocfitError> {
        if !x0.is_finite() {
            return Err(LocfitError::InvalidInput(
                "prediction point must be finite".to_string(),
            ));
        }

        let mut distances: Vec<_> = self
            .points
            .iter()
            .enumerate()
            .map(|(point_index, point)| Distance {
                point_index,
                original_index: point.original_index,
                distance: (point.x - x0).abs(),
            })
            .collect();

        distances.sort_by(|a, b| {
            a.distance
                .total_cmp(&b.distance)
                .then_with(|| a.original_index.cmp(&b.original_index))
        });

        let max_degree = self.config.degree.min(self.points.len().saturating_sub(1));
        self.predict_polynomial_with_downgrade(x0, &distances, max_degree)
    }

    fn build_evaluation_points(&self) -> Result<Option<Vec<EvaluationPoint>>, LocfitError> {
        if self.config.prediction_method != PredictionMethod::LocfitHermiteApprox {
            return Ok(None);
        }

        let Some((min_x, max_x)) = self.x_range() else {
            return Ok(None);
        };
        if min_x == max_x {
            return Ok(None);
        }

        let xs = locfit_like_evaluation_xs(&self.points, min_x, max_x, self.config.alpha)?;

        let mut evaluation_points = Vec::with_capacity(xs.len());
        for x in xs {
            let (value, slope) = self.predict_direct_with_derivative(x)?;
            evaluation_points.push(EvaluationPoint { x, value, slope });
        }
        evaluation_points.sort_by(|a, b| a.x.total_cmp(&b.x));
        evaluation_points.dedup_by(|a, b| a.x == b.x);

        if evaluation_points.len() < 2 {
            Ok(None)
        } else {
            Ok(Some(evaluation_points))
        }
    }

    fn x_range(&self) -> Option<(f64, f64)> {
        let mut values = self.points.iter().map(|point| point.x);
        let first = values.next()?;
        let mut min_x = first;
        let mut max_x = first;
        for x in values {
            min_x = min_x.min(x);
            max_x = max_x.max(x);
        }
        Some((min_x, max_x))
    }

    fn global_quadratic_curvature(&self) -> Option<f64> {
        if self.config.prediction_method != PredictionMethod::LocfitHermiteApprox
            || self.config.degree < 2
            || self.points.len() < 3
        {
            return None;
        }

        let weight_sum = self.points.iter().map(|point| point.weight).sum::<f64>();
        if weight_sum <= 0.0 {
            return None;
        }
        let center = self
            .points
            .iter()
            .map(|point| point.weight * point.x)
            .sum::<f64>()
            / weight_sum;
        let global_points: Vec<_> = self.points.iter().collect();
        let z: Vec<_> = global_points.iter().map(|point| point.x - center).collect();
        let y: Vec<_> = global_points.iter().map(|point| point.y).collect();
        let weights: Vec<_> = global_points.iter().map(|point| point.weight).collect();
        let coefficients = r_style_quadratic_coefficients(&z, &y, &weights)?;
        Some(coefficients[2])
    }

    fn predict_polynomial_with_downgrade(
        &self,
        x0: f64,
        distances: &[Distance],
        mut degree: usize,
    ) -> Result<(f64, f64), LocfitError> {
        loop {
            match self.predict_polynomial_for_degree(x0, distances, degree) {
                Ok(value) => return Ok(value),
                Err(LocfitError::SingularFit)
                    if self.config.allow_degree_downgrade && degree > 0 =>
                {
                    degree -= 1;
                }
                Err(error) => return Err(error),
            }
        }
    }

    fn predict_polynomial_for_degree(
        &self,
        x0: f64,
        distances: &[Distance],
        degree: usize,
    ) -> Result<(f64, f64), LocfitError> {
        let n = self.points.len();
        let min_neighbors = self.minimum_neighbors_for_prediction(degree, n);
        let alpha_neighbors = (self.config.alpha * n as f64).floor() as usize;
        let k = alpha_neighbors.clamp(min_neighbors, n);
        let bandwidth = distances[k - 1].distance;

        if bandwidth == 0.0 {
            if degree == 0 {
                return self.zero_distance_weighted_mean(x0);
            }
            return Err(LocfitError::SingularFit);
        }

        let mut z = Vec::new();
        let mut y = Vec::new();
        let mut weights = Vec::new();

        let mut active_distances: Vec<_> = distances
            .iter()
            .take_while(|distance| distance.distance <= bandwidth)
            .collect();
        if self.uses_input_order_for_local_sums() {
            active_distances.sort_by_key(|distance| distance.original_index);
        }

        for distance in active_distances {
            let point = &self.points[distance.point_index];
            let kernel_weight = kernel::evaluate(self.config.kernel, distance.distance / bandwidth);
            let combined_weight = point.weight * kernel_weight;
            if combined_weight > 0.0 && combined_weight.is_finite() {
                z.push(point.x - x0);
                y.push(point.y);
                weights.push(combined_weight);
            }
        }

        if degree == 2 && self.config.prediction_method == PredictionMethod::LocfitHermiteApprox {
            if let Some(coefficients) = r_style_quadratic_coefficients(&z, &y, &weights) {
                return Ok((coefficients[0], coefficients[1]));
            }
            return Err(LocfitError::SingularFit);
        }

        if weights.len() < degree + 1 {
            return Err(LocfitError::SingularFit);
        }

        match wls::weighted_polynomial_coefficients(&z, &y, &weights, degree) {
            Ok(coefficients) => Ok((coefficients[0], coefficients[1])),
            Err(error) => Err(error),
        }
    }

    fn minimum_neighbors_for_prediction(&self, degree: usize, n: usize) -> usize {
        if self.config.prediction_method == PredictionMethod::LocfitHermiteApprox {
            1
        } else {
            self.config.min_points.max(degree + 1).min(n)
        }
    }

    fn uses_input_order_for_local_sums(&self) -> bool {
        !has_repeated_x(&self.points)
    }

    fn zero_distance_weighted_mean(&self, x0: f64) -> Result<(f64, f64), LocfitError> {
        let mut weight_sum = 0.0;
        let mut weighted_y_sum = 0.0;
        for point in &self.points {
            if point.x == x0 {
                weight_sum += point.weight;
                weighted_y_sum += point.weight * point.y;
            }
        }

        if weight_sum <= 0.0 {
            return Err(LocfitError::SingularFit);
        }
        Ok((weighted_y_sum / weight_sum, 0.0))
    }
}

#[derive(Clone, Copy, Debug)]
struct Distance {
    point_index: usize,
    original_index: usize,
    distance: f64,
}

use super::Knot as EvaluationPoint;

fn locfit_like_evaluation_xs(
    points: &[Point],
    min_x: f64,
    max_x: f64,
    alpha: f64,
) -> Result<Vec<f64>, LocfitError> {
    #[derive(Clone, Copy)]
    struct Cell {
        left_fraction: f64,
        left: f64,
        left_bandwidth: f64,
        right_fraction: f64,
        right: f64,
        right_bandwidth: f64,
        depth: usize,
    }
    let neighbors = ((alpha * points.len() as f64).floor() as usize).clamp(1, points.len());
    let bandwidth = |x: f64| {
        let mut distances: Vec<_> = points.iter().map(|point| (point.x - x).abs()).collect();
        distances.select_nth_unstable_by(neighbors - 1, f64::total_cmp);
        distances[neighbors - 1]
    };
    let mut xs = vec![min_x, max_x];
    let mut cells = vec![Cell {
        left_fraction: 0.0,
        left: min_x,
        left_bandwidth: bandwidth(min_x),
        right_fraction: 1.0,
        right: max_x,
        right_bandwidth: bandwidth(max_x),
        depth: 0,
    }];
    while let Some(cell) = cells.pop() {
        if cell.right - cell.left <= 0.8 * cell.left_bandwidth.min(cell.right_bandwidth) {
            continue;
        }
        let fraction = 0.5 * (cell.left_fraction + cell.right_fraction);
        let midpoint = min_x + fraction * (max_x - min_x);
        if midpoint == cell.left || midpoint == cell.right {
            continue;
        }
        if !midpoint.is_finite() || cell.depth >= 48 || xs.len() >= 1024 {
            return Err(LocfitError::InvalidInput(
                "evaluation grid exceeds the finite subdivision limit".into(),
            ));
        }
        let midpoint_bandwidth = bandwidth(midpoint);
        xs.push(midpoint);
        cells.push(Cell {
            left_fraction: fraction,
            left: midpoint,
            left_bandwidth: midpoint_bandwidth,
            depth: cell.depth + 1,
            ..cell
        });
        cells.push(Cell {
            right_fraction: fraction,
            right: midpoint,
            right_bandwidth: midpoint_bandwidth,
            depth: cell.depth + 1,
            ..cell
        });
    }
    xs.sort_by(f64::total_cmp);
    xs.dedup();
    Ok(xs)
}

fn has_repeated_x(points: &[Point]) -> bool {
    let mut xs: Vec<_> = points.iter().map(|point| point.x).collect();
    xs.sort_by(f64::total_cmp);
    xs.windows(2).any(|window| window[0] == window[1])
}

fn r_style_quadratic_coefficients(z: &[f64], y: &[f64], weights: &[f64]) -> Option<[f64; 3]> {
    if z.len() != y.len() || z.len() != weights.len() {
        return None;
    }

    let mut active_z = Vec::with_capacity(z.len());
    let mut active_y = Vec::with_capacity(y.len());
    let mut active_weights = Vec::with_capacity(weights.len());
    for ((&zi, &yi), &wi) in z.iter().zip(y).zip(weights) {
        if wi > 0.0 && wi.is_finite() && zi.is_finite() && yi.is_finite() {
            active_z.push(zi);
            active_y.push(yi);
            active_weights.push(wi);
        }
    }
    if active_z.is_empty() {
        return None;
    }

    let z = active_z;
    let y = active_y;
    let weights = active_weights;
    let weight_sum = weights.iter().sum::<f64>();
    if weight_sum <= 0.0 {
        return None;
    }

    let mut coefficients = [
        y.iter()
            .zip(&weights)
            .map(|(&yi, &wi)| wi * yi)
            .sum::<f64>()
            / weight_sum,
        0.0,
        0.0,
    ];

    let mut hessian = [[0.0_f64; 3]; 3];
    let mut score = [0.0_f64; 3];

    for ((&zi, &yi), &wi) in z.iter().zip(&y).zip(&weights) {
        let basis = [1.0, zi, 0.5 * zi * zi];
        let residual = yi
            - coefficients[0] * basis[0]
            - coefficients[1] * basis[1]
            - coefficients[2] * basis[2];
        for row in [0, 1, 2] {
            score[row] += wi * basis[row] * residual;
            for col in 0..3 {
                hessian[row][col] += wi * basis[row] * basis[col];
            }
        }
    }

    let delta = solve_scaled_quadratic_system(hessian, score)?;
    for index in 0..3 {
        coefficients[index] += delta[index];
    }
    Some(coefficients)
}

fn solve_scaled_quadratic_system(matrix: [[f64; 3]; 3], rhs: [f64; 3]) -> Option<[f64; 3]> {
    let mut scale = [0.0_f64; 3];
    for index in 0..3 {
        if matrix[index][index] > 0.0 {
            scale[index] = 1.0 / matrix[index][index].sqrt();
        }
    }
    if scale.iter().all(|value| *value == 0.0) {
        return None;
    }

    let mut scaled_matrix = [[0.0_f64; 3]; 3];
    let mut scaled_rhs = [0.0_f64; 3];
    for row in 0..3 {
        scaled_rhs[row] = rhs[row] * scale[row];
        for col in 0..3 {
            scaled_matrix[row][col] = matrix[row][col] * scale[row] * scale[col];
        }
    }

    let (eigenvalues, eigenvectors) = symmetric_eigen_decomposition_3(scaled_matrix);
    let max_eigenvalue = eigenvalues.iter().copied().fold(0.0_f64, f64::max);
    if max_eigenvalue <= 0.0 {
        return Some([0.0; 3]);
    }

    let tolerance = 1e-8 * max_eigenvalue;
    let mut projected_rhs = [0.0_f64; 3];
    for eigen_index in 0..3 {
        projected_rhs[eigen_index] = (0..3)
            .map(|row| eigenvectors[row][eigen_index] * scaled_rhs[row])
            .sum::<f64>();
    }

    for eigen_index in 0..3 {
        let eigenvalue = eigenvalues[eigen_index];
        if eigenvalue > tolerance {
            projected_rhs[eigen_index] /= eigenvalue;
        }
    }

    let mut scaled_solution = [0.0_f64; 3];
    for eigen_index in 0..3 {
        for row in [0, 1, 2] {
            scaled_solution[row] += eigenvectors[row][eigen_index] * projected_rhs[eigen_index];
        }
    }

    let mut solution = [0.0_f64; 3];
    for index in 0..3 {
        solution[index] = scaled_solution[index] * scale[index];
    }
    Some(solution)
}

fn symmetric_eigen_decomposition_3(mut matrix: [[f64; 3]; 3]) -> ([f64; 3], [[f64; 3]; 3]) {
    let mut vectors = [[0.0_f64; 3]; 3];
    for (index, row) in vectors.iter_mut().enumerate() {
        row[index] = 1.0;
    }

    for _ in 0..20 {
        let mut moved = false;
        for (p, q) in [(0, 1), (0, 2), (1, 2)] {
            if matrix[p][q] * matrix[p][q] <= 1e-15 * (matrix[p][p] * matrix[q][q]).abs() {
                continue;
            }

            let mut cosine = (matrix[q][q] - matrix[p][p]) / 2.0;
            let mut sine = -matrix[p][q];
            let radius = (cosine * cosine + sine * sine).sqrt();
            cosine /= radius;
            sine = ((1.0 - cosine) / 2.0).sqrt() * if sine > 0.0 { 1.0 } else { -1.0 };
            cosine = ((1.0 + cosine) / 2.0).sqrt();

            for index in [0, 1, 2] {
                let left = matrix[p][index];
                let right = matrix[q][index];
                matrix[p][index] = left * cosine + right * sine;
                matrix[q][index] = right * cosine - left * sine;
            }
            for row in &mut matrix {
                let left = row[p];
                let right = row[q];
                row[p] = left * cosine + right * sine;
                row[q] = right * cosine - left * sine;
            }
            matrix[p][q] = 0.0;
            matrix[q][p] = 0.0;

            for row in &mut vectors {
                let left = row[p];
                let right = row[q];
                row[p] = left * cosine + right * sine;
                row[q] = right * cosine - left * sine;
            }
            moved = true;
        }

        if !moved {
            break;
        }
    }

    ([matrix[0][0], matrix[1][1], matrix[2][2]], vectors)
}
