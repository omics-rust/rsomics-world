// Adapted from rcompat-locfit 0.1.5, Copyright (c) 2026 Denis Demin.
// MIT license: ../../LICENSES/rcompat-locfit-MIT.txt.
use super::config::Kernel;

pub fn evaluate(kernel: Kernel, u: f64) -> f64 {
    match kernel {
        Kernel::Tricube => tricube(u),
    }
}

pub fn tricube(u: f64) -> f64 {
    let abs_u = u.abs();
    if !abs_u.is_finite() || abs_u >= 1.0 {
        return 0.0;
    }
    let inner = 1.0 - abs_u * abs_u * abs_u;
    inner * inner * inner
}
