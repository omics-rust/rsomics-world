use crate::{
    dataset::{CountMatrix, Design},
    glm,
    normalization::Normalization,
    prior::{self, Prior},
};
use anyhow::{Context, Result, ensure};
use nalgebra::{DMatrix, DVector};
use rayon::prelude::*;
use serde::{Deserialize, Serialize};
use special::Gamma;

const MIN_DISP: f64 = 1e-8;
const MAXIT: usize = 100;
const KAPPA_0: f64 = 1.0;
const DISP_TOL: f64 = 1e-6;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GeneDispersion {
    pub initial: f64,
    pub gene: f64,
    pub gene_iterations: usize,
    pub gene_grid: bool,
    pub fitted: f64,
    pub map: f64,
    pub map_iterations: usize,
    pub map_grid: bool,
    pub outlier: bool,
    pub final_disp: f64,
    pub estimation_mu: Vec<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Dispersions {
    pub base_mean: Vec<f64>,
    pub base_var: Vec<f64>,
    pub genes: Vec<Option<GeneDispersion>>,
    pub trend: Trend,
    pub log_dispersion_variance: f64,
    pub prior_variance: f64,
    pub prior: Prior,
}

pub fn size_factors(m: &CountMatrix) -> Result<Vec<f64>> {
    let positive = (0..m.n_genes)
        .filter(|&g| m.row(g).iter().all(|x| *x > 0.0))
        .map(|g| {
            (
                g,
                m.row(g).iter().map(|x| x.ln()).sum::<f64>() / m.n_samples as f64,
            )
        })
        .collect::<Vec<_>>();
    ensure!(
        !positive.is_empty(),
        "every gene contains a zero; ratio normalization is undefined"
    );
    Ok((0..m.n_samples)
        .map(|j| {
            median(
                &mut positive
                    .iter()
                    .map(|&(g, gm)| m.row(g)[j].ln() - gm)
                    .collect::<Vec<_>>(),
            )
            .exp()
        })
        .collect())
}

pub(crate) fn estimate_with_prior(
    m: &CountMatrix,
    design: &Design,
    normalization: &Normalization,
    fit_type: FitType,
    prior: Option<&Dispersions>,
) -> Result<Dispersions> {
    let n = m.n_samples;
    let p = design.p;
    let logsf = normalization.log_factors(n);
    let xim = normalization.moments_scale(m);
    let max_disp = (n as f64).max(10.0);
    let base_mean = (0..m.n_genes)
        .map(|g| {
            m.row(g)
                .iter()
                .zip(normalization.row(g, n))
                .map(|(y, s)| y / s)
                .sum::<f64>()
                / n as f64
        })
        .collect::<Vec<_>>();
    let base_var = (0..m.n_genes)
        .map(|g| {
            m.row(g)
                .iter()
                .zip(normalization.row(g, n))
                .map(|(y, s)| (y / s - base_mean[g]).powi(2))
                .sum::<f64>()
                / (n - 1) as f64
        })
        .collect::<Vec<_>>();
    let linear_mu = design.cells().len() == p;
    let mut genes = (0..m.n_genes)
        .into_par_iter()
        .map(|g| -> Result<Option<GeneDispersion>> {
            if base_mean[g] == 0.0 {
                return Ok(None);
            }
            let row = m.row(g);
            let sf = normalization.row(g, n);
            let invsf = sf.iter().map(|s| 1.0 / s).collect::<Vec<_>>();
            let norm = row
                .iter()
                .zip(&invsf)
                .map(|(y, s)| y * s)
                .collect::<Vec<_>>();
            let x = DMatrix::from_row_slice(n, p, &design.matrix);
            let beta = glm::least_squares(x.clone(), &DVector::from_row_slice(&norm))?;
            let ols = x * beta;
            let rough = (norm
                .iter()
                .zip(ols.iter())
                .map(|(y, m)| {
                    let mu = m.max(1.0);
                    ((y - mu).powi(2) - mu) / mu.powi(2)
                })
                .sum::<f64>()
                / (n - p) as f64)
                .max(0.0);
            let moments = (base_var[g] - xim * base_mean[g]) / base_mean[g].powi(2);
            let initial = rough.min(moments).clamp(MIN_DISP, max_disp);
            let mu = if linear_mu {
                ols.iter().zip(sf).map(|(m, s)| (m * s).max(0.5)).collect()
            } else {
                glm::fit(row, logsf.row(g), design, initial)
                    .with_context(|| format!("rough GLM {}", m.genes[g]))?
                    .floored_mu
            };
            let (gene, gene_iterations, gene_grid) =
                gene_disp(row, &mu, design, initial, max_disp, p, n);
            ensure!(
                gene.is_finite(),
                "non-finite gene dispersion {}",
                m.genes[g]
            );
            Ok(Some(GeneDispersion {
                initial,
                gene,
                gene_iterations,
                gene_grid,
                fitted: 0.0,
                map: 0.0,
                map_iterations: 0,
                map_grid: false,
                outlier: false,
                final_disp: 0.0,
                estimation_mu: mu,
            }))
        })
        .collect::<Result<Vec<_>>>()?;
    let (trend, log_dispersion_variance, prior_variance, prior_method) = if let Some(prior) = prior
    {
        (
            prior.trend.clone(),
            prior.log_dispersion_variance,
            prior.prior_variance,
            prior.prior.clone(),
        )
    } else {
        let selected = genes
            .iter()
            .enumerate()
            .filter_map(|(g, d)| {
                d.as_ref()
                    .filter(|d| d.gene > 100.0 * MIN_DISP)
                    .map(|d| (base_mean[g], d.gene))
            })
            .collect::<Vec<_>>();
        ensure!(
            !selected.is_empty(),
            "no gene dispersions above 100 times the noise floor for trend fitting"
        );
        let trend = match fit_type {
            FitType::Parametric => match parametric_dispersion_fit(
                &selected.iter().map(|x| x.0).collect::<Vec<_>>(),
                &selected.iter().map(|x| x.1).collect::<Vec<_>>(),
            ) {
                Ok(trend) => trend,
                Err(reason) => Trend::Local {
                    curve: crate::local::Curve::fit(&selected)?,
                    fallback_reason: Some(reason),
                },
            },
            FitType::Local => Trend::Local {
                curve: crate::local::Curve::fit(&selected)?,
                fallback_reason: None,
            },
            FitType::Mean => {
                let mut values = genes
                    .iter()
                    .flatten()
                    .map(|d| d.gene)
                    .filter(|d| *d > 10.0 * MIN_DISP)
                    .collect::<Vec<_>>();
                values.sort_by(f64::total_cmp);
                let cut = (0.001 * values.len() as f64).floor() as usize;
                Trend::Mean {
                    alpha: values[cut..values.len() - cut].iter().sum::<f64>()
                        / (values.len() - 2 * cut) as f64,
                }
            }
        };
        ensure!(
            base_mean.iter().filter(|m| **m > 0.0).all(|m| {
                let value = trend.value(*m);
                value.is_finite() && value > 0.0
            }),
            "non-finite or non-positive fitted dispersion trend"
        );
        let residuals = genes
            .iter()
            .enumerate()
            .filter_map(|(g, d)| {
                d.as_ref()
                    .filter(|d| d.gene >= 100.0 * MIN_DISP)
                    .map(|d| d.gene.ln() - trend.value(base_mean[g]).ln())
            })
            .collect::<Vec<_>>();
        let log_dispersion_variance = mad(&residuals).powi(2);
        let (prior_variance, prior_method) = if n - p <= 3 {
            prior::estimate(&residuals, n - p)?
        } else {
            let sampling_variance = trigamma((n - p) as f64 / 2.0);
            (
                (log_dispersion_variance - sampling_variance).max(0.25),
                Prior::Analytic {
                    residual_df: n - p,
                    sampling_variance,
                },
            )
        };
        (trend, log_dispersion_variance, prior_variance, prior_method)
    };
    genes
        .par_iter_mut()
        .enumerate()
        .try_for_each(|(g, d)| -> Result<()> {
            if let Some(d) = d {
                d.fitted = trend.value(base_mean[g]);
                ensure!(
                    d.fitted.is_finite() && d.fitted > 0.0,
                    "non-finite or non-positive trend dispersion {}",
                    m.genes[g]
                );
                let init = if d.gene > 0.1 * d.fitted {
                    d.gene
                } else {
                    d.fitted
                };
                let (map, iterations, grid) = map_disp(
                    m.row(g),
                    &d.estimation_mu,
                    design,
                    init,
                    d.fitted.ln(),
                    prior_variance,
                    max_disp,
                    p,
                    n,
                );
                ensure!(map.is_finite(), "non-finite MAP dispersion {}", m.genes[g]);
                d.map = map.clamp(MIN_DISP, max_disp);
                d.map_iterations = iterations;
                d.map_grid = grid;
                d.outlier = d.gene.ln() > d.fitted.ln() + 2.0 * log_dispersion_variance.sqrt();
                d.final_disp = if d.outlier { d.gene } else { d.map };
            }
            Ok(())
        })?;
    Ok(Dispersions {
        base_mean,
        base_var,
        genes,
        trend,
        log_dispersion_variance,
        prior_variance,
        prior: prior_method,
    })
}

#[allow(clippy::too_many_arguments)]
fn gene_disp(
    row: &[f64],
    mu: &[f64],
    design: &Design,
    alpha_init: f64,
    max_disp: f64,
    p: usize,
    n: usize,
) -> (f64, usize, bool) {
    let fit = fit_disp(
        row,
        mu,
        design,
        alpha_init.ln(),
        0.0,
        1.0,
        false,
        max_disp,
        p,
        n,
    );
    if !fit.alpha.is_finite() {
        return (f64::NAN, fit.iter, false);
    }
    let mut disp = fit.alpha;
    if fit.last_lp < fit.initial_lp + fit.initial_lp.abs() / 1e6 {
        disp = alpha_init;
    }
    let converged = fit.iter < MAXIT && fit.iter != 1;
    let grid = !converged && disp > MIN_DISP * 10.0;
    if grid {
        disp = fit_disp_grid(row, mu, design, 0.0, 1.0, false, max_disp, n);
    }
    (disp.clamp(MIN_DISP, max_disp), fit.iter, grid)
}

#[allow(clippy::too_many_arguments)]
fn map_disp(
    row: &[f64],
    mu: &[f64],
    design: &Design,
    init: f64,
    prior_mean: f64,
    sigmasq: f64,
    max_disp: f64,
    p: usize,
    n: usize,
) -> (f64, usize, bool) {
    let fit = fit_disp(
        row,
        mu,
        design,
        init.ln(),
        prior_mean,
        sigmasq,
        true,
        max_disp,
        p,
        n,
    );
    let value = if fit.iter < MAXIT {
        fit.alpha
    } else {
        fit_disp_grid(row, mu, design, prior_mean, sigmasq, true, max_disp, n)
    };
    (value, fit.iter, fit.iter >= MAXIT)
}

struct DispFit {
    alpha: f64,
    iter: usize,
    initial_lp: f64,
    last_lp: f64,
}

#[allow(clippy::too_many_arguments)]
fn log_posterior(
    y: &[f64],
    mu: &[f64],
    design: &Design,
    log_alpha: f64,
    prior_mean: f64,
    sigmasq: f64,
    use_prior: bool,
    p: usize,
    _n: usize,
) -> f64 {
    let alpha = log_alpha.exp();
    let a_inv = 1.0 / alpha;
    let lg_a_inv = Gamma::ln_gamma(a_inv).0;
    let mut xwx = DMatrix::<f64>::zeros(p, p);
    let mut ll = 0.0;
    for (j, ((&yi, &mui), _)) in y.iter().zip(mu).zip(0..mu.len()).enumerate() {
        let w = 1.0 / (1.0 / mui + alpha);
        let xr = design.rowvec(j);
        for a in 0..p {
            for b in 0..p {
                xwx[(a, b)] += w * xr[a] * xr[b];
            }
        }
        ll += Gamma::ln_gamma(yi + a_inv).0
            - lg_a_inv
            - yi * (mui + a_inv).ln()
            - a_inv * (1.0 + mui * alpha).ln();
    }
    let det = xwx.determinant();
    let mut lp = ll - 0.5 * det.ln();
    if use_prior {
        lp -= 0.5 * (log_alpha - prior_mean).powi(2) / sigmasq;
    }
    lp
}

#[allow(clippy::too_many_arguments)]
fn dlog_posterior(
    y: &[f64],
    mu: &[f64],
    design: &Design,
    log_alpha: f64,
    prior_mean: f64,
    sigmasq: f64,
    use_prior: bool,
    p: usize,
) -> f64 {
    let alpha = log_alpha.exp();
    let a_inv = 1.0 / alpha;
    let a_inv2 = a_inv * a_inv;
    let dg_a_inv = a_inv.digamma();
    let mut xwx = DMatrix::<f64>::zeros(p, p);
    let mut dxwx = DMatrix::<f64>::zeros(p, p);
    let mut ll = 0.0;
    for (j, (&yi, &mui)) in y.iter().zip(mu).enumerate() {
        let denom = 1.0 / mui + alpha;
        let w = 1.0 / denom;
        let dw = -1.0 / (denom * denom);
        let xr = design.rowvec(j);
        for a in 0..p {
            for b in 0..p {
                let xab = xr[a] * xr[b];
                xwx[(a, b)] += w * xab;
                dxwx[(a, b)] += dw * xab;
            }
        }
        ll += dg_a_inv + (1.0 + mui * alpha).ln()
            - mui * alpha / (1.0 + mui * alpha)
            - (yi + a_inv).digamma()
            + yi / (mui + a_inv);
    }
    let Some(inv) = xwx.try_inverse() else {
        return f64::NAN;
    };
    let mut tr = 0.0;
    for a in 0..p {
        for b in 0..p {
            tr += inv[(a, b)] * dxwx[(b, a)];
        }
    }
    let ll_part = a_inv2 * ll;
    let cr_term = -0.5 * tr;
    let mut grad = (ll_part + cr_term) * alpha;
    if use_prior {
        grad -= (log_alpha - prior_mean) / sigmasq;
    }
    grad
}

#[allow(clippy::too_many_arguments)]
fn fit_disp(
    y: &[f64],
    mu: &[f64],
    design: &Design,
    log_alpha_init: f64,
    prior_mean: f64,
    sigmasq: f64,
    use_prior: bool,
    max_disp: f64,
    p: usize,
    n: usize,
) -> DispFit {
    let min_log_alpha = (MIN_DISP / 10.0).ln();
    let epsilon = 1e-4;
    let mut a = log_alpha_init;
    let mut lp = log_posterior(y, mu, design, a, prior_mean, sigmasq, use_prior, p, n);
    let mut dlp = dlog_posterior(y, mu, design, a, prior_mean, sigmasq, use_prior, p);
    let initial_lp = lp;
    if !lp.is_finite() || !dlp.is_finite() {
        return DispFit {
            alpha: f64::NAN,
            iter: 0,
            initial_lp: lp,
            last_lp: lp,
        };
    }
    let mut kappa = KAPPA_0;
    let mut iter = 0usize;
    let mut iter_accept = 0usize;

    for _ in 0..MAXIT {
        iter += 1;
        if a + kappa * dlp < -30.0 {
            kappa = (-30.0 - a) / dlp;
        }
        if a + kappa * dlp > 10.0 {
            kappa = (10.0 - a) / dlp;
        }
        let theta_kappa = -log_posterior(
            y,
            mu,
            design,
            a + kappa * dlp,
            prior_mean,
            sigmasq,
            use_prior,
            p,
            n,
        );
        let theta_hat_kappa = -lp - kappa * epsilon * dlp * dlp;
        if theta_kappa <= theta_hat_kappa {
            iter_accept += 1;
            a += kappa * dlp;
            let lpnew = log_posterior(y, mu, design, a, prior_mean, sigmasq, use_prior, p, n);
            let change = lpnew - lp;
            if change < DISP_TOL {
                lp = lpnew;
                break;
            }
            if a < min_log_alpha {
                break;
            }
            lp = lpnew;
            dlp = dlog_posterior(y, mu, design, a, prior_mean, sigmasq, use_prior, p);
            kappa = (kappa * 1.1).min(KAPPA_0);
            if iter_accept.is_multiple_of(5) {
                kappa /= 2.0;
            }
        } else {
            kappa /= 2.0;
        }
    }

    DispFit {
        alpha: a.exp().min(max_disp),
        iter,
        initial_lp,
        last_lp: lp,
    }
}

#[allow(clippy::too_many_arguments)]
fn fit_disp_grid(
    y: &[f64],
    mu: &[f64],
    design: &Design,
    prior_mean: f64,
    sigmasq: f64,
    use_prior: bool,
    max_disp: f64,
    n: usize,
) -> f64 {
    const N: usize = 20;
    let p = design.p;
    let lo = (1e-8f64).ln();
    let hi = max_disp.ln();
    let delta = (hi - lo) / (N as f64 - 1.0);
    let argmax = |center_lo: f64, step: f64| -> f64 {
        let mut best_lp = f64::NEG_INFINITY;
        let mut best_a = center_lo;
        for t in 0..N {
            let a = center_lo + step * t as f64;
            let lp = log_posterior(y, mu, design, a, prior_mean, sigmasq, use_prior, p, n);
            if lp > best_lp {
                best_lp = lp;
                best_a = a;
            }
        }
        best_a
    };
    let a_hat = argmax(lo, delta);
    let fine_step = 2.0 * delta / (N as f64 - 1.0);
    argmax(a_hat - delta, fine_step).exp()
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize, clap::ValueEnum)]
#[serde(rename_all = "snake_case")]
pub enum FitType {
    #[default]
    Parametric,
    Local,
    Mean,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum Trend {
    Parametric {
        a0: f64,
        a1: f64,
    },
    Mean {
        alpha: f64,
    },
    Local {
        curve: crate::local::Curve,
        fallback_reason: Option<String>,
    },
}

impl Trend {
    pub fn value(&self, mean: f64) -> f64 {
        match self {
            Self::Parametric { a0, a1 } => a0 + a1 / mean,
            Self::Mean { alpha } => *alpha,
            Self::Local { curve, .. } => curve.log_value(mean.ln()).exp(),
        }
    }

    pub(crate) fn validate(&self, requested: FitType) -> Result<()> {
        let valid = match (self, requested) {
            (Self::Parametric { a0, a1 }, FitType::Parametric) => {
                a0.is_finite() && *a0 > 0.0 && a1.is_finite() && *a1 > 0.0
            }
            (Self::Mean { alpha }, FitType::Mean) => alpha.is_finite() && *alpha > 0.0,
            (
                Self::Local {
                    curve,
                    fallback_reason,
                },
                requested,
            ) => {
                curve.validate()?;
                match requested {
                    FitType::Local => fallback_reason.is_none(),
                    FitType::Parametric => fallback_reason
                        .as_ref()
                        .is_some_and(|reason| !reason.is_empty()),
                    FitType::Mean => false,
                }
            }
            _ => false,
        };
        ensure!(
            valid,
            "dispersion trend differs from requested fit policy or is invalid"
        );
        Ok(())
    }
}

fn parametric_dispersion_fit(means: &[f64], disps: &[f64]) -> Result<Trend, String> {
    let mut coefs = [0.1f64, 1.0];
    for _ in 0..=10 {
        let good: Vec<usize> = (0..means.len())
            .filter(|&i| {
                let r = disps[i] / (coefs[0] + coefs[1] / means[i]);
                r > 1e-4 && r < 15.0
            })
            .collect();
        if good.len() < 2 {
            return Err("dispersion trend window collapsed".into());
        }
        let new = gamma_glm_identity(means, disps, &good, coefs)?;
        if new[0] <= 0.0 || new[1] <= 0.0 {
            return Err("dispersion trend fit produced a non-positive coefficient".into());
        }
        let d0 = (new[0] / coefs[0]).ln();
        let d1 = (new[1] / coefs[1]).ln();
        let converged = d0 * d0 + d1 * d1 < 1e-6;
        coefs = new;
        if converged {
            return Ok(Trend::Parametric {
                a0: coefs[0],
                a1: coefs[1],
            });
        }
    }
    Err("dispersion trend did not converge".into())
}

fn gamma_glm_identity(
    means: &[f64],
    disps: &[f64],
    good: &[usize],
    start: [f64; 2],
) -> Result<[f64; 2], String> {
    let mut coefs = start;
    let deviance = |b: [f64; 2]| {
        good.iter()
            .map(|&i| {
                let mu = b[0] + b[1] / means[i];
                let ratio = disps[i] / mu;
                2.0 * (ratio - 1.0 - ratio.ln())
            })
            .sum::<f64>()
    };
    let mut old_deviance = deviance(start);
    for _ in 0..25 {
        let (mut s00, mut s01, mut s11, mut t0, mut t1) = (0.0, 0.0, 0.0, 0.0, 0.0);
        for &i in good {
            let x1 = 1.0 / means[i];
            let mu = coefs[0] + coefs[1] * x1;
            if mu <= 0.0 {
                return Err("dispersion trend fit produced a non-positive fitted value".into());
            }
            let w = 1.0 / (mu * mu);
            let z = disps[i];
            s00 += w;
            s01 += w * x1;
            s11 += w * x1 * x1;
            t0 += w * z;
            t1 += w * z * x1;
        }
        let det = s00 * s11 - s01 * s01;
        if det.abs() < f64::MIN_POSITIVE {
            return Err("dispersion trend fit hit a singular design".into());
        }
        let b0 = (t0 * s11 - t1 * s01) / det;
        let b1 = (s00 * t1 - s01 * t0) / det;
        coefs = [b0, b1];
        let new_deviance = deviance(coefs);
        if (new_deviance - old_deviance).abs() / (0.1 + new_deviance.abs()) < 1e-8 {
            return Ok(coefs);
        }
        old_deviance = new_deviance;
    }
    Err("Gamma identity-link trend IRLS did not converge".into())
}

fn median(xs: &mut [f64]) -> f64 {
    let n = xs.len();
    debug_assert!(n > 0);
    let mid = n / 2;
    if n % 2 == 1 {
        *xs.select_nth_unstable_by(mid, |a, b| a.total_cmp(b)).1
    } else {
        let (_, hi, _) = xs.select_nth_unstable_by(mid, |a, b| a.total_cmp(b));
        let upper = *hi;
        let lower = xs[..mid].iter().copied().fold(f64::NEG_INFINITY, f64::max);
        (lower + upper) / 2.0
    }
}

fn mad(xs: &[f64]) -> f64 {
    let mut v = xs.to_vec();
    let m = median(&mut v);
    let mut dev: Vec<f64> = xs.iter().map(|x| (x - m).abs()).collect();
    1.4826 * median(&mut dev)
}

fn trigamma(mut x: f64) -> f64 {
    let mut result = 0.0;
    while x < 6.0 {
        result += 1.0 / (x * x);
        x += 1.0;
    }
    let inv = 1.0 / x;
    let inv2 = inv * inv;
    result
        + inv
        + 0.5 * inv2
        + inv2 * inv * (1.0 / 6.0 - inv2 * (1.0 / 30.0 - inv2 * (1.0 / 42.0 - inv2 / 30.0)))
}
