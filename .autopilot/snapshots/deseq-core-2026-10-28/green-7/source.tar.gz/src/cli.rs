use crate::{artifact, dataset, fit, results};
use clap::{Args, Parser, Subcommand, ValueEnum};
use rsomics_common::{OutputArgs, RsomicsError, ThreadArgs, ToolMeta};
use std::num::NonZeroUsize;
use std::path::PathBuf;

#[derive(Debug, Parser)]
#[command(
    name = "rsomics-deseq",
    version,
    about = "Private DESeq2 fitted-workflow checkpoint",
    arg_required_else_help = true
)]
struct Cli {
    #[command(flatten)]
    output: OutputArgs,
    #[command(flatten)]
    threads: ThreadArgs,
    #[command(subcommand)]
    command: Command,
}

#[derive(Debug, Subcommand)]
enum Command {
    /// Fit integer counts using an identity-joined named numeric design
    Run(Run),
    /// Derive a named contrast from a saved fit without refitting
    Results(Derive),
    /// Export normalized counts or design-aware VST using a saved fit
    Transform(Transform),
    /// Evaluate the saved dispersion trend at positive means without refitting
    Inspect(Inspect),
}

#[derive(Debug, Args)]
struct Contrast {
    /// One NAME=WEIGHT per coefficient; explicitly include zero weights
    #[arg(long = "contrast", required = true)]
    terms: Vec<String>,
    #[arg(long, default_value_t = 0.1)]
    alpha: f64,
}

#[derive(Debug, Args)]
struct Run {
    #[arg(long)]
    counts: PathBuf,
    #[arg(long)]
    samples: PathBuf,
    #[arg(long, required_unless_present = "formula", conflicts_with = "formula")]
    design: Option<PathBuf>,
    /// Typed R-style formula; contrasts use raw model.matrix column names
    #[arg(long, required_unless_present = "design", conflicts_with = "design")]
    formula: Option<String>,
    #[arg(long, requires = "formula")]
    numeric: Vec<String>,
    /// NAME=LEVEL1,LEVEL2,..., with the reference level first
    #[arg(long, requires = "formula")]
    factor: Vec<String>,
    #[arg(long)]
    size_factors: Option<PathBuf>,
    #[arg(long)]
    normalization_factors: Option<PathBuf>,
    /// Disable outlier replacement (minReplicatesForReplace=Inf); retain Cook's masking
    #[arg(long)]
    no_replace_outliers: bool,
    /// Requested dispersion trend; an unsuccessful parametric fit never substitutes mean
    #[arg(long, value_enum, default_value_t = crate::dispersion::FitType::Parametric)]
    fit_type: crate::dispersion::FitType,
    #[arg(long)]
    bundle: PathBuf,
    #[command(flatten)]
    contrast: Contrast,
}

#[derive(Debug, Args)]
struct Derive {
    #[arg(long)]
    bundle: PathBuf,
    #[arg(long)]
    output: PathBuf,
    #[command(flatten)]
    contrast: Contrast,
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum Kind {
    Normalized,
    Vst,
}

#[derive(Debug, Args)]
struct Transform {
    #[arg(long)]
    bundle: PathBuf,
    #[arg(long)]
    output: PathBuf,
    #[arg(long, value_enum)]
    kind: Kind,
}

#[derive(Debug, Args)]
struct Inspect {
    #[arg(long)]
    bundle: PathBuf,
    /// TSV with query and mean columns, preserving query identities and order
    #[arg(long)]
    trend_queries: PathBuf,
    #[arg(long)]
    output: PathBuf,
}

pub fn run() -> std::process::ExitCode {
    let cli = rsomics_help::parse::<Cli>();
    rsomics_common::run(
        &cli.output,
        ToolMeta {
            name: "rsomics-deseq",
            version: env!("CARGO_PKG_VERSION"),
        },
        || execute(cli.command, cli.threads.requested()).map_err(process_error),
    )
}

pub(crate) fn process_error(error: anyhow::Error) -> RsomicsError {
    let error = match error.downcast::<RsomicsError>() {
        Ok(error) => return error,
        Err(error) => error,
    };
    let error = match error.downcast::<serde_json::Error>() {
        Ok(error) => return json_error(error),
        Err(error) => error,
    };
    if let Some(io) = error.downcast_ref::<std::io::Error>() {
        return RsomicsError::Io(std::io::Error::new(io.kind(), format!("{error:#}")));
    }
    if let Some(csv) = error.downcast_ref::<csv::Error>()
        && let csv::ErrorKind::Io(io) = csv.kind()
    {
        return RsomicsError::Io(std::io::Error::new(io.kind(), format!("{error:#}")));
    }
    RsomicsError::InvalidInput(format!("{error:#}"))
}

pub(crate) fn json_error(error: serde_json::Error) -> RsomicsError {
    if error.is_io() {
        RsomicsError::Io(error.into())
    } else {
        RsomicsError::InvalidInput(error.to_string())
    }
}

fn execute(command: Command, threads: Option<NonZeroUsize>) -> anyhow::Result<serde_json::Value> {
    match command {
        Command::Run(args) => {
            let workers = match threads {
                Some(threads) => threads.get(),
                None => std::thread::available_parallelism()?.get(),
            };
            rsomics_common::reject_output_alias(
                &args.bundle,
                [
                    Some(args.counts.as_path()),
                    Some(args.samples.as_path()),
                    args.design.as_deref(),
                    args.size_factors.as_deref(),
                    args.normalization_factors.as_deref(),
                ]
                .into_iter()
                .flatten(),
            )?;
            let input = if let Some(path) = args.design.as_deref() {
                dataset::DesignInput::Matrix(path)
            } else {
                dataset::DesignInput::Formula {
                    formula: args
                        .formula
                        .as_deref()
                        .ok_or_else(|| anyhow::anyhow!("a design matrix or formula is required"))?,
                    numeric: &args.numeric,
                    factors: &args.factor,
                }
            };
            let data = dataset::Dataset::read_inputs(
                &args.counts,
                &args.samples,
                input,
                args.size_factors.as_deref(),
                args.normalization_factors.as_deref(),
            )?;
            let contrast = dataset::contrast(&data.design, &args.contrast.terms)?;
            let mut fitted = fit::run_with_options(
                data,
                workers,
                fit::FitOptions {
                    no_replace_outliers: args.no_replace_outliers,
                    fit_type: args.fit_type,
                },
            )?;
            fitted.initial_results =
                Some(results::derive(&fitted, &contrast, args.contrast.alpha)?);
            artifact::save(&args.bundle, &fitted)?;
            Ok(
                serde_json::json!({"bundle":args.bundle,"genes":fitted.genes.len(),"workers":fitted.workers}),
            )
        }
        Command::Results(args) => {
            rsomics_common::reject_output_alias(&args.output, [args.bundle.as_path()])?;
            let fit = artifact::load(&args.bundle)?;
            let contrast = dataset::contrast(&fit.dataset.design, &args.contrast.terms)?;
            let result = results::derive(&fit, &contrast, args.contrast.alpha)?;
            artifact::results(&args.output, &fit, &result)?;
            Ok(
                serde_json::json!({"output":args.output,"refit":false,"filter_threshold":result.filter.threshold}),
            )
        }
        Command::Transform(args) => {
            rsomics_common::reject_output_alias(&args.output, [args.bundle.as_path()])?;
            let fit = artifact::load(&args.bundle)?;
            artifact::transform(&args.output, &fit, matches!(args.kind, Kind::Vst))?;
            Ok(serde_json::json!({"output":args.output,"refit":false}))
        }
        Command::Inspect(args) => {
            rsomics_common::reject_output_alias(
                &args.output,
                [args.bundle.as_path(), args.trend_queries.as_path()],
            )?;
            let fit = artifact::load(&args.bundle)?;
            artifact::inspect(&args.output, &fit, &args.trend_queries)?;
            Ok(serde_json::json!({"output":args.output,"refit":false}))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use clap::CommandFactory;
    #[test]
    fn help_tree_is_valid() {
        Cli::command().debug_assert();
    }

    #[test]
    fn shared_thread_selection_is_global_and_nonzero() {
        for command in [
            vec![
                "run",
                "--counts",
                "counts.tsv",
                "--samples",
                "samples.tsv",
                "--formula",
                "~1",
                "--bundle",
                "fit.json",
                "--contrast",
                "(Intercept)=1",
            ],
            vec![
                "results",
                "--bundle",
                "fit.json",
                "--output",
                "results.tsv",
                "--contrast",
                "(Intercept)=1",
            ],
            vec![
                "transform",
                "--bundle",
                "fit.json",
                "--output",
                "normalized.tsv",
                "--kind",
                "normalized",
            ],
        ] {
            let default = Cli::try_parse_from(
                std::iter::once("rsomics-deseq").chain(command.iter().copied()),
            )
            .unwrap();
            assert_eq!(default.threads.requested(), None);
            for flag in ["-t", "--threads"] {
                for before in [true, false] {
                    let mut args = vec!["rsomics-deseq"];
                    if before {
                        args.extend([flag, "2"]);
                    }
                    args.extend(command.iter().copied());
                    if !before {
                        args.extend([flag, "2"]);
                    }
                    let cli = Cli::try_parse_from(args).unwrap();
                    assert_eq!(cli.threads.requested().map(NonZeroUsize::get), Some(2));
                }
            }
            for selection in [["--threads", "0"], ["--workers", "2"]] {
                assert!(
                    Cli::try_parse_from(
                        std::iter::once("rsomics-deseq")
                            .chain(command.iter().copied())
                            .chain(selection)
                    )
                    .is_err()
                );
            }
        }
    }

    #[test]
    fn json_reader_writer_errors_keep_io_class() {
        struct FailingIo;
        impl std::io::Read for FailingIo {
            fn read(&mut self, _: &mut [u8]) -> std::io::Result<usize> {
                Err(std::io::Error::new(
                    std::io::ErrorKind::PermissionDenied,
                    "reader failure",
                ))
            }
        }
        impl std::io::Write for FailingIo {
            fn write(&mut self, _: &[u8]) -> std::io::Result<usize> {
                Err(std::io::Error::new(
                    std::io::ErrorKind::BrokenPipe,
                    "writer failure",
                ))
            }
            fn flush(&mut self) -> std::io::Result<()> {
                Ok(())
            }
        }
        let read = serde_json::from_reader::<_, serde_json::Value>(FailingIo).unwrap_err();
        assert!(
            matches!(process_error(read.into()), RsomicsError::Io(e) if e.kind() == std::io::ErrorKind::PermissionDenied && e.to_string().contains("reader failure"))
        );
        for write in [
            serde_json::to_writer(FailingIo, &42),
            serde_json::to_writer_pretty(FailingIo, &42),
        ] {
            assert!(
                matches!(json_error(write.unwrap_err()), RsomicsError::Io(e) if e.kind() == std::io::ErrorKind::BrokenPipe && e.to_string().contains("writer failure"))
            );
        }
        let malformed = serde_json::from_slice::<serde_json::Value>(b"{").unwrap_err();
        assert!(matches!(
            process_error(malformed.into()),
            RsomicsError::InvalidInput(_)
        ));
    }
}
