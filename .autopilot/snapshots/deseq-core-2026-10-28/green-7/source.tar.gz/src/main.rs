fn main() -> std::process::ExitCode {
    rsomics_deseq::run_cli()
}
