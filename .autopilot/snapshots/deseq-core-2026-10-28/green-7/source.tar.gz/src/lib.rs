#![forbid(unsafe_code)]

mod artifact;
mod cli;
mod dataset;
mod design;
mod dispersion;
mod fit;
mod glm;
mod local;
mod lowess;
mod normalization;
mod prior;
mod replacement;
mod results;
mod vst;

/// Runs the executable's CLI and returns its process exit status.
///
/// Analysis models and statistical kernels are internal. Use the executable's
/// commands and versioned output formats as the supported interface.
pub fn run_cli() -> std::process::ExitCode {
    cli::run()
}

#[cfg(test)]
mod tests;
