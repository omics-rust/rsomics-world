# Private local regression adaptation

The fitting core in `src/local/` is adapted from rcompat-locfit 0.1.5,
copyright 2026 Denis Demin, under the accompanying complete MIT license.
Archive SHA256: `57fc3c85ee6ee951198c4e105220025963815d8d981af873625044877b458572`.
Published VCS commit: `d1fe58bba1cfd8aded7fdd91ab0350b8f65bce5f`.

Only the fitting core is reused. The generic DESeq wrapper, its constant
fallback and its query-time fitting interfaces are not included. Product
validation rejects invalid observations instead of silently removing them.
The initial fit yields an inference-only ordered Hermite curve and exact
optional boundary curvature. Neither training observations nor solver
configuration is present in that serialized curve, and reload does not fit.

This adaptation uses the candidate's general large-population arithmetic:
input-order local sums for distinct predictors, ordinary quadratic sums and
the original scaled solve. Point-count-specific rules for 5, 7, 10, 30 and
100..999 observations are removed. This is not an assertion of small-sample
or universal R locfit parity. The four qualified complete source workflows
are the numerical consumer gate, not the candidate author's parity claims.

The local VST FMM spline in `src/vst.rs` is independently implemented from
the documented endpoint cubic conditions and the interior second-derivative
continuity equations. No GPL C implementation or fixed source-answer table
was transplanted. Source behavior authority is DESeq2 1.52.0 with locfit
1.5-9.12; the saved product curve is not the R model's binary layout.
