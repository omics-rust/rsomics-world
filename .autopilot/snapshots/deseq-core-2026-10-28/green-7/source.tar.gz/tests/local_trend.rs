use std::process::Command;

#[test]
fn local_and_fallback_preserve_curve_but_keep_sf_nf_vst_context_separate() {
    let dir = tempfile::tempdir().unwrap();
    let counts = dir.path().join("counts.tsv");
    let samples = dir.path().join("samples.tsv");
    let nf = dir.path().join("nf.tsv");
    let sf = dir.path().join("sf.tsv");
    let data = include_str!("fixtures/local-counts.tsv");
    std::fs::write(&counts, data).unwrap();
    let names = data
        .lines()
        .next()
        .unwrap()
        .split('\t')
        .skip(1)
        .collect::<Vec<_>>();
    let mut metadata = "sample\tcondition\n".to_owned();
    let mut size = "sample\tfactor\n".to_owned();
    for (j, name) in names.iter().enumerate() {
        metadata.push_str(&format!(
            "{name}\t{}\n",
            if j < 6 { "control" } else { "treated" }
        ));
        size.push_str(&format!("{name}\t2\n"));
    }
    std::fs::write(&samples, metadata).unwrap();
    std::fs::write(&sf, size).unwrap();
    let factors = data
        .lines()
        .map(|line| {
            let mut fields = line.split('\t');
            let gene = fields.next().unwrap();
            if gene == "gene" {
                line.to_owned()
            } else {
                format!("{gene}\t{}", vec!["1"; names.len()].join("\t"))
            }
        })
        .collect::<Vec<_>>()
        .join("\n");
    std::fs::write(&nf, factors).unwrap();
    let mut fits = Vec::new();
    for mode in ["local-nf", "local-sf-nf", "fallback"] {
        let bundle = dir.path().join(format!("{mode}.json"));
        let mut command = Command::new(env!("CARGO_BIN_EXE_rsomics-deseq"));
        command
            .arg("run")
            .arg("--counts")
            .arg(&counts)
            .arg("--samples")
            .arg(&samples)
            .args([
                "--formula",
                "~condition",
                "--factor",
                "condition=control,treated",
                "--threads",
                "1",
                "--bundle",
            ])
            .arg(&bundle)
            .args(["--contrast=(Intercept)=0", "--contrast=conditiontreated=1"]);
        if mode != "fallback" {
            command
                .args(["--fit-type", "local", "--normalization-factors"])
                .arg(&nf);
        }
        if mode == "local-sf-nf" {
            command.arg("--size-factors").arg(&sf);
        }
        let output = command.output().unwrap();
        assert!(
            output.status.success(),
            "{}",
            String::from_utf8_lossy(&output.stderr)
        );
        let bytes = std::fs::read(&bundle).unwrap();
        let state: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(state["dispersions"]["trend"]["kind"], "local");
        assert_eq!(
            state["dispersions"]["trend"]["fallback_reason"].is_string(),
            mode == "fallback"
        );
        let exported = dir.path().join(format!("{mode}.tsv"));
        let reload = Command::new(env!("CARGO_BIN_EXE_rsomics-deseq"))
            .args(["transform", "--bundle"])
            .arg(&bundle)
            .arg("--output")
            .arg(&exported)
            .args(["--kind", "vst"])
            .output()
            .unwrap();
        assert!(
            reload.status.success(),
            "{}",
            String::from_utf8_lossy(&reload.stderr)
        );
        assert_eq!(bytes, std::fs::read(&bundle).unwrap());
        let first_vst = {
            let mut reader = csv::ReaderBuilder::new()
                .delimiter(b'\t')
                .from_path(&exported)
                .unwrap();
            reader.records().next().unwrap().unwrap()[1]
                .parse::<f64>()
                .unwrap()
        };
        assert!(first_vst.is_finite());
        let queries = dir.path().join(format!("{mode}-queries.tsv"));
        let inspection = dir.path().join(format!("{mode}-trend.tsv"));
        std::fs::write(
            &queries,
            "query\tmean\n spaced identity \t 2.0 \npositive\t100000\n",
        )
        .unwrap();
        let inspect = || {
            Command::new(env!("CARGO_BIN_EXE_rsomics-deseq"))
                .args(["inspect", "--bundle"])
                .arg(&bundle)
                .arg("--trend-queries")
                .arg(&queries)
                .arg("--output")
                .arg(&inspection)
                .output()
                .unwrap()
        };
        let output = inspect();
        assert!(
            output.status.success(),
            "{}",
            String::from_utf8_lossy(&output.stderr)
        );
        let original = std::fs::read(&inspection).unwrap();
        assert!(String::from_utf8_lossy(&original).contains("\n spaced identity \t2\t"));
        std::fs::write(&queries, "query\tmean\ninvalid\t0\n").unwrap();
        assert!(!inspect().status.success());
        assert_eq!(original, std::fs::read(&inspection).unwrap());
        fits.push((state, std::fs::read(exported).unwrap(), first_vst));
    }
    assert_eq!(fits[0].0["dispersions"], fits[1].0["dispersions"]);
    assert_ne!(fits[0].1, fits[1].1);
    assert_ne!(fits[0].2, fits[1].2);
}
