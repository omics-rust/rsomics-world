use std::process::Command;

#[test]
fn mean_low_df_fit_reloads_contrasts_and_original_count_vst() {
    let dir = tempfile::tempdir().unwrap();
    let counts = dir.path().join("counts.tsv");
    let samples = dir.path().join("samples.tsv");
    let bundle = dir.path().join("fit.json");
    let mut table = "gene\tA1\tA2\tB1\tB2\nzero\t0\t0\t0\t0\n".to_owned();
    for line in include_str!("fixtures/cook-counts.tsv")
        .lines()
        .skip(1)
        .filter(|s| s.starts_with("gene"))
        .take(128)
    {
        let row = line.split('\t').collect::<Vec<_>>();
        table.push_str(&format!(
            "{}\t{}\t{}\t{}\t{}\n",
            row[0], row[1], row[2], row[8], row[9]
        ));
    }
    std::fs::write(&counts, table).unwrap();
    std::fs::write(
        &samples,
        "sample\tpair\tcondition\nA1\tP1\tA\nA2\tP2\tA\nB1\tP1\tB\nB2\tP2\tB\n",
    )
    .unwrap();
    let output = Command::new(env!("CARGO_BIN_EXE_rsomics-deseq"))
        .args(["run", "--counts"])
        .arg(&counts)
        .arg("--samples")
        .arg(&samples)
        .args([
            "--formula",
            "~pair+condition",
            "--factor",
            "pair=P1,P2",
            "--factor",
            "condition=A,B",
            "--fit-type",
            "mean",
            "--no-replace-outliers",
            "--threads",
            "1",
            "--bundle",
        ])
        .arg(&bundle)
        .args([
            "--contrast",
            "(Intercept)=0",
            "--contrast",
            "pairP2=0",
            "--contrast",
            "conditionB=1",
        ])
        .output()
        .unwrap();
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    let bytes = std::fs::read(&bundle).unwrap();
    let json: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
    assert_eq!(json["options"]["fit_type"], "mean");
    assert_eq!(json["dispersions"]["trend"]["kind"], "mean");
    assert_eq!(json["dispersions"]["prior"]["kind"], "fixed_reference");
    assert_eq!(json["dispersions"]["prior"]["residual_df"], 1);
    let alpha = json["dispersions"]["trend"]["alpha"].as_f64().unwrap();
    assert!(json["dispersions"]["prior_variance"].as_f64().unwrap() >= 0.25);
    let mut tables = Vec::new();
    for (name, weight) in [("forward", "1"), ("reverse", "-1")] {
        let output_path = dir.path().join(format!("{name}.tsv"));
        let output = Command::new(env!("CARGO_BIN_EXE_rsomics-deseq"))
            .args(["--json", "results", "--bundle"])
            .arg(&bundle)
            .arg("--output")
            .arg(&output_path)
            .args(["--contrast=(Intercept)=0", "--contrast=pairP2=0"])
            .arg(format!("--contrast=conditionB={weight}"))
            .output()
            .unwrap();
        assert!(
            output.status.success(),
            "{}",
            String::from_utf8_lossy(&output.stderr)
        );
        let report: serde_json::Value = serde_json::from_slice(&output.stdout).unwrap();
        assert_eq!(report["result"]["refit"], false);
        assert_eq!(
            report["result"]["filter_threshold"],
            json["initial_results"]["filter"]["threshold"]
        );
        let mut reader = csv::ReaderBuilder::new()
            .delimiter(b'\t')
            .from_path(output_path)
            .unwrap();
        let rows = reader.records().collect::<Result<Vec<_>, _>>().unwrap();
        if name == "forward" {
            let initial = json["initial_results"]["rows"].as_array().unwrap();
            assert_eq!(rows.len(), initial.len());
            for (g, (actual, expected)) in rows.iter().zip(initial).enumerate() {
                assert_eq!(
                    &actual[0],
                    json["dataset"]["counts"]["genes"][g].as_str().unwrap()
                );
                for (column, field) in [
                    "base_mean",
                    "log2_fold_change",
                    "lfc_se",
                    "stat",
                    "pvalue",
                    "padj",
                ]
                .iter()
                .enumerate()
                {
                    let value = match &actual[column + 1] {
                        "NA" => None,
                        value => Some(value.parse::<f64>().unwrap()),
                    };
                    assert_eq!(value, expected[*field].as_f64());
                }
            }
        }
        tables.push(rows);
    }
    for (one, two) in tables[0].iter().zip(&tables[1]) {
        assert_eq!(one[5], two[5]);
        let one = (&one[2] != "NA").then(|| one[2].parse::<f64>().unwrap());
        let two = (&two[2] != "NA").then(|| two[2].parse::<f64>().unwrap());
        assert_eq!(one, two.map(|value| -value));
    }
    for kind in ["normalized", "vst"] {
        let export = dir.path().join(format!("{kind}.tsv"));
        let output = Command::new(env!("CARGO_BIN_EXE_rsomics-deseq"))
            .args(["transform", "--bundle"])
            .arg(&bundle)
            .arg("--output")
            .arg(&export)
            .args(["--kind", kind])
            .output()
            .unwrap();
        assert!(
            output.status.success(),
            "{}",
            String::from_utf8_lossy(&output.stderr)
        );
        let mut reader = csv::ReaderBuilder::new()
            .delimiter(b'\t')
            .from_path(export)
            .unwrap();
        let rows = reader.records().collect::<Result<Vec<_>, _>>().unwrap();
        assert!(rows.len() > 100);
        assert_eq!(&rows[0][0], "zero");
        for value in rows[0].iter().skip(1) {
            let value = value.parse::<f64>().unwrap();
            if kind == "vst" {
                assert!((value + (4.0 * alpha).log2()).abs() < 1e-12);
            } else {
                assert_eq!(value, 0.0);
            }
        }
    }
    assert_eq!(bytes, std::fs::read(bundle).unwrap());
}
