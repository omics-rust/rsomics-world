# Fixed low-df algorithm reference profile

Data-independent generated numerical tables only; no observed gene data,
source fitted priors, selected minima, dataset IDs or RDS are embedded.
Behavior: DESeq2 1.52.0 estimateDispersionsPriorVar, released commit
16aeab6d6158bd8cbb8e98764c2f33399b1a3fd3; R 4.6.1 default
Mersenne-Twister/Inversion/Rejection RNG, seed 2, df 1/2/3, 10,000 chi-square
then 10,000 normal draws at each of 200 variances. Strict (-10,10) filter;
40 right-closed half-unit bins with hist.default fuzz and include.lowest.

Counts/totals are little-endian u32, df then coarse-grid then bin order.
Breaks and both grids are exact little-endian IEEE f64. The 1000 by 200
row-major signed prediction matrix encodes Gaussian degree-2 span .2
interpolated loess with default controls. Apply every weight in ascending
scalar multiply/add order; no FMA, pruning, normalization or clipping.

Qualified generation: source run 40603312183, controller
1f3f7a002ac2d6ac10016eb9a68536657b1367e4. Independent probes and complete
source workflows qualified this pinned profile, not universal bitwise R
equivalence. No R implementation bodies are included.

| File | SHA-256 |
| --- | --- |
| coarse-grid.f64le | c2111203942e07a2c906800b67f88a6759454e1d793e1ad8bf4e4eecec86bb55 |
| fine-grid.f64le | 02df83b29fa7d775b09426135826433cac71572b70999f3413ee436c68ae3e65 |
| histogram-breaks.f64le | d5a4afd46588f3389f408af61a483a3a5efd732e857ba2022745504c100252f9 |
| prediction-operator.f64le | 724416e33be82dde440a14acf5c5da3e4a4e110a503a2c700fb5b544f761af0d |
| reference-counts.u32le | 3ee14a42e6f39c7ba20ebdf715a429cc6ec85eedb41c66230756b4b5ebafb213 |
| reference-retained-totals.u32le | 525d58d6a355d8bed591349ecad0025bf28959a0cba2e17e81b19cbfb6b03248 |
