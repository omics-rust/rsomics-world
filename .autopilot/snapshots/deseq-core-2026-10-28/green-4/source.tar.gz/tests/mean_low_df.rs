use rsomics_deseq::{artifact, results};
use std::process::Command;

#[test]
fn mean_low_df_fit_reloads_contrasts_and_original_count_vst() {
    let dir = tempfile::tempdir().unwrap();
    let counts = dir.path().join("counts.tsv");
    let samples = dir.path().join("samples.tsv");
    let bundle = dir.path().join("fit.json");
    let mut table = "gene\tA1\tA2\tB1\tB2\nzero\t0\t0\t0\t0\n".to_owned();
    for line in include_str!("fixtures/cook-counts.tsv")
        .lines()
        .skip(1)
        .filter(|s| s.starts_with("gene"))
        .take(128)
    {
        let row = line.split('\t').collect::<Vec<_>>();
        table.push_str(&format!(
            "{}\t{}\t{}\t{}\t{}\n",
            row[0], row[1], row[2], row[8], row[9]
        ));
    }
    std::fs::write(&counts, table).unwrap();
    std::fs::write(
        &samples,
        "sample\tpair\tcondition\nA1\tP1\tA\nA2\tP2\tA\nB1\tP1\tB\nB2\tP2\tB\n",
    )
    .unwrap();
    let output = Command::new(env!("CARGO_BIN_EXE_rsomics-deseq"))
        .args(["run", "--counts"])
        .arg(&counts)
        .arg("--samples")
        .arg(&samples)
        .args([
            "--formula",
            "~pair+condition",
            "--factor",
            "pair=P1,P2",
            "--factor",
            "condition=A,B",
            "--fit-type",
            "mean",
            "--no-replace-outliers",
            "--threads",
            "1",
            "--bundle",
        ])
        .arg(&bundle)
        .args([
            "--contrast",
            "(Intercept)=0",
            "--contrast",
            "pairP2=0",
            "--contrast",
            "conditionB=1",
        ])
        .output()
        .unwrap();
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    let fit = artifact::load(&bundle).unwrap();
    let json = serde_json::to_value(&fit).unwrap();
    assert_eq!(json["options"]["fit_type"], "mean");
    assert_eq!(json["dispersions"]["trend"]["kind"], "mean");
    assert_eq!(json["dispersions"]["prior"]["kind"], "fixed_reference");
    assert_eq!(json["dispersions"]["prior"]["residual_df"], 1);
    let alpha = json["dispersions"]["trend"]["alpha"].as_f64().unwrap();
    assert!((fit.vst(0, 0) + (4.0 * alpha).log2()).abs() < 1e-12);
    assert_eq!(fit.normalized(0, 0), 0.0);
    assert!(fit.dispersions.prior_variance >= 0.25);
    let forward = results::derive(&fit, &[0.0, 0.0, 1.0], 0.1).unwrap();
    let reverse = results::derive(&fit, &[0.0, 0.0, -1.0], 0.1).unwrap();
    assert_eq!(
        serde_json::to_value(&forward).unwrap(),
        serde_json::to_value(fit.initial_results.as_ref().unwrap()).unwrap()
    );
    for (one, two) in forward.rows.iter().zip(&reverse.rows) {
        assert_eq!(one.pvalue, two.pvalue);
        assert_eq!(one.log2_fold_change, two.log2_fold_change.map(|v| -v));
    }
    let export = dir.path().join("vst.tsv");
    artifact::transform(&export, &fit, true).unwrap();
    assert!(std::fs::read_to_string(export).unwrap().lines().count() > 100);
}
