use rsomics_deseq::{
    artifact,
    dataset::{Dataset, DesignInput},
    fit,
    replacement::{Refit, Replacement},
    results,
};
use std::path::Path;

#[test]
fn cook_replacement_refit_and_zero_lifecycle_survive_reload() {
    let dir = tempfile::tempdir().unwrap();
    let samples = dir.path().join("samples.tsv");
    let factors = dir.path().join("factors.tsv");
    let ids = ["A", "B"]
        .into_iter()
        .flat_map(|group| (1..=7).map(move |j| (format!("{group}{j:02}"), group)))
        .collect::<Vec<_>>();
    std::fs::write(
        &samples,
        format!(
            "sample\tgroup\n{}",
            ids.iter()
                .map(|(id, group)| format!("{id}\t{group}\n"))
                .collect::<String>()
        ),
    )
    .unwrap();
    std::fs::write(
        &factors,
        format!(
            "sample\tfactor\n{}",
            ids.iter()
                .map(|(id, _)| format!("{id}\t1\n"))
                .collect::<String>()
        ),
    )
    .unwrap();
    let data = Dataset::read_inputs(
        &Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/cook-counts.tsv"),
        &samples,
        DesignInput::Formula {
            formula: "~group",
            numeric: &[],
            factors: &["group=A,B".into()],
        },
        Some(&factors),
        None,
    )
    .unwrap();
    let marker = |name: &str| data.counts.genes.iter().position(|g| g == name).unwrap();
    let mut fitted = fit::run(data.clone(), 1).unwrap();
    let disabled = fit::run_with_options(
        data.clone(),
        1,
        fit::FitOptions {
            no_replace_outliers: true,
            fit_type: rsomics_deseq::dispersion::FitType::Parametric,
        },
    )
    .unwrap();
    let Replacement::Assessed(state) = &fitted.replacement else {
        panic!("replacement was skipped");
    };
    assert!(state.eligible.iter().all(|v| *v));
    assert!(state.max_cooks.iter().all(Option::is_none));
    assert!(matches!(
        state.refits[marker("eligible-high-A")],
        Refit::Fitted(_)
    ));
    assert!(matches!(
        state.refits[marker("replace-zero-A")],
        Refit::Zero {
            results_cleared: true
        }
    ));
    assert_eq!(state.flags[marker("all-zero")], None);
    assert_eq!(
        state.counts.as_ref().unwrap().values[marker("eligible-high-A") * 14],
        36.0
    );
    assert_eq!(
        fitted.dataset.counts.row(marker("eligible-high-A"))[0],
        1_000_000.0
    );
    for g in 0..data.counts.n_genes {
        assert_eq!(
            fitted.genes[g].as_ref().map(|g| &g.glm.raw_mu),
            disabled.genes[g].as_ref().map(|g| &g.glm.raw_mu)
        );
        for j in 0..14 {
            assert_eq!(fitted.vst(g, j), disabled.vst(g, j));
        }
    }
    let result = results::derive(&fitted, &[0.0, 1.0], 0.1).unwrap();
    let zero = &result.rows[marker("replace-zero-A")];
    assert_eq!(
        (
            zero.base_mean,
            zero.log2_fold_change,
            zero.lfc_se,
            zero.stat,
            zero.pvalue
        ),
        (0.0, Some(0.0), Some(0.0), Some(0.0), Some(1.0))
    );
    assert_eq!(result.rows[marker("all-zero")].pvalue, None);
    fitted.initial_results = Some(result);
    let path = dir.path().join("fit.json");
    artifact::save(&path, &fitted).unwrap();
    let loaded = artifact::load(&path).unwrap();
    assert_eq!(
        serde_json::to_value(results::derive(&loaded, &[0.0, 1.0], 0.1).unwrap()).unwrap(),
        serde_json::to_value(fitted.initial_results.as_ref().unwrap()).unwrap()
    );
    let mut old = serde_json::to_value(&fitted).unwrap();
    old["schema"] = 2.into();
    old.as_object_mut().unwrap().remove("replacement");
    let old_path = dir.path().join("old-schema.json");
    std::fs::write(&old_path, serde_json::to_vec(&old).unwrap()).unwrap();
    assert!(
        artifact::load(&old_path)
            .unwrap_err()
            .to_string()
            .contains("schema 4 is required")
    );

    for n in [9, 10] {
        let counts_path = dir.path().join(format!("counts-{n}.tsv"));
        let samples_path = dir.path().join(format!("samples-{n}.tsv"));
        let factors_path = dir.path().join(format!("factors-{n}.tsv"));
        let mut counts = format!("gene\t{}\n", data.counts.samples[..n].join("\t"));
        for (g, name) in data.counts.genes.iter().enumerate() {
            counts.push_str(&format!(
                "{name}\t{}\n",
                data.counts.row(g)[..n]
                    .iter()
                    .map(f64::to_string)
                    .collect::<Vec<_>>()
                    .join("\t")
            ));
        }
        std::fs::write(&counts_path, counts).unwrap();
        std::fs::write(
            &samples_path,
            format!(
                "sample\tgroup\n{}",
                ids[..n]
                    .iter()
                    .map(|(id, group)| format!("{id}\t{group}\n"))
                    .collect::<String>()
            ),
        )
        .unwrap();
        std::fs::write(
            &factors_path,
            format!(
                "sample\tfactor\n{}",
                ids[..n]
                    .iter()
                    .map(|(id, _)| format!("{id}\t1\n"))
                    .collect::<String>()
            ),
        )
        .unwrap();
        let partial = Dataset::read_inputs(
            &counts_path,
            &samples_path,
            DesignInput::Formula {
                formula: "~group",
                numeric: &[],
                factors: &["group=A,B".into()],
            },
            Some(&factors_path),
            None,
        )
        .unwrap();
        let fitted = fit::run(partial, 1).unwrap();
        let Replacement::Assessed(state) = &fitted.replacement else {
            panic!("replacement was skipped");
        };
        assert!(state.refits.iter().any(|r| matches!(r, Refit::Fitted(_))));
        assert_eq!(state.eligible.iter().filter(|v| **v).count(), 7);
        assert!(fitted.genes[marker("all-zero")].is_none());
        assert_eq!(
            fitted.max_cooks(marker("all-zero")),
            if n == 9 { Some(0.0) } else { None }
        );
        assert_eq!(
            results::derive(&fitted, &[0.0, 1.0], 0.1).unwrap().rows[marker("all-zero")].pvalue,
            None
        );
    }

    for with_zero in [true, false] {
        let mut subset = data.clone();
        let indices = data
            .counts
            .genes
            .iter()
            .enumerate()
            .filter(|(_, g)| {
                g.starts_with("gene")
                    || *g == "all-zero"
                    || *g == "stable"
                    || (with_zero && *g == "replace-zero-A")
            })
            .map(|(g, _)| g)
            .collect::<Vec<_>>();
        subset.counts.genes = indices
            .iter()
            .map(|g| data.counts.genes[*g].clone())
            .collect();
        subset.counts.data = indices
            .iter()
            .flat_map(|g| data.counts.row(*g).iter().copied())
            .collect();
        subset.counts.n_genes = indices.len();
        let fitted = fit::run(subset, 1).unwrap();
        let Replacement::Assessed(state) = &fitted.replacement else {
            panic!("replacement was skipped");
        };
        assert_eq!(state.counts.is_some(), with_zero);
        assert_eq!(state.original_counts_assay, !with_zero);
        assert!(!state.refits.iter().any(|r| matches!(r, Refit::Fitted(_))));
        assert_eq!(
            state
                .refits
                .iter()
                .filter(|r| matches!(
                    r,
                    Refit::Zero {
                        results_cleared: false
                    }
                ))
                .count(),
            usize::from(with_zero)
        );
        assert_eq!(
            state.max_cooks,
            fitted
                .genes
                .iter()
                .map(|g| g.as_ref().and_then(|g| g.max_cooks))
                .collect::<Vec<_>>()
        );
    }
}
