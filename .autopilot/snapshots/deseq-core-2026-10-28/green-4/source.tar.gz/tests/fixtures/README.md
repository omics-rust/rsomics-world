`cook-counts.tsv` selects the first 100 background rows and all six marker rows
from the team-owned frozen Cook 7+7 input in source run 40592944209,
`inputs/cook-7x7/counts.tsv`. Quoting and numeric padding were removed; values
and sample order are unchanged. This small fixture tests whole-product state
transitions and reload, not independent numerical oracle parity for the subset.
The external full 15-case witness remains the compatibility authority.
