use anyhow::{Result, ensure};
use serde::{Deserialize, Serialize};

const BINS: usize = 40;
const COARSE: usize = 200;
const FINE: usize = 1000;
const BREAKS: &[u8; (BINS + 1) * 8] =
    include_bytes!("../assets/low-df-r461/histogram-breaks.f64le");
const COARSE_GRID: &[u8; COARSE * 8] = include_bytes!("../assets/low-df-r461/coarse-grid.f64le");
const FINE_GRID: &[u8; FINE * 8] = include_bytes!("../assets/low-df-r461/fine-grid.f64le");
const WEIGHTS: &[u8; FINE * COARSE * 8] =
    include_bytes!("../assets/low-df-r461/prediction-operator.f64le");
const COUNTS: &[u8; 3 * COARSE * BINS * 4] =
    include_bytes!("../assets/low-df-r461/reference-counts.u32le");
const TOTALS: &[u8; 3 * COARSE * 4] =
    include_bytes!("../assets/low-df-r461/reference-retained-totals.u32le");

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum Prior {
    Analytic {
        residual_df: usize,
        sampling_variance: f64,
    },
    FixedReference(Box<FixedReference>),
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub enum Profile {
    #[serde(rename = "R-4.6.1-default-seed-2-v1")]
    R461DefaultSeed2,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FixedReference {
    pub profile: Profile,
    pub residual_df: usize,
    pub observed_counts: Vec<usize>,
    pub observed_retained: usize,
    pub coarse_variances: Vec<f64>,
    pub small: Vec<f64>,
    pub kl: Vec<f64>,
    pub prediction: Vec<f64>,
    pub selected_index: usize,
}

fn double(bytes: &[u8], index: usize) -> f64 {
    f64::from_le_bytes(
        bytes[index * 8..(index + 1) * 8]
            .try_into()
            .expect("fixed f64 table element"),
    )
}

fn integer(bytes: &[u8], index: usize) -> u32 {
    u32::from_le_bytes(
        bytes[index * 4..(index + 1) * 4]
            .try_into()
            .expect("fixed u32 table element"),
    )
}

fn first_minimum(values: &[f64]) -> usize {
    let mut selected = 0;
    for i in 1..values.len() {
        if values[i] < values[selected] {
            selected = i;
        }
    }
    selected
}

pub(crate) fn estimate(residuals: &[f64], df: usize) -> Result<(f64, Prior)> {
    ensure!(
        (1..=3).contains(&df),
        "fixed-reference prior requires residual df 1, 2 or 3"
    );
    let breaks: [f64; BINS + 1] = std::array::from_fn(|i| double(BREAKS, i));
    let mut counts = vec![0; BINS];
    for &value in residuals {
        ensure!(value.is_finite(), "nonfinite observed dispersion residual");
        if value > breaks[0] && value < breaks[BINS] {
            let bin = (1..=BINS)
                .find(|&i| value <= breaks[i] + 5e-8)
                .expect("strict outer filter is within fuzzy histogram edges");
            counts[bin - 1] += 1;
        }
    }
    let retained: usize = counts.iter().sum();
    ensure!(
        retained > 0,
        "no observed dispersion residuals in the prior histogram range (-10, 10)"
    );
    let density: [f64; BINS] =
        std::array::from_fn(|i| counts[i] as f64 / (retained as f64 * (breaks[i + 1] - breaks[i])));
    let mut kl = Vec::with_capacity(COARSE);
    let mut small = Vec::with_capacity(COARSE);
    for grid in 0..COARSE {
        let row = (df - 1) * COARSE + grid;
        let total = integer(TOTALS, row) as f64;
        let reference: [f64; BINS] = std::array::from_fn(|i| {
            integer(COUNTS, row * BINS + i) as f64 / (total * (breaks[i + 1] - breaks[i]))
        });
        let positive = density
            .iter()
            .chain(&reference)
            .copied()
            .filter(|v| *v > 0.0)
            .fold(f64::INFINITY, f64::min);
        small.push(positive);
        kl.push(
            density
                .iter()
                .zip(reference)
                .map(|(observed, expected)| {
                    observed * ((observed + positive).ln() - (expected + positive).ln())
                })
                .sum(),
        );
    }
    let prediction: Vec<f64> = (0..FINE)
        .map(|i| {
            let mut value = 0.0;
            for (j, response) in kl.iter().enumerate() {
                value += double(WEIGHTS, i * COARSE + j) * response;
            }
            value
        })
        .collect();
    ensure!(
        kl.iter().chain(&prediction).all(|v| v.is_finite()),
        "nonfinite low-df prior prediction"
    );
    let selected_index = first_minimum(&prediction);
    let variance = double(FINE_GRID, selected_index).max(0.25);
    Ok((
        variance,
        Prior::FixedReference(Box::new(FixedReference {
            profile: Profile::R461DefaultSeed2,
            residual_df: df,
            observed_counts: counts,
            observed_retained: retained,
            coarse_variances: (0..COARSE).map(|i| double(COARSE_GRID, i)).collect(),
            small,
            kl,
            prediction,
            selected_index,
        })),
    ))
}

impl Prior {
    pub(crate) fn validate(&self, df: usize, variance: f64, residual_variance: f64) -> Result<()> {
        let expected = match self {
            Self::Analytic {
                residual_df,
                sampling_variance,
            } => {
                ensure!(
                    *residual_df == df
                        && df >= 4
                        && sampling_variance.is_finite()
                        && *sampling_variance > 0.0,
                    "invalid analytic dispersion prior"
                );
                (residual_variance - sampling_variance).max(0.25)
            }
            Self::FixedReference(state) => {
                ensure!(
                    state.residual_df == df
                        && (1..=3).contains(&df)
                        && state.observed_counts.len() == BINS
                        && state.observed_retained > 0
                        && state.observed_counts.iter().sum::<usize>() == state.observed_retained
                        && state.coarse_variances.len() == COARSE
                        && state.small.len() == COARSE
                        && state.kl.len() == COARSE
                        && state.prediction.len() == FINE,
                    "incomplete fixed-reference dispersion prior"
                );
                ensure!(
                    state
                        .coarse_variances
                        .iter()
                        .enumerate()
                        .all(|(i, v)| *v == double(COARSE_GRID, i))
                        && state.small.iter().all(|v| v.is_finite() && *v > 0.0)
                        && state
                            .kl
                            .iter()
                            .chain(&state.prediction)
                            .all(|v| v.is_finite())
                        && state.selected_index == first_minimum(&state.prediction),
                    "invalid fixed-reference dispersion prior"
                );
                double(FINE_GRID, state.selected_index).max(0.25)
            }
        };
        ensure!(
            variance == expected,
            "dispersion prior variance differs from saved method state"
        );
        Ok(())
    }
}
