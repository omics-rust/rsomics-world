#![forbid(unsafe_code)]

pub mod artifact;
pub mod cli;
pub mod dataset;
pub mod design;
pub mod dispersion;
pub mod fit;
pub mod glm;
mod lowess;
pub mod normalization;
pub mod prior;
pub mod replacement;
pub mod results;
