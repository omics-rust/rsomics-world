use crate::{fit::FittedAnalysis, results::Results};
use anyhow::Result;
use rsomics_common::{RsomicsError, write_atomic};
use std::{
    io::{BufReader, Write},
    path::Path,
};

pub fn save(path: &Path, fit: &FittedAnalysis) -> Result<()> {
    fit.validate()?;
    anyhow::ensure!(
        fit.initial_results.is_some(),
        "cannot save an incomplete analysis without initial contrast results"
    );
    anyhow::ensure!(path != Path::new("-"), "a named bundle path is required");
    write_atomic(path, |file| {
        serde_json::to_writer(file, fit).map_err(crate::cli::json_error)
    })?;
    Ok(())
}

pub fn load(path: &Path) -> Result<FittedAnalysis> {
    let fit: FittedAnalysis = serde_json::from_reader(BufReader::new(std::fs::File::open(path)?))
        .map_err(|error: serde_json::Error| {
        if error.is_io() {
            crate::cli::json_error(error)
        } else {
            RsomicsError::InvalidInput(format!(
                "cannot read fitted bundle; schema {} is required: {error}",
                crate::fit::SCHEMA
            ))
        }
    })?;
    fit.validate()?;
    anyhow::ensure!(
        fit.initial_results.is_some(),
        "incomplete analysis: missing initial contrast results"
    );
    Ok(fit)
}

pub fn results(path: &Path, fit: &FittedAnalysis, result: &Results) -> Result<()> {
    anyhow::ensure!(path != Path::new("-"), "a named result path is required");
    write_atomic(path, |file| {
        let mut writer = csv::WriterBuilder::new().delimiter(b'\t').from_writer(file);
        let mut operation = || -> Result<()> {
            writer.write_record([
                "gene",
                "baseMean",
                "log2FoldChange",
                "lfcSE",
                "stat",
                "pvalue",
                "padj",
            ])?;
            for (gene, row) in fit.dataset.counts.genes.iter().zip(&result.rows) {
                writer.write_record([
                    gene.clone(),
                    row.base_mean.to_string(),
                    number(row.log2_fold_change),
                    number(row.lfc_se),
                    number(row.stat),
                    number(row.pvalue),
                    number(row.padj),
                ])?;
            }
            writer.flush()?;
            Ok(())
        };
        operation().map_err(crate::cli::process_error)
    })?;
    Ok(())
}

pub fn transform(path: &Path, fit: &FittedAnalysis, vst: bool) -> Result<()> {
    anyhow::ensure!(path != Path::new("-"), "a named transform path is required");
    write_atomic(path, |file| {
        let mut writer = csv::WriterBuilder::new().delimiter(b'\t').from_writer(file);
        let mut operation = || -> Result<()> {
            writer.write_record(
                std::iter::once("gene")
                    .chain(fit.dataset.counts.samples.iter().map(String::as_str)),
            )?;
            for (g, gene) in fit.dataset.counts.genes.iter().enumerate() {
                writer.write_record(
                    std::iter::once(gene.clone()).chain(
                        (0..fit.dataset.counts.n_samples)
                            .map(|j| {
                                if vst {
                                    fit.vst(g, j)
                                } else {
                                    fit.normalized(g, j)
                                }
                            })
                            .map(|v| v.to_string()),
                    ),
                )?;
            }
            writer.flush()?;
            Ok(())
        };
        operation().map_err(crate::cli::process_error)
    })?;
    Ok(())
}

pub fn json(path: &Path, value: &impl serde::Serialize) -> Result<()> {
    write_atomic(path, |file| {
        serde_json::to_writer_pretty(&mut *file, value).map_err(crate::cli::json_error)?;
        file.write_all(b"\n").map_err(RsomicsError::Io)
    })?;
    Ok(())
}

fn number(value: Option<f64>) -> String {
    value.map(|v| v.to_string()).unwrap_or_else(|| "NA".into())
}
