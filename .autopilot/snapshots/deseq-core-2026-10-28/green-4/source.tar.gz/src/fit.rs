use crate::{
    dataset::Dataset,
    dispersion::{self, Dispersions},
    glm::{self, GlmFit},
};
use anyhow::{Context, Result, ensure};
use rayon::prelude::*;
use serde::{Deserialize, Serialize};

pub const SCHEMA: u32 = 4;
pub const UPSTREAM: &str = "DESeq2 1.52.0 (16aeab6d6158bd8cbb8e98764c2f33399b1a3fd3)";

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GeneFit {
    pub glm: GlmFit,
    pub cooks: Vec<f64>,
    pub max_cooks: Option<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FitOptions {
    pub no_replace_outliers: bool,
    pub fit_type: dispersion::FitType,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FittedAnalysis {
    pub schema: u32,
    pub product_version: String,
    pub upstream: String,
    pub workers: usize,
    pub dataset: Dataset,
    pub options: FitOptions,
    pub dispersions: Dispersions,
    pub genes: Vec<Option<GeneFit>>,
    pub replacement: crate::replacement::Replacement,
    pub initial_results: Option<crate::results::Results>,
}

pub fn run(dataset: Dataset, workers: usize) -> Result<FittedAnalysis> {
    run_with_options(
        dataset,
        workers,
        FitOptions {
            no_replace_outliers: false,
            fit_type: dispersion::FitType::Parametric,
        },
    )
}

pub fn run_with_options(
    dataset: Dataset,
    workers: usize,
    options: FitOptions,
) -> Result<FittedAnalysis> {
    dataset.validate()?;
    ensure!(workers > 0, "worker count must be positive");
    let pool = rayon::ThreadPoolBuilder::new()
        .num_threads(workers)
        .build()?;
    pool.install(|| {
        let dispersions = dispersion::estimate_with_prior(
            &dataset.counts,
            &dataset.design,
            &dataset.normalization,
            options.fit_type,
            None,
        )?;
        let genes = fit_genes(&dataset, &dispersions)?;
        let mut fitted = FittedAnalysis {
            schema: SCHEMA,
            product_version: env!("CARGO_PKG_VERSION").to_owned(),
            upstream: UPSTREAM.to_owned(),
            workers,
            dataset,
            options,
            dispersions,
            genes,
            replacement: crate::replacement::Replacement::NotRun,
            initial_results: None,
        };
        fitted.replacement = crate::replacement::run(&fitted)?;
        fitted.validate()?;
        Ok(fitted)
    })
}

pub(crate) fn fit_genes(
    dataset: &Dataset,
    dispersions: &Dispersions,
) -> Result<Vec<Option<GeneFit>>> {
    let logsf = dataset.normalization.log_factors(dataset.counts.n_samples);
    let intercept_shortcut = dataset.design_source.intercept_shortcut();
    let cells = dataset.design.cells();
    let eligible = cells
        .iter()
        .filter(|g| g.len() >= 3)
        .flatten()
        .copied()
        .collect::<Vec<_>>();
    (0..dataset.counts.n_genes)
        .into_par_iter()
        .map(|g| -> Result<Option<GeneFit>> {
            let Some(disp) = &dispersions.genes[g] else {
                return Ok(None);
            };
            let row = dataset.counts.row(g);
            let glm = glm::fit_with_intercept_shortcut(
                row,
                logsf.row(g),
                &dataset.design,
                disp.final_disp,
                intercept_shortcut,
            )
            .with_context(|| format!("Wald GLM {}", dataset.counts.genes[g]))?;
            let normalized = row
                .iter()
                .zip(dataset.normalization.row(g, dataset.counts.n_samples))
                .map(|(y, s)| y / s)
                .collect::<Vec<_>>();
            let variance = if eligible.is_empty() {
                trimmed_variance(&normalized, 0.125, 1.51)
            } else {
                cells
                    .iter()
                    .filter(|c| c.len() >= 3)
                    .map(|c| {
                        let (trim, scale) = if c.len() <= 3 {
                            (1.0 / 3.0, 2.04)
                        } else if c.len() <= 23 {
                            (0.25, 1.86)
                        } else {
                            (0.125, 1.51)
                        };
                        trimmed_variance(
                            &c.iter().map(|&j| normalized[j]).collect::<Vec<_>>(),
                            trim,
                            scale,
                        )
                    })
                    .fold(f64::NEG_INFINITY, f64::max)
            };
            let mean = dispersions.base_mean[g];
            let robust_disp = ((variance - mean) / mean.powi(2)).max(0.04);
            let cooks = row
                .iter()
                .zip(&glm.raw_mu)
                .zip(&glm.hat)
                .map(|((&y, &mu), &h)| {
                    (y - mu).powi(2) / (mu + robust_disp * mu.powi(2)) / dataset.design.p as f64 * h
                        / (1.0 - h).powi(2)
                })
                .collect::<Vec<_>>();
            ensure!(
                cooks.iter().all(|x| x.is_finite() && *x >= 0.0),
                "nonfinite Cook's distance {}",
                dataset.counts.genes[g]
            );
            let max_cooks = eligible.iter().map(|&j| cooks[j]).reduce(f64::max);
            Ok(Some(GeneFit {
                glm,
                cooks,
                max_cooks,
            }))
        })
        .collect::<Result<Vec<_>>>()
}

fn trimmed_variance(values: &[f64], trim: f64, scale: f64) -> f64 {
    let center = trimmed_mean(values.to_vec(), trim);
    scale * trimmed_mean(values.iter().map(|v| (v - center).powi(2)).collect(), trim)
}

fn trimmed_mean(mut values: Vec<f64>, trim: f64) -> f64 {
    values.sort_by(f64::total_cmp);
    let cut = (values.len() as f64 * trim).floor() as usize;
    values[cut..values.len() - cut].iter().sum::<f64>() / (values.len() - 2 * cut) as f64
}

impl FittedAnalysis {
    pub fn validate(&self) -> Result<()> {
        ensure!(
            self.schema == SCHEMA,
            "unsupported fit bundle schema {}",
            self.schema
        );
        ensure!(
            self.upstream == UPSTREAM,
            "unsupported numerical provenance"
        );
        self.dataset.validate()?;
        let m = &self.dataset.counts;
        let p = self.dataset.design.p;
        ensure!(self.workers > 0, "invalid worker count");
        ensure!(
            self.genes.len() == m.n_genes
                && self.dispersions.genes.len() == m.n_genes
                && self.dispersions.base_mean.len() == m.n_genes
                && self.dispersions.base_var.len() == m.n_genes,
            "incomplete fitted bundle"
        );
        ensure!(
            [self.dispersions.prior_variance]
                .iter()
                .all(|x| x.is_finite() && *x > 0.0)
                && self.dispersions.log_dispersion_variance.is_finite()
                && self.dispersions.log_dispersion_variance >= 0.0,
            "invalid dispersion trend state"
        );
        self.dispersions.trend.validate(self.options.fit_type)?;
        self.dispersions.prior.validate(
            m.n_samples - p,
            self.dispersions.prior_variance,
            self.dispersions.log_dispersion_variance,
        )?;
        ensure!(
            self.dispersions
                .base_mean
                .iter()
                .chain(&self.dispersions.base_var)
                .all(|x| x.is_finite() && *x >= 0.0),
            "invalid base statistics"
        );
        self.replacement.validate(self)?;
        for g in 0..m.n_genes {
            ensure!(
                self.genes[g].is_none() == m.row(g).iter().all(|y| *y == 0.0),
                "invalid all-zero state"
            );
            ensure!(
                self.genes[g].is_some() == self.dispersions.genes[g].is_some(),
                "incomplete dispersion state"
            );
            let refit = match self.replacement.refit(g) {
                Some(crate::replacement::Refit::Fitted(gene)) => Some(gene.as_ref()),
                _ => None,
            };
            for fit in self.genes[g].iter().chain(refit.map(|gene| &gene.fit)) {
                ensure!(
                    fit.glm.converged
                        && fit.glm.beta.len() == p
                        && fit.glm.covariance.len() == p * p
                        && fit.glm.raw_mu.len() == m.n_samples
                        && fit.glm.floored_mu.len() == m.n_samples
                        && fit.glm.hat.len() == m.n_samples
                        && fit.cooks.len() == m.n_samples,
                    "incomplete or failed gene fit"
                );
                ensure!(
                    fit.glm
                        .beta
                        .iter()
                        .chain(&fit.glm.covariance)
                        .chain(&fit.glm.raw_mu)
                        .chain(&fit.glm.floored_mu)
                        .chain(&fit.glm.hat)
                        .chain(&fit.cooks)
                        .all(|x| x.is_finite()),
                    "nonfinite stored gene fit"
                );
                ensure!(
                    fit.glm.raw_mu.iter().all(|x| *x > 0.0)
                        && fit.glm.floored_mu.iter().all(|x| *x >= 0.5)
                        && fit.glm.hat.iter().all(|x| *x >= 0.0 && *x <= 1.0)
                        && fit.cooks.iter().all(|x| *x >= 0.0)
                        && fit.max_cooks.is_none_or(|x| x.is_finite() && x >= 0.0)
                        && fit.glm.log_like.is_finite()
                        && (1..=100).contains(&fit.glm.iterations)
                        && (0..p).all(|k| fit.glm.covariance[k * p + k] > 0.0),
                    "invalid stored fit diagnostics"
                );
                if let Some(optimizer) = &fit.glm.optimizer {
                    ensure!(
                        optimizer.convergence == 0
                            && optimizer.start.len() == p
                            && optimizer.irls_beta.len() == p,
                        "incomplete or failed optimizer state"
                    );
                }
            }
            for dispersion in self.dispersions.genes[g]
                .iter()
                .chain(refit.map(|gene| &gene.dispersion))
            {
                ensure!(
                    [
                        dispersion.initial,
                        dispersion.gene,
                        dispersion.fitted,
                        dispersion.map,
                        dispersion.final_disp
                    ]
                    .iter()
                    .all(|x| x.is_finite() && *x > 0.0)
                        && dispersion.estimation_mu.len() == m.n_samples
                        && dispersion
                            .estimation_mu
                            .iter()
                            .all(|x| x.is_finite() && *x >= 0.5)
                        && dispersion.final_disp
                            == if dispersion.outlier {
                                dispersion.gene
                            } else {
                                dispersion.map
                            },
                    "invalid stored dispersion state"
                );
            }
        }
        if let Some(result) = &self.initial_results {
            ensure!(
                result.rows.len() == m.n_genes
                    && result.contrast.len() == p
                    && result.contrast.iter().all(|c| c.is_finite())
                    && result.contrast.iter().any(|c| *c != 0.0)
                    && result.alpha > 0.0
                    && result.alpha < 1.0,
                "incomplete initial contrast state"
            );
            let filter = &result.filter;
            ensure!(
                filter.theta.len() == 50
                    && filter.cutoffs.len() == 50
                    && filter.rejections.len() == 50
                    && filter.lowess.len() == 50
                    && filter.selected < 50
                    && filter.threshold == filter.cutoffs[filter.selected],
                "incomplete independent-filter state"
            );
        }
        Ok(())
    }
    pub fn base_mean(&self, g: usize) -> f64 {
        match &self.replacement {
            crate::replacement::Replacement::Assessed(state) => state.base_mean[g],
            crate::replacement::Replacement::NotRun => self.dispersions.base_mean[g],
        }
    }
    pub fn final_gene(&self, g: usize) -> Option<&GeneFit> {
        match self.replacement.refit(g) {
            Some(crate::replacement::Refit::Fitted(state)) => Some(&state.fit),
            Some(crate::replacement::Refit::Zero { .. }) => None,
            _ => self.genes[g].as_ref(),
        }
    }
    pub fn final_dispersion(&self, g: usize) -> Option<&dispersion::GeneDispersion> {
        match self.replacement.refit(g) {
            Some(crate::replacement::Refit::Fitted(state)) => Some(&state.dispersion),
            _ => self.dispersions.genes[g].as_ref(),
        }
    }
    pub fn max_cooks(&self, g: usize) -> Option<f64> {
        match &self.replacement {
            crate::replacement::Replacement::Assessed(state) => state.max_cooks[g],
            crate::replacement::Replacement::NotRun => {
                self.genes[g].as_ref().and_then(|fit| fit.max_cooks)
            }
        }
    }
    pub fn normalized(&self, g: usize, j: usize) -> f64 {
        self.dataset.counts.row(g)[j]
            / self
                .dataset
                .normalization
                .row(g, self.dataset.counts.n_samples)[j]
    }
    pub fn vst(&self, g: usize, j: usize) -> f64 {
        let q = self.normalized(g, j);
        match self.dispersions.trend {
            dispersion::Trend::Parametric { a0, a1 } => {
                ((1.0 + a1 + 2.0 * a0 * q + 2.0 * (a0 * q * (1.0 + a1 + a0 * q)).sqrt())
                    / (4.0 * a0))
                    .ln()
                    / std::f64::consts::LN_2
            }
            dispersion::Trend::Mean { alpha } => {
                (2.0 * (alpha * q).sqrt().asinh() - alpha.ln() - 4.0f64.ln())
                    / std::f64::consts::LN_2
            }
        }
    }
}
