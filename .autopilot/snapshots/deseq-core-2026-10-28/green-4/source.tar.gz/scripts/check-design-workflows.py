"""Compare complete private design/normalization workflows with a frozen source run."""
import argparse
import csv
import hashlib
import importlib.util
import json
import math
import pathlib
import re
import shutil
import subprocess
import time

module_spec = importlib.util.spec_from_file_location("pasilla", pathlib.Path(__file__).with_name("check-workflow.py"))
pasilla = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(pasilla)
BOUNDS, table, numeric = pasilla.BOUNDS, pasilla.table, pasilla.numeric

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", type=pathlib.Path, required=True)
    parser.add_argument("--witness", type=pathlib.Path, required=True)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--include-disabled-cook", action="store_true")
    parser.add_argument("--include-default-cook", action="store_true")
    parser.add_argument("--low-df", action="store_true", help="Compare all four qualified mean/low-df workflows")
    parser.add_argument("--reuse-from", type=pathlib.Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    source = json.loads((args.witness/"witness.json").read_text())
    assert source["package"]["version"] == "1.52.0"
    assert source["package"]["source_commit"] == "16aeab6d6158bd8cbb8e98764c2f33399b1a3fd3"
    assert source["status"] == "complete", "source execution/coverage is incomplete"
    _, manifest = table(args.witness/"sha256-manifest.tsv")
    for digest, name in manifest:
        assert sha(args.witness/name) == digest, name
    source_bounds = json.loads((args.witness/"inputs/native-comparison-bounds.json").read_text())
    for name, pair in BOUNDS.items():
        value = source_bounds[name]
        assert tuple(value if isinstance(value,list) else [value["absolute"],value["relative"]]) == tuple(pair)
    inventory = json.loads((args.witness/"inputs/case-inventory.json").read_text())
    if args.low_df:
        assert list(inventory) == ["df-1", "df-2", "df-3", "df-4"]
        inventory = list(inventory.values())
        cases = inventory
    else:
        cases = [s for s in inventory if s["input"] == "general" or (args.include_disabled_cook and s["replacement"] == "disabled") or (args.include_default_cook and s["replacement"] == "default")]
        assert sum(s["input"] == "general" for s in cases) == 7
    contract = {"bounds":BOUNDS,"binary_sha256":sha(args.binary),"source_witness_sha256":sha(args.witness/"witness.json"),"workers":args.workers,"cases":[s["id"] for s in cases],"excluded_cases":[s["id"] for s in inventory if s not in cases]}
    (args.output/"comparison-contract.json").write_text(json.dumps(contract,indent=2))
    summary = []
    for spec in cases:
        target = args.output/spec["id"]
        target.mkdir()
        oracle = args.witness/"cases"/spec["id"]
        commands, failures, metrics, iterations = [], [], {}, []
        def exact(field, actual, expected):
            if actual != expected:
                failures.append({"field":field,"actual":actual,"expected":expected})
        def check(field, actual, expected, kind):
            actual, expected = numeric(actual), numeric(expected)
            item = metrics.setdefault(field, {"count":0,"failed":0,"max_abs":0.0,"max_scaled":0.0})
            item["count"] += 1
            if actual is None or expected is None:
                ok = actual is None and expected is None
            else:
                absolute, relative = BOUNDS[kind]
                error = abs(actual-expected)
                scaled = error/(absolute+relative*abs(expected))
                item["max_abs"] = max(item["max_abs"],error)
                item["max_scaled"] = max(item["max_scaled"],scaled)
                ok = math.isfinite(actual) and scaled <= 1
            if not ok:
                item["failed"] += 1
                failures.append({"field":field,"index":item["count"]-1,"actual":actual,"expected":expected})
        def run(command):
            start = time.monotonic()
            proc = subprocess.run([str(args.binary),"--json",*map(str,command)],capture_output=True,text=True)
            commands.append({"argv":command,"exit":proc.returncode,"seconds":time.monotonic()-start,"stdout":proc.stdout,"stderr":proc.stderr})
            (target/"commands.json").write_text(json.dumps(commands,indent=2,default=str))
            if proc.returncode:
                raise RuntimeError(proc.stdout+proc.stderr)
        def contrast(name):
            return ["--contrast="+k+"="+str(v) for k,v in spec["contrasts"][name].items()]
        def compare_tables(native, reference, kind=None):
            header, rows = table(native)
            reference_header, reference_rows = table(reference)
            exact(native.name+" header",header,reference_header)
            exact(native.name+" row IDs",[r[0] for r in rows],[r[0] for r in reference_rows])
            for row, expected in zip(rows,reference_rows):
                for name,a,e in zip(header[1:],row[1:],expected[1:]):
                    bound = kind or ("normalization" if name == "baseMean" else "probability" if name in ("pvalue","padj") else "coefficient")
                    check(native.name+":"+name,a,e,bound)
                    if name == "padj":
                        exact(native.name+" discovery:"+row[0],numeric(a) is not None and numeric(a)<0.1,numeric(e) is not None and numeric(e)<0.1)
        try:
            state = json.loads((oracle/"case.json").read_text())
            assert state["status"] == "complete"
            fit_type = "mean" if args.low_df else "parametric"
            assert state["actual_dispersion_fit"] == fit_type, "unsupported actual trend"
            bundle = target/"fit.json"
            command = ["run","--counts",args.witness/spec["count_input"],"--samples",args.witness/spec["metadata_input"],"--bundle",bundle,"--threads",str(args.workers)]
            if args.low_df: command += ["--fit-type", "mean"]
            if spec["replacement"] == "disabled": command.append("--no-replace-outliers")
            if spec["route"] == "matrix":
                command += ["--design",oracle/"inputs/model-matrix.tsv"]
            else:
                command += ["--formula",spec["formula"]]
                used = set(re.findall(r"[A-Za-z][A-Za-z0-9_.]*",spec["formula"]))
                for name in spec["numeric_columns"]:
                    if name in used: command += ["--numeric",name]
                for name, levels in spec["factor_levels"].items():
                    if name in used: command += ["--factor",name+"="+",".join(levels)]
            for key, flag in [("size_factor_input","--size-factors"),("normalization_factor_input","--normalization-factors")]:
                if spec[key] is not None: command += [flag,args.witness/spec[key]]
            if args.reuse_from:
                original = args.reuse_from/spec["id"]/"fit.json"
                shutil.copyfile(original,bundle)
                commands.append({"reuse_bundle":str(original),"sha256":sha(original)})
            else:
                run(command+contrast("forward"))
            before = sha(bundle)
            fit = json.loads(bundle.read_text())
            exact("schema", fit["schema"], 4)
            exact("requested fit", fit["options"]["fit_type"], fit_type)
            exact("worker count",fit["workers"],args.workers)
            genes, samples = fit["dataset"]["counts"]["genes"],fit["dataset"]["counts"]["samples"]
            raw, rows = table(oracle/"inputs/model-matrix.tsv")
            exact("raw columns",fit["dataset"]["design"]["names"],raw[1:])
            exact("model sample IDs",samples,[r[0] for r in rows])
            exact("model matrix",fit["dataset"]["design"]["matrix"],[float(v) for r in rows for v in r[1:]])
            count_header, rows = table(args.witness/spec["count_input"])
            exact("count sample IDs",samples,count_header[1:])
            exact("count gene IDs",genes,[r[0] for r in rows])
            exact("counts",fit["dataset"]["counts"]["data"],[float(v) for r in rows for v in r[1:]])
            if spec["route"] == "formula":
                model = fit["dataset"]["design_source"]
                exact("formula origin",model["kind"],"formula")
                exact("formula",model["formula"],spec["formula"])
                exact("assign",model["assign"],spec["assign"])
                exact("coefficient names",model["coefficient_names"],state["coefficient_names"])
                terms_path = oracle/"inputs/terms-factors.tsv"
                if terms_path.exists():
                    header, rows = table(terms_path)
                    exact("formula variables",[v["name"] for v in model["variables"]],[r[0] for r in rows])
                    exact("term coding",model["term_coding"],[[int(float(row[j])) for row in rows] for j in range(1,len(header))])
            else:
                exact("matrix origin",fit["dataset"]["design_source"]["kind"],"matrix")
            exact("replacement disabled",fit["options"]["no_replace_outliers"],spec["replacement"] == "disabled")
            replacement = fit["replacement"]
            assessed = replacement["kind"] == "assessed"
            if spec["replacement"] == "disabled":
                exact("replacement lifecycle",replacement["kind"],"not_run")
            else:
                exact("replacement lifecycle",replacement["kind"],"assessed")
                source_eligible = state["cooks"]["replaceable_samples"]
                exact("replacement sample IDs",samples,list(source_eligible))
                exact("replacement eligibility",replacement["eligible"],[source_eligible[s] for s in samples])
                expected_assay = oracle/"fit/assay-replaceCounts.tsv"
                exact("replacement assay exists",replacement["counts"] is not None,expected_assay.exists())
                exact("originalCounts assay exists",replacement["original_counts_assay"],(oracle/"fit/assay-originalCounts.tsv").exists())
                if expected_assay.exists():
                    header, rows = table(expected_assay)
                    exact("replacement genes",genes,[r[0] for r in rows])
                    exact("replacement samples",samples,header[1:])
                    exact("replacement counts",replacement["counts"]["values"],[float(v) for r in rows for v in r[1:]])
                header, rows = table(oracle/"fit/assay-counts.tsv")
                exact("preserved original counts",fit["dataset"]["counts"]["data"],[float(v) for r in rows for v in r[1:]])
            norm = fit["dataset"]["normalization"]
            exact("normalization owner",norm["kind"],{"ratio":"ratio","sf":"supplied_size","nf":"supplied_matrix","sf-nf":"supplied_matrix"}[spec["normalization"]])
            if spec["normalization"] == "nf": exact("NF-only has no supplied SF",norm["size_factors"],None)
            if spec["normalization"] in ("ratio","sf","sf-nf"):
                _, rows = table(oracle/"fit/size-factors.tsv")
                sf = norm["size_factors"] if norm["kind"] == "supplied_matrix" else norm["factors"]
                exact("SF sample IDs",samples,[r[0] for r in rows])
                for a,r in zip(sf,rows): check("size factors",a,r[1],"normalization")
            if spec["normalization"] in ("nf","sf-nf"):
                _, rows = table(oracle/"fit/normalization-factors.tsv")
                exact("NF gene IDs",genes,[r[0] for r in rows])
                for a,e in zip(norm["factors"],[v for r in rows for v in r[1:]]): check("normalization factors",a,e,"normalization")
            for name in ["forward","reverse","mixed"]:
                if spec["contrasts"][name] is not None:
                    run(["results","--bundle",bundle,"--output",target/(name+".tsv"),*contrast(name)])
                    compare_tables(target/(name+".tsv"),oracle/("reload" if name == "reverse" else "results")/(name+".tsv"))
            for kind,name in [("normalized","normalized-counts.tsv"),("vst","vst.tsv")]:
                run(["transform","--bundle",bundle,"--output",target/name,"--kind",kind])
                compare_tables(target/name,oracle/"results"/name,"normalization" if kind == "normalized" else "vst")
            exact("bundle unchanged after reload",sha(bundle),before)
            trend = json.loads((oracle/"fit/dispersion-attributes.json").read_text())
            exact("actual trend", fit["dispersions"]["trend"]["kind"], fit_type)
            if args.low_df:
                check("mean trend", fit["dispersions"]["trend"]["alpha"], trend["mean"], "dispersion")
                df = len(samples)-fit["dataset"]["design"]["p"]
                prior = fit["dispersions"]["prior"]
                exact("prior residual df", prior["residual_df"], df)
                exact("prior method", prior["kind"], "fixed_reference" if df <= 3 else "analytic")
                if df <= 3:
                    qualification = oracle/"qualification"
                    source_prior = json.loads((qualification/"result.json").read_text())
                    exact("prior selected grid index", prior["selected_index"]+1, source_prior["source_replay_argmin_index"])
                    exact("observed histogram retained", prior["observed_retained"], source_prior["observed_retained"])
                    _, rows = table(qualification/"observed-histogram.tsv")
                    exact("observed histogram counts", prior["observed_counts"], [int(r[2]) for r in rows])
                    _, rows = table(qualification/"KL-grid.tsv")
                    exact("prior coarse grid", prior["coarse_variances"], [float(r[0]) for r in rows])
                    for field,column in [("small",2),("kl",4)]:
                        for a,r in zip(prior[field],rows): check("prior "+field,a,r[column],"diagnostic")
                    _, rows = table(qualification/"fine-predictions.tsv")
                    exact("prediction length",len(prior["prediction"]),len(rows))
                    for i,(a,r) in enumerate(zip(prior["prediction"],rows)):
                        if not math.isfinite(a) or abs(a-float(r[1])) > float(r[4]):
                            failures.append({"field":"prior prediction", "index":i,"actual":a,"expected":float(r[1]),"bound":float(r[4])})
            else:
                coefs = trend["coefficients"]
                if isinstance(coefs,dict): coefs = [coefs["asymptDisp"],coefs["extraPois"]]
                for key,value in zip(["a0","a1"],coefs): check("trend "+key,fit["dispersions"]["trend"][key],value,"dispersion")
            check("log dispersion variance",fit["dispersions"]["log_dispersion_variance"],trend["varLogDispEsts"],"dispersion")
            check("prior variance",fit["dispersions"]["prior_variance"],trend["dispPriorVar"],"dispersion")
            header, rows = table(oracle/"fit/row-diagnostics.tsv")
            exact("diagnostic IDs",genes,[r[0] for r in rows])
            source_base_means = [float(r[header.index("baseMean")]) for r in rows]
            p = len(raw)-1
            for g, values in enumerate(rows):
                expected = dict(zip(header,values)); gene = fit["genes"][g]; disp = fit["dispersions"]["genes"][g]
                if assessed:
                    refit = replacement["refits"][g]
                    exact("replace:"+genes[g],replacement["flags"][g],None if expected["replace"] == "NA" else expected["replace"] == "TRUE")
                    if refit["kind"] == "fitted":
                        gene,disp = refit["fit"],refit["dispersion"]
                    elif refit["kind"] == "zero" and refit["results_cleared"]:
                        gene = None
                    expected_refit = "unchanged" if replacement["flags"][g] != True else "zero" if expected["allZero"] == "TRUE" else "fitted"
                    exact("refit lifecycle:"+genes[g],refit["kind"],expected_refit)
                base = replacement if assessed else fit["dispersions"]
                exact("all-zero:"+genes[g],base["base_mean"][g] == 0,expected["allZero"] == "TRUE")
                for key,field in [("base_mean","baseMean"),("base_var","baseVar")]: check(field,base[key][g],expected[field],"normalization")
                for key,field in [("gene","dispGeneEst"),("fitted","dispFit"),("map","dispMAP"),("final_disp","dispersion")]: check(field,disp[key] if disp else None,expected[field],"dispersion")
                exact("dispOutlier:"+genes[g],disp["outlier"] if disp else None,None if expected["dispOutlier"] == "NA" else expected["dispOutlier"] == "TRUE")
                exact("betaConv:"+genes[g],gene["glm"]["converged"] if gene else None,None if expected["betaConv"] == "NA" else expected["betaConv"] == "TRUE")
                iterations.append({"gene":genes[g],"native":{"dispGeneIter":disp["gene_iterations"] if disp else None,"dispIter":disp["map_iterations"] if disp else None,"betaIter":gene["glm"]["iterations"] if gene else None},"source":{k:numeric(expected[k]) for k in ("dispGeneIter","dispIter","betaIter")}})
                check("deviance",-2*gene["glm"]["log_like"] if gene else None,expected["deviance"],"diagnostic")
                check("maxCooks",replacement["max_cooks"][g] if assessed else gene["max_cooks"] if gene else None,expected["maxCooks"],"diagnostic")
                for k,name in enumerate(state["coefficient_names"]):
                    beta = gene["glm"]["beta"][k]/math.log(2) if gene else None
                    se = math.sqrt(gene["glm"]["covariance"][k*p+k])/math.log(2) if gene else None
                    check(name,beta,expected[name],"coefficient")
                    check("SE_"+name,se,expected["SE_"+name],"coefficient")
                    check("WaldStatistic_"+name,beta/se if gene else None,expected["WaldStatistic_"+name],"coefficient")
                    check("WaldPvalue_"+name,math.erfc(abs(beta/se)/math.sqrt(2)) if gene else None,expected["WaldPvalue_"+name],"probability")
            for key,name,kind in [("raw_mu","mu","mu"),("hat","H","diagnostic"),("cooks","cooks","diagnostic")]:
                header, rows = table(oracle/"fit"/("assay-"+name+".tsv"))
                exact(name+" samples",header[1:],samples); exact(name+" genes",[r[0] for r in rows],genes)
                for gene,row in zip(fit["genes"],rows):
                    values = [None]*len(samples) if gene is None else gene["cooks"] if key == "cooks" else gene["glm"][key]
                    for a,e in zip(values,row[1:]): check(name,a,e,kind)
            if assessed and replacement["counts"] is not None:
                header, rows = table(oracle/"fit/assay-replaceCooks.tsv")
                exact("replaceCooks samples",header[1:],samples); exact("replaceCooks genes",[r[0] for r in rows],genes)
                for gene,row in zip(fit["genes"],rows):
                    for a,e in zip(gene["cooks"] if gene else [None]*len(samples),row[1:]): check("replaceCooks",a,e,"diagnostic")
            metadata = json.loads((oracle/"results/forward-metadata.json").read_text())
            result = fit["initial_results"]
            check("filter threshold",result["filter"]["threshold"],metadata["filterThreshold"],"normalization")
            selected = min(range(50),key=lambda k:abs(metadata["filterNumRej"][k]["theta"]-metadata["filterTheta"]))
            exact("filter selected",result["filter"]["selected"],selected)
            exact("filter rejections",result["filter"]["rejections"],[r["numRej"] for r in metadata["filterNumRej"]])
            for g,row in enumerate(result["rows"]):
                exact("filter retained:"+genes[g],row["retained"],source_base_means[g] >= metadata["filterThreshold"])
                exact("native filter retained:"+genes[g],row["retained"],row["base_mean"] >= result["filter"]["threshold"])
        except Exception as error:
            failures.append({"field":"workflow execution","error":str(error)})
        record = {"case":spec["id"],"passed":not failures,"failure_count":len(failures),"metrics":metrics}
        (target/"comparison.json").write_text(json.dumps(record,indent=2))
        (target/"failures.json").write_text(json.dumps(failures,indent=2))
        (target/"iteration-diagnostics.json").write_text(json.dumps(iterations,indent=2))
        summary.append({k:v for k,v in record.items() if k != "metrics"})
        print(json.dumps(summary[-1]),flush=True)
    (args.output/"summary.json").write_text(json.dumps({"passed":all(r["passed"] for r in summary),"cases":summary},indent=2))
    return 0 if all(r["passed"] for r in summary) else 1

if __name__ == "__main__":
    raise SystemExit(main())
