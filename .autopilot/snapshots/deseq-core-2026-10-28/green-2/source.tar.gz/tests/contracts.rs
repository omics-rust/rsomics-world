use rsomics_deseq::dataset::{Dataset, Design, contrast};

#[test]
fn design_identity_and_contrast_are_explicit() {
    let dir = tempfile::tempdir().unwrap();
    let counts = dir.path().join("counts.tsv");
    let samples = dir.path().join("samples.tsv");
    let design = dir.path().join("design.tsv");
    std::fs::write(&counts, "gene\ta\tb\tc\nd1\t10\t20\t30\n").unwrap();
    std::fs::write(&samples, "sample\ttype\nc\tC\na\tA\nb\tB\n").unwrap();
    std::fs::write(&design, "sample\tintercept\tx\nc\t1\t2\na\t1\t0\nb\t1\t1\n").unwrap();
    let data = Dataset::read(&counts, &samples, &design).unwrap();
    assert_eq!(data.metadata, vec![vec!["A"], vec!["B"], vec!["C"]]);
    assert_eq!(data.design.matrix, vec![1., 0., 1., 1., 1., 2.]);
    assert_eq!(
        contrast(&data.design, &["x=1".into(), "intercept=0".into()]).unwrap(),
        vec![0., 1.]
    );
    assert!(contrast(&data.design, &["x=1".into()]).is_err());
    assert!(
        contrast(
            &data.design,
            &["x=1".into(), "intercept=0".into(), "bogus=0".into()]
        )
        .is_err()
    );
    std::fs::write(&counts, "gene\ta\tb\tc\nd1\t1.5\t20\t30\n").unwrap();
    assert!(Dataset::read(&counts, &samples, &design).is_err());
}

#[test]
fn singular_and_nonfinite_designs_fail() {
    let mut design = Design {
        names: vec!["a".into(), "b".into()],
        matrix: vec![1., 1., 1., 1., 1., 1.],
        n_samples: 3,
        p: 2,
    };
    assert!(design.validate().is_err());
    design.matrix[1] = f64::NAN;
    assert!(design.validate().is_err());
}
