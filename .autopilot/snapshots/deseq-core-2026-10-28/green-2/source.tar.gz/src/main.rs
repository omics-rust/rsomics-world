fn main() -> std::process::ExitCode {
    rsomics_deseq::cli::run()
}
