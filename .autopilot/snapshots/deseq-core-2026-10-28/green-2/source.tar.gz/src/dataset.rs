use anyhow::{Context, Result, bail, ensure};
use nalgebra::DMatrix;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, HashSet},
    path::Path,
};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CountMatrix {
    pub genes: Vec<String>,
    pub samples: Vec<String>,
    pub data: Vec<f64>,
    pub n_genes: usize,
    pub n_samples: usize,
}

impl CountMatrix {
    pub fn row(&self, g: usize) -> &[f64] {
        &self.data[g * self.n_samples..(g + 1) * self.n_samples]
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Design {
    pub names: Vec<String>,
    pub matrix: Vec<f64>,
    pub n_samples: usize,
    pub p: usize,
}

impl Design {
    pub fn rowvec(&self, j: usize) -> &[f64] {
        &self.matrix[j * self.p..(j + 1) * self.p]
    }
    pub fn cells(&self) -> Vec<Vec<usize>> {
        let mut groups: Vec<Vec<usize>> = Vec::new();
        for j in 0..self.n_samples {
            if let Some(group) = groups
                .iter_mut()
                .find(|g| self.rowvec(g[0]) == self.rowvec(j))
            {
                group.push(j);
            } else {
                groups.push(vec![j]);
            }
        }
        groups
    }
    pub fn validate(&self) -> Result<()> {
        ensure!(
            self.p > 0 && self.n_samples > self.p,
            "design requires n > p > 0"
        );
        ensure!(
            Some(self.matrix.len()) == self.n_samples.checked_mul(self.p)
                && self.names.len() == self.p,
            "invalid design dimensions"
        );
        unique(&self.names, "coefficient")?;
        ensure!(
            self.matrix.iter().all(|x| x.is_finite()),
            "non-finite model matrix"
        );
        let x = DMatrix::from_row_slice(self.n_samples, self.p, &self.matrix);
        let svd = x.svd(false, false);
        let max = svd.singular_values.max();
        ensure!(
            svd.singular_values.iter().all(|s| *s > 1e-7 * max),
            "rank-deficient or ill-conditioned design"
        );
        Ok(())
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Dataset {
    pub counts: CountMatrix,
    pub design: Design,
    pub design_source: crate::design::DesignSource,
    pub normalization: crate::normalization::Normalization,
    pub metadata_columns: Vec<String>,
    pub metadata: Vec<Vec<String>>,
    pub input_sha256: BTreeMap<String, String>,
}

pub enum DesignInput<'a> {
    Matrix(&'a Path),
    Formula {
        formula: &'a str,
        numeric: &'a [String],
        factors: &'a [String],
    },
}

pub fn table(path: &Path) -> Result<(Vec<String>, Vec<Vec<String>>)> {
    let mut reader = csv::ReaderBuilder::new().delimiter(b'\t').from_path(path)?;
    let headers = reader
        .headers()?
        .iter()
        .map(|s| s.trim().to_owned())
        .collect::<Vec<_>>();
    ensure!(
        headers.len() >= 2,
        "{} needs an ID and data columns",
        path.display()
    );
    unique(&headers, "column")?;
    let rows = reader
        .records()
        .map(|r| r.map(|r| r.iter().map(|s| s.trim().to_owned()).collect()))
        .collect::<std::result::Result<Vec<Vec<String>>, _>>()?;
    ensure!(!rows.is_empty(), "{} has no data rows", path.display());
    unique(
        &rows.iter().map(|r| r[0].clone()).collect::<Vec<_>>(),
        "row",
    )?;
    Ok((headers, rows))
}

fn unique(names: &[String], kind: &str) -> Result<()> {
    let mut seen = HashSet::new();
    for name in names {
        ensure!(
            !name.is_empty() && seen.insert(name),
            "empty or duplicate {kind} identity: {name:?}"
        );
    }
    Ok(())
}

impl Dataset {
    pub fn read(counts_path: &Path, samples_path: &Path, design_path: &Path) -> Result<Self> {
        Self::read_inputs(
            counts_path,
            samples_path,
            DesignInput::Matrix(design_path),
            None,
            None,
        )
    }
    pub fn read_inputs(
        counts_path: &Path,
        samples_path: &Path,
        design_input: DesignInput<'_>,
        size_path: Option<&Path>,
        normalization_path: Option<&Path>,
    ) -> Result<Self> {
        let (ch, cr) = table(counts_path)?;
        let samples = ch[1..].to_vec();
        let mut data = Vec::new();
        for row in &cr {
            for value in &row[1..] {
                let value: u32 = value
                    .parse()
                    .with_context(|| format!("invalid nonnegative integer count in {}", row[0]))?;
                ensure!(
                    value <= i32::MAX as u32,
                    "count exceeds DESeq2 integer range"
                );
                data.push(f64::from(value));
            }
        }
        let (mh, mr) = table(samples_path)?;
        let join = |rows: Vec<Vec<String>>, label: &str| -> Result<Vec<Vec<String>>> {
            let mut map = rows
                .into_iter()
                .map(|r| (r[0].clone(), r[1..].to_vec()))
                .collect::<BTreeMap<_, _>>();
            let out = samples
                .iter()
                .map(|s| {
                    map.remove(s)
                        .with_context(|| format!("missing {label} sample {s}"))
                })
                .collect::<Result<Vec<_>>>()?;
            ensure!(
                map.is_empty(),
                "unexpected {label} sample identities: {:?}",
                map.keys()
            );
            Ok(out)
        };
        let metadata = join(mr, "metadata")?;
        let mut input_sha256 = BTreeMap::new();
        let (design, design_source) = match design_input {
            DesignInput::Matrix(design_path) => {
                let (dh, dr) = table(design_path)?;
                let matrix = join(dr, "design")?
                    .iter()
                    .flatten()
                    .map(|v| v.parse::<f64>().context("invalid numeric model matrix"))
                    .collect::<Result<Vec<_>>>()?;
                let design = Design {
                    p: dh.len() - 1,
                    names: dh[1..].to_vec(),
                    n_samples: samples.len(),
                    matrix,
                };
                design.validate()?;
                input_sha256.insert(
                    "design".to_owned(),
                    format!("{:x}", Sha256::digest(std::fs::read(design_path)?)),
                );
                (design, crate::design::DesignSource::Matrix)
            }
            DesignInput::Formula {
                formula,
                numeric,
                factors,
            } => crate::design::from_metadata(formula, numeric, factors, &mh[1..], &metadata)?,
        };
        for (label, path) in [("counts", counts_path), ("samples", samples_path)] {
            input_sha256.insert(
                label.to_owned(),
                format!("{:x}", Sha256::digest(std::fs::read(path)?)),
            );
        }
        let counts = CountMatrix {
            n_genes: cr.len(),
            n_samples: samples.len(),
            genes: cr.iter().map(|r| r[0].clone()).collect(),
            samples,
            data,
        };
        let normalization =
            crate::normalization::Normalization::read(&counts, size_path, normalization_path)?;
        for (label, path) in [
            ("size_factors", size_path),
            ("normalization_factors", normalization_path),
        ] {
            if let Some(path) = path {
                input_sha256.insert(
                    label.to_owned(),
                    format!("{:x}", Sha256::digest(std::fs::read(path)?)),
                );
            }
        }
        let dataset = Self {
            counts,
            design,
            design_source,
            normalization,
            metadata_columns: mh[1..].to_vec(),
            metadata,
            input_sha256,
        };
        dataset.validate()?;
        Ok(dataset)
    }
    pub fn validate(&self) -> Result<()> {
        let m = &self.counts;
        ensure!(
            m.n_genes > 0
                && m.n_genes == m.genes.len()
                && m.n_samples == m.samples.len()
                && Some(m.data.len()) == m.n_genes.checked_mul(m.n_samples),
            "invalid count dimensions"
        );
        unique(&m.genes, "gene")?;
        unique(&m.samples, "sample")?;
        ensure!(
            m.data
                .iter()
                .all(|x| x.is_finite() && *x >= 0.0 && *x <= i32::MAX as f64 && x.fract() == 0.0),
            "invalid integer counts"
        );
        ensure!(
            self.design.n_samples == m.n_samples && self.metadata.len() == m.n_samples,
            "unaligned dataset"
        );
        ensure!(
            self.metadata
                .iter()
                .all(|r| r.len() == self.metadata_columns.len()),
            "invalid metadata dimensions"
        );
        self.design.validate()?;
        self.design_source
            .validate(&self.design, &self.metadata_columns, &self.metadata)?;
        self.normalization.validate(m)
    }
}

pub fn contrast(design: &Design, terms: &[String]) -> Result<Vec<f64>> {
    let mut map = BTreeMap::new();
    for term in terms {
        let (name, value) = term
            .rsplit_once('=')
            .context("contrast terms must be NAME=WEIGHT")?;
        let weight: f64 = value.parse().context("invalid contrast weight")?;
        ensure!(
            weight.is_finite() && map.insert(name, weight).is_none(),
            "duplicate or nonfinite contrast term {name}"
        );
    }
    let mut result = Vec::new();
    for name in &design.names {
        result.push(map.remove(name.as_str()).with_context(|| {
            format!("contrast missing coefficient {name}; specify an explicit zero if excluded. Available raw model columns: {:?}", design.names)
        })?);
    }
    if !map.is_empty() {
        bail!("unknown contrast coefficients: {:?}", map.keys());
    }
    ensure!(
        result.iter().any(|v| *v != 0.0),
        "contrast cannot be all zero"
    );
    Ok(result)
}
