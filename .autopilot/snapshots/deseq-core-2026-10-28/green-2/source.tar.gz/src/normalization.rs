use crate::dataset::{CountMatrix, table};
use anyhow::{Context, Result, ensure};
use serde::{Deserialize, Serialize};
use std::{collections::BTreeMap, path::Path};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum Normalization {
    Ratio {
        factors: Vec<f64>,
    },
    SuppliedSize {
        factors: Vec<f64>,
    },
    SuppliedMatrix {
        factors: Vec<f64>,
        size_factors: Option<Vec<f64>>,
    },
}

impl Normalization {
    pub fn read(counts: &CountMatrix, size: Option<&Path>, matrix: Option<&Path>) -> Result<Self> {
        let sf = size
            .map(|path| -> Result<Vec<f64>> {
                let (header, rows) = table(path)?;
                ensure!(
                    header.len() == 2,
                    "size factors require sample and factor columns"
                );
                let mut values = rows
                    .into_iter()
                    .map(|r| (r[0].clone(), r[1].clone()))
                    .collect::<BTreeMap<_, _>>();
                let result = counts
                    .samples
                    .iter()
                    .map(|s| {
                        values
                            .remove(s)
                            .with_context(|| format!("missing size factor for {s}"))?
                            .parse::<f64>()
                            .context("invalid size factor")
                    })
                    .collect::<Result<Vec<_>>>()?;
                ensure!(
                    values.is_empty(),
                    "unexpected size factor sample identities"
                );
                Ok(result)
            })
            .transpose()?;
        let normalization = if let Some(path) = matrix {
            let (header, rows) = table(path)?;
            ensure!(
                header.len() == counts.n_samples + 1,
                "normalization matrix sample count mismatch"
            );
            let order = counts
                .samples
                .iter()
                .map(|s| {
                    header[1..]
                        .iter()
                        .position(|name| name == s)
                        .map(|j| j + 1)
                        .with_context(|| format!("missing normalization sample {s}"))
                })
                .collect::<Result<Vec<_>>>()?;
            let mut rows = rows
                .into_iter()
                .map(|r| (r[0].clone(), r))
                .collect::<BTreeMap<_, _>>();
            let mut factors = Vec::new();
            for gene in &counts.genes {
                let row = rows
                    .remove(gene)
                    .with_context(|| format!("missing normalization gene {gene}"))?;
                for j in &order {
                    factors.push(
                        row[*j]
                            .parse::<f64>()
                            .context("invalid normalization factor")?,
                    );
                }
            }
            ensure!(rows.is_empty(), "unexpected normalization gene identities");
            Self::SuppliedMatrix {
                factors,
                size_factors: sf,
            }
        } else if let Some(factors) = sf {
            Self::SuppliedSize { factors }
        } else {
            Self::Ratio {
                factors: crate::dispersion::size_factors(counts)?,
            }
        };
        normalization.validate(counts)?;
        Ok(normalization)
    }
    pub fn validate(&self, counts: &CountMatrix) -> Result<()> {
        let valid =
            |v: &[f64], len: usize| v.len() == len && v.iter().all(|x| x.is_finite() && *x > 0.0);
        ensure!(
            match self {
                Self::Ratio { factors } | Self::SuppliedSize { factors } =>
                    valid(factors, counts.n_samples),
                Self::SuppliedMatrix {
                    factors,
                    size_factors,
                } =>
                    valid(factors, counts.data.len())
                        && size_factors
                            .as_ref()
                            .is_none_or(|v| valid(v, counts.n_samples)),
            },
            "normalization factors must be finite, positive and identity-aligned"
        );
        Ok(())
    }
    pub fn row(&self, g: usize, n: usize) -> &[f64] {
        match self {
            Self::Ratio { factors } | Self::SuppliedSize { factors } => factors,
            Self::SuppliedMatrix { factors, .. } => &factors[g * n..(g + 1) * n],
        }
    }
    pub fn log_factors(&self, n: usize) -> LogFactors {
        let (values, per_gene) = match self {
            Self::Ratio { factors } | Self::SuppliedSize { factors } => (factors, false),
            Self::SuppliedMatrix { factors, .. } => (factors, true),
        };
        LogFactors {
            values: values.iter().map(|v| v.ln()).collect(),
            n,
            per_gene,
        }
    }
    pub fn moments_scale(&self, counts: &CountMatrix) -> f64 {
        match self {
            Self::Ratio { factors } | Self::SuppliedSize { factors } => {
                factors.iter().map(|v| 1.0 / v).sum::<f64>() / counts.n_samples as f64
            }
            Self::SuppliedMatrix { factors, .. } => {
                let nonzero = (0..counts.n_genes)
                    .filter(|g| counts.row(*g).iter().any(|y| *y != 0.0))
                    .collect::<Vec<_>>();
                (0..counts.n_samples)
                    .map(|j| {
                        nonzero.len() as f64
                            / nonzero
                                .iter()
                                .map(|g| factors[g * counts.n_samples + j])
                                .sum::<f64>()
                    })
                    .sum::<f64>()
                    / counts.n_samples as f64
            }
        }
    }
}

pub struct LogFactors {
    values: Vec<f64>,
    n: usize,
    per_gene: bool,
}
impl LogFactors {
    pub fn row(&self, g: usize) -> &[f64] {
        if self.per_gene {
            &self.values[g * self.n..(g + 1) * self.n]
        } else {
            &self.values
        }
    }
}
