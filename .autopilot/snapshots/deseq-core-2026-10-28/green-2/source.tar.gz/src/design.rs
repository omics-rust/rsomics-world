use crate::dataset::Design;
use anyhow::{Context, Result, bail, ensure};
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, HashSet};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum Variable {
    Numeric {
        name: String,
        values: Vec<f64>,
    },
    Factor {
        name: String,
        declared_levels: Vec<String>,
        levels: Vec<String>,
        values: Vec<usize>,
    },
}

impl Variable {
    fn name(&self) -> &str {
        match self {
            Self::Numeric { name, .. } | Self::Factor { name, .. } => name,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct FormulaModel {
    pub formula: String,
    pub variables: Vec<Variable>,
    pub intercept: bool,
    pub terms: Vec<Vec<usize>>,
    pub term_coding: Vec<Vec<u8>>,
    pub coding: Vec<Vec<u8>>,
    pub assign: Vec<usize>,
    pub coefficient_names: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum DesignSource {
    Matrix,
    Formula(FormulaModel),
}

impl DesignSource {
    pub fn intercept_shortcut(&self) -> bool {
        match self {
            Self::Matrix => true,
            Self::Formula(model) => {
                model
                    .formula
                    .chars()
                    .filter(|c| !c.is_whitespace())
                    .collect::<String>()
                    == "~1"
            }
        }
    }
    pub fn two_level_factor(&self) -> bool {
        matches!(self, Self::Formula(FormulaModel { variables, .. }) if matches!(variables.as_slice(), [Variable::Factor { levels, .. }] if levels.len() == 2))
    }
    pub fn validate(
        &self,
        design: &Design,
        columns: &[String],
        metadata: &[Vec<String>],
    ) -> Result<()> {
        if let Self::Formula(model) = self {
            let numeric = model
                .variables
                .iter()
                .filter_map(|v| match v {
                    Variable::Numeric { name, .. } => Some(name.clone()),
                    _ => None,
                })
                .collect::<Vec<_>>();
            let factors = model
                .variables
                .iter()
                .filter_map(|v| match v {
                    Variable::Factor {
                        name,
                        declared_levels,
                        ..
                    } => Some(format!("{name}={}", declared_levels.join(","))),
                    _ => None,
                })
                .collect::<Vec<_>>();
            let (actual, provenance) =
                from_metadata(&model.formula, &numeric, &factors, columns, metadata)?;
            ensure!(
                actual.names == design.names
                    && actual.matrix == design.matrix
                    && matches!(provenance, Self::Formula(actual) if actual == *model),
                "formula provenance does not match the stored design"
            );
        }
        Ok(())
    }
}

pub fn from_metadata(
    formula: &str,
    numeric: &[String],
    factors: &[String],
    columns: &[String],
    metadata: &[Vec<String>],
) -> Result<(Design, DesignSource)> {
    let mut declared = BTreeMap::new();
    for name in numeric {
        ensure!(
            declared.insert(name.clone(), None).is_none(),
            "duplicate variable declaration {name}"
        );
    }
    for declaration in factors {
        let (name, levels) = declaration
            .split_once('=')
            .context("factor must be NAME=LEVEL1,LEVEL2,...")?;
        let levels = levels.split(',').map(str::to_owned).collect::<Vec<_>>();
        ensure!(
            levels.len() >= 2 && levels.iter().all(|v| !v.is_empty() && v.is_ascii()),
            "factors require at least two nonempty ASCII levels"
        );
        ensure!(
            levels
                .iter()
                .map(|v| make_name(v))
                .collect::<HashSet<_>>()
                .len()
                == levels.len(),
            "factor levels collide after R name conversion"
        );
        ensure!(
            declared.insert(name.to_owned(), Some(levels)).is_none(),
            "duplicate variable declaration {name}"
        );
    }
    let parsed = Parser::parse(formula)?;
    let mut variables = Vec::new();
    for name in &parsed.variables {
        let levels = declared.remove(name).with_context(|| {
            format!("declare formula variable {name} with --numeric or --factor")
        })?;
        let column = columns
            .iter()
            .position(|s| s == name)
            .with_context(|| format!("missing metadata column {name}"))?;
        variables.push(if let Some(levels) = levels {
            let values = metadata
                .iter()
                .map(|r| {
                    levels
                        .iter()
                        .position(|v| v == &r[column])
                        .with_context(|| format!("unknown factor level {:?} for {name}", r[column]))
                })
                .collect::<Result<Vec<_>>>()?;
            let observed = (0..levels.len())
                .filter(|i| values.contains(i))
                .collect::<Vec<_>>();
            ensure!(
                observed.len() >= 2,
                "factor {name} has only one observed level; use ~1 or remove this variable"
            );
            let effective = observed.iter().map(|i| levels[*i].clone()).collect();
            let values = values
                .iter()
                .map(|i| {
                    observed
                        .iter()
                        .position(|j| j == i)
                        .expect("observed factor level")
                })
                .collect();
            Variable::Factor {
                name: name.clone(),
                declared_levels: levels,
                levels: effective,
                values,
            }
        } else {
            let values = metadata
                .iter()
                .map(|r| {
                    r[column]
                        .parse::<f64>()
                        .with_context(|| format!("invalid numeric value for {name}"))
                })
                .collect::<Result<Vec<_>>>()?;
            Variable::Numeric {
                name: name.clone(),
                values,
            }
        });
    }
    ensure!(
        declared.is_empty(),
        "declared variables absent from formula: {:?}",
        declared.keys()
    );
    if let [Variable::Numeric { values, .. }] = variables.as_slice() {
        ensure!(
            !values.iter().all(|v| *v == values[0]),
            "design has one constant variable; use ~1 instead"
        );
    }
    let (design, model) = compile(formula, variables, metadata.len())?;
    Ok((design, DesignSource::Formula(model)))
}

fn compile(formula: &str, variables: Vec<Variable>, n: usize) -> Result<(Design, FormulaModel)> {
    let parsed = Parser::parse(formula)?;
    ensure!(
        parsed.variables
            == variables
                .iter()
                .map(|v| v.name().to_owned())
                .collect::<Vec<_>>(),
        "invalid formula variable order"
    );
    for variable in &variables {
        match variable {
            Variable::Numeric { values, .. } => ensure!(
                values.len() == n && values.iter().all(|v| v.is_finite()),
                "invalid numeric formula column"
            ),
            Variable::Factor { levels, values, .. } => ensure!(
                levels.len() >= 2
                    && values.len() == n
                    && values.iter().all(|v| *v < levels.len())
                    && (0..levels.len()).all(|v| values.contains(&v)),
                "invalid factor formula column"
            ),
        }
    }
    let mut coding = parsed
        .terms
        .iter()
        .enumerate()
        .map(|(i, term)| {
            (0..variables.len())
                .map(|v| {
                    if !term.contains(&v) {
                        0
                    } else {
                        let remainder = term.iter().filter(|x| **x != v).collect::<Vec<_>>();
                        if remainder.is_empty()
                            || parsed.terms[..i]
                                .iter()
                                .any(|earlier| remainder.iter().all(|x| earlier.contains(x)))
                        {
                            1
                        } else {
                            2
                        }
                    }
                })
                .collect::<Vec<_>>()
        })
        .collect::<Vec<_>>();
    let term_coding = coding.clone();
    if !parsed.intercept {
        let first = coding.iter().enumerate().find_map(|(i, codes)| {
            codes
                .iter()
                .enumerate()
                .find(|(v, code)| **code > 0 && matches!(&variables[*v], Variable::Factor { .. }))
                .map(|(v, _)| (i, v))
        });
        if let Some((i, v)) = first {
            coding[i][v] = 2;
        }
    }
    let mut names = Vec::new();
    let mut cols = Vec::new();
    let mut assign = Vec::new();
    if parsed.intercept {
        names.push("(Intercept)".to_owned());
        cols.push(vec![1.0; n]);
        assign.push(0);
    }
    for (i, term) in parsed.terms.iter().enumerate() {
        let mut products = vec![(String::new(), vec![1.0; n])];
        for &v in term {
            let components = match &variables[v] {
                Variable::Numeric { name, values } => vec![(name.clone(), values.clone())],
                Variable::Factor {
                    name,
                    levels,
                    values,
                    ..
                } => (usize::from(coding[i][v] == 1)..levels.len())
                    .map(|k| {
                        (
                            format!("{name}{}", levels[k]),
                            values.iter().map(|j| f64::from(*j == k)).collect(),
                        )
                    })
                    .collect(),
            };
            products = components
                .into_iter()
                .flat_map(|(right, values)| {
                    products.iter().map(move |(left, prior)| {
                        (
                            if left.is_empty() {
                                right.clone()
                            } else {
                                format!("{left}:{right}")
                            },
                            prior
                                .iter()
                                .zip(&values)
                                .map(|(a, b)| a * b)
                                .collect::<Vec<_>>(),
                        )
                    })
                })
                .collect();
        }
        for (name, values) in products {
            names.push(name);
            cols.push(values);
            assign.push(i + 1);
        }
    }
    let mut coefficient_names = names
        .iter()
        .map(|name| {
            if name == "(Intercept)" {
                "Intercept".into()
            } else {
                make_name(name)
            }
        })
        .collect::<Vec<_>>();
    if parsed.intercept {
        for variable in &variables {
            if let Variable::Factor { name, levels, .. } = variable {
                for level in &levels[1..] {
                    let from = make_name(&format!("{name}{level}"));
                    if let Some(k) = coefficient_names.iter().position(|v| *v == from) {
                        coefficient_names[k] =
                            make_name(&format!("{name}_{level}_vs_{}", levels[0]));
                    }
                }
            }
        }
    }
    ensure!(
        coefficient_names.iter().collect::<HashSet<_>>().len() == coefficient_names.len(),
        "coefficient names collide after R name conversion"
    );
    let matrix = (0..n)
        .flat_map(|j| cols.iter().map(move |c| c[j]))
        .collect();
    let design = Design {
        p: names.len(),
        names,
        matrix,
        n_samples: n,
    };
    design.validate()?;
    Ok((
        design,
        FormulaModel {
            formula: formula.into(),
            variables,
            intercept: parsed.intercept,
            terms: parsed.terms,
            term_coding,
            coding,
            assign,
            coefficient_names,
        },
    ))
}

fn make_name(name: &str) -> String {
    let mut result = name
        .chars()
        .map(|c| {
            if c.is_ascii_alphanumeric() || c == '.' || c == '_' {
                c
            } else {
                '.'
            }
        })
        .collect::<String>();
    let bytes = result.as_bytes();
    if bytes.is_empty()
        || !(bytes[0].is_ascii_alphabetic()
            || (bytes[0] == b'.' && bytes.get(1).is_none_or(|c| !c.is_ascii_digit())))
    {
        result.insert(0, 'X');
    }
    if [
        "if",
        "else",
        "repeat",
        "while",
        "function",
        "for",
        "in",
        "next",
        "break",
        "TRUE",
        "FALSE",
        "NULL",
        "Inf",
        "NaN",
        "NA",
        "NA_integer_",
        "NA_real_",
        "NA_complex_",
        "NA_character_",
    ]
    .contains(&result.as_str())
    {
        result.push('.');
    }
    result
}

struct Parser {
    chars: Vec<char>,
    pos: usize,
    variables: Vec<String>,
    terms: Vec<Vec<usize>>,
    intercept: bool,
}

impl Parser {
    fn parse(formula: &str) -> Result<Self> {
        let rhs = formula
            .trim()
            .strip_prefix('~')
            .context("formula must begin with ~ and have no response")?;
        let mut previous = None;
        let mut separated = false;
        for c in rhs.chars() {
            if c.is_whitespace() {
                separated = true;
                continue;
            }
            let name_char = |c: char| c.is_ascii_alphanumeric() || c == '_' || c == '.';
            ensure!(
                !(separated && previous.is_some_and(name_char) && name_char(c)),
                "missing operator between formula tokens"
            );
            previous = Some(c);
            separated = false;
        }
        let mut parser = Self {
            chars: rhs.chars().filter(|c| !c.is_whitespace()).collect(),
            pos: 0,
            variables: Vec::new(),
            terms: Vec::new(),
            intercept: true,
        };
        let mut terms = parser.additive()?;
        ensure!(
            parser.pos == parser.chars.len(),
            "unsupported formula expression near character {}; use an explicit matrix",
            parser.pos + 1
        );
        terms.sort_by_key(Vec::len);
        parser.terms = terms;
        Ok(parser)
    }
    fn next(&self) -> Option<char> {
        self.chars.get(self.pos).copied()
    }
    fn additive(&mut self) -> Result<Vec<Vec<usize>>> {
        let mut terms = if self.next() == Some('-') {
            self.pos += 1;
            ensure!(
                self.next() == Some('1'),
                "only -1 intercept removal is supported"
            );
            self.pos += 1;
            self.intercept = false;
            Vec::new()
        } else {
            self.crossed()?
        };
        loop {
            match self.next() {
                Some('+') => {
                    self.pos += 1;
                    let added = self.crossed()?;
                    extend(&mut terms, added);
                }
                Some('-') => {
                    self.pos += 1;
                    ensure!(
                        self.next() == Some('1'),
                        "only -1 intercept removal is supported"
                    );
                    self.pos += 1;
                    self.intercept = false;
                }
                _ => return Ok(terms),
            }
        }
    }
    fn crossed(&mut self) -> Result<Vec<Vec<usize>>> {
        let mut left = self.interaction()?;
        while self.next() == Some('*') {
            self.pos += 1;
            let right = self.interaction()?;
            let crossed = multiply(&left, &right);
            extend(&mut left, right);
            extend(&mut left, crossed);
        }
        Ok(left)
    }
    fn interaction(&mut self) -> Result<Vec<Vec<usize>>> {
        let mut left = self.atom()?;
        while self.next() == Some(':') {
            self.pos += 1;
            left = multiply(&left, &self.atom()?);
        }
        Ok(left)
    }
    fn atom(&mut self) -> Result<Vec<Vec<usize>>> {
        match self.next() {
            Some('(') => {
                self.pos += 1;
                let terms = self.additive()?;
                ensure!(self.next() == Some(')'), "unclosed formula parentheses");
                self.pos += 1;
                Ok(terms)
            }
            Some('0' | '1') => {
                self.intercept = self.next() == Some('1');
                self.pos += 1;
                Ok(Vec::new())
            }
            Some(c) if c.is_ascii_alphabetic() || c == '.' => {
                let start = self.pos;
                while self
                    .next()
                    .is_some_and(|c| c.is_ascii_alphanumeric() || c == '_' || c == '.')
                {
                    self.pos += 1;
                }
                let name = self.chars[start..self.pos].iter().collect::<String>();
                ensure!(
                    name != "." && make_name(&name) == name,
                    "unsupported variable name {name}; use an explicit matrix"
                );
                let k = if let Some(k) = self.variables.iter().position(|s| *s == name) {
                    k
                } else {
                    self.variables.push(name);
                    self.variables.len() - 1
                };
                Ok(vec![vec![k]])
            }
            _ => bail!(
                "unsupported or incomplete formula expression; use an explicit matrix for functions, offsets, powers and non-syntactic names"
            ),
        }
    }
}

fn extend(terms: &mut Vec<Vec<usize>>, new: Vec<Vec<usize>>) {
    for term in new {
        if !terms.contains(&term) {
            terms.push(term);
        }
    }
}
fn multiply(left: &[Vec<usize>], right: &[Vec<usize>]) -> Vec<Vec<usize>> {
    let mut terms = Vec::new();
    for a in left {
        for b in right {
            let mut t = a.clone();
            t.extend(b);
            t.sort_unstable();
            t.dedup();
            extend(&mut terms, vec![t]);
        }
    }
    terms
}
