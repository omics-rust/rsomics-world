"""Exercise reload, complete named contrasts, rejection and output preservation."""
import argparse
import copy
import csv
import hashlib
import json
import math
import pathlib
import subprocess

parser=argparse.ArgumentParser()
parser.add_argument("--binary",type=pathlib.Path,required=True)
parser.add_argument("--bundle",type=pathlib.Path,required=True)
parser.add_argument("--output",type=pathlib.Path,required=True)
args=parser.parse_args()
args.output.mkdir(parents=True,exist_ok=True)
original=args.bundle.read_bytes()
fit=json.loads(original)
reports=[]
sentinel=args.output/"protected.tsv"
sentinel.write_text("preserve this pre-existing output\n")
protected=sentinel.read_bytes()

def execute(name,command,success):
    proc=subprocess.run([str(args.binary),"--json",*map(str,command)],capture_output=True,text=True)
    reports.append({"name":name,"argv":command,"exit":proc.returncode,"stdout":proc.stdout,"stderr":proc.stderr})
    assert (proc.returncode==0)==success,(name,proc.stdout,proc.stderr)
    assert sentinel.read_bytes()==protected,name+" changed the existing output"

base=["results","--bundle",args.bundle,"--output",sentinel]
execute("missing coefficient",base+["--contrast=conditiontreated=1"],False)
execute("unknown coefficient",base+["--contrast=(Intercept)=0","--contrast=typesingle-read=0","--contrast=conditiontreated=1","--contrast=unknown=0"],False)
execute("input output alias",["transform","--bundle",args.bundle,"--output",args.bundle,"--kind","vst"],False)
for name,mutate in [
    ("unsupported schema",lambda d:d.update(schema=999)),
    ("incomplete fit",lambda d:d.update(initial_results=None)),
    ("negative dispersion",lambda d:d["dispersions"]["genes"][0].update(final_disp=-1)),
    ("unconverged fit",lambda d:d["genes"][0]["glm"].update(converged=False)),
]:
    changed=copy.deepcopy(fit)
    mutate(changed)
    path=args.output/(name.replace(" ","-")+".json")
    path.write_text(json.dumps(changed))
    execute(name,["transform","--bundle",path,"--output",sentinel,"--kind","vst"],False)

mixed=args.output/"mixed-contrast.tsv"
execute("general covariance contrast",["results","--bundle",args.bundle,"--output",mixed,"--contrast=(Intercept)=0","--contrast=typesingle-read=1","--contrast=conditiontreated=-1"],True)
with mixed.open(newline="") as handle:
    rows=list(csv.DictReader(handle,delimiter="\t"))
checked=0
zeroed=[]
design=fit["dataset"]["design"]
counts=fit["dataset"]["counts"]
selected=[sum(design["matrix"][j*design["p"]+k] for k in (1,2))!=0 for j in range(counts["n_samples"])]
for g,(row,gene) in enumerate(zip(rows,fit["genes"])):
    if gene is None:
        assert row["log2FoldChange"]=="NA"
        continue
    glm=gene["glm"]
    estimate=(glm["beta"][1]-glm["beta"][2])/math.log(2)
    contrast_all_zero=all(counts["data"][g*counts["n_samples"]+j]==0 for j,keep in enumerate(selected) if keep)
    if contrast_all_zero:
        estimate=0.0
        zeroed.append(row["gene"])
        assert float(row["stat"])==0.0,row["gene"]
        expected_p="NA" if fit["initial_results"]["rows"][g]["reason"]=="cooks-outlier" else "1"
        assert row["pvalue"]==expected_p,(row["gene"],row["pvalue"],expected_p)
    covariance=glm["covariance"]
    se=math.sqrt(covariance[4]+covariance[8]-covariance[5]-covariance[7])/math.log(2)
    assert abs(float(row["log2FoldChange"])-estimate)<=1e-12*(1+abs(estimate))
    assert abs(float(row["lfcSE"])-se)<=1e-12*(1+abs(se))
    checked+=1
assert len(zeroed)==144,len(zeroed)
assert "FBgn0000216" in zeroed
assert args.bundle.read_bytes()==original,"reload commands modified the fitted bundle"
summary={"passed":True,"nonzero_general_contrasts_checked":checked,"contrast_all_zero_genes":zeroed,"unchanged_bundle_sha256":hashlib.sha256(original).hexdigest(),"commands":reports}
(args.output/"contract-report.json").write_text(json.dumps(summary,indent=2,default=str))
print(json.dumps({k:v for k,v in summary.items() if k!="commands"},indent=2))
