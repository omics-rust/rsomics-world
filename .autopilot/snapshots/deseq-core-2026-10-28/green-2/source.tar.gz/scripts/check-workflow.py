"""Complete fixed-witness comparison; no R or fitting through an oracle."""
import argparse
import csv
import hashlib
import json
import math
import pathlib
import subprocess
import time

BOUNDS = {
    "normalization": (1e-10, 1e-10),
    "dispersion": (1e-6, 1e-4),
    "coefficient": (1e-4, 1e-5),
    "probability": (1e-7, 1e-4),
    "mu": (1e-6, 1e-5),
    "diagnostic": (1e-6, 1e-4),
    "vst": (1e-5, 1e-6),
}

def table(path):
    with open(path, newline="") as handle:
        reader = csv.reader(handle, delimiter="\t")
        rows = [[v.strip() for v in row] for row in reader]
    return rows[0], rows[1:]

def numeric(value):
    return None if value in (None, "NA", "NaN") else float(value)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", type=pathlib.Path, required=True)
    parser.add_argument("--witness", type=pathlib.Path, required=True)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--reuse", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    manifest = {"bounds": BOUNDS, "binary_sha256": hashlib.sha256(args.binary.read_bytes()).hexdigest(), "workers": args.workers, "commands": []}
    (args.output/"comparison-contract.json").write_text(json.dumps(manifest, indent=2))
    def run(command):
        start = time.monotonic()
        proc = subprocess.run([str(args.binary), "--json", *map(str, command)], capture_output=True, text=True)
        manifest["commands"].append({"argv":command,"exit":proc.returncode,"seconds":time.monotonic()-start,"stdout":proc.stdout,"stderr":proc.stderr})
        (args.output/"commands.json").write_text(json.dumps(manifest, indent=2, default=str))
        if proc.returncode:
            raise RuntimeError(proc.stderr + proc.stdout)
    bundle = args.output/"fit.json"
    terms = ["--contrast=(Intercept)=0", "--contrast=typesingle-read=0", "--contrast=conditiontreated=1"]
    if not args.reuse:
        run(["run","--counts",args.witness/"inputs/counts.tsv","--samples",args.witness/"inputs/samples.tsv","--design",args.witness/"inputs/model-matrix.tsv","--bundle",bundle,"--threads",str(args.workers),*terms])
    before = hashlib.sha256(bundle.read_bytes()).hexdigest()
    run(["results","--bundle",bundle,"--output",args.output/"forward.tsv",*terms])
    run(["results","--bundle",bundle,"--output",args.output/"reverse.tsv",*terms[:-1],"--contrast=conditiontreated=-1"])
    run(["transform","--bundle",bundle,"--output",args.output/"normalized-counts.tsv","--kind","normalized"])
    run(["transform","--bundle",bundle,"--output",args.output/"vst.tsv","--kind","vst"])
    assert before == hashlib.sha256(bundle.read_bytes()).hexdigest(), "derived commands changed fitted state"
    fit = json.loads(bundle.read_text())
    genes = fit["dataset"]["counts"]["genes"]
    samples = fit["dataset"]["counts"]["samples"]
    failures = []
    metrics = {}
    def check(label, actual, expected, kind):
        actual, expected = numeric(actual), numeric(expected)
        item = metrics.setdefault(label, {"count":0,"failed":0,"max_abs":0.0,"max_scaled":0.0})
        item["count"] += 1
        if actual is None or expected is None:
            ok = actual is None and expected is None
        else:
            absolute, relative = BOUNDS[kind]
            error = abs(actual-expected)
            scaled = error/(absolute+relative*abs(expected))
            item["max_abs"] = max(item["max_abs"],error)
            item["max_scaled"] = max(item["max_scaled"],scaled)
            ok = math.isfinite(actual) and scaled <= 1
        if not ok:
            item["failed"] += 1
            failures.append({"field":label,"index":item["count"]-1,"actual":actual,"expected":expected})
    def exact(label,actual,expected):
        if actual != expected:
            failures.append({"field":label,"actual":actual,"expected":expected})
    _, factors = table(args.witness/"fit/size-factors.tsv")
    exact("factor sample order", [r[0] for r in factors], samples)
    for actual, expected in zip(fit["dataset"]["normalization"]["factors"], factors): check("size factor",actual,expected[1],"normalization")
    header, diagnostics = table(args.witness/"fit/row-diagnostics.tsv")
    exact("diagnostic gene order",[r[0] for r in diagnostics],genes)
    source_base_means = [float(r[header.index("baseMean")]) for r in diagnostics]
    coefficient_names = ["Intercept","type_single.read_vs_paired.end","condition_treated_vs_untreated"]
    for g, values in enumerate(diagnostics):
        source = dict(zip(header,values))
        dispersion = fit["dispersions"]["genes"][g]
        gene = fit["genes"][g]
        exact("allZero:"+genes[g],gene is None,source["allZero"]=="TRUE")
        check("baseMean",fit["dispersions"]["base_mean"][g],source["baseMean"],"normalization")
        check("baseVar",fit["dispersions"]["base_var"][g],source["baseVar"],"normalization")
        for key, field in [("gene","dispGeneEst"),("fitted","dispFit"),("map","dispMAP"),("final_disp","dispersion")]:
            check(field,dispersion[key] if dispersion else None,source[field],"dispersion")
        exact("dispOutlier:"+genes[g],dispersion["outlier"] if dispersion else None,None if source["dispOutlier"]=="NA" else source["dispOutlier"]=="TRUE")
        exact("betaConv:"+genes[g],gene["glm"]["converged"] if gene else None,None if source["betaConv"]=="NA" else source["betaConv"]=="TRUE")
        for k,name in enumerate(coefficient_names):
            beta = gene["glm"]["beta"][k]/math.log(2) if gene else None
            se = math.sqrt(gene["glm"]["covariance"][k*3+k])/math.log(2) if gene else None
            check(name,beta,source[name],"coefficient")
            check("SE_"+name,se,source["SE_"+name],"coefficient")
            check("WaldStatistic_"+name,beta/se if gene else None,source["WaldStatistic_"+name],"coefficient")
            check("WaldPvalue_"+name,math.erfc(abs(beta/se)/math.sqrt(2)) if gene else None,source["WaldPvalue_"+name],"probability")
        check("maxCooks",gene["max_cooks"] if gene else None,source["maxCooks"],"diagnostic")
    for native,source,kind in [("raw_mu","assay-mu.tsv","mu"),("hat","assay-H.tsv","diagnostic"),("cooks","assay-cooks.tsv","diagnostic")]:
        header, rows = table(args.witness/"fit"/source)
        exact(source+" samples",header[1:],samples)
        exact(source+" genes",[r[0] for r in rows],genes)
        for gene,row in zip(fit["genes"],rows):
            values = ([None]*len(samples) if gene is None else gene["cooks"] if native=="cooks" else gene["glm"][native])
            for a,e in zip(values,row[1:]): check(source,a,e,kind)
    for name,relative,kind in [("normalized-counts.tsv","results/normalized-counts.tsv","normalization"),("vst.tsv","results/vst.tsv","vst"),("forward.tsv","results/forward.tsv",None),("reverse.tsv","reload/reverse.tsv",None)]:
        header, rows = table(args.output/name)
        reference_header, reference_rows = table(args.witness/relative)
        exact(name+" header",header,reference_header)
        exact(name+" genes",[r[0] for r in rows],[r[0] for r in reference_rows])
        for row,reference in zip(rows,reference_rows):
            for field,a,e in zip(header[1:],row[1:],reference[1:]):
                bound = kind or ("normalization" if field=="baseMean" else "probability" if field in ("pvalue","padj") else "coefficient")
                check(name+":"+field,a,e,bound)
                if field=="padj": exact(name+" discovery:"+row[0],numeric(a) is not None and numeric(a)<0.1,numeric(e) is not None and numeric(e)<0.1)
    source_filter = json.loads((args.witness/"results/filter-and-result-metadata.json").read_text())
    result=fit["initial_results"]
    check("filterThreshold",result["filter"]["threshold"],source_filter["filterThreshold"],"normalization")
    exact("filter selected",result["filter"]["selected"],15)
    exact("filter rejections",result["filter"]["rejections"],[r["numRej"] for r in source_filter["filterNumRej"]])
    exact("padj missing",sum(r["padj"] is None for r in result["rows"]),5800)
    exact("discoveries",sum(r["padj"] is not None and r["padj"]<0.1 for r in result["rows"]),1330)
    exact("source counts",fit["dataset"]["counts"]["n_genes"],14599)
    exact("all-zero count",sum(g is None for g in fit["genes"]),2240)
    exact("dispersion outlier count",sum(d["outlier"] for d in fit["dispersions"]["genes"] if d),72)
    for i,row in enumerate(result["rows"]):
        exact("filter retention:"+genes[i],row["retained"],source_base_means[i]>=source_filter["filterThreshold"])
        exact("native filter retention:"+genes[i],row["retained"],row["base_mean"]>=result["filter"]["threshold"])
    summary={"passed":not failures,"failure_count":len(failures),"metrics":metrics,"bounds":BOUNDS,"bundle_sha256":before}
    (args.output/"comparison.json").write_text(json.dumps(summary,indent=2))
    (args.output/"failures.json").write_text(json.dumps(failures,indent=2))
    print(json.dumps(summary,indent=2))
    return 0 if not failures else 1

if __name__=="__main__":
    raise SystemExit(main())
