# rsomics-deseq — private checkpoint

This unpublished product owns a fitted count-analysis workflow, not a set of
independently recomputed statistical helpers. It is not release-ready.

`run` accepts integer counts, sample metadata, and exactly one of an explicit
named numeric `--design` matrix or a typed `--formula`. Sample rows are joined
by identifier. Every contrast coefficient
must be provided, including explicit zero weights. The fitted JSON bundle
retains original counts, metadata, model matrix, input hashes, normalization,
gene/trend/raw-MAP/final dispersions, full coefficient covariance, raw and
floored means, leverage, Cook's diagnostics, convergence and initial filtering.
All-zero genes have explicit absent fit state; their counts remain in exports.

`results` derives another contrast from that bundle. `transform --kind
normalized` exports normalized counts; `transform --kind vst` uses the fitted
parametric trend without refitting or blinding the design. Named outputs are
transactional through rsomics-common. `--json` uses the common process envelope.
Shared `--threads N` / `-t N` works before or after a subcommand. Omission uses
the available core count; explicit counts must be positive. The product owns
its worker pool and records the actual worker count in the fitted bundle.

The private checkpoint rejects residual degrees of freedom <= 3 and an unsuccessful
parametric trend. Default outlier replacement applies where a full-design cell
has at least 7 samples. `--no-replace-outliers` explicitly disables replacement
(`minReplicatesForReplace=Inf`); Cook's masking remains active. Formula-only
two-level-factor low-count Cook's exemptions survive bundle reload.
Nonparametric trends remain a release requirement, not a placeholder command.
Optimizer failures fail the command rather than writing
fake successful estimates.

## Typed designs and normalization

Formula syntax supports additive terms, `:`, `*`, parentheses, `~1` and
intercept removal with `0` or `-1`. Declare every used numeric variable with
`--numeric NAME` and every unordered factor with `--factor NAME=LEVEL1,LEVEL2,...`;
the first level is the reference. Formula variable names are ASCII R-syntactic
identifiers and factor level labels are ASCII. Functions, offsets, powers,
backticks, implicit `.` expansion and general term subtraction are rejected;
use an explicit matrix for other designs. Unused factor levels are dropped as
in source construction; both declared and effective ordered levels are saved.
Metadata values are never guessed to be factors.

For example, with group levels A/B and numeric x:

```sh
rsomics-deseq run --counts counts.tsv --samples samples.tsv \
  --formula '~group*x' --factor group=A,B --numeric x \
  --no-replace-outliers --bundle fit.json \
  '--contrast=(Intercept)=0' --contrast=groupB=0 --contrast=x=0 \
  --contrast=groupB:x=1
```

Contrasts always use raw model-matrix names, including `(Intercept)` and `:`.
Missing-coefficient errors list available columns. DESeq2 result-name aliases
are recorded separately, never silently matched. Terms use source ordering,
and factors use treatment or full indicator coding according to marginality
and the intercept. Formula origin and typed values are preserved in schema 3;
schemas 1 and 2 remain separate frozen checkpoints, not silently upgraded.

`--size-factors TSV` takes sample/factor rows. `--normalization-factors TSV`
takes a gene-by-sample positive numeric matrix. Both join by identities and
must contain finite, strictly positive factors. Values are not recentered.
NF overrides SF for every normalized count and fit offset; if both are supplied,
the original SF remains in provenance. With neither supplied, ratio factors
are estimated once. The bundle has one typed normalization owner, consumed by
dispersion estimation, Wald fitting, Cook's diagnostics and exports.

Schema 3 separates original fits and source-observable mu/H/Cook assays from
replacement eligibility, flags, saved replacement counts and refitted genes.
A flag can trigger a refit even if no eligible count changes. Refitting reuses
the original normalization, dispersion trend and prior; it does not estimate
them again. Source-conditional maximum-Cook clearing and replacement-to-zero
results survive reload. Normalized counts and VST still export original counts.
SF and NF replacement both truncate trimmed normalized mean times effective
factor. Ordinary NF and positive SF source cases do not constitute independent
NF-outlier fixture coverage.

The complete source witness and numeric tolerances are exercised by
`scripts/check-workflow.py`. The witness is external, not embedded in this
product or consulted by production code. Build and test with
`bash scripts/guarded-cargo.sh test`; its paths and APFS guard are specific to
the authorized development host.

## Source provenance

Behavior authority: DESeq2 1.52.0, commit
`16aeab6d6158bd8cbb8e98764c2f33399b1a3fd3`, particularly `R/core.R`,
`R/fitNbinomGLMs.R`, `R/results.R`, `R/vst.R`, and `src/DESeq2.cpp`.
Upstream is LGPL-3-or-later and is consulted as a behavior reference, not
included as vendored source. Cite Love MI, Huber W, Anders S (2014),
“Moderated estimation of fold change and dispersion for RNA-seq data with
DESeq2”, Genome Biology 15:550, doi:10.1186/s13059-014-0550-8.

Selected implementation assets are user-confirmed team-owned Rust:

| Asset | Revision | Reuse |
| --- | --- | --- |
| rsomics-deseq-sizefactors | 2aae52e2a4fc0d31d51c732d79f8dad38db7cf13 | ratio and median math |
| rsomics-deseq-lrt | a011348a0a61f20de84024b6ba59e56afc27c3a7 | dispersion posterior, gradient, Armijo/grid and trend kernels; refactored GLM seed |
| rsomics-deseq-estimate-dispersions | 30cfe948a68924b308d2cd61867fb194860fc4ca | rough/base dispersion statistics reference |
| rsomics-deseq-results | 94b1cea1e19f1e02fcf829a7f3cec7bb2f51dc5b | result and Cook's arithmetic reference; two-column design and approximate LOWESS rejected |
| rsomics-deseq-vst | 4178daad4d14b7bb4a3c6121b631464d35aeccef | parametric transform math |
| rsomics-voom | f51e528200ef16259f04451e1a33becc22932d57 | LOWESS/lowest kernel only, not trend interpolation or voom policy |

The median-of-ratios, NB GLM, dispersion and filtering policies remain private
product modules. No new public foundation APIs or Layer B dependencies exist.
BH adjustment uses the finite-value API of registry rsomics-stats 0.2.4 with
product-owned missing-value gather/scatter.

Bounded optimizer fallback uses registry `rcompat-lbfgsb =0.2.2` (MIT,
Denis Demin), with the released DESeq2 1.52 log2 objective, numeric gradient,
default R controls and original starting-value and leverage semantics.
The library's parity claims do not replace this product's fixed-witness tests.

Formula behavior references the official R
[model.matrix](https://stat.ethz.ch/R-manual/R-patched/library/stats/html/model.matrix.html),
[terms object](https://stat.ethz.ch/R-manual/R-patched/library/stats/html/terms.object.html)
and [formula](https://stat.ethz.ch/R-manual/R-patched/library/stats/html/formula.html)
contracts. R 4.6 branch model.c was consulted to resolve expansion order and
missing-lower-term coding semantics; no GPL implementation bodies are copied.
