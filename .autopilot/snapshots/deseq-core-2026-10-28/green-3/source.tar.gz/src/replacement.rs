use crate::{
    dispersion,
    fit::{self, FittedAnalysis, GeneFit},
};
use anyhow::{Result, ensure};
use serde::{Deserialize, Serialize};
use statrs::distribution::{ContinuousCDF, FisherSnedecor};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum Replacement {
    NotRun,
    Assessed(Box<Assessment>),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Assessment {
    pub cutoff: f64,
    pub eligible: Vec<bool>,
    pub flags: Vec<Option<bool>>,
    pub counts: Option<ReplacementCounts>,
    pub original_counts_assay: bool,
    pub base_mean: Vec<f64>,
    pub base_var: Vec<f64>,
    pub refits: Vec<Refit>,
    pub max_cooks: Vec<Option<f64>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReplacementCounts {
    pub values: Vec<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum Refit {
    Unchanged,
    Zero { results_cleared: bool },
    Fitted(Box<RefittedGene>),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RefittedGene {
    pub dispersion: dispersion::GeneDispersion,
    pub fit: GeneFit,
}

pub(crate) fn run(fit: &FittedAnalysis) -> Result<Replacement> {
    let dataset = &fit.dataset;
    let m = &dataset.counts;
    let n = m.n_samples;
    let mut eligible = vec![false; n];
    for cell in dataset.design.cells().iter().filter(|cell| cell.len() >= 7) {
        for &j in cell {
            eligible[j] = true;
        }
    }
    if fit.options.no_replace_outliers || !eligible.iter().any(|v| *v) {
        return Ok(Replacement::NotRun);
    }
    let cutoff = FisherSnedecor::new(dataset.design.p as f64, (n - dataset.design.p) as f64)?
        .inverse_cdf(0.99);
    let flags = fit
        .genes
        .iter()
        .map(|gene| gene.as_ref().map(|g| g.cooks.iter().any(|v| *v > cutoff)))
        .collect::<Vec<_>>();
    let any = flags.contains(&Some(true));
    let mut state = Assessment {
        cutoff,
        eligible,
        flags,
        counts: None,
        original_counts_assay: !any,
        base_mean: fit.dispersions.base_mean.clone(),
        base_var: fit.dispersions.base_var.clone(),
        refits: vec![Refit::Unchanged; m.n_genes],
        max_cooks: fit
            .genes
            .iter()
            .map(|g| g.as_ref().and_then(|g| g.max_cooks))
            .collect(),
    };
    if any {
        let mut counts = m.clone();
        let mut indices = Vec::new();
        for g in 0..m.n_genes {
            if state.flags[g] != Some(true) {
                continue;
            }
            let sf = dataset.normalization.row(g, n);
            let mut normalized = m
                .row(g)
                .iter()
                .zip(sf)
                .map(|(y, s)| y / s)
                .collect::<Vec<_>>();
            normalized.sort_by(f64::total_cmp);
            let cut = (n as f64 * 0.2).floor() as usize;
            let center = normalized[cut..n - cut].iter().sum::<f64>() / (n - 2 * cut) as f64;
            let original = fit.genes[g].as_ref().expect("flagged original fit exists");
            for (j, factor) in sf.iter().enumerate() {
                if state.eligible[j] && original.cooks[j] > cutoff {
                    let replacement = (center * factor).trunc();
                    ensure!(
                        replacement.is_finite() && replacement <= i32::MAX as f64,
                        "replacement count exceeds source integer range"
                    );
                    counts.data[g * n + j] = replacement;
                }
            }
            let normalized = counts
                .row(g)
                .iter()
                .zip(sf)
                .map(|(y, s)| y / s)
                .collect::<Vec<_>>();
            let mean = normalized.iter().sum::<f64>() / n as f64;
            state.base_mean[g] = mean;
            state.base_var[g] =
                normalized.iter().map(|v| (v - mean).powi(2)).sum::<f64>() / (n - 1) as f64;
            if mean == 0.0 {
                state.refits[g] = Refit::Zero {
                    results_cleared: false,
                };
            } else {
                indices.push(g);
            }
        }
        if !indices.is_empty() {
            let mut subset = dataset.clone();
            subset.counts.genes = indices.iter().map(|g| m.genes[*g].clone()).collect();
            subset.counts.data = indices
                .iter()
                .flat_map(|g| counts.row(*g).iter().copied())
                .collect();
            subset.counts.n_genes = indices.len();
            subset.normalization = dataset.normalization.subset(&indices, n);
            let dispersions = dispersion::estimate_with_prior(
                &subset.counts,
                &subset.design,
                &subset.normalization,
                Some(&fit.dispersions),
            )?;
            let genes = fit::fit_genes(&subset, &dispersions)?;
            for ((g, dispersion), gene) in indices.iter().zip(dispersions.genes).zip(genes) {
                state.refits[*g] = Refit::Fitted(Box::new(RefittedGene {
                    dispersion: dispersion.expect("nonzero refit dispersion"),
                    fit: gene.expect("nonzero refit GLM"),
                }));
            }
            for refit in &mut state.refits {
                if let Refit::Zero { results_cleared } = refit {
                    *results_cleared = true;
                }
            }
            let record = dataset
                .design
                .cells()
                .into_iter()
                .filter(|cell| cell.len() >= 3)
                .flatten()
                .collect::<Vec<_>>();
            state.max_cooks = fit
                .genes
                .iter()
                .map(|gene| {
                    if state.eligible.iter().all(|v| *v) {
                        None
                    } else {
                        record.iter().try_fold(0.0_f64, |maximum, &j| {
                            let value = if state.eligible[j] {
                                Some(0.0)
                            } else {
                                gene.as_ref().map(|gene| gene.cooks[j])
                            };
                            value.map(|value| maximum.max(value))
                        })
                    }
                })
                .collect();
        }
        state.counts = Some(ReplacementCounts {
            values: counts.data,
        });
    }
    Ok(Replacement::Assessed(Box::new(state)))
}

impl Replacement {
    pub fn refit(&self, g: usize) -> Option<&Refit> {
        match self {
            Self::NotRun => None,
            Self::Assessed(state) => Some(&state.refits[g]),
        }
    }
    pub(crate) fn validate(&self, fit: &FittedAnalysis) -> Result<()> {
        let m = &fit.dataset.counts;
        let required = !fit.options.no_replace_outliers
            && fit.dataset.design.cells().iter().any(|c| c.len() >= 7);
        ensure!(
            matches!(self, Self::Assessed(_)) == required,
            "inconsistent replacement lifecycle"
        );
        let Self::Assessed(state) = self else {
            return Ok(());
        };
        ensure!(
            state.eligible.len() == m.n_samples
                && state.flags.len() == m.n_genes
                && state.refits.len() == m.n_genes
                && state.base_mean.len() == m.n_genes
                && state.base_var.len() == m.n_genes
                && state.max_cooks.len() == m.n_genes,
            "incomplete replacement state"
        );
        ensure!(
            state.cutoff.is_finite()
                && state.cutoff > 0.0
                && state
                    .base_mean
                    .iter()
                    .chain(&state.base_var)
                    .all(|v| v.is_finite() && *v >= 0.0)
                && state
                    .max_cooks
                    .iter()
                    .all(|v| v.is_none_or(|v| v.is_finite() && v >= 0.0)),
            "invalid replacement diagnostics"
        );
        let any = state.flags.contains(&Some(true));
        let mut eligible = vec![false; m.n_samples];
        for cell in fit.dataset.design.cells().iter().filter(|c| c.len() >= 7) {
            for &j in cell {
                eligible[j] = true;
            }
        }
        ensure!(
            state.eligible == eligible,
            "inconsistent replacement eligibility"
        );
        ensure!(
            state.counts.is_some() == any && state.original_counts_assay != any,
            "inconsistent replacement assays"
        );
        if let Some(counts) = &state.counts {
            ensure!(
                counts.values.len() == m.data.len()
                    && counts.values.iter().all(|v| v.is_finite()
                        && *v >= 0.0
                        && v.fract() == 0.0
                        && *v <= i32::MAX as f64),
                "invalid replacement count assay"
            );
        }
        let any_refitted = state.refits.iter().any(|r| matches!(r, Refit::Fitted(_)));
        for g in 0..m.n_genes {
            ensure!(
                state.flags[g]
                    == fit.genes[g]
                        .as_ref()
                        .map(|gene| gene.cooks.iter().any(|v| *v > state.cutoff)),
                "invalid replacement flag"
            );
            ensure!(
                matches!(state.refits[g], Refit::Unchanged) == (state.flags[g] != Some(true)),
                "inconsistent gene refit lifecycle"
            );
            match &state.refits[g] {
                Refit::Zero { results_cleared } => ensure!(
                    state.base_mean[g] == 0.0
                        && *results_cleared == any_refitted
                        && state
                            .counts
                            .as_ref()
                            .is_some_and(|c| c.values[g * m.n_samples..(g + 1) * m.n_samples]
                                .iter()
                                .all(|v| *v == 0.0)),
                    "invalid replacement-to-zero state"
                ),
                Refit::Fitted(_) => {
                    ensure!(state.base_mean[g] > 0.0, "invalid nonzero refit state")
                }
                Refit::Unchanged => {}
            }
        }
        Ok(())
    }
}
