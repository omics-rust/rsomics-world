#![forbid(unsafe_code)]

pub mod artifact;
pub mod cli;
pub mod dataset;
pub mod dispersion;
pub mod fit;
pub mod glm;
mod lowess;
pub mod results;
