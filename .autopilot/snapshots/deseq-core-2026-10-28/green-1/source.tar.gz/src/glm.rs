use crate::dataset::Design;
use anyhow::{Context, Result, ensure};
use nalgebra::{DMatrix, DVector};
use serde::{Deserialize, Serialize};
use special::Gamma;

const LAMBDA: f64 = 1e-6 / (std::f64::consts::LN_2 * std::f64::consts::LN_2);

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GlmFit {
    pub beta: Vec<f64>,
    pub covariance: Vec<f64>,
    pub raw_mu: Vec<f64>,
    pub floored_mu: Vec<f64>,
    pub hat: Vec<f64>,
    pub iterations: usize,
    pub converged: bool,
    pub log_like: f64,
    pub optimizer: Option<OptimizerState>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OptimizerState {
    pub start: Vec<f64>,
    pub irls_beta: Vec<f64>,
    pub convergence: i32,
    pub message: String,
    pub function_evaluations: usize,
    pub gradient_evaluations: usize,
}

pub fn least_squares(x: DMatrix<f64>, y: &DVector<f64>) -> Result<DVector<f64>> {
    let qr = x.qr();
    let rhs = qr.q().transpose() * y;
    qr.r()
        .solve_upper_triangular(&rhs)
        .context("singular QR solve")
}

pub fn fit(y: &[f64], logsf: &[f64], design: &Design, alpha: f64) -> Result<GlmFit> {
    if design.p == 1 && design.matrix.iter().all(|x| *x == 1.0) {
        let mean = y.iter().zip(logsf).map(|(y, s)| y / s.exp()).sum::<f64>() / y.len() as f64;
        ensure!(mean > 0.0, "all-zero rows have no coefficient fit");
        let beta_log2 = mean.log2();
        let raw_mu = logsf
            .iter()
            .map(|s| s.exp() * 2.0_f64.powf(beta_log2))
            .collect::<Vec<_>>();
        let weights = raw_mu
            .iter()
            .map(|mu| 1.0 / (1.0 / mu + alpha))
            .collect::<Vec<_>>();
        let information = weights.iter().sum::<f64>();
        return Ok(GlmFit {
            beta: vec![beta_log2 * std::f64::consts::LN_2],
            covariance: vec![1.0 / information],
            hat: weights.iter().map(|w| w / information).collect(),
            log_like: y
                .iter()
                .zip(&raw_mu)
                .map(|(&y, &mu)| nb_lpmf(y, mu, 1.0 / alpha))
                .sum(),
            floored_mu: raw_mu.iter().map(|mu| mu.max(0.5)).collect(),
            raw_mu,
            iterations: 1,
            converged: true,
            optimizer: None,
        });
    }
    let mut fit = irls(y, logsf, design, alpha)?;
    if fit.converged {
        return Ok(fit);
    }
    let p = design.p;
    let log2_beta = fit
        .beta
        .iter()
        .map(|b| b / std::f64::consts::LN_2)
        .collect::<Vec<_>>();
    let start = if log2_beta.iter().all(|b| b.abs() < 30.0) {
        log2_beta
    } else {
        let x = DMatrix::from_row_slice(design.n_samples, p, &design.matrix);
        let z = DVector::from_iterator(
            design.n_samples,
            y.iter().zip(logsf).map(|(y, s)| (y / s.exp() + 0.1).ln()),
        );
        least_squares(x, &z)?.as_slice().to_vec()
    };
    let objective = |beta: &[f64]| {
        let mut value = 0.0;
        for (j, &count) in y.iter().enumerate() {
            let eta = design
                .rowvec(j)
                .iter()
                .zip(beta)
                .map(|(x, b)| x * b)
                .sum::<f64>();
            let mu = logsf[j].exp() * 2.0_f64.powf(eta);
            value -= nb_lpmf(count, mu, 1.0 / alpha);
        }
        value += beta
            .iter()
            .map(|b| 0.5 * 1e-6 * b * b + 0.5 * (2.0 * std::f64::consts::PI * 1e6).ln())
            .sum::<f64>();
        if value.is_finite() { value } else { 1e300 }
    };
    let optimized = rcompat_lbfgsb::optim_lbfgsb(
        start.clone(),
        rcompat_lbfgsb::Bounds::new(vec![-30.0; p], vec![30.0; p])?,
        objective,
        rcompat_lbfgsb::OptimControl::default_for_dimension(p),
    )?;
    ensure!(
        optimized.convergence == 0,
        "L-BFGS-B failed ({}): {}",
        optimized.convergence,
        optimized.message
    );
    fit.optimizer = Some(OptimizerState {
        start,
        irls_beta: fit.beta.clone(),
        convergence: optimized.convergence,
        message: optimized.message,
        function_evaluations: optimized.counts.function,
        gradient_evaluations: optimized.counts.gradient,
    });
    fit.beta = optimized
        .par
        .iter()
        .map(|b| b * std::f64::consts::LN_2)
        .collect();
    fit.raw_mu = (0..design.n_samples)
        .map(|j| {
            logsf[j].exp()
                * 2.0_f64.powf(
                    design
                        .rowvec(j)
                        .iter()
                        .zip(&optimized.par)
                        .map(|(x, b)| x * b)
                        .sum::<f64>(),
                )
        })
        .collect();
    fit.floored_mu = fit.raw_mu.iter().map(|m| m.max(0.5)).collect();
    fit.covariance = covariance(&fit.floored_mu, design, alpha)?.0;
    fit.log_like = y
        .iter()
        .zip(&fit.floored_mu)
        .map(|(&y, &mu)| nb_lpmf(y, mu, 1.0 / alpha))
        .sum();
    fit.converged = true;
    Ok(fit)
}

pub fn irls(y: &[f64], logsf: &[f64], design: &Design, alpha: f64) -> Result<GlmFit> {
    let n = design.n_samples;
    let p = design.p;
    ensure!(alpha.is_finite() && alpha > 0.0, "invalid GLM dispersion");
    let x = DMatrix::from_row_slice(n, p, &design.matrix);
    let z = DVector::from_iterator(
        n,
        y.iter().zip(logsf).map(|(y, s)| (y / s.exp() + 0.1).ln()),
    );
    let mut beta = least_squares(x.clone(), &z)?;
    let mut mu = means(&beta, design, logsf)
        .iter()
        .map(|m| m.max(0.5))
        .collect::<Vec<_>>();
    let mut old_dev = 0.0;
    let mut iterations = 0;
    let mut converged = false;
    for t in 0..100 {
        iterations = t + 1;
        let mut augmented = DMatrix::zeros(n + p, p);
        let mut response = DVector::zeros(n + p);
        for j in 0..n {
            let root_w = (mu[j] / (1.0 + alpha * mu[j])).sqrt();
            response[j] = ((mu[j] / logsf[j].exp()).ln() + (y[j] - mu[j]) / mu[j]) * root_w;
            for k in 0..p {
                augmented[(j, k)] = x[(j, k)] * root_w;
            }
        }
        for k in 0..p {
            augmented[(n + k, k)] = LAMBDA.sqrt();
        }
        beta = least_squares(augmented, &response)?;
        ensure!(
            beta.iter().all(|b| b.is_finite()),
            "nonfinite IRLS coefficients"
        );
        if beta.iter().any(|b| b.abs() > 30.0) {
            iterations = 100;
            break;
        }
        mu = means(&beta, design, logsf)
            .iter()
            .map(|m| m.max(0.5))
            .collect();
        let dev = -2.0
            * y.iter()
                .zip(&mu)
                .map(|(&y, &m)| nb_lpmf(y, m, 1.0 / alpha))
                .sum::<f64>();
        let change = (dev - old_dev).abs() / (dev.abs() + 0.1);
        ensure!(change.is_finite(), "non-finite GLM deviance");
        if t > 0 && change < 1e-8 {
            converged = true;
            break;
        }
        old_dev = dev;
    }
    converged &= iterations < 100;
    let (covariance, hat) = covariance(&mu, design, alpha)?;
    let raw_mu = means(&beta, design, logsf);
    let log_like = y
        .iter()
        .zip(&raw_mu)
        .map(|(&y, &m)| nb_lpmf(y, m, 1.0 / alpha))
        .sum();
    Ok(GlmFit {
        beta: beta.as_slice().to_vec(),
        covariance,
        raw_mu,
        floored_mu: mu,
        hat,
        iterations,
        converged,
        log_like,
        optimizer: None,
    })
}

pub(crate) fn covariance(mu: &[f64], design: &Design, alpha: f64) -> Result<(Vec<f64>, Vec<f64>)> {
    let n = design.n_samples;
    let p = design.p;
    let x = DMatrix::from_row_slice(n, p, &design.matrix);
    let w = mu.iter().map(|m| m / (1.0 + alpha * m)).collect::<Vec<_>>();
    let mut xwx = DMatrix::zeros(p, p);
    for j in 0..n {
        for a in 0..p {
            for b in 0..p {
                xwx[(a, b)] += w[j] * x[(j, a)] * x[(j, b)];
            }
        }
    }
    let inv = (&xwx + DMatrix::identity(p, p) * LAMBDA)
        .try_inverse()
        .context("singular GLM covariance")?;
    let sigma = &inv * &xwx * &inv;
    let mut hat = vec![0.0; n];
    for j in 0..n {
        for a in 0..p {
            for b in 0..p {
                hat[j] += w[j] * x[(j, a)] * x[(j, b)] * inv[(b, a)];
            }
        }
    }
    let covariance = (0..p)
        .flat_map(|a| (0..p).map(move |b| (a, b)))
        .map(|(a, b)| sigma[(a, b)])
        .collect::<Vec<_>>();
    ensure!(
        (0..p).all(|k| covariance[k * p + k].is_finite() && covariance[k * p + k] > 0.0),
        "non-positive GLM coefficient variance"
    );
    Ok((covariance, hat))
}

fn means(beta: &DVector<f64>, design: &Design, logsf: &[f64]) -> Vec<f64> {
    (0..design.n_samples)
        .map(|j| {
            (logsf[j]
                + design
                    .rowvec(j)
                    .iter()
                    .zip(beta)
                    .map(|(x, b)| x * b)
                    .sum::<f64>())
            .exp()
        })
        .collect()
}

fn nb_lpmf(y: f64, mu: f64, size: f64) -> f64 {
    if y == 0.0 {
        return -size * (mu / size).ln_1p();
    }
    let total = size + y;
    let expected_size = total * (size / (size + mu));
    let expected_y = total * (mu / (size + mu));
    stirling_error(total)
        - stirling_error(size)
        - stirling_error(y)
        - deviance_part(size, expected_size)
        - deviance_part(y, expected_y)
        + 0.5 * ((size / total).ln() - y.ln() - (2.0 * std::f64::consts::PI).ln())
}

fn stirling_error(x: f64) -> f64 {
    if x < 10.0 {
        return Gamma::ln_gamma(x).0 - (x - 0.5) * x.ln() + x
            - 0.5 * (2.0 * std::f64::consts::PI).ln();
    }
    let inverse = 1.0 / x;
    let square = inverse * inverse;
    inverse
        * (1.0 / 12.0
            - square
                * (1.0 / 360.0
                    - square
                        * (1.0 / 1260.0
                            - square
                                * (1.0 / 1680.0
                                    - square
                                        * (1.0 / 1188.0
                                            - square
                                                * (691.0 / 360360.0 - square * (1.0 / 156.0)))))))
}

fn deviance_part(x: f64, mean: f64) -> f64 {
    if (x - mean).abs() < 0.1 * (x + mean) {
        let v = (x - mean) / (x + mean);
        let mut sum = (x - mean) * v;
        let mut term = 2.0 * x * v;
        for j in 1..1000 {
            term *= v * v;
            let next = sum + term / (2 * j + 1) as f64;
            if next == sum {
                return sum;
            }
            sum = next;
        }
        sum
    } else {
        x * (x / mean).ln() + mean - x
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn negative_binomial_mass_and_poisson_limit() {
        assert!((nb_lpmf(0.0, 2.0, 3.0) - (0.6_f64).ln() * 3.0).abs() < 1e-14);
        assert!(
            (nb_lpmf(5.0, 5.0, 1e12) - (-5.0 + 5.0 * 5.0_f64.ln() - Gamma::ln_gamma(6.0).0)).abs()
                < 1e-10
        );
        let total = (0..1000)
            .map(|y| nb_lpmf(y as f64, 20.0, 0.5).exp())
            .sum::<f64>();
        assert!((total - 1.0).abs() < 1e-10);
    }

    #[test]
    fn intercept_only_uses_the_source_closed_form() {
        let design = Design {
            names: vec!["intercept".into()],
            matrix: vec![1.0; 5],
            n_samples: 5,
            p: 1,
        };
        let fitted = fit(&[0., 1., 3., 5., 7.], &[0.; 5], &design, 0.2).unwrap();
        assert_eq!(fitted.iterations, 1);
        assert!((fitted.beta[0] / std::f64::consts::LN_2 - 3.2_f64.log2()).abs() < 1e-15);
        assert!(fitted.hat.iter().all(|h| (*h - 0.2).abs() < 1e-15));
    }
}
