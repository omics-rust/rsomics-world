use crate::{artifact, dataset, fit, results};
use clap::{Args, Parser, Subcommand, ValueEnum};
use rsomics_common::{OutputArgs, RsomicsError, ToolMeta};
use std::path::PathBuf;

#[derive(Debug, Parser)]
#[command(
    name = "rsomics-deseq",
    version,
    about = "Private DESeq2 fitted-workflow checkpoint",
    arg_required_else_help = true
)]
struct Cli {
    #[command(flatten)]
    output: OutputArgs,
    #[command(subcommand)]
    command: Command,
}

#[derive(Debug, Subcommand)]
enum Command {
    /// Fit integer counts using an identity-joined named numeric design
    Run(Run),
    /// Derive a named contrast from a saved fit without refitting
    Results(Derive),
    /// Export normalized counts or design-aware VST using a saved fit
    Transform(Transform),
}

#[derive(Debug, Args)]
struct Contrast {
    /// One NAME=WEIGHT per coefficient; explicitly include zero weights
    #[arg(long = "contrast", required = true)]
    terms: Vec<String>,
    #[arg(long, default_value_t = 0.1)]
    alpha: f64,
}

#[derive(Debug, Args)]
struct Run {
    #[arg(long)]
    counts: PathBuf,
    #[arg(long)]
    samples: PathBuf,
    #[arg(long)]
    design: PathBuf,
    #[arg(long)]
    bundle: PathBuf,
    #[arg(long, default_value_t = 1)]
    workers: usize,
    #[command(flatten)]
    contrast: Contrast,
}

#[derive(Debug, Args)]
struct Derive {
    #[arg(long)]
    bundle: PathBuf,
    #[arg(long)]
    output: PathBuf,
    #[command(flatten)]
    contrast: Contrast,
}

#[derive(Debug, Clone, Copy, ValueEnum)]
enum Kind {
    Normalized,
    Vst,
}

#[derive(Debug, Args)]
struct Transform {
    #[arg(long)]
    bundle: PathBuf,
    #[arg(long)]
    output: PathBuf,
    #[arg(long, value_enum)]
    kind: Kind,
}

pub fn run() -> std::process::ExitCode {
    let cli = rsomics_help::parse::<Cli>();
    rsomics_common::run(
        &cli.output,
        ToolMeta {
            name: "rsomics-deseq",
            version: env!("CARGO_PKG_VERSION"),
        },
        || execute(cli.command).map_err(process_error),
    )
}

pub(crate) fn process_error(error: anyhow::Error) -> RsomicsError {
    let error = match error.downcast::<RsomicsError>() {
        Ok(error) => return error,
        Err(error) => error,
    };
    let error = match error.downcast::<serde_json::Error>() {
        Ok(error) => return json_error(error),
        Err(error) => error,
    };
    if let Some(io) = error.downcast_ref::<std::io::Error>() {
        return RsomicsError::Io(std::io::Error::new(io.kind(), format!("{error:#}")));
    }
    if let Some(csv) = error.downcast_ref::<csv::Error>()
        && let csv::ErrorKind::Io(io) = csv.kind()
    {
        return RsomicsError::Io(std::io::Error::new(io.kind(), format!("{error:#}")));
    }
    RsomicsError::InvalidInput(format!("{error:#}"))
}

pub(crate) fn json_error(error: serde_json::Error) -> RsomicsError {
    if error.is_io() {
        RsomicsError::Io(error.into())
    } else {
        RsomicsError::InvalidInput(error.to_string())
    }
}

fn execute(command: Command) -> anyhow::Result<serde_json::Value> {
    match command {
        Command::Run(args) => {
            rsomics_common::reject_output_alias(
                &args.bundle,
                [
                    args.counts.as_path(),
                    args.samples.as_path(),
                    args.design.as_path(),
                ],
            )?;
            let data = dataset::Dataset::read(&args.counts, &args.samples, &args.design)?;
            let contrast = dataset::contrast(&data.design, &args.contrast.terms)?;
            let mut fitted = fit::run(data, args.workers)?;
            fitted.initial_results =
                Some(results::derive(&fitted, &contrast, args.contrast.alpha)?);
            artifact::save(&args.bundle, &fitted)?;
            Ok(
                serde_json::json!({"bundle":args.bundle,"genes":fitted.genes.len(),"workers":args.workers}),
            )
        }
        Command::Results(args) => {
            rsomics_common::reject_output_alias(&args.output, [args.bundle.as_path()])?;
            let fit = artifact::load(&args.bundle)?;
            let contrast = dataset::contrast(&fit.dataset.design, &args.contrast.terms)?;
            let result = results::derive(&fit, &contrast, args.contrast.alpha)?;
            artifact::results(&args.output, &fit, &result)?;
            Ok(
                serde_json::json!({"output":args.output,"refit":false,"filter_threshold":result.filter.threshold}),
            )
        }
        Command::Transform(args) => {
            rsomics_common::reject_output_alias(&args.output, [args.bundle.as_path()])?;
            let fit = artifact::load(&args.bundle)?;
            artifact::transform(&args.output, &fit, matches!(args.kind, Kind::Vst))?;
            Ok(serde_json::json!({"output":args.output,"refit":false}))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use clap::CommandFactory;
    #[test]
    fn help_tree_is_valid() {
        Cli::command().debug_assert();
    }

    #[test]
    fn json_reader_writer_errors_keep_io_class() {
        struct FailingIo;
        impl std::io::Read for FailingIo {
            fn read(&mut self, _: &mut [u8]) -> std::io::Result<usize> {
                Err(std::io::Error::new(
                    std::io::ErrorKind::PermissionDenied,
                    "reader failure",
                ))
            }
        }
        impl std::io::Write for FailingIo {
            fn write(&mut self, _: &[u8]) -> std::io::Result<usize> {
                Err(std::io::Error::new(
                    std::io::ErrorKind::BrokenPipe,
                    "writer failure",
                ))
            }
            fn flush(&mut self) -> std::io::Result<()> {
                Ok(())
            }
        }
        let read = serde_json::from_reader::<_, serde_json::Value>(FailingIo).unwrap_err();
        assert!(
            matches!(process_error(read.into()), RsomicsError::Io(e) if e.kind() == std::io::ErrorKind::PermissionDenied && e.to_string().contains("reader failure"))
        );
        for write in [
            serde_json::to_writer(FailingIo, &42),
            serde_json::to_writer_pretty(FailingIo, &42),
        ] {
            assert!(
                matches!(json_error(write.unwrap_err()), RsomicsError::Io(e) if e.kind() == std::io::ErrorKind::BrokenPipe && e.to_string().contains("writer failure"))
            );
        }
        let malformed = serde_json::from_slice::<serde_json::Value>(b"{").unwrap_err();
        assert!(matches!(
            process_error(malformed.into()),
            RsomicsError::InvalidInput(_)
        ));
    }
}
