use crate::{fit::FittedAnalysis, lowess};
use anyhow::{Result, ensure};
use serde::{Deserialize, Serialize};
use statrs::{
    distribution::{ContinuousCDF, FisherSnedecor},
    function::erf::erfc,
};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResultRow {
    pub base_mean: f64,
    pub log2_fold_change: Option<f64>,
    pub lfc_se: Option<f64>,
    pub stat: Option<f64>,
    pub pvalue: Option<f64>,
    pub padj: Option<f64>,
    pub reason: Option<String>,
    pub retained: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Filter {
    pub threshold: f64,
    pub theta: Vec<f64>,
    pub cutoffs: Vec<f64>,
    pub rejections: Vec<f64>,
    pub lowess: Vec<f64>,
    pub selected: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Results {
    pub contrast: Vec<f64>,
    pub alpha: f64,
    pub rows: Vec<ResultRow>,
    pub filter: Filter,
}

pub fn derive(fit: &FittedAnalysis, contrast: &[f64], alpha: f64) -> Result<Results> {
    fit.validate()?;
    let p = fit.dataset.design.p;
    let n = fit.dataset.counts.n_samples;
    ensure!(
        contrast.len() == p
            && contrast.iter().all(|c| c.is_finite())
            && contrast.iter().any(|c| *c != 0.0),
        "invalid contrast"
    );
    ensure!(
        alpha > 0.0 && alpha < 1.0,
        "alpha must lie strictly between zero and one"
    );
    let cutoff = FisherSnedecor::new(p as f64, (n - p) as f64)?.inverse_cdf(0.99);
    let mixed_sign = contrast.iter().any(|c| *c < 0.0) && contrast.iter().any(|c| *c > 0.0);
    let selected_samples = (0..n)
        .filter(|j| {
            fit.dataset
                .design
                .rowvec(*j)
                .iter()
                .zip(contrast)
                .filter(|(_, c)| **c != 0.0)
                .map(|(x, _)| *x)
                .sum::<f64>()
                != 0.0
        })
        .collect::<Vec<_>>();
    let mut rows = Vec::new();
    for (g, gene) in fit.genes.iter().enumerate() {
        let mut row = ResultRow {
            base_mean: fit.dispersions.base_mean[g],
            log2_fold_change: None,
            lfc_se: None,
            stat: None,
            pvalue: None,
            padj: None,
            reason: Some("all-zero".into()),
            retained: false,
        };
        if let Some(gene) = gene {
            let intercept_covariance =
                if p == 1 && fit.dataset.design.matrix.iter().all(|x| *x == 1.0) {
                    let dispersion = fit.dispersions.genes[g]
                        .as_ref()
                        .ok_or_else(|| anyhow::anyhow!("missing fitted dispersion"))?;
                    Some(
                        crate::glm::covariance(
                            &gene.glm.floored_mu,
                            &fit.dataset.design,
                            dispersion.final_disp,
                        )?
                        .0,
                    )
                } else {
                    None
                };
            let covariance = intercept_covariance
                .as_deref()
                .unwrap_or(&gene.glm.covariance);
            let mut estimate = contrast
                .iter()
                .zip(&gene.glm.beta)
                .map(|(c, b)| c * b)
                .sum::<f64>();
            if mixed_sign
                && selected_samples
                    .iter()
                    .all(|j| fit.dataset.counts.row(g)[*j] == 0.0)
            {
                estimate = 0.0;
            }
            let variance = (0..p)
                .flat_map(|a| (0..p).map(move |b| (a, b)))
                .map(|(a, b)| contrast[a] * contrast[b] * covariance[a * p + b])
                .sum::<f64>();
            ensure!(
                variance.is_finite() && variance > 0.0,
                "invalid contrast variance for {}",
                fit.dataset.counts.genes[g]
            );
            let se = variance.sqrt();
            let stat = estimate / se;
            row.log2_fold_change = Some(estimate / std::f64::consts::LN_2);
            row.lfc_se = Some(se / std::f64::consts::LN_2);
            row.stat = Some(stat);
            if gene.max_cooks.is_some_and(|v| v > cutoff) {
                row.reason = Some("cooks-outlier".into());
            } else {
                row.pvalue = Some(erfc(stat.abs() / std::f64::consts::SQRT_2));
                row.reason = None;
            }
        }
        rows.push(row);
    }
    let lower = rows.iter().filter(|r| r.base_mean == 0.0).count() as f64 / rows.len() as f64;
    let upper = if lower < 0.95 { 0.95 } else { 1.0 };
    let theta = (0..50)
        .map(|i| lower + (upper - lower) * i as f64 / 49.0)
        .collect::<Vec<_>>();
    let mut means = rows.iter().map(|r| r.base_mean).collect::<Vec<_>>();
    means.sort_by(f64::total_cmp);
    let cutoffs = theta
        .iter()
        .map(|t| quantile(&means, *t))
        .collect::<Vec<_>>();
    let mut columns = Vec::new();
    let mut rejections = Vec::new();
    for cut in &cutoffs {
        let keep = rows
            .iter()
            .enumerate()
            .filter_map(|(i, r)| r.pvalue.filter(|_| r.base_mean >= *cut).map(|v| (i, v)))
            .collect::<Vec<_>>();
        let adj = rsomics_stats::bh_adjust(&keep.iter().map(|r| r.1).collect::<Vec<_>>())?;
        let mut column = vec![None; rows.len()];
        for ((i, _), v) in keep.into_iter().zip(adj) {
            column[i] = Some(v);
        }
        rejections.push(
            column
                .iter()
                .filter(|v| v.is_some_and(|v| v < alpha))
                .count() as f64,
        );
        columns.push(column);
    }
    let smooth = lowess::lowess(&theta, &rejections, 0.2, 3, 0.01 * (upper - lower));
    let selected = if rejections.iter().copied().fold(0.0, f64::max) <= 10.0 {
        0
    } else {
        let positive = rejections
            .iter()
            .zip(&smooth)
            .filter(|(r, _)| **r > 0.0)
            .collect::<Vec<_>>();
        let rmse = (positive.iter().map(|(r, s)| (*r - *s).powi(2)).sum::<f64>()
            / positive.len() as f64)
            .sqrt();
        let max = smooth.iter().copied().fold(f64::NEG_INFINITY, f64::max);
        rejections
            .iter()
            .position(|r| *r > max - rmse)
            .or_else(|| rejections.iter().position(|r| *r > 0.9 * max))
            .or_else(|| rejections.iter().position(|r| *r > 0.8 * max))
            .unwrap_or(0)
    };
    for (r, adj) in rows.iter_mut().zip(&columns[selected]) {
        r.padj = *adj;
        r.retained = r.base_mean >= cutoffs[selected];
        if r.pvalue.is_some() && r.padj.is_none() {
            r.reason = Some("independent-filter".into());
        }
    }
    Ok(Results {
        contrast: contrast.to_vec(),
        alpha,
        rows,
        filter: Filter {
            threshold: cutoffs[selected],
            theta,
            cutoffs,
            rejections,
            lowess: smooth,
            selected,
        },
    })
}

fn quantile(sorted: &[f64], p: f64) -> f64 {
    let h = (sorted.len() - 1) as f64 * p;
    let lo = h.floor() as usize;
    let hi = h.ceil() as usize;
    let f = h - lo as f64;
    if sorted[lo] == sorted[hi] {
        return sorted[lo];
    }
    (1.0 - f) * sorted[lo] + f * sorted[hi]
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn tied_quantiles_preserve_the_original_threshold() {
        let value = 0.18765639836784123;
        assert_eq!(quantile(&[value, value], 0.7804486189298), value);
    }
}
