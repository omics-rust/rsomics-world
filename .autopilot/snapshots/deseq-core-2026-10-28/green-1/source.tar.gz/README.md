# rsomics-deseq — private checkpoint

This unpublished product owns a fitted count-analysis workflow, not a set of
independently recomputed statistical helpers. It is not release-ready.

`run` accepts integer counts, sample metadata, and an explicit named numeric
model matrix. Sample rows are joined by identifier. Every contrast coefficient
must be provided, including explicit zero weights. The fitted JSON bundle
retains original counts, metadata, model matrix, input hashes, normalization,
gene/trend/raw-MAP/final dispersions, full coefficient covariance, raw and
floored means, leverage, Cook's diagnostics, convergence and initial filtering.
All-zero genes have explicit absent fit state; their counts remain in exports.

`results` derives another contrast from that bundle. `transform --kind
normalized` exports normalized counts; `transform --kind vst` uses the fitted
parametric trend without refitting or blinding the design. Named outputs are
transactional through rsomics-common. `--json` uses the common process envelope.

The private checkpoint rejects residual degrees of freedom <= 3, design cells
of size >= 7 requiring possible Cook's replacement, and an unsuccessful
parametric trend. General formula coding, supplied normalization, positive
Cook's replacement and nonparametric trends remain release requirements, not
placeholder commands. Optimizer failures fail the command rather than writing
fake successful estimates.

The complete source witness and numeric tolerances are exercised by
`scripts/check-workflow.py`. The witness is external, not embedded in this
product or consulted by production code. Build and test with
`bash scripts/guarded-cargo.sh test`; its paths and APFS guard are specific to
the authorized development host.

## Source provenance

Behavior authority: DESeq2 1.52.0, commit
`16aeab6d6158bd8cbb8e98764c2f33399b1a3fd3`, particularly `R/core.R`,
`R/fitNbinomGLMs.R`, `R/results.R`, `R/vst.R`, and `src/DESeq2.cpp`.
Upstream is LGPL-3-or-later and is consulted as a behavior reference, not
included as vendored source. Cite Love MI, Huber W, Anders S (2014),
“Moderated estimation of fold change and dispersion for RNA-seq data with
DESeq2”, Genome Biology 15:550, doi:10.1186/s13059-014-0550-8.

Selected implementation assets are user-confirmed team-owned Rust:

| Asset | Revision | Reuse |
| --- | --- | --- |
| rsomics-deseq-sizefactors | 2aae52e2a4fc0d31d51c732d79f8dad38db7cf13 | ratio and median math |
| rsomics-deseq-lrt | a011348a0a61f20de84024b6ba59e56afc27c3a7 | dispersion posterior, gradient, Armijo/grid and trend kernels; refactored GLM seed |
| rsomics-deseq-estimate-dispersions | 30cfe948a68924b308d2cd61867fb194860fc4ca | rough/base dispersion statistics reference |
| rsomics-deseq-results | 94b1cea1e19f1e02fcf829a7f3cec7bb2f51dc5b | result and Cook's arithmetic reference; two-column design and approximate LOWESS rejected |
| rsomics-deseq-vst | 4178daad4d14b7bb4a3c6121b631464d35aeccef | parametric transform math |
| rsomics-voom | f51e528200ef16259f04451e1a33becc22932d57 | LOWESS/lowest kernel only, not trend interpolation or voom policy |

The median-of-ratios, NB GLM, dispersion and filtering policies remain private
product modules. No new public foundation APIs or Layer B dependencies exist.
BH adjustment uses the finite-value API of registry rsomics-stats 0.2.4 with
product-owned missing-value gather/scatter.

Bounded optimizer fallback uses registry `rcompat-lbfgsb =0.2.2` (MIT,
Denis Demin), with the released DESeq2 1.52 log2 objective, numeric gradient,
default R controls and original starting-value and leverage semantics.
The library's parity claims do not replace this product's fixed-witness tests.
