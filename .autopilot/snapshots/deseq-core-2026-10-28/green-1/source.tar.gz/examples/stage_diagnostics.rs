use anyhow::{Context, Result};
use rsomics_deseq::{
    artifact,
    dataset::{self, Dataset},
    dispersion, glm,
};
use serde_json::json;
use std::path::PathBuf;

fn main() -> Result<()> {
    let args = std::env::args().skip(1).collect::<Vec<_>>();
    anyhow::ensure!(
        args.len() == 2,
        "usage: stage_diagnostics WITNESS OUTPUT_JSON"
    );
    let root = PathBuf::from(&args[0]);
    let dataset = Dataset::read(
        &root.join("inputs/counts.tsv"),
        &root.join("inputs/samples.tsv"),
        &root.join("inputs/model-matrix.tsv"),
    )?;
    let factors = dispersion::size_factors(&dataset.counts)?;
    let logsf = factors.iter().map(|s| s.ln()).collect::<Vec<_>>();
    let (headers, rows) = dataset::table(&root.join("fit/row-diagnostics.tsv"))?;
    let column = headers
        .iter()
        .position(|s| s == "dispersion")
        .context("missing source dispersion")?;
    let mut conditional = Vec::new();
    for (g, row) in rows.iter().enumerate() {
        anyhow::ensure!(
            row[0] == dataset.counts.genes[g],
            "source gene identity mismatch"
        );
        if row[column] == "NA" {
            conditional.push(json!({"gene":row[0],"all_zero":true}));
        } else {
            let alpha = row[column].parse::<f64>()?;
            let result = glm::irls(dataset.counts.row(g), &logsf, &dataset.design, alpha);
            conditional.push(match result {
                Ok(fit) => json!({"gene":row[0],"source_dispersion":alpha,"irls":fit}),
                Err(error) => json!({"gene":row[0],"error":format!("{error:#}")}),
            });
        }
    }
    let native_dispersion = match dispersion::estimate(&dataset.counts, &dataset.design, &factors) {
        Ok(d) => json!({"native":d}),
        Err(error) => json!({"error":format!("{error:#}")}),
    };
    artifact::json(
        &PathBuf::from(&args[1]),
        &json!({
            "diagnostic_only":true,
            "not_a_fitted_bundle":true,
            "wald_conditioning":"source final dispersions, native size factors; unoptimized IRLS state is explicitly labelled",
            "input_sha256":dataset.input_sha256,
            "size_factors":factors,
            "conditional_wald":conditional,
            "native_dispersion":native_dispersion,
        }),
    )
}
