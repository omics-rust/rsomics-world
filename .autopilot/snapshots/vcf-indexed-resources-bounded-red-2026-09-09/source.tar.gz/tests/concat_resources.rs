#![cfg(any(target_os = "linux", target_os = "macos"))]

use std::fs;
use std::io::{BufRead, BufReader, Read, Write};
use std::path::{Path, PathBuf};
use std::process::{Child, Command, Stdio};
use std::time::{Duration, Instant};

struct Process(Child);

impl Drop for Process {
    fn drop(&mut self) {
        if self.0.try_wait().ok().flatten().is_none() {
            let _ = self.0.kill();
            let _ = self.0.wait();
        }
    }
}

#[derive(Debug)]
struct Resources {
    inputs: usize,
    threads: usize,
    descriptors: usize,
    rss_kib: usize,
}

fn command() -> Command {
    let mut command = Command::new(env!("CARGO_BIN_EXE_rsomics-vcf"));
    command.env("LC_ALL", "C");
    command
}

fn capture(command: &mut Command) -> String {
    let output = command.output().unwrap();
    assert!(
        output.status.success(),
        "{command:?}: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    String::from_utf8(output.stdout).unwrap()
}

fn indexed_fixture(directory: &Path, records: usize) -> PathBuf {
    let source = directory.join("input.vcf");
    let mut writer = std::io::BufWriter::new(fs::File::create(&source).unwrap());
    write!(
        writer,
        "##fileformat=VCFv4.3\n##contig=<ID=chr1,length={records}>\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\n"
    )
    .unwrap();
    for position in 1..=records {
        writeln!(writer, "chr1\t{position}\tv{position}\tA\tC\t50\tPASS\t.").unwrap();
    }
    writer.flush().unwrap();
    let indexed = directory.join("input.vcf.gz");
    capture(
        command()
            .args(["view", "-Oz", "-o"])
            .arg(&indexed)
            .arg(source),
    );
    capture(command().arg("index").arg(&indexed));
    indexed
}

fn resources(pid: u32, inputs: usize) -> Resources {
    let pid = pid.to_string();
    #[cfg(target_os = "linux")]
    let (threads, descriptors) = (
        fs::read_dir(format!("/proc/{pid}/task"))
            .unwrap()
            .map(Result::unwrap)
            .count(),
        fs::read_dir(format!("/proc/{pid}/fd"))
            .unwrap()
            .map(Result::unwrap)
            .count(),
    );
    #[cfg(target_os = "macos")]
    let (threads, descriptors) = {
        let threads = capture(Command::new("ps").args(["-M", "-p", &pid]));
        let descriptors = capture(Command::new("/usr/sbin/lsof").args([
            "-a",
            "-p",
            &pid,
            "-d",
            "0-1048575",
            "-F",
            "f",
        ]));
        (
            threads
                .lines()
                .filter(|line| line.split_whitespace().nth(1) == Some(pid.as_str()))
                .count(),
            descriptors
                .lines()
                .filter(|line| {
                    line.strip_prefix('f')
                        .is_some_and(|value| value.parse::<u32>().is_ok())
                })
                .count(),
        )
    };
    let rss_kib = capture(Command::new("ps").args(["-p", &pid, "-o", "rss="]))
        .trim()
        .parse()
        .unwrap();
    Resources {
        inputs,
        threads,
        descriptors,
        rss_kib,
    }
}

fn wait_for_broken_pipe(process: &mut Process) {
    let deadline = Instant::now() + Duration::from_secs(10);
    let status = loop {
        if let Some(status) = process.0.try_wait().unwrap() {
            break status;
        }
        assert!(
            Instant::now() < deadline,
            "concat did not exit after pipe closure"
        );
        std::thread::sleep(Duration::from_millis(10));
    };
    let mut stderr = String::new();
    process
        .0
        .stderr
        .take()
        .unwrap()
        .read_to_string(&mut stderr)
        .unwrap();
    assert!(!status.success(), "pipe closure returned success");
    assert!(stderr.to_lowercase().contains("broken pipe"), "{stderr}");
}

fn first_record(process: &mut Process) -> BufReader<std::process::ChildStdout> {
    let stdout = process.0.stdout.take().unwrap();
    let (sender, receiver) = std::sync::mpsc::sync_channel(1);
    let reader = std::thread::spawn(move || {
        let mut output = BufReader::new(stdout);
        let mut line = String::new();
        loop {
            line.clear();
            assert_ne!(output.read_line(&mut line).unwrap(), 0, "no first record");
            if !line.starts_with('#') {
                break;
            }
        }
        sender.send((output, line)).unwrap();
    });
    let response = receiver.recv_timeout(Duration::from_secs(30));
    if response.is_err() {
        let _ = process.0.kill();
        let _ = process.0.wait();
    }
    let joined = reader.join();
    let (output, line) =
        response.expect("concat did not return its first record within 30 seconds");
    joined.unwrap();
    assert_eq!(line, "chr1\t1\tv1\tA\tC\t50\tPASS\t.\n");
    output
}

#[test]
fn indexed_input_count_does_not_add_threads_and_broken_pipes_exit() {
    let directory = tempfile::tempdir().unwrap();
    let indexed = indexed_fixture(directory.path(), 131_072);
    let mut samples = Vec::new();
    for inputs in [1, 2, 64, 256] {
        let mut process = Process(
            command()
                .args(["concat", "-a", "-r", "chr1:1-131072", "-Ov"])
                .args(std::iter::repeat_n(&indexed, inputs))
                .stdout(Stdio::piped())
                .stderr(Stdio::piped())
                .spawn()
                .unwrap(),
        );
        let output = first_record(&mut process);
        let sample = resources(process.0.id(), inputs);
        println!("indexed_concat_resources {sample:?}");
        samples.push(sample);
        drop(output);
        wait_for_broken_pipe(&mut process);
    }
    for sample in samples {
        assert_eq!(sample.threads, 1, "{sample:?}");
        assert!(sample.descriptors >= sample.inputs + 3, "{sample:?}");
        assert!(sample.rss_kib > 0, "{sample:?}");
    }
}

#[test]
fn indexed_many_input_merge_preserves_every_record() {
    let directory = tempfile::tempdir().unwrap();
    let indexed = indexed_fixture(directory.path(), 32);
    for inputs in [1, 2, 64, 256] {
        let output = capture(
            command()
                .args(["concat", "-a", "-r", "chr1:1-32", "-Ov"])
                .args(std::iter::repeat_n(&indexed, inputs)),
        );
        let records: Vec<_> = output
            .lines()
            .filter(|line| !line.starts_with('#'))
            .collect();
        assert_eq!(records.len(), inputs * 32);
        for (index, record) in records.iter().enumerate() {
            let position = index / inputs + 1;
            assert_eq!(
                *record,
                format!("chr1\t{position}\tv{position}\tA\tC\t50\tPASS\t."),
                "{inputs} inputs, record {index}"
            );
        }
    }
}
