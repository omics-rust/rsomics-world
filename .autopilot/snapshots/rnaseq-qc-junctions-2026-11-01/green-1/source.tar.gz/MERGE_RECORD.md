# Implementation and behavior provenance

This directory is the new coherent product, not a revival of a retired
operation-sized crate. It has no product or path dependencies and remains
`publish = false`.

## Team-owned implementation assets

| Asset and exact local revision | Disposition in this slice |
| --- | --- |
| `rsomics-bam-mapstat` `36a21482b2e76b03147d829469c4fd63b1e87aab` | Refactored count core into `metrics/mapping.rs`; removed reader, independent CLI, and fixed-width-only output |
| `rsomics-bam-strandedness` `6e4e20b08fcd649d6578eb9c906433476d219c2f` | Refactored first-N transcript-overlap classification into `metrics/strandedness.rs`; shared annotation/index and original-record observer |
| `rsomics-genebody-coverage` `1813f1f6e7504be12c4dcd8e8d6f6e9d180ff482` | Refactored genomic-list percentile interpolation into `metrics/sampling.rs`; no indexed per-transcript reader or generated R presentation retained |
| `rsomics-tin` `5e9fa05942c1ee999d87d475d3226638fa402c1a` | Reused exon-walk sampling idea; replaced source-disagreeing all-base dedup, entropy-zero handling, eligibility, summary population, and custom coverage scan |
| `rsomics-bam-read-dist` `2f39541572ebe2b795cba10275498f17333080ca` | Reviewed as asset only; no majority-overlap implementation retained |
| `rsomics-read-distribution` `e169e6c9b5ab8f1b6af64ea633134931102d1e58` | Reviewed as asset only; new shared annotation/midpoint logic follows the actual pinned source |
| `rsomics-bam-junctions` `4f7a39cd1a69c7bae5a5c98393ed15bcb0acd62e` | Private classifier/count type seeds; refactored site indexing and N projection onto strict shared annotation/original records with ordered detail/support; discarded standalone reader/CLI/permissive parser and per-event chromosome allocations |

The user confirmed ownership and permission to reuse these implementations.
Their original repositories remain available on external storage. No upstream
Python source text is embedded in the Rust implementation.

## Pinned behavior source

RSeQC 5.0.5 wheel SHA-256:
`a1fca6d455886b19bc2d58aa1e13b233977a2c835f676ef93bd0c6f4099b8452`.
Git source revision: `0d2e017723c5c4b41eb3b938e1631692d187de1f`.
Five script bodies were matched after the installed shebang; seven qcmodule
files, including SAM, BED, bam_cigar, and mystat, matched byte-for-byte between
the wheel and pinned source. The retained actual source witness is run
`40520155303`, under
`/Volumes/Zane's HDD/rsomics-fixtures/evidence/rnaseq-qc-2026-10-27/run-40520155303/`.
Its single/paired cases contain 88/175 original records. This source witness is
not a performance benchmark or evidence of every default's boundary behavior.

The implemented contracts were checked against the retained script/qcmodule
logic, not inferred from retired crate names or old success claims. Source
defaults use pysam 0.24.0/samtools 1.23.1: excluded flags `0x704`, MAPQ 0,
proper-pair admission, adjusted overlap qualities, depth 8000, BQ 13, no BAQ
without a supplied FASTA. Those mechanisms are delegated to `rsomics-pileup`
rather than copied into this product. The current private candidate pins its
0.9.1 source revision while registry publication is blocked by authentication.

Canonical distribution corrects CIGAR and point semantics; explicitly selected
`rseqc-5.0.5` preserves them. The zero-width midpoint query was verified in
bx-python 0.15.1 `lib/bx/intervals/intersection.pyx` (`_intersect` requires
strict overlap). TIN's `100 * exp(entropy) / sampled_length` is positive at zero
entropy when coverage is positive; the source entropy case is `100/102`.
Eligible-zero transcripts remain in the sample summary. The RSeQC profile
replays independent pileup contexts using the actual sorted source query
bounds and original unadjusted qualities. Identical query windows share replay;
record buffering is bounded by live spans and retired batches, not a fixed
absolute memory ceiling. Canonical coverage/integrity retain one global engine.
The depth-8000 saturation boundary remains uncertified.

Upstream attribution: Wang et al., RSeQC, Bioinformatics (2012),
<https://doi.org/10.1093/bioinformatics/bts356>; Wang et al., TIN, BMC
Bioinformatics (2016), <https://doi.org/10.1186/s12864-016-2539-1>; RSeQC
<https://rseqc.sourceforge.net/> (GPL-licensed upstream; behavioral attribution,
not a relicensing claim); SAM/BAM and BED12 specifications. The product's
team-owned Rust code uses MIT OR Apache-2.0; no clean-room or certification
claim is made.

## Junction annotation addition

The actual junction source chain is wheel
`rseqc-5.0.5.data/scripts/junction_annotation.py` →
`qcmodule/SAM.py:ParseBAM.annotate_junction` →
`qcmodule/bam_cigar.py:fetch_intron`, not ParseSAM or the legacy distribution
projection. Wheel script SHA-256 is
`527d4ef87cab543a5e92f5438f16152bc79f8a5f35f25a15b6ccefd0aa09e03b`;
SAM.py is `43727df48288f808159b1bf60c75db010a8e115359dd5280ddf3e0211944d5f5`;
bam_cigar.py is `805777b0853595733630db164663036f15f0e62e2af201f244385c652eafa2b9`.
The source TAR SHA-256 is
`8c9d34c208bf7852f147dd365312a43a546148d1bf76581c5c0ede73fdb254b8`
at the pinned upstream revision above. These source bodies were inspected as
data; no upstream Python text is embedded or executed on the Mac.

Root-adopted source run `41277337904/1`, exact head
`b4cde25cde7a7d52d4b3947004929991b897a727`, artifact `13071489886`,
contains six real invocations under freshly admitted CPython 3.12.10 and the
unchanged 17 scientific dependency versions. Its world receipt
`.autopilot/oracles/rnaseq-qc-junctions-2026-11-01.json` has SHA-256
`8ea60c35c952a600fa526ebfd3e020e142b01706f50a87a9fbc8818ce9ce5b2b`.
The complete authenticated originals stay in
`/Volumes/KIOXIA/Developments/tmp/rnaseq-junction-source-success-20261101.EQWawE`;
small original fixture BAM/SAM/BED, full primary outputs, statuses and counters
are captured with member names, lengths and SHA-256 in
`tests/fixtures/junctions/provenance.json`. They are data, not a restored runtime.
The older failed source run remains separate and unchanged.

Informative single/paired observations have event counters
`11/6/1/3/1` and `22/12/2/6/2` (total/known/partial/novel/filtered), with
distinct counts `6/2/1/3` (total/known/partial/novel). Full ordered rows, not
summary totals alone, are the compatibility contract. Supplementary records
and separate mates contribute support; duplicate annotation sites do not
multiply counts. Independent known endpoints classify `120–270` as annotated
even though the pair is absent from the gene model. The mixed CIGAR source
row is `522–572`; canonical geometry is `530–580`. Source pooling combines
admitted exact `chr1` and `CHR1` header contigs, while canonical identity is
exact. Native retains exact-header validation and rejects the source-only
`ChR1` annotation alias. Existing distribution ambiguity rejection is unchanged.

Valid no-N/all-short native complete-zero transactions are an intentional
source incompatibility: the actual upstream no-N files are empty at exit 0,
and actual all-short output is partial at exit 1. Those retained observations
are not rewritten or described as complete source success. Exports/R/PDF and
saturation are excluded. All junction code remains private within the existing
binary/library; no new dependency or foundation API is introduced.

The new connected workflow test was observed RED on the missing junctions
command before implementation. It covers full captured rows/counters/order,
canonical geometry, case policy, empty/filtered input, report opt-in/default
five preservation, shared original-record observation, workers and atomic-set
failure. Local verification, new four-native qualification and representative
junction performance are separate gates; earlier five-metric runs and timings
below are not proofs for this addition.

Local macOS aarch64 verification of this addition passes formatting, strict
all-target/all-feature Clippy, and the full debug/release suites (four unit
tests and eight workflow tests per profile). This is not four-native admission
or a performance result; the private candidate remains unpublished.

## Candidate verification ledger

Current source-query work supersedes the older global-pileup candidate below.
The complete original input (9,810,963 records, 58,384 transcript rows) matches
all five actual source metrics at one/four workers: 45,052 eligible TIN rows,
100 coverage bins, total coverage 13,624,401. Reports are byte-identical across
workers. A whole-feature review and scoped follow-up
closed the unmapped-record query-watermark finding. The new regression keeps
placed-unmapped coordinates from advancing source query state.

Shared producer fixes retain filtered-record overlap state, reproduce HTSlib's
QName-keyed expiry, and advance emission only for admitted records. Actual
samtools comparisons and consumer regressions cover those contracts. No new
public foundation item, product dependency or copied Python implementation is
introduced.

Source-query commit59f50135425702ce10f9dbc38fd8dc113b5b5fd6 (green5) passes
four-native40590326515:11 tests per debug/release profile, strict checks and
all16 complete source comparisons. Commitb7287f26d8d6f1d6e46bf580e850eb639d8a0ed0
changes only shared ThreadArgs plumbing; green6/run40597129172 also passes
all four classes. Both original artifact/source/binary/oracle chains are
retained and verified. Synthetic single/paired report bytes agree across
workers/platforms; this is not an assertion about real-whole floating bytes.

Whole-input performance40592936910 at exact world5fcb3820198c8fe8fd3e463a609b276df7ae590a
measures only green5's Linux executable
48091abdb22d5d91e18a733848798b8a9ae3dd83d3d8117dd77feca08fd13707.
The original full BAM/annotation and all5 source metric gates pass in every
trial, with no tolerance/input change. Warm-cache medians1557.27/54.94/28.95s
for source/native1/native4 give28.34x serial speed and1.90x worker gain with
separated ranges. Median process RSS885276/698436/704704KiB gives21.11% lower
serial RSS, not the old chr21 ratio. More native output blocks preclude an
I/O-volume advantage. Four logical CPUs were allocated;80-core model naming
does not imply80 available cores. All521 original artifact files, raw API/
logs/time/process/output manifests and exact measured controller are retained:
/Volumes/Zane's HDD/rsomics-fixtures/evidence/rnaseq-qc-real-performance-2026-10-28/run-40592936910/.
Verification SHA
fdee7132f239d321aa29363337739fd48eefba54daa430a30a3641ba103d405c.

Linux whole-report SHA8ce96492da5b184e961bb702cbf4d5de913db3f478aeb8045b09bcc447b4aebf
and earlier Mac70d947d7c5e3181a2ddec7114c73bba46452ee25e0b2f39b58bda20fc9215836
have exactly63 TIN scalar differences, maximum2.842170943040401e-14, within
the unchanged bound; every other field and TIN summary matches. This is
numerical compatibility, not cross-platform whole-report byte equality.
Registry adoption and final publication review remain open. These documentation
updates do not change the measured or four-native source code.

Historical green4 checkpoint:

- Read actual pinned behavior and successful single/paired source observations.
- Whole-workflow tests authored first; native execution intentionally deferred
  because the Mac boot APFS exceeds the 80% gate. No RED/GREEN claim is made.
- No local Cargo build/test/metadata/dependency download or installation.
- No new public foundation API or Layer B dependency.
- Standalone `rustfmt --edition 2024` on all Rust sources and workflow tests
  completed successfully on the external source directory. This is not a
  compilation or execution result.
- One independent whole-feature read-only source review found no actionable
  Critical/Important or Minor issue. It explicitly declined to certify native
  compilation/tests, complete helper equivalence, performance/depth-boundary
  equivalence, or publication readiness. No repeat review campaign is planned.
- Green4 run40546148508 at control-plane head
  1224fbf18d7af1b4b76869fc6e41b1611d7bb43b passes all four native platforms:
  format, strict Clippy, eight debug and eight release tests per platform,
  and sixteen complete single/paired one/four-worker source comparisons.
  All numeric outputs match the actual RSeQC witness; report bytes match
  across workers and platforms. Original artifact API/ZIP/log/source/binary
  evidence is retained under external fixtures run-40546148508.
- Executed archive SHA-256 is
  a451612a20af21f1d73e15fadb60f039f18ef9c613a16a1652ba3f7c9177ddb0;
  source-file manifest SHA-256 is
  a7449cb79fc889a3d2fcc4fd6fb8a56813d2c21a70d91481d2332af55f50a562;
  dependency lock SHA-256 is
  c09dea6b5397ca673d7052042d403fa55d2663e45c99672dc6f5ea6f51f308e2.
- The accepted run establishes the bounded synthetic semantic contract only.
  Representative real-input compatibility, CPU/RSS/I/O measurement, final
  metadata and release review remain open. Frozen manifest maturity wording
  predates the successful four-native gate; it is not fresh gate evidence.
