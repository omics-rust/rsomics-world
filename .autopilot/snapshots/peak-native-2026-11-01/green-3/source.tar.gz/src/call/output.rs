use super::{
    CallConfig, ScoreCutoff,
    signal::{Segment, Segments, Spool},
    statistics::{decimal_round, score_key},
};
use crate::{
    io::OutputGroup,
    model::{ChromDictionary, invalid},
};
use rsomics_common::Result;
use std::{
    collections::HashMap,
    io::{BufWriter, Write},
};

pub(super) struct Peak {
    start: u64,
    end: u64,
    summit: u64,
    pileup: f32,
    p: f32,
    q: f32,
    fold: f32,
    score: f32,
}
fn close(
    content: &[(u64, Segment, f32)],
    cutoff: f32,
    min_length: u32,
    qtable: &HashMap<u32, f32>,
    peaks: &mut Vec<Peak>,
) -> Result<()> {
    if content.is_empty() {
        return Ok(());
    }
    let end = content.last().expect("nonempty").1.end;
    if end - content[0].0 < u64::from(min_length) {
        return Ok(());
    }
    let height = content.iter().map(|r| r.1.treatment).fold(0.0, f32::max);
    let maxima = content
        .iter()
        .filter(|r| r.1.treatment == height)
        .collect::<Vec<_>>();
    let (start, segment, score) = *maxima[(maxima.len() - 1) / 2];
    if cutoff > score {
        return Ok(());
    }
    let fold = ((f64::from(segment.treatment) + 1.0) / (f64::from(segment.control) + 1.0)) as f32;
    if fold < 1.0 {
        return Ok(());
    }
    let q = *qtable
        .get(&score_key(segment.p))
        .ok_or_else(|| invalid("missing summit q-value"))?;
    peaks.push(Peak {
        start: content[0].0,
        end,
        summit: start + (segment.end - start) / 2,
        pileup: segment.treatment,
        p: segment.p,
        q,
        fold,
        score,
    });
    Ok(())
}
pub(super) fn call(
    spool: &Spool,
    qtable: &HashMap<u32, f32>,
    mode: ScoreCutoff,
    cutoff: f32,
    max_gap: u32,
    min_length: u32,
    budget: usize,
) -> Result<Vec<Peak>> {
    let mut reader = Segments::open(spool)?;
    let mut content = Vec::new();
    let mut peaks = Vec::new();
    let mut previous = 0;
    while let Some(segment) = reader.next()? {
        let score = match mode {
            ScoreCutoff::P(_) => segment.p,
            ScoreCutoff::Q(_) => *qtable
                .get(&score_key(segment.p))
                .ok_or_else(|| invalid("missing segment q-value"))?,
        };
        if score > cutoff {
            if content
                .last()
                .is_some_and(|r: &(u64, Segment, f32)| previous - r.1.end > u64::from(max_gap))
            {
                close(&content, cutoff, min_length, qtable, &mut peaks)?;
                content.clear();
            }
            content.push((previous, segment, score));
            if content.len().saturating_mul(64) + peaks.len().saturating_mul(96) > budget / 2 {
                return Err(invalid(
                    "caller peak workspace exceeds bounded worker memory",
                ));
            }
        }
        previous = segment.end;
    }
    close(&content, cutoff, min_length, qtable, &mut peaks)?;
    Ok(peaks)
}
fn g(value: f64) -> String {
    if value == 0.0 {
        return if value.is_sign_negative() {
            "-0".into()
        } else {
            "0".into()
        };
    }
    let scientific = format!("{value:.5e}");
    let (mantissa, exponent) = scientific
        .split_once('e')
        .expect("scientific format has exponent");
    let exponent: i32 = exponent.parse().expect("formatted exponent is numeric");
    if (-4..6).contains(&exponent) {
        let decimals = (5 - exponent).max(0) as usize;
        let text = format!("{value:.decimals$}");
        if text.contains('.') {
            text.trim_end_matches('0').trim_end_matches('.').into()
        } else {
            text
        }
    } else {
        format!(
            "{}e{}{:02}",
            mantissa.trim_end_matches('0').trim_end_matches('.'),
            if exponent < 0 { '-' } else { '+' },
            exponent.abs()
        )
    }
}
pub(super) fn write_peaks(
    group: &mut OutputGroup,
    results: &[Vec<Peak>],
    chromosomes: &[usize],
    dictionary: &ChromDictionary,
    c: &CallConfig,
) -> Result<()> {
    writeln!(
        group.file_mut(2),
        "chr\tstart\tend\tlength\tabs_summit\tpileup\t-log10(pvalue)\tfold_enrichment\t-log10(qvalue)\tname"
    )?;
    let mut number = 0;
    for (&id, peaks) in chromosomes.iter().zip(results) {
        let chrom = &dictionary.chromosomes[id].name;
        for peak in peaks {
            number += 1;
            let name = format!("{}_peak_{number}", c.name);
            let score = (10.0 * f64::from(peak.score)) as i64;
            writeln!(
                group.file_mut(0),
                "{chrom}\t{}\t{}\t{name}\t{score}\t.\t{}\t{}\t{}\t{}",
                peak.start,
                peak.end,
                g(f64::from(peak.fold)),
                g(f64::from(peak.p)),
                g(f64::from(peak.q)),
                peak.summit - peak.start
            )?;
            writeln!(
                group.file_mut(1),
                "{chrom}\t{}\t{}\t{name}\t{}",
                peak.summit,
                peak.summit + 1,
                g(f64::from(peak.score))
            )?;
            writeln!(
                group.file_mut(2),
                "{chrom}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{name}",
                peak.start + 1,
                peak.end,
                peak.end - peak.start,
                peak.summit + 1,
                g(decimal_round(f64::from(peak.pileup), 2)),
                g(f64::from(peak.p)),
                g(f64::from(peak.fold)),
                g(f64::from(peak.q))
            )?;
        }
    }
    Ok(())
}
pub(super) fn write_tracks(
    group: &mut OutputGroup,
    spools: &[Spool],
    chromosomes: &[usize],
    dictionary: &ChromDictionary,
) -> Result<()> {
    for (&id, spool) in chromosomes.iter().zip(spools) {
        let chrom = &dictionary.chromosomes[id].name;
        for (index, treatment) in [(4, true), (5, false)] {
            let mut writer = BufWriter::new(group.file_mut(index));
            let mut reader = Segments::open(spool)?;
            let mut start = 0;
            let mut end = 0;
            let mut previous = None;
            while let Some(segment) = reader.next()? {
                let value = if treatment {
                    segment.treatment
                } else {
                    segment.control
                };
                if previous.is_some_and(|v: f32| (value - v).abs() > 1e-5) {
                    writeln!(
                        writer,
                        "{chrom}\t{start}\t{end}\t{:.5}",
                        f64::from(previous.expect("present previous track value"))
                    )?;
                    start = end;
                }
                if previous.is_none() || previous.is_some_and(|v: f32| (value - v).abs() > 1e-5) {
                    previous = Some(value);
                }
                end = segment.end;
            }
            if let Some(value) = previous {
                writeln!(writer, "{chrom}\t{start}\t{end}\t{:.5}", f64::from(value))?;
            }
            writer.flush()?;
        }
    }
    Ok(())
}
