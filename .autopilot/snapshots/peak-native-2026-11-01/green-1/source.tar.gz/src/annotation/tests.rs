use super::graph::AnnotationGraph;
use super::*;
use crate::{execution::Execution, io::read_peak_rows};
use std::{collections::HashSet, num::NonZeroUsize, path::PathBuf};

fn oracle() -> PathBuf {
    std::env::var_os("RSOMICS_PEAK_ORACLE").map(PathBuf::from).unwrap_or_else(|| PathBuf::from("/Volumes/Zane's HDD/rsomics-fixtures/evidence/peak-first-workflow-oracle-2026-10-31/run-41209740891/selected"))
}

fn tsv(line: &str) -> Vec<String> {
    let mut fields = vec![String::new()];
    let mut quoted = false;
    let mut chars = line.chars().peekable();
    while let Some(ch) = chars.next() {
        match ch {
            '"' if quoted && chars.peek() == Some(&'"') => {
                chars.next();
                fields.last_mut().unwrap().push('"');
            }
            '"' => quoted = !quoted,
            '\t' if !quoted => fields.push(String::new()),
            _ => fields.last_mut().unwrap().push(ch),
        }
    }
    assert!(!quoted);
    fields
}

#[test]
fn complete_annotation_matches_three_original_source_views_and_preserves_rows() {
    let root = oracle();
    let gtf = read_graph(&root.join("inputs/annotation.gtf"), AnnotationFormat::Gtf).unwrap();
    let gff = read_graph(&root.join("inputs/annotation.gff3"), AnnotationFormat::Gff3).unwrap();
    assert_eq!(gtf.transcripts.len(), 320);
    assert_eq!(
        gtf.transcripts
            .iter()
            .flat_map(|tx| &tx.gene_ids)
            .collect::<HashSet<_>>()
            .len(),
        256
    );
    assert_eq!(
        gtf.transcripts
            .iter()
            .map(|tx| tx.exons.len())
            .sum::<usize>(),
        960
    );
    assert_eq!(
        gtf.transcripts
            .iter()
            .flat_map(|tx| &tx.exons)
            .filter(|exon| exon.cds.is_some())
            .count(),
        840
    );
    assert_eq!(
        gtf.transcripts
            .iter()
            .flat_map(|tx| tx.exons.iter().map(move |exon| (
                tx.span.chrom.0,
                tx.strand == Strand::Plus,
                exon.start,
                exon.end
            )))
            .collect::<HashSet<_>>()
            .len(),
        768
    );
    assert_eq!(
        gtf.transcripts
            .iter()
            .flat_map(|tx| tx
                .exons
                .iter()
                .filter_map(move |exon| exon.cds.as_ref().map(|cds| (
                    tx.span.chrom.0,
                    tx.strand == Strand::Plus,
                    cds.start,
                    cds.end
                ))))
            .collect::<HashSet<_>>()
            .len(),
        672
    );
    let exported =
        std::fs::read_to_string(root.join("witness/calls/A-gtf-default/transcripts.tsv")).unwrap();
    for (tx, expected) in gtf
        .transcripts
        .iter()
        .zip(exported.lines().skip(1).map(tsv))
    {
        assert_eq!(
            gtf.dictionary.chromosomes[tx.span.chrom.0].name,
            expected[0]
        );
        assert_eq!((tx.span.start + 1).to_string(), expected[1]);
        assert_eq!(tx.span.end.to_string(), expected[2]);
        assert_eq!(tx.name, expected[6]);
        assert_eq!(tx.gene_ids.join("/"), expected[7]);
    }
    let normalized = |graph: &AnnotationGraph| {
        graph
            .transcripts
            .iter()
            .map(|tx| {
                (
                    tx.name.clone(),
                    tx.gene_ids.clone(),
                    tx.span,
                    tx.strand,
                    tx.exons
                        .iter()
                        .map(|exon| {
                            (
                                exon.start,
                                exon.end,
                                exon.rank,
                                exon.cds.as_ref().map(|cds| (cds.start, cds.end, cds.phase)),
                            )
                        })
                        .collect::<Vec<_>>(),
                )
            })
            .collect::<Vec<_>>()
    };
    assert_eq!(normalized(&gtf), normalized(&gff));
    let peaks = read_peak_rows(&root.join("witness/rows/workflow.bed"), 512 << 20).unwrap();
    assert_eq!(peaks.rows.len(), 20561);
    assert!(
        peaks
            .rows
            .iter()
            .map(|row| &row.original_fields[3])
            .collect::<HashSet<_>>()
            .len()
            < peaks.rows.len()
    );
    let addon = root.join("addon");
    let addon_peaks = read_peak_rows(&addon.join("inputs/annotation.bed"), 512 << 20).unwrap();
    assert_eq!(addon_peaks.rows.len(), 10);
    let original_calls = root.join("witness/calls");
    let addon_calls = addon.join("calls");
    for (calls, name, graph, peaks, tss, downstream) in [
        (&original_calls, "A-gtf-default", &gtf, &peaks, 3000, 3000),
        (&original_calls, "A-gff3-default", &gff, &peaks, 3000, 3000),
        (&original_calls, "A-gtf-300", &gtf, &peaks, 3000, 300),
        (&addon_calls, "A-gtf-narrow", &gtf, &addon_peaks, 10, 3000),
        (&addon_calls, "A-gff3-narrow", &gff, &addon_peaks, 10, 3000),
        (
            &addon_calls,
            "A-gtf-default",
            &gtf,
            &addon_peaks,
            3000,
            3000,
        ),
    ] {
        let config = AnnotationConfig {
            tss_upstream: tss,
            tss_downstream: tss,
            downstream,
        };
        let serial = assign(graph, peaks, &config, &Execution::new(NonZeroUsize::MIN)).unwrap();
        let parallel = assign(
            graph,
            peaks,
            &config,
            &Execution::new(NonZeroUsize::new(4).unwrap()),
        )
        .unwrap();
        assert_eq!(serial.rows, parallel.rows);
        let expected = std::fs::read_to_string(calls.join(name).join("annotation.tsv")).unwrap();
        let mut lines = expected.lines();
        let header = tsv(lines.next().unwrap());
        let col = |key| header.iter().position(|value| value == key).unwrap();
        let expected = lines.map(tsv).collect::<Vec<_>>();
        assert_eq!(serial.rows.len(), expected.len());
        for (index, (row, expected)) in serial.rows.iter().zip(expected).enumerate() {
            let input = &peaks.rows[index];
            assert_eq!(row.row_id, input.id);
            for (key, actual) in [
                (
                    "seqnames",
                    peaks.dictionary.chromosomes[input.span.chrom.0]
                        .name
                        .clone(),
                ),
                ("start", (input.span.start + 1).to_string()),
                ("end", input.span.end.to_string()),
                ("width", (input.span.end - input.span.start).to_string()),
                (
                    "strand",
                    match input.strand {
                        Strand::Plus => "+",
                        Strand::Minus => "-",
                        Strand::Unknown => "*",
                    }
                    .to_owned(),
                ),
                ("row_ordinal", input.id.0.to_string()),
                ("display_id", input.original_fields[3].clone()),
            ] {
                assert_eq!(actual, expected[col(key)], "{name} row{index} {key}");
            }
            let tx = &graph.transcripts[row.nearest_transcript];
            let actual = [
                row.annotation.clone(),
                (tx.span.chrom.0 + 1).to_string(),
                (tx.span.start + 1).to_string(),
                tx.span.end.to_string(),
                (tx.span.end - tx.span.start).to_string(),
                (if tx.strand == Strand::Plus { 1 } else { 2 }).to_string(),
                tx.gene_ids.join("/"),
                tx.name.clone(),
                row.distance_to_tss.to_string(),
            ];
            let keys = [
                "annotation",
                "geneChr",
                "geneStart",
                "geneEnd",
                "geneLength",
                "geneStrand",
                "geneId",
                "transcriptId",
                "distanceToTSS",
            ];
            for (key, actual) in keys.into_iter().zip(actual) {
                assert_eq!(actual, expected[col(key)], "{name} row{index} {key}");
            }
        }
    }
}

#[test]
fn typed_graph_resolves_reverse_order_multi_parents_and_feature_priority() {
    let temp = tempfile::tempdir().unwrap();
    let path = temp.path().join("graph.gff3");
    std::fs::write(&path, "##gff-version 3\n##sequence-region unused 1 1000\nc\tx\tCDS\t101\t200\t.\t+\t0\tParent=e1\nc\tx\texon\t51\t200\t.\t+\t.\tID=e1;Parent=a,b\nc\tx\texon\t301\t450\t.\t+\t.\tParent=a,b\nc\tx\tCDS\t301\t400\t.\t+\t2\tParent=a,b\nc\tx\tmRNA\t51\t450\t.\t+\t.\tID=b;Parent=g\nc\tx\tmRNA\t51\t450\t.\t+\t.\tID=a;Parent=g\nc\tx\tgene\t51\t450\t.\t+\t.\tID=g\n").unwrap();
    let graph = read_graph(&path, AnnotationFormat::Gff3).unwrap();
    assert_eq!(graph.transcripts.len(), 2);
    assert_eq!(graph.transcripts[0].name, "a");
    assert_eq!(
        graph.transcripts[0].exons[0].cds.as_ref().unwrap().start,
        100
    );
    let bed = temp.path().join("peaks.bed");
    std::fs::write(&bed, "c\t70\t80\tx\t0\t.\nc\t150\t160\tx\t0\t.\nc\t250\t260\tx\t0\t.\nc\t420\t430\tx\t0\t.\nc\t50\t51\tx\t0\t.\n").unwrap();
    let peaks = read_peak_rows(&bed, 1 << 20).unwrap();
    let config = AnnotationConfig {
        tss_upstream: 10,
        tss_downstream: 10,
        downstream: 3000,
    };
    let result = assign(&graph, &peaks, &config, &Execution::new(NonZeroUsize::MIN)).unwrap();
    assert_eq!(
        result
            .rows
            .iter()
            .map(|row| row.annotation.as_str())
            .collect::<Vec<_>>(),
        [
            "5' UTR",
            "Exon (a/g, exon 1 of 2)",
            "Intron (a/g, intron 1 of 1)",
            "3' UTR",
            "Promoter"
        ]
    );
    assert!(
        result.rows[0].detail.exon && result.rows[0].detail.five_utr && result.rows[0].detail.genic
    );
    assert_eq!(result.rows[2].nearest_transcript, 1);
    assert_eq!(result.rows[4].distance_to_tss, 0);
    std::fs::write(&bed, "missing\t0\t1\n").unwrap();
    let absent = read_peak_rows(&bed, 1 << 20).unwrap();
    assert!(
        assign(&graph, &absent, &config, &Execution::new(NonZeroUsize::MIN))
            .unwrap_err()
            .to_string()
            .contains("missing")
    );
    std::fs::write(&path, "c\tx\texon\t1\t10\t.\t+\t.\tID=e;Parent=absent\n").unwrap();
    let error = read_graph(&path, AnnotationFormat::Gff3)
        .unwrap_err()
        .to_string();
    assert!(error.contains("graph.gff3:1") && error.contains("absent"));
    std::fs::write(
        &path,
        "c\tx\tmRNA\t1\t10\t.\t+\t.\tID=a;Parent=b\nc\tx\tmRNA\t1\t10\t.\t+\t.\tID=b;Parent=a\n",
    )
    .unwrap();
    assert!(
        read_graph(&path, AnnotationFormat::Gff3)
            .unwrap_err()
            .to_string()
            .contains("cycle")
    );
    let gtf = temp.path().join("graph.gtf");
    std::fs::write(&gtf, "c\tx\texon\t51\t200\t.\t-\t.\tgene_id \"g\"; transcript_id \"minus\"; exon_number \"2\";\nc\tx\tCDS\t101\t200\t.\t-\t0\tgene_id \"g\"; transcript_id \"minus\";\nc\tx\texon\t301\t450\t.\t-\t.\tgene_id \"g\"; transcript_id \"minus\"; exon_number \"1\";\nc\tx\tCDS\t301\t400\t.\t-\t2\tgene_id \"g\"; transcript_id \"minus\";\n").unwrap();
    let minus = read_graph(&gtf, AnnotationFormat::Gtf).unwrap();
    assert_eq!(minus.transcripts[0].exons[0].rank, 1);
    assert_eq!(minus.transcripts[0].exons[0].start, 300);
    let result = assign(&minus, &peaks, &config, &Execution::new(NonZeroUsize::MIN)).unwrap();
    assert_eq!(
        result
            .rows
            .iter()
            .map(|row| row.annotation.as_str())
            .collect::<Vec<_>>(),
        [
            "3' UTR",
            "Exon (minus/g, exon 2 of 2)",
            "Intron (minus/g, intron 1 of 1)",
            "5' UTR",
            "3' UTR"
        ]
    );
    let output = temp.path().join("annotation.tsv");
    let report = temp.path().join("annotation.json");
    let run_config = AnnotationRunConfig {
        peaks: bed.clone(),
        annotation: gtf.clone(),
        format: AnnotationFormat::Gtf,
        output: output.clone(),
        report: report.clone(),
        options: config,
    };
    assert!(run(&run_config, &Execution::new(NonZeroUsize::MIN)).is_err());
    assert!(!output.exists() && !report.exists());
    std::fs::write(&bed, "c\t420\t430\tx\t0\t.\nc\t420\t430\tx\t0\t.\n").unwrap();
    let completed = run(&run_config, &Execution::new(NonZeroUsize::MIN)).unwrap();
    assert_eq!(completed.rows, 2);
    let data = std::fs::read_to_string(&output).unwrap();
    assert_eq!(data.lines().count(), 3);
    assert!(data.contains("5' UTR"));
    assert!(serde_json::from_slice::<serde_json::Value>(&std::fs::read(report).unwrap()).is_ok());
    for child in ["CDS", "UTR"] {
        std::fs::write(
            &gtf,
            format!("c\tx\t{child}\t1\t10\t.\t+\t.\tgene_id \"g\"; transcript_id \"unearned\";\n"),
        )
        .unwrap();
        let error = read_graph(&gtf, AnnotationFormat::Gtf)
            .unwrap_err()
            .to_string();
        assert!(error.contains("graph.gtf:1") && error.contains("declared/exon-derived"));
    }
    std::fs::write(
        &gtf,
        "c\tx\ttranscript\t1\t100\t.\t.\t.\tgene_id \"g\"; transcript_id \"coerced\";\n",
    )
    .unwrap();
    assert_eq!(
        read_graph(&gtf, AnnotationFormat::Gtf).unwrap().transcripts[0].strand,
        Strand::Plus
    );
    std::fs::write(
        &gtf,
        "c\tx\ttranscript\t2\t100\t.\t.\t.\tgene_id \"g\"; transcript_id \"unknown\";\n",
    )
    .unwrap();
    assert!(
        read_graph(&gtf, AnnotationFormat::Gtf)
            .unwrap_err()
            .to_string()
            .contains("unknown strand")
    );
    std::fs::write(&path, "c\tx\tgene\t1\t100\t.\t+\t.\tID=g\nc\tx\tncRNA\t1\t100\t.\t+\t.\tID=z;Name=shared;Parent=g\nc\tx\tmRNA\t1\t100\t.\t+\t.\tID=a;Name=shared;Parent=g\n").unwrap();
    assert_eq!(
        read_graph(&path, AnnotationFormat::Gff3)
            .unwrap()
            .transcripts[0]
            .id,
        "z"
    );
    std::fs::write(&path, "c\tx\tgene\t1\t100\t.\t+\t.\tID=g\nc\tx\tncRNA\t1\t100\t.\t+\t.\tID=z;Name=shared;Parent=g\nc\tx\tncRNA\t1\t100\t.\t+\t.\tID=z;Name=shared;Parent=g\nc\tx\tmRNA\t1\t100\t.\t+\t.\tID=a;Name=shared;Parent=g\n").unwrap();
    assert_eq!(
        read_graph(&path, AnnotationFormat::Gff3)
            .unwrap()
            .transcripts[0]
            .id,
        "a"
    );
    std::fs::write(&path, "c\tx\tgene\t1\t100\t.\t+\t.\tID=g;Name=canonical;Dbxref=GeneID:1\nc\tx\tmRNA\t1\t100\t.\t+\t.\tID=t;Dbxref=GeneID:1;geneID=other\n").unwrap();
    assert_eq!(
        read_graph(&path, AnnotationFormat::Gff3)
            .unwrap()
            .transcripts[0]
            .gene_ids,
        ["canonical"]
    );
}
