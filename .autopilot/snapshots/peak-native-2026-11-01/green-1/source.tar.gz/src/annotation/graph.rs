use super::{
    AnnotationFormat,
    index::Indexes,
    parse::{self, GRAPH_BUDGET, Kind, Parsed, Record},
};
use crate::model::*;
use rsomics_common::{Context, Result};
use serde::Serialize;
use std::{
    collections::{BTreeMap, BTreeSet, HashMap},
    path::{Path, PathBuf},
};

#[derive(Clone, Debug, Serialize)]
pub(crate) struct CodingPart {
    pub start: u64,
    pub end: u64,
    pub phase: Option<u8>,
    pub source_line: usize,
}

#[derive(Clone, Debug, Serialize)]
pub(crate) struct Exon {
    pub start: u64,
    pub end: u64,
    pub rank: usize,
    pub source_line: usize,
    pub cds: Option<CodingPart>,
}

#[derive(Clone, Copy, Debug, Serialize)]
pub(crate) struct Region {
    pub start: u64,
    pub end: u64,
    pub rank: usize,
}

#[derive(Clone, Debug, Serialize)]
pub(crate) struct UtrEdge {
    pub start: u64,
    pub end: u64,
    pub five_prime: Option<bool>,
    pub source_line: usize,
}

#[derive(Clone, Debug, Serialize)]
pub(crate) struct Transcript {
    pub id: String,
    pub name: String,
    pub feature_type: String,
    pub span: Span,
    pub strand: Strand,
    pub gene_ids: Vec<String>,
    pub source_line: usize,
    pub exons: Vec<Exon>,
    pub cds_parts: Vec<CodingPart>,
    pub stop_codons: Vec<CodingPart>,
    pub explicit_utrs: Vec<UtrEdge>,
    pub introns: Vec<Region>,
    pub five_utrs: Vec<Region>,
    pub three_utrs: Vec<Region>,
    pub missing_name: bool,
}

impl Transcript {
    pub(super) fn tss(&self) -> u64 {
        if self.strand == Strand::Minus {
            self.span.end - 1
        } else {
            self.span.start
        }
    }
    pub(super) fn label(&self) -> String {
        let gene = if self.gene_ids.is_empty() {
            self.name.clone()
        } else {
            self.gene_ids.join(", ")
        };
        format!("{}/{gene}", self.name)
    }
}

#[derive(Debug, Serialize)]
pub(crate) struct Gene {
    pub id: String,
    pub span: Span,
    pub strand: Strand,
    pub source_line: usize,
}

#[derive(Debug)]
pub(crate) struct AnnotationGraph {
    pub dictionary: ChromDictionary,
    pub transcripts: Vec<Transcript>,
    pub genes: Vec<Gene>,
    pub notices: BTreeMap<String, usize>,
    pub(super) indexes: Indexes,
    pub(super) memory: usize,
    pub(super) source: PathBuf,
}

#[derive(Clone)]
struct Part {
    span: Span,
    strand: Strand,
    phase: Option<u8>,
    line: usize,
}

impl From<&Record> for Part {
    fn from(row: &Record) -> Self {
        Self {
            span: row.span,
            strand: row.strand,
            phase: row.phase,
            line: row.line,
        }
    }
}

struct Builder {
    id: String,
    name: String,
    feature_type: String,
    missing_name: bool,
    declared: bool,
    span: Span,
    strand: Strand,
    line: usize,
    genes: BTreeSet<String>,
    exons: Vec<Part>,
    cds: Vec<Part>,
    stops: Vec<Part>,
    utrs: Vec<UtrEdge>,
}

impl Builder {
    fn new(row: &Record, id: String, name: String, missing_name: bool, declared: bool) -> Self {
        Self {
            id,
            name,
            feature_type: if declared {
                row.feature_type.clone()
            } else {
                "inferred_from_exon".into()
            },
            missing_name,
            declared,
            span: row.span,
            strand: row.strand,
            line: row.line,
            genes: BTreeSet::new(),
            exons: Vec::new(),
            cds: Vec::new(),
            stops: Vec::new(),
            utrs: Vec::new(),
        }
    }
    fn add(&mut self, row: &Record, kind: Kind) -> Result<()> {
        if row.span.chrom != self.span.chrom || row.strand != self.strand {
            return Err(invalid(format!(
                "transcript {} has conflicting chromosome or strand",
                self.id
            )));
        }
        if kind == Kind::Transcript {
            if self.declared && row.feature_type != self.feature_type {
                return Err(invalid(format!(
                    "transcript {} has conflicting multipart type",
                    self.id
                )));
            }
            if !self.declared {
                self.span = row.span;
                self.feature_type = row.feature_type.clone();
            } else {
                self.span.start = self.span.start.min(row.span.start);
                self.span.end = self.span.end.max(row.span.end);
            }
            self.declared = true;
        } else {
            if !self.declared {
                self.span.start = self.span.start.min(row.span.start);
                self.span.end = self.span.end.max(row.span.end);
            }
            match kind {
                Kind::Exon => self.exons.push(row.into()),
                Kind::Cds => self.cds.push(row.into()),
                Kind::Stop => self.stops.push(row.into()),
                Kind::FiveUtr | Kind::ThreeUtr | Kind::Utr => self.utrs.push(UtrEdge {
                    start: row.span.start,
                    end: row.span.end,
                    five_prime: match kind {
                        Kind::FiveUtr => Some(true),
                        Kind::ThreeUtr => Some(false),
                        _ => None,
                    },
                    source_line: row.line,
                }),
                _ => return Err(invalid("unsupported transcript child type")),
            }
        }
        Ok(())
    }
}

fn coding(part: &Part) -> CodingPart {
    CodingPart {
        start: part.span.start,
        end: part.span.end,
        phase: part.phase,
        source_line: part.line,
    }
}

fn normalize(mut tx: Builder, notices: &mut BTreeMap<String, usize>) -> Result<Transcript> {
    if tx.strand == Strand::Unknown {
        return Err(invalid(format!(
            "transcript {} has unknown strand outside the source coercion boundary",
            tx.id
        )));
    }
    if tx.exons.is_empty() {
        if tx.cds.is_empty() {
            tx.exons.push(Part {
                span: tx.span,
                strand: tx.strand,
                phase: None,
                line: tx.line,
            });
        } else {
            tx.exons.clone_from(&tx.cds);
        }
        *notices
            .entry("transcripts with inferred exons".into())
            .or_insert(0) += 1;
    }
    tx.exons
        .sort_by_key(|part| (part.span.start, part.span.end, part.line));
    let mut last_end = tx.span.start;
    let mut introns = Vec::new();
    for exon in &tx.exons {
        if exon.span.start < tx.span.start
            || exon.span.end > tx.span.end
            || exon.span.start < last_end
        {
            return Err(invalid(format!(
                "transcript {} has overlapping or out-of-span exons at line{}",
                tx.id, exon.line
            )));
        }
        if exon.span.start > last_end {
            introns.push(Region {
                start: last_end,
                end: exon.span.start,
                rank: 0,
            });
        }
        last_end = exon.span.end;
    }
    if last_end < tx.span.end {
        introns.push(Region {
            start: last_end,
            end: tx.span.end,
            rank: 0,
        });
    }
    let total_introns = introns.len();
    for (i, intron) in introns.iter_mut().enumerate() {
        intron.rank = if tx.strand == Strand::Minus {
            total_introns - i
        } else {
            i + 1
        };
    }
    let mut exons = tx
        .exons
        .iter()
        .map(|part| Exon {
            start: part.span.start,
            end: part.span.end,
            rank: 0,
            source_line: part.line,
            cds: None,
        })
        .collect::<Vec<_>>();
    let mut stops = vec![None; exons.len()];
    for (parts, is_stop) in [(&tx.cds, false), (&tx.stops, true)] {
        for part in parts {
            if part.strand != tx.strand || part.span.chrom != tx.span.chrom {
                return Err(invalid(format!(
                    "transcript {} has incompatible coding strand/chromosome",
                    tx.id
                )));
            }
            let index = exons
                .partition_point(|exon| exon.start <= part.span.start)
                .checked_sub(1)
                .filter(|&i| part.span.end <= exons[i].end)
                .ok_or_else(|| {
                    invalid(format!(
                        "transcript {} coding part line{} is not contained in one exon",
                        tx.id, part.line
                    ))
                })?;
            let slot = if is_stop {
                &mut stops[index]
            } else {
                &mut exons[index].cds
            };
            if slot.is_none() {
                *slot = Some(coding(part));
            } else {
                *notices.entry("additional same-exon coding parts retained in graph; first used for source splicing".into()).or_insert(0) += 1;
            }
        }
    }
    for (exon, stop) in exons.iter_mut().zip(stops) {
        if let Some(stop) = stop {
            if let Some(cds) = &mut exon.cds {
                if stop.start > cds.end || cds.start > stop.end {
                    return Err(invalid(format!(
                        "transcript {} has disjoint CDS and stop codon in an exon",
                        tx.id
                    )));
                }
                if (tx.strand == Strand::Plus && stop.start < cds.start)
                    || (tx.strand == Strand::Minus && stop.end > cds.end)
                {
                    cds.phase = Some(0);
                }
                cds.start = cds.start.min(stop.start);
                cds.end = cds.end.max(stop.end);
            } else {
                exon.cds = Some(CodingPart {
                    phase: Some(0),
                    ..stop
                });
            }
        }
    }
    for utr in &tx.utrs {
        if !exons
            .iter()
            .any(|exon| exon.start <= utr.start && utr.end <= exon.end)
        {
            return Err(invalid(format!(
                "transcript {} explicit UTR line{} is not exonic",
                tx.id, utr.source_line
            )));
        }
    }
    if tx.strand == Strand::Minus {
        exons.reverse();
    }
    for (i, exon) in exons.iter_mut().enumerate() {
        exon.rank = i + 1;
    }
    let mut five_utrs = Vec::new();
    let mut three_utrs = Vec::new();
    if let (Some(first), Some(last)) = (
        exons.iter().position(|exon| exon.cds.is_some()),
        exons.iter().rposition(|exon| exon.cds.is_some()),
    ) {
        for (i, exon) in exons.iter().enumerate() {
            if i <= first {
                let mut region = Region {
                    start: exon.start,
                    end: exon.end,
                    rank: exon.rank,
                };
                if let Some(cds) = &exon.cds {
                    if tx.strand == Strand::Plus {
                        region.end = cds.start;
                    } else {
                        region.start = cds.end;
                    }
                }
                if region.start < region.end {
                    five_utrs.push(region);
                }
            }
            if i >= last {
                let mut region = Region {
                    start: exon.start,
                    end: exon.end,
                    rank: exon.rank,
                };
                if let Some(cds) = &exon.cds {
                    if tx.strand == Strand::Plus {
                        region.start = cds.end;
                    } else {
                        region.end = cds.start;
                    }
                }
                if region.start < region.end {
                    three_utrs.push(region);
                }
            }
        }
    }
    Ok(Transcript {
        id: tx.id,
        name: tx.name,
        feature_type: tx.feature_type,
        span: tx.span,
        strand: tx.strand,
        gene_ids: tx.genes.into_iter().collect(),
        source_line: tx.line,
        exons,
        cds_parts: tx.cds.iter().map(coding).collect(),
        stop_codons: tx.stops.iter().map(coding).collect(),
        explicit_utrs: tx.utrs,
        introns,
        five_utrs,
        three_utrs,
        missing_name: tx.missing_name,
    })
}

fn gtf(parsed: &Parsed, path: &Path) -> Result<Vec<Builder>> {
    let mut builders = BTreeMap::<String, Builder>::new();
    let mut gene_rows = BTreeMap::new();
    for row in &parsed.records {
        if row.kind == Kind::Other {
            continue;
        }
        let context = || format!("{}:{}", path.display(), row.line);
        let gene = row
            .gene_id
            .as_ref()
            .ok_or_else(|| invalid(format!("{}: GTF feature lacks gene_id", context())))?;
        if row.kind == Kind::Gene {
            gene_rows.insert(gene.clone(), row);
            continue;
        }
        if !matches!(row.kind, Kind::Transcript | Kind::Exon) {
            continue;
        }
        let id = row
            .transcript_id
            .as_ref()
            .ok_or_else(|| invalid(format!("{}: GTF feature lacks transcript_id", context())))?;
        let builder = builders.entry(id.clone()).or_insert_with(|| {
            Builder::new(
                row,
                id.clone(),
                id.clone(),
                false,
                row.kind == Kind::Transcript,
            )
        });
        builder.genes.insert(gene.clone());
        builder.add(row, row.kind).rs_with_context(context)?;
    }
    let assigned = builders
        .values()
        .flat_map(|tx| &tx.genes)
        .cloned()
        .collect::<BTreeSet<_>>();
    for (gene, row) in gene_rows {
        if !assigned.contains(&gene) {
            return Err(invalid(format!(
                "{}:{}: gene-only GTF graph {gene} is unsupported; provide declared transcripts or exon edges",
                path.display(),
                row.line
            )));
        }
    }
    for row in &parsed.records {
        if matches!(
            row.kind,
            Kind::Gene | Kind::Transcript | Kind::Exon | Kind::Other
        ) {
            continue;
        }
        let context = || format!("{}:{}", path.display(), row.line);
        let id = row
            .transcript_id
            .as_ref()
            .ok_or_else(|| invalid(format!("{}: GTF child lacks transcript_id", context())))?;
        let builder = builders.get_mut(id).ok_or_else(|| invalid(format!("{}: GTF child {id} lacks a declared/exon-derived transcript; CDS/UTR-only inference is unsupported", context())))?;
        if let Some(gene) = &row.gene_id {
            builder.genes.insert(gene.clone());
        }
        builder.add(row, row.kind).rs_with_context(context)?;
    }
    Ok(builders.into_values().collect())
}

fn prepare_transcripts(parsed: &mut Parsed, format: AnnotationFormat) -> bool {
    let gene_parents = if matches!(format, AnnotationFormat::Gff3) {
        parsed
            .records
            .iter()
            .filter(|row| matches!(row.kind, Kind::Exon | Kind::Cds))
            .flat_map(|row| row.parents.iter().cloned())
            .collect::<BTreeSet<_>>()
    } else {
        BTreeSet::new()
    };
    let indices = parsed
        .records
        .iter()
        .enumerate()
        .filter(|(_, row)| {
            row.kind == Kind::Transcript
                || (row.kind == Kind::Gene
                    && row.id.as_ref().is_some_and(|id| gene_parents.contains(id)))
        })
        .map(|(i, _)| i)
        .collect::<Vec<_>>();
    let mut logical = HashMap::<&str, (ChromId, u64, bool, usize)>::new();
    for &index in &indices {
        let row = &parsed.records[index];
        let id = match format {
            AnnotationFormat::Gtf => row.transcript_id.as_deref(),
            AnnotationFormat::Gff3 => row.id.as_deref(),
        };
        if let Some(id) = id {
            let entry = logical
                .entry(id)
                .or_insert((row.span.chrom, row.span.start, true, 0));
            entry.1 = entry.1.min(row.span.start);
            entry.2 &= row.strand == Strand::Unknown && entry.0 == row.span.chrom;
            entry.3 += 1;
        }
    }
    let character_types = logical.is_empty() || logical.values().any(|entry| entry.3 > 1);
    let coerce = !logical.is_empty()
        && logical.values().all(|entry| entry.1 == 0 && entry.2)
        && logical
            .values()
            .map(|entry| entry.0.0)
            .collect::<BTreeSet<_>>()
            .len()
            == logical.len();
    if coerce {
        for index in indices {
            parsed.records[index].strand = Strand::Plus;
        }
    }
    character_types
}

struct NameRule {
    has_names: bool,
    colon_prefix: bool,
    dash_prefix: bool,
}

fn name_rules(records: &[Record]) -> HashMap<&str, NameRule> {
    let mut rules = HashMap::<&str, NameRule>::new();
    for row in records {
        let rule = rules.entry(&row.feature_type).or_insert(NameRule {
            has_names: false,
            colon_prefix: true,
            dash_prefix: true,
        });
        rule.has_names |= row.name.is_some();
        if let Some(id) = &row.id {
            rule.colon_prefix &= id
                .strip_prefix(&row.feature_type)
                .is_some_and(|tail| tail.starts_with(':'));
            rule.dash_prefix &= id
                .strip_prefix(&row.feature_type)
                .is_some_and(|tail| tail.starts_with('-'));
        }
    }
    rules
}

fn inferred_name(row: &Record, rules: &HashMap<&str, NameRule>) -> (String, bool) {
    if let Some(name) = &row.name {
        return (name.clone(), false);
    }
    let rule = &rules[row.feature_type.as_str()];
    if rule.has_names {
        return ("NA".into(), true);
    }
    let Some(id) = &row.id else {
        return ("NA".into(), true);
    };
    if rule.colon_prefix || rule.dash_prefix {
        return (id[row.feature_type.len() + 1..].into(), false);
    }
    (id.clone(), false)
}

fn gff(parsed: &Parsed, path: &Path) -> Result<Vec<Builder>> {
    let rows = &parsed.records;
    let rules = name_rules(rows);
    let mut ids = HashMap::<&str, Vec<usize>>::new();
    for (i, row) in rows.iter().enumerate() {
        if let Some(id) = &row.id {
            ids.entry(id).or_default().push(i);
        }
    }
    let mut edges = vec![Vec::new(); rows.len()];
    let mut edge_bytes = parsed.memory;
    for (i, row) in rows.iter().enumerate() {
        let parts = row
            .id
            .as_ref()
            .map(|id| ids[id.as_str()].as_slice())
            .unwrap_or(std::slice::from_ref(&i));
        if parts[0] != i {
            continue;
        }
        let mut parents = BTreeSet::new();
        for &part in parts {
            let other = &rows[part];
            if other.kind != row.kind
                || other.span.chrom != row.span.chrom
                || other.strand != row.strand
            {
                return Err(invalid(format!(
                    "{}:{}: conflicting multipart GFF3 ID {:?}",
                    path.display(),
                    row.line,
                    row.id
                )));
            }
            for parent in &other.parents {
                let index = ids
                    .get(parent.as_str())
                    .and_then(|values| values.first())
                    .ok_or_else(|| {
                        invalid(format!(
                            "{}:{}: absent GFF3 Parent {parent}",
                            path.display(),
                            row.line
                        ))
                    })?;
                parents.insert(*index);
            }
        }
        edge_bytes = edge_bytes
            .checked_add((parents.len() * 16 + 24) * parts.len())
            .ok_or_else(|| invalid("annotation parent graph size overflows"))?;
        if edge_bytes > GRAPH_BUDGET {
            return Err(invalid(
                "annotation parent graph exceeds512MiB admission budget",
            ));
        }
        let parents = parents.into_iter().collect::<Vec<_>>();
        for &part in parts {
            edges[part].clone_from(&parents);
        }
    }
    let mut color = vec![0u8; rows.len()];
    for start in 0..rows.len() {
        if color[start] != 0 {
            continue;
        }
        let mut stack = vec![(start, false, 0usize)];
        while let Some((node, exit, depth)) = stack.pop() {
            if exit {
                color[node] = 2;
                continue;
            }
            if color[node] == 1 {
                return Err(invalid(format!(
                    "{}:{}: GFF3 Parent cycle",
                    path.display(),
                    rows[node].line
                )));
            }
            if color[node] == 2 {
                continue;
            }
            color[node] = 1;
            stack.push((node, true, depth));
            if depth > 1024 {
                return Err(invalid(format!(
                    "{}:{}: GFF3 parent depth exceeds admission limit",
                    path.display(),
                    rows[node].line
                )));
            }
            for &parent in edges[node].iter().rev() {
                stack.push((parent, false, depth + 1));
            }
        }
    }
    let mut is_tx = rows
        .iter()
        .map(|row| row.kind == Kind::Transcript)
        .collect::<Vec<_>>();
    for (i, row) in rows.iter().enumerate() {
        if matches!(row.kind, Kind::Exon | Kind::Cds) {
            for &parent in &edges[i] {
                if rows[parent].kind == Kind::Gene {
                    is_tx[parent] = true;
                }
            }
        }
    }
    let gene_rows = rows
        .iter()
        .filter(|row| row.kind == Kind::Gene)
        .collect::<Vec<_>>();
    let use_gene_attr = gene_rows.iter().all(|row| row.gene_id.is_some());
    let use_gene_names = gene_rows.iter().all(|row| !inferred_name(row, &rules).1);
    let mut gene_labels = HashMap::new();
    let mut label_ids = HashMap::<String, &str>::new();
    let mut ambiguous = false;
    for row in &gene_rows {
        let id = row.id.as_ref().ok_or_else(|| {
            invalid(format!(
                "{}:{}: GFF3 gene lacks ID",
                path.display(),
                row.line
            ))
        })?;
        let label = if use_gene_attr {
            row.gene_id.clone().unwrap()
        } else if use_gene_names {
            inferred_name(row, &rules).0
        } else {
            id.strip_prefix("gene:")
                .or_else(|| id.strip_prefix("gene-"))
                .unwrap_or(id)
                .into()
        };
        ambiguous |= label_ids
            .insert(label.clone(), id)
            .is_some_and(|old| old != id);
        gene_labels.insert(id.as_str(), label);
    }
    if ambiguous {
        for row in &gene_rows {
            let id = row.id.as_ref().unwrap();
            gene_labels.insert(
                id.as_str(),
                id.strip_prefix("gene:")
                    .or_else(|| id.strip_prefix("gene-"))
                    .unwrap_or(id)
                    .into(),
            );
        }
    }
    let use_tx_attr = rows.iter().any(|row| row.transcript_id.is_some());
    let mut builders = BTreeMap::<String, Builder>::new();
    for (i, row) in rows.iter().enumerate().filter(|(i, _)| is_tx[*i]) {
        let id = row.id.as_ref().ok_or_else(|| {
            invalid(format!(
                "{}:{}: GFF3 transcript lacks ID",
                path.display(),
                row.line
            ))
        })?;
        let (name, missing) = if use_tx_attr {
            (
                row.transcript_id.clone().unwrap_or_else(|| "NA".into()),
                row.transcript_id.is_none(),
            )
        } else {
            inferred_name(row, &rules)
        };
        let builder = builders
            .entry(id.clone())
            .or_insert_with(|| Builder::new(row, id.clone(), name.clone(), missing, true));
        if builder.name != name || builder.missing_name != missing {
            return Err(invalid(format!(
                "{}:{}: multipart transcript has conflicting name",
                path.display(),
                row.line
            )));
        }
        if row.kind == Kind::Transcript {
            builder
                .add(row, Kind::Transcript)
                .rs_with_context(|| format!("{}:{}", path.display(), row.line))?;
        }
        if row.kind == Kind::Gene {
            builder.genes.insert(gene_labels[id.as_str()].clone());
        }
        for &parent in &edges[i] {
            let p = &rows[parent];
            if p.kind != Kind::Gene {
                return Err(invalid(format!(
                    "{}:{}: transcript Parent is not a gene",
                    path.display(),
                    row.line
                )));
            }
            builder
                .genes
                .insert(gene_labels[p.id.as_deref().unwrap()].clone());
        }
        if builder.genes.is_empty() {
            if !row.dbxref.is_empty() {
                for gene in &gene_rows {
                    if row.dbxref.iter().any(|item| gene.dbxref.contains(item)) {
                        builder
                            .genes
                            .insert(gene_labels[gene.id.as_deref().unwrap()].clone());
                    }
                }
            }
            if builder.genes.is_empty()
                && let Some(gene) = &row.external_gene
            {
                builder.genes.insert(gene.clone());
            }
        }
    }
    for (i, row) in rows.iter().enumerate() {
        if matches!(row.kind, Kind::Gene | Kind::Transcript | Kind::Other) {
            continue;
        }
        let mut targets = BTreeSet::new();
        for &parent in &edges[i] {
            if is_tx[parent] {
                targets.insert(parent);
            } else if rows[parent].kind == Kind::Exon
                && matches!(
                    row.kind,
                    Kind::Cds | Kind::Stop | Kind::FiveUtr | Kind::ThreeUtr | Kind::Utr
                )
            {
                for &tx in &edges[parent] {
                    if is_tx[tx] {
                        targets.insert(tx);
                    } else {
                        return Err(invalid(format!(
                            "{}:{}: exon parent is not a transcript",
                            path.display(),
                            row.line
                        )));
                    }
                }
            } else {
                return Err(invalid(format!(
                    "{}:{}: unsupported {:?} parent type {}",
                    path.display(),
                    row.line,
                    row.kind,
                    rows[parent].feature_type
                )));
            }
        }
        if targets.is_empty() {
            return Err(invalid(format!(
                "{}:{}: orphan {:?} feature",
                path.display(),
                row.line,
                row.kind
            )));
        }
        for target in targets {
            let id = rows[target].id.as_ref().unwrap();
            edge_bytes = edge_bytes
                .checked_add(320)
                .ok_or_else(|| invalid("expanded annotation edges overflow"))?;
            if edge_bytes > GRAPH_BUDGET {
                return Err(invalid(format!(
                    "{}:{}: expanded annotation edges exceed512MiB admission budget",
                    path.display(),
                    row.line
                )));
            }
            builders
                .get_mut(id)
                .unwrap()
                .add(row, row.kind)
                .rs_with_context(|| format!("{}:{}", path.display(), row.line))?;
        }
    }
    Ok(builders.into_values().collect())
}

pub(crate) fn read_graph(path: &Path, format: AnnotationFormat) -> Result<AnnotationGraph> {
    let mut parsed = parse::read(path, format)?;
    let character_types = prepare_transcripts(&mut parsed, format);
    let builders = match format {
        AnnotationFormat::Gtf => gtf(&parsed, path)?,
        AnnotationFormat::Gff3 => gff(&parsed, path)?,
    };
    let mut transcripts = Vec::new();
    let mut memory = parsed.memory;
    for builder in builders {
        memory = memory
            .checked_add(
                512 + builder.id.len()
                    + builder.name.len()
                    + builder
                        .genes
                        .iter()
                        .map(|gene| gene.len() + 32)
                        .sum::<usize>()
                    + (builder.exons.len()
                        + builder.cds.len()
                        + builder.stops.len()
                        + builder.utrs.len())
                        * 320,
            )
            .ok_or_else(|| invalid("annotation graph size overflows"))?;
        if memory > GRAPH_BUDGET {
            return Err(invalid(format!(
                "{}: normalized graph exceeds512MiB admission budget",
                path.display()
            )));
        }
        let line = builder.line;
        transcripts.push(
            normalize(builder, &mut parsed.notices)
                .rs_with_context(|| format!("{}:{line}", path.display()))?,
        );
    }
    if transcripts.is_empty() {
        return Err(invalid(format!(
            "{}: annotation contains no supported transcripts",
            path.display()
        )));
    }
    let strand_rank = |strand| match strand {
        Strand::Plus => 0,
        Strand::Minus => 1,
        Strand::Unknown => 2,
    };
    let mut type_ranks = HashMap::<String, usize>::new();
    if character_types {
        for name in transcripts
            .iter()
            .map(|tx| tx.feature_type.clone())
            .collect::<BTreeSet<_>>()
        {
            let next = type_ranks.len();
            type_ranks.insert(name, next);
        }
    } else {
        for name in parsed
            .records
            .iter()
            .map(|row| &row.feature_type)
            .chain(transcripts.iter().map(|tx| &tx.feature_type))
        {
            let next = type_ranks.len();
            type_ranks.entry(name.clone()).or_insert(next);
        }
    }
    transcripts.sort_by(|a, b| {
        (
            a.span.chrom.0,
            strand_rank(a.strand),
            a.span.start,
            a.span.end,
            a.missing_name,
            &a.name,
            type_ranks[&a.feature_type],
            a.source_line,
        )
            .cmp(&(
                b.span.chrom.0,
                strand_rank(b.strand),
                b.span.start,
                b.span.end,
                b.missing_name,
                &b.name,
                type_ranks[&b.feature_type],
                b.source_line,
            ))
    });
    let mut genes = BTreeMap::<String, Gene>::new();
    for tx in &transcripts {
        for id in &tx.gene_ids {
            let gene = genes.entry(id.clone()).or_insert_with(|| Gene {
                id: id.clone(),
                span: tx.span,
                strand: tx.strand,
                source_line: tx.source_line,
            });
            if gene.span.chrom != tx.span.chrom || gene.strand != tx.strand {
                return Err(invalid(format!(
                    "{}:{}: gene {id} has incompatible transcript chromosome/strand",
                    path.display(),
                    tx.source_line
                )));
            }
            gene.span.start = gene.span.start.min(tx.span.start);
            gene.span.end = gene.span.end.max(tx.span.end);
        }
    }
    let projected_index = transcripts
        .iter()
        .try_fold(0usize, |sum, tx| {
            sum.checked_add(
                512 + tx.gene_ids.len() * 256
                    + (tx.exons.len()
                        + tx.introns.len()
                        + tx.five_utrs.len()
                        + tx.three_utrs.len())
                        * 128,
            )
        })
        .ok_or_else(|| invalid("annotation index storage overflows"))?;
    if memory
        .checked_add(projected_index)
        .is_none_or(|n| n > GRAPH_BUDGET)
    {
        return Err(invalid(format!(
            "{}: projected annotation indexes exceed512MiB admission budget",
            path.display()
        )));
    }
    let indexes = Indexes::new(&transcripts, parsed.dictionary.chromosomes.len());
    memory = memory
        .checked_add(indexes.memory())
        .ok_or_else(|| invalid("annotation index size overflows"))?;
    if memory > GRAPH_BUDGET {
        return Err(invalid(format!(
            "{}: annotation indexes exceed512MiB admission budget",
            path.display()
        )));
    }
    Ok(AnnotationGraph {
        dictionary: parsed.dictionary,
        transcripts,
        genes: genes.into_values().collect(),
        notices: parsed.notices,
        indexes,
        memory,
        source: path.into(),
    })
}
