# Attribution scope

The count operation is an independent native implementation of the declared
bedtools2.31.1 multicov behavior. bedtools is Copyright Aaron Quinlan and the Hall
Laboratory, licensed GPL-2.0. Those source bodies were inspected as an oracle;
their code is not incorporated into this differently licensed implementation.
See https://github.com/arq5x/bedtools2/tree/v2.31.1 .

Historical rsomics code is team-owned and may be reused under project policy.
The internal guard comes from rsomics-signal; the count donor is a behavioral/
geometry reference rather than a copied CLI or removed public API. Published
Rust dependencies retain their own licenses and notices. No source runtime,
scientific interpreter, raw source corpus or upstream executable is bundled.

Caller adaptations retain the complete MACS3.1.0 BSD3 notice in
src/call/UPSTREAM.md; that notice must accompany source and binary distributions.
The sparse implementation uses SEACR1.3 and base-R4.6.1 as behavior references
without incorporating their GPL source or runtime. Annotation similarly uses
ChIPseeker/txdbmaker and GenomicRanges/GenomicFeatures as behavior references,
not bundled R code. Team ownership of retired rsomics code is not a blanket
relicensing claim for independently inspected upstream packages.
