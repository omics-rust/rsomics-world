# rsomics-peak

Private, unpublished native peak-workflow implementation. The current functioning
CLI operations are `call`, `call-sparse`, `annotate` and `count`. The connected
native workflow and retained engineering-source comparisons pass locally;
four-platform, representative performance and release qualification are still
pending. There is no public remote or placeholder command.

```text
rsomics-peak call --treatment T1.bam T2.bam --control C1.bam C2.bam \
  --format bampe --model paired-end --genome-size 20000000 --name pooled \
  --output-directory results --write-tracks --threads 4
rsomics-peak annotate --peaks peaks.bed --annotation genes.gff3 --format gff3 \
  --output annotated.tsv --report annotation.json --threads 4
```

Calling supports narrow BAM/BAMPE peaks, pooled inputs, explicit duplicate
limits/auto/all, P/Q scoring, local control and scaling. Single-end BAM defaults
to a fitted model (bandwidth300, mfold5/50, minimum d20); fixed extension and
paired-end models are explicit. An optional fit fallback is never automatic.
Model-only options cannot be silently ignored under a different model. Outputs
and the model/admission/worker report publish together; the output directory must
already exist. Broad peaks, extra formats, subpeak calling and plots are outside
this slice. Per-contig work is bounded; global q adjustment is shared across
chromosomes, not performed independently per worker.

Annotation builds a transcript-level GTF/GFF3 graph before ordered indexed
assignment. Nearest transcript/distance, feature category and detail masks are
distinct. Default TSS and downstream windows are3000 bases and configurable;
category priority is fixed. Exact peak contigs must exist in the gene-associated
graph; unused annotation contigs are allowed. Gene-only/CDS-only GTF inference,
gene aggregation and chromosome aliases are unsupported rather than guessed.

```text
rsomics-peak count --peaks peaks.bed --sample T1=treatment1.bam T2=treatment2.bam \
  --output counts.tsv --report counts.json --threads 4
```

Counts are alignments, not fragments. By default unmapped, duplicate-bit and
QC-failed records are excluded, while secondary and supplementary alignments are
eligible. `--min-mapq`, `--proper-pairs-only`, `--include-duplicates`,
`--include-qc-failed` and `--split` are independent selectors. Proper pairing does
not collapse mates. Split geometry breaks at N, not D, and one alignment counts
at most once per peak row even when several aligned blocks overlap it.

Peak rows retain order, original fields and duplicate identities. Input supports
consistent-width BED3 through BED11, including narrowPeak; BED12 is explicitly
unsupported. Missing BAM contigs yield zero rows and a report counter; conflicting
lengths for an exact shared chromosome name are errors. There is no implicit
chromosome aliasing or fragment-count mode. Both sample column order and row
order are stable.

Count performs bounded parallel sample scans with one serial BAM inflater per
worker. Effective workers are min(samples,requested), not an assertion that four
cores are useful for a single sample. Count cells plus the peak index are checked
against the private512MiB invocation allocation budget. Data and report stage
together through common recoverable grouped atomic publication. Errors do not
replace existing outputs. Prospective sibling names are checked on the actual
output filesystem before staging, so case-folding aliases fail without replacing
data; truly distinct case-sensitive names remain valid. Global `--json` uses
the shared machine envelope.

Development requires the external-only guard and the reviewed69-file portable
fixture root from rsomics-world. It contains `inputs/`, `witness/` and mandatory
`addon/` from the two accepted source runs41209740891 and41228249024. Set
`RSOMICS_PEAK_FIXTURES`, `RSOMICS_PEAK_ORACLE` and `RSOMICS_PEAK_SOURCE_FIXTURE`
to that root, and `RSOMICS_PEAK_SOURCE_CALLS` to its `witness/calls` directory.
Run `bash scripts/guarded-cargo.sh test --locked -- --include-ignored` for the
complete source suite; absent required fixtures fail rather than silently skip.
Tests retain all original views plus actual both-strand feature categories and
independent count-filter effects. No upstream executable is launched locally.
The connected CLI test derives both call/sparse row ledgers from actual new
native outputs, then annotates and counts them without substituting source peaks.

`call-sparse` requires exactly one `--control` or `--fraction`, explicit
`--normalization norm|non`, `--mode stringent|relaxed`, and REQUIRED
`--compatibility seacr-1.3|corrected`. There is no inferred profile/default.
It publishes its six-field peak BED and report together. The SEACR six-field
format is not BED6: coordinate row ledgers must explicitly supply stable labels
and a strand column before annotation/count. The connected native test builds
that ledger from actual new native sparse outputs, not imported source answers.
`seacr-1.3` reproduces upstream initial-row, terminal-block and final-merge
omissions. `corrected` retains all valid input rows and terminal blocks. These
profiles can produce different peaks; neither is an inferred default.

One whole-product review and its three material corrections are closed locally.
Same-native-file source interoperability, actual native-four, representative
performance and publication remain future gates. Sparse default policy remains
human-held; explicit profiles allow the functioning workflow to proceed.
