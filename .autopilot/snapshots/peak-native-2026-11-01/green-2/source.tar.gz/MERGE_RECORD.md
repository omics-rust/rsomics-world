# Implementation provenance

- `scripts/guarded-cargo.sh`: direct internal reuse/refinement of team-owned
  rsomics-signal/scripts/guarded-cargo.sh. Retains physical external-volume,
  resolved Cargo target, rustup/TMP/cache checks; adds explicit unsupported wrapper/
  target/compiler-flag rejection. No source-program wrapper is used at runtime.
- Retired `rsomics-peak-count` source, historical head
  147ed9b4a3d2d58210d28b8be268ac25bd537b07: inspected as refactor/reference asset,
  not revived or depended on. Its removed public IntervalIndex/Set APIs,
  coordinate HashMap row collapse, unconditional secondary/supplementary skips and
  swallowed CIGAR errors are deliberately NOT reused. New count/index/CLI/output
  code is product-owned against actual published foundation contracts.
- bedtools2.31.1 multiBamCov.cpp, multiBamCovMain.cpp and BlockedIntervals.cpp:
  primary behavioral reference only; no GPL source code copied. Exact filter,
  default1E-9 float stage, N-only split and per-alignment/row semantics inform the
  implementation. Selected original regular source members were independently
  hash-checked against adopted source inventory in the external evidence packet.
- Source authority: unchanged run41209740891 original four count outputs and
  count-unit observations; proposed/failed addon rows are not accepted truth.
  Hand-authored native boundary assertions are labelled native invariants, not
  fabricated upstream captures.
- Published registry dependencies only: common0.12.3,help0.4.0,bamio0.8.4,
  intervals0.4.0 and normal external Rust dependencies. Actual Cargo.lock is
  owner-local; no LayerB/path dependency or public foundation addition.

- Caller: team-owned retired rsomics-macs assets refactored into product-local
  alignments/model/pileup/scoring/output modules against current MACS3.1.0,
  not old approximate goldens. Full BSD3 source notice and exact primary source
  identity are retained in src/call/UPSTREAM.md. Raw sequence size, final treatment
  parser mean and pooled fragment mean remain distinct source states.
- Sparse: inspected team-owned rsomics-seacr as an implementation/reference
  asset; implemented current SEACR1.3 and base-R4.6.1 density/threshold behavior
  in native Rust. R/SEACR GPL source is a behavioral oracle, not incorporated
  code or runtime. Required explicit legacy/corrected profiles distinguish
  source losses from intentional endpoint repairs; no default is inferred.
- Annotation: retired team-owned seeds were reference/refactor assets, not
  source answers. New typed graph/index/assignment follows inspected
  ChIPseeker1.48.0, txdbmaker1.8.0 and GenomicRanges/GenomicFeatures1.64.0
  source behavior; no R runtime or package source is incorporated.

All four native operations now function in one connected private CLI. Complete
engineering-source comparisons are additional evidence, not a performance,
four-host, biological-validity or publication claim.
