use std::{fs, path::PathBuf, process::Command};

fn execute(command: &mut Command) {
    let result = command.output().unwrap();
    assert!(
        result.status.success(),
        "{}",
        String::from_utf8_lossy(&result.stderr)
    );
}

fn product() -> Command {
    Command::new(env!("CARGO_BIN_EXE_rsomics-peak"))
}

#[test]
fn native_calls_and_sparse_rows_feed_annotation_and_alignment_counts() {
    execute(product().args(["call", "--shift", "-10", "--help"]));
    let fixture = std::env::var_os("RSOMICS_PEAK_FIXTURES").map(PathBuf::from).unwrap_or_else(||
        "/Volumes/Zane's HDD/rsomics-fixtures/evidence/peak-first-workflow-oracle-2026-10-31/run-41209740891/selected".into());
    let scratch = tempfile::Builder::new()
        .prefix("peak-whole-native-")
        .tempdir()
        .unwrap();
    let root = scratch.path();
    let alignments = fixture.join("inputs/alignments");
    execute(
        product()
            .arg("call")
            .arg("--treatment")
            .arg(alignments.join("T1.pe.bam"))
            .arg(alignments.join("T2.pe.bam"))
            .arg("--control")
            .arg(alignments.join("C1.pe.bam"))
            .arg(alignments.join("C2.pe.bam"))
            .args([
                "--format",
                "bampe",
                "--model",
                "paired-end",
                "--genome-size",
                "20000000",
                "--name",
                "native",
                "--write-tracks",
                "--threads",
                "4",
            ])
            .arg("--output-directory")
            .arg(root),
    );
    let called = root.join("native_peaks.narrowPeak");
    let call_report: serde_json::Value =
        serde_json::from_slice(&fs::read(root.join("native_call.json")).unwrap()).unwrap();
    assert_eq!(call_report["peak_count"], 400);
    assert_eq!(call_report["workers_used"], 2);

    let sparse = root.join("native-sparse.bed");
    let sparse_report = root.join("sparse.json");
    execute(
        product()
            .arg("call-sparse")
            .arg("--target")
            .arg(root.join("native_treat_pileup.bdg"))
            .args([
                "--fraction",
                "0.1",
                "--normalization",
                "non",
                "--mode",
                "stringent",
                "--compatibility",
                "corrected",
                "--threads",
                "4",
            ])
            .arg("--output")
            .arg(&sparse)
            .arg("--report")
            .arg(&sparse_report),
    );
    let sparse_state: serde_json::Value =
        serde_json::from_slice(&fs::read(&sparse_report).unwrap()).unwrap();
    assert!(sparse_state["peaks"].as_u64().unwrap() > 0);

    let mut ledger_rows = Vec::new();
    for (origin, path) in [("call", &called), ("sparse", &sparse)] {
        for (ordinal, line) in fs::read_to_string(path).unwrap().lines().enumerate() {
            let fields = line.split('\t').collect::<Vec<_>>();
            ledger_rows.push(format!(
                "{}\t{}\t{}\t{origin}-{ordinal}\t0\t.",
                fields[0], fields[1], fields[2]
            ));
        }
    }
    ledger_rows.push(ledger_rows[0].clone());
    let ledger = root.join("native-row-ledger.bed");
    fs::write(&ledger, ledger_rows.join("\n") + "\n").unwrap();
    let annotated = root.join("annotated.tsv");
    let annotation_report = root.join("annotation.json");
    execute(
        product()
            .arg("annotate")
            .arg("--peaks")
            .arg(&ledger)
            .arg("--annotation")
            .arg(fixture.join("inputs/annotation.gff3"))
            .args(["--format", "gff3", "--threads", "4"])
            .arg("--output")
            .arg(&annotated)
            .arg("--report")
            .arg(&annotation_report),
    );
    let annotations = fs::read_to_string(&annotated).unwrap();
    let annotated_rows = annotations.lines().skip(1).collect::<Vec<_>>();
    assert_eq!(annotated_rows.len(), ledger_rows.len());
    for (actual, original) in annotated_rows.iter().zip(&ledger_rows) {
        assert_eq!(
            actual.split('\t').take(6).collect::<Vec<_>>(),
            original.split('\t').collect::<Vec<_>>()
        );
    }
    let annotation_state: serde_json::Value =
        serde_json::from_slice(&fs::read(&annotation_report).unwrap()).unwrap();
    assert_eq!(
        annotation_state["rows"].as_u64().unwrap() as usize,
        ledger_rows.len()
    );
    assert_eq!(annotation_state["transcripts"], 320);

    let counts = root.join("counts.tsv");
    let count_report = root.join("counts.json");
    execute(
        product()
            .arg("count")
            .arg("--peaks")
            .arg(&ledger)
            .arg("--sample")
            .arg(format!("T1={}", alignments.join("T1.pe.bam").display()))
            .arg(format!("T2={}", alignments.join("T2.pe.bam").display()))
            .args(["--threads", "4"])
            .arg("--output")
            .arg(&counts)
            .arg("--report")
            .arg(&count_report),
    );
    let count_text = fs::read_to_string(&counts).unwrap();
    let count_rows = count_text
        .lines()
        .skip(1)
        .map(|line| line.split('\t').collect::<Vec<_>>())
        .collect::<Vec<_>>();
    assert_eq!(count_rows.len(), ledger_rows.len());
    for (actual, original) in count_rows.iter().zip(&ledger_rows) {
        assert_eq!(&actual[..6], original.split('\t').collect::<Vec<_>>());
    }
    assert_eq!(count_rows[0], *count_rows.last().unwrap());
    assert!(
        count_rows
            .iter()
            .any(|row| row[6].parse::<u64>().unwrap() > 0)
    );
    let count_state: serde_json::Value =
        serde_json::from_slice(&fs::read(&count_report).unwrap()).unwrap();
    assert_eq!(count_state["unit"], "alignment");
    assert_eq!(count_state["effective_workers"], 2);
    eprintln!(
        "retained connected native peak workflow: {}",
        scratch.keep().display()
    );
}
