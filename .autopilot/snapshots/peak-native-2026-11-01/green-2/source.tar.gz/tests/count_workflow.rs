use noodles::{bam, sam};
use std::{fs, num::NonZeroUsize, path::Path, process::Command};

fn bam_fixture(path: &Path) {
    use noodles::sam::alignment::io::Write;
    let header: sam::Header = "@HD\tVN:1.6\tSO:coordinate\n@SQ\tSN:chr1\tLN:1000\n"
        .parse()
        .unwrap();
    let mut reader = sam::io::Reader::new(std::io::Cursor::new(concat!(
        "plain\t0\tchr1\t101\t30\t10M\t*\t0\t0\tAAAAAAAAAA\tIIIIIIIIII\n",
        "secondary\t256\tchr1\t101\t30\t10M\t*\t0\t0\tAAAAAAAAAA\tIIIIIIIIII\n",
        "supplementary\t2048\tchr1\t101\t30\t10M\t*\t0\t0\tAAAAAAAAAA\tIIIIIIIIII\n",
        "dup\t1024\tchr1\t101\t19\t10M\t*\t0\t0\tAAAAAAAAAA\tIIIIIIIIII\n",
        "qc\t512\tchr1\t101\t30\t10M\t*\t0\t0\tAAAAAAAAAA\tIIIIIIIIII\n",
        "pair\t99\tchr1\t101\t30\t10M\t=\t201\t110\tAAAAAAAAAA\tIIIIIIIIII\n",
        "pair\t147\tchr1\t201\t30\t10M\t=\t101\t-110\tAAAAAAAAAA\tIIIIIIIIII\n",
        "splice\t0\tchr1\t301\t19\t5M10N5M\t*\t0\t0\tAAAAAAAAAA\tIIIIIIIIII\n",
        "deletion\t0\tchr1\t401\t30\t5M10D5M\t*\t0\t0\tAAAAAAAAAA\tIIIIIIIIII\n"
    )));
    let mut writer = bam::io::Writer::from(noodles::bgzf::io::Writer::new(
        fs::File::create(path).unwrap(),
    ));
    writer.write_header(&header).unwrap();
    for record in reader.record_bufs(&header) {
        writer
            .write_alignment_record(&header, &record.unwrap())
            .unwrap();
    }
    writer.into_inner().finish().unwrap();
}

#[test]
fn alignment_count_workflow_preserves_rows_flags_split_and_atomic_outputs() {
    let scratch = tempfile::Builder::new()
        .prefix("peak-count-workflow-")
        .tempdir()
        .unwrap();
    let bam = scratch.path().join("reads.bam");
    bam_fixture(&bam);
    let bed = scratch.path().join("rows.bed");
    fs::write(&bed, "chr1\t100\t110\tdup\t0\t+\nchr1\t100\t110\tdup\t0\t+\nchr1\t308\t312\tgap\t0\t+\nchr1\t300\t320\tblocks\t0\t+\nchr1\t408\t412\tdeletion\t0\t+\nchrMissing\t0\t10\tmissing\t0\t.\n").unwrap();
    let output = scratch.path().join("counts.tsv");
    let report = scratch.path().join("report.json");
    for (flags, expected) in [
        (vec![], vec![4, 4, 1, 1, 1, 0]),
        (vec!["--min-mapq", "20"], vec![4, 4, 0, 0, 1, 0]),
        (vec!["--proper-pairs-only"], vec![1, 1, 0, 0, 0, 0]),
        (
            vec!["--include-duplicates", "--include-qc-failed"],
            vec![6, 6, 1, 1, 1, 0],
        ),
        (vec!["--split"], vec![4, 4, 0, 1, 1, 0]),
    ] {
        let mut first = None;
        for workers in [NonZeroUsize::MIN.get(), 4] {
            let result = Command::new(env!("CARGO_BIN_EXE_rsomics-peak"))
                .args(["count", "--peaks"])
                .arg(&bed)
                .arg("--sample")
                .arg(format!("S1={}", bam.display()))
                .arg(format!("S2={}", bam.display()))
                .arg("--output")
                .arg(&output)
                .arg("--report")
                .arg(&report)
                .args(["--threads", &workers.to_string()])
                .args(&flags)
                .output()
                .unwrap();
            assert!(
                result.status.success(),
                "{}",
                String::from_utf8_lossy(&result.stderr)
            );
            let text = fs::read_to_string(&output).unwrap();
            let counts = text
                .lines()
                .skip(1)
                .map(|line| {
                    let fields = line.split('\t').collect::<Vec<_>>();
                    assert_eq!(fields[6], fields[7]);
                    fields[6].parse::<u64>().unwrap()
                })
                .collect::<Vec<_>>();
            assert_eq!(counts, expected);
            if let Some(old) = &first {
                assert_eq!(&text, old);
            } else {
                first = Some(text);
            }
        }
    }
    fs::write(&output, "old counts\n").unwrap();
    fs::write(&report, "old report\n").unwrap();
    let broken = scratch.path().join("broken.bam");
    fs::write(&broken, b"not a BAM").unwrap();
    let status = Command::new(env!("CARGO_BIN_EXE_rsomics-peak"))
        .arg("count")
        .arg("--peaks")
        .arg(&bed)
        .arg("--sample")
        .arg(format!("bad={}", broken.display()))
        .arg("--output")
        .arg(&output)
        .arg("--report")
        .arg(&report)
        .output()
        .unwrap();
    assert!(!status.status.success());
    assert_eq!(fs::read_to_string(output).unwrap(), "old counts\n");
    assert_eq!(fs::read_to_string(report).unwrap(), "old report\n");
    fs::write(scratch.path().join("case-probe"), b"filesystem profile").unwrap();
    let case_insensitive = scratch.path().join("CASE-PROBE").exists();
    let data = scratch.path().join("case-counts.tsv");
    let state = scratch.path().join("CASE-COUNTS.tsv");
    let result = Command::new(env!("CARGO_BIN_EXE_rsomics-peak"))
        .arg("count")
        .arg("--peaks")
        .arg(&bed)
        .arg("--sample")
        .arg(format!("native={}", bam.display()))
        .arg("--output")
        .arg(&data)
        .arg("--report")
        .arg(&state)
        .output()
        .unwrap();
    if case_insensitive {
        assert!(
            !result.status.success(),
            "case-aliasing destinations were admitted"
        );
        assert!(!data.exists() && !state.exists());
    } else {
        assert!(
            result.status.success(),
            "{}",
            String::from_utf8_lossy(&result.stderr)
        );
        assert!(fs::read_to_string(&data).unwrap().starts_with("#chrom\t"));
        assert_eq!(
            serde_json::from_slice::<serde_json::Value>(&fs::read(state).unwrap()).unwrap()["unit"],
            "alignment"
        );
    }
}

#[test]
fn retained_original_count_rows_and_populations_match_all_four_views() {
    let fixture = std::env::var_os("RSOMICS_PEAK_FIXTURES").map(std::path::PathBuf::from).unwrap_or_else(||
        "/Volumes/Zane's HDD/rsomics-fixtures/evidence/peak-first-workflow-oracle-2026-10-31/run-41209740891/selected".into());
    let scratch = tempfile::Builder::new()
        .prefix("peak-count-original-")
        .tempdir()
        .unwrap();
    let bed = fixture.join("witness/rows/workflow.bed");
    let unit_summary: serde_json::Value = serde_json::from_slice(
        &fs::read(fixture.join("witness/calls/count-unit-summary/observation.json")).unwrap(),
    )
    .unwrap();
    assert_eq!(fs::read_to_string(&bed).unwrap().lines().count(), 20561);
    let addon = fixture.join("addon");
    let addon_bed = addon.join("inputs/count.bed");
    assert_eq!(fs::read_to_string(&addon_bed).unwrap().lines().count(), 16);
    let original_calls = fixture.join("witness/calls");
    let addon_calls = addon.join("calls");
    for (origin, calls, bed, name, flags) in [
        ("original", &original_calls, &bed, "C-default", vec![]),
        (
            "original",
            &original_calls,
            &bed,
            "C-proper",
            vec!["--min-mapq", "20", "--proper-pairs-only"],
        ),
        (
            "original",
            &original_calls,
            &bed,
            "C-flags",
            vec![
                "--min-mapq",
                "20",
                "--include-duplicates",
                "--include-qc-failed",
            ],
        ),
        (
            "original",
            &original_calls,
            &bed,
            "C-split",
            vec!["--min-mapq", "20", "--split"],
        ),
        ("addon", &addon_calls, &addon_bed, "C-default", vec![]),
        (
            "addon",
            &addon_calls,
            &addon_bed,
            "C-q20",
            vec!["--min-mapq", "20"],
        ),
        (
            "addon",
            &addon_calls,
            &addon_bed,
            "C-proper",
            vec!["--proper-pairs-only"],
        ),
        (
            "addon",
            &addon_calls,
            &addon_bed,
            "C-include",
            vec!["--include-duplicates", "--include-qc-failed"],
        ),
        (
            "addon",
            &addon_calls,
            &addon_bed,
            "C-split",
            vec!["--split"],
        ),
    ] {
        let expected = fs::read_to_string(calls.join(name).join("stdout.txt")).unwrap();
        let mut previous = None;
        for threads in [1, 4] {
            let output = scratch
                .path()
                .join(format!("{origin}-{name}-{threads}.tsv"));
            let report = scratch
                .path()
                .join(format!("{origin}-{name}-{threads}.json"));
            let result = Command::new(env!("CARGO_BIN_EXE_rsomics-peak"))
                .arg("count")
                .arg("--peaks")
                .arg(bed)
                .arg("--sample")
                .arg(format!(
                    "T1={}",
                    fixture.join("inputs/alignments/T1.pe.bam").display()
                ))
                .arg(format!(
                    "T2={}",
                    fixture.join("inputs/alignments/T2.pe.bam").display()
                ))
                .arg("--output")
                .arg(&output)
                .arg("--report")
                .arg(&report)
                .args(["--threads", &threads.to_string()])
                .args(&flags)
                .output()
                .unwrap();
            assert!(
                result.status.success(),
                "{origin} {name} {threads}: {}",
                String::from_utf8_lossy(&result.stderr)
            );
            let actual = fs::read_to_string(&output).unwrap();
            let actual_rows = actual.lines().skip(1).collect::<Vec<_>>();
            let expected_rows = expected.lines().collect::<Vec<_>>();
            assert_eq!(
                actual_rows.len(),
                expected_rows.len(),
                "{origin} {name} {threads}"
            );
            for (index, (actual, expected)) in actual_rows.iter().zip(expected_rows).enumerate() {
                assert_eq!(*actual, expected, "{origin} {name} {threads} row{index}");
            }
            if let Some(prior) = &previous {
                assert_eq!(&actual, prior);
            } else {
                previous = Some(actual);
            }
            let observed: serde_json::Value =
                serde_json::from_slice(&fs::read(&report).unwrap()).unwrap();
            assert_eq!(observed["unit"], "alignment");
            assert_eq!(observed["requested_threads"], threads);
            assert_eq!(observed["effective_workers"], threads.min(2));
            if origin == "original" {
                for (index, sample) in ["T1", "T2"].iter().enumerate() {
                    let source = &unit_summary[name]["samples"][sample];
                    let native = &observed["samples"][index];
                    assert_eq!(native["visited_records"], source["examined_alignments"]);
                    assert_eq!(
                        native["eligible_alignments"],
                        source["eligible_mapped_alignments"]
                    );
                    assert_eq!(native["row_assignments"], source["peak_assignments"]);
                }
            }
        }
    }
    eprintln!(
        "retained native count outputs: {}",
        scratch.keep().display()
    );
}

#[test]
fn explicit_sparse_cli_rows_feed_alignment_counts_without_a_default_profile() {
    let directory = tempfile::Builder::new()
        .prefix("peak-sparse-count-")
        .tempdir()
        .unwrap();
    let target = directory.path().join("native-target.bedgraph");
    fs::write(&target,"chr1\t0\t5\t0\nchr1\t100\t105\t1\nchr1\t105\t110\t1\nchr1\t200\t205\t10\nchr1\t205\t210\t10\nchr1\t300\t305\t2\nchr1\t305\t310\t2\nchr1\t900\t905\t0\n").unwrap();
    let sparse = directory.path().join("native-sparse.bed");
    let sparse_report = directory.path().join("sparse.json");
    let invoke = |profile: Option<&str>| {
        let mut command = Command::new(env!("CARGO_BIN_EXE_rsomics-peak"));
        command
            .arg("call-sparse")
            .arg("--target")
            .arg(&target)
            .args([
                "--fraction",
                "0.5",
                "--normalization",
                "non",
                "--mode",
                "stringent",
            ])
            .arg("--output")
            .arg(&sparse)
            .arg("--report")
            .arg(&sparse_report);
        if let Some(profile) = profile {
            command.args(["--compatibility", profile]);
        }
        command.output().unwrap()
    };
    let actual = invoke(Some("corrected"));
    assert!(
        actual.status.success(),
        "{}",
        String::from_utf8_lossy(&actual.stderr)
    );
    let text = fs::read_to_string(&sparse).unwrap();
    let coordinates = text
        .lines()
        .map(|line| line.split('\t').take(3).collect::<Vec<_>>())
        .collect::<Vec<_>>();
    assert_eq!(coordinates, vec![vec!["chr1", "200", "210"]]);
    let ledger = directory.path().join("native-row-ledger.bed");
    let mut rows = String::new();
    for (ordinal, line) in text.lines().enumerate() {
        let fields = line.split('\t').collect::<Vec<_>>();
        rows.push_str(&format!(
            "{}\t{}\t{}\tnative-sparse-{ordinal}\t{}\t.\n",
            fields[0], fields[1], fields[2], fields[3]
        ));
    }
    fs::write(&ledger, rows).unwrap();
    let bam = directory.path().join("native.bam");
    bam_fixture(&bam);
    let counts = directory.path().join("counts.tsv");
    let count_report = directory.path().join("count.json");
    let result = Command::new(env!("CARGO_BIN_EXE_rsomics-peak"))
        .arg("count")
        .arg("--peaks")
        .arg(&ledger)
        .arg("--sample")
        .arg(format!("native={}", bam.display()))
        .arg("--output")
        .arg(&counts)
        .arg("--report")
        .arg(&count_report)
        .args(["--threads", "4"])
        .output()
        .unwrap();
    assert!(
        result.status.success(),
        "{}",
        String::from_utf8_lossy(&result.stderr)
    );
    assert_eq!(
        fs::read_to_string(counts)
            .unwrap()
            .lines()
            .skip(1)
            .map(|line| line
                .split('\t')
                .next_back()
                .unwrap()
                .parse::<u64>()
                .unwrap())
            .collect::<Vec<_>>(),
        vec![1]
    );
    let before = fs::read(&sparse).unwrap();
    let result = invoke(None);
    assert!(!result.status.success());
    assert!(String::from_utf8_lossy(&result.stderr).contains("--compatibility"));
    assert_eq!(fs::read(&sparse).unwrap(), before);
}
