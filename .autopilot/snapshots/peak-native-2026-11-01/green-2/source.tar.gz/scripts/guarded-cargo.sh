#!/bin/bash
set -euo pipefail
export CARGO_HOME=/Volumes/KIOXIA/Developments/cargo-home
export CARGO_TARGET_DIR=/Volumes/KIOXIA/Developments/cargo-target
export RUSTUP_HOME=/Volumes/KIOXIA/Developments/rustup-home
export TMPDIR=/Volumes/KIOXIA/Developments/tmp
export XDG_CACHE_HOME=/Volumes/KIOXIA/Developments/tmp/cache
export GH_CACHE_DIR=/Volumes/KIOXIA/Developments/tmp/gh-cache
export PYTHONDONTWRITEBYTECODE=1
toolchain=/Volumes/KIOXIA/Developments/rustup-home/toolchains/1.91.0-aarch64-apple-darwin/bin
export CARGO="$toolchain/cargo" RUSTC="$toolchain/rustc" RUSTDOC="$toolchain/rustdoc" RUSTFMT="$toolchain/rustfmt"
export CARGO_BUILD_JOBS=2
export PATH="$toolchain:$PATH"
for name in CARGO_BUILD_TARGET RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS; do
  if [[ -n "${!name:-}" ]]; then echo "Unsupported compiler/target override: $name" >&2; exit 1; fi
done
/usr/sbin/diskutil info -plist /Volumes/KIOXIA | /usr/bin/python3 -c '
import plistlib,sys
volume=plistlib.loads(sys.stdin.buffer.read())
if volume.get("MountPoint")!="/Volumes/KIOXIA" or volume.get("Internal") is not False:
    sys.exit("KIOXIA is not mounted as an external volume")
print("verified external volume:",volume["DeviceNode"])
'
device=$(stat -f %d /Volumes/KIOXIA)
for path in "$CARGO_HOME" "$CARGO_TARGET_DIR" "$RUSTUP_HOME" "$TMPDIR" "$toolchain" "$XDG_CACHE_HOME" "$GH_CACHE_DIR"; do
  test -d "$path"
  resolved=$(cd "$path" && pwd -P)
  case "$resolved" in /Volumes/KIOXIA/Developments/*) ;; *) echo "Forbidden project/cache path: $resolved" >&2; exit 1;; esac
  test "$(stat -f %d "$resolved")" = "$device" || { echo "Path not on external device: $resolved" >&2; exit 1; }
  echo "verified external path: $resolved"
done
for argument in "$@"; do
  case "$argument" in --target-dir|--target-dir=*|--config|--config=*) echo "Storage overrides are forbidden" >&2; exit 1;; esac
done
df -h /Volumes/KIOXIA
target=$("$CARGO" metadata --no-deps --format-version 1 | /usr/bin/python3 -c 'import json,sys; print(json.load(sys.stdin)["target_directory"])')
test "$target" = "$CARGO_TARGET_DIR"
echo "Cargo resolved target: $target"
case "${1:-}" in
  --exec) shift; exec "$@";;
  clippy) shift; exec "$toolchain/cargo-clippy" clippy "$@";;
  fmt) shift; exec "$toolchain/cargo-fmt" fmt "$@";;
  *) exec "$CARGO" "$@";;
esac
