mod assign;
mod graph;
mod index;
mod parse;

use crate::{
    execution::Execution,
    io::{OutputGroup, read_peak_rows},
    model::*,
};
pub(crate) use assign::assign;
pub(crate) use graph::read_graph;
use rsomics_common::Result;
use serde::Serialize;
use std::{
    collections::BTreeMap,
    io::{BufWriter, Write},
    path::PathBuf,
};

#[derive(Clone, Copy, Debug, Serialize)]
pub(crate) enum AnnotationFormat {
    Gtf,
    Gff3,
}

#[derive(Clone, Debug, Serialize)]
pub(crate) struct AnnotationConfig {
    pub tss_upstream: u64,
    pub tss_downstream: u64,
    pub downstream: u64,
}

impl Default for AnnotationConfig {
    fn default() -> Self {
        Self {
            tss_upstream: 3000,
            tss_downstream: 3000,
            downstream: 3000,
        }
    }
}

#[derive(Clone, Debug)]
pub(crate) struct AnnotationRunConfig {
    pub peaks: PathBuf,
    pub annotation: PathBuf,
    pub format: AnnotationFormat,
    pub output: PathBuf,
    pub report: PathBuf,
    pub options: AnnotationConfig,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
pub(crate) enum Category {
    Promoter,
    FiveUtr,
    ThreeUtr,
    Exon,
    Intron,
    Downstream,
    DistalIntergenic,
}

#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize)]
pub(crate) struct Detail {
    pub genic: bool,
    pub intergenic: bool,
    pub promoter: bool,
    pub five_utr: bool,
    pub three_utr: bool,
    pub exon: bool,
    pub intron: bool,
    pub downstream: bool,
    pub distal_intergenic: bool,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
pub(crate) struct FeatureHit {
    pub transcript: usize,
    pub rank: usize,
    pub total: usize,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
pub(crate) struct AnnotationRow {
    pub row_id: RowId,
    pub nearest_transcript: usize,
    pub distance_to_tss: i64,
    pub category: Category,
    pub annotation: String,
    pub exon_hit: Option<FeatureHit>,
    pub intron_hit: Option<FeatureHit>,
    pub five_utr_hit: Option<FeatureHit>,
    pub three_utr_hit: Option<FeatureHit>,
    pub downstream_transcript: Option<usize>,
    pub downstream_distance: Option<i64>,
    pub detail: Detail,
}

#[derive(Debug)]
pub(crate) struct AnnotationResults {
    pub rows: Vec<AnnotationRow>,
    pub effective_workers: usize,
}

#[derive(Debug, Serialize)]
pub(crate) struct AnnotationReport {
    pub source_profile: &'static str,
    pub peaks: PathBuf,
    pub annotation: PathBuf,
    pub format: AnnotationFormat,
    pub output: PathBuf,
    pub report: PathBuf,
    pub options: AnnotationConfig,
    pub rows: usize,
    pub genes: usize,
    pub transcripts: usize,
    pub exon_edges: usize,
    pub coding_edges: usize,
    pub explicit_utr_edges: usize,
    pub category_counts: BTreeMap<String, usize>,
    pub detail_counts: DetailCounts,
    pub requested_threads: usize,
    pub effective_workers: usize,
    pub strategy: &'static str,
    pub scratch: PathBuf,
    pub graph_notices: BTreeMap<String, usize>,
}

#[derive(Debug, Default, Serialize)]
pub(crate) struct DetailCounts {
    pub genic: usize,
    pub intergenic: usize,
    pub promoter: usize,
    pub five_utr: usize,
    pub three_utr: usize,
    pub exon: usize,
    pub intron: usize,
    pub downstream: usize,
    pub distal_intergenic: usize,
}

pub(crate) fn run(config: &AnnotationRunConfig, execution: &Execution) -> Result<AnnotationReport> {
    let graph = read_graph(&config.annotation, config.format)?;
    let peaks = read_peak_rows(&config.peaks, execution.memory_budget / 2)?;
    let results = assign(&graph, &peaks, &config.options, execution)?;
    let mut output = OutputGroup::new(
        &[config.peaks.clone(), config.annotation.clone()],
        &[config.output.clone(), config.report.clone()],
    )?;
    let mut counts = BTreeMap::new();
    let mut detail = DetailCounts::default();
    for row in &results.rows {
        *counts.entry(row.annotation.clone()).or_insert(0) += 1;
        let d = &row.detail;
        detail.genic += usize::from(d.genic);
        detail.intergenic += usize::from(d.intergenic);
        detail.promoter += usize::from(d.promoter);
        detail.five_utr += usize::from(d.five_utr);
        detail.three_utr += usize::from(d.three_utr);
        detail.exon += usize::from(d.exon);
        detail.intron += usize::from(d.intron);
        detail.downstream += usize::from(d.downstream);
        detail.distal_intergenic += usize::from(d.distal_intergenic);
    }
    let report = AnnotationReport {
        source_profile: "ChIPseeker-1.48.0/txdbmaker-1.8.0/GenomicFeatures-1.64.0",
        peaks: config.peaks.clone(),
        annotation: config.annotation.clone(),
        format: config.format,
        output: config.output.clone(),
        report: config.report.clone(),
        options: config.options.clone(),
        rows: results.rows.len(),
        genes: graph.genes.len(),
        transcripts: graph.transcripts.len(),
        exon_edges: graph.transcripts.iter().map(|tx| tx.exons.len()).sum(),
        coding_edges: graph
            .transcripts
            .iter()
            .flat_map(|tx| &tx.exons)
            .filter(|exon| exon.cds.is_some())
            .count(),
        explicit_utr_edges: graph
            .transcripts
            .iter()
            .map(|tx| tx.explicit_utrs.len())
            .sum(),
        category_counts: counts,
        detail_counts: detail,
        requested_threads: execution.threads.get(),
        effective_workers: results.effective_workers,
        strategy: "immutable chromosome feature indexes; bounded ordered 1024-row chunks; exact chromosome names",
        scratch: execution.scratch.clone(),
        graph_notices: graph.notices.clone(),
    };
    {
        let mut writer = BufWriter::new(output.file_mut(0));
        write!(writer, "#chrom\tstart\tend")?;
        for column in 3..peaks.field_count {
            write!(writer, "\tfield{}", column + 1)?;
        }
        writeln!(
            writer,
            "\trow_id\tannotation\tgeneChr\tgeneStart\tgeneEnd\tgeneLength\tgeneStrand\tgeneId\ttranscriptId\tdistanceToTSS\tfeature_hits\tdetail"
        )?;
        for (peak, row) in peaks.rows.iter().zip(&results.rows) {
            let tx = &graph.transcripts[row.nearest_transcript];
            let genes = if tx.gene_ids.len() == 1 {
                tx.gene_ids[0].clone()
            } else {
                serde_json::to_string(&tx.gene_ids).map_err(|e| invalid(e.to_string()))?
            };
            let features = serde_json::to_string(&(
                row.exon_hit,
                row.intron_hit,
                row.five_utr_hit,
                row.three_utr_hit,
            ))
            .map_err(|e| invalid(e.to_string()))?;
            let flags = serde_json::to_string(&row.detail).map_err(|e| invalid(e.to_string()))?;
            writeln!(
                writer,
                "{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}",
                peak.original_fields.join("\t"),
                row.row_id.0,
                row.annotation,
                graph.dictionary.chromosomes[tx.span.chrom.0].name,
                tx.span.start + 1,
                tx.span.end,
                tx.span.end - tx.span.start,
                match tx.strand {
                    Strand::Plus => "+",
                    Strand::Minus => "-",
                    Strand::Unknown => ".",
                },
                genes,
                tx.name,
                row.distance_to_tss,
                features,
                flags
            )?;
        }
        writer.flush()?;
    }
    serde_json::to_writer_pretty(output.file_mut(1), &report)
        .map_err(|e| invalid(format!("writing annotation report: {e}")))?;
    output.file_mut(1).write_all(b"\n")?;
    output.commit()?;
    Ok(report)
}

#[cfg(test)]
mod tests;
