use super::AnnotationFormat;
use crate::model::*;
use rsomics_common::{Context, Result};
use std::{
    collections::{BTreeMap, HashSet},
    fs::File,
    io::{BufRead, BufReader, Read},
    mem::size_of,
    path::Path,
};

pub(super) const GRAPH_BUDGET: usize = 512 << 20;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum Kind {
    Gene,
    Transcript,
    Exon,
    Cds,
    Stop,
    FiveUtr,
    ThreeUtr,
    Utr,
    Other,
}

#[derive(Debug)]
pub(super) struct Record {
    pub line: usize,
    pub kind: Kind,
    pub feature_type: String,
    pub span: Span,
    pub strand: Strand,
    pub phase: Option<u8>,
    pub id: Option<String>,
    pub name: Option<String>,
    pub gene_id: Option<String>,
    pub transcript_id: Option<String>,
    pub parents: Vec<String>,
    pub dbxref: Vec<String>,
    pub external_gene: Option<String>,
}

impl Record {
    fn heap_memory(&self) -> usize {
        self.feature_type.capacity()
            + [
                &self.id,
                &self.name,
                &self.gene_id,
                &self.transcript_id,
                &self.external_gene,
            ]
            .into_iter()
            .flatten()
            .map(String::capacity)
            .sum::<usize>()
            + [&self.parents, &self.dbxref]
                .into_iter()
                .map(|values| {
                    values.capacity() * size_of::<String>()
                        + values.iter().map(String::capacity).sum::<usize>()
                })
                .sum::<usize>()
    }
}

pub(super) fn btree_node_memory<T>() -> usize {
    // Charge a full Rust B-tree node per key, not only occupied slots.
    11 * size_of::<T>() + 15 * size_of::<usize>()
}

pub(super) fn metadata_memory(
    dictionary: &ChromDictionary,
    notices: &BTreeMap<String, usize>,
) -> usize {
    size_of::<ChromDictionary>()
        + dictionary.chromosomes.capacity() * size_of::<Chromosome>()
        + dictionary
            .chromosomes
            .iter()
            .map(|chrom| chrom.name.capacity() * 2)
            .sum::<usize>()
        + dictionary.chromosomes.len().next_power_of_two()
            * 2
            * (size_of::<(String, ChromId)>() + 1)
        + size_of::<BTreeMap<String, usize>>()
        + notices
            .keys()
            .map(|name| name.capacity() + btree_node_memory::<(String, usize)>())
            .sum::<usize>()
}

pub(super) struct Parsed {
    pub dictionary: ChromDictionary,
    pub records: Vec<Record>,
    pub notices: BTreeMap<String, usize>,
    pub memory: usize,
}

fn kind(value: &str) -> Kind {
    match value {
        "gene"
        | "pseudogene"
        | "protein_coding_gene"
        | "gene_with_edited_transcript"
        | "gene_with_mRNA_with_frameshift"
        | "gene_with_polyadenylated_mRNA"
        | "gene_with_recoded_mRNA"
        | "gene_with_mRNA_recoded_by_translational_bypass"
        | "gene_with_transcript_with_translational_frameshift"
        | "gene_with_stop_codon_read_through"
        | "gene_with_stop_codon_redefined_as_pyrrolysine"
        | "gene_with_stop_codon_redefined_as_selenocysteine"
        | "bidirectional_promoter_lncRNA"
        | "sense_overlap_ncRNA_gene"
        | "lincRNA_gene"
        | "antisense_lncRNA_gene"
        | "sense_intronic_ncRNA_gene"
        | "ncRNA_gene"
        | "snoRNA_gene"
        | "gRNA_gene"
        | "RNase_P_RNA_gene"
        | "tmRNA_gene"
        | "SRP_RNA_gene"
        | "tRNA_gene"
        | "rRNA_gene"
        | "rRNA_25S_gene"
        | "rRNA_16S_gene"
        | "rRNA_21S_gene"
        | "rRNA_5S_gene"
        | "rRNA_28S_gene"
        | "rRNA_23S_gene"
        | "rRNA_5_8S_gene"
        | "rRNA_18S_gene"
        | "lncRNA_gene"
        | "enzymatic_RNA_gene"
        | "ribozyme_gene"
        | "RNase_MRP_RNA_gene"
        | "snRNA_gene"
        | "telomerase_RNA_gene"
        | "miRNA_gene"
        | "piRNA_gene"
        | "scRNA_gene"
        | "non_processed_pseudogene"
        | "duplicated_pseudogene"
        | "cassette_pseudogene"
        | "nuclear_mt_pseudogene"
        | "translated_unprocessed_pseudogene"
        | "pseudogene_by_unequal_crossing_over"
        | "transcribed_unprocessed_pseudogene"
        | "unitary_pseudogene"
        | "transcribed_unitary_pseudogene"
        | "allelic_pseudogene"
        | "processed_pseudogene"
        | "transcribed_processed_pseudogene"
        | "translated_processed_pseudogene"
        | "polymorphic_pseudogene"
        | "polymorphic_pseudogene_with_retained_intron"
        | "vertebrate_immune_system_pseudogene"
        | "T_cell_receptor_pseudogene"
        | "TR_J_pseudogene"
        | "TR_V_pseudogene"
        | "immunoglobulin_pseudogene"
        | "IG_J_pseudogene"
        | "IG_V_pseudogene"
        | "IG_C_pseudogene"
        | "transposable_element_pseudogene"
        | "transposable_element_gene"
        | "engineered_foreign_transposable_element_gene" => Kind::Gene,
        "transcript"
        | "primary_transcript"
        | "mRNA"
        | "rRNA"
        | "snoRNA"
        | "snRNA"
        | "tRNA"
        | "tmRNA"
        | "miRNA"
        | "miRNA_primary_transcript"
        | "RNase_P_RNA"
        | "RNase_MRP_RNA"
        | "SRP_RNA"
        | "misc_RNA"
        | "antisense_RNA"
        | "antisense"
        | "lnc_RNA"
        | "antisense_lncRNA"
        | "transcript_region"
        | "scRNA"
        | "guide_RNA"
        | "telomerase_RNA"
        | "vault_RNA"
        | "Y_RNA"
        | "ncRNA"
        | "three_prime_overlapping_ncrna"
        | "predicted_transcript"
        | "unconfirmed_transcript"
        | "pseudogenic_transcript"
        | "pseudogenic_rRNA"
        | "unitary_pseudogenic_rRNA"
        | "allelic_pseudogenic_rRNA"
        | "unprocessed_pseudogenic_rRNA"
        | "processed_pseudogenic_rRNA"
        | "pseudogenic_tRNA"
        | "unitary_pseudogenic_tRNA"
        | "allelic_pseudogenic_tRNA"
        | "unprocessed_pseudogenic_tRNA"
        | "processed_pseudogenic_tRNA"
        | "vertebrate_immunoglobulin_T_cell_receptor_segment"
        | "V_gene_segment"
        | "D_gene_segment"
        | "C_gene_segment"
        | "J_gene_segment"
        | "gene_segment"
        | "pseudogenic_gene_segment" => Kind::Transcript,
        "exon"
        | "pseudogenic_exon"
        | "coding_exon"
        | "five_prime_coding_exon"
        | "interior_coding_exon"
        | "three_prime_coding_exon"
        | "exon_of_single_exon_gene"
        | "interior_exon"
        | "noncoding_exon"
        | "five_prime_noncoding_exon"
        | "three_prime_noncoding_exon" => Kind::Exon,
        "CDS" | "transposable_element_CDS" | "CDS_predicted" | "edited_CDS" => Kind::Cds,
        "stop_codon" => Kind::Stop,
        "five_prime_UTR" | "5UTR" => Kind::FiveUtr,
        "three_prime_UTR" | "3UTR" => Kind::ThreeUtr,
        "UTR" => Kind::Utr,
        _ => Kind::Other,
    }
}

fn clean(value: String) -> Result<String> {
    if value.is_empty() || value.chars().any(char::is_control) {
        return Err(invalid("empty or control-containing annotation attribute"));
    }
    Ok(value)
}

fn decode(value: &str) -> Result<String> {
    let input = value.as_bytes();
    let mut output = Vec::with_capacity(input.len());
    let mut i = 0;
    while i < input.len() {
        if input[i] == b'%' {
            let hex = input
                .get(i + 1..i + 3)
                .ok_or_else(|| invalid("truncated GFF3 percent escape"))?;
            let digit = |c: u8| {
                (c as char)
                    .to_digit(16)
                    .map(|n| n as u8)
                    .ok_or_else(|| invalid("invalid GFF3 percent escape"))
            };
            output.push(digit(hex[0])? * 16 + digit(hex[1])?);
            i += 3;
        } else {
            output.push(input[i]);
            i += 1;
        }
    }
    clean(String::from_utf8(output).map_err(|e| invalid(format!("non-UTF8 GFF3 attribute: {e}")))?)
}

fn gtf_attributes(value: &str) -> Result<Vec<(String, String)>> {
    let mut answer = Vec::new();
    let mut rest = value.trim();
    while !rest.is_empty() {
        let split = rest
            .find(char::is_whitespace)
            .ok_or_else(|| invalid("GTF attribute lacks value"))?;
        let key = clean(rest[..split].to_owned())?;
        rest = rest[split..].trim_start();
        let mut result = String::new();
        if rest.starts_with('"') {
            let mut escaped = false;
            let mut closed = None;
            for (offset, ch) in rest[1..].char_indices() {
                if escaped {
                    result.push(ch);
                    escaped = false;
                } else if ch == '\\' {
                    escaped = true;
                } else if ch == '"' {
                    closed = Some(offset + 2);
                    break;
                } else {
                    result.push(ch);
                }
            }
            rest = rest[closed.ok_or_else(|| invalid("unterminated GTF quoted attribute"))?..]
                .trim_start();
            if !rest.is_empty() && !rest.starts_with(';') {
                return Err(invalid("GTF attribute lacks semicolon"));
            }
        } else {
            let end = rest.find(';').unwrap_or(rest.len());
            result.push_str(rest[..end].trim());
            rest = &rest[end..];
        }
        answer.push((key, clean(result)?));
        rest = rest.strip_prefix(';').unwrap_or(rest).trim_start();
    }
    Ok(answer)
}

pub(super) fn read(path: &Path, format: AnnotationFormat) -> Result<Parsed> {
    let mut reader = BufReader::new(
        File::open(path).rs_with_context(|| format!("opening annotation {}", path.display()))?,
    );
    let mut parsed = Parsed {
        dictionary: ChromDictionary::default(),
        records: Vec::new(),
        notices: BTreeMap::new(),
        memory: 0,
    };
    let mut bytes = Vec::new();
    let mut record_heap = 0usize;
    let mut line_number = 0;
    loop {
        bytes.clear();
        if (&mut reader)
            .take((1 << 20) + 1)
            .read_until(b'\n', &mut bytes)?
            == 0
        {
            break;
        }
        line_number += 1;
        let context = || format!("{}:{line_number}", path.display());
        if bytes.len() > 1 << 20 {
            return Err(invalid(format!(
                "{}: annotation line exceeds1MiB",
                context()
            )));
        }
        let text = std::str::from_utf8(&bytes)
            .map_err(|e| invalid(format!("{}: {e}", context())))?
            .trim_end_matches(['\n', '\r']);
        if text == "##FASTA" {
            break;
        }
        if text.starts_with("##sequence-region ") {
            let fields = text.split_whitespace().collect::<Vec<_>>();
            if fields.len() != 4 || fields[2] != "1" {
                return Err(invalid(format!(
                    "{}: invalid sequence-region directive",
                    context()
                )));
            }
            let len = fields[3]
                .parse::<u64>()
                .map_err(|_| invalid(format!("{}: invalid sequence-region length", context())))?;
            parsed
                .dictionary
                .intern(&decode(fields[1])?, Some(len))
                .rs_with_context(context)?;
            continue;
        }
        if text.is_empty() || text.starts_with('#') {
            continue;
        }
        let row = (|| -> Result<Record> {
            let fields = text.split('\t').collect::<Vec<_>>();
            if fields.len() != 9 {
                return Err(invalid("annotation requires exactly9 tab-separated fields"));
            }
            let chrom = match format {
                AnnotationFormat::Gff3 => decode(fields[0])?,
                AnnotationFormat::Gtf => clean(fields[0].into())?,
            };
            let chrom = parsed.dictionary.intern(&chrom, None)?;
            let start = fields[3]
                .parse::<u64>()
                .map_err(|_| invalid("invalid1-based annotation start"))?;
            let end = fields[4]
                .parse::<u64>()
                .map_err(|_| invalid("invalid annotation end"))?;
            let start = start
                .checked_sub(1)
                .ok_or_else(|| invalid("annotation start must be positive"))?;
            if end > i64::MAX as u64 {
                return Err(invalid("annotation end exceeds signed distance range"));
            }
            let span = Span::new(chrom, start, end)?;
            if parsed.dictionary.chromosomes[chrom.0]
                .len
                .is_some_and(|len| end > len)
            {
                return Err(invalid("annotation extends past sequence-region length"));
            }
            let strand = match fields[6] {
                "+" => Strand::Plus,
                "-" => Strand::Minus,
                "." | "?" => Strand::Unknown,
                _ => return Err(invalid("invalid annotation strand")),
            };
            let phase = match fields[7] {
                "." => None,
                "0" => Some(0),
                "1" => Some(1),
                "2" => Some(2),
                _ => return Err(invalid("annotation phase must be0,1,2 or '.'")),
            };
            let attributes = match format {
                AnnotationFormat::Gtf => gtf_attributes(fields[8])?,
                AnnotationFormat::Gff3 => {
                    let mut result = Vec::new();
                    for field in fields[8].split(';').filter(|s| !s.is_empty() && *s != ".") {
                        let (key, value) = field
                            .split_once('=')
                            .ok_or_else(|| invalid("GFF3 attribute lacks '='"))?;
                        result.push((clean(key.into())?, value.to_owned()));
                    }
                    result
                }
            };
            let mut seen = HashSet::new();
            let mut record = Record {
                line: line_number,
                kind: kind(fields[2]),
                feature_type: clean(fields[2].into())?,
                span,
                strand,
                phase,
                id: None,
                name: None,
                gene_id: None,
                transcript_id: None,
                parents: Vec::new(),
                dbxref: Vec::new(),
                external_gene: None,
            };
            for (key, raw) in attributes {
                if !matches!(
                    key.as_str(),
                    "ID" | "Name" | "Parent" | "gene_id" | "transcript_id" | "Dbxref" | "geneID"
                ) {
                    continue;
                }
                if !seen.insert(key.clone()) {
                    return Err(invalid(format!("duplicate structural attribute {key}")));
                }
                let value = |raw: &str| match format {
                    AnnotationFormat::Gff3 => decode(raw),
                    AnnotationFormat::Gtf => clean(raw.into()),
                };
                match key.as_str() {
                    "Parent" => {
                        record.parents = raw.split(',').map(value).collect::<Result<_>>()?
                    }
                    "Dbxref" => record.dbxref = raw.split(',').map(value).collect::<Result<_>>()?,
                    "ID" => record.id = Some(value(&raw)?),
                    "Name" => record.name = Some(value(&raw)?),
                    "gene_id" => record.gene_id = Some(value(&raw)?),
                    "transcript_id" => record.transcript_id = Some(value(&raw)?),
                    "geneID" => record.external_gene = Some(value(&raw)?),
                    _ => unreachable!(),
                }
            }
            if record.parents.iter().collect::<HashSet<_>>().len() != record.parents.len() {
                return Err(invalid("feature has duplicate Parent edges"));
            }
            Ok(record)
        })()
        .rs_with_context(context)?;
        if row.kind == Kind::Other {
            *parsed
                .notices
                .entry(format!("unmodeled feature type {}", row.feature_type))
                .or_insert(0) += 1;
        }
        record_heap = record_heap
            .checked_add(row.heap_memory())
            .ok_or_else(|| invalid("annotation graph size overflows"))?;
        parsed.records.push(row);
        parsed.memory = record_heap
            .checked_add(parsed.records.capacity() * size_of::<Record>())
            .and_then(|n| n.checked_add(metadata_memory(&parsed.dictionary, &parsed.notices)))
            .ok_or_else(|| invalid("annotation graph size overflows"))?;
        if parsed
            .memory
            .checked_add(bytes.capacity() + reader.capacity())
            .is_none_or(|n| n > GRAPH_BUDGET)
        {
            return Err(invalid(format!(
                "{}: annotation graph exceeds512MiB admission budget",
                context()
            )));
        }
    }
    if parsed.records.is_empty() {
        return Err(invalid(format!(
            "{}: annotation contains no feature records",
            path.display()
        )));
    }
    for row in &parsed.records {
        if parsed.dictionary.chromosomes[row.span.chrom.0]
            .len
            .is_some_and(|len| row.span.end > len)
        {
            return Err(invalid(format!(
                "{}:{}: annotation extends past sequence-region length",
                path.display(),
                row.line
            )));
        }
    }
    Ok(parsed)
}
