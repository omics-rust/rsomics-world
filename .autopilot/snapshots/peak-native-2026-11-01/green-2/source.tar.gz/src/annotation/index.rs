use super::{FeatureHit, graph::Transcript, parse};
use rsomics_common::Result;
use std::{collections::BTreeMap, mem::size_of};

#[derive(Clone, Copy, Debug)]
struct Entry {
    start: u64,
    end: u64,
    order: usize,
    hit: FeatureHit,
}

#[derive(Debug, Default)]
pub(super) struct FeatureIndex {
    entries: Vec<Entry>,
    max_end: Vec<u64>,
}

impl FeatureIndex {
    fn build(&mut self) {
        self.entries
            .sort_by_key(|entry| (entry.start, entry.end, entry.order));
        self.max_end = vec![0; self.entries.len()];
        fn fill(entries: &[Entry], ends: &mut [u64]) -> u64 {
            if entries.is_empty() {
                return 0;
            }
            let mid = entries.len() / 2;
            let (left, tail) = ends.split_at_mut(mid);
            let (value, right) = tail.split_first_mut().unwrap();
            *value = entries[mid]
                .end
                .max(fill(&entries[..mid], left))
                .max(fill(&entries[mid + 1..], right));
            *value
        }
        fill(&self.entries, &mut self.max_end);
    }

    pub fn first(&self, start: u64, end: u64) -> Option<FeatureHit> {
        fn search(entries: &[Entry], ends: &[u64], start: u64, end: u64, best: &mut Option<Entry>) {
            if entries.is_empty() {
                return;
            }
            let mid = entries.len() / 2;
            if ends[mid] <= start || entries[0].start >= end {
                return;
            }
            let entry = entries[mid];
            if entry.start < end
                && start < entry.end
                && best.is_none_or(|old| entry.order < old.order)
            {
                *best = Some(entry);
            }
            search(&entries[..mid], &ends[..mid], start, end, best);
            if entry.start < end {
                search(&entries[mid + 1..], &ends[mid + 1..], start, end, best);
            }
        }
        let mut best = None;
        search(&self.entries, &self.max_end, start, end, &mut best);
        best.map(|entry| entry.hit)
    }
}

#[derive(Clone, Copy, Debug)]
struct Endpoint {
    position: u64,
    order: usize,
    tx: usize,
}

#[derive(Debug, Default)]
struct Endpoints(Vec<Endpoint>);

impl Endpoints {
    fn build(&mut self) {
        self.0.sort_by_key(|entry| (entry.position, entry.order));
    }
    fn before(&self, boundary: u64, last: bool) -> Option<usize> {
        let end = self.0.partition_point(|entry| entry.position < boundary);
        if end == 0 {
            return None;
        }
        let index = if last {
            end - 1
        } else {
            self.0[..end].partition_point(|entry| entry.position < self.0[end - 1].position)
        };
        Some(self.0[index].tx)
    }
    fn after(&self, boundary: u64, last: bool) -> Option<usize> {
        let begin = self.0.partition_point(|entry| entry.position < boundary);
        if begin == self.0.len() {
            return None;
        }
        let index = if last {
            self.0
                .partition_point(|entry| entry.position <= self.0[begin].position)
                - 1
        } else {
            begin
        };
        Some(self.0[index].tx)
    }
}

#[derive(Debug, Default)]
pub(super) struct ChromIndex {
    tss: Endpoints,
    starts: Endpoints,
    ends: Endpoints,
    pub tss_overlap: FeatureIndex,
    pub exon: FeatureIndex,
    pub intron: FeatureIndex,
    pub five_utr: FeatureIndex,
    pub three_utr: FeatureIndex,
}

impl ChromIndex {
    pub fn tss_flanks(&self, start: u64, end: u64, minus: bool) -> (Option<usize>, Option<usize>) {
        if minus {
            (self.tss.after(end, true), self.tss.before(start, false))
        } else {
            (self.tss.before(start, true), self.tss.after(end, false))
        }
    }
    pub fn downstream(&self, start: u64, end: u64, minus: bool) -> Option<usize> {
        if minus {
            self.starts.after(end, true)
        } else {
            self.ends.before(start, true)
        }
    }
    pub fn has_nearest(&self) -> bool {
        !self.tss.0.is_empty()
    }
}

#[derive(Debug)]
pub(super) struct Indexes {
    pub chromosomes: Vec<ChromIndex>,
}

impl Indexes {
    pub fn projected_memory(transcripts: &[Transcript], chromosomes: usize) -> Result<usize> {
        let mut counts = vec![[0usize; 5]; chromosomes];
        let mut labels = 0;
        for tx in transcripts {
            let count = &mut counts[tx.span.chrom.0];
            for (total, value) in count.iter_mut().zip([
                tx.gene_ids.len(),
                tx.exons.len(),
                tx.introns.len(),
                tx.five_utrs.len(),
                tx.three_utrs.len(),
            ]) {
                *total += value;
            }
            labels += tx.name.len()
                + tx.gene_ids.iter().map(String::len).sum::<usize>()
                + tx.gene_ids.len() * 2
                + 1;
        }
        let capacity = |len: usize| -> usize {
            if len == 0 {
                0
            } else {
                len.next_power_of_two().max(4)
            }
        };
        let mut memory = size_of::<Self>()
            + chromosomes * size_of::<ChromIndex>()
            + counts.capacity() * size_of::<[usize; 5]>()
            + (counts.iter().map(|count| count[0]).sum::<usize>() * 2).max(4)
                * size_of::<(&String, usize)>()
            + 2 * (labels * 2 + transcripts.len() * parse::btree_node_memory::<(String, usize)>());
        let mut sort_scratch = 0;
        for count in counts {
            memory += 3 * capacity(count[0]) * size_of::<Endpoint>();
            sort_scratch = sort_scratch.max(count[0] * size_of::<Endpoint>());
            for len in count {
                memory += capacity(len) * size_of::<Entry>() + len * size_of::<u64>();
                sort_scratch = sort_scratch.max(len * size_of::<Entry>());
            }
        }
        memory
            .checked_add(sort_scratch)
            .ok_or_else(|| crate::model::invalid("annotation index storage overflows"))
    }

    pub fn new(transcripts: &[Transcript], chromosomes: usize) -> Self {
        let mut result = Self {
            chromosomes: (0..chromosomes).map(|_| ChromIndex::default()).collect(),
        };
        let mut subjects = transcripts
            .iter()
            .enumerate()
            .flat_map(|(i, tx)| tx.gene_ids.iter().map(move |gene| (gene, i)))
            .collect::<Vec<_>>();
        subjects.sort_unstable();
        for (order, (_, tx_id)) in subjects.into_iter().enumerate() {
            let tx = &transcripts[tx_id];
            let index = &mut result.chromosomes[tx.span.chrom.0];
            let hit = FeatureHit {
                transcript: tx_id,
                rank: 0,
                total: 0,
            };
            index.tss.0.push(Endpoint {
                position: tx.tss(),
                order,
                tx: tx_id,
            });
            index.starts.0.push(Endpoint {
                position: tx.span.start,
                order,
                tx: tx_id,
            });
            index.ends.0.push(Endpoint {
                position: tx.span.end - 1,
                order,
                tx: tx_id,
            });
            index.tss_overlap.entries.push(Entry {
                start: tx.tss(),
                end: tx.tss() + 1,
                order,
                hit,
            });
        }
        let mut exon_totals = BTreeMap::new();
        let mut intron_totals = BTreeMap::new();
        let mut order = 0;
        for (tx_id, tx) in transcripts.iter().enumerate() {
            let index = &mut result.chromosomes[tx.span.chrom.0];
            let exon_total = *exon_totals.entry(tx.label()).or_insert(tx.exons.len());
            let intron_total = *intron_totals.entry(tx.label()).or_insert(tx.introns.len());
            for exon in &tx.exons {
                index.exon.entries.push(Entry {
                    start: exon.start,
                    end: exon.end,
                    order,
                    hit: FeatureHit {
                        transcript: tx_id,
                        rank: exon.rank,
                        total: exon_total,
                    },
                });
                order += 1;
            }
            for intron in &tx.introns {
                index.intron.entries.push(Entry {
                    start: intron.start,
                    end: intron.end,
                    order,
                    hit: FeatureHit {
                        transcript: tx_id,
                        rank: intron.rank,
                        total: intron_total,
                    },
                });
                order += 1;
            }
            for (regions, target) in [
                (&tx.five_utrs, &mut index.five_utr),
                (&tx.three_utrs, &mut index.three_utr),
            ] {
                for region in regions {
                    target.entries.push(Entry {
                        start: region.start,
                        end: region.end,
                        order,
                        hit: FeatureHit {
                            transcript: tx_id,
                            rank: region.rank,
                            total: tx.exons.len(),
                        },
                    });
                    order += 1;
                }
            }
        }
        for index in &mut result.chromosomes {
            index.tss.build();
            index.starts.build();
            index.ends.build();
            index.tss_overlap.build();
            index.exon.build();
            index.intron.build();
            index.five_utr.build();
            index.three_utr.build();
        }
        result
    }

    pub fn memory(&self) -> usize {
        size_of::<Self>()
            + self.chromosomes.capacity() * size_of::<ChromIndex>()
            + self
                .chromosomes
                .iter()
                .map(|index| {
                    [&index.tss, &index.starts, &index.ends]
                        .iter()
                        .map(|entries| entries.0.capacity() * std::mem::size_of::<Endpoint>())
                        .sum::<usize>()
                        + [
                            &index.tss_overlap,
                            &index.exon,
                            &index.intron,
                            &index.five_utr,
                            &index.three_utr,
                        ]
                        .iter()
                        .map(|feature| {
                            feature.entries.capacity() * std::mem::size_of::<Entry>()
                                + feature.max_end.capacity() * 8
                        })
                        .sum::<usize>()
                })
                .sum::<usize>()
    }
}
