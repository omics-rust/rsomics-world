use super::{
    AnnotationConfig, AnnotationResults, AnnotationRow, Category, Detail, graph::AnnotationGraph,
};
use crate::{execution::Execution, model::*};
use rsomics_common::Result;

const ROW_CHUNK: usize = 1024;

fn signed(value: i128) -> Result<i64> {
    i64::try_from(value).map_err(|_| invalid("annotation distance exceeds signed64-bit range"))
}

fn promoter_label(distance: i64, config: &AnnotationConfig) -> String {
    if config.tss_upstream.max(config.tss_downstream) < 2000 {
        return "Promoter".into();
    }
    let bin = distance.unsigned_abs().div_ceil(1000).max(1);
    if bin == 1 {
        "Promoter (<=1kb)".into()
    } else {
        format!("Promoter ({}-{bin}kb)", bin - 1)
    }
}

fn downstream_label(distance: u64, limit: u64) -> String {
    if limit <= 1000 {
        return format!("Downstream (<={limit}bp)");
    }
    let bin = distance.div_ceil(1000).max(1);
    if bin <= limit / 1000 {
        if bin == 1 {
            "Downstream (<1kb)".into()
        } else {
            format!("Downstream ({}-{bin}kb)", bin - 1)
        }
    } else {
        format!("Downstream ({}kb-{limit}bp)", limit as f64 / 1000.0)
    }
}

fn one(
    graph: &AnnotationGraph,
    peak: &PeakRow,
    chrom: ChromId,
    config: &AnnotationConfig,
) -> Result<AnnotationRow> {
    let index = &graph.indexes.chromosomes[chrom.0];
    let start = peak.span.start;
    let end = peak.span.end;
    let (previous, next) = index.tss_flanks(start, end, peak.strand == Strand::Minus);
    let distance = |tx_id: usize, boundary: u64| -> Result<i64> {
        let tx = &graph.transcripts[tx_id];
        let sign = if tx.strand == Strand::Plus { 1 } else { -1 };
        signed((i128::from(boundary) - i128::from(tx.tss())) * sign)
    };
    let previous = previous
        .map(|tx| distance(tx, start).map(|d| (tx, d)))
        .transpose()?;
    let next = next
        .map(|tx| distance(tx, end - 1).map(|d| (tx, d)))
        .transpose()?;
    let nearest = match (previous, next) {
        (Some(a), Some(b)) => {
            if a.1.unsigned_abs() <= b.1.unsigned_abs() {
                Some(a)
            } else {
                Some(b)
            }
        }
        (a, b) => a.or(b),
    };
    let (nearest_transcript, distance_to_tss) = index
        .tss_overlap
        .first(start, end)
        .map(|hit| (hit.transcript, 0))
        .or(nearest)
        .ok_or_else(|| {
            invalid(format!(
                "row{}: no gene-associated transcript on annotation contig {}",
                peak.id.0, graph.dictionary.chromosomes[chrom.0].name
            ))
        })?;
    let exon_hit = index.exon.first(start, end);
    let intron_hit = index.intron.first(start, end);
    let five_utr_hit = index.five_utr.first(start, end);
    let three_utr_hit = index.three_utr.first(start, end);
    let downstream_transcript = index.downstream(start, end, peak.strand == Strand::Minus);
    let downstream_distance = downstream_transcript
        .map(|id| {
            let tx = &graph.transcripts[id];
            signed(if tx.strand == Strand::Plus {
                i128::from(start) + 1 - i128::from(tx.span.end)
            } else {
                i128::from(end) - i128::from(tx.span.start) - 1
            })
        })
        .transpose()?;
    let promoter = i128::from(distance_to_tss) >= -i128::from(config.tss_upstream)
        && i128::from(distance_to_tss) <= i128::from(config.tss_downstream);
    let downstream =
        downstream_distance.is_some_and(|d| d != 0 && d.unsigned_abs() <= config.downstream);
    let (category, annotation) = if promoter {
        (Category::Promoter, promoter_label(distance_to_tss, config))
    } else if five_utr_hit.is_some() {
        (Category::FiveUtr, "5' UTR".into())
    } else if three_utr_hit.is_some() {
        (Category::ThreeUtr, "3' UTR".into())
    } else if let Some(hit) = exon_hit {
        (
            Category::Exon,
            format!(
                "Exon ({}, exon {} of {})",
                graph.transcripts[hit.transcript].label(),
                hit.rank,
                hit.total
            ),
        )
    } else if let Some(hit) = intron_hit {
        (
            Category::Intron,
            format!(
                "Intron ({}, intron {} of {})",
                graph.transcripts[hit.transcript].label(),
                hit.rank,
                hit.total
            ),
        )
    } else if downstream {
        (
            Category::Downstream,
            downstream_label(
                downstream_distance.unwrap().unsigned_abs(),
                config.downstream,
            ),
        )
    } else {
        (Category::DistalIntergenic, "Distal Intergenic".into())
    };
    let genic = exon_hit.is_some() || intron_hit.is_some();
    let detail = Detail {
        genic,
        intergenic: !genic,
        promoter,
        five_utr: five_utr_hit.is_some(),
        three_utr: three_utr_hit.is_some(),
        exon: exon_hit.is_some(),
        intron: intron_hit.is_some(),
        downstream: downstream_distance.is_some_and(|d| d > 0 && (d as u64) < config.downstream),
        distal_intergenic: category == Category::DistalIntergenic,
    };
    Ok(AnnotationRow {
        row_id: peak.id,
        nearest_transcript,
        distance_to_tss,
        category,
        annotation,
        exon_hit,
        intron_hit,
        five_utr_hit,
        three_utr_hit,
        downstream_transcript,
        downstream_distance,
        detail,
    })
}

pub(crate) fn assign(
    graph: &AnnotationGraph,
    peaks: &PeakRows,
    config: &AnnotationConfig,
    execution: &Execution,
) -> Result<AnnotationResults> {
    if [
        config.tss_upstream,
        config.tss_downstream,
        config.downstream,
    ]
    .into_iter()
    .any(|n| n > i64::MAX as u64)
    {
        return Err(invalid("annotation distances exceed signed64-bit range"));
    }
    let mapping = peaks
        .dictionary
        .chromosomes
        .iter()
        .map(|chrom| {
            let id = graph
                .dictionary
                .find(&chrom.name)
                .filter(|id| graph.indexes.chromosomes[id.0].has_nearest())
                .ok_or_else(|| {
                    invalid(format!(
                        "{}: peak contig {} absent from gene-associated annotation graph",
                        graph.source.display(),
                        chrom.name
                    ))
                })?;
            if chrom.len.is_some()
                && graph.dictionary.chromosomes[id.0].len.is_some()
                && chrom.len != graph.dictionary.chromosomes[id.0].len
            {
                return Err(invalid(format!(
                    "annotation/peak chromosome {} lengths conflict",
                    chrom.name
                )));
            }
            Ok(id)
        })
        .collect::<Result<Vec<_>>>()?;
    let peak_memory = peaks
        .rows
        .iter()
        .try_fold(0usize, |sum, row| {
            sum.checked_add(
                std::mem::size_of::<PeakRow>()
                    + row
                        .original_fields
                        .iter()
                        .map(|field| std::mem::size_of::<String>() + field.len())
                        .sum::<usize>(),
            )
        })
        .ok_or_else(|| invalid("annotation row storage overflows"))?;
    let max_label = graph
        .transcripts
        .iter()
        .map(|tx| {
            tx.name.len()
                + tx.gene_ids.iter().map(String::len).sum::<usize>()
                + tx.gene_ids.len() * 2
                + 96
        })
        .max()
        .unwrap_or(96);
    let result_memory = peaks
        .rows
        .len()
        .checked_mul(std::mem::size_of::<AnnotationRow>() + max_label)
        .ok_or_else(|| invalid("annotation result storage overflows"))?;
    if graph
        .memory
        .checked_add(peak_memory)
        .and_then(|n| n.checked_add(result_memory))
        .is_none_or(|n| n > execution.memory_budget)
    {
        return Err(invalid(
            "annotation graph, rows and results exceed invocation memory budget",
        ));
    }
    let chunks = peaks.rows.len().div_ceil(ROW_CHUNK);
    let mut rows = execution
        .ordered_map(chunks, |chunk| {
            let first = chunk * ROW_CHUNK;
            let end = (first + ROW_CHUNK).min(peaks.rows.len());
            peaks.rows[first..end]
                .iter()
                .map(|peak| one(graph, peak, mapping[peak.span.chrom.0], config))
                .collect::<Result<Vec<_>>>()
        })?
        .into_iter()
        .flatten()
        .collect::<Vec<_>>();
    // R's negative indexing of an empty genic set selects no rows.
    if !rows.iter().any(|row| row.detail.genic) {
        for row in &mut rows {
            row.detail.intergenic = false;
        }
    }
    Ok(AnnotationResults {
        rows,
        effective_workers: execution.workers_for(chunks),
    })
}
