use super::density::{mode, quantile};
use crate::model::invalid;
use rsomics_common::Result;
use serde::Serialize;

#[derive(Clone, Debug, Serialize)]
pub(super) struct Thresholds {
    pub x0: f64,
    pub z0: f64,
    pub d0: f64,
    pub normalization: f64,
    pub fdr: Vec<f64>,
}

pub(super) fn round_significant(value: f64, digits: usize) -> f64 {
    format!("{value:.precision$e}", precision = digits - 1)
        .parse()
        .expect("formatting a finite float yields a valid float")
}

fn sorted(values: &[f64]) -> Vec<f64> {
    let mut result = values.to_vec();
    result.sort_unstable_by(f64::total_cmp);
    result
}

fn ecdf(values: &[f64], value: f64) -> f64 {
    values.partition_point(|point| *point <= value) as f64 / values.len() as f64
}

fn numeric(values: &[f64], fraction: f64) -> Result<f64> {
    let values = sorted(values);
    values
        .iter()
        .copied()
        .find(|value| 1.0 - ecdf(&values, *value) <= fraction)
        .ok_or_else(|| invalid("sparse numeric threshold is undefined"))
}

pub(super) fn fraction(auc: &[f64], components: &[f64], value: f64) -> Result<Thresholds> {
    Ok(Thresholds {
        x0: numeric(auc, value)?,
        z0: numeric(components, value)?,
        d0: 0.0,
        normalization: 1.0,
        fdr: vec![value],
    })
}

fn knee(values: &[f64]) -> Result<f64> {
    if values.len() < 2 {
        return Err(invalid(
            "sparse normalization knee needs at least two blocks",
        ));
    }
    let ascending = sorted(values);
    let maximum = ascending[ascending.len() - 1];
    let descending = ascending.iter().rev().copied().collect::<Vec<_>>();
    let curve = descending
        .iter()
        .enumerate()
        .map(|(index, value)| {
            let count = 1.0 + index as f64 * (-1.0 / (values.len() - 1) as f64);
            count - value / maximum
        })
        .collect::<Vec<_>>();
    let max_difference = curve.iter().map(|value| value.abs()).fold(0.0, f64::max);
    let mut best = None;
    for (index, difference) in curve.iter().enumerate() {
        if difference.abs() > 0.9 * max_difference
            && best.is_none_or(|prior: usize| *difference > curve[prior])
        {
            best = Some(index);
        }
    }
    let index = best.ok_or_else(|| invalid("sparse normalization knee is undefined"))?;
    let percentile_index = (0.9 * values.len() as f64) as usize;
    if percentile_index == 0 {
        return Err(invalid("sparse normalization percentile is undefined"));
    }
    Ok(descending[index].max(ascending[percentile_index - 1]))
}

fn peak(axis: &[f64], probability: &impl Fn(f64) -> f64) -> Result<Vec<f64>> {
    let eligible = axis
        .iter()
        .map(|value| probability(*value))
        .filter(|value| *value < 1.0)
        .filter(|value| !value.is_nan())
        .collect::<Vec<_>>();
    let maximum = eligible
        .iter()
        .copied()
        .reduce(f64::max)
        .ok_or_else(|| invalid("sparse empirical threshold has no eligible probability"))?;
    // SEACR indexes the original axis with positions in the filtered probability vector.
    Ok(eligible
        .iter()
        .enumerate()
        .filter(|(_, value)| **value == maximum)
        .map(|(index, _)| axis[index])
        .collect())
}

fn relaxed(axis: &[f64], peaks: &[f64], probability: &impl Fn(f64) -> f64) -> Result<Vec<f64>> {
    let candidates = axis
        .iter()
        .copied()
        .filter(|value| *value <= peaks[0])
        .collect::<Vec<_>>();
    let minimum = candidates
        .iter()
        .map(|value| probability(*value))
        .reduce(f64::min)
        .ok_or_else(|| invalid("sparse relaxed threshold has no lower curve"))?;
    let centers = peaks
        .iter()
        .map(|value| (probability(*value) + minimum) / 2.0)
        .collect::<Vec<_>>();
    let distances = candidates
        .iter()
        .enumerate()
        .map(|(index, value)| (centers[index % centers.len()] - probability(*value)).abs())
        .collect::<Vec<_>>();
    let distance = distances
        .iter()
        .copied()
        .reduce(f64::min)
        .ok_or_else(|| invalid("sparse relaxed threshold has no midpoint"))?;
    let lower = candidates
        .iter()
        .zip(distances)
        .find(|(_, value)| *value == distance)
        .map(|(value, _)| *value)
        .ok_or_else(|| invalid("sparse relaxed threshold midpoint is undefined"))?;
    if lower == peaks[0] {
        return Ok(peaks.to_vec());
    }
    let upper = candidates
        .into_iter()
        .filter(|value| *value > lower)
        .collect::<Vec<_>>();
    if upper.is_empty() {
        return Err(invalid("sparse relaxed threshold interval is empty"));
    }
    let target = upper[upper.len() - 1] - 0.5 * (upper[upper.len() - 1] - upper[0]);
    let minimum = upper
        .iter()
        .map(|value| (value - target).abs())
        .fold(f64::INFINITY, f64::min);
    Ok(upper
        .into_iter()
        .filter(|value| (value - target).abs() == minimum)
        .collect())
}

pub(super) fn control(
    auc: &[f64],
    control_auc: &[f64],
    components: &[f64],
    control_components: &[f64],
    normalize: bool,
) -> Result<Thresholds> {
    let normalization = if normalize {
        let exp_limit = knee(auc)?;
        let ctrl_limit = knee(control_auc)?;
        let exp = auc
            .iter()
            .copied()
            .filter(|value| *value <= exp_limit)
            .collect::<Vec<_>>();
        let ctrl = control_auc
            .iter()
            .copied()
            .filter(|value| *value <= ctrl_limit)
            .collect::<Vec<_>>();
        mode(&exp)? / mode(&ctrl)?
    } else {
        1.0
    };
    if !normalization.is_finite() || normalization <= 0.0 {
        return Err(invalid(
            "sparse normalization ratio is not finite and positive",
        ));
    }
    let experiment = sorted(auc);
    let control = control_auc
        .iter()
        .map(|value| value * normalization)
        .collect::<Vec<_>>();
    if control.iter().any(|value| !value.is_finite()) {
        return Err(invalid("normalized sparse control AUC overflows"));
    }
    let mut both = experiment
        .iter()
        .chain(&control)
        .copied()
        .collect::<Vec<_>>();
    both.sort_unstable_by(f64::total_cmp);
    let mut axis = both.clone();
    axis.dedup();
    let probability = |value| {
        (experiment.len() as f64 - ecdf(&experiment, value) * experiment.len() as f64)
            / (both.len() as f64 - ecdf(&both, value) * both.len() as f64)
    };
    let mut x0 = peak(&axis, &probability)?;
    let mut z0 = relaxed(&axis, &x0, &probability)?;
    let frame = axis
        .windows(2)
        .filter_map(|pair| {
            let value = probability(pair[0]);
            let difference = (probability(pair[1]) - value).abs();
            (!value.is_nan() && !difference.is_nan()).then_some((pair[0], value, difference))
        })
        .collect::<Vec<_>>();
    let differences = sorted(&frame.iter().map(|row| row.2).collect::<Vec<_>>());
    if differences.is_empty() || differences[differences.len() - 1] == 0.0 {
        return Err(invalid(
            "sparse spurious-threshold fit has no nonzero curve change",
        ));
    }
    let mut nines = 2;
    let cutoff = loop {
        let probability = 1.0 - 10.0_f64.powi(-nines);
        let cutoff = quantile(&differences, probability);
        if cutoff != 0.0 {
            break cutoff;
        }
        nines += 1;
    };
    let subaxis = frame
        .iter()
        .filter(|row| row.2 != 0.0 && row.2 < cutoff)
        .map(|row| row.0)
        .collect::<Vec<_>>();
    let a0 = peak(&subaxis, &probability)?;
    let b0 = relaxed(&subaxis, &a0, &probability)?;
    let maximum = |values: &[f64]| {
        values
            .iter()
            .map(|value| probability(*value))
            .filter(|value| *value < 1.0)
            .fold(f64::NEG_INFINITY, f64::max)
    };
    if maximum(&subaxis) / maximum(&axis) > 0.95 {
        x0 = a0;
        z0 = b0;
    }
    let exp_components = sorted(components);
    let ctrl_components = sorted(control_components);
    let d0 = exp_components
        .iter()
        .chain(&ctrl_components)
        .copied()
        .filter(|value| {
            1.0 - (ecdf(&exp_components, *value) - ecdf(&ctrl_components, *value)) > 1.0
        })
        .reduce(f64::min)
        .unwrap_or(1.0);
    let fdr = vec![1.0 - probability(x0[0]), 1.0 - probability(z0[0])];
    let result = Thresholds {
        x0: x0[0],
        z0: z0[0],
        d0,
        normalization,
        fdr,
    };
    if [result.x0, result.z0, result.d0]
        .iter()
        .chain(&result.fdr)
        .any(|value| !value.is_finite())
    {
        return Err(invalid(
            "sparse empirical fit produced nonfinite thresholds",
        ));
    }
    Ok(result)
}
