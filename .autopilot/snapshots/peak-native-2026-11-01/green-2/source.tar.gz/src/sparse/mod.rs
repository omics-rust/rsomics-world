mod density;
mod thresholds;

use crate::{
    execution::Execution,
    io::OutputGroup,
    model::{ChromDictionary, ChromId, invalid},
};
use rsomics_common::{Context, Result};
use serde::Serialize;
use std::{
    collections::HashSet,
    fs::File,
    io::{BufRead, BufReader, BufWriter, Read, Write},
    path::{Path, PathBuf},
};
use thresholds::{Thresholds, round_significant};

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub(crate) enum Compatibility {
    Seacr13,
    Corrected,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "lowercase")]
pub(crate) enum Mode {
    Stringent,
    Relaxed,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "lowercase")]
pub(crate) enum Normalization {
    Norm,
    Non,
}

#[derive(Debug)]
pub(crate) enum Threshold {
    Control(PathBuf),
    Fraction(f64),
}

#[derive(Debug)]
pub(crate) struct SparseConfig {
    pub target: PathBuf,
    pub threshold: Threshold,
    pub normalization: Normalization,
    pub mode: Mode,
    pub compatibility: Compatibility,
    pub output: PathBuf,
    pub report: PathBuf,
}

#[derive(Debug, Serialize)]
pub(crate) struct SparseReport {
    compatibility: Compatibility,
    mode: Mode,
    normalization: Normalization,
    input_records: Vec<u64>,
    input_blocks: Vec<usize>,
    omitted_initial_records: Vec<u64>,
    omitted_terminal_blocks: Vec<u64>,
    selected_blocks: usize,
    merged_blocks: usize,
    excluded_by_control: usize,
    peaks: usize,
    thresholds: Thresholds,
    merge_gap: f64,
    requested_threads: usize,
    reading_workers: usize,
    merging_workers: usize,
    output: PathBuf,
    report: PathBuf,
}

#[derive(Clone, Debug)]
struct Block {
    chrom: ChromId,
    start: u64,
    end: u64,
    auc: f64,
    maximum: f64,
    maximum_text: String,
    maximum_start: u64,
    maximum_end: u64,
    components: u64,
}

struct Track {
    dictionary: ChromDictionary,
    blocks: Vec<Block>,
    records: u64,
    omitted_initial: u64,
    omitted_terminal: u64,
}

fn finish_block(block: &mut Block) -> Result<()> {
    if !block.auc.is_finite() {
        return Err(invalid("sparse block AUC overflows a finite value"));
    }
    block.auc = round_significant(block.auc, 6);
    Ok(())
}

fn read_track(path: &Path, compatibility: Compatibility, budget: usize) -> Result<Track> {
    let file =
        File::open(path).rs_with_context(|| format!("opening bedGraph {}", path.display()))?;
    let mut reader = BufReader::new(file);
    let mut track = Track {
        dictionary: ChromDictionary::default(),
        blocks: Vec::new(),
        records: 0,
        omitted_initial: 0,
        omitted_terminal: 0,
    };
    let mut pending: Option<Block> = None;
    let mut previous = None;
    let mut completed = HashSet::new();
    let mut line = String::new();
    let mut line_number = 0;
    loop {
        line.clear();
        line_number += 1;
        let context = || format!("{}:{line_number}", path.display());
        if reader
            .by_ref()
            .take(1024 * 1024 + 1)
            .read_line(&mut line)
            .rs_with_context(context)?
            == 0
        {
            break;
        }
        if line.len() > 1024 * 1024 {
            return Err(invalid(format!("{}: bedGraph row exceeds1MiB", context())));
        }
        let text = line.trim();
        if text.is_empty()
            || text.starts_with('#')
            || text.starts_with("track ")
            || text.starts_with("browser ")
        {
            continue;
        }
        let fields = text.split_whitespace().collect::<Vec<_>>();
        if fields.len() != 4 {
            return Err(invalid(format!(
                "{}: expected four bedGraph fields",
                context()
            )));
        }
        let chrom = track.dictionary.intern(fields[0], None)?;
        let start = fields[1]
            .parse::<u64>()
            .map_err(|error| invalid(format!("{}: start: {error}", context())))?;
        let end = fields[2]
            .parse::<u64>()
            .map_err(|error| invalid(format!("{}: end: {error}", context())))?;
        let value = fields[3]
            .parse::<f64>()
            .map_err(|error| invalid(format!("{}: signal: {error}", context())))?;
        if start >= end || !value.is_finite() || value < 0.0 {
            return Err(invalid(format!(
                "{}: bedGraph needs a nonempty span and finite nonnegative signal",
                context()
            )));
        }
        if let Some((last_chrom, last_end)) = previous {
            if chrom == last_chrom {
                if start < last_end {
                    return Err(invalid(format!(
                        "{}: overlapping or unsorted bedGraph rows",
                        context()
                    )));
                }
            } else {
                completed.insert(last_chrom);
                if completed.contains(&chrom) {
                    return Err(invalid(format!(
                        "{}: repeated bedGraph chromosome group",
                        context()
                    )));
                }
            }
        }
        previous = Some((chrom, end));
        track.records += 1;
        if compatibility == Compatibility::Seacr13 && line_number == 1 {
            track.omitted_initial += 1;
            continue;
        }
        if value == 0.0 {
            continue;
        }
        let auc = value * (end - start) as f64;
        if let Some(block) = pending
            .as_mut()
            .filter(|block| block.chrom == chrom && block.end == start)
        {
            block.end = end;
            block.auc += auc;
            block.components += 1;
            if value > block.maximum {
                block.maximum = value;
                block.maximum_text = fields[3].into();
                block.maximum_start = start;
                block.maximum_end = end;
            } else if value == block.maximum {
                block.maximum_end = end;
            }
        } else {
            if let Some(mut block) = pending.take() {
                finish_block(&mut block)?;
                track.blocks.push(block);
            }
            pending = Some(Block {
                chrom,
                start,
                end,
                auc,
                maximum: value,
                maximum_text: fields[3].into(),
                maximum_start: start,
                maximum_end: end,
                components: 1,
            });
        }
        if track
            .blocks
            .len()
            .saturating_mul(std::mem::size_of::<Block>() + 32)
            > budget
        {
            return Err(invalid(format!(
                "{}: sparse blocks exceed the invocation memory budget",
                path.display()
            )));
        }
    }
    if let Some(mut block) = pending {
        finish_block(&mut block)?;
        if compatibility == Compatibility::Corrected {
            track.blocks.push(block);
        } else {
            track.omitted_terminal = 1;
        }
    }
    Ok(track)
}

fn merge(blocks: &[Block], gap: f64) -> Result<Vec<Block>> {
    let mut result: Vec<Block> = Vec::new();
    for block in blocks {
        if let Some(prior) = result
            .last_mut()
            .filter(|prior| (block.start as f64) < prior.end as f64 + gap)
        {
            prior.end = block.end;
            prior.auc += block.auc;
            prior.components += block.components;
            if block.maximum > prior.maximum {
                prior.maximum = block.maximum;
                prior.maximum_text.clone_from(&block.maximum_text);
                prior.maximum_start = block.maximum_start;
                prior.maximum_end = block.maximum_end;
            } else if block.maximum == prior.maximum {
                prior.maximum_end = block.maximum_end;
            }
            if !prior.auc.is_finite() {
                return Err(invalid("merged sparse AUC overflows"));
            }
        } else {
            result.push(block.clone());
        }
    }
    Ok(result)
}

fn mask_control(
    peaks: Vec<Block>,
    target: &ChromDictionary,
    control: &Track,
    normalization: f64,
    threshold: f64,
) -> Vec<Block> {
    let normalization = round_significant(normalization, 15);
    let mut spans = vec![Vec::new(); target.chromosomes.len()];
    for block in &control.blocks {
        let value = round_significant(block.auc * normalization, 6);
        if value > threshold
            && let Some(chrom) = target.find(&control.dictionary.chromosomes[block.chrom.0].name)
        {
            spans[chrom.0].push((block.start, block.end));
        }
    }
    let mut cursor = vec![0; spans.len()];
    peaks
        .into_iter()
        .filter(|peak| {
            let intervals = &spans[peak.chrom.0];
            let index = &mut cursor[peak.chrom.0];
            while *index < intervals.len() && intervals[*index].1 <= peak.start {
                *index += 1;
            }
            !(*index < intervals.len() && intervals[*index].0 < peak.end)
        })
        .collect()
}

pub(crate) fn run(config: &SparseConfig, execution: &Execution) -> Result<SparseReport> {
    let mut inputs = vec![config.target.clone()];
    match &config.threshold {
        Threshold::Fraction(value) => {
            if !value.is_finite()
                || *value <= 0.0
                || *value > 1.0
                || config.normalization != Normalization::Non
            {
                return Err(invalid(
                    "numeric sparse threshold needs fraction in(0,1] and normalization=non",
                ));
            }
        }
        Threshold::Control(path) => inputs.push(path.clone()),
    }
    let tracks = execution.ordered_map(inputs.len(), |index| {
        read_track(
            &inputs[index],
            config.compatibility,
            execution.memory_budget / (4 * inputs.len()),
        )
    })?;
    if tracks.iter().any(|track| track.blocks.is_empty()) {
        return Err(invalid(
            "sparse threshold fitting needs nonempty experiment/control blocks",
        ));
    }
    let target = &tracks[0];
    let auc = target
        .blocks
        .iter()
        .map(|block| block.auc)
        .collect::<Vec<_>>();
    let components = target
        .blocks
        .iter()
        .map(|block| block.components as f64)
        .collect::<Vec<_>>();
    let thresholds = match config.threshold {
        Threshold::Fraction(value) => thresholds::fraction(&auc, &components, value)?,
        Threshold::Control(_) => {
            let control = &tracks[1];
            thresholds::control(
                &auc,
                &control
                    .blocks
                    .iter()
                    .map(|block| block.auc)
                    .collect::<Vec<_>>(),
                &components,
                &control
                    .blocks
                    .iter()
                    .map(|block| block.components as f64)
                    .collect::<Vec<_>>(),
                config.normalization == Normalization::Norm,
            )?
        }
    };
    let cutoff = round_significant(
        match config.mode {
            Mode::Stringent => thresholds.x0,
            Mode::Relaxed => thresholds.z0,
        },
        15,
    );
    let component_cutoff = round_significant(thresholds.d0, 15);
    let selected = target
        .blocks
        .iter()
        .filter(|block| block.auc > cutoff && block.components as f64 > component_cutoff)
        .cloned()
        .collect::<Vec<_>>();
    let gap = if selected.is_empty() {
        0.0
    } else {
        round_significant(
            selected
                .iter()
                .map(|block| (block.end - block.start) as f64)
                .sum::<f64>()
                / (selected.len() as f64 * 10.0),
            6,
        )
    };
    let merged = execution.ordered_map(target.dictionary.chromosomes.len(), |index| {
        let start = selected.partition_point(|block| block.chrom.0 < index);
        let end = selected.partition_point(|block| block.chrom.0 <= index);
        merge(&selected[start..end], gap)
    })?;
    let mut peaks = merged.into_iter().flatten().collect::<Vec<_>>();
    if config.compatibility == Compatibility::Seacr13 {
        peaks.pop();
    }
    let merged_blocks = peaks.len();
    if matches!(config.threshold, Threshold::Control(_)) {
        peaks = mask_control(
            peaks,
            &target.dictionary,
            &tracks[1],
            thresholds.normalization,
            round_significant(thresholds.x0, 15),
        );
    }
    let report = SparseReport {
        compatibility: config.compatibility,
        mode: config.mode,
        normalization: config.normalization,
        input_records: tracks.iter().map(|track| track.records).collect(),
        input_blocks: tracks.iter().map(|track| track.blocks.len()).collect(),
        omitted_initial_records: tracks.iter().map(|track| track.omitted_initial).collect(),
        omitted_terminal_blocks: tracks.iter().map(|track| track.omitted_terminal).collect(),
        selected_blocks: selected.len(),
        merged_blocks,
        excluded_by_control: merged_blocks - peaks.len(),
        peaks: peaks.len(),
        thresholds,
        merge_gap: gap,
        requested_threads: execution.threads.get(),
        reading_workers: execution.workers_for(inputs.len()),
        merging_workers: execution.workers_for(target.dictionary.chromosomes.len()),
        output: config.output.clone(),
        report: config.report.clone(),
    };
    let mut output = OutputGroup::new(&inputs, &[config.output.clone(), config.report.clone()])?;
    {
        let mut bed = BufWriter::new(output.file_mut(0));
        for peak in &peaks {
            let chrom = &target.dictionary.chromosomes[peak.chrom.0].name;
            writeln!(
                bed,
                "{chrom}\t{}\t{}\t{}\t{}\t{chrom}:{}-{}",
                peak.start,
                peak.end,
                round_significant(peak.auc, 6),
                peak.maximum_text,
                peak.maximum_start,
                peak.maximum_end
            )?;
        }
        bed.flush()?;
    }
    {
        let mut writer = BufWriter::new(output.file_mut(1));
        serde_json::to_writer_pretty(&mut writer, &report)
            .map_err(|error| invalid(error.to_string()))?;
        writeln!(writer)?;
        writer.flush()?;
    }
    output.commit()?;
    Ok(report)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::num::NonZeroUsize;

    #[test]
    fn numeric_workflow_preserves_corrected_endpoints_and_explicit_legacy_losses() {
        let root = tempfile::tempdir().unwrap();
        let input = root.path().join("target.bg");
        std::fs::write(
            &input,
            "chrA\t0\t10\t1\nchrA\t20\t30\t2\nchrA\t40\t50\t3\nchrA\t60\t70\t4\nchrB\t0\t10\t5\n",
        )
        .unwrap();
        for workers in [1, 4] {
            for profile in [Compatibility::Corrected, Compatibility::Seacr13] {
                let config = SparseConfig {
                    target: input.clone(),
                    threshold: Threshold::Fraction(0.5),
                    normalization: Normalization::Non,
                    mode: Mode::Stringent,
                    compatibility: profile,
                    output: root.path().join(format!("{workers}-{profile:?}.bed")),
                    report: root.path().join(format!("{workers}-{profile:?}.json")),
                };
                let report = run(
                    &config,
                    &Execution::new(NonZeroUsize::new(workers).unwrap()),
                )
                .unwrap();
                let actual = std::fs::read_to_string(&config.output).unwrap();
                if profile == Compatibility::Corrected {
                    assert_eq!(
                        actual,
                        "chrA\t60\t70\t40\t4\tchrA:60-70\nchrB\t0\t10\t50\t5\tchrB:0-10\n"
                    );
                    assert_eq!(report.peaks, 2);
                    assert_eq!(report.thresholds.x0, 30.0);
                } else {
                    assert_eq!(actual, "");
                    assert_eq!(report.omitted_initial_records, [1]);
                    assert_eq!(report.omitted_terminal_blocks, [1]);
                }
            }
        }
    }

    #[test]
    #[ignore = "requires the separately retained and verified current source casebook"]
    fn original_six_sparse_workflows_match_retained_source_and_threshold_state() {
        let source = PathBuf::from(
            std::env::var_os("RSOMICS_PEAK_SOURCE_CALLS")
                .expect("explicit retained source calls required"),
        );
        let root = tempfile::tempdir().unwrap();
        for workers in [1, 4] {
            for (label, normalization, controlled) in [
                ("control-norm", Normalization::Norm, true),
                ("control-non", Normalization::Non, true),
                ("numeric", Normalization::Non, false),
            ] {
                for mode in [Mode::Stringent, Mode::Relaxed] {
                    let suffix = match mode {
                        Mode::Stringent => "stringent",
                        Mode::Relaxed => "relaxed",
                    };
                    let case = format!("S-{label}-{suffix}");
                    let config = SparseConfig {
                        target: source.join("track-target/stdout.txt"),
                        threshold: if controlled {
                            Threshold::Control(source.join("track-control/stdout.txt"))
                        } else {
                            Threshold::Fraction(0.1)
                        },
                        normalization,
                        mode,
                        compatibility: Compatibility::Seacr13,
                        output: root.path().join(format!("{workers}-{case}.bed")),
                        report: root.path().join(format!("{workers}-{case}.json")),
                    };
                    let actual = run(
                        &config,
                        &Execution::new(NonZeroUsize::new(workers).unwrap()),
                    )
                    .unwrap();
                    let native = std::fs::read_to_string(&config.output).unwrap();
                    let expected = std::fs::read_to_string(
                        source.join(&case).join(format!("result.{suffix}.bed")),
                    )
                    .unwrap();
                    let native = native
                        .lines()
                        .map(|line| line.split_whitespace().collect::<Vec<_>>())
                        .collect::<Vec<_>>();
                    let expected = expected
                        .lines()
                        .map(|line| line.split_whitespace().collect::<Vec<_>>())
                        .collect::<Vec<_>>();
                    assert_eq!(native.len(), expected.len(), "{case},workers={workers}");
                    for (index, (native, expected)) in native.iter().zip(&expected).enumerate() {
                        assert_eq!(native.len(), 6);
                        for column in [0, 1, 2, 5] {
                            assert_eq!(native[column], expected[column], "{case},row={index}");
                        }
                        for column in [3, 4] {
                            assert_eq!(
                                native[column].parse::<f64>().unwrap(),
                                expected[column].parse::<f64>().unwrap(),
                                "{case},row={index},column={column}"
                            );
                        }
                    }
                    let state = std::fs::read_to_string(
                        source.join(format!("D-{case}/retained-r/thresholds.tsv")),
                    )
                    .unwrap();
                    for line in state.lines().skip(1) {
                        let columns = line
                            .split('\t')
                            .map(|value| value.trim_matches('"'))
                            .collect::<Vec<_>>();
                        let expected = columns[2].parse::<f64>().unwrap();
                        let native = match columns[0] {
                            "x0" => actual.thresholds.x0,
                            "z0" => actual.thresholds.z0,
                            "d0" => actual.thresholds.d0,
                            "constant" => actual.thresholds.normalization,
                            "fdr" => {
                                actual.thresholds.fdr[columns[1].parse::<usize>().unwrap() - 1]
                            }
                            other => panic!("unrecognized source threshold state {other}"),
                        };
                        assert!(
                            (native - expected).abs() <= 1e-10 + 1e-10 * expected.abs(),
                            "{case},{}: native{native} vs source{expected}",
                            columns[0]
                        );
                    }
                    println!(
                        "{case} workers={workers}: {} peaks; x0={} z0={} d0={} normalization={}",
                        actual.peaks,
                        actual.thresholds.x0,
                        actual.thresholds.z0,
                        actual.thresholds.d0,
                        actual.thresholds.normalization
                    );
                }
            }
        }
    }
}
