use crate::model::invalid;
use rsomics_common::Result;

pub(super) fn quantile(sorted: &[f64], probability: f64) -> f64 {
    let index = (sorted.len() - 1) as f64 * probability;
    let lower = index.floor() as usize;
    let upper = index.ceil() as usize;
    if lower == upper || sorted[lower] == sorted[upper] {
        sorted[lower]
    } else {
        let weight = index - lower as f64;
        (1.0 - weight) * sorted[lower] + weight * sorted[upper]
    }
}

fn sum(values: impl Iterator<Item = f64>) -> f64 {
    let mut total = 0.0;
    let mut correction = 0.0;
    for value in values {
        let next = total + value;
        correction += if total.abs() >= value.abs() {
            (total - next) + value
        } else {
            (value - next) + total
        };
        total = next;
    }
    total + correction
}

fn bandwidth(values: &[f64], sorted: &[f64]) -> f64 {
    let count = values.len() as f64;
    let initial = sum(values.iter().copied()) / count;
    let mean = initial + sum(values.iter().map(|value| value - initial)) / count;
    let deviation =
        (sum(values.iter().map(|value| (value - mean) * (value - mean))) / (count - 1.0)).sqrt();
    let mut scale = deviation.min((quantile(sorted, 0.75) - quantile(sorted, 0.25)) / 1.34);
    if scale == 0.0 {
        scale = deviation;
    }
    if scale == 0.0 {
        scale = values[0].abs();
    }
    if scale == 0.0 {
        scale = 1.0;
    }
    0.9 * scale * count.powf(-0.2)
}

fn transform(values: &mut [(f64, f64)], inverse: bool) {
    let length = values.len();
    let mut reversed = 0;
    for index in 1..length {
        let mut bit = length >> 1;
        while reversed & bit != 0 {
            reversed ^= bit;
            bit >>= 1;
        }
        reversed ^= bit;
        if index < reversed {
            values.swap(index, reversed);
        }
    }
    let mut width = 2;
    while width <= length {
        let angle = if inverse { 2.0 } else { -2.0 } * std::f64::consts::PI / width as f64;
        let step = (angle.cos(), angle.sin());
        for chunk in values.chunks_exact_mut(width) {
            let mut phase = (1.0, 0.0);
            for index in 0..width / 2 {
                let left = chunk[index];
                let right = chunk[index + width / 2];
                let product = (
                    right.0 * phase.0 - right.1 * phase.1,
                    right.0 * phase.1 + right.1 * phase.0,
                );
                chunk[index] = (left.0 + product.0, left.1 + product.1);
                chunk[index + width / 2] = (left.0 - product.0, left.1 - product.1);
                phase = (
                    phase.0 * step.0 - phase.1 * step.1,
                    phase.0 * step.1 + phase.1 * step.0,
                );
            }
        }
        width *= 2;
    }
}

fn grid(from: f64, to: f64, length: usize) -> Vec<f64> {
    let step = (to - from) / (length - 1) as f64;
    let mut result = (0..length)
        .map(|index| from + index as f64 * step)
        .collect::<Vec<_>>();
    result[length - 1] = to;
    result
}

fn gaussian(z: f64, bandwidth: f64) -> f64 {
    let factor = 1.0 / std::f64::consts::TAU.sqrt();
    if z < 5.0 {
        return factor * (-0.5 * z * z).exp() / bandwidth;
    }
    if z > (-2.0 * std::f64::consts::LN_2 * -1074.0).sqrt() {
        return 0.0;
    }
    let high = (z * 65536.0).round_ties_even() / 65536.0;
    let low = z - high;
    factor / bandwidth * ((-0.5 * high * high).exp() * (-low * (high + 0.5 * low)).exp())
}

pub(super) fn mode(values: &[f64]) -> Result<f64> {
    if values.len() < 2 {
        return Err(invalid(
            "sparse normalization density needs at least two observations",
        ));
    }
    let mut sorted = values.to_vec();
    sorted.sort_unstable_by(f64::total_cmp);
    let bw = bandwidth(values, &sorted);
    if !bw.is_finite() || bw <= 0.0 {
        return Err(invalid(
            "sparse normalization has no finite positive bandwidth",
        ));
    }
    let from = sorted[0] - 3.0 * bw;
    let to = sorted[sorted.len() - 1] + 3.0 * bw;
    let lower = from - 4.0 * bw;
    let upper = to + 4.0 * bw;
    if !lower.is_finite() || !upper.is_finite() || upper <= lower {
        return Err(invalid("sparse normalization density grid is not finite"));
    }
    let mut mass = vec![(0.0, 0.0); 1024];
    let delta = (upper - lower) / 511.0;
    let weight = 1.0 / values.len() as f64;
    for value in values {
        let position = (value - lower) / delta;
        let index = position.floor() as usize;
        let fraction = position - index as f64;
        mass[index].0 += (1.0 - fraction) * weight;
        mass[index + 1].0 += fraction * weight;
    }
    let coordinates = grid(0.0, (1023.0 / 511.0) * (upper - lower), 1024);
    let mut kernel = coordinates
        .iter()
        .enumerate()
        .map(|(index, &coordinate)| {
            let coordinate = if index > 512 {
                -coordinates[1024 - index]
            } else {
                coordinate
            };
            let z = coordinate.abs() / bw;
            let value = gaussian(z, bw);
            (value, 0.0)
        })
        .collect::<Vec<_>>();
    transform(&mut mass, false);
    transform(&mut kernel, false);
    for (value, kernel) in mass.iter_mut().zip(kernel) {
        *value = (
            value.0 * kernel.0 + value.1 * kernel.1,
            value.1 * kernel.0 - value.0 * kernel.1,
        );
    }
    transform(&mut mass, true);
    let density = mass[..512]
        .iter()
        .map(|value| (value.0 / 1024.0).max(0.0))
        .collect::<Vec<_>>();
    let internal = grid(lower, upper, 512);
    let output = grid(from, to, 512);
    let mut interpolated = Vec::with_capacity(512);
    for coordinate in &output {
        let right = internal
            .partition_point(|point| point <= coordinate)
            .clamp(1, 511);
        let left = right - 1;
        interpolated.push(
            density[left]
                + (density[right] - density[left])
                    * ((coordinate - internal[left]) / (internal[right] - internal[left])),
        );
    }
    let maximum = interpolated
        .iter()
        .copied()
        .fold(f64::NEG_INFINITY, f64::max);
    let modes = interpolated
        .iter()
        .enumerate()
        .filter(|(_, value)| **value == maximum)
        .map(|(index, _)| output[index])
        .collect::<Vec<_>>();
    if modes.len() != 1 || !modes[0].is_finite() {
        return Err(invalid(
            "sparse normalization requires a finite scalar density mode; tied modes are unsupported",
        ));
    }
    Ok(modes[0])
}
