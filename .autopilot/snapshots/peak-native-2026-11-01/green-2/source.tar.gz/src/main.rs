fn main() -> std::process::ExitCode {
    rsomics_peak::run_cli()
}
