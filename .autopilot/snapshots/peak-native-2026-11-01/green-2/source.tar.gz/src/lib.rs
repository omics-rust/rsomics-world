mod annotation;
mod call;
mod cli;
mod count;
mod execution;
mod io;
mod model;
mod sparse;

/// Runs the peak product command-line application.
pub fn run_cli() -> std::process::ExitCode {
    let cli: cli::Cli = rsomics_help::parse();
    rsomics_common::run(
        &cli.output,
        rsomics_common::ToolMeta {
            name: "rsomics-peak",
            version: env!("CARGO_PKG_VERSION"),
        },
        || {
            let execution = execution::Execution::new(
                cli.threads
                    .requested()
                    .unwrap_or(std::num::NonZeroUsize::MIN),
            );
            match cli.command {
                cli::Command::Call(args) => {
                    report_value(call::run(&args.into_config()?, &execution)?)
                }
                cli::Command::Count(args) => report_value(count::run(&args, &execution)?),
                cli::Command::CallSparse(args) => {
                    report_value(sparse::run(&args.into_config()?, &execution)?)
                }
                cli::Command::Annotate(args) => {
                    report_value(annotation::run(&args.into_config(), &execution)?)
                }
            }
        },
    )
}

fn report_value(report: impl serde::Serialize) -> rsomics_common::Result<serde_json::Value> {
    serde_json::to_value(report)
        .map_err(|error| model::invalid(format!("serializing command report: {error}")))
}
