mod overlap;

use crate::{
    cli::CountArgs,
    execution::Execution,
    io::{OutputGroup, open_bam, read_peak_rows},
    model::*,
};
use overlap::PeakIndex;
use rsomics_common::{Context, Result};
use serde::Serialize;
use std::{
    collections::HashSet,
    io::{BufWriter, Write},
    num::NonZeroUsize,
    path::PathBuf,
};

#[derive(Clone, Debug, Default, Serialize)]
pub(crate) struct CountConfig {
    pub min_mapq: u8,
    pub proper_pairs_only: bool,
    pub include_duplicates: bool,
    pub include_qc_failed: bool,
    pub split: bool,
}

#[derive(Debug, Serialize)]
pub(crate) struct SampleStatistics {
    pub sample: Sample,
    pub visited_records: u64,
    pub mapped_records: u64,
    pub eligible_alignments: u64,
    pub row_assignments: u64,
    pub missing_contig_rows: usize,
}

pub(crate) struct CountMatrix {
    pub columns: Vec<Vec<u64>>,
    pub statistics: Vec<SampleStatistics>,
}

#[derive(Serialize)]
pub(crate) struct CountReport {
    pub unit: &'static str,
    pub source_profile: &'static str,
    pub peaks: PathBuf,
    pub output: PathBuf,
    pub report: PathBuf,
    pub rows: usize,
    pub stranded_rows: usize,
    pub options: CountConfig,
    pub requested_threads: usize,
    pub effective_workers: usize,
    pub strategy: &'static str,
    pub scratch: PathBuf,
    pub samples: Vec<SampleStatistics>,
}

pub(crate) fn compute(
    peaks: &PeakRows,
    samples: &[Sample],
    config: &CountConfig,
    execution: &Execution,
) -> Result<CountMatrix> {
    if samples.is_empty() {
        return Err(invalid("count requires at least one named BAM sample"));
    }
    let mut names = HashSet::new();
    let mut dictionaries = Vec::new();
    let mut merged = peaks.dictionary.clone();
    for sample in samples {
        if !names.insert(&sample.name) {
            return Err(invalid(format!("duplicate sample name {}", sample.name)));
        }
        let (_, dictionary) = open_bam(&sample.path, NonZeroUsize::MIN)?;
        for chrom in &dictionary.chromosomes {
            merged.intern(&chrom.name, chrom.len)?;
        }
        dictionaries.push(dictionary);
    }
    let cells = peaks
        .rows
        .len()
        .checked_mul(samples.len())
        .and_then(|n| n.checked_mul(8))
        .ok_or_else(|| invalid("count matrix allocation overflows"))?;
    let rows_size = peaks
        .rows
        .iter()
        .try_fold(0usize, |sum, row| {
            sum.checked_add(
                std::mem::size_of::<PeakRow>()
                    + 80
                    + row
                        .original_fields
                        .iter()
                        .map(|field| field.len() + std::mem::size_of::<String>())
                        .sum::<usize>(),
            )
        })
        .ok_or_else(|| invalid("peak index allocation overflows"))?;
    if cells
        .checked_add(rows_size)
        .is_none_or(|bytes| bytes > execution.memory_budget)
    {
        return Err(invalid(
            "count matrix and peak index exceed the invocation memory budget; reduce rows/samples per invocation",
        ));
    }
    let index = PeakIndex::new(peaks);
    let results = execution.ordered_map(samples.len(), |sample| {
        count_sample(
            peaks,
            &index,
            &samples[sample],
            &dictionaries[sample],
            config,
        )
    })?;
    let (columns, statistics) = results.into_iter().unzip();
    Ok(CountMatrix {
        columns,
        statistics,
    })
}

fn add(counter: &mut u64) -> Result<()> {
    *counter = counter
        .checked_add(1)
        .ok_or_else(|| invalid("alignment count overflow"))?;
    Ok(())
}

fn count_sample(
    peaks: &PeakRows,
    index: &PeakIndex,
    sample: &Sample,
    admitted: &ChromDictionary,
    config: &CountConfig,
) -> Result<(Vec<u64>, SampleStatistics)> {
    let (mut reader, dictionary) = open_bam(&sample.path, NonZeroUsize::MIN)?;
    if dictionary
        .chromosomes
        .iter()
        .map(|c| (&c.name, c.len))
        .ne(admitted.chromosomes.iter().map(|c| (&c.name, c.len)))
    {
        return Err(invalid(format!(
            "{}: BAM dictionary changed after admission",
            sample.path.display()
        )));
    }
    let mapping = dictionary
        .chromosomes
        .iter()
        .map(|c| peaks.dictionary.find(&c.name))
        .collect::<Vec<_>>();
    let mut statistics = SampleStatistics {
        sample: sample.clone(),
        visited_records: 0,
        mapped_records: 0,
        eligible_alignments: 0,
        row_assignments: 0,
        missing_contig_rows: peaks
            .rows
            .iter()
            .filter(|row| {
                dictionary
                    .find(&peaks.dictionary.chromosomes[row.span.chrom.0].name)
                    .is_none()
            })
            .count(),
    };
    let mut counts = vec![0u64; peaks.rows.len()];
    let mut raw = rsomics_bamio::raw::RawRecord::default();
    let mut cigar = Vec::new();
    let mut blocks = Vec::<(u64, u64)>::new();
    let mut hits = Vec::new();
    loop {
        let bytes =
            rsomics_bamio::raw::read_record(reader.get_mut(), &mut raw).rs_with_context(|| {
                format!(
                    "{}: record {}",
                    sample.path.display(),
                    statistics.visited_records + 1
                )
            })?;
        if bytes == 0 {
            break;
        }
        add(&mut statistics.visited_records)?;
        let flags = raw.flags();
        if flags & 4 != 0 {
            continue;
        }
        add(&mut statistics.mapped_records)?;
        if raw.mapping_quality() < config.min_mapq
            || config.proper_pairs_only && flags & 2 == 0
            || !config.include_duplicates && flags & 1024 != 0
            || !config.include_qc_failed && flags & 512 != 0
        {
            continue;
        }
        add(&mut statistics.eligible_alignments)?;
        let context = || {
            format!(
                "{}: record {} read {}",
                sample.path.display(),
                statistics.visited_records,
                String::from_utf8_lossy(raw.name())
            )
        };
        let reference = usize::try_from(raw.reference_sequence_id())
            .map_err(|_| invalid(format!("{}: mapped record lacks reference", context())))?;
        let chrom = dictionary
            .chromosomes
            .get(reference)
            .ok_or_else(|| invalid(format!("{}: reference ID outside header", context())))?;
        let start = u64::try_from(raw.alignment_start())
            .map_err(|_| invalid(format!("{}: mapped record lacks position", context())))?;
        raw.decode_cigar_into(&mut cigar).rs_with_context(context)?;
        if cigar.is_empty() {
            return Err(invalid(format!("{}: mapped record lacks CIGAR", context())));
        }
        blocks.clear();
        let mut cursor = start;
        let mut block_start = start;
        for &(kind, length) in &cigar {
            if matches!(kind, 0 | 2 | 3 | 7 | 8) {
                if config.split && kind == 3 {
                    if block_start < cursor {
                        blocks.push((block_start, cursor));
                    }
                    cursor = cursor
                        .checked_add(u64::from(length))
                        .ok_or_else(|| invalid(format!("{}: CIGAR span overflow", context())))?;
                    block_start = cursor;
                } else {
                    cursor = cursor
                        .checked_add(u64::from(length))
                        .ok_or_else(|| invalid(format!("{}: CIGAR span overflow", context())))?;
                }
            }
        }
        if cursor > chrom.len.expect("BAM dictionary lengths are known") {
            return Err(invalid(format!(
                "{}: CIGAR extends beyond chromosome {}",
                context(),
                chrom.name
            )));
        }
        if block_start < cursor {
            blocks.push((block_start, cursor));
        }
        let Some(chrom) = mapping[reference] else {
            continue;
        };
        if start == cursor {
            continue;
        }
        let span = Span::new(chrom, start, cursor)?;
        index.overlaps(span, &mut hits);
        let footprint = blocks
            .iter()
            .map(|&(left, right)| right - left)
            .sum::<u64>();
        for &hit in &hits {
            let row = &peaks.rows[hit];
            let overlap = blocks
                .iter()
                .map(|&(left, right)| {
                    right
                        .min(row.span.end)
                        .saturating_sub(left.max(row.span.start))
                })
                .sum::<u64>();
            let denominator = if config.split {
                footprint
            } else {
                row.span.end - row.span.start
            };
            let fraction = overlap as f32 / denominator as f32;
            let selected = overlap > 0
                && if config.split {
                    fraction > 1e-9_f32
                } else {
                    fraction >= 1e-9_f32
                };
            if selected {
                add(&mut counts[row.id.0])?;
                add(&mut statistics.row_assignments)?;
            }
        }
    }
    Ok((counts, statistics))
}

pub(crate) fn run(args: &CountArgs, execution: &Execution) -> Result<CountReport> {
    let peaks = read_peak_rows(&args.peaks, execution.memory_budget / 2)?;
    let config = CountConfig {
        min_mapq: args.min_mapq,
        proper_pairs_only: args.proper_pairs_only,
        include_duplicates: args.include_duplicates,
        include_qc_failed: args.include_qc_failed,
        split: args.split,
    };
    let matrix = compute(&peaks, &args.sample, &config, execution)?;
    let report = CountReport {
        unit: "alignment",
        source_profile: "bedtools-2.31.1-multicov",
        peaks: args.peaks.clone(),
        output: args.output.clone(),
        report: args.report.clone(),
        rows: peaks.rows.len(),
        stranded_rows: peaks
            .rows
            .iter()
            .filter(|row| row.strand != Strand::Unknown)
            .count(),
        options: config,
        requested_threads: execution.threads.get(),
        effective_workers: execution.workers_for(args.sample.len()),
        strategy: "ordered parallel sample scans; one serial BGZF decoder per worker; immutable interval index",
        scratch: execution.scratch.clone(),
        samples: matrix.statistics,
    };
    let mut inputs = vec![args.peaks.clone()];
    inputs.extend(args.sample.iter().map(|sample| sample.path.clone()));
    let mut output = OutputGroup::new(&inputs, &[args.output.clone(), args.report.clone()])?;
    {
        let mut writer = BufWriter::new(output.file_mut(0));
        write!(writer, "#chrom\tstart\tend")?;
        for column in 3..peaks.field_count {
            write!(writer, "\tfield{}", column + 1)?;
        }
        for sample in &args.sample {
            write!(writer, "\t{}", sample.name)?;
        }
        writeln!(writer)?;
        for row in &peaks.rows {
            write!(writer, "{}", row.original_fields.join("\t"))?;
            for column in &matrix.columns {
                write!(writer, "\t{}", column[row.id.0])?;
            }
            writeln!(writer)?;
        }
        writer.flush()?;
    }
    serde_json::to_writer_pretty(output.file_mut(1), &report)
        .map_err(|e| invalid(format!("writing count report: {e}")))?;
    output.file_mut(1).write_all(b"\n")?;
    output.commit()?;
    Ok(report)
}
