use crate::model::{PeakRows, Span};

struct Node {
    row: usize,
    start: u64,
    end: u64,
    max_end: u64,
    left: Option<usize>,
    right: Option<usize>,
}

pub(super) struct PeakIndex {
    roots: Vec<Option<usize>>,
    nodes: Vec<Node>,
}

impl PeakIndex {
    pub fn new(peaks: &PeakRows) -> Self {
        let mut index = Self {
            roots: vec![None; peaks.dictionary.chromosomes.len()],
            nodes: Vec::with_capacity(peaks.rows.len()),
        };
        let mut chromosomes = vec![Vec::new(); index.roots.len()];
        for row in &peaks.rows {
            chromosomes[row.span.chrom.0].push(row.id.0);
        }
        for (chrom, rows) in chromosomes.iter_mut().enumerate() {
            rows.sort_unstable_by_key(|&id| {
                (peaks.rows[id].span.start, peaks.rows[id].span.end, id)
            });
            index.roots[chrom] = index.build(rows, peaks);
        }
        index
    }
    fn build(&mut self, rows: &[usize], peaks: &PeakRows) -> Option<usize> {
        if rows.is_empty() {
            return None;
        }
        let middle = rows.len() / 2;
        let left = self.build(&rows[..middle], peaks);
        let right = self.build(&rows[middle + 1..], peaks);
        let span = peaks.rows[rows[middle]].span;
        let mut max_end = span.end;
        for id in [left, right].into_iter().flatten() {
            max_end = max_end.max(self.nodes[id].max_end);
        }
        let id = self.nodes.len();
        self.nodes.push(Node {
            row: rows[middle],
            start: span.start,
            end: span.end,
            max_end,
            left,
            right,
        });
        Some(id)
    }
    pub fn overlaps(&self, span: Span, hits: &mut Vec<usize>) {
        hits.clear();
        self.visit(self.roots[span.chrom.0], span.start, span.end, hits);
    }
    fn visit(&self, id: Option<usize>, start: u64, end: u64, hits: &mut Vec<usize>) {
        let Some(id) = id else {
            return;
        };
        let node = &self.nodes[id];
        if node.max_end <= start {
            return;
        }
        self.visit(node.left, start, end, hits);
        if node.start >= end {
            return;
        }
        if node.end > start {
            hits.push(node.row);
        }
        self.visit(node.right, start, end, hits);
    }
}
