use crate::model::{Sample, invalid};
use clap::{Args, Parser, Subcommand, ValueEnum};
use std::path::PathBuf;

#[derive(Debug, Parser)]
#[command(
    name = "rsomics-peak",
    version,
    about = "Native peak workflow operations"
)]
pub(crate) struct Cli {
    #[command(flatten)]
    pub output: rsomics_common::OutputArgs,
    #[command(flatten)]
    pub threads: rsomics_common::ThreadArgs,
    #[command(subcommand)]
    pub command: Command,
}

#[derive(Debug, Subcommand)]
pub(crate) enum Command {
    /// Call narrow peaks from pooled BAM alignments or paired fragments.
    Call(CallArgs),
    /// Count overlapping BAM alignments in ordered peak rows.
    Count(CountArgs),
    /// Call peaks from positive sparse bedGraph signal using an explicit profile.
    CallSparse(SparseArgs),
    /// Annotate ordered peak rows against a transcript-level GTF or GFF3 graph.
    Annotate(AnnotationArgs),
}

#[derive(Clone, Copy, Debug, ValueEnum)]
pub(crate) enum CallFormat {
    Bam,
    Bampe,
}

#[derive(Clone, Copy, Debug, ValueEnum)]
pub(crate) enum CallModel {
    Fitted,
    Fixed,
    PairedEnd,
}

#[derive(Clone, Copy, Debug, ValueEnum)]
pub(crate) enum CallScale {
    Small,
    Large,
}

#[derive(Debug, Args)]
pub(crate) struct CallArgs {
    #[arg(long, required = true, num_args = 1..)]
    pub treatment: Vec<PathBuf>,
    #[arg(long, num_args = 1..)]
    pub control: Vec<PathBuf>,
    #[arg(long, value_enum, default_value = "bam")]
    pub format: CallFormat,
    #[arg(long)]
    pub genome_size: f64,
    #[arg(long, default_value = "1", value_parser = duplicate_policy)]
    pub duplicates: crate::call::DuplicatePolicy,
    #[arg(long, value_enum, default_value = "fitted")]
    pub model: CallModel,
    #[arg(long, required_if_eq("model", "fixed"))]
    pub extension: Option<u32>,
    #[arg(long)]
    pub bandwidth: Option<u32>,
    #[arg(long, num_args = 2)]
    pub mfold: Vec<u32>,
    #[arg(long)]
    pub d_min: Option<u32>,
    #[arg(long)]
    pub fallback_extension: Option<u32>,
    #[arg(long, default_value_t = 0, allow_negative_numbers = true)]
    pub shift: i32,
    #[arg(long, conflicts_with = "qvalue")]
    pub pvalue: Option<f64>,
    #[arg(long, conflicts_with = "pvalue")]
    pub qvalue: Option<f64>,
    #[arg(long, default_value_t = 1000)]
    pub small_local: u32,
    #[arg(long, default_value_t = 10000)]
    pub large_local: u32,
    #[arg(long)]
    pub disable_local: bool,
    #[arg(long, value_enum, default_value = "small")]
    pub scale_to: CallScale,
    #[arg(long)]
    pub tag_size: Option<u32>,
    #[arg(long)]
    pub max_gap: Option<u32>,
    #[arg(long)]
    pub min_length: Option<u32>,
    #[arg(long)]
    pub name: String,
    #[arg(long)]
    pub output_directory: PathBuf,
    #[arg(long)]
    pub write_tracks: bool,
}

fn duplicate_policy(text: &str) -> Result<crate::call::DuplicatePolicy, String> {
    use crate::call::DuplicatePolicy;
    match text {
        "auto" => Ok(DuplicatePolicy::Auto),
        "all" => Ok(DuplicatePolicy::All),
        _ => text
            .parse::<u32>()
            .ok()
            .filter(|limit| *limit > 0)
            .map(DuplicatePolicy::Limit)
            .ok_or_else(|| "duplicates must be auto, all or a positive integer".into()),
    }
}

impl CallArgs {
    pub fn into_config(self) -> rsomics_common::Result<crate::call::CallConfig> {
        use crate::call::{AlignmentFormat, CallConfig, ModelConfig, ScaleTo, ScoreCutoff};
        if !matches!(self.model, CallModel::Fitted)
            && (self.bandwidth.is_some() || !self.mfold.is_empty() || self.d_min.is_some())
        {
            return Err(invalid(
                "bandwidth, mfold and d-min require the fitted model",
            ));
        }
        let model = match self.model {
            CallModel::Fitted if self.extension.is_none() => ModelConfig::Fitted {
                bandwidth: self.bandwidth.unwrap_or(300),
                mfold: if self.mfold.is_empty() {
                    [5, 50]
                } else {
                    [self.mfold[0], self.mfold[1]]
                },
                d_min: self.d_min.unwrap_or(20),
                fallback_extension: self.fallback_extension,
            },
            CallModel::Fixed if self.fallback_extension.is_none() => ModelConfig::Fixed {
                extension: self
                    .extension
                    .ok_or_else(|| invalid("fixed model requires extension"))?,
            },
            CallModel::PairedEnd
                if self.extension.is_none() && self.fallback_extension.is_none() =>
            {
                ModelConfig::PairedEnd
            }
            _ => {
                return Err(invalid(
                    "extension and fallback extension do not apply to this model",
                ));
            }
        };
        Ok(CallConfig {
            treatment: self.treatment,
            control: self.control,
            format: match self.format {
                CallFormat::Bam => AlignmentFormat::Bam,
                CallFormat::Bampe => AlignmentFormat::Bampe,
            },
            genome_size: self.genome_size,
            duplicates: self.duplicates,
            model,
            shift: self.shift,
            score: match self.pvalue {
                Some(value) => ScoreCutoff::P(value),
                None => ScoreCutoff::Q(self.qvalue.unwrap_or(0.05)),
            },
            small_local: self.small_local,
            large_local: self.large_local,
            disable_local: self.disable_local,
            scale_to: match self.scale_to {
                CallScale::Small => ScaleTo::Small,
                CallScale::Large => ScaleTo::Large,
            },
            tag_size: self.tag_size,
            max_gap: self.max_gap,
            min_length: self.min_length,
            name: self.name,
            output_directory: self.output_directory,
            write_tracks: self.write_tracks,
        })
    }
}

#[derive(Clone, Copy, Debug, ValueEnum)]
pub(crate) enum AnnotationFormat {
    Gtf,
    Gff3,
}

#[derive(Debug, Args)]
pub(crate) struct AnnotationArgs {
    #[arg(long)]
    pub peaks: PathBuf,
    #[arg(long)]
    pub annotation: PathBuf,
    #[arg(long, value_enum)]
    pub format: AnnotationFormat,
    #[arg(long)]
    pub output: PathBuf,
    #[arg(long)]
    pub report: PathBuf,
    #[arg(long, default_value_t = 3000)]
    pub tss_upstream: u64,
    #[arg(long, default_value_t = 3000)]
    pub tss_downstream: u64,
    #[arg(long, default_value_t = 3000)]
    pub downstream: u64,
}

impl AnnotationArgs {
    pub fn into_config(self) -> crate::annotation::AnnotationRunConfig {
        use crate::annotation::{AnnotationConfig, AnnotationFormat, AnnotationRunConfig};
        AnnotationRunConfig {
            peaks: self.peaks,
            annotation: self.annotation,
            format: match self.format {
                crate::cli::AnnotationFormat::Gtf => AnnotationFormat::Gtf,
                crate::cli::AnnotationFormat::Gff3 => AnnotationFormat::Gff3,
            },
            output: self.output,
            report: self.report,
            options: AnnotationConfig {
                tss_upstream: self.tss_upstream,
                tss_downstream: self.tss_downstream,
                downstream: self.downstream,
            },
        }
    }
}

#[derive(Debug, Args)]
pub(crate) struct CountArgs {
    #[arg(long)]
    pub peaks: PathBuf,
    #[arg(long, value_name = "NAME=BAM", required = true, num_args = 1.., value_parser = sample)]
    pub sample: Vec<Sample>,
    #[arg(long)]
    pub output: PathBuf,
    #[arg(long)]
    pub report: PathBuf,
    #[arg(long, default_value_t = 0)]
    pub min_mapq: u8,
    #[arg(long)]
    pub proper_pairs_only: bool,
    #[arg(long)]
    pub include_duplicates: bool,
    #[arg(long)]
    pub include_qc_failed: bool,
    #[arg(long)]
    pub split: bool,
}

fn sample(text: &str) -> Result<Sample, String> {
    let (name, path) = text
        .split_once('=')
        .ok_or_else(|| "sample must be NAME=BAM".to_owned())?;
    if name.is_empty() || name.contains(['\t', '\n', '\r']) || path.is_empty() {
        return Err(invalid("sample needs a nonempty TSV-safe name and BAM path").to_string());
    }
    Ok(Sample {
        name: name.into(),
        path: path.into(),
    })
}

#[derive(Clone, Copy, Debug, ValueEnum)]
pub(crate) enum SparseCompatibility {
    /// Preserve the upstream initial-row and terminal-block omissions.
    #[value(name = "seacr-1.3")]
    Seacr13,
    /// Retain every valid input row and terminal signal block.
    Corrected,
}

#[derive(Clone, Copy, Debug, ValueEnum)]
pub(crate) enum SparseMode {
    Stringent,
    Relaxed,
}

#[derive(Clone, Copy, Debug, ValueEnum)]
pub(crate) enum SparseNormalization {
    Norm,
    Non,
}

#[derive(Debug, Args)]
pub(crate) struct SparseArgs {
    #[arg(long)]
    pub target: PathBuf,
    #[arg(
        long,
        required_unless_present = "fraction",
        conflicts_with = "fraction"
    )]
    pub control: Option<PathBuf>,
    #[arg(long, required_unless_present = "control", conflicts_with = "control")]
    pub fraction: Option<f64>,
    #[arg(long, value_enum)]
    pub normalization: SparseNormalization,
    #[arg(long, value_enum)]
    pub mode: SparseMode,
    #[arg(long, value_enum)]
    pub compatibility: SparseCompatibility,
    #[arg(long)]
    pub output: PathBuf,
    #[arg(long)]
    pub report: PathBuf,
}

impl SparseArgs {
    pub fn into_config(self) -> rsomics_common::Result<crate::sparse::SparseConfig> {
        use crate::sparse::{Compatibility, Mode, Normalization, SparseConfig, Threshold};
        let threshold = match (self.control, self.fraction) {
            (Some(path), None) => Threshold::Control(path),
            (None, Some(value)) => Threshold::Fraction(value),
            _ => {
                return Err(invalid(
                    "exactly one sparse control or fraction is required",
                ));
            }
        };
        Ok(SparseConfig {
            target: self.target,
            threshold,
            normalization: match self.normalization {
                SparseNormalization::Norm => Normalization::Norm,
                SparseNormalization::Non => Normalization::Non,
            },
            mode: match self.mode {
                SparseMode::Stringent => Mode::Stringent,
                SparseMode::Relaxed => Mode::Relaxed,
            },
            compatibility: match self.compatibility {
                SparseCompatibility::Seacr13 => Compatibility::Seacr13,
                SparseCompatibility::Corrected => Compatibility::Corrected,
            },
            output: self.output,
            report: self.report,
        })
    }
}
