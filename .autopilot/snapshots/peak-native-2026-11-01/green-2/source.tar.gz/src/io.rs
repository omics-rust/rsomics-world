use crate::model::*;
use rsomics_common::{AtomicFile, Context, Result, reject_output_alias};
use std::{
    collections::{HashMap, hash_map::Entry},
    fs::{File, OpenOptions},
    io::{BufRead, BufReader, ErrorKind, Read},
    num::NonZeroUsize,
    path::{Path, PathBuf},
};

pub(crate) fn open_bam(
    path: &Path,
    workers: NonZeroUsize,
) -> Result<(rsomics_bamio::ParallelBamReader, ChromDictionary)> {
    let mut reader = rsomics_bamio::open_with_workers(path, workers)?;
    let header = reader
        .read_header()
        .rs_with_context(|| format!("reading BAM header {}", path.display()))?;
    let mut dictionary = ChromDictionary::default();
    for (name, reference) in header.reference_sequences() {
        let name = std::str::from_utf8(name.as_ref())
            .map_err(|e| invalid(format!("{}: chromosome name: {e}", path.display())))?;
        dictionary.intern(name, Some(usize::from(reference.length()) as u64))?;
    }
    Ok((reader, dictionary))
}

pub(crate) fn read_peak_rows(path: &Path, memory_budget: usize) -> Result<PeakRows> {
    let mut reader = BufReader::new(
        File::open(path).rs_with_context(|| format!("opening peaks {}", path.display()))?,
    );
    let mut result = PeakRows::default();
    let mut line = Vec::new();
    let mut line_number = 0;
    let mut allocation = 0usize;
    loop {
        line.clear();
        let size = reader
            .by_ref()
            .take(1024 * 1024 + 1)
            .read_until(b'\n', &mut line)?;
        if size == 0 {
            break;
        }
        line_number += 1;
        let context = || format!("{}:{line_number}", path.display());
        if size > 1024 * 1024 {
            return Err(invalid(format!("{}: BED row exceeds1MiB", context())));
        }
        let text = std::str::from_utf8(&line)
            .map_err(|e| invalid(format!("{}: {e}", context())))?
            .trim_end_matches(['\r', '\n']);
        if text.is_empty()
            || text.starts_with(['#'])
            || text.starts_with("track ")
            || text.starts_with("browser ")
        {
            continue;
        }
        let fields = if text.contains('\t') {
            text.split('\t').collect::<Vec<_>>()
        } else {
            text.split_whitespace().collect::<Vec<_>>()
        };
        if fields.len() < 3 || fields.len() >= 12 {
            return Err(invalid(format!(
                "{}: expected BED3..11 or narrowPeak, BED12 is not supported",
                context()
            )));
        }
        if result.field_count != 0 && fields.len() != result.field_count {
            return Err(invalid(format!(
                "{}: inconsistent BED column count",
                context()
            )));
        }
        let start = fields[1]
            .parse::<u64>()
            .map_err(|e| invalid(format!("{}: BED start: {e}", context())))?;
        let end = fields[2]
            .parse::<u64>()
            .map_err(|e| invalid(format!("{}: BED end: {e}", context())))?;
        let strand = match fields.get(5).copied() {
            Some("+") => Strand::Plus,
            Some("-") => Strand::Minus,
            None | Some(".") => Strand::Unknown,
            _ => return Err(invalid(format!("{}: invalid BED strand", context()))),
        };
        let chrom = result.dictionary.intern(fields[0], None)?;
        let span = Span::new(chrom, start, end).rs_with_context(context)?;
        allocation = allocation
            .checked_add(
                size + fields.len() * std::mem::size_of::<String>()
                    + std::mem::size_of::<PeakRow>(),
            )
            .ok_or_else(|| invalid("peak allocation overflow"))?;
        if allocation > memory_budget {
            return Err(invalid("peak rows exceed the invocation memory budget"));
        }
        result.field_count = fields.len();
        result.rows.push(PeakRow {
            id: RowId(result.rows.len()),
            span,
            strand,
            original_fields: fields.into_iter().map(String::from).collect(),
        });
    }
    Ok(result)
}

pub(crate) struct OutputGroup {
    files: Vec<AtomicFile>,
}

impl OutputGroup {
    pub fn new(inputs: &[PathBuf], destinations: &[PathBuf]) -> Result<Self> {
        let mut probes = HashMap::new();
        for (index, path) in destinations.iter().enumerate() {
            if path == Path::new("-") {
                return Err(invalid("transactional grouped outputs require named files"));
            }
            reject_output_alias(path, inputs.iter().map(PathBuf::as_path))?;
            reject_output_alias(path, destinations[..index].iter().map(PathBuf::as_path))?;
            let parent = path
                .parent()
                .filter(|p| !p.as_os_str().is_empty())
                .unwrap_or(Path::new("."));
            let name = path
                .file_name()
                .ok_or_else(|| invalid("output has no file name"))?;
            let parent = parent.canonicalize()?;
            let probe = match probes.entry(same_file::Handle::from_path(&parent)?) {
                Entry::Occupied(entry) => entry.into_mut(),
                Entry::Vacant(entry) => entry.insert(
                    tempfile::Builder::new()
                        .prefix(".rsomics-peak-output-check-")
                        .tempdir_in(&parent)?,
                ),
            };
            match OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(probe.path().join(name))
            {
                Ok(_) => (),
                Err(error) if error.kind() == ErrorKind::AlreadyExists => {
                    return Err(invalid(
                        "output destinations alias each other on this filesystem",
                    ));
                }
                Err(error) => return Err(error.into()),
            }
        }
        Ok(Self {
            files: destinations
                .iter()
                .map(AtomicFile::new)
                .collect::<Result<_>>()?,
        })
    }
    pub fn file_mut(&mut self, index: usize) -> &mut File {
        self.files[index].file_mut()
    }
    pub fn commit(self) -> Result<()> {
        AtomicFile::commit_all(self.files)
    }
}
