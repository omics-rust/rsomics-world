use rsomics_common::{Result, RsomicsError};
use rsomics_intervals::Interval;
use serde::Serialize;
use std::{collections::HashMap, path::PathBuf};

pub(crate) fn invalid(message: impl Into<String>) -> RsomicsError {
    RsomicsError::InvalidInput(message.into())
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Serialize)]
pub(crate) struct ChromId(pub usize);

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Serialize)]
pub(crate) struct RowId(pub usize);

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
pub(crate) enum Strand {
    Plus,
    Minus,
    Unknown,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
pub(crate) struct Span {
    pub chrom: ChromId,
    pub start: u64,
    pub end: u64,
}

impl Span {
    pub fn new(chrom: ChromId, start: u64, end: u64) -> Result<Self> {
        let interval = Interval::new(chrom, start, end).map_err(|e| invalid(e.to_string()))?;
        if interval.is_empty() {
            return Err(invalid("peak span must be nonempty"));
        }
        Ok(Self { chrom, start, end })
    }
}

#[derive(Clone, Debug, Serialize)]
pub(crate) struct Chromosome {
    pub name: String,
    pub len: Option<u64>,
}

#[derive(Clone, Debug, Default)]
pub(crate) struct ChromDictionary {
    pub chromosomes: Vec<Chromosome>,
    by_name: HashMap<String, ChromId>,
}

impl ChromDictionary {
    pub fn intern(&mut self, name: &str, len: Option<u64>) -> Result<ChromId> {
        if name.is_empty() || name.contains(['\t', '\n', '\r', '\0']) || len == Some(0) {
            return Err(invalid("invalid chromosome name or zero chromosome length"));
        }
        if let Some(&id) = self.by_name.get(name) {
            let row = &mut self.chromosomes[id.0];
            if row.len.is_some() && len.is_some() && row.len != len {
                return Err(invalid(format!(
                    "chromosome {name} has conflicting lengths {:?} and {len:?}",
                    row.len
                )));
            }
            row.len = row.len.or(len);
            return Ok(id);
        }
        let id = ChromId(self.chromosomes.len());
        self.chromosomes.push(Chromosome {
            name: name.into(),
            len,
        });
        self.by_name.insert(name.into(), id);
        Ok(id)
    }
    pub fn find(&self, name: &str) -> Option<ChromId> {
        self.by_name.get(name).copied()
    }
}

#[derive(Clone, Debug)]
pub(crate) struct PeakRow {
    pub id: RowId,
    pub span: Span,
    pub strand: Strand,
    pub original_fields: Vec<String>,
}

#[derive(Clone, Debug, Default)]
pub(crate) struct PeakRows {
    pub dictionary: ChromDictionary,
    pub rows: Vec<PeakRow>,
    pub field_count: usize,
}

#[derive(Clone, Debug, Serialize)]
pub(crate) struct Sample {
    pub name: String,
    pub path: PathBuf,
}
