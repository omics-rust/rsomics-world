use crate::model::invalid;
use rsomics_common::Result;
use std::{
    num::NonZeroUsize,
    path::PathBuf,
    sync::atomic::{AtomicUsize, Ordering},
};

#[derive(Clone, Debug)]
pub(crate) struct Execution {
    pub threads: NonZeroUsize,
    pub scratch: PathBuf,
    pub memory_budget: usize,
}

impl Execution {
    pub fn new(threads: NonZeroUsize) -> Self {
        Self {
            threads,
            scratch: std::env::temp_dir(),
            memory_budget: 512 * 1024 * 1024,
        }
    }
    pub fn workers_for(&self, tasks: usize) -> usize {
        tasks.min(self.threads.get())
    }
    pub fn ordered_map<T: Send, F: Fn(usize) -> Result<T> + Sync>(
        &self,
        tasks: usize,
        work: F,
    ) -> Result<Vec<T>> {
        if tasks == 0 {
            return Ok(Vec::new());
        }
        let workers = self.workers_for(tasks);
        let next = AtomicUsize::new(workers);
        let mut rows = std::thread::scope(|scope| {
            let handles = (0..workers)
                .map(|initial| {
                    let work = &work;
                    let next = &next;
                    scope.spawn(move || {
                        let mut rows = Vec::new();
                        let mut index = initial;
                        loop {
                            if index >= tasks {
                                break;
                            }
                            rows.push((index, work(index)));
                            index = next.fetch_add(1, Ordering::Relaxed);
                        }
                        rows
                    })
                })
                .collect::<Vec<_>>();
            let mut results = Vec::new();
            for handle in handles {
                results.extend(
                    handle
                        .join()
                        .map_err(|_| invalid("bounded worker panicked"))?,
                );
            }
            Ok::<_, rsomics_common::RsomicsError>(results)
        })?;
        rows.sort_unstable_by_key(|row| row.0);
        rows.into_iter().map(|(_, row)| row).collect()
    }
}
