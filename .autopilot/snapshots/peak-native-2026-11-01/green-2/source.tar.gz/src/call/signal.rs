use super::{
    AlignmentFormat, CallConfig, ScaleTo,
    alignments::{Tags, Track},
    statistics::{Scores, score_key},
};
use crate::model::invalid;
use rsomics_common::Result;
use std::{
    collections::HashMap,
    fs::File,
    io::{BufReader, BufWriter, Read, Write},
    path::PathBuf,
};

pub(super) type Pileup = Vec<(u64, f32)>;
pub(super) struct Parameters {
    paired: bool,
    d: u32,
    treat_scale: f32,
    background: f32,
    windows: Vec<(u32, f32)>,
}
impl Parameters {
    pub fn new(c: &CallConfig, d: u32, treatment: &Track, control: Option<&Track>) -> Result<Self> {
        let paired = c.format == AlignmentFormat::Bampe;
        let policy_d = if paired {
            f64::from(
                treatment
                    .last_parser_mean
                    .ok_or_else(|| invalid("missing final paired parser mean"))?,
            )
        } else {
            f64::from(d)
        };
        let treat_sum = if paired {
            treatment.fragment_bases as f64
        } else {
            treatment.retained as f64 * f64::from(d)
        };
        let (mut scale, mut background) = (1.0, (treat_sum / c.genome_size) as f32);
        let mut windows = Vec::new();
        if let Some(control) = control {
            if (c.small_local != 0 && f64::from(c.small_local) < policy_d)
                || (c.large_local != 0
                    && (f64::from(c.large_local) < policy_d || c.large_local < c.small_local))
            {
                return Err(invalid(
                    "control local windows must be ordered and no smaller than d",
                ));
            }
            let count = control
                .retained
                .checked_mul(if paired { 2 } else { 1 })
                .ok_or_else(|| invalid("control count overflow"))?;
            let control_sum = if paired {
                (count as f64
                    * f64::from(
                        treatment
                            .pooled_mean
                            .ok_or_else(|| invalid("missing paired treatment mean"))?,
                    )) as u64 as f64
            } else {
                count as f64 * f64::from(d)
            };
            if control_sum <= 0.0 {
                return Err(invalid("control has zero total fragment mass"));
            }
            let ratio = treat_sum / control_sum;
            let to_control = match c.scale_to {
                ScaleTo::Small => treatment.retained > count,
                ScaleTo::Large => treatment.retained < count,
            };
            if to_control {
                scale = (1.0 / ratio) as f32;
                background = (control_sum / c.genome_size) as f32;
            }
            let control_scale = if to_control { 1.0 } else { ratio };
            if !c.disable_local {
                windows.push((d, control_scale as f32));
                if c.small_local > 0 {
                    windows.push((
                        c.small_local,
                        (policy_d / f64::from(c.small_local) * control_scale) as f32,
                    ));
                }
                if c.large_local > c.small_local {
                    windows.push((
                        c.large_local,
                        (policy_d / f64::from(c.large_local) * control_scale) as f32,
                    ));
                }
            }
        } else if !c.disable_local {
            if c.large_local == 0 {
                return Err(invalid(
                    "no-control local background requires a positive large window",
                ));
            }
            let factor = if paired {
                treatment.fragment_bases as f64
                    / (f64::from(c.large_local) * treatment.retained as f64 * 2.0)
            } else {
                f64::from(d) / f64::from(c.large_local)
            };
            windows.push((c.large_local, factor as f32));
        }
        if !scale.is_finite()
            || scale <= 0.0
            || !background.is_finite()
            || background <= 0.0
            || windows.iter().any(|w| !w.1.is_finite() || w.1 <= 0.0)
        {
            return Err(invalid("caller scaling produced invalid float32 factors"));
        }
        Ok(Self {
            paired,
            d,
            treat_scale: scale,
            background,
            windows,
        })
    }
}
pub(super) fn sweep(mut starts: Vec<u64>, mut ends: Vec<u64>, scale: f32, floor: f32) -> Pileup {
    starts.sort_unstable();
    ends.sort_unstable();
    let n = starts.len();
    let mut output = Vec::with_capacity(n * 2);
    if n == 0 {
        return output;
    }
    let (mut s, mut e, mut count) = (0, 0, 0i64);
    let mut previous = starts[0].min(ends[0]);
    if previous != 0 {
        output.push((previous, floor));
    }
    while s < n && e < n {
        if starts[s] < ends[e] {
            let pos = starts[s];
            if pos != previous {
                output.push((pos, (count as f32 * scale).max(floor)));
            }
            count += 1;
            previous = pos;
            s += 1;
        } else if ends[e] < starts[s] {
            let pos = ends[e];
            if pos != previous {
                output.push((pos, (count as f32 * scale).max(floor)));
            }
            count -= 1;
            previous = pos;
            e += 1;
        } else {
            s += 1;
            e += 1;
        }
    }
    while e < n {
        let pos = ends[e];
        if pos != previous {
            output.push((pos, (count as f32 * scale).max(floor)));
        }
        count -= 1;
        previous = pos;
        e += 1;
    }
    output
}
struct Projection {
    paired: bool,
    width: u32,
    directional: bool,
    shift: i32,
}

fn projected(tags: &Tags, geometry: Projection, length: u64, scale: f32, floor: f32) -> Pileup {
    let Projection {
        paired,
        width,
        directional,
        shift,
    } = geometry;
    let five = if directional {
        -i64::from(shift)
    } else {
        i64::from(width / 2)
    };
    let three = if directional {
        i64::from(shift) + i64::from(width)
    } else if paired {
        i64::from(width / 2)
    } else {
        i64::from(width - width / 2)
    };
    let clip = |p: i128| p.clamp(0, i128::from(length)) as u64;
    let mut starts = Vec::with_capacity(tags.len() * if paired { 2 } else { 1 });
    let mut ends = Vec::with_capacity(starts.capacity());
    let mut plus = |p: u64| {
        starts.push(clip(i128::from(p) - i128::from(five)));
        ends.push(clip(i128::from(p) + i128::from(three)));
    };
    if paired {
        for &(p, _) in &tags.fragments {
            plus(p);
        }
    } else {
        for &p in &tags.plus {
            plus(p);
        }
    }
    let mut minus = |p: u64| {
        starts.push(clip(i128::from(p) - i128::from(three)));
        ends.push(clip(i128::from(p) + i128::from(five)));
    };
    if paired {
        for &(_, p) in &tags.fragments {
            minus(p);
        }
    } else {
        for &p in &tags.minus {
            minus(p);
        }
    }
    sweep(starts, ends, scale, floor)
}
fn maximum(left: &[(u64, f32)], right: &[(u64, f32)]) -> Pileup {
    let (mut i, mut j) = (0, 0);
    let mut output = Vec::with_capacity(left.len() + right.len());
    while i < left.len() && j < right.len() {
        let a = left[i];
        let b = right[j];
        output.push((a.0.min(b.0), a.1.max(b.1)));
        if a.0 <= b.0 {
            i += 1;
        }
        if b.0 <= a.0 {
            j += 1;
        }
    }
    output
}
pub(super) struct Spool {
    pub path: PathBuf,
    pub histogram: HashMap<u32, u64>,
}
#[derive(Clone, Copy)]
pub(super) struct Segment {
    pub end: u64,
    pub treatment: f32,
    pub control: f32,
    pub p: f32,
}
impl Segment {
    fn write(self, w: &mut impl Write) -> Result<()> {
        w.write_all(&self.end.to_le_bytes())?;
        w.write_all(&self.treatment.to_le_bytes())?;
        w.write_all(&self.control.to_le_bytes())?;
        w.write_all(&self.p.to_le_bytes())?;
        Ok(())
    }
}
pub(super) struct Segments {
    reader: BufReader<File>,
}
impl Segments {
    pub fn open(spool: &Spool) -> Result<Self> {
        Ok(Self {
            reader: BufReader::new(File::open(&spool.path)?),
        })
    }
    pub fn next(&mut self) -> Result<Option<Segment>> {
        let mut bytes = [0u8; 20];
        let n = self.reader.read(&mut bytes[..1])?;
        if n == 0 {
            return Ok(None);
        }
        self.reader.read_exact(&mut bytes[1..])?;
        let u64_at =
            |i| u64::from_le_bytes(bytes[i..i + 8].try_into().expect("fixed segment field"));
        let f32_at =
            |i| f32::from_le_bytes(bytes[i..i + 4].try_into().expect("fixed segment field"));
        Ok(Some(Segment {
            end: u64_at(0),
            treatment: f32_at(8),
            control: f32_at(12),
            p: f32_at(16),
        }))
    }
}
pub(super) fn prepare(
    tags: &Tags,
    control: Option<&Tags>,
    length: u64,
    p: &Parameters,
    c: &CallConfig,
    budget: usize,
    path: PathBuf,
) -> Result<Spool> {
    let n = tags
        .len()
        .checked_add(control.map_or(0, Tags::len))
        .ok_or_else(|| invalid("caller event count overflow"))?;
    if n > budget / 256 {
        return Err(invalid(format!(
            "caller chromosome working set exceeds its {budget}-byte worker budget"
        )));
    }
    let treatment = if p.paired {
        sweep(
            tags.fragments.iter().map(|r| r.0).collect(),
            tags.fragments.iter().map(|r| r.1).collect(),
            p.treat_scale,
            0.0,
        )
    } else {
        projected(
            tags,
            Projection {
                paired: false,
                width: p.d,
                directional: true,
                shift: c.shift,
            },
            length,
            p.treat_scale,
            0.0,
        )
    };
    let source = control.unwrap_or(tags);
    let mut background: Option<Pileup> = None;
    for &(width, scale) in &p.windows {
        let current = projected(
            source,
            Projection {
                paired: p.paired,
                width,
                directional: false,
                shift: 0,
            },
            length,
            scale,
            p.background,
        );
        background = Some(match background {
            None => current,
            Some(previous) => maximum(&previous, &current),
        });
    }
    let background = background.unwrap_or_else(|| vec![(length, p.background)]);
    let mut writer = BufWriter::new(File::create(&path)?);
    let mut histogram = HashMap::new();
    let mut scores = Scores::new(budget / 8);
    let (mut i, mut j, mut previous) = (0, 0, 0u64);
    while i < treatment.len() && j < background.len() {
        let t = treatment[i];
        let b = background[j];
        let end = t.0.min(b.0);
        let score = scores.get(t.1, b.1)?;
        if end < previous {
            return Err(invalid("caller pileup endpoints are not monotone"));
        }
        *histogram.entry(score_key(score)).or_default() += end - previous;
        if histogram.len() > budget / 128 {
            return Err(invalid(
                "caller score histogram exceeds bounded worker memory",
            ));
        }
        Segment {
            end,
            treatment: t.1,
            control: b.1,
            p: score,
        }
        .write(&mut writer)?;
        previous = end;
        if t.0 <= b.0 {
            i += 1;
        }
        if b.0 <= t.0 {
            j += 1;
        }
    }
    writer.flush()?;
    Ok(Spool { path, histogram })
}
