use super::{AlignmentFormat, CallConfig, DuplicatePolicy, InputReport, TrackReport, statistics};
use crate::{
    io::open_bam,
    model::{ChromDictionary, invalid},
};
use rsomics_bamio::raw::{RawRecord, read_record};
use rsomics_common::{Context, Result};
use std::{collections::BTreeMap, num::NonZeroUsize, path::PathBuf};

#[derive(Default)]
pub(super) struct Tags {
    pub plus: Vec<u64>,
    pub minus: Vec<u64>,
    pub fragments: Vec<(u64, u64)>,
}
impl Tags {
    pub fn len(&self) -> usize {
        self.plus.len() + self.minus.len() + self.fragments.len()
    }
}
pub(super) struct Track {
    pub chromosomes: BTreeMap<usize, Tags>,
    pub admitted: u64,
    pub retained: u64,
    pub fragment_bases: u64,
    pub pooled_mean: Option<f32>,
    pub raw_tag_size: u32,
    pub last_parser_mean: Option<f32>,
    cap: Option<u32>,
    inputs: Vec<InputReport>,
}
impl Track {
    pub fn filter(&mut self, policy: DuplicatePolicy, genome_size: f64) -> Result<()> {
        self.cap = match policy {
            DuplicatePolicy::All => None,
            DuplicatePolicy::Limit(n) => Some(n),
            DuplicatePolicy::Auto => Some(statistics::duplicate_cap(self.admitted, genome_size)?),
        };
        self.retained = 0;
        self.fragment_bases = 0;
        for tags in self.chromosomes.values_mut() {
            tags.plus.sort_unstable();
            tags.minus.sort_unstable();
            tags.fragments.sort_unstable();
            if let Some(cap) = self.cap {
                retain_runs(&mut tags.plus, cap.max(1));
                retain_runs(&mut tags.minus, cap.max(1));
                retain_runs(&mut tags.fragments, cap.max(1));
            }
            self.retained += tags.len() as u64;
            for &(left, right) in &tags.fragments {
                self.fragment_bases = self
                    .fragment_bases
                    .checked_add(right - left)
                    .ok_or_else(|| invalid("fragment length overflow"))?;
            }
        }
        if self.retained == 0 {
            return Err(invalid(
                "no alignments remain after caller admission and duplicate filtering",
            ));
        }
        if self.pooled_mean.is_some() {
            self.pooled_mean = Some(if self.cap.is_some() {
                (self.fragment_bases as f64 / self.retained as f64) as f32
            } else {
                self.fragment_bases as f32 / self.retained as f32
            });
        }
        Ok(())
    }
    pub fn report(&self) -> TrackReport {
        TrackReport {
            admitted: self.admitted,
            retained: self.retained,
            duplicate_cap: self.cap,
            fragment_bases: self.fragment_bases,
            pooled_fragment_mean: self.pooled_mean,
            inputs: self
                .inputs
                .iter()
                .map(|r| InputReport {
                    path: r.path.clone(),
                    raw_records: r.raw_records,
                    admitted: r.admitted,
                    parser_mean: r.parser_mean,
                })
                .collect(),
        }
    }
}
fn retain_runs<T: PartialEq + Copy>(values: &mut Vec<T>, cap: u32) {
    let mut previous = None;
    let mut count = 0;
    values.retain(|value| {
        if previous != Some(*value) {
            previous = Some(*value);
            count = 0;
        }
        count += 1;
        count <= cap
    });
}
pub(super) fn load(
    paths: &[PathBuf],
    config: &CallConfig,
    dictionary: &mut ChromDictionary,
    budget: usize,
) -> Result<Track> {
    let paired = config.format == AlignmentFormat::Bampe;
    let mut track = Track {
        chromosomes: BTreeMap::new(),
        admitted: 0,
        retained: 0,
        fragment_bases: 0,
        pooled_mean: paired.then_some(0.0),
        raw_tag_size: 0,
        last_parser_mean: None,
        cap: None,
        inputs: Vec::new(),
    };
    let mut allocation = 0usize;
    for (input_index, path) in paths.iter().enumerate() {
        let (mut reader, local) = open_bam(path, NonZeroUsize::MIN)?;
        let ids = local
            .chromosomes
            .iter()
            .map(|chr| dictionary.intern(&chr.name, chr.len))
            .collect::<Result<Vec<_>>>()?;
        let mut record = RawRecord::default();
        let mut cigar = Vec::new();
        let mut raw = 0u64;
        let mut admitted = 0u64;
        let mut length = 0u64;
        let mut probe_sum = 0u64;
        let mut probe_n = 0u64;
        while read_record(reader.get_mut(), &mut record).rs_with_context(|| {
            format!("reading caller BAM {} record{}", path.display(), raw + 1)
        })? != 0
        {
            raw += 1;
            if input_index == 0 && probe_n < 10 {
                probe_sum += record.sequence_len() as u64;
                probe_n += 1;
            }
            let flags = record.flags();
            if flags & 2820 != 0
                || record.reference_sequence_id() < 0
                || (flags & 1 != 0 && (flags & 136 != 0 || flags & 2 == 0))
            {
                continue;
            }
            let local_id = record.reference_sequence_id() as usize;
            let id = ids
                .get(local_id)
                .ok_or_else(|| {
                    invalid(format!(
                        "{}: reference id outside BAM header",
                        path.display()
                    ))
                })?
                .0;
            let limit = local.chromosomes[local_id]
                .len
                .ok_or_else(|| invalid("missing reference length"))?;
            let start = u64::try_from(record.alignment_start())
                .map_err(|_| invalid("negative mapped BAM coordinate"))?;
            if start >= limit {
                return Err(invalid(format!(
                    "{}: mapped coordinate outside reference",
                    path.display()
                )));
            }
            let tags = track.chromosomes.entry(id).or_default();
            if paired {
                if flags & 1 == 0
                    || record.mate_reference_sequence_id() != record.reference_sequence_id()
                    || record.template_length() == 0
                {
                    return Err(invalid(
                        "BAMPE requires nonzero, same-reference proper-pair geometry",
                    ));
                }
                let mate = u64::try_from(record.mate_alignment_start())
                    .map_err(|_| invalid("negative BAMPE mate coordinate"))?;
                let left = start.min(mate);
                let width = u64::from(record.template_length().unsigned_abs());
                let right = left
                    .checked_add(width)
                    .ok_or_else(|| invalid("BAMPE fragment coordinate overflow"))?;
                if right > limit || mate >= right {
                    return Err(invalid(
                        "BAMPE fragment lies outside reference or excludes its mate",
                    ));
                }
                tags.fragments.push((left, right));
                length = length
                    .checked_add(width)
                    .ok_or_else(|| invalid("BAMPE parser length overflow"))?;
                allocation += 32;
            } else {
                record.decode_cigar_into(&mut cigar)?;
                let span = cigar
                    .iter()
                    .filter(|(op, _)| matches!(*op, 0 | 2 | 3 | 7 | 8))
                    .try_fold(0u64, |sum, (_, n)| {
                        sum.checked_add(u64::from(*n))
                            .ok_or_else(|| invalid("CIGAR reference span overflow"))
                    })?;
                let end = start
                    .checked_add(span)
                    .ok_or_else(|| invalid("alignment end overflow"))?;
                if span == 0 || end > limit {
                    return Err(invalid("mapped CIGAR span is empty or outside reference"));
                }
                if flags & 16 != 0 {
                    tags.minus.push(end);
                } else {
                    tags.plus.push(start);
                }
                allocation += 16;
            }
            if allocation > budget {
                return Err(invalid(format!(
                    "caller admitted tag state exceeds bounded input memory ({budget} bytes)"
                )));
            }
            admitted += 1;
        }
        if input_index == 0 {
            track.raw_tag_size = if probe_n == 0 {
                0
            } else {
                (probe_sum / probe_n) as u32
            };
        }
        let mean = if paired {
            if admitted == 0 {
                return Err(invalid(format!(
                    "{}: no admitted paired fragments",
                    path.display()
                )));
            }
            Some((length as f64 / admitted as f64) as f32)
        } else {
            None
        };
        track.last_parser_mean = mean;
        track.admitted = track
            .admitted
            .checked_add(admitted)
            .ok_or_else(|| invalid("admitted count overflow"))?;
        track.fragment_bases = track
            .fragment_bases
            .checked_add(length)
            .ok_or_else(|| invalid("pooled length overflow"))?;
        track.inputs.push(InputReport {
            path: path.clone(),
            raw_records: raw,
            admitted,
            parser_mean: mean,
        });
    }
    if paired && track.admitted > 0 {
        track.pooled_mean = Some(track.fragment_bases as f32 / track.admitted as f32);
    }
    Ok(track)
}
