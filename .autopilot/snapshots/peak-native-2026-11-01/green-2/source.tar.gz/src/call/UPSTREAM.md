# Caller implementation provenance

The private caller uses team-owned `rsomics-macs` tag sorting, pileup, model and
peak-writing implementation assets as refactoring material. Those retired
repositories are not revived or linked as product dependencies.

Behavior authority is MACS 3.1.0, release commit
`81761ed60a985cd817aca862f8b0402fafaeb11f`, retained source archive SHA-256
`aae548b86ab652717dca281fa2e33645fc1dc8091264ccbf7ce09cf8a13532e0`.
The current reader, model projection/correlation, pileup/scaling, probability,
global q-adjustment and output bodies were inspected directly. Current-source
algorithm adaptations retain the BSD notice below. No GPL upstream code or R
implementation is copied into this module.

The immutable original compatibility answers are the five MACS views in source
run 41209740891. Native answers must be computed from every admitted pooled input;
original outputs are comparisons, never a lookup table or substituted output.
This module does not implement broad peaks, subpeak calling, FRAG/barcodes,
downsampling, generic alignment input breadth, plotting, or upstream subprocesses.
Successful source comparison does not itself establish performance superiority,
biological validity, native-four admission or release readiness.

## MACS source notice

BSD 3-Clause License

Copyright (c) 2025, macs3 project team All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
