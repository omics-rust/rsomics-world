use super::{ModelReport, alignments::Track};
use crate::model::invalid;
use rsomics_common::Result;

fn pileup(tags: &[u64], extension: i64) -> Vec<(u64, f32)> {
    let starts = tags
        .iter()
        .map(|&p| (p as i64 - extension).max(0) as u64)
        .collect::<Vec<_>>();
    let ends = tags
        .iter()
        .map(|&p| p + extension as u64)
        .collect::<Vec<_>>();
    super::signal::sweep(starts, ends, 1.0, 0.0)
}
fn close(content: &[(u64, u64, f32)], maximum: f32, peaks: &mut Vec<(i64, f32)>) {
    if content.is_empty() || content.last().expect("nonempty").1 - content[0].0 < 200 {
        return;
    }
    let highest = content.iter().map(|r| r.2).fold(0.0, f32::max);
    if highest >= maximum {
        return;
    }
    let summits = content
        .iter()
        .filter(|r| r.2 == highest)
        .map(|r| ((r.0 + r.1) / 2) as i64)
        .collect::<Vec<_>>();
    peaks.push((summits[(summits.len() - 1) / 2], highest));
}
fn naive(tags: &[u64], size: i64, minimum: f32, maximum: f32) -> Vec<(i64, f32)> {
    if tags.len() < 2 {
        return Vec::new();
    }
    let mut content = Vec::new();
    let mut result = Vec::new();
    let mut start = 0;
    for (end, value) in pileup(tags, size / 2) {
        if value > minimum {
            if content
                .last()
                .is_some_and(|r: &(u64, u64, f32)| start - r.1 > 50)
            {
                close(&content, maximum, &mut result);
                content.clear();
            }
            content.push((start, end, value));
        }
        start = end;
    }
    close(&content, maximum, &mut result);
    result
}
fn centers(plus: &[(i64, f32)], minus: &[(i64, f32)], size: i64) -> Vec<i64> {
    let mut result = Vec::new();
    let (mut ip, mut im, mut previous) = (0, 0, 0);
    let mut overlap = false;
    while ip < plus.len() && im < minus.len() {
        let (pp, pn) = plus[ip];
        let (mp, mn) = minus[im];
        if pp - size > mp {
            im += 1;
        } else if pp + size < mp {
            ip += 1;
            im = previous;
            overlap = false;
        } else {
            if !overlap {
                overlap = true;
                previous = im;
            }
            let ratio = pn / mn;
            if ratio > 0.5 && ratio < 2.0 && pp < mp {
                result.push((pp + mp) / 2);
            }
            im += 1;
        }
    }
    result
}
fn project(centers: &[i64], tags: &[u64], size: i64, start: &mut [i64], end: &mut [i64]) {
    let half = size + 5;
    let last = start.len() as i64 - 1;
    let mut first = 0;
    for &center in centers {
        while first < tags.len() && (tags[first] as i64) < center - half {
            first += 1;
        }
        let mut j = first;
        while j < tags.len() && tags[j] as i64 <= center + half {
            let position = tags[j] as i64;
            start[(position - 5 - center + half).max(0) as usize] += 1;
            end[(position + 5 - center + half).min(last) as usize] -= 1;
            j += 1;
        }
    }
}
fn normalize(start: &[i64], end: &[i64]) -> Vec<f64> {
    let mut current = 0;
    let values = start
        .iter()
        .zip(end)
        .map(|(s, e)| {
            current += s + e;
            current as f64
        })
        .collect::<Vec<_>>();
    let n = values.len() as f64;
    let mean = values.iter().sum::<f64>() / n;
    let std = (values.iter().map(|v| (v - mean) * (v - mean)).sum::<f64>() / n).sqrt();
    values.iter().map(|v| (v - mean) / (std * n)).collect()
}
fn correlation(plus: &[f64], minus: &[f64], size: usize) -> Vec<f64> {
    let n = plus.len() as i64;
    let raw = ((plus.len() - size)..(plus.len() + size))
        .map(|j| {
            let lag = j as i64 - (n - 1);
            (lag.max(0)..(n + lag).min(n))
                .map(|i| minus[i as usize] * plus[(i - lag) as usize])
                .sum::<f64>()
        })
        .collect::<Vec<_>>();
    let mut padded = Vec::with_capacity(raw.len() + 20);
    padded.extend((1..11).rev().map(|i| raw[i]));
    padded.extend_from_slice(&raw);
    padded.extend((0..10).map(|i| raw[raw.len() - 1 - i]));
    let full = padded
        .windows(11)
        .map(|w| w.iter().map(|v| v * (1.0 / 11.0)).sum::<f64>())
        .collect::<Vec<_>>();
    full[5..full.len() - 5].to_vec()
}
pub(super) fn build(
    track: &Track,
    genome: f64,
    bw: u32,
    mfold: [u32; 2],
    d_min: u32,
    fallback: Option<u32>,
    tag_size: u32,
) -> Result<ModelReport> {
    let size = i64::from(bw) * 2;
    let threshold = |fold: u32| {
        (track.retained as f64 * f64::from(fold) * size as f64 / genome / 2.0).round_ties_even()
            as f32
    };
    let mut paired = Vec::new();
    let mut count = 0;
    for tags in track.chromosomes.values() {
        let p = naive(&tags.plus, size, threshold(mfold[0]), threshold(mfold[1]));
        let m = naive(&tags.minus, size, threshold(mfold[0]), threshold(mfold[1]));
        let c = centers(&p, &m, size);
        count += c.len();
        paired.push((tags, c));
    }
    if count < 100 {
        if let Some(d) = fallback {
            let mut result = ModelReport::fixed(d);
            result.fallback_used = true;
            result.paired_peaks = count;
            return Ok(result);
        }
        return Err(invalid(format!(
            "fitted model has {count} paired peaks; requires100 or an explicit fallback extension"
        )));
    }
    let width = (1 + size * 2 + 10) as usize;
    let (mut ps, mut pe, mut ms, mut me) = (
        vec![0; width],
        vec![0; width],
        vec![0; width],
        vec![0; width],
    );
    for (tags, c) in paired {
        project(&c, &tags.plus, size, &mut ps, &mut pe);
        project(&c, &tags.minus, size, &mut ms, &mut me);
    }
    let corr = correlation(&normalize(&ps, &pe), &normalize(&ms, &me), size as usize);
    if corr.iter().any(|v| !v.is_finite()) {
        return Err(invalid(
            "model projection has zero variance or nonfinite correlation",
        ));
    }
    let lag =
        |index: usize| -(size as f64) + index as f64 * (size * 2) as f64 / (corr.len() - 1) as f64;
    let mut maxima = (1..corr.len() - 1)
        .filter(|&i| corr[i - 1] < corr[i] && corr[i] > corr[i + 1] && lag(i) > f64::from(d_min))
        .collect::<Vec<_>>();
    maxima.sort_by(|&a, &b| corr[b].total_cmp(&corr[a]).then(b.cmp(&a)));
    let fitted = lag(*maxima
        .first()
        .ok_or_else(|| invalid("model has no local maximum beyond d-min"))?)
        as u32;
    let mut alternatives = maxima
        .into_iter()
        .map(|i| lag(i) as u32)
        .collect::<Vec<_>>();
    alternatives.sort_unstable();
    let use_fallback = fitted <= tag_size.saturating_mul(2) && fallback.is_some();
    Ok(ModelReport {
        d: if use_fallback {
            fallback.expect("present fallback")
        } else {
            fitted
        },
        fitted_d: Some(fitted),
        fallback_used: use_fallback,
        paired_peaks: count,
        correlation: corr,
        alternative_d: alternatives,
    })
}
