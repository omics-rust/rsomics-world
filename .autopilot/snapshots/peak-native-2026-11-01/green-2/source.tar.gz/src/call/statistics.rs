use crate::model::invalid;
use rsomics_common::Result;
use std::collections::HashMap;

pub(super) fn decimal_round(x: f64, places: i32) -> f64 {
    if !x.is_finite() {
        return x;
    }
    let factor = 10f64.powi(places);
    if x.abs() >= 2f64.powi(52 - factor.log2().floor() as i32) {
        return x;
    }
    if x.abs() >= 1e10 {
        let bits = x.abs().to_bits();
        let mantissa = u128::from((bits & ((1u64 << 52) - 1)) | (1u64 << 52));
        let exponent = ((bits >> 52) & 0x7ff) as i32 - 1023 - 52 + places;
        if exponent >= 0 {
            return x;
        }
        let numerator = mantissa * 5u128.pow(places as u32);
        let shift = (-exponent) as u32;
        let mut integral = numerator >> shift;
        let remainder = numerator & ((1u128 << shift) - 1);
        let half = 1u128 << (shift - 1);
        if remainder > half || (remainder == half && integral & 1 != 0) {
            integral += 1;
        }
        return ((integral as f64) / factor).copysign(x);
    }
    let mut r = (x * factor).round_ties_even();
    let upper = x.mul_add(factor, -(r + 0.5));
    if upper > 0.0 || (upper == 0.0 && r % 2.0 != 0.0) {
        r += 1.0;
    }
    let lower = x.mul_add(factor, -(r - 0.5));
    if lower < 0.0 || (lower == 0.0 && r % 2.0 != 0.0) {
        r -= 1.0;
    }
    r / factor
}
pub(super) struct Scores {
    cache: HashMap<(u32, u32), f32>,
    logarithms: Vec<f64>,
    budget: usize,
}
impl Scores {
    pub fn new(budget: usize) -> Self {
        Self {
            cache: HashMap::new(),
            logarithms: vec![0.0],
            budget,
        }
    }
    pub fn get(&mut self, treatment: f32, control: f32) -> Result<f32> {
        if !treatment.is_finite()
            || treatment < 0.0
            || treatment >= i32::MAX as f32
            || !control.is_finite()
            || control <= 0.0
        {
            return Err(invalid(
                "nonfinite/out-of-range caller pileup or nonpositive lambda",
            ));
        }
        let k = treatment as u32;
        let key = (k, control.to_bits());
        if let Some(v) = self.cache.get(&key) {
            return Ok(*v);
        }
        let m0 = k as usize + 1;
        if m0 > self.budget / 16 {
            return Err(invalid(
                "Poisson observation exceeds bounded score workspace",
            ));
        }
        while self.logarithms.len() <= m0 {
            let i = self.logarithms.len();
            self.logarithms
                .push(self.logarithms[i - 1] + (i as f64).ln());
        }
        let lambda = f64::from(control);
        let logarithm = lambda.ln();
        let mut logx = m0 as f64 * logarithm - self.logarithms[m0];
        let mut residue = logx;
        let mut m = m0 as u64;
        loop {
            m += 1;
            let logy = logx + logarithm - (m as f64).ln();
            let before = residue;
            residue = if before > logy {
                before + (logy - before).exp().ln_1p()
            } else {
                logy + (before - logy).exp().ln_1p()
            };
            if (before - residue).abs() < 1e-5 {
                break;
            }
            logx = logy;
        }
        let value = (-decimal_round((residue - lambda) / std::f64::consts::LN_10, 5)) as f32;
        if self.cache.len() >= self.budget / 64 {
            self.cache.clear();
        }
        self.cache.insert(key, value);
        Ok(value)
    }
}
pub(super) fn score_key(value: f32) -> u32 {
    if value == 0.0 { 0 } else { value.to_bits() }
}
pub(super) fn qtable(histogram: &HashMap<u32, u64>) -> Result<HashMap<u32, f32>> {
    let n = histogram.values().try_fold(0u64, |sum, n| {
        sum.checked_add(*n)
            .ok_or_else(|| invalid("q-value population length overflow"))
    })?;
    if n == 0 {
        return Err(invalid("no nonempty caller score population"));
    }
    let mut scores = histogram.keys().copied().collect::<Vec<_>>();
    scores.sort_by(|a, b| f32::from_bits(*b).total_cmp(&f32::from_bits(*a)));
    let f = (-(n as f64).log10()) as f32;
    let mut previous = i32::MAX as f32;
    let mut k = 1u64;
    let mut result = HashMap::new();
    let mut last = 0;
    for (i, &key) in scores.iter().enumerate() {
        last = i;
        let value = f32::from_bits(key);
        let q = ((f64::from(value) + ((k as f64).log10() + f64::from(f))) as f32).min(previous);
        if q <= 0.0 {
            break;
        }
        result.insert(key, q);
        previous = q;
        k = k
            .checked_add(histogram[&key])
            .ok_or_else(|| invalid("q rank overflow"))?;
    }
    for &key in &scores[last..] {
        result.insert(key, 0.0);
    }
    Ok(result)
}
fn binomial_pdf(x: u64, a: u64, b: f64) -> f64 {
    if x > a {
        return 0.0;
    }
    if b == 0.0 {
        return if x == 0 { 1.0 } else { 0.0 };
    }
    if b == 1.0 {
        return if x == a { 1.0 } else { 0.0 };
    }
    let (p, mn, mx) = if x > a - x {
        (1.0 - b, a - x, x)
    } else {
        (b, x, a - x)
    };
    let mut pdf = 1.0;
    let mut t = 0;
    for q in 1..=mn {
        pdf *= (a - q + 1) as f64 * p / (mn - q + 1) as f64;
        if pdf < 1e-100 {
            while pdf < 1e-3 && t > -(a as i64) {
                pdf /= 1.0 - p;
                t -= 1;
            }
        }
        if pdf > 1e100 {
            while pdf > 1e3 && t < mx as i64 {
                pdf *= 1.0 - p;
                t += 1;
            }
        }
    }
    for _ in 0..(mx as i64 - t) {
        pdf *= 1.0 - p;
    }
    pdf
}
pub(super) fn duplicate_cap(n: u64, genome: f64) -> Result<u32> {
    if genome < 1.0 || n > i64::MAX as u64 {
        return Err(invalid(
            "automatic duplicate cap requires genome size>=1 and a bounded count",
        ));
    }
    let mut sum = 0.0;
    for x in 0..=n {
        sum += binomial_pdf(x, n, 1.0 / genome);
        if 1.0 - 1e-5 < sum {
            return u32::try_from(x).map_err(|_| invalid("automatic duplicate cap exceeds u32"));
        }
    }
    Err(invalid(
        "binomial inverse failed to reach its cumulative probability",
    ))
}
