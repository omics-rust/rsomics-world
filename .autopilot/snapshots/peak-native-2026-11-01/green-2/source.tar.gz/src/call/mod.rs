mod alignments;
mod fit;
mod output;
mod signal;
mod statistics;

use crate::{execution::Execution, io::OutputGroup, model::invalid};
use rsomics_common::Result;
use serde::Serialize;
use std::{collections::HashMap, io::Write, path::PathBuf};

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
pub(crate) enum AlignmentFormat {
    Bam,
    Bampe,
}
#[derive(Clone, Copy, Debug, Serialize)]
pub(crate) enum DuplicatePolicy {
    Limit(u32),
    Auto,
    All,
}
#[derive(Clone, Debug, Serialize)]
pub(crate) enum ModelConfig {
    Fitted {
        bandwidth: u32,
        mfold: [u32; 2],
        d_min: u32,
        fallback_extension: Option<u32>,
    },
    Fixed {
        extension: u32,
    },
    PairedEnd,
}
#[derive(Clone, Copy, Debug, Serialize)]
pub(crate) enum ScaleTo {
    Small,
    Large,
}
#[derive(Clone, Copy, Debug, Serialize)]
pub(crate) enum ScoreCutoff {
    P(f64),
    Q(f64),
}
#[derive(Clone, Debug, Serialize)]
pub(crate) struct CallConfig {
    pub treatment: Vec<PathBuf>,
    pub control: Vec<PathBuf>,
    pub format: AlignmentFormat,
    pub genome_size: f64,
    pub duplicates: DuplicatePolicy,
    pub model: ModelConfig,
    pub shift: i32,
    pub score: ScoreCutoff,
    pub small_local: u32,
    pub large_local: u32,
    pub disable_local: bool,
    pub scale_to: ScaleTo,
    pub tag_size: Option<u32>,
    pub max_gap: Option<u32>,
    pub min_length: Option<u32>,
    pub name: String,
    pub output_directory: PathBuf,
    pub write_tracks: bool,
}
#[derive(Debug, Serialize)]
pub(crate) struct ModelReport {
    pub d: u32,
    pub fitted_d: Option<u32>,
    pub fallback_used: bool,
    pub paired_peaks: usize,
    pub correlation: Vec<f64>,
    pub alternative_d: Vec<u32>,
}
impl ModelReport {
    fn fixed(d: u32) -> Self {
        Self {
            d,
            fitted_d: None,
            fallback_used: false,
            paired_peaks: 0,
            correlation: Vec::new(),
            alternative_d: Vec::new(),
        }
    }
}
#[derive(Debug, Serialize)]
pub(crate) struct InputReport {
    pub path: PathBuf,
    pub raw_records: u64,
    pub admitted: u64,
    pub parser_mean: Option<f32>,
}
#[derive(Debug, Serialize)]
pub(crate) struct TrackReport {
    pub admitted: u64,
    pub retained: u64,
    pub duplicate_cap: Option<u32>,
    pub fragment_bases: u64,
    pub pooled_fragment_mean: Option<f32>,
    pub inputs: Vec<InputReport>,
}
#[derive(Debug, Serialize)]
pub(crate) struct CallReport {
    pub peak_count: usize,
    pub workers_requested: usize,
    pub workers_used: usize,
    pub model: ModelReport,
    pub treatment: TrackReport,
    pub control: Option<TrackReport>,
    pub raw_tag_size: u32,
    pub effective_tag_size: u32,
    pub final_treatment_parser_mean: Option<f32>,
    pub max_gap: u32,
    pub min_length: u32,
    pub config: CallConfig,
    pub narrow_peak_path: PathBuf,
    pub summits_path: PathBuf,
    pub xls_path: PathBuf,
    pub treatment_track_path: Option<PathBuf>,
    pub control_track_path: Option<PathBuf>,
    pub report_path: PathBuf,
}

fn validate(c: &CallConfig, e: &Execution) -> Result<()> {
    let p = match c.score {
        ScoreCutoff::P(p) | ScoreCutoff::Q(p) => p,
    };
    if c.treatment.is_empty()
        || !c.genome_size.is_finite()
        || c.genome_size <= 0.0
        || !p.is_finite()
        || p <= 0.0
        || p > 1.0
    {
        return Err(invalid(
            "call requires treatment, positive finite genome size, and a probability in (0,1]",
        ));
    }
    if c.name.is_empty()
        || c.name.contains(['/', '\\', '\t', '\n', '\r', '\0'])
        || c.name == "."
        || c.name == ".."
    {
        return Err(invalid("call name must be a nonempty file-name component"));
    }
    if !c.output_directory.is_dir() || !e.scratch.is_dir() || e.memory_budget < 1024 * 1024 {
        return Err(invalid(
            "call requires existing output/scratch directories and at least1MiB memory",
        ));
    }
    if matches!(c.duplicates, DuplicatePolicy::Limit(0))
        || c.tag_size == Some(0)
        || c.min_length == Some(0)
    {
        return Err(invalid(
            "duplicate limit, tag size and minimum length must be positive",
        ));
    }
    match (&c.model, c.format) {
        (ModelConfig::PairedEnd, AlignmentFormat::Bampe)
            if c.shift == 0 && c.tag_size.is_none() => {}
        (ModelConfig::Fixed { extension }, AlignmentFormat::Bam) if *extension > 0 => (),
        (
            ModelConfig::Fitted {
                bandwidth,
                mfold,
                fallback_extension,
                ..
            },
            AlignmentFormat::Bam,
        ) if *bandwidth >= 3
            && *bandwidth <= 100_000
            && mfold[0] > 0
            && mfold[0] < mfold[1]
            && *fallback_extension != Some(0) => {}
        _ => {
            return Err(invalid(
                "incompatible call format/model/shift/tag-size options",
            ));
        }
    }
    Ok(())
}

pub(crate) fn run(c: &CallConfig, e: &Execution) -> Result<CallReport> {
    validate(c, e)?;
    let path = |suffix: &str| c.output_directory.join(format!("{}{suffix}", c.name));
    let mut destinations = vec![
        path("_peaks.narrowPeak"),
        path("_summits.bed"),
        path("_peaks.xls"),
        path("_call.json"),
    ];
    if c.write_tracks {
        destinations.extend([path("_treat_pileup.bdg"), path("_control_lambda.bdg")]);
    }
    let inputs = c
        .treatment
        .iter()
        .chain(&c.control)
        .cloned()
        .collect::<Vec<_>>();
    let mut group = OutputGroup::new(&inputs, &destinations)?;
    let mut dictionary = crate::model::ChromDictionary::default();
    let mut treatment = alignments::load(&c.treatment, c, &mut dictionary, e.memory_budget / 4)?;
    let mut control = if c.control.is_empty() {
        None
    } else {
        Some(alignments::load(
            &c.control,
            c,
            &mut dictionary,
            e.memory_budget / 4,
        )?)
    };
    treatment.filter(c.duplicates, c.genome_size)?;
    if let Some(control) = &mut control {
        control.filter(c.duplicates, c.genome_size)?;
    }
    let raw_tag_size = treatment.raw_tag_size;
    let effective_tag_size = if c.format == AlignmentFormat::Bampe {
        treatment
            .last_parser_mean
            .ok_or_else(|| invalid("empty paired treatment parser"))? as u32
    } else {
        c.tag_size.unwrap_or(raw_tag_size)
    };
    if effective_tag_size == 0 {
        return Err(invalid("effective tag/fragment size is zero"));
    }
    if let ModelConfig::Fitted { bandwidth, .. } = c.model
        && u64::from(bandwidth) * 256 > e.memory_budget as u64 / 4
    {
        return Err(invalid(
            "fitted model projection exceeds invocation memory budget",
        ));
    }
    let model = match c.model {
        ModelConfig::Fixed { extension } => ModelReport::fixed(extension),
        ModelConfig::PairedEnd => ModelReport::fixed(effective_tag_size),
        ModelConfig::Fitted {
            bandwidth,
            mfold,
            d_min,
            fallback_extension,
        } => fit::build(
            &treatment,
            c.genome_size,
            bandwidth,
            mfold,
            d_min,
            fallback_extension,
            effective_tag_size,
        )?,
    };
    let min_length = c.min_length.unwrap_or(model.d);
    let max_gap = c.max_gap.unwrap_or(effective_tag_size);
    let parameters = signal::Parameters::new(c, model.d, &treatment, control.as_ref())?;
    let mut chromosomes = treatment
        .chromosomes
        .keys()
        .copied()
        .filter(|id| {
            control
                .as_ref()
                .is_none_or(|ctrl| ctrl.chromosomes.contains_key(id))
        })
        .collect::<Vec<_>>();
    chromosomes.sort_by(|a, b| {
        dictionary.chromosomes[*a]
            .name
            .cmp(&dictionary.chromosomes[*b].name)
    });
    if chromosomes.is_empty() {
        return Err(invalid(
            "treatment and control have no populated chromosomes in common",
        ));
    }
    let workers_used = e.workers_for(chromosomes.len());
    let scratch = tempfile::Builder::new()
        .prefix("peak-call-")
        .tempdir_in(&e.scratch)?;
    let per_worker = e.memory_budget / 2 / workers_used;
    let spools = e.ordered_map(chromosomes.len(), |index| {
        let id = chromosomes[index];
        let chromosome = &dictionary.chromosomes[id];
        let tags = &treatment.chromosomes[&id];
        let ctl = control.as_ref().map(|track| &track.chromosomes[&id]);
        signal::prepare(
            tags,
            ctl,
            chromosome
                .len
                .ok_or_else(|| invalid("missing BAM reference length"))?,
            &parameters,
            c,
            per_worker,
            scratch.path().join(format!("segments-{index}")),
        )
    })?;
    let mut histogram = HashMap::<u32, u64>::new();
    for spool in &spools {
        for (&score, &length) in &spool.histogram {
            let count = histogram.entry(score).or_default();
            *count = count
                .checked_add(length)
                .ok_or_else(|| invalid("global score length overflow"))?;
        }
        if histogram.len() > e.memory_budget / 512 {
            return Err(invalid(
                "global caller score histogram exceeds invocation memory budget",
            ));
        }
    }
    let qtable = statistics::qtable(&histogram)?;
    let cutoff = match c.score {
        ScoreCutoff::P(p) | ScoreCutoff::Q(p) => (-(p.ln() / std::f64::consts::LN_10)) as f32,
    };
    let results = e.ordered_map(spools.len(), |index| {
        output::call(
            &spools[index],
            &qtable,
            c.score,
            cutoff,
            max_gap,
            min_length,
            per_worker,
        )
    })?;
    let report = CallReport {
        peak_count: results.iter().map(Vec::len).sum(),
        workers_requested: e.threads.get(),
        workers_used,
        model,
        raw_tag_size,
        effective_tag_size,
        final_treatment_parser_mean: treatment.last_parser_mean,
        treatment: treatment.report(),
        control: control.as_ref().map(alignments::Track::report),
        max_gap,
        min_length,
        config: c.clone(),
        narrow_peak_path: path("_peaks.narrowPeak"),
        summits_path: path("_summits.bed"),
        xls_path: path("_peaks.xls"),
        treatment_track_path: c.write_tracks.then(|| path("_treat_pileup.bdg")),
        control_track_path: c.write_tracks.then(|| path("_control_lambda.bdg")),
        report_path: path("_call.json"),
    };
    output::write_peaks(&mut group, &results, &chromosomes, &dictionary, c)?;
    if c.write_tracks {
        output::write_tracks(&mut group, &spools, &chromosomes, &dictionary)?;
    }
    serde_json::to_writer_pretty(group.file_mut(3), &report)
        .map_err(|error| invalid(format!("writing caller report: {error}")))?;
    for index in 0..destinations.len() {
        group.file_mut(index).flush()?;
    }
    group.commit()?;
    Ok(report)
}

#[cfg(test)]
mod tests;
