use super::{AlignmentFormat, CallConfig, DuplicatePolicy, ModelConfig, ScaleTo, ScoreCutoff, run};
use crate::execution::Execution;
use std::{
    fs,
    num::NonZeroUsize,
    path::{Path, PathBuf},
};

fn source_fixture() -> PathBuf {
    std::env::var_os("RSOMICS_PEAK_SOURCE_FIXTURE").map(PathBuf::from).unwrap_or_else(|| {
        PathBuf::from("/Volumes/Zane's HDD/rsomics-fixtures/evidence/peak-first-workflow-oracle-2026-10-31/run-41209740891/selected")
    })
}

fn config(fixture: &Path, number: usize, output_directory: PathBuf) -> CallConfig {
    let paired = number >= 4;
    let format = if paired {
        AlignmentFormat::Bampe
    } else {
        AlignmentFormat::Bam
    };
    let extension = if paired { "pe" } else { "se" };
    let input = |sample: &str| fixture.join(format!("inputs/alignments/{sample}.{extension}.bam"));
    CallConfig {
        treatment: if number == 1 {
            vec![input("T1")]
        } else {
            vec![input("T1"), input("T2")]
        },
        control: if number == 2 || number == 4 {
            vec![input("C1"), input("C2")]
        } else {
            Vec::new()
        },
        format,
        genome_size: 20_000_000.0,
        duplicates: match number {
            2 => DuplicatePolicy::Auto,
            3 | 5 => DuplicatePolicy::All,
            _ => DuplicatePolicy::Limit(1),
        },
        model: match number {
            1 | 2 => ModelConfig::Fitted {
                bandwidth: 300,
                mfold: [5, 50],
                d_min: 20,
                fallback_extension: None,
            },
            3 => ModelConfig::Fixed { extension: 200 },
            _ => ModelConfig::PairedEnd,
        },
        shift: 0,
        score: if number == 3 || number == 5 {
            ScoreCutoff::P(0.0001)
        } else {
            ScoreCutoff::Q(0.05)
        },
        small_local: 1000,
        large_local: 10_000,
        disable_local: false,
        scale_to: ScaleTo::Small,
        tag_size: None,
        max_gap: None,
        min_length: None,
        name: format!("M{number}"),
        output_directory,
        write_tracks: true,
    }
}

fn table_body(path: &Path) -> Vec<String> {
    fs::read_to_string(path)
        .unwrap()
        .lines()
        .filter(|line| !line.starts_with('#') && !line.is_empty())
        .map(str::to_owned)
        .collect()
}

#[test]
fn five_original_macs_modes_fit_pool_score_and_publish_exact_outputs_with_one_and_four_workers() {
    let fixture = source_fixture();
    let scratch = tempfile::tempdir().unwrap();
    let mut semantic_outputs = Vec::new();
    for workers in [1, 4] {
        let mut generation = Vec::new();
        for number in 1..=5 {
            let output = scratch.path().join(format!("workers{workers}-M{number}"));
            fs::create_dir(&output).unwrap();
            let configuration = config(&fixture, number, output.clone());
            let execution = Execution {
                threads: NonZeroUsize::new(workers).unwrap(),
                scratch: scratch.path().to_owned(),
                memory_budget: 512 * 1024 * 1024,
            };
            let report = run(&configuration, &execution).unwrap();
            assert_eq!(report.peak_count, 400, "M{number}, workers{workers}");
            assert_eq!(report.workers_requested, workers);
            assert_eq!(report.workers_used, workers.min(2));
            assert_eq!(report.model.d, [212, 211, 200, 220, 220][number - 1]);
            assert!(!report.model.fallback_used);
            if number <= 2 {
                assert_eq!(report.model.fitted_d, Some([212, 211][number - 1]));
                assert!(report.model.paired_peaks >= 100);
                assert!(!report.model.correlation.is_empty());
            }
            assert_eq!(
                report.treatment.admitted,
                if number == 1 {
                    100_020
                } else if number < 4 {
                    200_040
                } else {
                    200_038
                }
            );
            assert_eq!(
                report.treatment.retained,
                [95_291, 197_293, 200_040, 199_454, 200_038][number - 1]
            );
            if number == 2 || number == 4 {
                let control = report.control.as_ref().unwrap();
                assert_eq!(
                    control.admitted,
                    if number == 2 { 120_040 } else { 120_038 }
                );
                assert_eq!(
                    control.retained,
                    if number == 2 { 120_040 } else { 120_008 }
                );
            }
            let mut files = Vec::new();
            for suffix in [
                "_peaks.narrowPeak",
                "_summits.bed",
                "_peaks.xls",
                "_treat_pileup.bdg",
                "_control_lambda.bdg",
            ] {
                let name = format!("M{number}{suffix}");
                let actual = table_body(&output.join(&name));
                let expected =
                    table_body(&fixture.join(format!("witness/results/M{number}/{name}")));
                assert_eq!(actual, expected, "full original {name}, workers{workers}");
                files.push(actual);
            }
            let persisted: serde_json::Value =
                serde_json::from_slice(&fs::read(&report.report_path).unwrap()).unwrap();
            assert_eq!(persisted["peak_count"], 400);
            assert_eq!(persisted["model"]["d"], report.model.d);
            generation.push(files);
        }
        semantic_outputs.push(generation);
    }
    assert_eq!(semantic_outputs[0], semantic_outputs[1]);
}

#[test]
fn invalid_call_contracts_and_failed_bam_admission_preserve_the_complete_output_group() {
    let scratch = tempfile::tempdir().unwrap();
    let fixture = source_fixture();
    let execution = Execution {
        threads: NonZeroUsize::new(4).unwrap(),
        scratch: scratch.path().to_owned(),
        memory_budget: 512 * 1024 * 1024,
    };
    let configuration = config(&fixture, 3, scratch.path().to_owned());
    let mut invalid = Vec::new();
    let mut c = configuration.clone();
    c.treatment.clear();
    invalid.push(c);
    let mut c = configuration.clone();
    c.format = AlignmentFormat::Bampe;
    invalid.push(c);
    let mut c = configuration.clone();
    c.model = ModelConfig::PairedEnd;
    invalid.push(c);
    let mut c = configuration.clone();
    c.duplicates = DuplicatePolicy::Limit(0);
    invalid.push(c);
    let mut c = configuration.clone();
    c.score = ScoreCutoff::Q(0.0);
    invalid.push(c);
    let mut c = configuration.clone();
    c.name = "../escape".into();
    invalid.push(c);
    let mut c = configuration.clone();
    c.tag_size = Some(0);
    invalid.push(c);
    let mut c = configuration.clone();
    c.model = ModelConfig::Fixed { extension: 0 };
    invalid.push(c);
    for c in invalid {
        assert!(run(&c, &execution).is_err());
    }
    assert_eq!(fs::read_dir(scratch.path()).unwrap().count(), 0);
    let suffixes = [
        "_peaks.narrowPeak",
        "_summits.bed",
        "_peaks.xls",
        "_call.json",
        "_treat_pileup.bdg",
        "_control_lambda.bdg",
    ];
    for suffix in suffixes {
        fs::write(
            scratch.path().join(format!("M3{suffix}")),
            b"unchanged original\n",
        )
        .unwrap();
    }
    let mut alias = configuration.clone();
    alias.treatment = vec![scratch.path().join("M3_peaks.narrowPeak")];
    assert!(
        run(&alias, &execution)
            .unwrap_err()
            .to_string()
            .contains("is also an input path")
    );
    let malformed = scratch.path().join("truncated.bam");
    fs::write(&malformed, b"BAM\x01").unwrap();
    let mut c = configuration;
    c.treatment = vec![malformed];
    assert!(run(&c, &execution).is_err());
    for suffix in suffixes {
        assert_eq!(
            fs::read(scratch.path().join(format!("M3{suffix}"))).unwrap(),
            b"unchanged original\n"
        );
    }
    assert_eq!(fs::read_dir(scratch.path()).unwrap().count(), 7);
}
