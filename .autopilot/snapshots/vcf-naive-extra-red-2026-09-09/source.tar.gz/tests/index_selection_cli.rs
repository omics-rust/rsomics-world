use std::fs::{self, File, FileTimes};
use std::path::PathBuf;
use std::process::{Command, Output};
use std::time::Duration;

struct Fixture {
    directory: tempfile::TempDir,
    input: PathBuf,
}

impl Fixture {
    fn new(encoding: &str) -> Self {
        let directory = tempfile::tempdir().unwrap();
        let source = directory.path().join("source.vcf");
        fs::write(
            &source,
            b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t10\tselected\tA\tC\t.\tPASS\t.\tGT\t0|1\n",
        )
        .unwrap();
        let input = directory.path().join("input.data");
        success(
            command()
                .args(["view", "-O", encoding, "-o"])
                .arg(&input)
                .arg(&source)
                .output()
                .unwrap(),
        );
        Self { directory, input }
    }

    fn index(&self, kind: &str) -> PathBuf {
        self.input.with_extension(format!("data.{kind}"))
    }

    fn build(&self, kind: &str) {
        success(
            command()
                .args(["index", "--force", &format!("--{kind}")])
                .arg(&self.input)
                .output()
                .unwrap(),
        );
    }

    fn make_stale(&self, kind: &str) {
        let modified = fs::metadata(&self.input).unwrap().modified().unwrap();
        File::options()
            .write(true)
            .open(self.index(kind))
            .unwrap()
            .set_times(FileTimes::new().set_modified(modified - Duration::from_secs(60)))
            .unwrap();
    }

    fn write_empty_tbi(&self) {
        let index = noodles_tabix::Index::builder()
            .set_header(noodles_csi::binning_index::index::Header::default())
            .build();
        noodles_tabix::fs::write(self.index("tbi"), &index).unwrap();
    }

    fn run(&self, arguments: &[&str]) -> Output {
        command().args(arguments).arg(&self.input).output().unwrap()
    }

    fn reject_atomically(&self, arguments: &[&str], error: &str) {
        let destination = self.directory.path().join("output.vcf");
        fs::write(&destination, b"previous output").unwrap();
        let output = command()
            .args(arguments)
            .arg("-o")
            .arg(&destination)
            .arg(&self.input)
            .output()
            .unwrap();
        assert!(
            !output.status.success(),
            "unexpected success: {arguments:?}"
        );
        let stderr = String::from_utf8_lossy(&output.stderr);
        assert!(stderr.contains(error), "{stderr}");
        assert_eq!(fs::read(destination).unwrap(), b"previous output");
    }
}

fn command() -> Command {
    Command::new(env!("CARGO_BIN_EXE_rsomics-vcf"))
}

fn success(output: Output) -> Output {
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    output
}

const REGION_COMMANDS: &[&[&str]] = &[
    &["view", "-r", "chr1:10-10"],
    &["concat", "-a", "-r", "chr1:10-10"],
];
const INDEX_COMMANDS: &[&[&str]] = &[
    REGION_COMMANDS[0],
    REGION_COMMANDS[1],
    &["concat", "--ligate"],
];

#[test]
fn vcf_prefers_valid_tbi_over_stale_or_corrupt_csi() {
    for corrupt in [false, true] {
        let fixture = Fixture::new("z");
        fixture.build("csi");
        fixture.build("tbi");
        if corrupt {
            fs::write(fixture.index("csi"), b"corrupt CSI").unwrap();
        } else {
            fixture.make_stale("csi");
        }
        for arguments in INDEX_COMMANDS {
            let output = success(fixture.run(arguments));
            assert!(String::from_utf8_lossy(&output.stdout).contains("chr1\t10\tselected\t"));
        }
    }
}

#[test]
fn vcf_does_not_fall_back_from_stale_or_corrupt_tbi() {
    for corrupt in [false, true] {
        let fixture = Fixture::new("z");
        fixture.build("csi");
        fixture.build("tbi");
        if corrupt {
            fs::write(fixture.index("tbi"), b"corrupt TBI").unwrap();
        } else {
            fixture.make_stale("tbi");
        }
        for arguments in INDEX_COMMANDS {
            fixture.reject_atomically(arguments, "input.data.tbi");
        }
    }
}

#[test]
fn indexed_query_uses_tbi_contents_when_both_indexes_exist() {
    let fixture = Fixture::new("z");
    fixture.build("tbi");
    noodles_csi::fs::write(fixture.index("csi"), &noodles_csi::Index::default()).unwrap();
    for arguments in REGION_COMMANDS {
        let output = success(fixture.run(arguments));
        assert!(String::from_utf8_lossy(&output.stdout).contains("chr1\t10\tselected\t"));
    }
}

#[test]
fn csi_is_used_when_tbi_is_absent() {
    for encoding in ["z", "b"] {
        let fixture = Fixture::new(encoding);
        fixture.build("csi");
        for arguments in INDEX_COMMANDS {
            let output = success(fixture.run(arguments));
            assert!(String::from_utf8_lossy(&output.stdout).contains("chr1\t10\tselected\t"));
        }
    }
}

#[test]
fn bcf_ignores_tbi_but_requires_a_valid_csi() {
    let fixture = Fixture::new("b");
    fixture.build("csi");
    fs::write(fixture.index("tbi"), b"not a TBI index").unwrap();
    for arguments in INDEX_COMMANDS {
        success(fixture.run(arguments));
    }
    fs::write(fixture.index("csi"), b"corrupt CSI").unwrap();
    fixture.write_empty_tbi();
    for arguments in INDEX_COMMANDS {
        fixture.reject_atomically(arguments, "input.data.csi");
    }
}

#[test]
fn bcf_rejects_tbi_only_even_for_ligation() {
    let fixture = Fixture::new("b");
    fixture.write_empty_tbi();
    for arguments in INDEX_COMMANDS {
        fixture.reject_atomically(arguments, "no CSI index found");
    }
}

#[test]
fn indexed_operations_reject_missing_indexes() {
    for encoding in ["z", "b"] {
        let fixture = Fixture::new(encoding);
        for arguments in INDEX_COMMANDS {
            fixture.reject_atomically(arguments, "index found");
        }
    }
}

#[cfg(target_os = "linux")]
#[test]
fn indexed_operations_preserve_non_utf8_paths() {
    use std::ffi::OsString;
    use std::os::unix::ffi::OsStringExt;

    for (encoding, kind) in [("z", "tbi"), ("z", "csi"), ("b", "csi")] {
        for collision in [false, true] {
            let mut fixture = Fixture::new(encoding);
            fixture.build(kind);
            let previous_index = fixture.index(kind);
            let input = fixture
                .directory
                .path()
                .join(OsString::from_vec(b"input-\xff.data".to_vec()));
            fs::rename(&fixture.input, &input).unwrap();
            fixture.input = input;
            fs::rename(previous_index, fixture.index(kind)).unwrap();
            if collision {
                let unrelated = PathBuf::from(format!("{}.{}", fixture.input.display(), kind));
                assert_ne!(unrelated, fixture.index(kind));
                fs::write(unrelated, b"unrelated index").unwrap();
            }
            for arguments in INDEX_COMMANDS {
                let output = success(fixture.run(arguments));
                assert!(String::from_utf8_lossy(&output.stdout).contains("chr1\t10\tselected\t"));
            }
        }
    }
}

#[cfg(target_os = "linux")]
#[test]
fn index_creation_preserves_non_utf8_paths() {
    use std::ffi::OsString;
    use std::os::unix::ffi::OsStringExt;

    for (encoding, kind) in [("z", "tbi"), ("z", "csi"), ("b", "csi")] {
        let mut fixture = Fixture::new(encoding);
        let input = fixture
            .directory
            .path()
            .join(OsString::from_vec(b"input-\xff.data".to_vec()));
        fs::rename(&fixture.input, &input).unwrap();
        fixture.input = input;
        fixture.build(kind);
        assert!(fixture.index(kind).is_file());
        let lossy = PathBuf::from(format!("{}.{}", fixture.input.display(), kind));
        assert!(!lossy.exists());
    }
}

#[cfg(unix)]
#[test]
fn default_index_paths_preserve_non_utf8_bytes() {
    use std::ffi::OsString;
    use std::os::unix::ffi::OsStringExt;

    use rsomics_vcf::index::{IndexKind, default_output_path};

    let input = PathBuf::from(OsString::from_vec(b"input-\xff.data".to_vec()));
    for (kind, expected) in [
        (IndexKind::Tbi, b"input-\xff.data.tbi"),
        (IndexKind::Csi, b"input-\xff.data.csi"),
    ] {
        assert_eq!(
            default_output_path(&input, kind)
                .into_os_string()
                .into_vec(),
            expected
        );
    }
}

#[cfg(unix)]
#[test]
fn dangling_preferred_tbi_does_not_fall_back_to_valid_csi() {
    let fixture = Fixture::new("z");
    fixture.build("csi");
    std::os::unix::fs::symlink("missing-index", fixture.index("tbi")).unwrap();
    for arguments in INDEX_COMMANDS {
        fixture.reject_atomically(arguments, "input.data.tbi");
    }
}

#[test]
fn indexed_bcf_queries_reject_zero_shared_lengths_inside_selected_chunks() {
    use std::io::{self, Cursor, Read, Write};

    use noodles_bgzf as bgzf;
    use noodles_csi::{
        BinningIndex,
        binning_index::{
            Indexer,
            index::reference_sequence::{bin::Chunk, index::BinnedIndex},
        },
    };
    use noodles_vcf::variant::io::Write as _;

    const BGZF_EOF: [u8; 28] = [
        0x1f, 0x8b, 0x08, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0xff, 0x06, 0x00, 0x42, 0x43, 0x02,
        0x00, 0x1b, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    ];

    fn write_indexed_payload(
        fixture: &Fixture,
        payload: &[u8],
        header_end: usize,
        header: &noodles_vcf::Header,
    ) {
        assert!(payload.len() < 65_536);
        let mut writer = bgzf::io::Writer::new(Vec::new());
        writer.write_all(payload).unwrap();
        let encoded = writer.finish().unwrap();
        assert_eq!(&encoded[..4], &[0x1f, 0x8b, 0x08, 0x04]);
        assert_eq!(&encoded[10..16], &[6, 0, b'B', b'C', 2, 0]);
        let frame_length = usize::from(u16::from_le_bytes([encoded[16], encoded[17]])) + 1;
        assert_eq!(&encoded[frame_length..], &BGZF_EOF);
        let mut decoded = Vec::new();
        flate2::read::MultiGzDecoder::new(encoded.as_slice())
            .read_to_end(&mut decoded)
            .unwrap();
        assert_eq!(decoded, payload);

        let mut reader = noodles_bcf::io::Reader::new(Cursor::new(encoded.as_slice()));
        assert_eq!(&reader.read_header().unwrap(), header);
        let start = reader.get_ref().virtual_position();
        assert_eq!(
            start,
            bgzf::VirtualPosition::try_from((0, u16::try_from(header_end).unwrap())).unwrap()
        );
        let mut body = vec![0; payload.len() - header_end];
        reader.get_mut().read_exact(&mut body).unwrap();
        assert_eq!(body, payload[header_end..]);
        let end = reader.get_ref().virtual_position();
        assert_eq!(
            end,
            bgzf::VirtualPosition::try_from((u64::try_from(frame_length).unwrap(), 0)).unwrap()
        );
        let chunk = Chunk::new(start, end);
        let position = noodles_core::Position::try_from(10).unwrap();
        let mut indexer = Indexer::<BinnedIndex>::new(14, 5);
        indexer
            .add_record(Some((0, position, position, true)), chunk)
            .unwrap();
        fs::write(&fixture.input, &encoded).unwrap();
        noodles_csi::fs::write(fixture.index("csi"), &indexer.build(1)).unwrap();
        assert!(
            fs::metadata(fixture.index("csi"))
                .unwrap()
                .modified()
                .unwrap()
                >= fs::metadata(&fixture.input).unwrap().modified().unwrap()
        );
        let index = noodles_csi::fs::read(fixture.index("csi")).unwrap();
        assert_eq!(index.reference_sequences().len(), 1);
        let chunks = index.query(0, (position..=position).into()).unwrap();
        assert_eq!(chunks, [chunk]);
        let mut reader = bgzf::io::Reader::new(File::open(&fixture.input).unwrap());
        let mut query = noodles_csi::io::Query::new(&mut reader, chunks);
        let mut queried = Vec::new();
        query.read_to_end(&mut queried).unwrap();
        assert_eq!(queried, payload[header_end..]);
        eprintln!(
            "indexed BCF fixture: header_bytes={header_end}, body_bytes={}, data_frame_bytes={frame_length}, chunk={chunk:?}",
            queried.len()
        );
    }

    fn decoded_records(source: &[u8]) -> io::Result<Vec<u8>> {
        let mut reader = noodles_util::variant::io::Reader::new(source)?;
        let header = reader.read_header()?;
        let mut writer = noodles_vcf::io::Writer::new(Vec::new());
        for record in reader.records(&header) {
            writer.write_variant_record(&header, record?.as_ref())?;
        }
        Ok(writer.into_inner())
    }

    let fixture = Fixture::new("u");
    let original = fs::read(&fixture.input).unwrap();
    assert!(original.starts_with(b"BCF\x02\x02"));
    let mut reader = noodles_bcf::io::Reader::from(original.as_slice());
    let header = reader.read_header().unwrap();
    assert_eq!(header.contigs().len(), 1);
    assert_eq!(header.string_maps().contigs().get_index(0), Some("chr1"));
    let header_end = original.len() - reader.get_ref().len();
    assert_eq!(
        header_end,
        9 + usize::try_from(u32::from_le_bytes(original[5..9].try_into().unwrap())).unwrap()
    );
    let mut record = noodles_bcf::Record::default();
    assert!(reader.read_record(&mut record).unwrap() > 0);
    assert_eq!(record.reference_sequence_id().unwrap(), 0);
    assert_eq!(usize::from(record.variant_start().unwrap().unwrap()), 10);
    noodles_vcf::variant::RecordBuf::try_from_variant_record(&header, &record).unwrap();
    assert!(reader.get_ref().is_empty());
    assert_eq!(reader.read_record(&mut record).unwrap(), 0);
    let expected = b"chr1\t10\tselected\tA\tC\t.\tPASS\t.\tGT\t0|1\n";
    assert_eq!(decoded_records(&original).unwrap(), expected);

    let mut failures = Vec::new();
    let mut malformed_runs = 0;
    let mut control_runs = 0;
    for (layout, zero_before, zero_after) in [
        ("positive-control", false, false),
        ("zero-then-record", true, false),
        ("record-then-zero", false, true),
    ] {
        let mut payload = original[..header_end].to_vec();
        if zero_before {
            payload.extend_from_slice(&0u32.to_le_bytes());
        }
        payload.extend_from_slice(&original[header_end..]);
        if zero_after {
            payload.extend_from_slice(&0u32.to_le_bytes());
        }
        write_indexed_payload(&fixture, &payload, header_end, &header);
        for arguments in REGION_COMMANDS {
            for encoding in ["v", "z", "b", "u"] {
                let case = format!("{layout}, command={}, output={encoding}", arguments[0]);
                let destination = fixture
                    .directory
                    .path()
                    .join(format!("indexed-zero-{layout}-{}-{encoding}", arguments[0]));
                fs::write(&destination, b"previous output").unwrap();
                let output = command()
                    .args(*arguments)
                    .args(["-O", encoding, "-o"])
                    .arg(&destination)
                    .arg(&fixture.input)
                    .output()
                    .unwrap();
                eprintln!(
                    "indexed zero-length BCF: {case}: status={}, stdout_bytes={}, stderr={}",
                    output.status,
                    output.stdout.len(),
                    String::from_utf8_lossy(&output.stderr)
                );
                if zero_before || zero_after {
                    malformed_runs += 1;
                    if output.status.success() {
                        failures.push(format!("{case}: malformed indexed BCF was accepted"));
                    }
                    if fs::read(&destination).unwrap() != b"previous output" {
                        failures.push(format!("{case}: existing output was replaced"));
                    }
                } else {
                    control_runs += 1;
                    if !output.status.success() {
                        failures.push(format!("{case}: valid indexed BCF was rejected"));
                        continue;
                    }
                    match decoded_records(&fs::read(&destination).unwrap()) {
                        Ok(records) if records == expected => {}
                        other => failures.push(format!("{case}: unexpected records {other:?}")),
                    }
                }
            }
        }
    }
    eprintln!(
        "indexed zero-length BCF completed: {malformed_runs} malformed runs, {control_runs} controls"
    );
    assert!(failures.is_empty(), "{failures:#?}");
}
