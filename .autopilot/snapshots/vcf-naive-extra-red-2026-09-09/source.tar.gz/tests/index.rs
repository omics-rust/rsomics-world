use std::fs::{self, File};
use std::io::{BufReader, Read, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

use noodles_bcf as bcf;
use noodles_bgzf as bgzf;
use noodles_vcf::{self as vcf, variant::io::Write as _};

#[path = "common/sparse_bcf.rs"]
mod sparse_fixture;

fn binary() -> PathBuf {
    PathBuf::from(env!("CARGO_BIN_EXE_rsomics-vcf"))
}

fn fixture() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/index.vcf")
}

fn bgzip(source: &[u8], destination: &Path) {
    let mut writer = bgzf::io::Writer::new(File::create(destination).unwrap());
    writer.write_all(source).unwrap();
    writer.try_finish().unwrap();
}

fn write_bcf(input: &Path, output: &Path) {
    let mut reader = vcf::io::Reader::new(BufReader::new(File::open(input).unwrap()));
    let header = reader.read_header().unwrap();
    let mut writer = bcf::io::Writer::new(File::create(output).unwrap());
    writer.write_header(&header).unwrap();

    for record in reader.records() {
        writer
            .write_variant_record(&header, &record.unwrap())
            .unwrap();
    }

    writer.try_finish().unwrap();
}

fn corrupt_bcf_reference_type(input: &Path, output: &Path) {
    let mut data = Vec::new();
    bgzf::io::Reader::new(File::open(input).unwrap())
        .read_to_end(&mut data)
        .unwrap();
    let header_length =
        usize::try_from(u32::from_le_bytes(data[5..9].try_into().unwrap())).unwrap();
    let record_start = 9 + header_length;
    let id_start = record_start + 8 + 24;
    let id_length = usize::from(data[id_start] >> 4);
    data[id_start + 1 + id_length] = 0x11;
    bgzip(&data, output);
}

fn run(arguments: &[&str]) -> std::process::Output {
    let output = Command::new(binary()).args(arguments).output().unwrap();
    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    output
}

#[test]
fn builds_csi_tbi_and_reports_counts() {
    let directory = tempfile::tempdir().unwrap();
    let input = directory.path().join("calls.vcf.gz");
    bgzip(&fs::read(fixture()).unwrap(), &input);
    let input = input.to_str().unwrap();

    run(&["index", "--threads", "2", input]);
    assert!(PathBuf::from(format!("{input}.csi")).exists());
    assert_eq!(run(&["index", "--nrecords", input]).stdout, b"14\n");
    assert_eq!(
        run(&["index", "--stats", input]).stdout,
        b"chr1\t248956422\t9\nchr2\t242193529\t5\n"
    );
    assert_eq!(
        run(&["index", "--stats", "--all", input]).stdout,
        b"chr1\t248956422\t9\nchr2\t242193529\t5\n"
    );

    fs::remove_file(format!("{input}.csi")).unwrap();
    run(&["index", "--tbi", input]);
    assert!(PathBuf::from(format!("{input}.tbi")).exists());
    assert_eq!(run(&["index", "--nrecords", input]).stdout, b"14\n");
}

#[test]
fn builds_bcf_csi_and_reports_empty_contigs() {
    let directory = tempfile::tempdir().unwrap();
    let input = directory.path().join("calls.bcf");
    write_bcf(&fixture(), &input);
    let input = input.to_str().unwrap();

    run(&["index", input]);
    assert!(PathBuf::from(format!("{input}.csi")).exists());
    assert_eq!(run(&["index", "--nrecords", input]).stdout, b"14\n");
    assert_eq!(
        run(&["index", "--stats", input]).stdout,
        b"chr1\t248956422\t9\nchr2\t242193529\t5\n"
    );
    assert_eq!(
        run(&["index", "--stats", "--all", input]).stdout,
        b"chr1\t248956422\t9\nchr2\t242193529\t5\nchr3\t198295559\t.\n"
    );

    let result = Command::new(binary())
        .args(["index", "--tbi", input])
        .output()
        .unwrap();
    assert!(!result.status.success());
    assert!(String::from_utf8_lossy(&result.stderr).contains("BCF"));
}

#[test]
fn rejects_malformed_bcf_without_replacing_an_index() {
    let directory = tempfile::tempdir().unwrap();
    let valid = directory.path().join("valid.bcf");
    let input = directory.path().join("malformed.bcf");
    let output = directory.path().join("malformed.bcf.csi");
    write_bcf(&fixture(), &valid);
    corrupt_bcf_reference_type(&valid, &input);
    fs::write(&output, b"existing").unwrap();

    let result = Command::new(binary())
        .args([
            "index",
            "--force",
            "--output",
            output.to_str().unwrap(),
            input.to_str().unwrap(),
        ])
        .output()
        .unwrap();
    assert!(!result.status.success());
    assert!(String::from_utf8_lossy(&result.stderr).contains("REF/ALT"));
    assert_eq!(fs::read(output).unwrap(), b"existing");
}

#[test]
fn overwrite_is_explicit_and_transactional() {
    let directory = tempfile::tempdir().unwrap();
    let input = directory.path().join("bad.vcf.gz");
    let output = directory.path().join("bad.vcf.gz.csi");
    bgzip(
        b"##fileformat=VCFv4.3\n#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\nchr1\tbad\t.\tA\tT\t.\tPASS\t.\n",
        &input,
    );
    fs::write(&output, b"existing").unwrap();

    let result = Command::new(binary())
        .args([
            "index",
            "--force",
            "--output",
            output.to_str().unwrap(),
            input.to_str().unwrap(),
        ])
        .output()
        .unwrap();
    assert!(!result.status.success());
    assert!(String::from_utf8_lossy(&result.stderr).contains("VCF record 1"));
    assert_eq!(fs::read(output).unwrap(), b"existing");
}

#[test]
fn standard_input_requires_and_uses_named_output() {
    let input = fs::read(fixture()).unwrap();
    let directory = tempfile::tempdir().unwrap();
    let compressed = directory.path().join("input.vcf.gz");
    let output = directory.path().join("stdin.csi");
    bgzip(&input, &compressed);
    let compressed = fs::read(compressed).unwrap();

    let missing = Command::new(binary())
        .args(["index", "-"])
        .stdin(Stdio::null())
        .output()
        .unwrap();
    assert!(!missing.status.success());

    let mut child = Command::new(binary())
        .args(["index", "--output", output.to_str().unwrap(), "-"])
        .stdin(Stdio::piped())
        .spawn()
        .unwrap();
    child.stdin.take().unwrap().write_all(&compressed).unwrap();
    assert!(child.wait().unwrap().success());
    assert!(output.exists());
}

#[test]
fn rejects_incomplete_and_unsorted_inputs() {
    let directory = tempfile::tempdir().unwrap();
    let incomplete = directory.path().join("incomplete.vcf.gz");
    let mut compressed = Vec::new();
    {
        let mut writer = bgzf::io::Writer::new(&mut compressed);
        writer.write_all(&fs::read(fixture()).unwrap()).unwrap();
        writer.try_finish().unwrap();
    }
    compressed.truncate(compressed.len() - 29);
    fs::write(&incomplete, compressed).unwrap();
    let result = Command::new(binary())
        .args(["index", incomplete.to_str().unwrap()])
        .output()
        .unwrap();
    assert!(!result.status.success());
    assert!(String::from_utf8_lossy(&result.stderr).contains("end-of-file marker"));

    let unsorted = directory.path().join("unsorted.vcf.gz");
    bgzip(
        b"##fileformat=VCFv4.3\n##contig=<ID=chr1,length=100>\n#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\nchr1\t20\t.\tA\tT\t.\tPASS\t.\nchr1\t10\t.\tA\tT\t.\tPASS\t.\n",
        &unsorted,
    );
    let result = Command::new(binary())
        .args(["index", unsorted.to_str().unwrap()])
        .output()
        .unwrap();
    assert!(!result.status.success());
    assert!(String::from_utf8_lossy(&result.stderr).contains("positions are not sorted"));
    assert!(!PathBuf::from(format!("{}.csi", unsorted.display())).exists());
}

fn sparse_bcf(directory: &Path, empty: bool) -> PathBuf {
    let source = directory.join("sparse.vcf");
    let input = directory.join("sparse.bcf");
    sparse_fixture::write_vcf(&source, empty);
    run(&[
        "view",
        "-Ob",
        "-o",
        input.to_str().unwrap(),
        source.to_str().unwrap(),
    ]);
    sparse_fixture::assert_bcf(&input, empty);
    input
}

fn sparse_csi(input: &Path) {
    sparse_csi_slots(input, 10);
}

fn sparse_csi_slots(input: &Path, slots: usize) {
    use noodles_csi::binning_index::{
        Indexer,
        index::reference_sequence::{bin::Chunk, index::BinnedIndex},
    };
    let mut reader = bcf::io::Reader::new(File::open(input).unwrap());
    reader.read_header().unwrap();
    let mut indexer = Indexer::<BinnedIndex>::new(14, 5);
    let mut record = bcf::Record::default();
    loop {
        let start = reader.get_ref().virtual_position();
        if reader.read_record(&mut record).unwrap() == 0 {
            break;
        }
        let end = reader.get_ref().virtual_position();
        let reference = record.reference_sequence_id().unwrap();
        let position = record.variant_start().unwrap().unwrap();
        indexer
            .add_record(
                Some((reference, position, position, true)),
                Chunk::new(start, end),
            )
            .unwrap();
    }
    noodles_csi::fs::write(input.with_extension("bcf.csi"), &indexer.build(slots)).unwrap();
}

#[test]
fn sparse_bcf_builds_preserve_dictionary_span_and_declared_contig_count() {
    let mut failures = Vec::new();
    for empty in [false, true] {
        for threads in ["0", "2"] {
            let directory = tempfile::tempdir().unwrap();
            let input = sparse_bcf(directory.path(), empty);
            let output = Command::new(binary())
                .args(["--json", "index", "--threads", threads])
                .arg(&input)
                .output()
                .unwrap();
            if !output.status.success() {
                failures.push(format!(
                    "empty={empty}, threads={threads}: {}",
                    String::from_utf8_lossy(&output.stderr)
                ));
                continue;
            }
            let json: serde_json::Value = serde_json::from_slice(&output.stdout).unwrap();
            let summary = &json["result"]["outcome"];
            assert_eq!(summary["reference_sequences"], 3);
            assert_eq!(summary["records"], if empty { 0 } else { 3 });
            let index = noodles_csi::fs::read(input.with_extension("bcf.csi")).unwrap();
            if index.reference_sequences().len() != 10 {
                failures.push(format!(
                    "empty={empty}, threads={threads}: {} index slots, expected 10",
                    index.reference_sequences().len()
                ));
                continue;
            }
            for (region, suffix) in [
                ("chrB:10", "chrB\t10\tb1\tA\tC\t.\tPASS\t.\n"),
                ("chrA:30", "chrA\t30\ta1\tT\tA\t.\tPASS\t.\n"),
                ("empty:1", ""),
            ] {
                let output = run(&["view", "--no-header", "-r", region, input.to_str().unwrap()]);
                assert_eq!(
                    output.stdout,
                    if empty {
                        b"".as_slice()
                    } else {
                        suffix.as_bytes()
                    }
                );
            }
            assert_eq!(
                run(&["index", "--nrecords", input.to_str().unwrap()]).stdout,
                if empty { b"0\n" } else { b"3\n" }
            );
        }
    }
    assert!(failures.is_empty(), "{failures:#?}");
}

#[test]
fn sparse_bcf_statistics_use_raw_ids_without_inventing_contigs() {
    let directory = tempfile::tempdir().unwrap();
    let input = sparse_bcf(directory.path(), false);
    sparse_csi(&input);
    let mut failures = Vec::new();
    for all in [false, true] {
        let mut command = Command::new(binary());
        command.args(["index", "--stats"]);
        if all {
            command.arg("--all");
        }
        let output = command.arg(&input).output().unwrap();
        assert!(output.status.success());
        let expected = if all {
            "chrB\t100\t2\nchrA\t200\t1\nempty\t300\t.\n"
        } else {
            "chrB\t100\t2\nchrA\t200\t1\n"
        };
        if output.stdout != expected.as_bytes() {
            failures.push(format!(
                "all={all}: {}",
                String::from_utf8_lossy(&output.stdout)
            ));
        }
    }
    assert!(failures.is_empty(), "{failures:#?}");
}

#[test]
fn sparse_bcf_rejects_unknown_record_ids_without_replacing_an_index() {
    for reference in [1i32, 10, i32::MAX] {
        for threads in ["0", "2"] {
            let directory = tempfile::tempdir().unwrap();
            let valid = sparse_bcf(directory.path(), false);
            let input = directory.path().join("invalid.bcf");
            let output = input.with_extension("bcf.csi");
            let mut data = Vec::new();
            bgzf::io::Reader::new(File::open(&valid).unwrap())
                .read_to_end(&mut data)
                .unwrap();
            let header_length =
                usize::try_from(u32::from_le_bytes(data[5..9].try_into().unwrap())).unwrap();
            let record_start = 9 + header_length;
            data[record_start + 8..record_start + 12].copy_from_slice(&reference.to_le_bytes());
            bgzip(&data, &input);
            fs::write(&output, b"existing").unwrap();
            let result = Command::new(binary())
                .args(["index", "--force", "--threads", threads])
                .arg(&input)
                .output()
                .unwrap();
            assert!(
                !result.status.success(),
                "RID={reference}, threads={threads}"
            );
            assert!(
                String::from_utf8_lossy(&result.stderr)
                    .contains("contig ID is outside the header dictionary")
            );
            assert_eq!(fs::read(&output).unwrap(), b"existing");
        }
    }
}

#[test]
fn sparse_bcf_statistics_reject_counts_in_an_unnamed_index_slot() {
    use noodles_csi::BinningIndex as _;
    let directory = tempfile::tempdir().unwrap();
    let input = sparse_bcf(directory.path(), false);
    sparse_csi(&input);
    let path = input.with_extension("bcf.csi");
    let index = noodles_csi::fs::read(&path).unwrap();
    let mut references = index.reference_sequences().to_vec();
    references.swap(1, 2);
    for auxiliary_names in [false, true] {
        let mut builder = noodles_csi::Index::builder()
            .set_min_shift(index.min_shift())
            .set_depth(index.depth())
            .set_reference_sequences(references.clone());
        if auxiliary_names {
            let header = noodles_csi::binning_index::index::Header::builder()
                .set_reference_sequence_names(
                    ["fake0".into(), "fake1".into()].into_iter().collect(),
                )
                .build();
            builder = builder.set_header(header);
        }
        noodles_csi::fs::write(&path, &builder.build()).unwrap();
        for option in ["--stats", "--nrecords"] {
            let output = Command::new(binary())
                .args(["index", option])
                .arg(&input)
                .output()
                .unwrap();
            assert!(
                !output.status.success(),
                "auxiliary_names={auxiliary_names}, {option}"
            );
            assert!(output.stdout.is_empty());
            assert!(
                String::from_utf8_lossy(&output.stderr)
                    .contains("index slot 1 has records but no BCF contig")
            );
        }
    }
}

fn variant_body(path: &Path) -> Vec<u8> {
    let mut reader = noodles_util::variant::io::Reader::new(File::open(path).unwrap()).unwrap();
    let header = reader.read_header().unwrap();
    let mut writer = vcf::io::Writer::new(Vec::new());
    for record in reader.records(&header) {
        writer
            .write_variant_record(&header, record.unwrap().as_ref())
            .unwrap();
    }
    writer.into_inner()
}

#[test]
fn sparse_bcf_queries_accept_indexes_without_empty_tail_slots() {
    let mut failures = Vec::new();
    for empty in [false, true] {
        let directory = tempfile::tempdir().unwrap();
        let input = sparse_bcf(directory.path(), empty);
        let slots = if empty { 0 } else { 6 };
        sparse_csi_slots(&input, slots);
        let index = noodles_csi::fs::read(input.with_extension("bcf.csi")).unwrap();
        assert_eq!(index.reference_sequences().len(), slots);
        for operation in ["view", "concat"] {
            for encoding in ["v", "z", "b", "u"] {
                for region in ["empty:1", "empty:1,chrB:10"] {
                    let output_path = directory.path().join("output");
                    let mut command = Command::new(binary());
                    command.args(["--json", operation]);
                    if operation == "concat" {
                        command.arg("-a");
                    }
                    let result = command
                        .args(["-O", encoding, "-r", region, "-o"])
                        .arg(&output_path)
                        .arg(&input)
                        .output()
                        .unwrap();
                    let case = format!("empty={empty}, {operation}, {encoding}, {region}");
                    if !result.status.success() {
                        failures.push(format!(
                            "{case}: {}",
                            String::from_utf8_lossy(&result.stderr)
                        ));
                        continue;
                    }
                    let expected = if empty || region == "empty:1" {
                        b"".as_slice()
                    } else {
                        b"chrB\t10\tb1\tA\tC\t.\tPASS\t.\n".as_slice()
                    };
                    assert_eq!(variant_body(&output_path), expected, "{case}");
                    let json: serde_json::Value = serde_json::from_slice(&result.stdout).unwrap();
                    let summary = &json["result"]["summary"];
                    let (read, written) = if operation == "view" {
                        ("read", "written")
                    } else {
                        ("records_read", "records_written")
                    };
                    assert_eq!(summary[written], u64::from(!expected.is_empty()), "{case}");
                    if expected.is_empty() {
                        assert_eq!(summary[read], 0, "{case}");
                    }
                }
            }
        }
    }
    assert!(failures.is_empty(), "{failures:#?}");
}

#[test]
fn sparse_bcf_statistics_include_declared_contigs_beyond_index_span() {
    let mut failures = Vec::new();
    for empty in [false, true] {
        let directory = tempfile::tempdir().unwrap();
        let input = sparse_bcf(directory.path(), empty);
        sparse_csi_slots(&input, if empty { 0 } else { 6 });
        let output = run(&["index", "--stats", "--all", input.to_str().unwrap()]);
        let expected = if empty {
            b"chrB\t100\t.\nchrA\t200\t.\nempty\t300\t.\n".as_slice()
        } else {
            b"chrB\t100\t2\nchrA\t200\t1\nempty\t300\t.\n".as_slice()
        };
        if output.stdout != expected {
            failures.push(format!(
                "empty={empty}: {}",
                String::from_utf8_lossy(&output.stdout)
            ));
        }
        assert_eq!(
            run(&["index", "--nrecords", input.to_str().unwrap()]).stdout,
            if empty { b"0\n" } else { b"3\n" }
        );
        assert_eq!(
            run(&["index", "--stats", input.to_str().unwrap()]).stdout,
            if empty {
                b"".as_slice()
            } else {
                b"chrB\t100\t2\nchrA\t200\t1\n"
            }
        );
    }
    assert!(failures.is_empty(), "{failures:#?}");
}

#[test]
fn sparse_bcf_empty_queries_still_reject_unknown_regions_and_corrupt_indexes() {
    let directory = tempfile::tempdir().unwrap();
    let input = sparse_bcf(directory.path(), false);
    for corrupt in [false, true] {
        sparse_csi_slots(&input, 6);
        if corrupt {
            fs::write(input.with_extension("bcf.csi"), b"broken CSI").unwrap();
        }
        for operation in ["view", "concat"] {
            for encoding in ["v", "z", "b", "u"] {
                let destination = directory.path().join("preserved");
                fs::write(&destination, b"existing output").unwrap();
                let mut command = Command::new(binary());
                command.arg(operation);
                if operation == "concat" {
                    command.arg("-a");
                }
                let region = if corrupt { "empty:1" } else { "missing:1" };
                let output = command
                    .args(["-O", encoding, "-r", region, "-o"])
                    .arg(&destination)
                    .arg(&input)
                    .output()
                    .unwrap();
                assert!(
                    !output.status.success(),
                    "corrupt={corrupt}, {operation}, {encoding}"
                );
                assert!(output.stdout.is_empty());
                assert!(!output.stderr.is_empty());
                if !corrupt {
                    assert!(String::from_utf8_lossy(&output.stderr).contains("missing"));
                }
                assert_eq!(fs::read(&destination).unwrap(), b"existing output");
            }
        }
    }
}
