use std::fs::{self, File};
use std::path::Path;

pub fn write_vcf(destination: &Path, empty: bool) {
    let source = include_str!("../fixtures/sparse-ids.vcf");
    let content: String = source
        .split_inclusive('\n')
        .filter(|line| !empty || line.starts_with('#'))
        .collect();
    fs::write(destination, content).unwrap();
}

pub fn assert_bcf(path: &Path, empty: bool) {
    let mut reader = noodles_bcf::io::Reader::new(File::open(path).unwrap());
    let header = reader.read_header().unwrap();
    for (id, name) in [(2, "chrB"), (5, "chrA"), (9, "empty")] {
        assert_eq!(header.string_maps().contigs().get_index(id), Some(name));
    }
    let mut record = noodles_bcf::Record::default();
    if !empty {
        for reference in [2, 2, 5] {
            assert!(reader.read_record(&mut record).unwrap() > 0);
            assert_eq!(record.reference_sequence_id().unwrap(), reference);
        }
    }
    assert_eq!(reader.read_record(&mut record).unwrap(), 0);
}
