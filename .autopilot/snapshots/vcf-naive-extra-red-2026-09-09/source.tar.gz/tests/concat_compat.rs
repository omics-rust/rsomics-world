use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};

fn ours() -> Command {
    Command::new(env!("CARGO_BIN_EXE_rsomics-vcf"))
}

fn oracle() -> PathBuf {
    std::env::var_os("RSOMICS_BCFTOOLS")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("bcftools"))
}

fn run(command: &mut Command) -> Output {
    let output = command.output().unwrap();
    assert!(
        output.status.success(),
        "stdout={}\nstderr={}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    output
}

fn path(path: &Path) -> &str {
    path.to_str().unwrap()
}

fn assert_oracle_version() {
    let output = run(Command::new(oracle()).arg("--version"));
    assert!(
        String::from_utf8_lossy(&output.stdout).starts_with("bcftools 1.24\n"),
        "{}",
        String::from_utf8_lossy(&output.stdout)
    );
}

fn records(output: &[u8]) -> Vec<&[u8]> {
    output
        .split(|byte| *byte == b'\n')
        .filter(|line| !line.is_empty() && !line.starts_with(b"#"))
        .collect()
}

fn canonical(output: &[u8]) -> Vec<Vec<u8>> {
    let mut metadata = Vec::new();
    let mut body = Vec::new();
    for line in output
        .split(|byte| *byte == b'\n')
        .filter(|line| !line.is_empty())
    {
        if line.starts_with(b"##") {
            if !line.starts_with(b"##FILTER=<ID=PASS,") && !line.starts_with(b"##bcftools_") {
                metadata.push(line.to_vec());
            }
        } else {
            body.push(line.to_vec());
        }
    }
    metadata.sort();
    metadata.extend(body);
    metadata
}

fn index(source: &Path, output: &Path) {
    run(Command::new(oracle()).args([
        "view",
        "--no-version",
        "-Oz",
        "-o",
        path(output),
        path(source),
    ]));
    run(Command::new(oracle()).args(["index", "-f", path(output)]));
}

#[test]
#[ignore = "release oracle: requires bcftools 1.24"]
fn successful_concat_modes_match_bcftools_1_24() {
    assert_oracle_version();
    let directory = tempfile::tempdir().unwrap();
    let ordered_left = directory.path().join("ordered-left.vcf");
    let ordered_right = directory.path().join("ordered-right.vcf");
    let overlap_left = directory.path().join("overlap-left.vcf");
    let overlap_right = directory.path().join("overlap-right.vcf");
    let header = "##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n";
    fs::write(
        &ordered_left,
        format!("{header}chr1\t10\ta\tA\tC\t.\tPASS\t.\tGT\t0/1\n"),
    )
    .unwrap();
    fs::write(
        &ordered_right,
        format!("{header}chr1\t20\tb\tG\tT\t.\tPASS\t.\tGT\t1/1\n"),
    )
    .unwrap();
    fs::write(
        &overlap_left,
        format!(
            "{header}chr1\t10\ta\tA\tC\t.\tPASS\t.\tGT\t0/1\n\
chr1\t20\tb\tG\tT\t.\tPASS\t.\tGT\t1/1\n"
        ),
    )
    .unwrap();
    fs::write(
        &overlap_right,
        format!(
            "{header}chr1\t5\tearly\tC\tG\t.\tPASS\t.\tGT\t0/1\n\
chr1\t10\tduplicate\tA\tC\t.\tPASS\t.\tGT\t1/1\n\
chr1\t10\tdifferent\tA\tG\t.\tPASS\t.\tGT\t0/1\n\
chr1\t15\tmiddle\tT\tC\t.\tPASS\t.\tGT\t0/1\n"
        ),
    )
    .unwrap();
    let overlap_left_bgzf = directory.path().join("overlap-left.vcf.gz");
    let overlap_right_bgzf = directory.path().join("overlap-right.vcf.gz");
    index(&overlap_left, &overlap_left_bgzf);
    index(&overlap_right, &overlap_right_bgzf);

    for extra in [Vec::<&str>::new(), vec!["-G"]] {
        let mut our = ours();
        our.arg("concat")
            .args(&extra)
            .args([path(&ordered_left), path(&ordered_right)]);
        let mut expected = Command::new(oracle());
        expected
            .args(["concat", "--no-version", "-Ov"])
            .args(&extra)
            .args([path(&ordered_left), path(&ordered_right)]);
        assert_eq!(
            canonical(&run(&mut our).stdout),
            canonical(&run(&mut expected).stdout)
        );
    }

    for mode in ["exact", "snps", "indels", "both", "all"] {
        let actual = run(ours().args([
            "concat",
            "--allow-overlaps",
            "--rm-dups",
            mode,
            path(&overlap_left_bgzf),
            path(&overlap_right_bgzf),
        ]));
        let expected = run(Command::new(oracle()).args([
            "concat",
            "--no-version",
            "-Ov",
            "-a",
            "-d",
            mode,
            path(&overlap_left_bgzf),
            path(&overlap_right_bgzf),
        ]));
        assert_eq!(
            canonical(&actual.stdout),
            canonical(&expected.stdout),
            "{mode}"
        );
    }
    let actual = run(ours().args([
        "concat",
        "--allow-overlaps",
        "--regions",
        "chr1:10-15",
        path(&overlap_left_bgzf),
        path(&overlap_right_bgzf),
    ]));
    let expected = run(Command::new(oracle()).args([
        "concat",
        "--no-version",
        "-Ov",
        "-a",
        "-r",
        "chr1:10-15",
        path(&overlap_left_bgzf),
        path(&overlap_right_bgzf),
    ]));
    assert_eq!(canonical(&actual.stdout), canonical(&expected.stdout));

    let ligate_left_source = directory.path().join("ligate-left.vcf");
    let ligate_right_source = directory.path().join("ligate-right.vcf");
    let ligate_left = directory.path().join("ligate-left.vcf.gz");
    let ligate_right = directory.path().join("ligate-right.vcf.gz");
    fs::write(
        &ligate_left_source,
        format!(
            "{header}chr1\t10\tl1\tA\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t20\tl2\tG\tT\t.\tPASS\t.\tGT\t0|1\n\
chr1\t30\tl3\tC\tG\t.\tPASS\t.\tGT\t1|0\n"
        ),
    )
    .unwrap();
    fs::write(
        &ligate_right_source,
        format!(
            "{header}chr1\t20\tl2\tG\tT\t.\tPASS\t.\tGT\t1|0\n\
chr1\t30\tl3\tC\tG\t.\tPASS\t.\tGT\t0|1\n\
chr1\t40\tl4\tT\tA\t.\tPASS\t.\tGT\t1|0\n"
        ),
    )
    .unwrap();
    index(&ligate_left_source, &ligate_left);
    index(&ligate_right_source, &ligate_right);
    let actual = run(ours().args([
        "concat",
        "--ligate",
        path(&ligate_left),
        path(&ligate_right),
    ]));
    let expected = run(Command::new(oracle()).args([
        "concat",
        "--no-version",
        "-Ov",
        "--ligate",
        path(&ligate_left),
        path(&ligate_right),
    ]));
    assert_eq!(canonical(&actual.stdout), canonical(&expected.stdout));

    let actual = run(ours().args(["concat", "--naive", path(&ligate_left), path(&ligate_right)]));
    let expected = run(Command::new(oracle()).args([
        "concat",
        "--no-version",
        "--naive",
        path(&ligate_left),
        path(&ligate_right),
    ]));
    let actual_path = directory.path().join("naive-actual.vcf.gz");
    let expected_path = directory.path().join("naive-expected.vcf.gz");
    fs::write(&actual_path, actual.stdout).unwrap();
    fs::write(&expected_path, expected.stdout).unwrap();
    let actual = run(Command::new(oracle()).args(["view", "-Ov", path(&actual_path)]));
    let expected = run(Command::new(oracle()).args(["view", "-Ov", path(&expected_path)]));
    assert_eq!(canonical(&actual.stdout), canonical(&expected.stdout));
}

#[test]
#[ignore = "release oracle: requires bcftools 1.24"]
fn ligation_quality_matches_when_a_sample_has_no_informative_sites() {
    assert_oracle_version();
    let directory = tempfile::tempdir().unwrap();
    let left_source = directory.path().join("left.vcf");
    let right_source = directory.path().join("right.vcf");
    let left = directory.path().join("left.vcf.gz");
    let right = directory.path().join("right.vcf.gz");
    let header = "##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tA\tB\n";
    fs::write(
        &left_source,
        format!(
            "{header}chr1\t10\tl1\tA\tC\t.\tPASS\t.\tGT\t0|1\t0|0\n\
chr1\t20\tl2\tG\tT\t.\tPASS\t.\tGT\t0|1\t0|0\n\
chr1\t30\tl3\tC\tG\t.\tPASS\t.\tGT\t1|0\t1|1\n"
        ),
    )
    .unwrap();
    fs::write(
        &right_source,
        format!(
            "{header}chr1\t20\tr2\tG\tT\t.\tPASS\t.\tGT\t1|0\t0|0\n\
chr1\t30\tr3\tC\tG\t.\tPASS\t.\tGT\t0|1\t1|1\n\
chr1\t40\tr4\tT\tA\t.\tPASS\t.\tGT\t1|0\t0|0\n"
        ),
    )
    .unwrap();
    index(&left_source, &left);
    index(&right_source, &right);
    let expected = run(Command::new(oracle()).args([
        "concat",
        "--no-version",
        "-Ov",
        "--ligate",
        path(&left),
        path(&right),
    ]));
    let actual = run(ours().args(["concat", "--ligate", path(&left), path(&right)]));
    assert_eq!(canonical(&actual.stdout), canonical(&expected.stdout));
}

#[test]
#[ignore = "release oracle: requires bcftools 1.24"]
fn multi_contig_ligation_fails_instead_of_dropping_records_like_bcftools_1_24() {
    assert_oracle_version();
    let directory = tempfile::tempdir().unwrap();
    let left_source = directory.path().join("multi-left.vcf");
    let right_source = directory.path().join("multi-right.vcf");
    let left = directory.path().join("multi-left.vcf.gz");
    let right = directory.path().join("multi-right.vcf.gz");
    let header = "##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##contig=<ID=chr2,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n";
    fs::write(
        &left_source,
        format!(
            "{header}chr1\t10\tl1a\tA\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t20\tl1b\tG\tT\t.\tPASS\t.\tGT\t0|1\n\
chr2\t10\tl2a\tC\tG\t.\tPASS\t.\tGT\t1|0\n\
chr2\t20\tl2b\tT\tA\t.\tPASS\t.\tGT\t1|0\n"
        ),
    )
    .unwrap();
    fs::write(
        &right_source,
        format!(
            "{header}chr1\t20\tr1b\tG\tT\t.\tPASS\t.\tGT\t1|0\n\
chr1\t30\tr1c\tA\tG\t.\tPASS\t.\tGT\t1|0\n\
chr2\t20\tr2b\tT\tA\t.\tPASS\t.\tGT\t0|1\n\
chr2\t30\tr2c\tG\tA\t.\tPASS\t.\tGT\t0|1\n"
        ),
    )
    .unwrap();
    index(&left_source, &left);
    index(&right_source, &right);

    let expected = run(Command::new(oracle()).args([
        "concat",
        "--no-version",
        "-Ov",
        "--ligate",
        path(&left),
        path(&right),
    ]));
    let expected = records(&expected.stdout);
    assert!(
        expected
            .iter()
            .all(|record| !record.windows(5).any(|value| value == b"l2a\t"))
    );

    let actual = ours()
        .args(["concat", "--ligate", path(&left), path(&right)])
        .output()
        .unwrap();
    assert!(!actual.status.success());
    assert!(
        String::from_utf8_lossy(&actual.stderr).contains("exactly one reference sequence"),
        "{}",
        String::from_utf8_lossy(&actual.stderr)
    );
}

#[test]
#[ignore = "release oracle: requires bcftools 1.24"]
fn imperfect_ligation_policies_match_bcftools_1_24() {
    assert_oracle_version();
    let directory = tempfile::tempdir().unwrap();
    let left_source = directory.path().join("imperfect-left.vcf");
    let right_source = directory.path().join("imperfect-right.vcf");
    let disjoint_source = directory.path().join("disjoint.vcf");
    let unmatched_source = directory.path().join("unmatched.vcf");
    let left = directory.path().join("imperfect-left.vcf.gz");
    let right = directory.path().join("imperfect-right.vcf.gz");
    let disjoint = directory.path().join("disjoint.vcf.gz");
    let unmatched = directory.path().join("unmatched.vcf.gz");
    let header = "##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n";
    fs::write(
        &left_source,
        format!(
            "{header}chr1\t10\tl1\tA\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t20\tl2\tG\tT\t.\tPASS\t.\tGT\t0|1\n\
chr1\t30\tl3\tC\tG\t.\tPASS\t.\tGT\t1|0\n"
        ),
    )
    .unwrap();
    fs::write(
        &right_source,
        format!(
            "{header}chr1\t20\tr2\tG\tT\t.\tPASS\t.\tGT\t1|0\n\
chr1\t25\textra\tA\tG\t.\tPASS\t.\tGT\t0|1\n\
chr1\t30\tr3\tC\tG\t.\tPASS\t.\tGT\t0|1\n\
chr1\t40\tr4\tT\tA\t.\tPASS\t.\tGT\t1|0\n"
        ),
    )
    .unwrap();
    fs::write(
        &disjoint_source,
        format!(
            "{header}chr1\t50\td1\tA\tT\t.\tPASS\t.\tGT\t0|1\n\
chr1\t60\td2\tG\tC\t.\tPASS\t.\tGT\t1|0\n"
        ),
    )
    .unwrap();
    fs::write(
        &unmatched_source,
        format!(
            "{header}chr1\t20\tu2\tG\tA\t.\tPASS\t.\tGT\t1|0\n\
chr1\t25\tu-extra\tA\tG\t.\tPASS\t.\tGT\t0|1\n\
chr1\t30\tu3\tC\tT\t.\tPASS\t.\tGT\t0|1\n\
chr1\t40\tu4\tT\tC\t.\tPASS\t.\tGT\t1|0\n"
        ),
    )
    .unwrap();
    index(&left_source, &left);
    index(&right_source, &right);
    index(&disjoint_source, &disjoint);
    index(&unmatched_source, &unmatched);

    let ours_default = ours()
        .args(["concat", "--ligate", path(&left), path(&right)])
        .output()
        .unwrap();
    let oracle_default = Command::new(oracle())
        .args([
            "concat",
            "--no-version",
            "-Ov",
            "--ligate",
            path(&left),
            path(&right),
        ])
        .output()
        .unwrap();
    assert!(!ours_default.status.success());
    assert!(!oracle_default.status.success());

    for policy in ["--ligate-warn", "--ligate-force"] {
        let actual = run(ours().args(["concat", "--ligate", policy, path(&left), path(&right)]));
        let expected = run(Command::new(oracle()).args([
            "concat",
            "--no-version",
            "-Ov",
            "--ligate",
            policy,
            path(&left),
            path(&right),
        ]));
        assert_eq!(
            canonical(&actual.stdout),
            canonical(&expected.stdout),
            "{policy}"
        );
    }

    let actual = run(ours().args([
        "concat",
        "--ligate",
        "--ligate-force",
        path(&left),
        path(&disjoint),
    ]));
    let expected = run(Command::new(oracle()).args([
        "concat",
        "--no-version",
        "-Ov",
        "--ligate",
        "--ligate-force",
        path(&left),
        path(&disjoint),
    ]));
    assert_eq!(canonical(&actual.stdout), canonical(&expected.stdout));

    let ours_default = ours()
        .args(["concat", "--ligate", path(&left), path(&unmatched)])
        .output()
        .unwrap();
    let oracle_default = Command::new(oracle())
        .args([
            "concat",
            "--no-version",
            "-Ov",
            "--ligate",
            path(&left),
            path(&unmatched),
        ])
        .output()
        .unwrap();
    assert!(!ours_default.status.success());
    assert!(!oracle_default.status.success());

    let actual_warn = run(ours().args([
        "concat",
        "--ligate",
        "--ligate-warn",
        path(&left),
        path(&unmatched),
    ]));
    let expected_warn = run(Command::new(oracle()).args([
        "concat",
        "--no-version",
        "-Ov",
        "--ligate",
        "--ligate-warn",
        path(&left),
        path(&unmatched),
    ]));
    assert!(records(&actual_warn.stdout).iter().all(|record| {
        !record
            .windows(b"\tu3\t".len())
            .any(|value| value == b"\tu3\t")
    }));
    assert!(records(&expected_warn.stdout).iter().any(|record| {
        record
            .windows(b"\tu3\t".len())
            .any(|value| value == b"\tu3\t")
    }));

    let actual_force = run(ours().args([
        "concat",
        "--ligate",
        "--ligate-force",
        path(&left),
        path(&unmatched),
    ]));
    let expected_force = run(Command::new(oracle()).args([
        "concat",
        "--no-version",
        "-Ov",
        "--ligate",
        "--ligate-force",
        path(&left),
        path(&unmatched),
    ]));
    assert_eq!(
        canonical(&actual_force.stdout),
        canonical(&expected_force.stdout)
    );
}

#[test]
#[ignore = "release oracle: requires bcftools 1.24"]
fn encoding_matrix_and_naive_bcf_match_bcftools_1_24() {
    assert_oracle_version();
    let directory = tempfile::tempdir().unwrap();
    let left_source = directory.path().join("left.vcf");
    let right_source = directory.path().join("right.vcf");
    let header = "##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Depth\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\n";
    fs::write(
        &left_source,
        format!("{header}chr1\t10\ta\tA\tC\t.\tPASS\tDP=2\n"),
    )
    .unwrap();
    fs::write(
        &right_source,
        format!("{header}chr1\t20\tb\tG\tT\t.\tPASS\tDP=3\n"),
    )
    .unwrap();

    let mut encoded = Vec::new();
    for (name, flag) in [("v", "-Ov"), ("z", "-Oz"), ("b", "-Ob"), ("u", "-Ou")] {
        let left = directory.path().join(format!("left.{name}"));
        let right = directory.path().join(format!("right.{name}"));
        run(Command::new(oracle()).args([
            "view",
            "--no-version",
            flag,
            "-o",
            path(&left),
            path(&left_source),
        ]));
        run(Command::new(oracle()).args([
            "view",
            "--no-version",
            flag,
            "-o",
            path(&right),
            path(&right_source),
        ]));
        encoded.push((name, left, right));
    }

    for (case, output) in encoded.iter().zip(["v", "z", "b", "u"]) {
        let (input, left, right) = case;
        let actual = directory.path().join(format!("actual-{input}-{output}"));
        let expected = directory.path().join(format!("expected-{input}-{output}"));
        run(ours().args([
            "concat",
            "-O",
            output,
            "-o",
            path(&actual),
            path(left),
            path(right),
        ]));
        run(Command::new(oracle()).args([
            "concat",
            "--no-version",
            &format!("-O{output}"),
            "-o",
            path(&expected),
            path(left),
            path(right),
        ]));
        let actual =
            run(Command::new(oracle()).args(["view", "--no-version", "-Ov", path(&actual)]));
        let expected =
            run(Command::new(oracle()).args(["view", "--no-version", "-Ov", path(&expected)]));
        assert_eq!(canonical(&actual.stdout), canonical(&expected.stdout));
    }

    let (_, left, right) = encoded.iter().find(|(name, _, _)| *name == "b").unwrap();
    let actual = run(ours().args(["concat", "--naive", path(left), path(right)]));
    let expected = run(Command::new(oracle()).args([
        "concat",
        "--no-version",
        "--naive",
        path(left),
        path(right),
    ]));
    let actual_path = directory.path().join("actual-naive.bcf");
    let expected_path = directory.path().join("expected-naive.bcf");
    fs::write(&actual_path, actual.stdout).unwrap();
    fs::write(&expected_path, expected.stdout).unwrap();
    let actual =
        run(Command::new(oracle()).args(["view", "--no-version", "-Ov", path(&actual_path)]));
    let expected =
        run(Command::new(oracle()).args(["view", "--no-version", "-Ov", path(&expected_path)]));
    assert_eq!(canonical(&actual.stdout), canonical(&expected.stdout));
}
