use std::io::{self, Write};
use std::path::{Path, PathBuf};

use clap::{Args, ValueEnum};
use rsomics_common::{AtomicFile, Result, RsomicsError, reject_output_alias};

use crate::cli::CommandOutput;
use crate::commands::variant::{OutputType, Overlap, read_regions};
use crate::concat::{self, DuplicatePolicy, LigateOptions, Mode, Options};

#[derive(Clone, Copy, Debug, ValueEnum)]
enum DuplicateMode {
    Snps,
    Indels,
    Both,
    All,
    Exact,
}

impl From<DuplicateMode> for DuplicatePolicy {
    fn from(value: DuplicateMode) -> Self {
        match value {
            DuplicateMode::Snps => Self::Snps,
            DuplicateMode::Indels => Self::Indels,
            DuplicateMode::Both => Self::Both,
            DuplicateMode::All => Self::All,
            DuplicateMode::Exact => Self::Exact,
        }
    }
}

#[derive(Debug, Args)]
#[command(after_help = "\
Output types:
  v  uncompressed VCF
  z  BGZF-compressed VCF
  b  BGZF-compressed BCF
  u  uncompressed BCF

Examples:
  rsomics-vcf concat chr1.vcf.gz chr2.vcf.gz -O z -o genome.vcf.gz
  rsomics-vcf concat -a -d exact cohort-a.bcf cohort-b.bcf -O b -o cohort.bcf")]
pub(crate) struct Arguments {
    /// Input VCF or BCF chunks in output order
    #[arg(
        value_name = "VARIANT",
        num_args = 1..,
        required_unless_present = "file_list",
        conflicts_with = "file_list"
    )]
    inputs: Vec<PathBuf>,

    /// Read one input path per line from FILE
    #[arg(short = 'f', long, value_name = "FILE")]
    file_list: Option<PathBuf>,

    /// Merge overlapping coordinate ranges
    #[arg(short = 'a', long)]
    allow_overlaps: bool,

    /// Remove cross-input duplicates: snps, indels, both, all, or exact
    #[arg(short = 'd', long, value_name = "MODE", requires = "allow_overlaps")]
    rm_dups: Option<DuplicateMode>,

    /// Remove exact cross-input duplicates
    #[arg(
        short = 'D',
        long,
        requires = "allow_overlaps",
        conflicts_with = "rm_dups"
    )]
    remove_duplicates: bool,

    /// Remove FORMAT definitions, values, and sample columns
    #[arg(short = 'G', long, conflicts_with = "ligate")]
    drop_genotypes: bool,

    /// Reconcile phased diploid haplotypes across chunk overlaps
    #[arg(short = 'l', long, conflicts_with_all = ["allow_overlaps", "naive"])]
    ligate: bool,

    /// Emit FORMAT/PS only at phase-set starts
    #[arg(short = 'c', long = "compact-PS", requires = "ligate")]
    compact_ps: bool,

    /// Keep unpaired sites and permit nonoverlapping ligation chunks
    #[arg(long, requires = "ligate", conflicts_with = "ligate_warn")]
    ligate_force: bool,

    /// Drop unpaired overlap sites and report them
    #[arg(long, requires = "ligate", conflicts_with = "ligate_force")]
    ligate_warn: bool,

    /// Minimum phase-orientation quality
    #[arg(
        short = 'q',
        long = "min-PQ",
        value_name = "INT",
        default_value_t = 30,
        requires = "ligate"
    )]
    min_pq: u32,

    /// Indexed genomic regions, separated by commas
    #[arg(
        short = 'r',
        long,
        value_name = "REGIONS",
        requires = "allow_overlaps",
        conflicts_with = "regions_file"
    )]
    regions: Option<String>,

    /// File containing one indexed genomic region per line
    #[arg(short = 'R', long, value_name = "FILE", requires = "allow_overlaps")]
    regions_file: Option<PathBuf>,

    /// Indexed-region overlap rule
    #[arg(
        long,
        value_name = "MODE",
        default_value = "record",
        requires = "allow_overlaps"
    )]
    regions_overlap: Overlap,

    /// Splice compatible BGZF streams without recompression
    #[arg(
        short = 'n',
        long,
        conflicts_with_all = ["allow_overlaps", "ligate", "drop_genotypes", "regions", "regions_file", "threads"]
    )]
    naive: bool,

    /// Write variants to FILE instead of standard output
    #[arg(
        short = 'o',
        long,
        value_name = "FILE",
        default_value = "-",
        hide_default_value = true
    )]
    output: PathBuf,

    /// Output encoding: v, z, b, or u
    #[arg(short = 'O', long, value_name = "TYPE")]
    output_type: Option<OutputType>,

    /// Use INT BGZF compression workers; 0 selects serial output
    #[arg(long, value_name = "INT", default_value_t = 0)]
    threads: usize,
}

pub(crate) fn execute(arguments: Arguments, json: bool) -> Result<CommandOutput> {
    let inputs = read_inputs(arguments.inputs, arguments.file_list.as_deref())?;
    if json && arguments.output == Path::new("-") {
        return Err(RsomicsError::ConfigError(
            "--json requires --output because variant data otherwise uses standard output"
                .to_owned(),
        ));
    }
    if inputs
        .iter()
        .filter(|path| path == &&PathBuf::from("-"))
        .count()
        > 1
    {
        return Err(RsomicsError::ConfigError(
            "standard input may appear only once".to_owned(),
        ));
    }
    if arguments.naive && arguments.output_type.is_some() {
        return Err(RsomicsError::ConfigError(
            "--naive preserves the input encoding and does not accept --output-type".to_owned(),
        ));
    }
    let output_type = arguments.output_type.unwrap_or(OutputType::V);
    if arguments.threads > 0 && !matches!(output_type, OutputType::Z | OutputType::B) {
        return Err(RsomicsError::ConfigError(
            "--threads requires BGZF VCF or BCF output".to_owned(),
        ));
    }
    let mut aliases: Vec<&Path> = inputs.iter().map(PathBuf::as_path).collect();
    aliases.extend(arguments.file_list.as_deref());
    aliases.extend(arguments.regions_file.as_deref());
    reject_output_alias(&arguments.output, aliases)?;

    if arguments.ligate && inputs.iter().any(|path| path == Path::new("-")) {
        return Err(RsomicsError::ConfigError(
            "ligation requires named indexed inputs".to_owned(),
        ));
    }
    if arguments.allow_overlaps && inputs.iter().any(|path| path == Path::new("-")) {
        return Err(RsomicsError::ConfigError(
            "overlap concat requires named inputs".to_owned(),
        ));
    }
    let regions = read_regions(
        arguments.regions,
        arguments.regions_file.as_deref(),
        arguments.regions_overlap.into(),
    )?;
    let duplicate_policy = arguments.rm_dups.map(Into::into).or(arguments
        .remove_duplicates
        .then_some(DuplicatePolicy::Exact));
    if arguments.naive {
        let summary = if arguments.output == Path::new("-") {
            concat::write_naive(&inputs, io::stdout().lock())?
        } else {
            let mut transaction = AtomicFile::new(&arguments.output)?;
            let summary = concat::write_naive(&inputs, transaction.file_mut())?;
            transaction.commit()?;
            summary
        };
        return Ok(CommandOutput::Concat { summary });
    }
    let options = Options {
        drop_genotypes: arguments.drop_genotypes,
        output_format: output_type.into(),
        regions,
        mode: if arguments.ligate {
            Mode::Ligate(LigateOptions {
                compact_ps: arguments.compact_ps,
                force: arguments.ligate_force,
                warn: arguments.ligate_warn,
                min_pq: arguments.min_pq,
            })
        } else if arguments.allow_overlaps {
            Mode::Overlap { duplicate_policy }
        } else {
            Mode::Ordered
        },
    };
    let summary = if arguments.output == Path::new("-") {
        let summary = if arguments.threads == 0 {
            concat::write(&inputs, &options, io::stdout().lock())?
        } else {
            concat::write_parallel(&inputs, &options, io::stdout(), arguments.threads)?
        };
        report_ligate_warning(&summary, arguments.ligate_warn, json)?;
        summary
    } else {
        let mut transaction = AtomicFile::new(&arguments.output)?;
        let summary = if arguments.threads == 0 {
            concat::write(&inputs, &options, transaction.file_mut())?
        } else {
            concat::write_parallel(&inputs, &options, transaction.reopen()?, arguments.threads)?
        };
        report_ligate_warning(&summary, arguments.ligate_warn, json)?;
        transaction.commit()?;
        summary
    };
    Ok(CommandOutput::Concat { summary })
}

fn report_ligate_warning(summary: &concat::Summary, enabled: bool, json: bool) -> Result<()> {
    let dropped = summary.overlap_records_dropped();
    if enabled && !json && dropped > 0 {
        writeln!(
            io::stderr().lock(),
            "warning: dropped {dropped} unpaired overlap record{} during ligation",
            if dropped == 1 { "" } else { "s" }
        )
        .map_err(RsomicsError::Io)?;
    }
    Ok(())
}

fn read_inputs(positional: Vec<PathBuf>, list: Option<&Path>) -> Result<Vec<PathBuf>> {
    if let Some(list) = list {
        let content = std::fs::read_to_string(list).map_err(|error| {
            RsomicsError::Io(std::io::Error::new(
                error.kind(),
                format!("reading concat file list {}: {error}", list.display()),
            ))
        })?;
        let paths: Vec<_> = content
            .lines()
            .map(str::trim)
            .filter(|line| !line.is_empty() && !line.starts_with('#'))
            .map(PathBuf::from)
            .collect();
        if paths.is_empty() {
            return Err(RsomicsError::InvalidInput(format!(
                "concat file list is empty: {}",
                list.display()
            )));
        }
        Ok(paths)
    } else {
        Ok(positional)
    }
}
