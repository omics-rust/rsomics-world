use std::io::{self, Cursor, Read, Write};

pub(crate) const EOF_BLOCK: [u8; 28] = [
    0x1f, 0x8b, 0x08, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0xff, 0x06, 0x00, 0x42, 0x43, 0x02, 0x00,
    0x1b, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
];

#[derive(Debug, Eq, PartialEq)]
pub(crate) enum Frame {
    Data(Vec<u8>),
    Eof,
}

pub(crate) struct FrameReader<R> {
    inner: R,
    finished: bool,
}

impl<R> FrameReader<R> {
    pub(crate) fn new(inner: R) -> Self {
        Self {
            inner,
            finished: false,
        }
    }

    pub(crate) fn into_inner(self) -> R {
        self.inner
    }
}

impl<R: Read> FrameReader<R> {
    pub(crate) fn next(&mut self) -> io::Result<Option<Frame>> {
        if self.finished {
            return Ok(None);
        }

        let mut header = [0; 12];
        let Some(first) = read_byte(&mut self.inner)? else {
            return Ok(None);
        };
        header[0] = first;
        read_complete(&mut self.inner, &mut header[1..], "partial BGZF header")?;
        validate_fixed_header(&header)?;
        let extra_length = usize::from(u16::from_le_bytes([header[10], header[11]]));
        let mut extra = vec![0; extra_length];
        read_complete(&mut self.inner, &mut extra, "partial BGZF extra field")?;
        let length = block_size(&extra)?;
        let prefix = header.len() + extra.len();
        if length < prefix + 8 || length > 65_536 {
            return Err(invalid(format!("invalid BGZF block size: {length}")));
        }
        let mut raw = Vec::with_capacity(length);
        raw.extend_from_slice(&header);
        raw.extend_from_slice(&extra);
        raw.resize(length, 0);
        read_complete(&mut self.inner, &mut raw[prefix..], "partial BGZF payload")?;

        if raw == EOF_BLOCK {
            if read_byte(&mut self.inner)?.is_some() {
                return Err(invalid("bytes follow the canonical BGZF EOF block"));
            }
            self.finished = true;
            Ok(Some(Frame::Eof))
        } else {
            Ok(Some(Frame::Data(raw)))
        }
    }

    pub(crate) fn copy_through_eof<W: Write>(&mut self, mut output: W) -> io::Result<u64> {
        let mut copied = 0u64;
        loop {
            let raw = match self.next()? {
                Some(Frame::Data(raw)) => raw,
                Some(Frame::Eof) => EOF_BLOCK.to_vec(),
                None => return Err(invalid("canonical BGZF EOF block is missing")),
            };
            output.write_all(&raw)?;
            copied = copied
                .checked_add(raw.len() as u64)
                .ok_or_else(|| invalid("copied BGZF length exceeds u64"))?;
            if raw == EOF_BLOCK {
                return Ok(copied);
            }
        }
    }
}

pub(crate) fn inflate_frame(raw: &[u8]) -> io::Result<Vec<u8>> {
    let mut decoder = flate2::bufread::GzDecoder::new(raw);
    let mut inflated = Vec::new();
    decoder
        .by_ref()
        .take(65_537)
        .read_to_end(&mut inflated)
        .map_err(|error| invalid(format!("invalid BGZF member: {error}")))?;
    if inflated.len() > 65_536 {
        return Err(invalid("inflated BGZF block exceeds 65536 bytes"));
    }
    if !decoder.into_inner().is_empty() {
        return Err(invalid("bytes follow the gzip member within a BGZF block"));
    }
    Ok(inflated)
}

pub(crate) struct DecodedReader<R> {
    frames: FrameReader<R>,
    current: Cursor<Vec<u8>>,
    complete: bool,
}

impl<R> DecodedReader<R> {
    pub(crate) fn new(inner: R) -> Self {
        Self {
            frames: FrameReader::new(inner),
            current: Cursor::new(Vec::new()),
            complete: false,
        }
    }
}

impl<R: Read> Read for DecodedReader<R> {
    fn read(&mut self, buffer: &mut [u8]) -> io::Result<usize> {
        if buffer.is_empty() {
            return Ok(0);
        }
        loop {
            let read = self.current.read(buffer)?;
            if read != 0 {
                return Ok(read);
            }
            if self.complete {
                return Ok(0);
            }
            let raw = match self.frames.next()? {
                Some(Frame::Data(raw)) => raw,
                Some(Frame::Eof) => {
                    self.complete = true;
                    return Ok(0);
                }
                None => return Err(invalid("canonical BGZF EOF block is missing")),
            };
            self.current = Cursor::new(inflate_frame(&raw)?);
        }
    }
}

fn validate_fixed_header(header: &[u8; 12]) -> io::Result<()> {
    if header[..4] != [0x1f, 0x8b, 0x08, 0x04] {
        return Err(invalid("invalid BGZF gzip header"));
    }
    if header[3] != 0x04 {
        return Err(invalid("invalid BGZF gzip flags"));
    }
    Ok(())
}

fn block_size(extra: &[u8]) -> io::Result<usize> {
    let mut offset = 0;
    let mut size = None;
    while offset < extra.len() {
        if extra.len() - offset < 4 {
            return Err(invalid("partial BGZF extra subfield header"));
        }
        let length = usize::from(u16::from_le_bytes([extra[offset + 2], extra[offset + 3]]));
        let end = offset
            .checked_add(4 + length)
            .ok_or_else(|| invalid("BGZF extra subfield length overflow"))?;
        if end > extra.len() {
            return Err(invalid("partial BGZF extra subfield payload"));
        }
        if extra[offset..offset + 2] == *b"BC" {
            if length != 2 || size.is_some() {
                return Err(invalid("invalid or duplicate BGZF BC subfield"));
            }
            size =
                Some(usize::from(u16::from_le_bytes([extra[offset + 4], extra[offset + 5]])) + 1);
        }
        offset = end;
    }
    size.ok_or_else(|| invalid("BGZF BC subfield is missing"))
}

fn read_byte(reader: &mut impl Read) -> io::Result<Option<u8>> {
    let mut byte = [0];
    loop {
        match reader.read(&mut byte) {
            Ok(0) => return Ok(None),
            Ok(_) => return Ok(Some(byte[0])),
            Err(error) if error.kind() == io::ErrorKind::Interrupted => {}
            Err(error) => return Err(error),
        }
    }
}

fn read_complete(reader: &mut impl Read, buffer: &mut [u8], message: &str) -> io::Result<()> {
    let mut offset = 0;
    while offset < buffer.len() {
        match reader.read(&mut buffer[offset..]) {
            Ok(0) => return Err(invalid(message)),
            Ok(length) => offset += length,
            Err(error) if error.kind() == io::ErrorKind::Interrupted => {}
            Err(error) => return Err(error),
        }
    }
    Ok(())
}

fn invalid(message: impl Into<String>) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, message.into())
}

#[cfg(test)]
mod tests {
    use std::io::{self, Read, Write};

    use super::{DecodedReader, EOF_BLOCK, Frame, FrameReader, inflate_frame};

    fn bgzf_fixture(source: &[u8]) -> Vec<u8> {
        let mut writer = noodles_bgzf::io::Writer::new(Vec::new());
        writer.write_all(source).unwrap();
        writer.finish().unwrap()
    }

    #[test]
    fn copies_complete_frames_through_one_canonical_eof() {
        let input = bgzf_fixture(b"body");
        let mut output = Vec::new();
        let copied = FrameReader::new(input.as_slice())
            .copy_through_eof(&mut output)
            .unwrap();
        assert_eq!(copied, input.len() as u64);
        assert_eq!(output, input);
    }

    #[test]
    fn exposes_data_and_eof_frames_in_order() {
        let input = bgzf_fixture(b"body");
        let mut reader = FrameReader::new(input.as_slice());
        assert!(matches!(reader.next().unwrap(), Some(Frame::Data(_))));
        assert!(matches!(reader.next().unwrap(), Some(Frame::Eof)));
        assert!(reader.next().unwrap().is_none());
    }

    #[test]
    fn rejects_bytes_or_a_second_frame_after_eof() {
        for suffix in [b"trailing".as_slice(), EOF_BLOCK.as_slice()] {
            let mut input = bgzf_fixture(b"body");
            input.extend_from_slice(suffix);
            assert_eq!(
                FrameReader::new(input.as_slice())
                    .copy_through_eof(io::sink())
                    .unwrap_err()
                    .kind(),
                io::ErrorKind::InvalidData
            );
        }
    }

    #[test]
    fn rejects_partial_headers_and_payloads() {
        let input = bgzf_fixture(b"body");
        for end in [1, 17, input.len() - EOF_BLOCK.len() - 1] {
            assert_eq!(
                FrameReader::new(&input[..end])
                    .copy_through_eof(io::sink())
                    .unwrap_err()
                    .kind(),
                io::ErrorKind::InvalidData,
                "end={end}"
            );
        }
    }

    #[test]
    fn rejects_invalid_frame_headers_and_sizes() {
        let input = bgzf_fixture(b"body");
        for (index, value) in [
            (0, 0),
            (3, 0),
            (3, 0x05),
            (3, 0x0c),
            (10, 0),
            (12, b'X'),
            (14, 0),
        ] {
            let mut invalid = input.clone();
            invalid[index] = value;
            assert_eq!(
                FrameReader::new(invalid.as_slice())
                    .copy_through_eof(io::sink())
                    .unwrap_err()
                    .kind(),
                io::ErrorKind::InvalidData,
                "index={index}"
            );
        }

        let mut invalid = input;
        invalid[16..18].copy_from_slice(&0u16.to_le_bytes());
        assert_eq!(
            FrameReader::new(invalid.as_slice())
                .copy_through_eof(io::sink())
                .unwrap_err()
                .kind(),
            io::ErrorKind::InvalidData
        );
    }

    #[test]
    fn rejects_a_stream_without_the_canonical_eof() {
        let mut input = bgzf_fixture(b"body");
        input.truncate(input.len() - EOF_BLOCK.len());
        assert_eq!(
            FrameReader::new(input.as_slice())
                .copy_through_eof(io::sink())
                .unwrap_err()
                .kind(),
            io::ErrorKind::InvalidData
        );
    }

    #[test]
    fn accepts_a_noncanonical_empty_data_frame_before_eof() {
        let mut empty = EOF_BLOCK;
        empty[4] = 1;
        let mut input = empty.to_vec();
        input.extend_from_slice(&EOF_BLOCK);
        let mut reader = FrameReader::new(input.as_slice());
        assert!(matches!(reader.next().unwrap(), Some(Frame::Data(frame)) if frame == empty));
        assert!(matches!(reader.next().unwrap(), Some(Frame::Eof)));
    }

    #[test]
    fn accepts_arbitrary_extra_subfields_around_bc() {
        let input = bgzf_fixture(b"body");
        let mut frames = FrameReader::new(input.as_slice());
        let Some(Frame::Data(mut raw)) = frames.next().unwrap() else {
            panic!("missing data frame");
        };
        raw.splice(12..12, [b'X', b'Y', 1, 0, 7]);
        raw[10..12].copy_from_slice(&11u16.to_le_bytes());
        let size = u16::try_from(raw.len() - 1).unwrap();
        raw[21..23].copy_from_slice(&size.to_le_bytes());
        raw.extend_from_slice(&EOF_BLOCK);

        let mut reader = FrameReader::new(raw.as_slice());
        assert!(matches!(reader.next().unwrap(), Some(Frame::Data(_))));
        assert!(matches!(reader.next().unwrap(), Some(Frame::Eof)));
    }

    fn gzip_frame(source: &[u8]) -> Vec<u8> {
        let mut writer = flate2::GzBuilder::new()
            .extra(vec![b'B', b'C', 2, 0, 0, 0])
            .write(Vec::new(), flate2::Compression::default());
        writer.write_all(source).unwrap();
        let mut raw = writer.finish().unwrap();
        set_block_size(&mut raw);
        raw
    }

    fn set_block_size(raw: &mut [u8]) {
        let size = u16::try_from(raw.len() - 1).unwrap();
        raw[16..18].copy_from_slice(&size.to_le_bytes());
    }

    #[test]
    fn inflation_accepts_the_bgzf_uncompressed_size_boundary() {
        for length in [0, 65_536] {
            let source = vec![b'A'; length];
            assert_eq!(inflate_frame(&gzip_frame(&source)).unwrap(), source);
        }
    }

    #[test]
    fn inflation_rejects_oversized_blocks_even_with_a_forged_isize() {
        let raw = gzip_frame(&vec![b'A'; 65_537]);
        for forged in [false, true] {
            let mut raw = raw.clone();
            if forged {
                let end = raw.len();
                raw[end - 4..].copy_from_slice(&65_536u32.to_le_bytes());
            }
            let error = inflate_frame(&raw).unwrap_err();
            assert_eq!(error.kind(), io::ErrorKind::InvalidData);
            assert!(error.to_string().contains("exceeds 65536 bytes"));
        }
    }

    #[test]
    fn inflation_checks_crc_and_isize() {
        let original = gzip_frame(b"body");
        for offset in [8, 4] {
            let mut raw = original.clone();
            let index = raw.len() - offset;
            raw[index] ^= 1;
            assert_eq!(
                inflate_frame(&raw).unwrap_err().kind(),
                io::ErrorKind::InvalidData
            );
        }
    }

    #[test]
    fn inflation_rejects_bytes_outside_the_single_gzip_member() {
        for suffix in [b"trailing".to_vec(), gzip_frame(b"second")] {
            let mut raw = gzip_frame(b"body");
            raw.extend_from_slice(&suffix);
            set_block_size(&mut raw);
            let error = inflate_frame(&raw).unwrap_err();
            assert_eq!(error.kind(), io::ErrorKind::InvalidData);
            assert!(error.to_string().contains("within a BGZF block"));
        }
    }

    #[test]
    fn decoded_reader_skips_empty_frames_and_retains_frame_boundaries() {
        let mut empty = EOF_BLOCK;
        empty[4] = 1;
        let input = [
            empty.to_vec(),
            gzip_frame(b"first"),
            empty.to_vec(),
            gzip_frame(b"second"),
            EOF_BLOCK.to_vec(),
        ]
        .concat();
        let mut reader = DecodedReader::new(input.as_slice());
        assert_eq!(reader.read(&mut []).unwrap(), 0);
        let mut actual = Vec::new();
        let mut buffer = [0; 3];
        loop {
            let read = reader.read(&mut buffer).unwrap();
            if read == 0 {
                break;
            }
            actual.extend_from_slice(&buffer[..read]);
        }
        assert_eq!(actual, b"firstsecond");
        assert_eq!(reader.read(&mut buffer).unwrap(), 0);
    }

    #[test]
    fn decoded_reader_requires_one_terminal_canonical_eof() {
        let data = gzip_frame(b"body");
        for suffix in [
            Vec::new(),
            [EOF_BLOCK.as_slice(), b"trailing"].concat(),
            [EOF_BLOCK.as_slice(), EOF_BLOCK.as_slice()].concat(),
        ] {
            let input = [data.clone(), suffix].concat();
            assert_eq!(
                DecodedReader::new(input.as_slice())
                    .read_to_end(&mut Vec::new())
                    .unwrap_err()
                    .kind(),
                io::ErrorKind::InvalidData
            );
        }
    }
}
