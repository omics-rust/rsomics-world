#![deny(unsafe_code)]

#[allow(dead_code)]
mod annotate;
pub mod head;
pub mod index;
pub mod query;
pub mod validate;
pub mod view;

mod cli;
mod commands;
mod concat;
mod expression;
mod filter;
mod format;
mod genotype;
mod norm;
mod query_bcf;
mod query_format;
mod regions;
mod reheader;
mod setgt;
mod validation;
mod variant_type;

#[must_use]
pub fn run_binary() -> std::process::ExitCode {
    cli::run()
}
