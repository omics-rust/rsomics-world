use std::fs::File;
use std::io::{Cursor, Read, Write};
use std::path::{Path, PathBuf};

use noodles_bgzf as bgzf;
use noodles_vcf::Header;
use rsomics_common::{Context, Result, RsomicsError};

use super::Summary;
use crate::format::bgzf::{EOF_BLOCK, Frame, FrameReader};
use crate::format::{OutputFormat, Reader, RecordScratch};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum Encoding {
    Vcf,
    Bcf,
}

struct Inspected {
    path: PathBuf,
    encoding: Encoding,
    header: Header,
    records: u64,
}

pub(super) fn write(inputs: &[PathBuf], mut output: impl Write) -> Result<Summary> {
    if inputs.is_empty() {
        return Err(RsomicsError::ConfigError(
            "concat requires at least one input".to_owned(),
        ));
    }
    if inputs.iter().any(|path| path == Path::new("-")) {
        return Err(RsomicsError::ConfigError(
            "--naive requires named BGZF inputs".to_owned(),
        ));
    }
    let inspected = inputs
        .iter()
        .map(|path| inspect(path))
        .collect::<Result<Vec<_>>>()?;
    let first = &inspected[0];
    for input in &inspected[1..] {
        if input.encoding != first.encoding {
            return Err(RsomicsError::InvalidInput(format!(
                "naive concat cannot mix BGZF VCF and BCF: {}",
                input.path.display()
            )));
        }
        if input.header != first.header {
            return Err(RsomicsError::InvalidInput(format!(
                "naive concat header differs from the first input: {}",
                input.path.display()
            )));
        }
        if input.encoding == Encoding::Bcf
            && input.header.string_maps() != first.header.string_maps()
        {
            return Err(RsomicsError::InvalidInput(format!(
                "naive concat BCF dictionary differs from the first input: {}",
                input.path.display()
            )));
        }
    }

    copy_first(&inspected[0].path, &mut output)?;
    for input in &inspected[1..] {
        copy_without_header(&input.path, input.encoding, &mut output)?;
    }
    output.write_all(&EOF_BLOCK).map_err(RsomicsError::Io)?;
    output.flush().map_err(RsomicsError::Io)?;
    let records = inspected.iter().try_fold(0u64, |total, input| {
        total.checked_add(input.records).ok_or_else(|| {
            RsomicsError::InvalidInput("variant record count exceeds u64".to_owned())
        })
    })?;
    Ok(Summary {
        inputs: inspected.len() as u64,
        records_read: records,
        records_written: records,
        duplicates_removed: 0,
        overlap_records_dropped: 0,
        samples_dropped: 0,
        phase_orientations_changed: 0,
        output_format: match first.encoding {
            Encoding::Vcf => OutputFormat::VcfBgzf,
            Encoding::Bcf => OutputFormat::Bcf,
        },
        raw_bgzf: true,
    })
}

fn inspect(path: &Path) -> Result<Inspected> {
    let encoding = inspect_frames(path)?;
    let mut reader = Reader::open(path)?;
    let (header, _, _) = reader.read_header()?;
    let mut scratch = RecordScratch::default();
    let mut records = 0u64;
    loop {
        let number = records.checked_add(1).ok_or_else(|| {
            RsomicsError::InvalidInput("variant record count exceeds u64".to_owned())
        })?;
        if reader.read_record(&header, &mut scratch, number)?.is_none() {
            break;
        }
        records = number;
    }
    Ok(Inspected {
        path: path.to_path_buf(),
        encoding,
        header,
        records,
    })
}

fn inspect_frames(path: &Path) -> Result<Encoding> {
    let file = File::open(path)
        .rs_with_context(|| format!("opening naive concat input {}", path.display()))?;
    let mut frames = FrameReader::new(file);
    let mut encoding = None;
    let mut prefix = Vec::new();
    loop {
        match frames.next().map_err(|error| frame_error(path, error))? {
            Some(Frame::Data(raw)) => {
                let inflated = inflate(&raw, path)?;
                if encoding.is_none() && !inflated.is_empty() {
                    prefix.extend_from_slice(&inflated);
                    encoding = detect_encoding(&prefix, path)?;
                }
            }
            Some(Frame::Eof) => break,
            None => {
                return Err(RsomicsError::InvalidInput(format!(
                    "canonical BGZF EOF block is missing: {}",
                    path.display()
                )));
            }
        }
    }
    encoding.ok_or_else(|| {
        RsomicsError::InvalidInput(format!(
            "BGZF input contains no variant data: {}",
            path.display()
        ))
    })
}

fn detect_encoding(prefix: &[u8], path: &Path) -> Result<Option<Encoding>> {
    const BCF_MAGIC: &[u8] = b"BCF\x02\x02";
    const VCF_MAGIC: &[u8] = b"##fileformat=VCF";

    if prefix.starts_with(BCF_MAGIC) {
        Ok(Some(Encoding::Bcf))
    } else if prefix.starts_with(VCF_MAGIC) {
        Ok(Some(Encoding::Vcf))
    } else if BCF_MAGIC.starts_with(prefix) || VCF_MAGIC.starts_with(prefix) {
        Ok(None)
    } else {
        Err(RsomicsError::InvalidInput(format!(
            "BGZF stream is not VCF or BCF: {}",
            path.display()
        )))
    }
}

fn copy_first(path: &Path, output: &mut impl Write) -> Result<()> {
    let file = File::open(path)
        .rs_with_context(|| format!("opening naive concat input {}", path.display()))?;
    let mut frames = FrameReader::new(file);
    loop {
        match frames.next().map_err(|error| frame_error(path, error))? {
            Some(Frame::Data(raw)) => output.write_all(&raw).map_err(RsomicsError::Io)?,
            Some(Frame::Eof) => return Ok(()),
            None => {
                return Err(RsomicsError::InvalidInput(format!(
                    "canonical BGZF EOF block is missing: {}",
                    path.display()
                )));
            }
        }
    }
}

fn copy_without_header(path: &Path, encoding: Encoding, output: &mut impl Write) -> Result<()> {
    let file = File::open(path)
        .rs_with_context(|| format!("opening naive concat input {}", path.display()))?;
    let mut frames = FrameReader::new(file);
    let mut prefix = Vec::new();
    let mut header_complete = false;
    loop {
        match frames.next().map_err(|error| frame_error(path, error))? {
            Some(Frame::Data(raw)) if !header_complete => {
                let inflated = inflate(&raw, path)?;
                let previous = prefix.len();
                prefix.extend_from_slice(&inflated);
                if let Some(end) = header_end(&prefix, encoding)? {
                    header_complete = true;
                    let in_frame = end.saturating_sub(previous).min(inflated.len());
                    write_recompressed(&inflated[in_frame..], output)?;
                }
            }
            Some(Frame::Data(raw)) => output.write_all(&raw).map_err(RsomicsError::Io)?,
            Some(Frame::Eof) if header_complete => return Ok(()),
            Some(Frame::Eof) => {
                return Err(RsomicsError::InvalidInput(format!(
                    "variant header is incomplete: {}",
                    path.display()
                )));
            }
            None => {
                return Err(RsomicsError::InvalidInput(format!(
                    "canonical BGZF EOF block is missing: {}",
                    path.display()
                )));
            }
        }
    }
}

fn header_end(source: &[u8], encoding: Encoding) -> Result<Option<usize>> {
    match encoding {
        Encoding::Vcf => {
            let mut offset = 0;
            for line in source.split_inclusive(|byte| *byte == b'\n') {
                if line.last() != Some(&b'\n') {
                    break;
                }
                offset += line.len();
                if line.starts_with(b"#CHROM\t") || line == b"#CHROM\n" {
                    return Ok(Some(offset));
                }
                if !line.starts_with(b"##") {
                    return Err(RsomicsError::InvalidInput(
                        "VCF contains a non-header line before #CHROM".to_owned(),
                    ));
                }
            }
            Ok(None)
        }
        Encoding::Bcf => {
            if source.len() < 9 {
                return Ok(None);
            }
            if &source[..5] != b"BCF\x02\x02" {
                return Err(RsomicsError::InvalidInput(
                    "invalid BCF 2.2 header".to_owned(),
                ));
            }
            let length = u32::from_le_bytes(source[5..9].try_into().unwrap()) as usize;
            let end = 9usize.checked_add(length).ok_or_else(|| {
                RsomicsError::InvalidInput("BCF header length exceeds usize".to_owned())
            })?;
            Ok((source.len() >= end).then_some(end))
        }
    }
}

fn write_recompressed(source: &[u8], output: &mut impl Write) -> Result<()> {
    if source.is_empty() {
        return Ok(());
    }
    let mut writer = bgzf::io::Writer::new(Vec::new());
    writer.write_all(source).map_err(RsomicsError::Io)?;
    let mut encoded = writer.finish().map_err(RsomicsError::Io)?;
    if !encoded.ends_with(&EOF_BLOCK) {
        return Err(RsomicsError::InvalidInput(
            "recompressed BGZF boundary has no canonical EOF".to_owned(),
        ));
    }
    encoded.truncate(encoded.len() - EOF_BLOCK.len());
    output.write_all(&encoded).map_err(RsomicsError::Io)
}

fn inflate(raw: &[u8], path: &Path) -> Result<Vec<u8>> {
    let mut reader = bgzf::io::Reader::new(Cursor::new(raw));
    let mut inflated = Vec::new();
    reader.read_to_end(&mut inflated).map_err(|error| {
        RsomicsError::InvalidInput(format!("invalid BGZF frame in {}: {error}", path.display()))
    })?;
    Ok(inflated)
}

fn frame_error(path: &Path, error: std::io::Error) -> RsomicsError {
    RsomicsError::InvalidInput(format!("invalid BGZF stream {}: {error}", path.display()))
}

#[cfg(test)]
mod tests {
    use std::io::Write;

    use super::{Encoding, inspect_frames};
    use crate::format::bgzf::EOF_BLOCK;

    #[test]
    fn detects_vcf_magic_split_across_bgzf_frames() {
        let mut stream = Vec::new();
        for chunk in [
            b"#".as_slice(),
            b"#file".as_slice(),
            b"format=VCFv4.3\n".as_slice(),
        ] {
            let mut writer = noodles_bgzf::io::Writer::new(Vec::new());
            writer.write_all(chunk).unwrap();
            let mut frame = writer.finish().unwrap();
            frame.truncate(frame.len() - EOF_BLOCK.len());
            stream.extend_from_slice(&frame);
        }
        stream.extend_from_slice(&EOF_BLOCK);
        let file = tempfile::NamedTempFile::new().unwrap();
        std::fs::write(file.path(), stream).unwrap();
        assert_eq!(inspect_frames(file.path()).unwrap(), Encoding::Vcf);
    }
}
