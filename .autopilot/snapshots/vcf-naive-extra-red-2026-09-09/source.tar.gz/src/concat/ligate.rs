use std::collections::HashMap;
use std::path::{Path, PathBuf};

use noodles_vcf::{
    Header,
    header::record::value::{
        Map,
        map::{Format, format},
    },
    variant::{
        RecordBuf,
        record::samples::series::value::genotype::Phasing,
        record_buf::{
            Samples,
            samples::sample::{
                Value as SampleValue,
                value::{Genotype, genotype::Allele},
            },
        },
    },
};
use rsomics_common::{Result, RsomicsError};

use super::{LigateOptions, PlannedInput, Summary, invalid_record, reopen};
use crate::format::{Reader, RecordScratch, VariantWriter};

struct Chunk {
    reader: Reader,
    header: Header,
    path: PathBuf,
    scratch: RecordScratch,
    number: u64,
    next: Option<RecordBuf>,
    previous: Option<(usize, usize)>,
    swap: Vec<bool>,
}

struct PhaseState {
    contig: Option<String>,
    sets: Vec<i32>,
    pending: Vec<bool>,
    compact: bool,
}

struct Buffered {
    record: RecordBuf,
    later: Option<RecordBuf>,
    from_later: bool,
    matched: bool,
}

struct PairContext<'a, W> {
    header: &'a Header,
    references: &'a HashMap<String, usize>,
    options: LigateOptions,
    phase: &'a mut PhaseState,
    writer: &'a mut W,
    summary: &'a mut Summary,
}

pub(super) fn prepare_header(header: &mut Header) -> Result<()> {
    prepare_format(header, "PQ", "Phasing Quality (bigger is better)")?;
    prepare_format(header, "PS", "Phase Set")
}

pub(super) fn write(
    planned: &[PlannedInput],
    output_header: &Header,
    options: LigateOptions,
    writer: &mut impl VariantWriter,
    summary: &mut Summary,
) -> Result<()> {
    let references: HashMap<_, _> = output_header
        .contigs()
        .keys()
        .enumerate()
        .map(|(index, name)| (name.clone(), index))
        .collect();
    let sample_count = output_header.sample_names().len();
    let mut phase = PhaseState {
        contig: None,
        sets: vec![0; sample_count],
        pending: vec![true; sample_count],
        compact: options.compact_ps,
    };
    let mut chunks = planned.iter();
    let Some(mut current) = next_nonempty(&mut chunks, &references, sample_count, summary)? else {
        return Ok(());
    };
    let mut context = PairContext {
        header: output_header,
        references: &references,
        options,
        phase: &mut phase,
        writer,
        summary,
    };
    for planned in chunks {
        let Some(mut later) = Chunk::open(planned, &references, sample_count, context.summary)?
        else {
            continue;
        };
        ligate_pair(&mut current, &mut later, &mut context)?;
        current = later;
    }
    while let Some(mut record) = current.take(&references, context.summary)? {
        apply_swap(&mut record, &current.swap)?;
        context.phase.write(
            record,
            None,
            context.options.min_pq,
            context.header,
            context.writer,
            context.summary,
        )?;
    }
    Ok(())
}

fn next_nonempty<'a>(
    chunks: &mut impl Iterator<Item = &'a PlannedInput>,
    references: &HashMap<String, usize>,
    sample_count: usize,
    summary: &mut Summary,
) -> Result<Option<Chunk>> {
    for planned in chunks {
        if let Some(chunk) = Chunk::open(planned, references, sample_count, summary)? {
            return Ok(Some(chunk));
        }
    }
    Ok(None)
}

fn ligate_pair<W: VariantWriter>(
    current: &mut Chunk,
    later: &mut Chunk,
    context: &mut PairContext<'_, W>,
) -> Result<()> {
    let references = context.references;
    let later_start = later.coordinate(references)?.unwrap();
    if current
        .coordinate(references)?
        .is_some_and(|current_start| later_start < current_start)
    {
        return Err(RsomicsError::InvalidInput(format!(
            "ligation chunk order regresses at {}",
            later.path.display()
        )));
    }
    while current
        .coordinate(references)?
        .is_some_and(|coordinate| coordinate < later_start)
    {
        let mut record = current.take(references, context.summary)?.unwrap();
        apply_swap(&mut record, &current.swap)?;
        context.phase.write(
            record,
            None,
            context.options.min_pq,
            context.header,
            context.writer,
            context.summary,
        )?;
    }

    let Some(current_start) = current.coordinate(references)? else {
        if current
            .previous
            .is_some_and(|coordinate| coordinate.0 < later_start.0)
        {
            context.phase.reset();
            return Ok(());
        }
        if context.options.force {
            return Ok(());
        }
        return Err(RsomicsError::InvalidInput(format!(
            "ligation chunks do not overlap on the same contig before {}",
            later.path.display()
        )));
    };
    if current_start.0 != later_start.0 {
        if current_start.0 < later_start.0 {
            while let Some(mut record) = current.take(references, context.summary)? {
                apply_swap(&mut record, &current.swap)?;
                context.phase.write(
                    record,
                    None,
                    context.options.min_pq,
                    context.header,
                    context.writer,
                    context.summary,
                )?;
            }
            context.phase.reset();
            return Ok(());
        }
        return Err(RsomicsError::InvalidInput(format!(
            "ligation chunk order regresses at {}",
            later.path.display()
        )));
    }

    let mut buffered = Vec::new();
    let mut votes = vec![(0u64, 0u64); context.header.sample_names().len()];
    let mut matched = 0usize;
    while current.next.is_some() {
        let left_coordinate = current.coordinate(references)?.unwrap();
        match later.coordinate(references)? {
            Some(right_coordinate) if right_coordinate < left_coordinate => {
                for right in take_group(later, references, context.summary)?.1 {
                    unpaired(
                        right,
                        true,
                        &later.path,
                        right_coordinate,
                        context,
                        &mut buffered,
                    )?;
                }
            }
            Some(right_coordinate) if right_coordinate == left_coordinate => {
                let (_, mut left) = take_group(current, references, context.summary)?;
                let (_, right) = take_group(later, references, context.summary)?;
                for record in &mut left {
                    apply_swap(record, &current.swap)?;
                }
                let mut right: Vec<_> = right.into_iter().map(Some).collect();
                for record in left {
                    if let Some(index) = right.iter().enumerate().find_map(|(index, candidate)| {
                        candidate
                            .as_ref()
                            .is_some_and(|candidate| same_variant(&record, candidate))
                            .then_some(index)
                    }) {
                        let counterpart = right[index].take().unwrap();
                        add_votes(&record, &counterpart, &mut votes)?;
                        matched = matched.checked_add(1).ok_or_else(|| {
                            RsomicsError::InvalidInput(
                                "matched overlap count exceeds usize".to_owned(),
                            )
                        })?;
                        buffered.push(Buffered {
                            record,
                            later: Some(counterpart),
                            from_later: false,
                            matched: true,
                        });
                    } else {
                        unpaired(
                            record,
                            false,
                            &later.path,
                            left_coordinate,
                            context,
                            &mut buffered,
                        )?;
                    }
                }
                for record in right.into_iter().flatten() {
                    unpaired(
                        record,
                        true,
                        &later.path,
                        right_coordinate,
                        context,
                        &mut buffered,
                    )?;
                }
            }
            _ => {
                for mut left in take_group(current, references, context.summary)?.1 {
                    apply_swap(&mut left, &current.swap)?;
                    unpaired(
                        left,
                        false,
                        &later.path,
                        left_coordinate,
                        context,
                        &mut buffered,
                    )?;
                }
            }
        }
    }
    let overlap_end = current.previous.unwrap();
    while later
        .coordinate(references)?
        .is_some_and(|coordinate| coordinate.0 == overlap_end.0 && coordinate <= overlap_end)
    {
        let coordinate = later.coordinate(references)?.unwrap();
        for right in take_group(later, references, context.summary)?.1 {
            unpaired(right, true, &later.path, coordinate, context, &mut buffered)?;
        }
    }
    if matched == 0 && !context.options.force && !context.options.warn {
        return Err(RsomicsError::InvalidInput(format!(
            "ligation chunks have no shared sites before {}",
            later.path.display()
        )));
    }

    let (swap, quality) = orientation(votes, matched > 0);
    context.summary.phase_orientations_changed = context
        .summary
        .phase_orientations_changed
        .checked_add(swap.iter().filter(|value| **value).count() as u64)
        .ok_or_else(|| RsomicsError::InvalidInput("phase change count exceeds u64".to_owned()))?;
    later.swap = swap;
    let handoff = buffered.iter().rposition(|record| record.matched);
    for (index, mut buffered) in buffered.into_iter().enumerate() {
        if Some(index) == handoff
            && let Some(later) = buffered.later.take()
        {
            buffered.record = later;
            buffered.from_later = true;
        }
        if buffered.from_later && handoff.is_some_and(|handoff| index >= handoff) {
            apply_swap(&mut buffered.record, &later.swap)?;
        }
        context.phase.write(
            buffered.record,
            (Some(index) == handoff).then_some(quality.as_slice()),
            context.options.min_pq,
            context.header,
            context.writer,
            context.summary,
        )?;
    }
    Ok(())
}

fn take_group(
    chunk: &mut Chunk,
    references: &HashMap<String, usize>,
    summary: &mut Summary,
) -> Result<((usize, usize), Vec<RecordBuf>)> {
    let coordinate = chunk.coordinate(references)?.ok_or_else(|| {
        RsomicsError::InvalidInput("cannot take a record group from an empty chunk".to_owned())
    })?;
    let mut records = Vec::new();
    while chunk.coordinate(references)? == Some(coordinate) {
        records.push(chunk.take(references, summary)?.unwrap());
    }
    Ok((coordinate, records))
}

fn unpaired<W: VariantWriter>(
    record: RecordBuf,
    from_later: bool,
    path: &Path,
    coordinate: (usize, usize),
    context: &mut PairContext<'_, W>,
    buffered: &mut Vec<Buffered>,
) -> Result<()> {
    if context.options.force {
        buffered.push(Buffered {
            record,
            later: None,
            from_later,
            matched: false,
        });
    } else if context.options.warn {
        context.summary.overlap_records_dropped = context
            .summary
            .overlap_records_dropped
            .checked_add(1)
            .ok_or_else(|| {
                RsomicsError::InvalidInput("dropped overlap count exceeds u64".to_owned())
            })?;
    } else {
        return Err(imperfect(path, coordinate));
    }
    Ok(())
}

impl Chunk {
    fn open(
        planned: &PlannedInput,
        references: &HashMap<String, usize>,
        sample_count: usize,
        summary: &mut Summary,
    ) -> Result<Option<Self>> {
        require_index(&planned.path)?;
        let mut chunk = Self {
            reader: reopen(planned)?,
            header: planned.header.clone(),
            path: planned.path.clone(),
            scratch: RecordScratch::default(),
            number: 0,
            next: None,
            previous: None,
            swap: vec![false; sample_count],
        };
        chunk.advance(references, summary)?;
        Ok(chunk.next.is_some().then_some(chunk))
    }

    fn coordinate(&self, references: &HashMap<String, usize>) -> Result<Option<(usize, usize)>> {
        self.next
            .as_ref()
            .map(|record| coordinate(record, references, &self.path, self.number))
            .transpose()
    }

    fn take(
        &mut self,
        references: &HashMap<String, usize>,
        summary: &mut Summary,
    ) -> Result<Option<RecordBuf>> {
        let record = self.next.take();
        if record.is_some() {
            self.advance(references, summary)?;
        }
        Ok(record)
    }

    fn advance(
        &mut self,
        references: &HashMap<String, usize>,
        summary: &mut Summary,
    ) -> Result<()> {
        self.number = self.number.checked_add(1).ok_or_else(|| {
            RsomicsError::InvalidInput("variant record count exceeds u64".to_owned())
        })?;
        let Some(record) = self
            .reader
            .read_record(&self.header, &mut self.scratch, self.number)?
        else {
            self.next = None;
            return Ok(());
        };
        summary.records_read = summary.records_read.checked_add(1).ok_or_else(|| {
            RsomicsError::InvalidInput("variant record count exceeds u64".to_owned())
        })?;
        let coordinate = coordinate(&record, references, &self.path, self.number)?;
        if let Some(previous) = self.previous {
            if coordinate < previous {
                return Err(invalid_record(
                    &self.path,
                    self.number,
                    "input records are not coordinate sorted",
                ));
            }
            if coordinate.0 != previous.0 {
                return Err(invalid_record(
                    &self.path,
                    self.number,
                    "ligation inputs must each contain exactly one reference sequence",
                ));
            }
        }
        self.previous = Some(coordinate);
        self.next = Some(record);
        Ok(())
    }
}

impl PhaseState {
    fn reset(&mut self) {
        self.contig = None;
        self.pending.fill(true);
    }

    fn write(
        &mut self,
        mut record: RecordBuf,
        quality: Option<&[i32]>,
        min_pq: u32,
        header: &Header,
        writer: &mut impl VariantWriter,
        summary: &mut Summary,
    ) -> Result<()> {
        let position = record
            .variant_start()
            .map(usize::from)
            .ok_or_else(|| RsomicsError::InvalidInput("variant position is missing".to_owned()))?;
        if self.contig.as_deref() != Some(record.reference_sequence_name()) {
            self.contig = Some(record.reference_sequence_name().to_owned());
            let value = i32::try_from(position).map_err(|_| {
                RsomicsError::InvalidInput("phase-set position exceeds i32".to_owned())
            })?;
            self.sets.fill(value);
            self.pending.fill(true);
        }
        if let Some(quality) = quality {
            if quality.len() != self.sets.len() {
                return Err(RsomicsError::InvalidInput(
                    "phase quality sample count differs from the header".to_owned(),
                ));
            }
            set_integer_format(
                &mut record,
                "PQ",
                quality.iter().copied().map(Some).collect(),
            )?;
            let value = i32::try_from(position).map_err(|_| {
                RsomicsError::InvalidInput("phase-set position exceeds i32".to_owned())
            })?;
            for (sample, quality) in quality.iter().enumerate() {
                if u32::try_from(*quality).map_or(true, |quality| quality < min_pq) {
                    self.sets[sample] = value;
                    self.pending[sample] = true;
                }
            }
        }
        if !self.compact || self.pending.iter().any(|pending| *pending) {
            let values = self
                .sets
                .iter()
                .zip(&self.pending)
                .map(|(value, pending)| (!self.compact || *pending).then_some(*value))
                .collect();
            set_integer_format(&mut record, "PS", values)?;
            self.pending.fill(false);
        }
        summary.records_written = summary.records_written.checked_add(1).ok_or_else(|| {
            RsomicsError::InvalidInput("output record count exceeds u64".to_owned())
        })?;
        writer.write_record(header, &record, summary.records_written)
    }
}

fn prepare_format(header: &mut Header, key: &str, description: &str) -> Result<()> {
    if let Some(existing) = header.formats().get(key) {
        if existing.number() != format::Number::Count(1) || existing.ty() != format::Type::Integer {
            return Err(RsomicsError::InvalidInput(format!(
                "FORMAT/{key} must have Number=1,Type=Integer for ligation"
            )));
        }
    } else {
        header.formats_mut().insert(
            key.to_owned(),
            Map::<Format>::new(
                format::Number::Count(1),
                format::Type::Integer,
                description.to_owned(),
            ),
        );
    }
    Ok(())
}

fn coordinate(
    record: &RecordBuf,
    references: &HashMap<String, usize>,
    path: &Path,
    number: u64,
) -> Result<(usize, usize)> {
    let reference = references
        .get(record.reference_sequence_name())
        .copied()
        .ok_or_else(|| {
            invalid_record(
                path,
                number,
                "reference sequence is absent from the merged header",
            )
        })?;
    let position = record
        .variant_start()
        .map(usize::from)
        .ok_or_else(|| invalid_record(path, number, "variant position is missing"))?;
    Ok((reference, position))
}

fn same_variant(left: &RecordBuf, right: &RecordBuf) -> bool {
    left.reference_sequence_name() == right.reference_sequence_name()
        && left.variant_start() == right.variant_start()
        && left
            .reference_bases()
            .eq_ignore_ascii_case(right.reference_bases())
        && left.alternate_bases().as_ref().len() == right.alternate_bases().as_ref().len()
        && left
            .alternate_bases()
            .as_ref()
            .iter()
            .zip(right.alternate_bases().as_ref())
            .all(|(left, right)| left.eq_ignore_ascii_case(right))
}

fn add_votes(left: &RecordBuf, right: &RecordBuf, votes: &mut [(u64, u64)]) -> Result<()> {
    for (sample, vote) in votes.iter_mut().enumerate() {
        let (Some(left), Some(right)) = (phase_pair(left, sample)?, phase_pair(right, sample)?)
        else {
            continue;
        };
        if left == right {
            vote.0 = vote.0.checked_add(1).ok_or_else(|| {
                RsomicsError::InvalidInput("phase vote count exceeds u64".to_owned())
            })?;
        } else if left == (right.1, right.0) {
            vote.1 = vote.1.checked_add(1).ok_or_else(|| {
                RsomicsError::InvalidInput("phase vote count exceeds u64".to_owned())
            })?;
        }
    }
    Ok(())
}

fn orientation(votes: Vec<(u64, u64)>, evidence: bool) -> (Vec<bool>, Vec<i32>) {
    let swap = votes
        .iter()
        .map(|(matches, mismatches)| mismatches > matches)
        .collect();
    let quality = if evidence {
        votes
            .into_iter()
            .map(|(matches, mismatches)| phase_quality(matches, mismatches))
            .collect()
    } else {
        vec![0; votes.len()]
    };
    (swap, quality)
}

fn phase_pair(record: &RecordBuf, sample: usize) -> Result<Option<(usize, usize)>> {
    let Some(index) = record.samples().keys().as_ref().get_index_of("GT") else {
        return Ok(None);
    };
    let Some(row) = record.samples().values().nth(sample) else {
        return Err(RsomicsError::InvalidInput(format!(
            "record has fewer samples than the header at sample {}",
            sample + 1
        )));
    };
    let Some(value) = row.values().get(index) else {
        return Ok(None);
    };
    let Some(value) = value else {
        return Ok(None);
    };
    let SampleValue::Genotype(genotype) = value else {
        return Err(RsomicsError::InvalidInput(format!(
            "sample {} FORMAT/GT is not encoded as a genotype",
            sample + 1
        )));
    };
    complete_phased_pair(genotype)
}

fn complete_phased_pair(genotype: &Genotype) -> Result<Option<(usize, usize)>> {
    if genotype.as_ref().len() != 2 || genotype.as_ref()[1].phasing() != Phasing::Phased {
        return Ok(None);
    }
    let Some(left) = genotype.as_ref()[0].position() else {
        return Ok(None);
    };
    let Some(right) = genotype.as_ref()[1].position() else {
        return Ok(None);
    };
    Ok((left != right).then_some((left, right)))
}

fn phase_quality(matches: u64, mismatches: u64) -> i32 {
    if matches == 0 || mismatches == 0 {
        return 99;
    }
    let total = matches as f64 + mismatches as f64;
    let fraction = matches as f64 / total;
    (99.0 * (0.7 + fraction * fraction.ln() + (1.0 - fraction) * (1.0 - fraction).ln()) / 0.7)
        as i32
}

fn apply_swap(record: &mut RecordBuf, selected: &[bool]) -> Result<()> {
    let keys = record.samples().keys().clone();
    let Some(index) = keys.as_ref().get_index_of("GT") else {
        return Ok(());
    };
    let mut rows = record
        .samples()
        .values()
        .map(|sample| sample.values().to_vec())
        .collect::<Vec<_>>();
    if rows.len() != selected.len() {
        return Err(RsomicsError::InvalidInput(
            "record sample count differs from the ligation header".to_owned(),
        ));
    }
    for (row, selected) in rows.iter_mut().zip(selected) {
        if !selected {
            continue;
        }
        let Some(value) = row.get_mut(index).and_then(Option::as_mut) else {
            continue;
        };
        let SampleValue::Genotype(genotype) = value else {
            return Err(RsomicsError::InvalidInput(
                "FORMAT/GT is not encoded as a genotype".to_owned(),
            ));
        };
        if complete_phased_pair(genotype)?.is_none() {
            continue;
        }
        let left = &genotype.as_ref()[0];
        let right = &genotype.as_ref()[1];
        *genotype = [
            Allele::new(right.position(), left.phasing()),
            Allele::new(left.position(), right.phasing()),
        ]
        .into_iter()
        .collect();
    }
    *record.samples_mut() = Samples::new(keys, rows);
    Ok(())
}

fn set_integer_format(record: &mut RecordBuf, key: &str, values: Vec<Option<i32>>) -> Result<()> {
    let mut keys = record.samples().keys().clone();
    let index = if let Some(index) = keys.as_ref().get_index_of(key) {
        index
    } else {
        keys.as_mut().insert(key.to_owned());
        keys.as_ref().len() - 1
    };
    let mut rows = record
        .samples()
        .values()
        .map(|sample| sample.values().to_vec())
        .collect::<Vec<_>>();
    if rows.len() != values.len() {
        return Err(RsomicsError::InvalidInput(format!(
            "FORMAT/{key} has {} samples but the record has {}",
            values.len(),
            rows.len()
        )));
    }
    for (row, value) in rows.iter_mut().zip(values) {
        row.resize(keys.as_ref().len(), None);
        row[index] = value.map(SampleValue::Integer);
    }
    *record.samples_mut() = Samples::new(keys, rows);
    Ok(())
}

fn require_index(path: &Path) -> Result<()> {
    crate::index::read_fresh(path).map(|_| ()).map_err(|error| {
        RsomicsError::InvalidInput(format!(
            "ligation requires a valid CSI or TBI index for {}: {error}",
            path.display()
        ))
    })
}

fn imperfect(path: &Path, coordinate: (usize, usize)) -> RsomicsError {
    RsomicsError::InvalidInput(format!(
        "ligation failed at merged reference {} position {} in {}: the chunks do not have perfect overlap",
        coordinate.0,
        coordinate.1,
        path.display()
    ))
}

#[cfg(test)]
mod tests {
    use noodles_vcf::{
        Header,
        header::record::value::{
            Map,
            map::{Format, format},
        },
        variant::record_buf::samples::sample::value::Genotype,
    };

    use super::{complete_phased_pair, prepare_header};

    #[test]
    fn phase_formats_require_scalar_integers() {
        for key in ["PQ", "PS"] {
            let mut header = Header::default();
            header.formats_mut().insert(
                key.to_owned(),
                Map::<Format>::new(
                    format::Number::Count(2),
                    format::Type::Float,
                    "Incompatible".to_owned(),
                ),
            );
            let error = prepare_header(&mut header).unwrap_err();
            assert!(error.to_string().contains(&format!("FORMAT/{key}")));
        }
    }

    #[test]
    fn only_complete_phased_diploid_heterozygotes_vote() {
        let informative: Genotype = "0|1".parse().unwrap();
        assert_eq!(complete_phased_pair(&informative).unwrap(), Some((0, 1)));
        for value in ["0|0", "0", "0|1|1", "0/1", ".|."] {
            let genotype: Genotype = value.parse().unwrap();
            assert_eq!(complete_phased_pair(&genotype).unwrap(), None, "{value}");
        }
    }
}
