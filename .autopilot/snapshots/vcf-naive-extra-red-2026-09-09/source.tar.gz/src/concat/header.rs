use std::path::Path;

use noodles_vcf::{Header, header::record::value::Collection};
use rsomics_common::{Result, RsomicsError};

pub(super) fn merge(
    target: &mut Header,
    source: &Header,
    path: &Path,
    drop_genotypes: bool,
) -> Result<()> {
    if !drop_genotypes && target.sample_names() != source.sample_names() {
        return Err(conflict(path, "sample names or order differ"));
    }

    for (id, value) in source.contigs() {
        if let Some(existing) = target.contigs().get(id) {
            if existing.length().is_some()
                && value.length().is_some()
                && existing.length() != value.length()
            {
                return Err(conflict(
                    path,
                    &format!("contig {id} has conflicting lengths"),
                ));
            }
            if existing.length().is_none() && value.length().is_some() {
                *target.contigs_mut().get_mut(id).unwrap().length_mut() = value.length();
            }
        } else {
            target.contigs_mut().insert(id.clone(), value.clone());
        }
    }
    for (id, value) in source.infos() {
        if let Some(existing) = target.infos().get(id) {
            if existing.number() != value.number() || existing.ty() != value.ty() {
                return Err(conflict(
                    path,
                    &format!("INFO/{id} has conflicting Number or Type"),
                ));
            }
        } else {
            target.infos_mut().insert(id.clone(), value.clone());
        }
    }
    if !drop_genotypes {
        for (id, value) in source.formats() {
            if let Some(existing) = target.formats().get(id) {
                if existing.number() != value.number() || existing.ty() != value.ty() {
                    return Err(conflict(
                        path,
                        &format!("FORMAT/{id} has conflicting Number or Type"),
                    ));
                }
            } else {
                target.formats_mut().insert(id.clone(), value.clone());
            }
        }
    }
    for (id, value) in source.filters() {
        if let Some(existing) = target.filters().get(id) {
            if existing.description() != value.description()
                || existing.other_fields() != value.other_fields()
            {
                return Err(conflict(
                    path,
                    &format!("FILTER/{id} has conflicting definitions"),
                ));
            }
        } else {
            target.filters_mut().insert(id.clone(), value.clone());
        }
    }
    for (id, value) in source.alternative_alleles() {
        if let Some(existing) = target.alternative_alleles().get(id) {
            if existing.description() != value.description()
                || existing.other_fields() != value.other_fields()
            {
                return Err(conflict(
                    path,
                    &format!("ALT/{id} has conflicting definitions"),
                ));
            }
        } else {
            target
                .alternative_alleles_mut()
                .insert(id.clone(), value.clone());
        }
    }
    merge_other(target, source, path)
}

fn merge_other(target: &mut Header, source: &Header, path: &Path) -> Result<()> {
    for (key, values) in source.other_records() {
        let Some(existing) = target.other_records_mut().get_mut(key) else {
            target
                .other_records_mut()
                .insert(key.clone(), values.clone());
            continue;
        };
        match (existing, values) {
            (Collection::Unstructured(target), Collection::Unstructured(source)) => {
                for value in source {
                    if !target.contains(value) {
                        target.push(value.clone());
                    }
                }
            }
            (Collection::Structured(target), Collection::Structured(source)) => {
                for (id, value) in source {
                    if let Some(existing) = target.get(id) {
                        if existing != value {
                            return Err(conflict(
                                path,
                                &format!("header record {key}/{id} has conflicting definitions"),
                            ));
                        }
                    } else {
                        target.insert(id.clone(), value.clone());
                    }
                }
            }
            _ => {
                return Err(conflict(
                    path,
                    &format!("header record {key} mixes structured and unstructured values"),
                ));
            }
        }
    }
    Ok(())
}

fn conflict(path: &Path, message: &str) -> RsomicsError {
    RsomicsError::InvalidInput(format!("header conflict in {}: {message}", path.display()))
}
