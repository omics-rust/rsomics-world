use std::cmp::{Ordering, Reverse};
use std::collections::{BinaryHeap, HashMap, HashSet};

use noodles_vcf::{
    Header,
    variant::{RecordBuf, record_buf::Samples},
};
use rsomics_common::{Result, RsomicsError};

use super::{DuplicatePolicy, Options, Preflight, Summary, invalid_record, reopen};
use crate::format::{Reader, RecordScratch, VariantWriter};
use crate::regions::RegionSet;
use crate::variant_type;

struct Input {
    reader: Reader,
    header: Header,
    path: std::path::PathBuf,
    scratch: RecordScratch,
    number: u64,
    previous: Option<(usize, usize)>,
    seen: HashSet<usize>,
}

struct Pending {
    reference: usize,
    position: usize,
    input: usize,
    number: u64,
    record: RecordBuf,
}

impl PartialEq for Pending {
    fn eq(&self, other: &Self) -> bool {
        self.cmp(other) == Ordering::Equal
    }
}

impl Eq for Pending {}

impl PartialOrd for Pending {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for Pending {
    fn cmp(&self, other: &Self) -> Ordering {
        self.coordinate()
            .cmp(&other.coordinate())
            .then_with(|| self.input.cmp(&other.input))
            .then_with(|| self.number.cmp(&other.number))
    }
}

impl Pending {
    fn coordinate(&self) -> (usize, usize) {
        (self.reference, self.position)
    }
}

pub(super) fn write_overlap(
    preflight: &mut Preflight,
    options: &Options,
    duplicate_policy: Option<DuplicatePolicy>,
    writer: &mut impl VariantWriter,
    summary: &mut Summary,
) -> Result<()> {
    if let Some(regions) = &options.regions {
        return write_indexed(
            preflight,
            options,
            duplicate_policy,
            regions,
            writer,
            summary,
        );
    }
    let planned = &preflight.inputs;
    let output_header = &preflight.header;
    let references: HashMap<_, _> = output_header
        .contigs()
        .keys()
        .enumerate()
        .map(|(index, name)| (name.clone(), index))
        .collect();
    let mut inputs: Vec<_> = planned
        .iter()
        .map(|input| {
            Ok(Input {
                reader: reopen(input)?,
                header: input.header.clone(),
                path: input.path.clone(),
                scratch: RecordScratch::default(),
                number: 0,
                previous: None,
                seen: HashSet::new(),
            })
        })
        .collect::<Result<_>>()?;
    let mut pending = BinaryHeap::new();
    for index in 0..inputs.len() {
        push_next(index, &references, &mut inputs, &mut pending, summary)?;
    }

    while let Some(Reverse(first)) = pending.pop() {
        let coordinate = first.coordinate();
        let mut records = vec![first];
        let input = records[0].input;
        push_next(input, &references, &mut inputs, &mut pending, summary)?;
        while pending
            .peek()
            .is_some_and(|Reverse(record)| record.coordinate() == coordinate)
        {
            let Reverse(record) = pending.pop().unwrap();
            let input = record.input;
            records.push(record);
            push_next(input, &references, &mut inputs, &mut pending, summary)?;
        }
        write_coordinate(
            records,
            output_header,
            options,
            duplicate_policy,
            writer,
            summary,
        )?;
    }
    Ok(())
}

#[derive(Default)]
struct RegionState {
    previous: Option<(usize, usize)>,
    seen: HashSet<usize>,
}

struct RegionInput<'a, I> {
    records: I,
    path: &'a std::path::Path,
    state: &'a mut RegionState,
}

fn write_indexed(
    preflight: &mut Preflight,
    options: &Options,
    duplicate_policy: Option<DuplicatePolicy>,
    regions: &RegionSet,
    writer: &mut impl VariantWriter,
    summary: &mut Summary,
) -> Result<()> {
    let output_header = &preflight.header;
    let references: HashMap<_, _> = output_header
        .contigs()
        .keys()
        .enumerate()
        .map(|(index, name)| (name.clone(), index))
        .collect();
    let regions = regions.merged(output_header)?;
    let mut counts = vec![0; preflight.indexed.len()];
    let mut states: Vec<_> = (0..preflight.indexed.len())
        .map(|_| RegionState::default())
        .collect();
    for regions in regions.chunk_by(|left, right| left.name() == right.name()) {
        let mut inputs = preflight
            .indexed
            .iter_mut()
            .zip(&preflight.inputs)
            .zip(&mut states)
            .zip(&mut counts)
            .map(|(((reader, planned), state), read)| {
                Ok(RegionInput {
                    records: reader.query_contig(regions, read)?,
                    path: &planned.path,
                    state,
                })
            })
            .collect::<Result<Vec<_>>>()?;
        merge_indexed(
            &references,
            &mut inputs,
            output_header,
            options,
            duplicate_policy,
            writer,
            summary,
        )?;
    }
    for read in counts {
        summary.records_read = summary.records_read.checked_add(read).ok_or_else(|| {
            RsomicsError::InvalidInput("variant record count exceeds u64".to_owned())
        })?;
    }
    Ok(())
}

fn merge_indexed<I>(
    references: &HashMap<String, usize>,
    inputs: &mut [RegionInput<'_, I>],
    output_header: &Header,
    options: &Options,
    duplicate_policy: Option<DuplicatePolicy>,
    writer: &mut impl VariantWriter,
    summary: &mut Summary,
) -> Result<()>
where
    I: Iterator<Item = Result<(RecordBuf, u64)>>,
{
    let mut pending = BinaryHeap::new();
    for index in 0..inputs.len() {
        push_next_indexed(index, references, inputs, &mut pending)?;
    }
    while let Some(Reverse(first)) = pending.pop() {
        let coordinate = first.coordinate();
        let mut records = vec![first];
        let input = records[0].input;
        push_next_indexed(input, references, inputs, &mut pending)?;
        while pending
            .peek()
            .is_some_and(|Reverse(record)| record.coordinate() == coordinate)
        {
            let Reverse(record) = pending.pop().unwrap();
            let input = record.input;
            records.push(record);
            push_next_indexed(input, references, inputs, &mut pending)?;
        }
        write_coordinate(
            records,
            output_header,
            options,
            duplicate_policy,
            writer,
            summary,
        )?;
    }
    Ok(())
}

fn push_next_indexed<I>(
    index: usize,
    references: &HashMap<String, usize>,
    inputs: &mut [RegionInput<'_, I>],
    pending: &mut BinaryHeap<Reverse<Pending>>,
) -> Result<()>
where
    I: Iterator<Item = Result<(RecordBuf, u64)>>,
{
    let input = &mut inputs[index];
    if let Some(result) = input.records.next() {
        let (record, number) = result?;
        let reference = references
            .get(record.reference_sequence_name())
            .copied()
            .ok_or_else(|| {
                invalid_record(
                    input.path,
                    number,
                    "reference sequence is absent from the merged header",
                )
            })?;
        let position = record
            .variant_start()
            .map(usize::from)
            .ok_or_else(|| invalid_record(input.path, number, "variant position is missing"))?;
        if let Some((previous_reference, previous_position)) = input.state.previous {
            if reference < previous_reference
                || (reference == previous_reference && position < previous_position)
            {
                return Err(invalid_record(
                    input.path,
                    number,
                    "indexed records are not coordinate sorted",
                ));
            }
            if reference != previous_reference && !input.state.seen.insert(previous_reference) {
                return Err(invalid_record(
                    input.path,
                    number,
                    "indexed reference sequence blocks are not contiguous",
                ));
            }
        }
        input.state.previous = Some((reference, position));
        pending.push(Reverse(Pending {
            reference,
            position,
            input: index,
            number,
            record,
        }));
    }
    Ok(())
}

fn push_next(
    index: usize,
    references: &HashMap<String, usize>,
    inputs: &mut [Input],
    pending: &mut BinaryHeap<Reverse<Pending>>,
    summary: &mut Summary,
) -> Result<()> {
    let input = &mut inputs[index];
    input.number = input
        .number
        .checked_add(1)
        .ok_or_else(|| RsomicsError::InvalidInput("variant record count exceeds u64".to_owned()))?;
    let Some(record) = input
        .reader
        .read_record(&input.header, &mut input.scratch, input.number)?
    else {
        return Ok(());
    };
    summary.records_read = summary
        .records_read
        .checked_add(1)
        .ok_or_else(|| RsomicsError::InvalidInput("variant record count exceeds u64".to_owned()))?;
    let reference = references
        .get(record.reference_sequence_name())
        .copied()
        .ok_or_else(|| {
            invalid_record(
                &input.path,
                input.number,
                "reference sequence is absent from the merged header",
            )
        })?;
    let position = record
        .variant_start()
        .map(usize::from)
        .ok_or_else(|| invalid_record(&input.path, input.number, "variant position is missing"))?;
    if let Some((previous_reference, previous_position)) = input.previous {
        if reference < previous_reference
            || (reference == previous_reference && position < previous_position)
        {
            return Err(invalid_record(
                &input.path,
                input.number,
                "input records are not coordinate sorted",
            ));
        }
        if reference != previous_reference && !input.seen.insert(previous_reference) {
            return Err(invalid_record(
                &input.path,
                input.number,
                "reference sequence blocks are not contiguous",
            ));
        }
    }
    input.previous = Some((reference, position));
    pending.push(Reverse(Pending {
        reference,
        position,
        input: index,
        number: input.number,
        record,
    }));
    Ok(())
}

fn write_coordinate(
    records: Vec<Pending>,
    header: &Header,
    options: &Options,
    duplicate_policy: Option<DuplicatePolicy>,
    writer: &mut impl VariantWriter,
    summary: &mut Summary,
) -> Result<()> {
    let mut accepted: Vec<(usize, RecordBuf)> = Vec::with_capacity(records.len());
    let mut input = None;
    let mut matched = HashSet::new();
    for mut pending in records {
        if input != Some(pending.input) {
            input = Some(pending.input);
            matched.clear();
        }
        let duplicate = duplicate_policy.and_then(|policy| {
            accepted
                .iter()
                .enumerate()
                .find(|(index, (input, previous))| {
                    *input < pending.input
                        && !matched.contains(index)
                        && exact_alleles(previous, &pending.record)
                })
                .or_else(|| {
                    accepted
                        .iter()
                        .enumerate()
                        .find(|(index, (input, previous))| {
                            *input < pending.input
                                && !matched.contains(index)
                                && relaxed_match(policy, previous, &pending.record)
                        })
                })
                .map(|(index, _)| index)
        });
        if let Some(index) = duplicate {
            matched.insert(index);
            summary.duplicates_removed =
                summary.duplicates_removed.checked_add(1).ok_or_else(|| {
                    RsomicsError::InvalidInput("duplicate count exceeds u64".to_owned())
                })?;
            continue;
        }
        if options.drop_genotypes {
            *pending.record.samples_mut() = Samples::default();
        }
        summary.records_written = summary.records_written.checked_add(1).ok_or_else(|| {
            RsomicsError::InvalidInput("output record count exceeds u64".to_owned())
        })?;
        writer.write_record(header, &pending.record, summary.records_written)?;
        accepted.push((pending.input, pending.record));
    }
    Ok(())
}

fn relaxed_match(policy: DuplicatePolicy, left: &RecordBuf, right: &RecordBuf) -> bool {
    let left_type = variant_type::record_mask(left);
    let right_type = variant_type::record_mask(right);
    match policy {
        DuplicatePolicy::Exact => false,
        DuplicatePolicy::All => true,
        DuplicatePolicy::Snps => {
            same_class(left_type, right_type, variant_type::SNP | variant_type::MNP)
        }
        DuplicatePolicy::Indels => same_class(left_type, right_type, variant_type::INDEL),
        DuplicatePolicy::Both => {
            same_class(left_type, right_type, variant_type::SNP | variant_type::MNP)
                || same_class(left_type, right_type, variant_type::INDEL)
        }
    }
}

fn exact_alleles(left: &RecordBuf, right: &RecordBuf) -> bool {
    if !left
        .reference_bases()
        .eq_ignore_ascii_case(right.reference_bases())
    {
        return false;
    }
    let left = left.alternate_bases().as_ref();
    let right = right.alternate_bases().as_ref();
    if left.len() != right.len() {
        return false;
    }
    let mut matched = vec![false; right.len()];
    left.iter().all(|allele| {
        right
            .iter()
            .enumerate()
            .find(|(index, candidate)| !matched[*index] && allele.eq_ignore_ascii_case(candidate))
            .is_some_and(|(index, _)| {
                matched[index] = true;
                true
            })
    })
}

fn same_class(left: u32, right: u32, mask: u32) -> bool {
    left & mask != 0 && right & mask != 0
}

#[cfg(test)]
mod tests {
    use noodles_vcf::{Header, Record, variant::RecordBuf};

    use super::exact_alleles;

    fn record(alleles: &str) -> RecordBuf {
        let header = Header::default();
        let source =
            Record::try_from(format!("chr1\t1\t.\tA\t{alleles}\t.\tPASS\t.").as_bytes()).unwrap();
        RecordBuf::try_from_variant_record(&header, &source).unwrap()
    }

    #[test]
    fn exact_alleles_are_case_insensitive_unordered_multisets() {
        assert!(exact_alleles(&record("C,G"), &record("g,c")));
        assert!(!exact_alleles(&record("C,C"), &record("C,G")));
    }
}
