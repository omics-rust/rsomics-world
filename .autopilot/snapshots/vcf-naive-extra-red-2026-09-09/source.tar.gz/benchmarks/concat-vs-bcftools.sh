#!/usr/bin/env bash
set -euo pipefail

usage() {
    echo "usage:" >&2
    echo "  $0 generate RSOMICS_VCF BCFTOOLS WORKSPACE" >&2
    echo "  $0 run RSOMICS_VCF BCFTOOLS WORKSPACE RESULT_DIRECTORY" >&2
    exit 2
}

external_directory() {
    case "$1" in
        /Volumes/*) ;;
        *)
            echo "benchmark data and results must be on an external volume" >&2
            exit 2
            ;;
    esac
}

resolve_binary() {
    if [[ "$1" == */* ]]; then
        realpath "$1"
    else
        command -v "$1"
    fi
}

require_oracle() {
    [[ "$($1 --version | sed -n '1p')" == "bcftools 1.24" ]] || {
        echo "bcftools 1.24 is required" >&2
        exit 2
    }
}

canonicalize() {
    local bcftools="$1"
    local source="$2"
    local destination="$3"
    local metadata="$destination.metadata"
    local body="$destination.body"
    "$bcftools" view --no-version -Ov "$source" | awk -v metadata="$metadata" -v body="$body" '
        /^##/ { print > metadata; next }
        { print > body }
    '
    LC_ALL=C sort "$metadata" > "$destination"
    awk '{ print }' "$body" >> "$destination"
    rm "$metadata" "$body"
}

generate_workload() {
    [[ $# -eq 3 ]] || usage
    local binary bcftools workspace records overlap_records samples chunks marker
    binary="$(resolve_binary "$1")"
    bcftools="$(resolve_binary "$2")"
    workspace="$3"
    external_directory "$workspace"
    require_oracle "$bcftools"
    "$binary" --version >/dev/null
    if [[ "${RSOMICS_BENCH_SMOKE:-0}" == 1 ]]; then
        records="${SMOKE_RECORDS:-20000}"
        overlap_records="${SMOKE_OVERLAP_RECORDS:-20000}"
    else
        records="${CONCAT_RECORDS:-2000000}"
        overlap_records="${CONCAT_OVERLAP_RECORDS:-1000000}"
    fi
    samples="${CONCAT_SAMPLES:-4}"
    chunks=4
    for value in "$records" "$overlap_records" "$samples"; do
        [[ "$value" =~ ^[0-9]+$ && "$value" -gt 0 ]] || {
            echo "generated workload sizes must be positive integers" >&2
            exit 2
        }
    done
    ((records >= chunks && overlap_records >= 4)) || {
        echo "record counts are too small for the benchmark layout" >&2
        exit 2
    }

    mkdir -p "$workspace"
    workspace="$(realpath "$workspace")"
    marker="$workspace/generation.sha256"
    if [[ -f "$marker" ]]; then
        (cd "$workspace" && shasum -a 256 --check generation.sha256)
        return
    fi
    if find "$workspace" -mindepth 1 -print -quit | grep -q .; then
        echo "workspace is nonempty and has no complete generation manifest: $workspace" >&2
        exit 2
    fi
    mkdir -p "$workspace/inputs/ordered" "$workspace/inputs/overlap"

    local chunk chunk_size start end source
    chunk_size=$((records / chunks))
    for ((chunk = 1; chunk <= chunks; chunk++)); do
        start=$(((chunk - 1) * chunk_size + 1))
        if ((chunk == chunks)); then
            end="$records"
        else
            end=$((chunk * chunk_size))
        fi
        source="$workspace/inputs/ordered/chunk-$chunk.vcf"
        awk -v start="$start" -v end="$end" -v records="$records" -v samples="$samples" 'BEGIN {
            print "##fileformat=VCFv4.3"
            print "##FILTER=<ID=PASS,Description=\"All filters passed\">"
            print "##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Total depth\">"
            print "##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">"
            print "##FORMAT=<ID=DP,Number=1,Type=Integer,Description=\"Sample depth\">"
            print "##contig=<ID=chr1,length=" records + 100 ">"
            printf "#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT"
            for (sample = 1; sample <= samples; sample++) printf "\tS%d", sample
            print ""
            for (position = start; position <= end; position++) {
                printf "chr1\t%d\tv%d\tA\tC\t50\tPASS\tDP=%d\tGT:DP", position, position, samples * 10
                for (sample = 1; sample <= samples; sample++) printf "\t0/1:10"
                print ""
            }
        }' > "$source"
        "$bcftools" view --no-version -Oz -o "$source.gz" "$source"
        "$bcftools" view --no-version -Ob -o "${source%.vcf}.bcf" "$source"
    done

    local half first_overlap second_overlap part
    half=$((overlap_records / 2))
    first_overlap="$workspace/inputs/overlap/first.vcf"
    second_overlap="$workspace/inputs/overlap/second.vcf"
    for part in first second; do
        if [[ "$part" == first ]]; then
            start=1
            end="$overlap_records"
            source="$first_overlap"
        else
            start=$((half + 1))
            end=$((overlap_records + half))
            source="$second_overlap"
        fi
        awk -v start="$start" -v end="$end" -v length="$((overlap_records + half + 100))" 'BEGIN {
            print "##fileformat=VCFv4.3"
            print "##FILTER=<ID=PASS,Description=\"All filters passed\">"
            print "##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Total depth\">"
            print "##contig=<ID=chr1,length=" length ">"
            print "#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO"
            for (position = start; position <= end; position++)
                printf "chr1\t%d\to%d\tA\tC\t50\tPASS\tDP=%d\n", position, position, position % 100
        }' > "$source"
        "$bcftools" view --no-version -Oz -o "$source.gz" "$source"
        "$bcftools" index -f "$source.gz"
    done

    {
        printf 'records=%s\noverlap_records=%s\nsamples=%s\nchunks=%s\n' \
            "$records" "$overlap_records" "$samples" "$chunks"
        printf 'overlap_region=chr1:%s-%s\n' "$((half / 2 + 1))" "$((overlap_records + half / 2))"
    } > "$workspace/generation.txt"
    (
        cd "$workspace"
        find inputs -type f -print0 | LC_ALL=C sort -z | xargs -0 shasum -a 256
        shasum -a 256 generation.txt
    ) > "$marker"
}

measure() {
    local workload="$1"
    local pair="$2"
    local order="$3"
    local tool="$4"
    shift 4
    local timing="$result_directory/$workload-$tool-$pair.time"
    /usr/bin/time -lp "$@" > /dev/null 2> "$timing"
    local wall user system rss
    wall="$(awk '$1 == "real" { print $2 }' "$timing")"
    user="$(awk '$1 == "user" { print $2 }' "$timing")"
    system="$(awk '$1 == "sys" { print $2 }' "$timing")"
    rss="$(awk '$2 == "maximum" && $3 == "resident" { print $1 }' "$timing")"
    [[ -n "$wall" && -n "$user" && -n "$system" && -n "$rss" ]]
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
        "$workload" "$pair" "$order" "$tool" "$wall" "$user" "$system" "$rss" \
        >> "$raw_results"
}

summarize() {
    local workload="$1"
    local tool="$2"
    local column="$3"
    local metric="$4"
    local values="$result_directory/$workload-$tool-$metric.values"
    awk -F '\t' -v workload="$workload" -v tool="$tool" -v column="$column" \
        '$1 == workload && $4 == tool { print $column }' "$raw_results" | LC_ALL=C sort -n > "$values"
    awk -v workload="$workload" -v tool="$tool" -v metric="$metric" '
        { value[NR] = $1; sum += $1; sumsq += $1 * $1 }
        END {
            if (NR == 0) exit 1
            median = NR % 2 ? value[(NR + 1) / 2] : (value[NR / 2] + value[NR / 2 + 1]) / 2
            p99 = value[int(0.99 * NR + 0.999999)]
            mean = sum / NR
            stdev = NR > 1 ? sqrt((sumsq - sum * sum / NR) / (NR - 1)) : 0
            printf "%s\t%s\t%s\t%d\t%.9g\t%.9g\t%.9g\t%.9g\n", workload, tool, metric, NR, median, p99, mean, stdev
        }
    ' "$values" >> "$summary"
}

median_value() {
    awk -F '\t' -v workload="$1" -v tool="$2" -v metric="$3" \
        '$1 == workload && $2 == tool && $3 == metric { print $5 }' "$summary"
}

set_commands() {
    local workload="$1"
    local ours_output="$2"
    local oracle_output="$3"
    case "$workload" in
        ordered-vcf)
            ours_command=("$binary" concat -O v -o "$ours_output" "${ordered_vcf[@]}")
            oracle_command=("$bcftools" concat --no-version -Ov -o "$oracle_output" "${ordered_vcf[@]}")
            ;;
        ordered-bcf)
            ours_command=("$binary" concat -O u -o "$ours_output" "${ordered_bcf[@]}")
            oracle_command=("$bcftools" concat --no-version -Ou -o "$oracle_output" "${ordered_bcf[@]}")
            ;;
        overlap-region)
            ours_command=("$binary" concat -a -d exact -r "$region" -O z -o "$ours_output" "$overlap_first" "$overlap_second")
            oracle_command=("$bcftools" concat --no-version -a -d exact -r "$region" -Oz -o "$oracle_output" "$overlap_first" "$overlap_second")
            ;;
        naive-vcf)
            ours_command=("$binary" concat --naive -o "$ours_output" "${naive_vcf[@]}")
            oracle_command=("$bcftools" concat --no-version --naive -o "$oracle_output" "${naive_vcf[@]}")
            ;;
        naive-bcf)
            ours_command=("$binary" concat --naive -o "$ours_output" "${naive_bcf[@]}")
            oracle_command=("$bcftools" concat --no-version --naive -o "$oracle_output" "${naive_bcf[@]}")
            ;;
        *) usage ;;
    esac
}

run_gate() {
    [[ $# -eq 4 ]] || usage
    local binary bcftools workspace repository rustc runs warmups minimum_runs minimum_warmups
    binary="$(resolve_binary "$1")"
    bcftools="$(resolve_binary "$2")"
    workspace="$(realpath "$3")"
    result_directory="$4"
    external_directory "$workspace"
    external_directory "$result_directory"
    [[ "$(uname -s)" == "Darwin" ]] || {
        echo "resource measurements are calibrated for macOS /usr/bin/time" >&2
        exit 2
    }
    require_oracle "$bcftools"
    repository="$(cd "$(dirname "$0")/.." && pwd)"
    [[ -z "$(git -C "$repository" status --porcelain)" || "${RSOMICS_BENCH_SMOKE:-0}" == 1 ]] || {
        echo "the product worktree must be clean" >&2
        exit 2
    }
    (cd "$workspace" && shasum -a 256 --check generation.sha256)
    if [[ -e "$result_directory" ]] && find "$result_directory" -mindepth 1 -print -quit | grep -q .; then
        echo "result directory must be absent or empty: $result_directory" >&2
        exit 2
    fi
    mkdir -p "$result_directory"
    result_directory="$(realpath "$result_directory")"

    runs="${BENCH_RUNS:-10}"
    warmups="${BENCH_WARMUPS:-3}"
    minimum_runs=10
    minimum_warmups=3
    if [[ "${RSOMICS_BENCH_SMOKE:-0}" == 1 ]]; then
        minimum_runs=2
        minimum_warmups=1
    fi
    [[ "$runs" =~ ^[0-9]+$ && "$runs" -ge "$minimum_runs" ]] || {
        echo "BENCH_RUNS must be an integer of at least $minimum_runs" >&2
        exit 2
    }
    [[ "$warmups" =~ ^[0-9]+$ && "$warmups" -ge "$minimum_warmups" ]] || {
        echo "BENCH_WARMUPS must be an integer of at least $minimum_warmups" >&2
        exit 2
    }

    local region
    region="$(awk -F= '$1 == "overlap_region" { print $2 }' "$workspace/generation.txt")"
    local -a ordered_vcf ordered_bcf naive_vcf naive_bcf
    ordered_vcf=("$workspace"/inputs/ordered/chunk-*.vcf)
    ordered_bcf=("$workspace"/inputs/ordered/chunk-*.bcf)
    naive_vcf=("$workspace"/inputs/ordered/chunk-*.vcf.gz)
    naive_bcf=("${ordered_bcf[@]}")
    local overlap_first="$workspace/inputs/overlap/first.vcf.gz"
    local overlap_second="$workspace/inputs/overlap/second.vcf.gz"

    local workload ours_hash oracle_hash
    local -a ours_command oracle_command
    printf 'workload\trsomics_sha256\tbcftools_sha256\n' > "$result_directory/equality.tsv"
    for workload in ordered-vcf ordered-bcf overlap-region naive-vcf naive-bcf; do
        local ours_output="$result_directory/rsomics-$workload.out"
        local oracle_output="$result_directory/bcftools-$workload.out"
        set_commands "$workload" "$ours_output" "$oracle_output"
        "${ours_command[@]}"
        "${oracle_command[@]}"
        canonicalize "$bcftools" "$ours_output" "$result_directory/rsomics-$workload.canonical.vcf"
        canonicalize "$bcftools" "$oracle_output" "$result_directory/bcftools-$workload.canonical.vcf"
        cmp "$result_directory/rsomics-$workload.canonical.vcf" \
            "$result_directory/bcftools-$workload.canonical.vcf"
        ours_hash="$(shasum -a 256 "$result_directory/rsomics-$workload.canonical.vcf" | awk '{ print $1 }')"
        oracle_hash="$(shasum -a 256 "$result_directory/bcftools-$workload.canonical.vcf" | awk '{ print $1 }')"
        printf '%s\t%s\t%s\n' "$workload" "$ours_hash" "$oracle_hash" \
            >> "$result_directory/equality.tsv"
        for ((pair = 1; pair <= warmups; pair++)); do
            if ((pair % 2)); then
                "${ours_command[@]}"
                "${oracle_command[@]}"
            else
                "${oracle_command[@]}"
                "${ours_command[@]}"
            fi
        done
    done

    raw_results="$result_directory/raw.tsv"
    printf 'workload\tpair\torder\ttool\twall_seconds\tuser_seconds\tsystem_seconds\tmax_rss_bytes\n' \
        > "$raw_results"
    for workload in ordered-vcf ordered-bcf overlap-region naive-vcf naive-bcf; do
        local ours_output="$result_directory/timed-rsomics-$workload.out"
        local oracle_output="$result_directory/timed-bcftools-$workload.out"
        set_commands "$workload" "$ours_output" "$oracle_output"
        for ((pair = 1; pair <= runs; pair++)); do
            if ((pair % 2)); then
                measure "$workload" "$pair" 1 rsomics "${ours_command[@]}"
                measure "$workload" "$pair" 2 bcftools "${oracle_command[@]}"
            else
                measure "$workload" "$pair" 1 bcftools "${oracle_command[@]}"
                measure "$workload" "$pair" 2 rsomics "${ours_command[@]}"
            fi
        done
    done

    summary="$result_directory/summary.tsv"
    printf 'workload\ttool\tmetric\tn\tmedian\tp99\tmean\tstdev\n' > "$summary"
    local tool
    for workload in ordered-vcf ordered-bcf overlap-region naive-vcf naive-bcf; do
        for tool in rsomics bcftools; do
            summarize "$workload" "$tool" 5 wall_seconds
            summarize "$workload" "$tool" 6 user_seconds
            summarize "$workload" "$tool" 7 system_seconds
            summarize "$workload" "$tool" 8 max_rss_bytes
        done
    done

    local ours_wall oracle_wall ours_rss oracle_rss decision
    printf 'workload\trsomics_wall\tbcftools_wall\twall_ratio\trsomics_rss\tbcftools_rss\trss_ratio\tdecision\n' \
        > "$result_directory/decision.tsv"
    for workload in ordered-vcf ordered-bcf overlap-region naive-vcf naive-bcf; do
        ours_wall="$(median_value "$workload" rsomics wall_seconds)"
        oracle_wall="$(median_value "$workload" bcftools wall_seconds)"
        ours_rss="$(median_value "$workload" rsomics max_rss_bytes)"
        oracle_rss="$(median_value "$workload" bcftools max_rss_bytes)"
        if [[ "${RSOMICS_BENCH_SMOKE:-0}" == 1 ]]; then
            decision=smoke
        else
            decision="$(awk -v ow="$ours_wall" -v bw="$oracle_wall" -v or="$ours_rss" -v br="$oracle_rss" \
                'BEGIN { print (ow < bw || or < br) ? "pass" : "fail" }')"
        fi
        awk -v workload="$workload" -v ow="$ours_wall" -v bw="$oracle_wall" -v or="$ours_rss" -v br="$oracle_rss" -v decision="$decision" '
            BEGIN {
                wall_ratio = bw > 0 ? ow / bw : 0
                rss_ratio = br > 0 ? or / br : 0
                printf "%s\t%.9g\t%.9g\t%.9g\t%.9g\t%.9g\t%.9g\t%s\n", workload, ow, bw, wall_ratio, or, br, rss_ratio, decision
            }
        ' >> "$result_directory/decision.tsv"
    done

    rustc="$(resolve_binary "${RSOMICS_RUSTC:-rustc}")"
    {
        printf 'utc=%s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
        uname -a
        sysctl -n hw.model
        sysctl -n machdep.cpu.brand_string
        printf 'physical_memory_bytes=%s\n' "$(sysctl -n hw.memsize)"
        sw_vers
        "$rustc" --version --verbose
        "$binary" --version
        "$bcftools" --version | sed -n '1,2p'
        printf 'git_head=%s\ngit_dirty=%s\nruns=%s\nwarmups=%s\n' \
            "$(git -C "$repository" rev-parse HEAD)" \
            "$([[ -z "$(git -C "$repository" status --porcelain)" ]] && echo false || echo true)" \
            "$runs" "$warmups"
        shasum -a 256 "$binary" "$bcftools" "$rustc" \
            "$repository/benchmarks/concat-vs-bcftools.sh" "$workspace/generation.sha256" \
            "$raw_results" "$summary" "$result_directory/decision.tsv" \
            "$result_directory/equality.tsv" \
            "$result_directory"/*.canonical.vcf
    } > "$result_directory/provenance.txt"

    if [[ "${RSOMICS_BENCH_SMOKE:-0}" != 1 ]]; then
        awk -F '\t' 'NR > 1 && $8 != "pass" { failed = 1 } END { exit failed }' \
            "$result_directory/decision.tsv"
    fi
}

case "${1:-}" in
    generate)
        shift
        generate_workload "$@"
        ;;
    run)
        shift
        run_gate "$@"
        ;;
    *) usage ;;
esac
