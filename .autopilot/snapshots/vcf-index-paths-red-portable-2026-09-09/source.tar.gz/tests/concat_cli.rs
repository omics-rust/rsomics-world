use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Output, Stdio};

const BGZF_EOF: [u8; 28] = [
    0x1f, 0x8b, 0x08, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0xff, 0x06, 0x00, 0x42, 0x43, 0x02, 0x00,
    0x1b, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
];

struct Fixture {
    _directory: tempfile::TempDir,
    first: PathBuf,
    second: PathBuf,
    conflicting_samples: PathBuf,
    regressing: PathBuf,
    overlapping: PathBuf,
    ligate_first: PathBuf,
    ligate_second: PathBuf,
}

impl Fixture {
    fn new() -> Self {
        let directory = tempfile::tempdir().unwrap();
        let first = directory.path().join("first.vcf");
        let second = directory.path().join("second.vcf");
        let conflicting_samples = directory.path().join("samples.vcf");
        let regressing = directory.path().join("regressing.vcf");
        let overlapping = directory.path().join("overlapping.vcf");
        let ligate_first = directory.path().join("ligate-first.vcf");
        let ligate_second = directory.path().join("ligate-second.vcf");
        fs::write(
            &first,
            b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Depth\">\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t10\ta\tA\tC\t.\tPASS\tDP=4\tGT\t0/1\n",
        )
        .unwrap();
        fs::write(
            &second,
            b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##contig=<ID=chr2,length=50>\n\
##FILTER=<ID=q10,Description=\"Low quality\">\n\
##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Later depth text\">\n\
##INFO=<ID=AF,Number=A,Type=Float,Description=\"Frequency\">\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t20\tb\tG\tT\t.\tq10\tDP=8;AF=0.5\tGT\t1/1\n\
chr2\t1\tc\tC\tA\t.\tPASS\tAF=0.25\tGT\t0/1\n",
        )
        .unwrap();
        fs::write(
            &conflicting_samples,
            b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS2\n\
chr1\t20\tb\tG\tT\t.\tPASS\t.\tGT\t0/1\n",
        )
        .unwrap();
        fs::write(
            &regressing,
            b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t20\tb\tG\tT\t.\tPASS\t.\tGT\t0/1\n\
chr1\t15\tc\tC\tA\t.\tPASS\t.\tGT\t0/1\n",
        )
        .unwrap();
        fs::write(
            &overlapping,
            b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Depth\">\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t5\tearly\tA\tG\t.\tPASS\tDP=2\tGT\t0/1\n\
chr1\t10\tduplicate-1\tA\tC\t.\tPASS\tDP=9\tGT\t1/1\n\
chr1\t10\twithin-1\tA\tG\t.\tPASS\tDP=10\tGT\t0/1\n\
chr1\t10\twithin-2\tA\tG\t.\tPASS\tDP=11\tGT\t1/1\n\
chr1\t15\tlater\tC\tT\t.\tPASS\tDP=3\tGT\t0/1\n",
        )
        .unwrap();
        fs::write(
            &ligate_first,
            b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\tS2\n\
chr1\t10\tl1\tA\tC\t.\tPASS\t.\tGT\t0|1\t0|0\n\
chr1\t20\tl2\tG\tT\t.\tPASS\t.\tGT\t0|1\t1|0\n\
chr1\t30\tl3\tC\tG\t.\tPASS\t.\tGT\t1|0\t0|1\n",
        )
        .unwrap();
        fs::write(
            &ligate_second,
            b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\tS2\n\
chr1\t20\tl2\tG\tT\t.\tPASS\t.\tGT\t1|0\t1|0\n\
chr1\t30\tl3\tC\tG\t.\tPASS\t.\tGT\t0|1\t0|1\n\
chr1\t40\tl4\tT\tA\t.\tPASS\t.\tGT\t1|0\t0|1\n",
        )
        .unwrap();
        Self {
            _directory: directory,
            first,
            second,
            conflicting_samples,
            regressing,
            overlapping,
            ligate_first,
            ligate_second,
        }
    }
}

fn command() -> Command {
    Command::new(env!("CARGO_BIN_EXE_rsomics-vcf"))
}

fn success(output: Output) -> Output {
    assert!(
        output.status.success(),
        "stdout={}\nstderr={}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    output
}

fn record_lines(output: &[u8]) -> Vec<&[u8]> {
    output
        .split(|byte| *byte == b'\n')
        .filter(|line| !line.is_empty() && !line.starts_with(b"#"))
        .collect()
}

fn path(path: &Path) -> &str {
    path.to_str().unwrap()
}

fn index_vcf(input: &Path, output: &Path) {
    success(
        command()
            .args(["view", "-O", "z", "-o", path(output), path(input)])
            .output()
            .unwrap(),
    );
    success(command().args(["index", path(output)]).output().unwrap());
}

fn convert(input: &Path, output: &Path, encoding: &str) {
    success(
        command()
            .args(["view", "-O", encoding, "-o", path(output), path(input)])
            .output()
            .unwrap(),
    );
}

#[test]
fn help_exposes_the_complete_family_surface() {
    let output = success(command().args(["concat", "--help"]).output().unwrap());
    let help = String::from_utf8(output.stdout).unwrap();
    for option in [
        "-f, --file-list <FILE>",
        "-a, --allow-overlaps",
        "-d, --rm-dups <MODE>",
        "-G, --drop-genotypes",
        "-l, --ligate",
        "-c, --compact-PS",
        "--ligate-force",
        "--ligate-warn",
        "-q, --min-PQ <INT>",
        "-r, --regions <REGIONS>",
        "--regions-overlap <MODE>",
        "-n, --naive",
        "-O, --output-type <TYPE>",
        "--threads <INT>",
    ] {
        assert!(help.contains(option), "missing {option} in {help}");
    }
}

#[test]
fn invalid_argument_combinations_and_output_aliases_fail_loud() {
    let fixture = Fixture::new();
    let list = fixture._directory.path().join("empty.list");
    fs::write(&list, b"\n# no inputs\n").unwrap();
    let first = path(&fixture.first);
    for arguments in [
        vec!["concat", "--file-list", path(&list), first],
        vec!["concat", "--rm-dups", "exact", first],
        vec!["concat", "--allow-overlaps", "--ligate", first],
        vec!["concat", "--ligate", "--drop-genotypes", first],
        vec!["concat", "--compact-PS", first],
        vec![
            "concat",
            "--ligate",
            "--ligate-force",
            "--ligate-warn",
            first,
        ],
        vec!["concat", "--naive", "-O", "z", first],
        vec!["concat", "--threads", "1", first],
        vec!["concat", "-", "-"],
    ] {
        let output = command().args(arguments).output().unwrap();
        assert!(!output.status.success());
    }

    let empty = command()
        .args(["concat", "--file-list", path(&list)])
        .output()
        .unwrap();
    assert!(!empty.status.success());
    assert!(String::from_utf8_lossy(&empty.stderr).contains("file list is empty"));

    let before = fs::read(&fixture.first).unwrap();
    let alias = command()
        .args([
            "concat",
            "--output",
            path(&fixture.first),
            path(&fixture.first),
        ])
        .output()
        .unwrap();
    assert!(!alias.status.success());
    assert_eq!(fs::read(&fixture.first).unwrap(), before);

    let regions = fixture._directory.path().join("regions.txt");
    fs::write(&regions, b"chr1:1-20\n").unwrap();
    let alias = command()
        .args([
            "concat",
            "--allow-overlaps",
            "--regions-file",
            path(&regions),
            "--output",
            path(&regions),
            path(&fixture.first),
        ])
        .output()
        .unwrap();
    assert!(!alias.status.success());
    assert_eq!(fs::read(&regions).unwrap(), b"chr1:1-20\n");
}

#[test]
fn ordinary_mode_merges_headers_and_streams_in_argument_order() {
    let fixture = Fixture::new();
    let output = success(
        command()
            .args(["concat", path(&fixture.first), path(&fixture.second)])
            .output()
            .unwrap(),
    );
    let text = String::from_utf8(output.stdout.clone()).unwrap();
    assert_eq!(text.matches("##INFO=<ID=DP,").count(), 1, "{text}");
    assert!(text.contains("##INFO=<ID=AF,Number=A,Type=Float"), "{text}");
    assert!(text.contains("##FILTER=<ID=q10,"), "{text}");
    assert!(text.contains("##contig=<ID=chr2,length=50>"), "{text}");
    let records = record_lines(&output.stdout);
    assert_eq!(records.len(), 3);
    assert!(records[0].starts_with(b"chr1\t10\ta\t"));
    assert!(records[1].starts_with(b"chr1\t20\tb\t"));
    assert!(records[2].starts_with(b"chr2\t1\tc\t"));
}

#[test]
fn ordinary_mode_translates_all_input_and_output_encodings() {
    let fixture = Fixture::new();
    for (case, first_encoding, second_encoding, output_encoding) in [
        ("vz-v", "v", "z", "v"),
        ("zb-z", "z", "b", "z"),
        ("bu-b", "b", "u", "b"),
        ("uv-u", "u", "v", "u"),
    ] {
        let first = fixture
            ._directory
            .path()
            .join(format!("{case}-first.variant"));
        let second = fixture
            ._directory
            .path()
            .join(format!("{case}-second.variant"));
        let output_path = fixture
            ._directory
            .path()
            .join(format!("{case}-output.variant"));
        convert(&fixture.first, &first, first_encoding);
        convert(&fixture.second, &second, second_encoding);
        let mut concat = command();
        concat.args(["concat", "-O", output_encoding, "-o", path(&output_path)]);
        if matches!(output_encoding, "z" | "b") {
            concat.args(["--threads", "2"]);
        }
        success(concat.args([path(&first), path(&second)]).output().unwrap());
        let decoded = success(
            command()
                .args(["view", "-O", "v", path(&output_path)])
                .output()
                .unwrap(),
        );
        let text = String::from_utf8(decoded.stdout).unwrap();
        assert_eq!(
            text.lines().filter(|line| !line.starts_with('#')).count(),
            3,
            "{case}: {text}"
        );
        assert!(text.contains("AF=0.5"), "{case}: {text}");
        assert!(
            text.contains("##INFO=<ID=AF,Number=A,Type=Float"),
            "{case}: {text}"
        );
    }
}

#[test]
fn ordinary_mode_retains_one_standard_input_after_header_preflight() {
    let fixture = Fixture::new();
    let mut child = command()
        .args(["concat", "-", path(&fixture.second)])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap();
    child
        .stdin
        .take()
        .unwrap()
        .write_all(&fs::read(&fixture.first).unwrap())
        .unwrap();
    let output = success(child.wait_with_output().unwrap());
    assert_eq!(record_lines(&output.stdout).len(), 3);
}

#[test]
fn file_list_ignores_blank_and_comment_lines() {
    let fixture = Fixture::new();
    let list = fixture._directory.path().join("inputs.list");
    fs::write(
        &list,
        format!(
            "  # chunks\n\n{}\n  {}  \n",
            fixture.first.display(),
            fixture.second.display()
        ),
    )
    .unwrap();
    let output = success(
        command()
            .args(["concat", "--file-list", path(&list)])
            .output()
            .unwrap(),
    );
    assert_eq!(record_lines(&output.stdout).len(), 3);
}

#[test]
fn incompatible_samples_fail_before_named_output_is_replaced() {
    let fixture = Fixture::new();
    let output_path = fixture._directory.path().join("output.vcf");
    fs::write(&output_path, b"existing").unwrap();
    let output = command()
        .args([
            "concat",
            "--output",
            path(&output_path),
            path(&fixture.first),
            path(&fixture.conflicting_samples),
        ])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert!(output.stdout.is_empty());
    assert_eq!(fs::read(output_path).unwrap(), b"existing");
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("sample"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn semantic_header_conflicts_fail_before_named_output_is_replaced() {
    let fixture = Fixture::new();
    let base = fixture._directory.path().join("header-base.vcf");
    let output_path = fixture._directory.path().join("header-output.vcf");
    let document = |contig: usize, info: &str, format_type: &str, filter: &str, sample: &str| {
        format!(
            "##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length={contig}>\n\
##INFO=<ID=X,Number=1,Type={info},Description=\"X\">\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
##FORMAT=<ID=X,Number=1,Type={format_type},Description=\"X\">\n\
##FILTER=<ID=q10,Description=\"{filter}\">\n\
##SAMPLE=<ID=S,Description=\"{sample}\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n"
        )
    };
    fs::write(&base, document(100, "Integer", "Integer", "low", "base")).unwrap();
    for (name, source) in [
        ("contig", document(101, "Integer", "Integer", "low", "base")),
        ("info", document(100, "Float", "Integer", "low", "base")),
        ("format", document(100, "Integer", "Float", "low", "base")),
        (
            "filter",
            document(100, "Integer", "Integer", "other", "base"),
        ),
        (
            "structured",
            document(100, "Integer", "Integer", "low", "other"),
        ),
    ] {
        let conflict = fixture._directory.path().join(format!("header-{name}.vcf"));
        fs::write(&conflict, source).unwrap();
        fs::write(&output_path, b"existing").unwrap();
        let output = command()
            .args([
                "concat",
                "--output",
                path(&output_path),
                path(&base),
                path(&conflict),
            ])
            .output()
            .unwrap();
        assert!(!output.status.success(), "{name}");
        assert_eq!(fs::read(&output_path).unwrap(), b"existing", "{name}");
        assert!(
            String::from_utf8_lossy(&output.stderr).contains("header conflict"),
            "{name}: {}",
            String::from_utf8_lossy(&output.stderr)
        );
    }
}

#[test]
fn coordinate_regression_fails_loud() {
    let fixture = Fixture::new();
    let output_path = fixture._directory.path().join("regression-output.vcf");
    fs::write(&output_path, b"existing").unwrap();
    let output = command()
        .args([
            "concat",
            "--output",
            path(&output_path),
            path(&fixture.first),
            path(&fixture.regressing),
        ])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert_eq!(fs::read(output_path).unwrap(), b"existing");
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("coordinate sorted"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn malformed_records_fail_without_replacing_named_output() {
    let fixture = Fixture::new();
    let malformed = fixture._directory.path().join("malformed.vcf");
    let output_path = fixture._directory.path().join("malformed-output.vcf");
    fs::write(
        &malformed,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\tbad\tbroken\tA\tC\t.\tPASS\t.\tGT\t0/1\n",
    )
    .unwrap();
    fs::write(&output_path, b"existing").unwrap();
    let output = command()
        .args([
            "concat",
            "--output",
            path(&output_path),
            path(&fixture.first),
            path(&malformed),
        ])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert_eq!(fs::read(&output_path).unwrap(), b"existing");
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("record 1"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn json_requires_named_variant_output() {
    let fixture = Fixture::new();
    let output = command()
        .args(["--json", "concat", path(&fixture.first)])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert!(output.stdout.is_empty());
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("--json requires --output"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn overlap_mode_performs_a_stable_coordinate_merge() {
    let fixture = Fixture::new();
    let output = success(
        command()
            .args([
                "concat",
                "--allow-overlaps",
                path(&fixture.first),
                path(&fixture.overlapping),
            ])
            .output()
            .unwrap(),
    );
    let records = record_lines(&output.stdout);
    let keys: Vec<_> = records
        .iter()
        .map(|record| {
            let fields: Vec<_> = record.split(|byte| *byte == b'\t').collect();
            (fields[1], fields[2])
        })
        .collect();
    assert_eq!(
        keys,
        [
            (b"5".as_slice(), b"early".as_slice()),
            (b"10".as_slice(), b"a".as_slice()),
            (b"10".as_slice(), b"duplicate-1".as_slice()),
            (b"10".as_slice(), b"within-1".as_slice()),
            (b"10".as_slice(), b"within-2".as_slice()),
            (b"15".as_slice(), b"later".as_slice()),
        ]
    );
}

#[test]
fn exact_duplicate_removal_is_cross_input_only_and_first_wins() {
    let fixture = Fixture::new();
    let output_path = fixture._directory.path().join("deduplicated.vcf");
    let output = success(
        command()
            .args([
                "--json",
                "concat",
                "--allow-overlaps",
                "--rm-dups",
                "exact",
                "--output",
                path(&output_path),
                path(&fixture.first),
                path(&fixture.overlapping),
            ])
            .output()
            .unwrap(),
    );
    let records = fs::read(output_path).unwrap();
    let records = record_lines(&records);
    assert_eq!(records.len(), 5);
    let text = records
        .iter()
        .map(|record| String::from_utf8_lossy(record))
        .collect::<Vec<_>>()
        .join("\n");
    assert!(text.contains("within-1"), "{text}");
    assert!(text.contains("within-2"), "{text}");
    assert!(!text.contains("duplicate-1"), "{text}");
    let envelope: serde_json::Value = serde_json::from_slice(&output.stdout).unwrap();
    assert_eq!(envelope["result"]["summary"]["records_read"], 6);
    assert_eq!(envelope["result"]["summary"]["records_written"], 5);
    assert_eq!(envelope["result"]["summary"]["duplicates_removed"], 1);
}

#[test]
fn relaxed_duplicate_matching_is_one_to_one_and_prefers_exact_alleles() {
    let fixture = Fixture::new();
    for mode in ["snps", "both", "all"] {
        let output = success(
            command()
                .args([
                    "concat",
                    "--allow-overlaps",
                    "--rm-dups",
                    mode,
                    path(&fixture.first),
                    path(&fixture.overlapping),
                ])
                .output()
                .unwrap(),
        );
        let text = String::from_utf8(output.stdout).unwrap();
        assert_eq!(
            text.lines().filter(|line| !line.starts_with('#')).count(),
            5
        );
        assert!(!text.contains("duplicate-1"), "{mode}: {text}");
        assert!(text.contains("within-1"), "{mode}: {text}");
        assert!(text.contains("within-2"), "{mode}: {text}");
    }
}

#[test]
fn every_duplicate_mode_has_a_distinct_cross_input_contract() {
    let fixture = Fixture::new();
    let first = fixture._directory.path().join("dups-first.vcf");
    let second = fixture._directory.path().join("dups-second.vcf");
    let header = "##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\n";
    fs::write(
        &first,
        format!(
            "{header}chr1\t10\ta-exact\tA\tC\t.\tPASS\t.\n\
chr1\t10\ta-snp\tA\tG\t.\tPASS\t.\n\
chr1\t10\ta-indel\tA\tAT\t.\tPASS\t.\n"
        ),
    )
    .unwrap();
    fs::write(
        &second,
        format!(
            "{header}chr1\t10\tb-exact\tA\tC\t.\tPASS\t.\n\
chr1\t10\tb-snp\tA\tT\t.\tPASS\t.\n\
chr1\t10\tb-indel\tA\tAG\t.\tPASS\t.\n"
        ),
    )
    .unwrap();

    for (mode, expected) in [
        ("exact", 5),
        ("snps", 4),
        ("indels", 4),
        ("both", 3),
        ("all", 3),
    ] {
        let output = success(
            command()
                .args([
                    "concat",
                    "--allow-overlaps",
                    "--rm-dups",
                    mode,
                    path(&first),
                    path(&second),
                ])
                .output()
                .unwrap(),
        );
        assert_eq!(record_lines(&output.stdout).len(), expected, "{mode}");
    }
}

#[test]
fn overlap_mode_rejects_standard_input_and_unsorted_sources() {
    let fixture = Fixture::new();
    let stdin = command()
        .args(["concat", "--allow-overlaps", "-", path(&fixture.first)])
        .output()
        .unwrap();
    assert!(!stdin.status.success());
    assert!(
        String::from_utf8_lossy(&stdin.stderr).contains("named inputs"),
        "{}",
        String::from_utf8_lossy(&stdin.stderr)
    );

    let unsorted = command()
        .args([
            "concat",
            "--allow-overlaps",
            path(&fixture.first),
            path(&fixture.regressing),
        ])
        .output()
        .unwrap();
    assert!(!unsorted.status.success());
    assert!(
        String::from_utf8_lossy(&unsorted.stderr).contains("coordinate sorted"),
        "{}",
        String::from_utf8_lossy(&unsorted.stderr)
    );
}

#[test]
fn drop_genotypes_removes_format_schema_and_sample_values() {
    let fixture = Fixture::new();
    let first = fixture._directory.path().join("drop-first.vcf");
    let incompatible = fixture
        ._directory
        .path()
        .join("drop-incompatible-format.vcf");
    fs::write(
        &first,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
##FORMAT=<ID=X,Number=1,Type=Integer,Description=\"Integer field\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t10\ta\tA\tC\t.\tPASS\tDP=4\tGT:X\t0/1:1\n",
    )
    .unwrap();
    fs::write(
        &incompatible,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
##FORMAT=<ID=X,Number=1,Type=Float,Description=\"Float field\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS2\n\
chr1\t20\tb\tG\tT\t.\tPASS\t.\tGT:X\t1/1:0.5\n",
    )
    .unwrap();
    let output = success(
        command()
            .args([
                "concat",
                "--drop-genotypes",
                path(&first),
                path(&incompatible),
            ])
            .output()
            .unwrap(),
    );
    let text = String::from_utf8(output.stdout).unwrap();
    assert!(!text.contains("##FORMAT="), "{text}");
    let chrom = text
        .lines()
        .find(|line| line.starts_with("#CHROM"))
        .unwrap();
    assert_eq!(chrom.split('\t').count(), 8);
    assert!(
        text.lines()
            .filter(|line| !line.starts_with('#'))
            .all(|line| line.split('\t').count() == 8)
    );
}

#[test]
fn indexed_regions_are_merged_across_every_input() {
    let fixture = Fixture::new();
    let first = fixture._directory.path().join("first.vcf.gz");
    let second = fixture._directory.path().join("overlap.vcf.gz");
    index_vcf(&fixture.first, &first);
    index_vcf(&fixture.overlapping, &second);
    let output = success(
        command()
            .args([
                "concat",
                "--allow-overlaps",
                "--regions",
                "chr1:10-10",
                path(&first),
                path(&second),
            ])
            .output()
            .unwrap(),
    );
    let records = record_lines(&output.stdout);
    assert_eq!(records.len(), 4);
    assert!(records.iter().all(|record| {
        record
            .split(|byte| *byte == b'\t')
            .nth(1)
            .is_some_and(|position| position == b"10")
    }));
}

#[test]
fn indexed_regions_reject_an_index_older_than_replaced_input() {
    let fixture = Fixture::new();
    let source = fixture._directory.path().join("stale-source.vcf");
    let indexed = fixture._directory.path().join("stale.vcf.gz");
    index_vcf(&fixture.first, &indexed);
    fs::write(
        &source,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Depth\">\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t10\ta\tA\tC\t.\tPASS\tDP=4\tGT\t0/1\n\
chr1\t11\tnew\tG\tT\t.\tPASS\tDP=5\tGT\t0/1\n",
    )
    .unwrap();
    std::thread::sleep(std::time::Duration::from_millis(10));
    convert(&source, &indexed, "z");
    let output = command()
        .args([
            "concat",
            "--allow-overlaps",
            "--regions",
            "chr1:10-11",
            path(&indexed),
        ])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("index is older than its input"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn ligation_reconciles_phase_and_emits_pq_ps() {
    let fixture = Fixture::new();
    let first = fixture._directory.path().join("ligate-first.vcf.gz");
    let second = fixture._directory.path().join("ligate-second.vcf.gz");
    index_vcf(&fixture.ligate_first, &first);
    index_vcf(&fixture.ligate_second, &second);
    let output = success(
        command()
            .args(["concat", "--ligate", path(&first), path(&second)])
            .output()
            .unwrap(),
    );
    let text = String::from_utf8(output.stdout).unwrap();
    assert!(
        text.contains("##FORMAT=<ID=PQ,Number=1,Type=Integer"),
        "{text}"
    );
    assert!(
        text.contains("##FORMAT=<ID=PS,Number=1,Type=Integer"),
        "{text}"
    );
    assert!(
        text.contains("chr1\t30\tl3\tC\tG\t.\tPASS\t.\tGT:PQ:PS\t1|0:99:10\t0|1:99:10"),
        "{text}"
    );
    assert!(
        text.contains("chr1\t40\tl4\tT\tA\t.\tPASS\t.\tGT:PS\t0|1:10\t0|1:10"),
        "{text}"
    );

    let compact = success(
        command()
            .args([
                "concat",
                "--ligate",
                "--compact-PS",
                path(&first),
                path(&second),
            ])
            .output()
            .unwrap(),
    );
    let compact = String::from_utf8(compact.stdout).unwrap();
    assert!(
        compact.contains("chr1\t10\tl1\tA\tC\t.\tPASS\t.\tGT:PS"),
        "{compact}"
    );
    assert!(
        compact.contains("chr1\t30\tl3\tC\tG\t.\tPASS\t.\tGT:PQ"),
        "{compact}"
    );
    assert!(
        compact.contains("chr1\t40\tl4\tT\tA\t.\tPASS\t.\tGT\t"),
        "{compact}"
    );
}

#[test]
fn ligation_rejects_incompatible_phase_format_definitions_atomically() {
    let fixture = Fixture::new();
    let first_source = fixture._directory.path().join("invalid-pq.vcf");
    let output_path = fixture._directory.path().join("phase-output.vcf");
    fs::write(
        &first_source,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
##FORMAT=<ID=PQ,Number=1,Type=Float,Description=\"Wrong type\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\tS2\n\
chr1\t10\tl1\tA\tC\t.\tPASS\t.\tGT:PQ\t0|1:.\t0|0:.\n\
chr1\t20\tl2\tG\tT\t.\tPASS\t.\tGT:PQ\t0|1:.\t1|0:.\n",
    )
    .unwrap();
    fs::write(&output_path, b"existing").unwrap();
    let output = command()
        .args([
            "concat",
            "--ligate",
            "--output",
            path(&output_path),
            path(&first_source),
            path(&fixture.ligate_second),
        ])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert_eq!(fs::read(&output_path).unwrap(), b"existing");
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("parsing VCF header"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn ligate_force_keeps_disjoint_chunks_in_order() {
    let fixture = Fixture::new();
    let left_source = fixture._directory.path().join("disjoint-left.vcf");
    let right_source = fixture._directory.path().join("disjoint-right.vcf");
    let left = fixture._directory.path().join("disjoint-left.vcf.gz");
    let right = fixture._directory.path().join("disjoint-right.vcf.gz");
    let header = "##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n";
    fs::write(
        &left_source,
        format!(
            "{header}chr1\t10\tleft-a\tA\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t20\tleft-b\tG\tT\t.\tPASS\t.\tGT\t1|0\n"
        ),
    )
    .unwrap();
    fs::write(
        &right_source,
        format!(
            "{header}chr1\t30\tright-a\tC\tG\t.\tPASS\t.\tGT\t0|1\n\
chr1\t40\tright-b\tT\tA\t.\tPASS\t.\tGT\t1|0\n"
        ),
    )
    .unwrap();
    index_vcf(&left_source, &left);
    index_vcf(&right_source, &right);

    let rejected = command()
        .args(["concat", "--ligate", path(&left), path(&right)])
        .output()
        .unwrap();
    assert!(!rejected.status.success());

    let forced = success(
        command()
            .args([
                "concat",
                "--ligate",
                "--ligate-force",
                path(&left),
                path(&right),
            ])
            .output()
            .unwrap(),
    );
    let ids: Vec<_> = record_lines(&forced.stdout)
        .into_iter()
        .map(|record| record.split(|byte| *byte == b'\t').nth(2).unwrap())
        .collect();
    assert_eq!(
        ids,
        [
            b"left-a".as_slice(),
            b"left-b".as_slice(),
            b"right-a".as_slice(),
            b"right-b".as_slice(),
        ]
    );
}

#[test]
fn imperfect_ligation_has_distinct_error_warn_and_force_policies() {
    let fixture = Fixture::new();
    let first = fixture._directory.path().join("imperfect-first.vcf.gz");
    let second_source = fixture._directory.path().join("imperfect-second.vcf");
    let second = fixture._directory.path().join("imperfect-second.vcf.gz");
    index_vcf(&fixture.ligate_first, &first);
    fs::write(
        &second_source,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\tS2\n\
chr1\t20\tl2\tG\tT\t.\tPASS\t.\tGT\t1|0\t1|0\n\
chr1\t25\textra\tA\tG\t.\tPASS\t.\tGT\t1|0\t0|1\n\
chr1\t30\tl3\tC\tG\t.\tPASS\t.\tGT\t0|1\t0|1\n\
chr1\t40\tl4\tT\tA\t.\tPASS\t.\tGT\t1|0\t0|1\n",
    )
    .unwrap();
    index_vcf(&second_source, &second);

    let rejected = command()
        .args(["concat", "--ligate", path(&first), path(&second)])
        .output()
        .unwrap();
    assert!(!rejected.status.success());
    assert!(
        String::from_utf8_lossy(&rejected.stderr).contains("perfect overlap"),
        "{}",
        String::from_utf8_lossy(&rejected.stderr)
    );

    let warned = success(
        command()
            .args([
                "concat",
                "--ligate",
                "--ligate-warn",
                path(&first),
                path(&second),
            ])
            .output()
            .unwrap(),
    );
    assert!(!String::from_utf8_lossy(&warned.stdout).contains("\textra\t"));
    assert!(
        String::from_utf8_lossy(&warned.stderr)
            .contains("warning: dropped 1 unpaired overlap record during ligation")
    );

    let warned_path = fixture._directory.path().join("warned.vcf");
    let warned_json = success(
        command()
            .args([
                "--json",
                "concat",
                "--ligate",
                "--ligate-warn",
                "--output",
                path(&warned_path),
                path(&first),
                path(&second),
            ])
            .output()
            .unwrap(),
    );
    assert!(warned_json.stderr.is_empty());
    let envelope: serde_json::Value = serde_json::from_slice(&warned_json.stdout).unwrap();
    assert_eq!(envelope["result"]["summary"]["overlap_records_dropped"], 1);

    let forced = success(
        command()
            .args([
                "concat",
                "--ligate",
                "--ligate-force",
                path(&first),
                path(&second),
            ])
            .output()
            .unwrap(),
    );
    assert!(String::from_utf8_lossy(&forced.stdout).contains("\textra\t"));
}

#[test]
fn ligation_matches_same_coordinate_variants_by_alleles() {
    let fixture = Fixture::new();
    let left_source = fixture._directory.path().join("ligate-multi-left.vcf");
    let right_source = fixture._directory.path().join("ligate-multi-right.vcf");
    let left = fixture._directory.path().join("ligate-multi-left.vcf.gz");
    let right = fixture._directory.path().join("ligate-multi-right.vcf.gz");
    fs::write(
        &left_source,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t10\tleft-start\tT\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t20\tleft-c\tA\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t20\tleft-g\tA\tG\t.\tPASS\t.\tGT\t1|0\n\
chr1\t30\tleft-end\tG\tT\t.\tPASS\t.\tGT\t0|1\n",
    )
    .unwrap();
    fs::write(
        &right_source,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t20\tright-g\tA\tG\t.\tPASS\t.\tGT\t1|0\n\
chr1\t20\tright-c\tA\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t30\tright-end\tG\tT\t.\tPASS\t.\tGT\t0|1\n\
chr1\t40\tright-tail\tC\tA\t.\tPASS\t.\tGT\t0|1\n",
    )
    .unwrap();
    index_vcf(&left_source, &left);
    index_vcf(&right_source, &right);

    let output = success(
        command()
            .args(["concat", "--ligate", path(&left), path(&right)])
            .output()
            .unwrap(),
    );
    let ids: Vec<_> = record_lines(&output.stdout)
        .iter()
        .map(|line| line.split(|byte| *byte == b'\t').nth(2).unwrap())
        .collect();
    assert_eq!(
        ids,
        [
            b"left-start".as_slice(),
            b"left-c".as_slice(),
            b"left-g".as_slice(),
            b"right-end".as_slice(),
            b"right-tail".as_slice(),
        ]
    );
}

#[test]
fn ligation_rejects_corrupt_indexes_and_regressing_chunk_starts() {
    let fixture = Fixture::new();
    let first = fixture._directory.path().join("ligate-index-first.vcf.gz");
    let second = fixture._directory.path().join("ligate-index-second.vcf.gz");
    let output_path = fixture._directory.path().join("ligate-output.vcf");
    index_vcf(&fixture.ligate_first, &first);
    index_vcf(&fixture.ligate_second, &second);
    fs::write(format!("{}.csi", second.display()), b"not an index").unwrap();
    fs::write(&output_path, b"existing").unwrap();
    let corrupt = command()
        .args([
            "concat",
            "--ligate",
            "--output",
            path(&output_path),
            path(&first),
            path(&second),
        ])
        .output()
        .unwrap();
    assert!(!corrupt.status.success());
    assert_eq!(fs::read(&output_path).unwrap(), b"existing");
    assert!(
        String::from_utf8_lossy(&corrupt.stderr).contains("valid CSI or TBI index"),
        "{}",
        String::from_utf8_lossy(&corrupt.stderr)
    );

    let late_source = fixture._directory.path().join("ligate-late.vcf");
    let early_source = fixture._directory.path().join("ligate-early.vcf");
    let late = fixture._directory.path().join("ligate-late.vcf.gz");
    let early = fixture._directory.path().join("ligate-early.vcf.gz");
    let header = "##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n";
    fs::write(
        &late_source,
        format!(
            "{header}chr1\t20\tshared\tA\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t30\ttail\tG\tT\t.\tPASS\t.\tGT\t0|1\n"
        ),
    )
    .unwrap();
    fs::write(
        &early_source,
        format!(
            "{header}chr1\t10\tearly\tC\tG\t.\tPASS\t.\tGT\t0|1\n\
chr1\t20\tshared\tA\tC\t.\tPASS\t.\tGT\t0|1\n"
        ),
    )
    .unwrap();
    index_vcf(&late_source, &late);
    index_vcf(&early_source, &early);
    let regressing = command()
        .args([
            "concat",
            "--ligate",
            "--ligate-force",
            path(&late),
            path(&early),
        ])
        .output()
        .unwrap();
    assert!(!regressing.status.success());
    assert!(
        String::from_utf8_lossy(&regressing.stderr).contains("chunk order regresses"),
        "{}",
        String::from_utf8_lossy(&regressing.stderr)
    );
}

#[test]
fn ligation_ties_preserve_orientation_and_min_pq_controls_phase_sets() {
    let fixture = Fixture::new();
    let left_source = fixture._directory.path().join("ligate-tie-left.vcf");
    let right_source = fixture._directory.path().join("ligate-tie-right.vcf");
    let left = fixture._directory.path().join("ligate-tie-left.vcf.gz");
    let right = fixture._directory.path().join("ligate-tie-right.vcf.gz");
    let header = "##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n";
    fs::write(
        &left_source,
        format!(
            "{header}chr1\t10\tl1\tT\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t20\tl2\tA\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t30\tl3\tG\tT\t.\tPASS\t.\tGT\t0|1\n"
        ),
    )
    .unwrap();
    fs::write(
        &right_source,
        format!(
            "{header}chr1\t20\tr2\tA\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t30\tr3\tG\tT\t.\tPASS\t.\tGT\t1|0\n\
chr1\t40\tr4\tC\tA\t.\tPASS\t.\tGT\t0|1\n"
        ),
    )
    .unwrap();
    index_vcf(&left_source, &left);
    index_vcf(&right_source, &right);

    let default = success(
        command()
            .args(["concat", "--ligate", path(&left), path(&right)])
            .output()
            .unwrap(),
    );
    let default = String::from_utf8(default.stdout).unwrap();
    assert!(default.contains("chr1\t30\tr3\tG\tT\t.\tPASS\t.\tGT:PQ:PS\t1|0:0:30"));
    assert!(default.contains("chr1\t40\tr4\tC\tA\t.\tPASS\t.\tGT:PS\t0|1:30"));

    for threshold in ["0", "4294967295"] {
        let output = success(
            command()
                .args([
                    "concat",
                    "--ligate",
                    "--min-PQ",
                    threshold,
                    path(&left),
                    path(&right),
                ])
                .output()
                .unwrap(),
        );
        let output = String::from_utf8(output.stdout).unwrap();
        let expected = if threshold == "0" { ":0:10" } else { ":0:30" };
        assert!(output.contains(expected), "threshold={threshold}: {output}");
    }
}

#[test]
fn naive_mode_splices_compatible_bgzf_vcf_and_bcf() {
    let fixture = Fixture::new();
    let compatible = fixture._directory.path().join("naive-compatible.vcf");
    fs::write(
        &compatible,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Depth\">\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t20\tb\tG\tT\t.\tPASS\tDP=8\tGT\t1/1\n",
    )
    .unwrap();
    for (encoding, suffix) in [("z", "vcf.gz"), ("b", "bcf")] {
        let first = fixture
            ._directory
            .path()
            .join(format!("naive-first.{suffix}"));
        let second = fixture
            ._directory
            .path()
            .join(format!("naive-second.{suffix}"));
        let output_path = fixture
            ._directory
            .path()
            .join(format!("naive-output.{suffix}"));
        convert(&fixture.first, &first, encoding);
        convert(&compatible, &second, encoding);
        let output = success(
            command()
                .args(["concat", "--naive", path(&first), path(&second)])
                .output()
                .unwrap(),
        );
        assert!(output.stdout.ends_with(&BGZF_EOF));
        assert_eq!(
            output
                .stdout
                .windows(BGZF_EOF.len())
                .filter(|window| *window == BGZF_EOF)
                .count(),
            1
        );
        fs::write(&output_path, &output.stdout).unwrap();
        let decoded = success(
            command()
                .args(["view", "-O", "v", path(&output_path)])
                .output()
                .unwrap(),
        );
        assert_eq!(record_lines(&decoded.stdout).len(), 2, "{suffix}");
    }
}

#[test]
fn naive_corrupt_frame_fails_before_replacing_output() {
    let fixture = Fixture::new();
    let first = fixture._directory.path().join("naive-first.vcf.gz");
    let output_path = fixture._directory.path().join("naive-output.vcf.gz");
    convert(&fixture.first, &first, "z");
    let valid = fs::read(&first).unwrap();
    let mut corruptions = Vec::new();
    let mut crc = valid.clone();
    let frame_len = usize::from(u16::from_le_bytes([crc[16], crc[17]])) + 1;
    crc[frame_len - 8] ^= 0xff;
    corruptions.push(("crc", crc));
    corruptions.push((
        "missing-eof",
        valid[..valid.len() - BGZF_EOF.len()].to_vec(),
    ));
    let mut repeated_eof = valid.clone();
    repeated_eof.extend_from_slice(&BGZF_EOF);
    corruptions.push(("repeated-eof", repeated_eof));
    let mut trailing = valid.clone();
    trailing.push(0);
    corruptions.push(("trailing", trailing));
    corruptions.push((
        "partial-frame",
        valid[..valid.len() - BGZF_EOF.len() - 1].to_vec(),
    ));
    let mut invalid_size = valid;
    invalid_size[16..18].copy_from_slice(&0u16.to_le_bytes());
    corruptions.push(("invalid-size", invalid_size));

    for (name, bytes) in corruptions {
        let corrupt = fixture
            ._directory
            .path()
            .join(format!("naive-corrupt-{name}.vcf.gz"));
        fs::write(&corrupt, bytes).unwrap();
        fs::write(&output_path, b"existing").unwrap();
        let output = command()
            .args([
                "concat",
                "--naive",
                "--output",
                path(&output_path),
                path(&first),
                path(&corrupt),
            ])
            .output()
            .unwrap();
        assert!(!output.status.success(), "{name}");
        assert_eq!(fs::read(&output_path).unwrap(), b"existing", "{name}");
        assert!(
            String::from_utf8_lossy(&output.stderr).contains("BGZF"),
            "{name}: {}",
            String::from_utf8_lossy(&output.stderr)
        );
    }
}

#[test]
fn naive_rejects_mixed_vcf_and_bcf_before_stdout() {
    let fixture = Fixture::new();
    let vcf = fixture._directory.path().join("naive.vcf.gz");
    let bcf = fixture._directory.path().join("naive.bcf");
    convert(&fixture.first, &vcf, "z");
    convert(&fixture.second, &bcf, "b");
    let output = command()
        .args(["concat", "--naive", path(&vcf), path(&bcf)])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert!(output.stdout.is_empty());
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("cannot mix BGZF VCF and BCF"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn naive_header_conflict_fails_before_replacing_output() {
    let fixture = Fixture::new();
    let conflict_source = fixture._directory.path().join("naive-conflict.vcf");
    let first = fixture._directory.path().join("naive-first.vcf.gz");
    let conflict = fixture._directory.path().join("naive-conflict.vcf.gz");
    let output_path = fixture._directory.path().join("naive-output.vcf.gz");
    fs::write(
        &conflict_source,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=101>\n\
##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Depth\">\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t20\tb\tG\tT\t.\tPASS\tDP=8\tGT\t1/1\n",
    )
    .unwrap();
    convert(&fixture.first, &first, "z");
    convert(&conflict_source, &conflict, "z");
    fs::write(&output_path, b"existing").unwrap();
    let output = command()
        .args([
            "concat",
            "--naive",
            "--output",
            path(&output_path),
            path(&first),
            path(&conflict),
        ])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert_eq!(fs::read(output_path).unwrap(), b"existing");
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("header"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}
