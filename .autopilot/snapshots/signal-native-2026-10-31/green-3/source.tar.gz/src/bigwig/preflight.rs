use crate::model::invalid;
use rsomics_common::Result;
use std::{
    fs::File,
    io::{Read, Seek, SeekFrom},
};

const MEMORY_LIMIT: u64 = 16 * 1024 * 1024;
const MAX_CHROMS: u64 = 262144;
const MAX_KEY: u64 = 4096;
const MAX_DEPTH: usize = 32;
const MAX_NODES: u64 = 1000000;
const MAX_ENTRIES: u64 = 8000000;

#[derive(Clone, Copy)]
enum Endian {
    Little,
    Big,
}
impl Endian {
    fn u16(self, b: [u8; 2]) -> u16 {
        match self {
            Self::Little => u16::from_le_bytes(b),
            Self::Big => u16::from_be_bytes(b),
        }
    }
    fn u32(self, b: [u8; 4]) -> u32 {
        match self {
            Self::Little => u32::from_le_bytes(b),
            Self::Big => u32::from_be_bytes(b),
        }
    }
    fn u64(self, b: [u8; 8]) -> u64 {
        match self {
            Self::Little => u64::from_le_bytes(b),
            Self::Big => u64::from_be_bytes(b),
        }
    }
}

#[derive(Clone, Copy)]
enum Tree {
    Chromosomes { key: u64 },
    Intervals,
}
struct Node {
    offset: u64,
    next: u64,
    remaining: u16,
    leaf: bool,
    width: u64,
}
struct Admission<'a> {
    file: &'a mut File,
    length: u64,
    endian: Endian,
    header_end: u64,
    nodes: u64,
    entries: u64,
    dictionary_bytes: u64,
}
impl Admission<'_> {
    fn extent(&self, offset: u64, size: u64) -> Result<()> {
        if offset.checked_add(size).is_none_or(|end| end > self.length) {
            return Err(invalid("bigWig structural extent exceeds the file"));
        }
        Ok(())
    }
    fn read<const N: usize>(&mut self, offset: u64) -> Result<[u8; N]> {
        self.extent(offset, N as u64)?;
        self.file.seek(SeekFrom::Start(offset))?;
        let mut data = [0; N];
        self.file.read_exact(&mut data)?;
        Ok(data)
    }
    fn structure(&self, offset: u64, size: u64) -> Result<()> {
        if offset < self.header_end {
            return Err(invalid("bigWig structural offset overlaps the file header"));
        }
        self.extent(offset, size)
    }
    fn node(&mut self, offset: u64, tree: Tree, block_size: u32) -> Result<Node> {
        self.structure(offset, 4)?;
        self.nodes += 1;
        if self.nodes > MAX_NODES {
            return Err(invalid(
                "bigWig index exceeds the private 1000000-node budget",
            ));
        }
        let bytes = self.read::<4>(offset)?;
        let count = self.endian.u16([bytes[2], bytes[3]]);
        if bytes[0] > 1 || u32::from(count) > block_size || (bytes[0] == 0 && count == 0) {
            return Err(invalid("invalid bigWig index node type/count"));
        }
        let leaf = bytes[0] == 1;
        let width = match tree {
            Tree::Chromosomes { key } => key + 8,
            Tree::Intervals if leaf => 32,
            Tree::Intervals => 24,
        };
        let size = width * u64::from(count);
        self.extent(offset + 4, size)?;
        if matches!(tree, Tree::Chromosomes { .. }) {
            self.dictionary_bytes += size;
            if self.dictionary_bytes > MEMORY_LIMIT {
                return Err(invalid(
                    "bigWig chromosome tree exceeds the private 16 MiB budget",
                ));
            }
        } else if !leaf {
            // The pinned reader buffers 32 bytes per internal entry before parsing its 24-byte records.
            self.extent(offset + 4, 32 * u64::from(count))?;
        }
        Ok(Node {
            offset,
            next: offset + 4,
            remaining: count,
            leaf,
            width,
        })
    }
    fn walk(&mut self, root: u64, tree: Tree, block_size: u32) -> Result<u64> {
        let mut stack = vec![self.node(root, tree, block_size)?];
        let mut leaves = 0u64;
        while let Some(node) = stack.last_mut() {
            if node.remaining == 0 {
                stack.pop();
                continue;
            }
            let offset = node.next;
            let leaf = node.leaf;
            node.next += node.width;
            node.remaining -= 1;
            self.entries += 1;
            if self.entries > MAX_ENTRIES {
                return Err(invalid(
                    "bigWig index exceeds the private 8000000-entry budget",
                ));
            }
            let child = match tree {
                Tree::Chromosomes { key } => {
                    let value = self.read::<8>(offset + key)?;
                    if leaf {
                        leaves += 1;
                        None
                    } else {
                        Some(self.endian.u64(value))
                    }
                }
                Tree::Intervals if leaf => {
                    let value = self.read::<16>(offset + 16)?;
                    let data = self.endian.u64(value[..8].try_into().unwrap());
                    let size = self.endian.u64(value[8..].try_into().unwrap());
                    if size == 0 || size > MEMORY_LIMIT {
                        return Err(invalid(
                            "bigWig data block exceeds the private 16 MiB budget or is empty",
                        ));
                    }
                    self.structure(data, size)?;
                    leaves += 1;
                    None
                }
                Tree::Intervals => Some(self.endian.u64(self.read::<8>(offset + 16)?)),
            };
            if let Some(child) = child {
                if child < root || stack.iter().any(|node| node.offset == child) {
                    return Err(invalid("cyclic or out-of-tree bigWig index offset"));
                }
                if stack.len() == MAX_DEPTH {
                    return Err(invalid(
                        "bigWig index exceeds the private 32-level depth budget",
                    ));
                }
                stack.push(self.node(child, tree, block_size)?);
            }
        }
        Ok(leaves)
    }
    fn chromosome_tree(&mut self, offset: u64) -> Result<()> {
        self.structure(offset, 36)?;
        let header = self.read::<32>(offset)?;
        let block = self.endian.u32(header[4..8].try_into().unwrap());
        let key = u64::from(self.endian.u32(header[8..12].try_into().unwrap()));
        let count = self.endian.u64(header[16..24].try_into().unwrap());
        if self.endian.u32(header[..4].try_into().unwrap()) != 0x78ca8c91
            || block == 0
            || self.endian.u32(header[12..16].try_into().unwrap()) != 8
        {
            return Err(invalid("invalid bigWig chromosome tree header"));
        }
        if count == 0
            || count > MAX_CHROMS
            || key == 0
            || key > MAX_KEY
            || count
                .checked_mul(key + 64)
                .is_none_or(|bytes| bytes > MEMORY_LIMIT)
        {
            return Err(invalid(
                "bigWig dictionary exceeds private count/key/16 MiB allocation limits",
            ));
        }
        self.extent(offset + 32, count * (key + 8))?;
        let observed = self.walk(offset + 32, Tree::Chromosomes { key }, block)?;
        if observed != count {
            return Err(invalid(
                "bigWig dictionary item count differs from its leaves",
            ));
        }
        Ok(())
    }
    fn interval_tree(&mut self, offset: u64) -> Result<()> {
        self.structure(offset, 52)?;
        let header = self.read::<48>(offset)?;
        let block = self.endian.u32(header[4..8].try_into().unwrap());
        if self.endian.u32(header[..4].try_into().unwrap()) != 0x2468ace0 || block == 0 {
            return Err(invalid("invalid bigWig interval index header"));
        }
        self.walk(offset + 48, Tree::Intervals, block)?;
        Ok(())
    }
    fn header(&mut self) -> Result<bool> {
        let header = self.read::<64>(0)?;
        self.endian = match u32::from_le_bytes(header[..4].try_into().unwrap()) {
            0x888ffc26 => Endian::Little,
            0x26fc8f88 => Endian::Big,
            _ => return Err(invalid("not a bigWig file")),
        };
        let zooms = self.endian.u16(header[6..8].try_into().unwrap());
        self.header_end = 64 + 24 * u64::from(zooms);
        self.extent(0, self.header_end)?;
        let buffer = u64::from(self.endian.u32(header[52..56].try_into().unwrap()));
        if buffer > MEMORY_LIMIT {
            return Err(invalid(
                "bigWig decompression buffer exceeds the private 16 MiB budget",
            ));
        }
        for (start, size) in [(36, 1), (44, 40), (56, 1)] {
            let offset = self
                .endian
                .u64(header[start..start + 8].try_into().unwrap());
            if offset != 0 {
                self.structure(offset, size)?;
            }
        }
        self.chromosome_tree(self.endian.u64(header[8..16].try_into().unwrap()))?;
        let data = self.endian.u64(header[16..24].try_into().unwrap());
        self.structure(data, 8)?;
        let index = self.endian.u64(header[24..32].try_into().unwrap());
        if index == 0 {
            let summary = self.endian.u64(header[44..52].try_into().unwrap());
            if summary == 0
                || zooms != 0
                || self.endian.u64(self.read::<8>(summary)?) != 0
                || self.endian.u64(self.read::<8>(data)?) != 0
            {
                return Err(invalid("bigWig without an index contains data or zooms"));
            }
            return Ok(true);
        }
        self.interval_tree(index)?;
        for i in 0..u64::from(zooms) {
            let zoom = self.read::<24>(64 + 24 * i)?;
            if self.endian.u32(zoom[..4].try_into().unwrap()) == 0 {
                return Err(invalid("invalid zero bigWig zoom reduction"));
            }
            self.structure(self.endian.u64(zoom[8..16].try_into().unwrap()), 4)?;
            self.interval_tree(self.endian.u64(zoom[16..24].try_into().unwrap()))?;
        }
        Ok(false)
    }
}

pub(super) fn validate(file: &mut File) -> Result<bool> {
    let position = file.stream_position()?;
    let length = file.metadata()?.len();
    let result = Admission {
        file,
        length,
        endian: Endian::Little,
        header_end: 64,
        nodes: 0,
        entries: 0,
        dictionary_bytes: 0,
    }
    .header();
    file.seek(SeekFrom::Start(position))?;
    result
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::Chromosome;
    use std::io::Write;

    #[test]
    fn bounded_structure_admits_empty_and_rejects_leaf_extent_and_cycle() {
        let scratch = tempfile::tempdir().unwrap();
        let path = scratch.path().join("empty.bw");
        super::super::empty::write(
            &path,
            &vec![Chromosome {
                name: "chr1".into(),
                len: 131,
            }],
        )
        .unwrap();
        let mut file = File::options().read(true).write(true).open(&path).unwrap();
        assert_eq!(file.metadata().unwrap().len(), 165);
        assert!(validate(&mut file).unwrap());
        let mut header = [0; 64];
        file.read_exact(&mut header).unwrap();
        let index = file.metadata().unwrap().len() - 4;
        file.seek(SeekFrom::Start(24)).unwrap();
        file.write_all(&index.to_le_bytes()).unwrap();
        file.seek(SeekFrom::Start(index)).unwrap();
        let mut root = [0u8; 48];
        root[..4].copy_from_slice(&0x2468ace0u32.to_le_bytes());
        root[4..8].copy_from_slice(&256u32.to_le_bytes());
        file.write_all(&root).unwrap();
        let node = index + 48;
        file.set_len(node + 36).unwrap();
        file.seek(SeekFrom::Start(node)).unwrap();
        file.write_all(&[1, 0, 1, 0]).unwrap();
        file.write_all(&[0; 24]).unwrap();
        file.write_all(&u64::MAX.to_le_bytes()).unwrap();
        assert!(validate(&mut file).is_err());
        file.seek(SeekFrom::Start(node)).unwrap();
        file.write_all(&[0, 0, 1, 0]).unwrap();
        file.write_all(&[0; 16]).unwrap();
        file.write_all(&node.to_le_bytes()).unwrap();
        assert!(validate(&mut file).is_err());
    }
}
