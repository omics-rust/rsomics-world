use std::io::{BufRead, BufReader, Read};
use std::path::{Path, PathBuf};
use std::process::Command;
#[path = "support/fixtures.rs"]
mod fixtures;
use std::sync::{
    OnceLock,
    atomic::{AtomicUsize, Ordering},
};
static LOG_ROOT: OnceLock<PathBuf> = OnceLock::new();
static CALL_NUMBER: AtomicUsize = AtomicUsize::new(0);

fn source_npz(native: &Path, fixture: &Path, name: &str) {
    let source: serde_json::Value = serde_json::from_reader(
        std::fs::File::open(fixture.join(format!("calls/{name}-arrays/observation.json"))).unwrap(),
    )
    .unwrap();
    let expected = source["result"]["arrays"]["matrix"]["values"]
        .as_array()
        .unwrap();
    let mut archive = zip::ZipArchive::new(std::fs::File::open(native).unwrap()).unwrap();
    let mut bytes = Vec::new();
    archive
        .by_name("matrix.npy")
        .unwrap()
        .read_to_end(&mut bytes)
        .unwrap();
    assert_eq!(&bytes[..8], b"\x93NUMPY\x01\x00");
    let header = u16::from_le_bytes([bytes[8], bytes[9]]) as usize;
    let values: Vec<_> = bytes[10 + header..]
        .chunks_exact(8)
        .map(|b| f64::from_le_bytes(b.try_into().unwrap()))
        .collect();
    let expected: Vec<_> = expected
        .iter()
        .flat_map(|r| r.as_array().unwrap())
        .collect();
    assert_eq!(values.len(), expected.len());
    for (i, (native, expected)) in values.iter().zip(expected).enumerate() {
        if expected["nonfinite"] == "nan" {
            assert!(native.is_nan(), "{name}[{i}]");
        } else {
            let expected = expected.as_f64().unwrap();
            assert!(
                (native - expected).abs() <= 1e-12 + 1e-12 * expected.abs(),
                "{name}[{i}]: {native} != {expected}"
            );
        }
    }
}

fn source_matrix(native: &Path, fixture: &Path, name: &str) {
    let source: serde_json::Value = serde_json::from_reader(
        std::fs::File::open(fixture.join(format!("calls/{name}-arrays/observation.json"))).unwrap(),
    )
    .unwrap();
    let decoder = flate2::read::GzDecoder::new(std::fs::File::open(native).unwrap());
    let mut lines = BufReader::new(decoder).lines();
    let first = lines.next().unwrap().unwrap();
    assert!(first.starts_with('@'));
    let header: serde_json::Value = serde_json::from_str(&first[1..]).unwrap();
    for key in [
        "sample_boundaries",
        "group_boundaries",
        "sample_labels",
        "group_labels",
    ] {
        assert_eq!(header[key], source["result"]["header"][key], "{name} {key}");
    }
    let rows: Vec<_> = lines
        .map(|l| {
            l.unwrap()
                .split('\t')
                .map(str::to_owned)
                .collect::<Vec<_>>()
        })
        .collect();
    let expected = source["result"]["rows"].as_array().unwrap();
    assert_eq!(rows.len(), expected.len());
    for (row, expected) in rows.iter().zip(expected) {
        let identity = expected["identity"].as_array().unwrap();
        for i in 0..6 {
            assert_eq!(row[i], identity[i].as_str().unwrap(), "{name} identity");
        }
        let expected = expected["values"].as_array().unwrap();
        assert_eq!(row.len(), 6 + expected.len());
        for (v, e) in row[6..].iter().zip(expected) {
            let v = v.parse::<f64>().unwrap();
            if e["nonfinite"] == "nan" {
                assert!(v.is_nan());
            } else {
                let e = e.as_f64().unwrap();
                assert!(
                    (v - e).abs() <= 0.5e-6 + e.abs() * 1e-12,
                    "{name}: {v} != {e}"
                );
            }
        }
    }
}

fn native_command(binary: &Path, arguments: &[String]) -> std::process::Output {
    let result = Command::new(binary)
        .env("NO_COLOR", "1")
        .args(arguments)
        .output();
    assert!(
        result.is_ok(),
        "whole-first-six native executable missing: {result:?}"
    );
    let result = result.unwrap();
    if let Some(root) = LOG_ROOT.get() {
        let id = CALL_NUMBER.fetch_add(1, Ordering::Relaxed);
        let stem = root.join(format!("call-{id:03}"));
        std::fs::write(stem.with_extension("stdout"), &result.stdout).unwrap();
        std::fs::write(stem.with_extension("stderr"), &result.stderr).unwrap();
        std::fs::write(stem.with_extension("json"),serde_json::to_vec_pretty(&serde_json::json!({"binary":binary,"argv":arguments,"status":result.status.code()})).unwrap()).unwrap();
    }
    result
}
fn invoke(binary: &Path, arguments: &[String]) {
    let result = native_command(binary, arguments);
    assert!(
        result.status.success(),
        "native command failed: {arguments:?}\n{}",
        String::from_utf8_lossy(&result.stderr)
    );
}

fn explicit_sort_and_index(input: &Path, output: &Path) {
    let mut reader = rsomics_bamio::open_with_workers(input, std::num::NonZeroUsize::MIN).unwrap();
    let header = reader.read_header().unwrap();
    let mut records = Vec::new();
    let mut record = rsomics_bamio::raw::RawRecord::default();
    while rsomics_bamio::raw::read_record(reader.get_mut(), &mut record).unwrap() != 0 {
        records.push(record.clone());
    }
    records.sort_by_key(|r| {
        (
            if r.reference_sequence_id() < 0 {
                i32::MAX
            } else {
                r.reference_sequence_id()
            },
            r.alignment_start(),
        )
    });
    let mut writer =
        rsomics_bamio::create_with_workers(output, std::num::NonZeroUsize::MIN).unwrap();
    writer.write_header(&header).unwrap();
    for record in records {
        rsomics_bamio::raw::write_record(writer.get_mut(), &record).unwrap();
    }
    writer.into_inner().finish().unwrap();
    let index = noodles::bam::fs::index(output).unwrap();
    noodles::bam::bai::fs::write(format!("{}.bai", output.display()), &index).unwrap();
}

#[test]
fn whole_first_six() {
    let target = std::env::var_os("CARGO_TARGET_DIR").expect("external target required");
    let binary = option_env!("CARGO_BIN_EXE_rsomics-signal")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from(target).join("debug/rsomics-signal"));
    let fixture = fixtures::fixture_root();
    let scratch = tempfile::Builder::new()
        .prefix("signal-first-six-")
        .tempdir_in(std::env::temp_dir())
        .unwrap()
        .keep();
    LOG_ROOT.set(scratch.clone()).unwrap();
    for command in [
        "track",
        "compare",
        "average",
        "summarize",
        "matrix",
        "filter",
    ] {
        invoke(&binary, &[command.into(), "--help".into()]);
    }
    let path = |p: PathBuf| p.to_string_lossy().into_owned();
    let output = scratch.join("signed.bedgraph");
    invoke(
        &binary,
        &[
            "compare".into(),
            "--input".into(),
            "bigwig".into(),
            "--first".into(),
            path(fixture.join("generated-inputs/signed-a.bw")),
            "--second".into(),
            path(fixture.join("generated-inputs/signed-b.bw")),
            "--out".into(),
            path(output.clone()),
            "--format".into(),
            "bedgraph".into(),
            "--bin-size".into(),
            "20".into(),
            "--operation".into(),
            "subtract".into(),
            "--skip-zero-over-zero".into(),
        ],
    );
    assert_eq!(
        std::fs::read_to_string(output).unwrap(),
        "chr1\t0\t20\t4\nchr1\t60\t100\t-6\n"
    );
    let signed = |name: &str, extra: &[&str]| {
        let output = scratch.join(format!("{name}.bedgraph"));
        let mut args = vec![
            "compare".into(),
            "--input".into(),
            "bigwig".into(),
            "--first".into(),
            path(fixture.join("generated-inputs/signed-a.bw")),
            "--second".into(),
            path(fixture.join("generated-inputs/signed-b.bw")),
            "--out".into(),
            path(output.clone()),
            "--format".into(),
            "bedgraph".into(),
            "--bin-size".into(),
            "20".into(),
        ];
        args.extend(extra.iter().map(|s| s.to_string()));
        invoke(&binary, &args);
        std::fs::read_to_string(output).unwrap()
    };
    assert_eq!(
        signed("tail", &["--operation", "subtract"]),
        "chr1\t0\t20\t4\nchr1\t20\t60\t0\nchr1\t60\t100\t-6\nchr1\t100\t131\t0\n"
    );
    assert_eq!(
        signed("missing", &["--operation", "subtract", "--skip-nas"]),
        "chr1\t0\t20\t4\nchr1\t20\t40\t0\nchr1\t60\t100\t-6\nchr1\t100\t131\t0\n"
    );
    let nonfinite = signed(
        "nonfinite",
        &["--operation", "ratio", "--pseudocount", "0", "--fixed-step"],
    );
    let cells: Vec<_> = nonfinite
        .lines()
        .map(|l| l.split('\t').next_back().unwrap().parse::<f64>().unwrap())
        .collect();
    assert_eq!(cells.len(), 7);
    assert_eq!(cells.iter().filter(|v| v.is_nan()).count(), 4);
    let asymmetric = signed(
        "nonfinite-log",
        &[
            "--operation",
            "log2",
            "--pseudocount",
            "0",
            "2",
            "--fixed-step",
        ],
    );
    let cells: Vec<_> = asymmetric
        .lines()
        .map(|l| l.split('\t').next_back().unwrap().parse::<f64>().unwrap())
        .collect();
    assert_eq!(cells.iter().filter(|v| **v == f64::INFINITY).count(), 1);
    assert_eq!(cells.iter().filter(|v| **v == f64::NEG_INFINITY).count(), 4);
    assert_eq!(cells.iter().filter(|v| v.is_nan()).count(), 2);
    let empty = scratch.join("legitimate-empty.bw");
    invoke(
        &binary,
        &[
            "compare".into(),
            "--input".into(),
            "bigwig".into(),
            "--first".into(),
            path(fixture.join("generated-inputs/signed-a.bw")),
            "--second".into(),
            path(fixture.join("generated-inputs/signed-b.bw")),
            "--out".into(),
            path(empty.clone()),
            "--bin-size".into(),
            "20".into(),
            "--operation".into(),
            "log2".into(),
            "--pseudocount".into(),
            "0".into(),
        ],
    );
    let mut empty_reader = bigtools::BigWigRead::open_file(&empty).unwrap();
    let summary = empty_reader.get_summary().unwrap();
    assert_eq!(summary.bases_covered, 0);
    assert_eq!(summary.min_val, f64::MAX);
    assert_eq!(summary.max_val, f64::MIN_POSITIVE);
    assert_eq!(empty_reader.chroms()[0].name, "chr1");
    assert_eq!(empty_reader.chroms()[0].length, 131);
    let header = std::fs::read(&empty).unwrap();
    assert_eq!(u64::from_le_bytes(header[24..32].try_into().unwrap()), 0);
    let empty_summary = scratch.join("empty-summary.npz");
    invoke(
        &binary,
        &[
            "summarize".into(),
            "bins".into(),
            "--input".into(),
            "bigwig".into(),
            "--files".into(),
            path(empty),
            "--out".into(),
            path(empty_summary.clone()),
            "--bin-size".into(),
            "20".into(),
        ],
    );
    let mut archive = zip::ZipArchive::new(std::fs::File::open(empty_summary).unwrap()).unwrap();
    let mut bytes = Vec::new();
    archive
        .by_name("matrix.npy")
        .unwrap()
        .read_to_end(&mut bytes)
        .unwrap();
    let header = u16::from_le_bytes([bytes[8], bytes[9]]) as usize;
    let values: Vec<_> = bytes[10 + header..]
        .chunks_exact(8)
        .map(|v| f64::from_le_bytes(v.try_into().unwrap()))
        .collect();
    assert_eq!(values.len(), 7);
    assert!(values.iter().all(|v| v.is_nan()));
    let mut tracks = Vec::new();
    let mut native_bams = Vec::new();
    for sample in ["a", "b"] {
        let filtered = scratch.join(format!("{sample}.filtered.bam"));
        invoke(
            &binary,
            &[
                "filter".into(),
                "--bam".into(),
                path(fixture.join(format!("generated-inputs/{sample}.raw.bam"))),
                "--out".into(),
                path(filtered.clone()),
                "--min-mapq".into(),
                "20".into(),
                "--exclude-flags".into(),
                "2816".into(),
            ],
        );
        let indexed = scratch.join(format!("{sample}.filtered-indexed.bam"));
        explicit_sort_and_index(&filtered, &indexed);
        let shifted = scratch.join(format!("{sample}.shifted.bam"));
        invoke(
            &binary,
            &[
                "filter".into(),
                "--bam".into(),
                path(indexed),
                "--out".into(),
                path(shifted.clone()),
                "--atac-shift".into(),
            ],
        );
        let native_bam = scratch.join(format!("{sample}.source-native.bam"));
        explicit_sort_and_index(&shifted, &native_bam);
        native_bams.push(path(native_bam.clone()));
        let out = scratch.join(format!("{sample}.bw"));
        invoke(
            &binary,
            &[
                "track".into(),
                "--bam".into(),
                path(native_bam),
                "--out".into(),
                path(out.clone()),
                "--bin-size".into(),
                "20".into(),
                "--normalize".into(),
                "CPM".into(),
                "--exact-scaling".into(),
            ],
        );
        tracks.push(path(out));
    }
    invoke(
        &binary,
        &[
            "average".into(),
            "--bigwig".into(),
            tracks[0].clone(),
            tracks[1].clone(),
            tracks[0].clone(),
            "--scale-factors".into(),
            "1:0.5:2".into(),
            "--out".into(),
            path(scratch.join("average.bw")),
            "--bin-size".into(),
            "20".into(),
        ],
    );
    let comparison = path(scratch.join("compare.bw"));
    for (profile, options) in [
        ("readCount", Vec::<&str>::new()),
        (
            "SES",
            vec![
                "--scale-method",
                "SES",
                "--sample-length",
                "50",
                "--number-of-samples",
                "24",
            ],
        ),
        (
            "manual",
            vec![
                "--scale-factors",
                "2:0.5",
                "--operation",
                "ratio",
                "--pseudocount",
                "2",
                "3",
            ],
        ),
        (
            "normalized",
            vec![
                "--scale-method",
                "none",
                "--normalize",
                "CPM",
                "--exact-scaling",
            ],
        ),
    ] {
        let output = scratch.join(format!("compare-bam-{profile}.bedgraph"));
        let mut args = vec![
            "compare".into(),
            "--input".into(),
            "bam".into(),
            "--first".into(),
            native_bams[0].clone(),
            "--second".into(),
            native_bams[1].clone(),
            "--out".into(),
            path(output.clone()),
            "--format".into(),
            "bedgraph".into(),
            "--bin-size".into(),
            "20".into(),
        ];
        args.extend(options.into_iter().map(str::to_owned));
        invoke(&binary, &args);
        assert_eq!(
            std::fs::read_to_string(output).unwrap(),
            std::fs::read_to_string(
                fixture.join(format!("results/compare-bam-{profile}.bedgraph"))
            )
            .unwrap(),
            "BAM compare {profile}"
        );
    }
    for (profile, options) in [
        ("blocks", Vec::<String>::new()),
        (
            "extended-centered",
            [
                "--extend-reads",
                "160",
                "--center-reads",
                "--smooth-length",
                "60",
            ]
            .map(str::to_owned)
            .to_vec(),
        ),
        (
            "offset-strand",
            [
                "--extend-reads",
                "160",
                "--offset",
                "5",
                "-1",
                "--rna-strand",
                "forward",
            ]
            .map(str::to_owned)
            .to_vec(),
        ),
        (
            "blacklist-grid",
            vec![
                "--blacklist".into(),
                path(fixture.join("inputs/authored/blacklist.bed")),
            ],
        ),
        (
            "mnase",
            [
                "--mnase",
                "--min-fragment-length",
                "130",
                "--max-fragment-length",
                "200",
            ]
            .map(str::to_owned)
            .to_vec(),
        ),
    ] {
        let output = scratch.join(format!("profile-{profile}.bedgraph"));
        let mut args = vec![
            "track".into(),
            "--bam".into(),
            path(fixture.join("generated-inputs/a.raw.bam")),
            "--out".into(),
            path(output.clone()),
            "--format".into(),
            "bedgraph".into(),
            "--bin-size".into(),
            "20".into(),
            "--region".into(),
            "chr1:180:720".into(),
        ];
        args.extend(options);
        invoke(&binary, &args);
        assert_eq!(
            std::fs::read_to_string(output).unwrap(),
            std::fs::read_to_string(fixture.join(format!("results/profile-{profile}.bedgraph")))
                .unwrap(),
            "track {profile}"
        );
    }
    invoke(
        &binary,
        &[
            "compare".into(),
            "--input".into(),
            "bigwig".into(),
            "--first".into(),
            tracks[0].clone(),
            "--second".into(),
            tracks[1].clone(),
            "--out".into(),
            comparison.clone(),
            "--bin-size".into(),
            "20".into(),
        ],
    );
    let mut corrected = bigtools::BigWigRead::open_file(&comparison).unwrap();
    let zeros: Vec<_> = corrected
        .get_interval("chr2", 0, 333)
        .unwrap()
        .map(Result::unwrap)
        .collect();
    assert_eq!(zeros.len(), 1);
    assert_eq!(
        (zeros[0].start, zeros[0].end, zeros[0].value),
        (0, 333, 0.0)
    );
    let alias = scratch.join("alias-summary.npz");
    invoke(
        &binary,
        &[
            "-t".into(),
            "2".into(),
            "summarize".into(),
            "bins".into(),
            "--input".into(),
            "bigwig".into(),
            "--files".into(),
            path(fixture.join("generated-inputs/signed-a.bw")),
            path(fixture.join("generated-inputs/aliased-dictionary.bw")),
            "--out".into(),
            path(alias.clone()),
            "--bin-size".into(),
            "20".into(),
        ],
    );
    source_npz(&alias, &fixture, "alias-summary");
    let unequal = scratch.join("unequal.bedgraph");
    invoke(
        &binary,
        &[
            "compare".into(),
            "--input".into(),
            "bigwig".into(),
            "--first".into(),
            path(fixture.join("generated-inputs/signed-a.bw")),
            "--second".into(),
            path(fixture.join("generated-inputs/short-dictionary.bw")),
            "--out".into(),
            path(unequal.clone()),
            "--format".into(),
            "bedgraph".into(),
            "--bin-size".into(),
            "20".into(),
        ],
    );
    assert_eq!(
        std::fs::read_to_string(unequal).unwrap(),
        std::fs::read_to_string(fixture.join("results/unequal-dictionary.bedgraph")).unwrap()
    );
    for input in ["bigwig", "bam"] {
        let files: Vec<String> = if input == "bam" {
            native_bams.clone()
        } else {
            tracks.clone()
        };
        for mode in ["bins", "regions"] {
            let mut args = vec![
                "summarize".into(),
                mode.into(),
                "--input".into(),
                input.into(),
                "--files".into(),
            ];
            args.extend(files.clone());
            args.extend([
                "--out".into(),
                path(scratch.join(format!("{input}-{mode}.npz"))),
                "--bin-size".into(),
                "100".into(),
            ]);
            args.extend(["--labels".into(), "A".into(), "B".into()]);
            if input == "bam" && mode == "bins" {
                args.extend(["--genome-chunk-size".into(), "333".into()]);
            }
            if mode == "regions" {
                args.extend([
                    "--regions".into(),
                    path(fixture.join("inputs/authored/regions.bed")),
                ]);
            }
            invoke(&binary, &args);
            source_npz(
                &scratch.join(format!("{input}-{mode}.npz")),
                &fixture,
                &format!(
                    "summary-{}-{}",
                    if input == "bam" { "bam" } else { "bw" },
                    if mode == "bins" { "bins" } else { "BED-file" }
                ),
            );
        }
    }
    for mode in ["reference", "scale"] {
        let mut args = vec![
            "matrix".into(),
            mode.into(),
            "--bigwig".into(),
            comparison.clone(),
            path(scratch.join("average.bw")),
            "--regions".into(),
            path(fixture.join("inputs/authored/groups.bed")),
            "--out".into(),
            path(scratch.join(format!("matrix-{mode}.gz"))),
            "--before".into(),
            "50".into(),
            "--after".into(),
            if mode == "reference" {
                "100".into()
            } else {
                "50".into()
            },
            "--labels".into(),
            "CPM A/B log2 ratio".into(),
            "CPM A/B/A scaled average".into(),
        ];
        if mode == "scale" {
            args.extend([
                "--body-length".into(),
                "200".into(),
                "--unscaled-5prime".into(),
                "20".into(),
                "--unscaled-3prime".into(),
                "20".into(),
            ]);
        }
        invoke(&binary, &args);
        source_matrix(
            &scratch.join(format!("matrix-{mode}.gz")),
            &fixture,
            &format!("matrix-{mode}"),
        );
    }
    for (name, mode, regions, before, after) in [
        ("bed12", "reference", "exons.bed", "50", "50"),
        ("gtf", "scale", "regions.gtf", "20", "20"),
    ] {
        let output = scratch.join(format!("matrix-{name}.gz"));
        let mut args = vec![
            "matrix".into(),
            mode.into(),
            "--bigwig".into(),
            tracks[0].clone(),
            tracks[1].clone(),
            "--regions".into(),
            path(fixture.join(format!("inputs/authored/{regions}"))),
            "--out".into(),
            path(output.clone()),
            "--before".into(),
            before.into(),
            "--after".into(),
            after.into(),
            "--metagene".into(),
            "--labels".into(),
            "A".into(),
            "B".into(),
        ];
        if name == "bed12" {
            args.extend(["--reference-point".into(), "center".into()]);
        } else {
            args.extend(["--body-length".into(), "200".into()]);
        }
        invoke(&binary, &args);
        source_matrix(&output, &fixture, &format!("matrix-{name}"));
    }
    invoke(
        &binary,
        &[
            "filter".into(),
            "--bam".into(),
            path(fixture.join("generated-inputs/a.raw.bam")),
            "--out".into(),
            path(scratch.join("fragments.bed")),
            "--format".into(),
            "fragments-bed".into(),
            "--filtered-out".into(),
            path(scratch.join("rejected.bam")),
            "--atac-shift".into(),
            "--min-mapq".into(),
            "20".into(),
            "--exclude-flags".into(),
            "2816".into(),
        ],
    );
    assert_eq!(
        std::fs::read_to_string(scratch.join("fragments.bed"))
            .unwrap()
            .lines()
            .count(),
        32
    );
    let raw = scratch.join("rollover-input.bw");
    let mut writer = bigtools::BigWigWrite::create_file(
        &raw,
        std::collections::HashMap::from([("chr1".to_owned(), 120003)]),
    )
    .unwrap();
    writer.options.manual_zoom_sizes = Some(Vec::new());
    let values = bigtools::beddata::BedParserStreamingIterator::wrap_infallible_iter(
        (0..12000).map(|i| {
            (
                "chr1".to_owned(),
                bigtools::Value {
                    start: i * 10,
                    end: i * 10 + 5,
                    value: 1.0,
                },
            )
        }),
        false,
    );
    writer
        .write(
            values,
            tokio::runtime::Builder::new_multi_thread()
                .worker_threads(2)
                .build()
                .unwrap(),
        )
        .unwrap();
    let rollover = scratch.join("rollover-native.bw");
    invoke(
        &binary,
        &[
            "average".into(),
            "--bigwig".into(),
            path(raw),
            "--out".into(),
            path(rollover.clone()),
            "--bin-size".into(),
            "5".into(),
            "--skip-nas".into(),
        ],
    );
    let mut reader = bigtools::BigWigRead::open_file(rollover).unwrap();
    let levels: Vec<_> = reader
        .info()
        .zoom_headers
        .iter()
        .map(|z| z.reduction_level)
        .collect();
    assert_eq!(levels, vec![80, 320]);
    let records: Vec<_> = reader
        .get_zoom_interval("chr1", 0, 120003, 80)
        .unwrap()
        .map(Result::unwrap)
        .collect();
    assert!(records.len() > 1023);
    assert_eq!(
        (
            records[1022].start,
            records[1022].end,
            records[1022].summary.sum
        ),
        (81760, 81765, 0.0)
    );
    assert_eq!(records[1023].start, 81770);
    assert_eq!(records.last().unwrap().summary.sum, 0.0);
    let previous = scratch.join("preserved.bedgraph");
    std::fs::write(&previous, b"previous-output\n").unwrap();
    let failed = native_command(
        &binary,
        &[
            "compare".into(),
            "--input".into(),
            "bigwig".into(),
            "--first".into(),
            tracks[0].clone(),
            "--second".into(),
            tracks[1].clone(),
            "--out".into(),
            path(previous.clone()),
            "--report".into(),
            path(scratch.join("missing-parent/report.json")),
        ],
    );
    assert!(!failed.status.success());
    assert_eq!(std::fs::read(&previous).unwrap(), b"previous-output\n");
    let broken = scratch.join("broken.bw");
    std::fs::write(&broken, b"not-bigwig").unwrap();
    let invalid_output = scratch.join("invalid.bw");
    let failed = native_command(
        &binary,
        &[
            "average".into(),
            "--bigwig".into(),
            path(broken),
            "--out".into(),
            path(invalid_output.clone()),
        ],
    );
    assert!(!failed.status.success());
    assert!(!invalid_output.exists());
    let invalid_mode = scratch.join("invalid-mode.bw");
    let failed = native_command(
        &binary,
        &[
            "compare".into(),
            "--input".into(),
            "bigwig".into(),
            "--first".into(),
            tracks[0].clone(),
            "--second".into(),
            tracks[1].clone(),
            "--out".into(),
            path(invalid_mode.clone()),
            "--scale-method".into(),
            "readCount".into(),
        ],
    );
    assert!(!failed.status.success());
    assert!(!invalid_mode.exists());
    review_corrections(&binary, &fixture, &scratch);
    eprintln!("retained connected native workflow: {}", scratch.display());
}

fn review_corrections(binary: &Path, fixture: &Path, scratch: &Path) {
    summary_task_ownership(binary, scratch);
    for threads in [1, 4] {
        let out = scratch.join(format!("review-ignore-{threads}.bedgraph"));
        invoke(
            binary,
            &[
                "track".into(),
                "--bam".into(),
                fixture
                    .join("generated-inputs/a.raw.bam")
                    .display()
                    .to_string(),
                "--out".into(),
                out.display().to_string(),
                "--format".into(),
                "bedgraph".into(),
                "--bin-size".into(),
                "20".into(),
                "--ignore-for-normalization".into(),
                "chr2".into(),
                "--threads".into(),
                threads.to_string(),
            ],
        );
        assert!(
            std::fs::read_to_string(out)
                .unwrap()
                .lines()
                .any(|l| l.starts_with("chr2\t")),
            "normalization exclusions must retain output chromosomes"
        );
    }
    assert_eq!(
        std::fs::read(scratch.join("review-ignore-1.bedgraph")).unwrap(),
        std::fs::read(scratch.join("review-ignore-4.bedgraph")).unwrap()
    );
    let mut bams = Vec::new();
    for (name, cigar, copies) in [("short", "10M", 6), ("long", "200M", 1)] {
        let mut sam =
            "@HD\tVN:1.6\tSO:coordinate\n@SQ\tSN:chr1\tLN:1000\n@SQ\tSN:chrM\tLN:333\n".to_owned();
        for i in 0..copies {
            sam.push_str(&format!(
                "r{i}\t0\tchr1\t{}\t60\t{cigar}\t*\t0\t0\t*\t*\n",
                if i < 2 { 101 } else { 301 }
            ));
        }
        let mut reader = noodles::sam::io::Reader::new(sam.as_bytes());
        let header = reader.read_header().unwrap();
        let path = scratch.join(format!("review-{name}.bam"));
        let mut writer =
            rsomics_bamio::create_with_workers(&path, std::num::NonZeroUsize::MIN).unwrap();
        writer.write_header(&header).unwrap();
        let mut encoder = rsomics_bamio::raw::RawRecordEncoder::new();
        for record in reader.record_bufs(&header) {
            let record = encoder.encode(&header, &record.unwrap()).unwrap();
            rsomics_bamio::raw::write_record(writer.get_mut(), &record).unwrap();
        }
        writer.into_inner().finish().unwrap();
        let index = noodles::bam::fs::index(&path).unwrap();
        noodles::bam::bai::fs::write(format!("{}.bai", path.display()), &index).unwrap();
        bams.push(path.display().to_string());
    }
    let run = |name: &str, mut args: Vec<String>| {
        let output = scratch.join(name);
        args.extend(["--out".into(), output.display().to_string()]);
        invoke(binary, &args);
        output
    };
    let track = vec![
        "track".into(),
        "--bam".into(),
        bams[0].clone(),
        "--format".into(),
        "bedgraph".into(),
        "--bin-size".into(),
        "100".into(),
        "--region".into(),
        "1:100:400".into(),
    ];
    let retained = run(
        "review-ignore-compare.bw",
        vec![
            "compare".into(),
            "--input".into(),
            "bam".into(),
            "--first".into(),
            bams[0].clone(),
            "--second".into(),
            bams[1].clone(),
            "--scale-method".into(),
            "none".into(),
            "--ignore-for-normalization".into(),
            "chrM".into(),
        ],
    );
    let reader = bigtools::BigWigRead::open_file(retained).unwrap();
    assert!(reader.chroms().iter().any(|c| c.name == "chrM"));
    let mut missing = track.clone();
    missing.extend(["--skip-nas".into(), "--smooth-length".into(), "300".into()]);
    assert!(
        std::fs::read(run("review-smooth.bedgraph", missing))
            .unwrap()
            .is_empty()
    );
    let compare = vec![
        "compare".into(),
        "--input".into(),
        "bam".into(),
        "--first".into(),
        bams[0].clone(),
        "--second".into(),
        bams[0].clone(),
        "--scale-method".into(),
        "none".into(),
        "--format".into(),
        "bedgraph".into(),
        "--bin-size".into(),
        "100".into(),
        "--region".into(),
        "chr1:100:400".into(),
        "--operation".into(),
        "add".into(),
        "--skip-nas".into(),
    ];
    assert_eq!(
        std::fs::read_to_string(run("review-skip-compare.bedgraph", compare)).unwrap(),
        "chr1\t100\t200\t4\nchr1\t300\t400\t8\n"
    );
    for threads in [1, 4] {
        let args = vec![
            "compare".into(),
            "--input".into(),
            "bam".into(),
            "--first".into(),
            bams[0].clone(),
            "--second".into(),
            bams[1].clone(),
            "--scale-method".into(),
            "none".into(),
            "--format".into(),
            "bedgraph".into(),
            "--bin-size".into(),
            "100".into(),
            "--region".into(),
            "chr1:100:400".into(),
            "--operation".into(),
            "second".into(),
            "--extend-reads".into(),
            "100".into(),
            "--threads".into(),
            threads.to_string(),
        ];
        assert_eq!(
            std::fs::read_to_string(run(
                &format!("review-shared-geometry-{threads}.bedgraph"),
                args
            ))
            .unwrap(),
            "chr1\t100\t200\t1\nchr1\t200\t400\t0\n"
        );
    }
    let mut clipped = track.clone();
    let last = clipped.len() - 1;
    clipped[last] = "1:181:399".into();
    let clipped = std::fs::read_to_string(run("review-region.bedgraph", clipped)).unwrap();
    assert!(clipped.starts_with("chr1\t100\t200\t2\n"));
    assert!(clipped.ends_with("\t399\t4\n"));
    let summary = vec![
        "summarize".into(),
        "bins".into(),
        "--input".into(),
        "bam".into(),
        "--files".into(),
        bams[0].clone(),
        bams[1].clone(),
        "--bin-size".into(),
        "100".into(),
        "--distance-between-bins".into(),
        "50".into(),
        "--genome-chunk-size".into(),
        "333".into(),
    ];
    for threads in [1, 4] {
        let raw = scratch.join(format!("review-spaced-{threads}.tsv"));
        let mut args = summary.clone();
        args.extend([
            "--raw-counts".into(),
            raw.display().to_string(),
            "--threads".into(),
            threads.to_string(),
            "--scaling-factors".into(),
            scratch
                .join(format!("review-factors-{threads}.tsv"))
                .display()
                .to_string(),
        ]);
        run(&format!("review-spaced-{threads}.npz"), args);
        for line in std::fs::read_to_string(raw).unwrap().lines().skip(1) {
            let fields = line.split('\t').collect::<Vec<_>>();
            assert_eq!(
                fields[2].parse::<u32>().unwrap() - fields[1].parse::<u32>().unwrap(),
                100
            );
        }
    }
    assert_eq!(
        std::fs::read(scratch.join("review-spaced-1.tsv")).unwrap(),
        std::fs::read(scratch.join("review-spaced-4.tsv")).unwrap()
    );
    for (name, text) in [
        ("exact", "chr1\t100\t200\nchrM\t0\t100\n"),
        ("alias", "1\t100\t200\nMT\t0\t100\n"),
    ] {
        let bed = scratch.join(format!("review-{name}.bed"));
        std::fs::write(&bed, text).unwrap();
        run(
            &format!("review-alias-{name}.npz"),
            vec![
                "summarize".into(),
                "regions".into(),
                "--input".into(),
                "bam".into(),
                "--files".into(),
                bams[0].clone(),
                "--regions".into(),
                bed.display().to_string(),
                "--raw-counts".into(),
                scratch
                    .join(format!("review-alias-{name}.tsv"))
                    .display()
                    .to_string(),
            ],
        );
        let mut args = track.clone();
        args.extend(["--blacklist".into(), bed.display().to_string()]);
        run(&format!("review-mask-{name}.bedgraph"), args);
    }
    assert_eq!(
        std::fs::read(scratch.join("review-alias-exact.tsv")).unwrap(),
        std::fs::read(scratch.join("review-alias-alias.tsv")).unwrap()
    );
    assert_eq!(
        std::fs::read(scratch.join("review-mask-exact.bedgraph")).unwrap(),
        std::fs::read(scratch.join("review-mask-alias.bedgraph")).unwrap()
    );
    for threads in [1, 4] {
        let report = scratch.join(format!("review-spool-{threads}.json"));
        run(
            &format!("review-spool-{threads}.npz"),
            vec![
                "summarize".into(),
                "bins".into(),
                "--input".into(),
                "bigwig".into(),
                "--files".into(),
                scratch.join("rollover-native.bw").display().to_string(),
                "--bin-size".into(),
                "5".into(),
                "--raw-counts".into(),
                scratch
                    .join(format!("review-spool-{threads}.tsv"))
                    .display()
                    .to_string(),
                "--report".into(),
                report.display().to_string(),
                "--threads".into(),
                threads.to_string(),
            ],
        );
        let report: serde_json::Value =
            serde_json::from_slice(&std::fs::read(report).unwrap()).unwrap();
        assert_eq!(report["rows"], 24001);
        assert_eq!(report["numeric_spool_bytes"], 24001 * 8);
        assert!(report["row_block_limit"].as_u64().unwrap() <= 4096);
    }
    assert_eq!(
        std::fs::read(scratch.join("review-spool-1.tsv")).unwrap(),
        std::fs::read(scratch.join("review-spool-4.tsv")).unwrap()
    );
    let wide = scratch.join("review-wide.bw");
    let mut writer = bigtools::BigWigWrite::create_file(
        &wide,
        std::collections::HashMap::from([("chr1".to_owned(), 2_000_003)]),
    )
    .unwrap();
    writer.options.manual_zoom_sizes = Some(Vec::new());
    writer
        .write(
            bigtools::beddata::BedParserStreamingIterator::wrap_infallible_iter(
                std::iter::once((
                    "chr1".to_owned(),
                    bigtools::Value {
                        start: 0,
                        end: 2_000_003,
                        value: 1.0,
                    },
                )),
                false,
            ),
            tokio::runtime::Builder::new_multi_thread()
                .worker_threads(1)
                .build()
                .unwrap(),
        )
        .unwrap();
    let wide = run(
        "review-cap.bedgraph",
        vec![
            "average".into(),
            "--bigwig".into(),
            wide.display().to_string(),
            "--format".into(),
            "bedgraph".into(),
            "--bin-size".into(),
            "20".into(),
            "--region".into(),
            "1:181:1100719".into(),
        ],
    );
    let lines = std::fs::read_to_string(wide).unwrap();
    assert_eq!(lines, "chr1\t180\t1000180\t1\nchr1\t1000180\t1100719\t1\n");
    let valid = std::fs::read(scratch.join("a.bw")).unwrap();
    for (name, offset, bytes) in [
        (
            "dictionary",
            u64::from_le_bytes(valid[8..16].try_into().unwrap()) as usize + 16,
            u64::MAX.to_le_bytes().to_vec(),
        ),
        ("decompression", 52, u32::MAX.to_le_bytes().to_vec()),
    ] {
        let mut corrupt = valid.clone();
        corrupt[offset..offset + bytes.len()].copy_from_slice(&bytes);
        let input = scratch.join(format!("review-corrupt-{name}.bw"));
        std::fs::write(&input, corrupt).unwrap();
        let output = scratch.join(format!("review-corrupt-{name}-out.bw"));
        let result = native_command(
            binary,
            &[
                "average".into(),
                "--bigwig".into(),
                input.display().to_string(),
                "--out".into(),
                output.display().to_string(),
            ],
        );
        assert!(!result.status.success());
        assert!(!output.exists());
        assert!(String::from_utf8_lossy(&result.stderr).contains("preflight"));
    }
}

fn summary_task_ownership(binary: &Path, scratch: &Path) {
    let sam = b"@HD\tVN:1.6\tSO:coordinate\n@SQ\tSN:chr1\tLN:1000000\nshort\t0\tchr1\t101\t60\t10M\t=\t201\t100\t*\t*\nspliced\t0\tchr1\t101\t60\t10M5000N10M\t=\t201\t100\t*\t*\n";
    let mut reader = noodles::sam::io::Reader::new(&sam[..]);
    let header = reader.read_header().unwrap();
    let bam = scratch.join("review-task-dedup.bam");
    let mut writer = rsomics_bamio::create_with_workers(&bam, std::num::NonZeroUsize::MIN).unwrap();
    writer.write_header(&header).unwrap();
    let mut encoder = rsomics_bamio::raw::RawRecordEncoder::new();
    for record in reader.record_bufs(&header) {
        let record = encoder.encode(&header, &record.unwrap()).unwrap();
        rsomics_bamio::raw::write_record(writer.get_mut(), &record).unwrap();
    }
    writer.into_inner().finish().unwrap();
    let index = noodles::bam::fs::index(&bam).unwrap();
    noodles::bam::bai::fs::write(format!("{}.bai", bam.display()), &index).unwrap();
    for threads in [1, 4] {
        let raw = scratch.join(format!("review-task-dedup-{threads}.tsv"));
        invoke(
            binary,
            &[
                "summarize".into(),
                "bins".into(),
                "--input".into(),
                "bam".into(),
                "--files".into(),
                bam.display().to_string(),
                "--out".into(),
                scratch
                    .join(format!("review-task-dedup-{threads}.npz"))
                    .display()
                    .to_string(),
                "--raw-counts".into(),
                raw.display().to_string(),
                "--bin-size".into(),
                "1".into(),
                "--genome-chunk-size".into(),
                "10000".into(),
                "--region".into(),
                "chr1:0:10000".into(),
                "--ignore-duplicates".into(),
                "--threads".into(),
                threads.to_string(),
            ],
        );
        let raw = std::fs::read_to_string(raw).unwrap();
        let values = raw
            .lines()
            .skip(1)
            .map(|line| {
                let fields = line.split('\t').collect::<Vec<_>>();
                (
                    fields[1].parse::<u32>().unwrap(),
                    fields[3].parse::<f64>().unwrap(),
                )
            })
            .collect::<Vec<_>>();
        assert_eq!(values.len(), 10000);
        assert!(
            values
                .iter()
                .all(|(start, value)| *value == if (100..110).contains(start) { 1.0 } else { 0.0 }),
            "contiguous semantic task must retain one fetch/dedup population across output blocks"
        );
    }
    let output = scratch.join("review-task-budget.npz");
    let result = native_command(
        binary,
        &[
            "summarize".into(),
            "bins".into(),
            "--input".into(),
            "bam".into(),
            "--files".into(),
            bam.display().to_string(),
            "--out".into(),
            output.display().to_string(),
            "--bin-size".into(),
            "1".into(),
            "--genome-chunk-size".into(),
            "1000000".into(),
        ],
    );
    assert!(!result.status.success());
    assert!(!output.exists());
    assert!(String::from_utf8_lossy(&result.stderr).contains("task/in-flight allocation budget"));
    assert!(String::from_utf8_lossy(&result.stderr).contains("--genome-chunk-size"));
}
