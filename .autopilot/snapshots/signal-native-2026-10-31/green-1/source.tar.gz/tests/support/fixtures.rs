#[cfg(test)]
pub fn fixture_root() -> std::path::PathBuf {
    let root=std::env::var_os("RSOMICS_SIGNAL_FIXTURES").map(std::path::PathBuf::from).unwrap_or_else(||std::path::PathBuf::from("/Volumes/Zane's HDD/rsomics-fixtures/evidence/signal-first-workflow-oracle-2026-10-31/run-41192955170/selected/witness"));
    assert!(
        root.is_absolute(),
        "RSOMICS_SIGNAL_FIXTURES must be the absolute selected/witness directory"
    );
    assert!(
        root.join("generated-inputs/a.raw.bam").is_file(),
        "RSOMICS_SIGNAL_FIXTURES must identify selected/witness, not its parent run directory: {}",
        root.display()
    );
    root
}
