use crate::model::{Dictionary, Span, invalid};
use rsomics_common::Result;
use std::{
    collections::HashMap,
    fs::File,
    io::{BufRead, BufReader},
    path::PathBuf,
};

#[derive(Clone, Debug, Default)]
pub(crate) struct MaskIndex {
    pub spans: HashMap<String, Vec<(u32, u32)>>,
}
impl MaskIndex {
    pub(crate) fn lookup(&self, chrom: &str) -> Option<&[(u32, u32)]> {
        self.spans
            .get(chrom)
            .or_else(|| self.spans.get(&crate::grid::annotation_alias(chrom)))
            .map(Vec::as_slice)
    }
    pub fn load(paths: &[PathBuf]) -> Result<Self> {
        let mut this = Self::default();
        for path in paths {
            for (line_no, line) in BufReader::new(File::open(path)?).lines().enumerate() {
                let line = line?;
                if line.trim().is_empty()
                    || line.starts_with('#')
                    || line.starts_with("track")
                    || line.starts_with("browser")
                {
                    continue;
                }
                let fields: Vec<_> = line.split('\t').collect();
                let parse = || -> Result<(u32, u32)> {
                    if fields.len() >= 9 && fields[1].parse::<u32>().is_err() {
                        return Ok((
                            fields[3]
                                .parse::<u32>()?
                                .checked_sub(1)
                                .ok_or_else(|| invalid("GTF starts are 1-based"))?,
                            fields[4].parse()?,
                        ));
                    }
                    if fields.len() < 3 {
                        return Err(invalid(
                            "blacklist needs at least three tab-separated columns",
                        ));
                    }
                    Ok((fields[1].parse()?, fields[2].parse()?))
                };
                let (s, e) = parse()
                    .map_err(|e| invalid(format!("{}:{}: {e}", path.display(), line_no + 1)))?;
                if s >= e {
                    return Err(invalid(format!(
                        "{}:{}: invalid blacklist interval",
                        path.display(),
                        line_no + 1
                    )));
                }
                this.spans.entry(fields[0].into()).or_default().push((s, e));
            }
        }
        for spans in this.spans.values_mut() {
            spans.sort_unstable();
        }
        Ok(this)
    }
    pub fn contains_start(&self, chrom: &str, pos: u32) -> bool {
        self.lookup(chrom)
            .is_some_and(|spans| spans.iter().any(|&(s, e)| s <= pos && pos < e))
    }
    pub fn subtract(&self, chrom: &str, start: u32, end: u32) -> Vec<(u32, u32)> {
        let mut result = Vec::new();
        let mut cursor = start;
        if let Some(spans) = self.lookup(chrom) {
            for &(s, e) in spans {
                if e <= cursor {
                    continue;
                }
                if s >= end {
                    break;
                }
                if s > cursor {
                    result.push((cursor, s.min(end)));
                }
                cursor = cursor.max(e);
                if cursor >= end {
                    break;
                }
            }
        }
        if cursor < end {
            result.push((cursor, end));
        }
        result
    }
    pub fn validate_normalization(&self) -> Result<()> {
        for (chrom, spans) in &self.spans {
            if spans.windows(2).any(|s| s[1].0 < s[0].1) {
                return Err(invalid(format!(
                    "overlapping blacklist intervals on {chrom} cannot define normalization population"
                )));
            }
        }
        Ok(())
    }
    pub fn overlaps(&self, chrom: &str, start: u32, end: u32) -> bool {
        self.lookup(chrom)
            .is_some_and(|v| v.iter().any(|&(s, e)| s < end && start < e))
    }
    pub fn task_spans(&self, dict: &Dictionary, span: Span) -> Vec<Span> {
        self.subtract(&dict[span.chrom].name, span.start, span.end)
            .into_iter()
            .map(|(start, end)| Span {
                chrom: span.chrom,
                start,
                end,
            })
            .collect()
    }
}
