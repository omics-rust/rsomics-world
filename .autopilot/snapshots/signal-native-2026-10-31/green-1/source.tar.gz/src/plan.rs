use crate::{cli::*, model::*};
use rsomics_common::Result;

fn bin(value: u32) -> Result<()> {
    if value == 0 {
        Err(invalid("bin size must be positive"))
    } else {
        Ok(())
    }
}
fn bam(options: &BamArgs) -> Result<()> {
    if options.max_fragment_length > 0 && options.min_fragment_length > options.max_fragment_length
    {
        return Err(invalid("minimum fragment length exceeds maximum"));
    }
    if options.extend_reads.is_some_and(|v| v > 2000) {
        return Err(invalid("extension length must not exceed2000"));
    }
    Ok(())
}
fn normalization(options: &NormalizeArgs) -> Result<()> {
    if options.normalize == Normalization::Rpgc
        && options.effective_genome_size.is_none_or(|n| n == 0)
    {
        return Err(invalid("RPGC requires a positive effective genome size"));
    }
    Ok(())
}
fn has_bam_options(args: &BamArgs) -> bool {
    args.extend_reads.is_some()
        || args.center_reads
        || args.ignore_duplicates
        || args.min_mapq != 0
        || args.include_flags != 0
        || args.exclude_flags != 0
        || args.min_fragment_length != 0
        || args.max_fragment_length != 0
}
pub(crate) fn validate(command: Command) -> Result<Command> {
    match &command {
        Command::Track(a) => {
            bin(a.bin_size)?;
            bam(&a.bam_options)?;
            normalization(&a.normalization)?;
            if !a.scale.is_finite() {
                return Err(invalid("scale must be finite"));
            }
            if a.offset.contains(&0) {
                return Err(invalid("offset positions are1-based and cannot be zero"));
            }
        }
        Command::Compare(a) => {
            bin(a.bin_size)?;
            bam(&a.bam_options)?;
            normalization(&a.normalization)?;
            if a.input == InputKind::Bigwig
                && (has_bam_options(&a.bam_options)
                    || a.normalization.normalize != Normalization::None
                    || a.normalization.exact_scaling
                    || !a.normalization.ignore_for_normalization.is_empty()
                    || a.smooth_length.is_some()
                    || a.scale_method != ScaleMethod::ReadCount)
            {
                return Err(invalid(
                    "BAM filters, normalization, smoothing and scale-method are not bigWig compare options",
                ));
            }
            if a.input == InputKind::Bam
                && (a.fixed_step || a.normalization.normalize == Normalization::Rpgc)
            {
                return Err(invalid("BAM compare does not support fixed-step or RPGC"));
            }
            if a.input == InputKind::Bam
                && a.normalization.normalize != Normalization::None
                && a.scale_method != ScaleMethod::None
            {
                return Err(invalid("normalize requires --scale-method none"));
            }
            if a.pseudocount.iter().any(|x| !x.is_finite()) {
                return Err(invalid("pseudocounts must be finite"));
            }
            if a.sample_length == 0 || a.number_of_samples == 0 {
                return Err(invalid("SES sample length/count must be positive"));
            }
        }
        Command::Average(a) => {
            bin(a.bin_size)?;
        }
        Command::Summarize { mode } => {
            let a = match mode {
                SummaryCommand::Bins(a) | SummaryCommand::Regions(a) => a,
            };
            bin(a.bin_size)?;
            bam(&a.bam_options)?;
            if a.input == InputKind::Bigwig
                && (has_bam_options(&a.bam_options)
                    || a.scaling_factors.is_some()
                    || a.genome_chunk_size.is_some())
            {
                return Err(invalid(
                    "BAM summary options are not valid for bigWig inputs",
                ));
            }
            if a.input == InputKind::Bam && !a.chromosomes_to_skip.is_empty() {
                return Err(invalid("chromosomes-to-skip is a bigWig summary option"));
            }
        }
        Command::Matrix { mode } => {
            let a = match mode {
                MatrixCommand::Reference(a) | MatrixCommand::Scale(a) => a,
            };
            bin(a.bin_size)?;
            if a.execution.region.is_some() {
                return Err(invalid(
                    "matrix windows are defined by --regions, not --region",
                ));
            }
            if a.regions.is_empty() {
                return Err(invalid("matrix requires at least one regions file"));
            }
            if !a.scale.is_finite() {
                return Err(invalid("matrix scale must be finite"));
            }
        }
        Command::Filter(a) => {
            bam(&a.bam_options)?;
            if a.execution.region.is_some()
                || a.bam_options.extend_reads.is_some()
                || a.bam_options.center_reads
            {
                return Err(invalid(
                    "filter does not accept region/extension/centering options",
                ));
            }
            if !a.shift.is_empty() && a.shift.len() != 2 && a.shift.len() != 4 {
                return Err(invalid("shift requires exactly2 or4 values"));
            }
            if a.genome_chunk_length == 0 {
                return Err(invalid("filter genome chunk length must be positive"));
            }
        }
    }
    Ok(command)
}
