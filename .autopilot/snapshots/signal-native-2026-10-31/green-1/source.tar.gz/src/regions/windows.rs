use crate::{
    cli::MatrixArgs,
    model::{RefPoint, Region, invalid},
};
use rsomics_common::Result;
use std::ops::Range;

#[derive(Clone, Debug)]
pub(crate) struct Zone {
    pub blocks: Vec<Range<i64>>,
    pub bins: usize,
}
#[derive(Clone, Debug)]
pub(crate) struct WindowPlan {
    pub zones: Vec<Zone>,
    pub reverse: bool,
    pub pad_left: usize,
    pub pad_right: usize,
    pub short: bool,
}
#[derive(Clone, Copy, Debug)]
pub(crate) struct Geometry {
    pub before: u32,
    pub after: u32,
    pub body: u32,
    pub u5: u32,
    pub u3: u32,
    pub bin: u32,
    pub point: RefPoint,
    pub nan_after: bool,
}
impl Geometry {
    pub fn new(args: &MatrixArgs, scale: bool) -> Result<Self> {
        let this = Self {
            before: args.before.unwrap_or(if scale { 0 } else { 500 }),
            after: args.after.unwrap_or(if scale { 0 } else { 1500 }),
            body: if scale {
                args.body_length.unwrap_or(1000)
            } else {
                0
            },
            u5: args.unscaled_5prime,
            u3: args.unscaled_3prime,
            bin: args.bin_size,
            point: args.reference_point,
            nan_after: args.nan_after_end,
        };
        if this.bin == 0
            || [this.before, this.after, this.body, this.u5, this.u3]
                .iter()
                .any(|n| n % this.bin != 0)
        {
            return Err(invalid(
                "matrix lengths must be multiples of a positive bin size",
            ));
        }
        if (!scale && (this.u5 > 0 || this.u3 > 0 || args.body_length.is_some()))
            || (scale && this.body == 0)
        {
            return Err(invalid(
                "body and unscaled ends require scale mode with a positive body length",
            ));
        }
        if this.columns()? == 0 {
            return Err(invalid("matrix window has no bins"));
        }
        Ok(this)
    }
    pub fn columns(self) -> Result<usize> {
        let sum = [self.before, self.after, self.body, self.u5, self.u3]
            .into_iter()
            .try_fold(0u64, |a, b| {
                a.checked_add(u64::from(b))
                    .ok_or_else(|| invalid("matrix window length overflow"))
            })?;
        usize::try_from(sum / u64::from(self.bin))
            .map_err(|_| invalid("matrix column count overflow"))
    }
}
pub(crate) fn alternate_chrom(chrom: &str) -> String {
    if let Some(short) = chrom.strip_prefix("chr") {
        if short == "M" {
            "MT".into()
        } else {
            short.into()
        }
    } else if chrom == "MT" {
        "chrM".into()
    } else {
        format!("chr{chrom}")
    }
}
pub(crate) fn length(blocks: &[Range<i64>]) -> u64 {
    blocks.iter().map(|b| (b.end - b.start) as u64).sum()
}
pub(crate) fn slice(blocks: &[Range<i64>], from: u64, to: u64) -> Vec<Range<i64>> {
    let mut offset = 0u64;
    let mut output = Vec::new();
    for block in blocks {
        let next = offset + (block.end - block.start) as u64;
        if next > from && offset < to {
            let s = block.start + from.saturating_sub(offset) as i64;
            let e = block.start + (to.min(next) - offset) as i64;
            if s < e {
                output.push(s..e);
            }
        }
        offset = next;
        if offset >= to {
            break;
        }
    }
    output
}
pub(crate) fn plan(region: &Region, g: Geometry) -> Result<WindowPlan> {
    let blocks: Vec<_> = region
        .exons
        .iter()
        .map(|e| i64::from(e.start)..i64::from(e.end))
        .collect();
    let first = blocks
        .first()
        .ok_or_else(|| invalid("region has no exons"))?
        .start;
    let last = blocks
        .last()
        .ok_or_else(|| invalid("region has no exons"))?
        .end;
    let size = length(&blocks);
    let reverse = region.strand == '-';
    let (left, right, uleft, uright) = if reverse {
        (g.after, g.before, g.u3, g.u5)
    } else {
        (g.before, g.after, g.u5, g.u3)
    };
    let mut result = WindowPlan {
        zones: Vec::new(),
        reverse,
        pad_left: 0,
        pad_right: 0,
        short: false,
    };
    let zone = |blocks, bases: u32| Zone {
        blocks,
        bins: (bases / g.bin) as usize,
    };
    if g.body > 0 {
        let unscaled = u64::from(uleft) + u64::from(uright);
        if size < unscaled + u64::from(g.bin) {
            result.short = true;
            return Ok(result);
        }
        result.zones = vec![
            zone(
                if left == 0 {
                    vec![]
                } else {
                    std::iter::once(first - i64::from(left)..first).collect()
                },
                left,
            ),
            zone(slice(&blocks, 0, u64::from(uleft)), uleft),
            Zone {
                blocks: slice(&blocks, u64::from(uleft), size - u64::from(uright)),
                bins: (g.body / g.bin) as usize,
            },
            zone(slice(&blocks, size - u64::from(uright), size), uright),
            zone(
                if right == 0 {
                    vec![]
                } else {
                    std::iter::once(last..last + i64::from(right)).collect()
                },
                right,
            ),
        ];
        return Ok(result);
    }
    let anchor = match (g.point, reverse) {
        (RefPoint::Tss, false) | (RefPoint::Tes, true) => 0,
        (RefPoint::Tss, true) | (RefPoint::Tes, false) => size,
        (RefPoint::Center, _) => size / 2,
    };
    let available_left = anchor.min(u64::from(left));
    let available_right = (size - anchor).min(u64::from(right));
    let mut lhs = slice(&blocks, anchor - available_left, anchor);
    let mut rhs = slice(&blocks, anchor, anchor + available_right);
    let missing_left = u64::from(left) - available_left;
    let missing_right = u64::from(right) - available_right;
    // Exterior flanks are real genomic signal; nanAfterEnd limits only the inward side.
    let limit_left = g.nan_after && anchor > 0;
    let limit_right = g.nan_after && anchor < size;
    if missing_left > 0 && !limit_left {
        lhs.insert(0, first - missing_left as i64..first);
    }
    if missing_right > 0 && !limit_right {
        rhs.push(last..last + missing_right as i64);
    }
    let lb = (length(&lhs) / u64::from(g.bin)) as usize;
    let rb = (length(&rhs) / u64::from(g.bin)) as usize;
    result.pad_left = (left / g.bin) as usize - lb;
    result.pad_right = (right / g.bin) as usize - rb;
    result.zones = vec![
        Zone {
            blocks: if lb == 0 { vec![] } else { lhs },
            bins: lb,
        },
        Zone {
            blocks: if rb == 0 { vec![] } else { rhs },
            bins: rb,
        },
    ];
    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn center_exons_and_reverse_scale() {
        let r = Region {
            row_id: 0,
            chrom: "1".into(),
            exons: vec![10..30, 100..140],
            name: "x".into(),
            strand: '-',
            score: "0".into(),
            group: 0,
            source_order: 0,
        };
        let g = Geometry {
            before: 20,
            after: 10,
            body: 0,
            u5: 0,
            u3: 0,
            bin: 10,
            point: RefPoint::Center,
            nan_after: false,
        };
        let p = plan(&r, g).unwrap();
        assert_eq!(p.zones[0].blocks, vec![100..110]);
        assert_eq!(p.zones[1].blocks, vec![110..130]);
        let p = plan(
            &r,
            Geometry {
                body: 100,
                u5: 10,
                u3: 20,
                ..g
            },
        )
        .unwrap();
        assert_eq!(p.zones[1].blocks, vec![10..30]);
        assert_eq!(p.zones[3].blocks, vec![130..140]);
    }
}
