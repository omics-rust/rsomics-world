use super::{add, bounds, group, strand};
use crate::{
    cli::AnnotationArgs,
    model::{Region, RegionSet, invalid},
};
use rsomics_common::{Context, Result};
use std::collections::{HashMap, HashSet};

pub(super) fn parse(
    lines: &[String],
    default: &str,
    annotation: &AnnotationArgs,
    set: &mut RegionSet,
) -> Result<()> {
    let default = super::unique(&set.group_labels, default);
    let mut transcripts: Vec<(String, Region)> = Vec::new();
    type Exon = (String, char, std::ops::Range<u32>);
    let mut exons: HashMap<(usize, String), Vec<Exon>> = HashMap::new();
    let mut seen = HashSet::new();
    let mut current_group = None;
    for (line_number, line) in lines.iter().enumerate() {
        if line.trim().is_empty() || line.starts_with('#') {
            continue;
        }
        let mut parse = || -> Result<()> {
            let f: Vec<_> = line.split('\t').collect();
            if f.len() != 9 {
                return Err(invalid("GTF requires exactly nine tab-separated fields"));
            }
            let span = bounds(f[3], f[4], true)?;
            let direction = strand(f[6])?;
            let transcript = f[2].eq_ignore_ascii_case(&annotation.transcript_id);
            let exon = f[2].eq_ignore_ascii_case(&annotation.exon_id);
            if !transcript && !exon {
                return Ok(());
            }
            let attrs = attributes(f[8])?;
            let name = attrs
                .get(&annotation.transcript_id_designator)
                .filter(|s| !s.is_empty())
                .ok_or_else(|| {
                    invalid(format!(
                        "GTF feature lacks {}",
                        annotation.transcript_id_designator
                    ))
                })?
                .clone();
            if transcript {
                let label = attrs
                    .get("deepTools_group")
                    .map(String::as_str)
                    .unwrap_or(&default);
                let group_id = group(set, label, false);
                current_group = Some(group_id);
                if !seen.insert((group_id, name.clone())) {
                    eprintln!(
                        "Warning: {name} occurs more than once; using first transcript instance"
                    );
                    return Ok(());
                }
                transcripts.push((
                    name.clone(),
                    Region {
                        row_id: 0,
                        chrom: f[0].into(),
                        exons: vec![span.clone()],
                        name: name.clone(),
                        strand: direction,
                        score: f[5].into(),
                        group: group_id,
                        source_order: 0,
                    },
                ));
            }
            if exon && annotation.metagene {
                let group_id = if let Some(label) = attrs.get("deepTools_group") {
                    group(set, label, false)
                } else {
                    current_group.ok_or_else(|| {
                        invalid("GTF exon precedes any selected transcript feature")
                    })?
                };
                exons
                    .entry((group_id, name))
                    .or_default()
                    .push((f[0].into(), direction, span));
            }
            Ok(())
        };
        parse().rs_with_context(|| format!("line {}", line_number + 1))?;
    }
    for (id, mut transcript) in transcripts {
        if annotation.metagene {
            let Some(blocks) = exons.get(&(transcript.group, id.clone())) else {
                eprintln!(
                    "Warning: GTF transcript {id} has no selected exon features; retaining transcript bounds as the pinned parser does"
                );
                add(set, transcript);
                continue;
            };
            let outer = transcript.exons[0].clone();
            let mut spans = Vec::with_capacity(blocks.len());
            for (chrom, direction, span) in blocks {
                if *chrom != transcript.chrom
                    || *direction != transcript.strand
                    || span.start < outer.start
                    || span.end > outer.end
                {
                    return Err(invalid(format!(
                        "GTF exon inconsistent with transcript {id}"
                    )));
                }
                spans.push(span.clone());
            }
            spans.sort_by_key(|s| (s.start, s.end));
            transcript.exons = spans;
        }
        add(set, transcript);
    }
    Ok(())
}
fn attributes(raw: &str) -> Result<HashMap<String, String>> {
    let mut output = HashMap::new();
    for field in raw.split(';').map(str::trim).filter(|s| !s.is_empty()) {
        let at = field
            .find(char::is_whitespace)
            .ok_or_else(|| invalid("GTF attribute requires key and value"))?;
        let key = &field[..at];
        let value = field[at..].trim();
        if value.is_empty() || value.starts_with('"') != value.ends_with('"') {
            return Err(invalid("malformed GTF attribute value"));
        }
        if output
            .insert(key.to_owned(), value.trim_matches('"').to_owned())
            .is_some()
        {
            return Err(invalid("duplicate GTF attribute key"));
        }
    }
    Ok(output)
}
