use crate::{
    cli::AnnotationArgs,
    model::{Region, RegionSet, invalid},
};
use flate2::read::MultiGzDecoder;
use rsomics_common::{Context, Result};
use std::{
    collections::HashSet,
    fs::File,
    io::{BufRead, BufReader, Read},
    path::PathBuf,
};
mod bed;
mod gtf;
pub(crate) mod windows;

pub(super) fn unique(existing: impl IntoIterator<Item = impl AsRef<str>>, name: &str) -> String {
    let names: HashSet<String> = existing
        .into_iter()
        .map(|s| s.as_ref().to_owned())
        .collect();
    if !names.contains(name) {
        return name.to_owned();
    }
    let mut n = 1usize;
    loop {
        let candidate = format!("{name}_r{n}");
        if !names.contains(&candidate) {
            return candidate;
        }
        n += 1;
    }
}
pub(super) fn group(set: &mut RegionSet, label: &str, distinct: bool) -> usize {
    if !distinct && let Some(&i) = set.group_ids.get(label) {
        return i;
    }
    let label = indexed_name(&mut set.group_names, &mut set.group_suffixes, label);
    set.group_ids.insert(label.clone(), set.group_labels.len());
    set.group_labels.push(label);
    set.group_labels.len() - 1
}
fn indexed_name(
    names: &mut HashSet<String>,
    suffixes: &mut std::collections::HashMap<String, usize>,
    name: &str,
) -> String {
    if names.insert(name.to_owned()) {
        return name.to_owned();
    }
    let next = suffixes.entry(name.to_owned()).or_insert(1);
    loop {
        let candidate = format!("{name}_r{next}");
        *next += 1;
        if names.insert(candidate.clone()) {
            return candidate;
        }
    }
}
pub(super) fn add(set: &mut RegionSet, mut row: Region) {
    row.row_id = set.regions.len();
    row.source_order = row.row_id;
    row.name = indexed_name(&mut set.region_names, &mut set.region_suffixes, &row.name);
    if !set.chromosomes.contains(&row.chrom) {
        let other = windows::alternate_chrom(&row.chrom);
        if set.chromosomes.contains(&other) {
            row.chrom = other;
        }
    }
    set.chromosomes.insert(row.chrom.clone());
    set.by_chrom
        .entry(row.chrom.clone())
        .or_default()
        .push(row.row_id);
    set.regions.push(row);
}
pub(super) fn strand(raw: &str) -> Result<char> {
    match raw {
        "+" => Ok('+'),
        "-" => Ok('-'),
        "." | "?" => Ok('.'),
        _ => Err(invalid(format!("invalid annotation strand {raw:?}"))),
    }
}
pub(super) fn bounds(start: &str, end: &str, gtf: bool) -> Result<std::ops::Range<u32>> {
    let start: u32 = start.parse()?;
    let start = if gtf {
        start
            .checked_sub(1)
            .ok_or_else(|| invalid("GTF start must be positive"))?
    } else {
        start
    };
    let end = end.parse()?;
    if start >= end {
        return Err(invalid("annotation interval must be nonempty and ordered"));
    }
    Ok(start..end)
}
pub(crate) fn load(paths: &[PathBuf], annotation: &AnnotationArgs) -> Result<RegionSet> {
    if paths.is_empty() {
        return Err(invalid("at least one region file is required"));
    }
    let mut set = RegionSet::default();
    for path in paths {
        let mut file =
            File::open(path).rs_with_context(|| format!("opening {}", path.display()))?;
        let mut magic = [0; 3];
        let count = file.read(&mut magic)?;
        drop(file);
        let file = File::open(path)?;
        let input: Box<dyn Read> = if count == 3 && magic == [0x1f, 0x8b, 8] {
            Box::new(MultiGzDecoder::new(file))
        } else {
            Box::new(file)
        };
        let lines: Vec<String> = BufReader::new(input)
            .lines()
            .collect::<std::io::Result<_>>()?;
        let Some(first) = lines.iter().find(|l| {
            !l.trim().is_empty()
                && !l.starts_with('#')
                && !l.starts_with("track")
                && !l.starts_with("browser")
        }) else {
            continue;
        };
        let fields: Vec<_> = first.split('\t').collect();
        let default = if paths.len() == 1 {
            "genes".to_owned()
        } else {
            path.file_name()
                .ok_or_else(|| invalid("region path has no filename"))?
                .to_string_lossy()
                .into_owned()
        };
        let parsed = if fields.len() >= 9 && fields[1].parse::<u32>().is_err() {
            gtf::parse(&lines, &default, annotation, &mut set)
        } else {
            bed::parse(&lines, &default, annotation, &mut set)
        };
        parsed.rs_with_context(|| format!("parsing {}", path.display()))?;
    }
    if set.regions.is_empty() {
        return Err(invalid("no valid BED/GTF regions"));
    }
    Ok(set)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn terminal_groups_global_names_and_strict_blocks() {
        let a = AnnotationArgs {
            metagene: true,
            transcript_id: "transcript".into(),
            exon_id: "exon".into(),
            transcript_id_designator: "transcript_id".into(),
        };
        let lines = [
            "chr1\t10\t20\tx\t0\t+",
            "#first",
            "chr1\t30\t50\tx\t0\t-",
            "#second",
        ]
        .map(String::from);
        let mut set = RegionSet::default();
        bed::parse(&lines, "genes", &a, &mut set).unwrap();
        assert_eq!(set.group_labels, ["first", "second"]);
        assert_eq!(set.regions[1].name, "x_r1");
        assert_eq!(set.regions[1].group, 1);
        for name in ["x_r2", "x", "x_r1", "x"] {
            let mut region = set.regions[0].clone();
            region.name = name.into();
            add(&mut set, region);
        }
        assert_eq!(
            set.regions
                .iter()
                .map(|r| r.name.as_str())
                .collect::<Vec<_>>(),
            ["x", "x_r1", "x_r2", "x_r3", "x_r1_r1", "x_r4"]
        );
        let bad = ["chr1\t0\t100\tx\t0\t+\t0\t100\t0\t2\t20\t0,80".into()];
        assert!(bed::parse(&bad, "g", &a, &mut RegionSet::default()).is_err());
    }

    #[test]
    fn gtf_feature_override_grouped_graph_and_missing_key() {
        let a = AnnotationArgs {
            metagene: true,
            transcript_id: "gene".into(),
            exon_id: "CDS".into(),
            transcript_id_designator: "gene_id".into(),
        };
        let lines = [
            "chr1\tx\tgene\t101\t400\t.\t+\t.\tgene_id \"g\"; deepTools_group \"A\";",
            "chr1\tx\tCDS\t101\t150\t.\t+\t.\tgene_id \"g\";",
            "chr1\tx\tCDS\t101\t150\t.\t+\t.\tgene_id \"g\";",
            "chr1\tx\tgene\t801\t1100\t.\t-\t.\tgene_id \"g\"; deepTools_group \"B\";",
            "chr1\tx\tCDS\t1021\t1100\t.\t-\t.\tgene_id \"g\";",
        ]
        .map(String::from);
        let mut set = RegionSet::default();
        gtf::parse(&lines, "genes", &a, &mut set).unwrap();
        assert_eq!(set.group_labels, ["A", "B"]);
        assert_eq!(set.regions[0].exons, vec![100..150, 100..150]);
        assert_eq!(set.regions[1].exons, vec![1020..1100]);
        assert_eq!(set.regions[1].name, "g_r1");
        let bad = ["chr1\tx\tgene\t101\t400\t.\t+\t.\ttranscript_id \"x\";".into()];
        assert!(gtf::parse(&bad, "genes", &a, &mut RegionSet::default()).is_err());
    }
}
