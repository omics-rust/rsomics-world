use super::{add, bounds, group, strand};
use crate::{
    cli::AnnotationArgs,
    model::{Region, RegionSet, invalid},
};
use rsomics_common::{Context, Result};

pub(super) fn parse(
    lines: &[String],
    default: &str,
    annotation: &AnnotationArgs,
    set: &mut RegionSet,
) -> Result<()> {
    let mut label_column = None;
    let mut pending: Vec<Region> = Vec::new();
    let mut begun = false;
    for (line_number, line) in lines.iter().enumerate() {
        let line = line.trim_end();
        if line.trim().is_empty() || line.starts_with("browser") || line.starts_with("track") {
            continue;
        }
        if let Some(comment) = line.strip_prefix('#') {
            if !begun {
                if let Some(i) = line.split('\t').position(|s| s == "deepTools_group") {
                    label_column = Some(i);
                }
            } else if label_column.is_none() && !pending.is_empty() {
                let label = comment.trim();
                let index = group(set, if label.is_empty() { default } else { label }, true);
                for mut region in pending.drain(..) {
                    region.group = index;
                    add(set, region);
                }
            }
            continue;
        }
        begun = true;
        let parse = || -> Result<(Region, Option<String>)> {
            let mut f: Vec<_> = line.split('\t').collect();
            let label = if let Some(i) = label_column {
                if i >= f.len() {
                    return Err(invalid("missing deepTools_group column"));
                }
                Some(f.remove(i).to_owned())
            } else {
                None
            };
            if f.len() < 3 {
                return Err(invalid("BED requires three tab-separated fields"));
            }
            let span = bounds(f[1], f[2], false)?;
            if f[0].is_empty() {
                return Err(invalid("empty BED chromosome"));
            }
            let named = f.len() >= 6;
            let name = if named {
                f[3].to_owned()
            } else {
                format!("{}:{}-{}", f[0], f[1], f[2])
            };
            let score = if named && f[4] != "." {
                let score: f64 = f[4].parse()?;
                if score.is_finite() && score.fract() == 0.0 {
                    format!("{score:.1}")
                } else {
                    score.to_string().to_lowercase()
                }
            } else {
                ".".into()
            };
            let strand = if named { strand(f[5])? } else { '.' };
            let mut exons = vec![span.clone()];
            if f.len() >= 12 {
                let count: usize = f[9].parse()?;
                let sizes = numbers(f[10])?;
                let offsets = numbers(f[11])?;
                if count == 0 || count != sizes.len() || count != offsets.len() {
                    return Err(invalid(
                        "BED12 blockCount disagrees with blockSizes/blockStarts",
                    ));
                }
                let mut blocks = Vec::with_capacity(count);
                for (size, offset) in sizes.into_iter().zip(offsets) {
                    let start = span
                        .start
                        .checked_add(offset)
                        .ok_or_else(|| invalid("BED12 block start overflow"))?;
                    let end = start
                        .checked_add(size)
                        .ok_or_else(|| invalid("BED12 block end overflow"))?;
                    if start >= end
                        || end > span.end
                        || blocks
                            .last()
                            .is_some_and(|p: &std::ops::Range<u32>| p.end > start)
                    {
                        return Err(invalid(
                            "BED12 blocks must be nonempty, ordered, nonoverlapping, and inside bounds",
                        ));
                    }
                    blocks.push(start..end);
                }
                if annotation.metagene {
                    exons = blocks;
                }
            }
            Ok((
                Region {
                    row_id: 0,
                    chrom: f[0].into(),
                    exons,
                    name,
                    strand,
                    score,
                    group: 0,
                    source_order: 0,
                },
                label,
            ))
        };
        let (mut row, label) = parse().rs_with_context(|| format!("line {}", line_number + 1))?;
        if let Some(label) = label {
            row.group = group(set, &label, false);
            add(set, row);
        } else {
            pending.push(row);
        }
    }
    if !pending.is_empty() {
        let index = group(set, default, true);
        for mut row in pending {
            row.group = index;
            add(set, row);
        }
    }
    Ok(())
}
fn numbers(s: &str) -> Result<Vec<u32>> {
    s.trim_end_matches(',')
        .split(',')
        .map(|s| s.parse().map_err(Into::into))
        .collect()
}
