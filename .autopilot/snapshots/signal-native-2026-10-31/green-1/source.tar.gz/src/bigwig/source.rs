use crate::model::{Dictionary, invalid};
use bigtools::{BBIDataProcessor, BBIDataSource, BBIProcessError, ProcessDataError, Value};
use rsomics_common::{Result, RsomicsError};
use std::{
    fs::File,
    io::{BufRead, BufReader},
    path::Path,
};

pub(super) struct SignalSource {
    reader: BufReader<File>,
    dictionary: Dictionary,
    line: String,
}
impl SignalSource {
    pub fn open(path: &Path, dictionary: &Dictionary) -> Result<Self> {
        Ok(Self {
            reader: BufReader::new(File::open(path)?),
            dictionary: dictionary.clone(),
            line: String::new(),
        })
    }
    fn next(&mut self) -> Result<Option<(String, Value)>> {
        self.line.clear();
        if self.reader.read_line(&mut self.line)? == 0 {
            return Ok(None);
        }
        let f: Vec<_> = self
            .line
            .trim_end_matches(['\r', '\n'])
            .split('\t')
            .collect();
        if f.len() != 4 {
            return Err(invalid("staged signal stream needs four columns"));
        }
        let start = f[1].parse()?;
        let end = f[2].parse()?;
        if start >= end {
            return Err(invalid("staged signal intervals must be nonempty"));
        }
        Ok(Some((
            f[0].to_owned(),
            Value {
                start,
                end,
                value: f[3].parse()?,
            },
        )))
    }
}
impl BBIDataSource for SignalSource {
    type Value = Value;
    type Error = RsomicsError;
    fn process_to_bbi<
        P: BBIDataProcessor<Value = Value> + Send + 'static,
        S: FnMut(String) -> std::result::Result<P, ProcessDataError>,
        A: FnMut(P),
    >(
        &mut self,
        runtime: &tokio::runtime::Runtime,
        start_processing: &mut S,
        advance: &mut A,
    ) -> std::result::Result<(), BBIProcessError<Self::Error>> {
        runtime.block_on(async {
            let mut pending = self.next().map_err(BBIProcessError::SourceError)?;
            for chrom in self.dictionary.clone() {
                let mut processor = start_processing(chrom.name.clone())?;
                while pending
                    .as_ref()
                    .is_some_and(|(name, _)| *name == chrom.name)
                {
                    let Some((_, value)) = pending.take() else {
                        return Err(BBIProcessError::SourceError(invalid(
                            "signal lookahead disappeared",
                        )));
                    };
                    pending = self.next().map_err(BBIProcessError::SourceError)?;
                    let next = pending
                        .as_ref()
                        .filter(|(name, _)| *name == chrom.name)
                        .map(|(_, v)| v);
                    processor.do_process(value, next).await?;
                }
                advance(processor);
            }
            if pending.is_some() {
                return Err(BBIProcessError::SourceError(invalid(
                    "staged signal chromosome order differs from output dictionary",
                )));
            }
            Ok(())
        })
    }
}
