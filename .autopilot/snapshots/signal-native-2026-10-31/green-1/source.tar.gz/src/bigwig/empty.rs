use crate::model::{Dictionary, invalid};
use rsomics_common::Result;
use std::{fs::File, io::Write, path::Path};

pub(super) fn write(path: &Path, dictionary: &Dictionary) -> Result<()> {
    let count = u16::try_from(dictionary.len())
        .map_err(|_| invalid("bigWig dictionary exceeds the codec's65535-reference limit"))?;
    let key_size = dictionary
        .iter()
        .map(|c| c.name.len())
        .max()
        .unwrap_or(0)
        .checked_add(1)
        .ok_or_else(|| invalid("chromosome key size overflow"))?;
    let chrom_tree = 104u64;
    let tree_bytes = 36u64
        .checked_add(
            (dictionary.len() as u64)
                .checked_mul((key_size + 8) as u64)
                .ok_or_else(|| invalid("chromosome tree size overflow"))?,
        )
        .ok_or_else(|| invalid("chromosome tree size overflow"))?;
    let data = chrom_tree
        .checked_add(tree_bytes)
        .ok_or_else(|| invalid("empty bigWig offset overflow"))?;
    let index = data
        .checked_add(8)
        .ok_or_else(|| invalid("empty bigWig offset overflow"))?;
    let mut header = [0u8; 64];
    header[..4].copy_from_slice(&0x888ffc26u32.to_le_bytes());
    header[4..6].copy_from_slice(&4u16.to_le_bytes());
    header[8..16].copy_from_slice(&chrom_tree.to_le_bytes());
    header[16..24].copy_from_slice(&data.to_le_bytes());
    header[24..32].copy_from_slice(&index.to_le_bytes());
    header[44..52].copy_from_slice(&64u64.to_le_bytes());
    let mut file = File::create(path)?;
    file.write_all(&header)?;
    file.write_all(&[0; 40])?;
    file.write_all(&0x78ca8c91u32.to_le_bytes())?;
    file.write_all(&u32::from(count).max(256).to_le_bytes())?;
    file.write_all(
        &u32::try_from(key_size)
            .map_err(|_| invalid("chromosome key is too long"))?
            .to_le_bytes(),
    )?;
    file.write_all(&8u32.to_le_bytes())?;
    file.write_all(&u64::from(count).to_le_bytes())?;
    file.write_all(&0u64.to_le_bytes())?;
    file.write_all(&[1, 0])?;
    file.write_all(&count.to_le_bytes())?;
    let mut key = vec![0u8; key_size];
    for (id, chrom) in dictionary.iter().enumerate() {
        key.fill(0);
        key[..chrom.name.len()].copy_from_slice(chrom.name.as_bytes());
        file.write_all(&key)?;
        file.write_all(&(id as u32).to_le_bytes())?;
        file.write_all(&chrom.len.to_le_bytes())?;
    }
    file.write_all(&0u64.to_le_bytes())?;
    let mut root = [0u8; 48];
    root[..4].copy_from_slice(&0x2468ace0u32.to_le_bytes());
    root[4..8].copy_from_slice(&256u32.to_le_bytes());
    root[40..44].copy_from_slice(&1u32.to_le_bytes());
    file.write_all(&root)?;
    file.write_all(&[1, 0, 0, 0])?;
    file.write_all(&0x888ffc26u32.to_le_bytes())?;
    file.flush()?;
    Ok(())
}
