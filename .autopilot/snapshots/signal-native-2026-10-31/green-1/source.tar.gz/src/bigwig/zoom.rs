use crate::model::{Dictionary, RunContext, invalid};
use flate2::{Compression, write::ZlibEncoder};
use rsomics_common::Result;
use std::{
    collections::HashMap,
    fs::{File, OpenOptions},
    io::{BufRead, BufReader, Read, Seek, SeekFrom, Write},
    path::Path,
};

const RECORDS_PER_BUFFER: usize = 1023;
const FANOUT: usize = 256;
#[derive(Clone, Copy)]
struct Record {
    chrom: u32,
    start: u32,
    end: u32,
    bases: u32,
    min: f32,
    max: f32,
    sum: f32,
    squares: f32,
}
#[derive(Clone, Copy)]
struct Section {
    bounds: [u32; 4],
    offset: u64,
    size: u64,
}
struct ZoomSpool {
    file: tempfile::NamedTempFile,
    sections: Vec<Section>,
}
struct Node {
    bounds: [u32; 4],
    children: Children,
}
enum Children {
    Leaves(Vec<Section>),
    Branches(Vec<Node>),
}

fn write_record(file: &mut dyn Write, r: Record) -> Result<()> {
    for n in [r.chrom, r.start, r.end, r.bases] {
        file.write_all(&n.to_le_bytes())?;
    }
    for n in [r.min, r.max, r.sum, r.squares] {
        file.write_all(&n.to_le_bytes())?;
    }
    Ok(())
}
fn flush(records: &mut Vec<Record>, file: &mut File, sections: &mut Vec<Section>) -> Result<()> {
    if records.is_empty() {
        return Ok(());
    }
    let first = records[0];
    let last = records[records.len() - 1];
    let offset = file.stream_position()?;
    let mut compressed = ZlibEncoder::new(Vec::new(), Compression::default());
    for r in records.iter() {
        write_record(&mut compressed, *r)?;
    }
    let bytes = compressed.finish()?;
    file.write_all(&bytes)?;
    sections.push(Section {
        bounds: [first.chrom, first.start, last.chrom, last.end],
        offset,
        size: bytes.len() as u64,
    });
    records.clear();
    Ok(())
}
fn construct(
    graph: &Path,
    reduction: u32,
    ids: &HashMap<String, u32>,
    context: &RunContext,
) -> Result<ZoomSpool> {
    let mut file = tempfile::NamedTempFile::new_in(&context.scratch)?;
    let mut sections = Vec::new();
    let mut records: Vec<Record> = Vec::with_capacity(RECORDS_PER_BUFFER);
    let (mut sum, mut squares) = (0.0f64, 0.0f64);
    for (line_no, line) in BufReader::new(File::open(graph)?).lines().enumerate() {
        let line = line?;
        let f: Vec<_> = line.split('\t').collect();
        if f.len() != 4 {
            return Err(invalid(format!(
                "staged bedGraph line{} is malformed",
                line_no + 1
            )));
        }
        let chrom = *ids
            .get(f[0])
            .ok_or_else(|| invalid("staged bedGraph chromosome absent from BBI dictionary"))?;
        let mut start = f[1].parse::<u32>()?;
        let end = f[2].parse::<u32>()?;
        let value = f[3].parse::<f32>()?;
        while start < end {
            if records.len() >= RECORDS_PER_BUFFER {
                flush(&mut records, file.as_file_mut(), &mut sections)?;
                sum = 0.0;
                squares = 0.0;
            }
            let overlapping = records
                .last()
                .is_some_and(|r| r.chrom == chrom && start < r.start.saturating_add(reduction));
            if !overlapping {
                if let Some(previous) = records.last_mut() {
                    previous.sum = sum as f32;
                    previous.squares = squares as f32;
                    sum = 0.0;
                    squares = 0.0;
                }
                records.push(Record {
                    chrom,
                    start,
                    end: start,
                    bases: 0,
                    min: value,
                    max: value,
                    sum: 0.0,
                    squares: 0.0,
                });
            }
            let current = records
                .last_mut()
                .ok_or_else(|| invalid("zoom record was not created"))?;
            let stop = current.start.saturating_add(reduction).min(end);
            if stop <= start {
                return Err(invalid("zoom construction made no progress"));
            }
            let width = stop - start;
            current.end = stop;
            current.bases = current
                .bases
                .checked_add(width)
                .ok_or_else(|| invalid("zoom coverage overflow"))?;
            if value < current.min {
                current.min = value;
            }
            if value > current.max {
                current.max = value;
            }
            sum += f64::from(width as f32 * value);
            squares += f64::from(width) * f64::from(value).powi(2);
            start = stop;
        }
    }
    // DeepTools356's libBigWig profile leaves each terminal buffer accumulator unwritten.
    flush(&mut records, file.as_file_mut(), &mut sections)?;
    Ok(ZoomSpool { file, sections })
}
fn tree(sections: Vec<Section>) -> Result<Node> {
    if sections.is_empty() {
        return Err(invalid("empty native zoom index"));
    }
    let mut nodes: Vec<Node> = sections
        .chunks(FANOUT)
        .map(|chunk| Node {
            bounds: [
                chunk[0].bounds[0],
                chunk[0].bounds[1],
                chunk[chunk.len() - 1].bounds[2],
                chunk[chunk.len() - 1].bounds[3],
            ],
            children: Children::Leaves(chunk.to_vec()),
        })
        .collect();
    while nodes.len() > 1 {
        let mut parents = Vec::new();
        let mut input = nodes.into_iter();
        loop {
            let children: Vec<_> = input.by_ref().take(FANOUT).collect();
            if children.is_empty() {
                break;
            }
            let first = &children[0];
            let last = &children[children.len() - 1];
            parents.push(Node {
                bounds: [
                    first.bounds[0],
                    first.bounds[1],
                    last.bounds[2],
                    last.bounds[3],
                ],
                children: Children::Branches(children),
            });
        }
        nodes = parents;
    }
    nodes
        .pop()
        .ok_or_else(|| invalid("zoom index tree missing"))
}
fn write_bounds(file: &mut File, bounds: [u32; 4]) -> Result<()> {
    for n in bounds {
        file.write_all(&n.to_le_bytes())?;
    }
    Ok(())
}
fn write_node(file: &mut File, node: &Node) -> Result<u64> {
    let offset = file.stream_position()?;
    match &node.children {
        Children::Leaves(items) => {
            file.write_all(&[1, 0])?;
            file.write_all(&(items.len() as u16).to_le_bytes())?;
            for item in items {
                write_bounds(file, item.bounds)?;
                file.write_all(&item.offset.to_le_bytes())?;
                file.write_all(&item.size.to_le_bytes())?;
            }
        }
        Children::Branches(children) => {
            file.write_all(&[0, 0])?;
            file.write_all(&(children.len() as u16).to_le_bytes())?;
            let placeholders = file.stream_position()?;
            file.write_all(&vec![0; children.len() * 24])?;
            let mut pointers = Vec::with_capacity(children.len());
            for child in children {
                pointers.push(write_node(file, child)?);
            }
            let end = file.stream_position()?;
            file.seek(SeekFrom::Start(placeholders))?;
            for (child, pointer) in children.iter().zip(pointers) {
                write_bounds(file, child.bounds)?;
                file.write_all(&pointer.to_le_bytes())?;
            }
            file.seek(SeekFrom::Start(end))?;
        }
    }
    Ok(offset)
}
fn write_index(file: &mut File, sections: &[Section]) -> Result<u64> {
    let index = file.stream_position()?;
    let root = tree(sections.to_vec())?;
    file.write_all(&0x2468ace0u32.to_le_bytes())?;
    file.write_all(&(FANOUT as u32).to_le_bytes())?;
    file.write_all(&(sections.len() as u64).to_le_bytes())?;
    write_bounds(file, root.bounds)?;
    file.write_all(&0u64.to_le_bytes())?;
    file.write_all(&1024u32.to_le_bytes())?;
    file.write_all(&0u32.to_le_bytes())?;
    write_node(file, &root)?;
    Ok(index)
}
pub(super) fn install(
    path: &Path,
    graph: &Path,
    dictionary: &Dictionary,
    levels: &[u32],
    ids: &HashMap<String, u32>,
    context: &RunContext,
) -> Result<Vec<u32>> {
    let mut file = OpenOptions::new().read(true).write(true).open(path)?;
    let mut magic = [0; 4];
    file.read_exact(&mut magic)?;
    if u32::from_le_bytes(magic) != 0x888ffc26 {
        return Err(invalid(
            "native staged BBI has unexpected byte order or magic",
        ));
    }
    let mut accepted = Vec::new();
    let mut previous_blocks = None;
    for &level in levels {
        let mut spool = construct(graph, level, ids, context)?;
        if previous_blocks == Some(spool.sections.len()) {
            break;
        }
        previous_blocks = Some(spool.sections.len());
        let data = file.seek(SeekFrom::End(0))?;
        file.write_all(
            &u32::try_from(spool.sections.len())
                .map_err(|_| invalid("too many native zoom blocks"))?
                .to_le_bytes(),
        )?;
        let base = file.stream_position()?;
        spool.file.as_file_mut().seek(SeekFrom::Start(0))?;
        std::io::copy(spool.file.as_file_mut(), &mut file)?;
        for section in &mut spool.sections {
            section.offset = section
                .offset
                .checked_add(base)
                .ok_or_else(|| invalid("zoom offset overflow"))?;
        }
        let index = write_index(&mut file, &spool.sections)?;
        let header = 64 + accepted.len() as u64 * 24;
        file.seek(SeekFrom::Start(header))?;
        file.write_all(&level.to_le_bytes())?;
        file.write_all(&0u32.to_le_bytes())?;
        file.write_all(&data.to_le_bytes())?;
        file.write_all(&index.to_le_bytes())?;
        accepted.push(level);
    }
    file.seek(SeekFrom::Start(6))?;
    file.write_all(&(accepted.len() as u16).to_le_bytes())?;
    file.seek(SeekFrom::Start(52))?;
    let mut size = [0; 4];
    file.read_exact(&mut size)?;
    let size = u32::from_le_bytes(size).max((RECORDS_PER_BUFFER * 32) as u32);
    file.seek(SeekFrom::Start(52))?;
    file.write_all(&size.to_le_bytes())?;
    file.flush()?;
    let _ = dictionary;
    Ok(accepted)
}
