use crate::model::{Chromosome, Dictionary, RunContext, invalid};
use bigtools::{BigWigRead, BigWigWrite, Value, utils::reopen::ReopenableFile};
use rsomics_common::{Context, Result};
use std::{
    fs::File,
    panic::{AssertUnwindSafe, catch_unwind},
    path::{Path, PathBuf},
};
mod empty;
mod preflight;
mod source;
mod zoom;

pub(crate) struct BwReader {
    pub path: PathBuf,
    inner: BigWigRead<ReopenableFile>,
    pub dictionary: Dictionary,
    stamp: FileStamp,
}
#[derive(Clone, Copy, PartialEq, Eq)]
struct FileStamp {
    length: u64,
    modified: std::time::SystemTime,
    #[cfg(unix)]
    identity: (u64, u64),
}
impl FileStamp {
    fn read(file: &File) -> Result<Self> {
        let metadata = file.metadata()?;
        Ok(Self {
            length: metadata.len(),
            modified: metadata.modified()?,
            #[cfg(unix)]
            identity: {
                use std::os::unix::fs::MetadataExt;
                (metadata.dev(), metadata.ino())
            },
        })
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum StatsMode {
    Approximate356,
    Exact,
}
impl BwReader {
    pub fn open(path: &Path) -> Result<Self> {
        let mut file =
            File::open(path).rs_with_context(|| format!("opening {}", path.display()))?;
        preflight::validate(&mut file).rs_with_context(|| {
            format!("{}: bigWig structural/resource preflight", path.display())
        })?;
        let stamp = FileStamp::read(&file)?;
        use std::io::{Seek, SeekFrom};
        file.seek(SeekFrom::Start(0))?;
        let inner = catch_unwind(AssertUnwindSafe(|| {
            BigWigRead::open(ReopenableFile {
                path: path.into(),
                file,
            })
        }))
        .map_err(|_| {
            invalid(format!(
                "{}: bigWig header decoder panicked",
                path.display()
            ))
        })?
        .map_err(|e| invalid(format!("{}: {e}", path.display())))?;
        let dictionary = inner
            .chroms()
            .iter()
            .map(|c| Chromosome {
                name: c.name.clone(),
                len: c.length,
            })
            .collect();
        Ok(Self {
            path: path.into(),
            inner,
            dictionary,
            stamp,
        })
    }
    pub fn reopen(&self) -> Result<Self> {
        let file = File::open(&self.path)?;
        if FileStamp::read(&file)? != self.stamp {
            return Err(invalid(format!(
                "{}: bigWig input changed after validation",
                self.path.display()
            )));
        }
        Ok(Self {
            path: self.path.clone(),
            dictionary: self.dictionary.clone(),
            stamp: self.stamp,
            inner: BigWigRead::with_info(
                self.inner.info().clone(),
                ReopenableFile {
                    path: self.path.clone(),
                    file,
                },
            ),
        })
    }
    pub fn full_runs(&mut self, chrom: &str, start: u32, end: u32) -> Result<Vec<Value>> {
        if start >= end {
            return Ok(Vec::new());
        }
        let path = self.path.clone();
        catch_unwind(AssertUnwindSafe(|| -> Result<Vec<Value>> {
            let iter = self
                .inner
                .get_interval(chrom, start, end)
                .map_err(|e| invalid(e.to_string()))?;
            let mut values = Vec::new();
            let limit = 64 * 1024 * 1024 / std::mem::size_of::<Value>();
            for value in iter {
                if values.len() == limit {
                    return Err(invalid("bigWig query exceeds the private 64 MiB run budget; reduce the query/bin width"));
                }
                if values.len() == values.capacity() {
                    let capacity = values.capacity().max(1024).saturating_mul(2).min(limit);
                    values.try_reserve_exact(capacity - values.len()).map_err(|e| invalid(format!("allocating bounded bigWig query: {e}")))?;
                }
                values.push(value.map_err(|e| invalid(e.to_string()))?);
            }
            if values.iter().any(|v| v.start >= v.end) {
                return Err(invalid("invalid bigWig interval"));
            }
            Ok(values)
        }))
        .map_err(|_| {
            invalid(format!(
                "{}:{chrom}:{start}-{end}: bigWig decoder panicked",
                path.display()
            ))
        })?
        .rs_with_context(|| format!("{}:{chrom}:{start}-{end}", path.display()))
    }
    pub fn bin_means(
        &mut self,
        chrom: &str,
        windows: &[(u32, u32)],
        missing_zero: bool,
    ) -> Result<Vec<f64>> {
        if windows.is_empty() {
            return Ok(Vec::new());
        }
        let runs = self.full_runs(chrom, windows[0].0, windows[windows.len() - 1].1)?;
        let mut cursor = 0;
        let mut result = Vec::with_capacity(windows.len());
        for &(start, end) in windows {
            while cursor < runs.len() && runs[cursor].end <= start {
                cursor += 1;
            }
            let mut covered = 0u64;
            let mut sum = 0.0;
            let mut poisoned = false;
            for r in runs[cursor..].iter().take_while(|r| r.start < end) {
                let n = r.end.min(end).saturating_sub(r.start.max(start)) as u64;
                if n > 0 {
                    if r.value.is_nan() {
                        if !missing_zero {
                            poisoned = true;
                        }
                    } else {
                        covered += n;
                        sum += f64::from(r.value) * n as f64;
                    }
                }
            }
            let width = u64::from(end - start);
            result.push(if poisoned || (!missing_zero && covered < width) {
                f64::NAN
            } else {
                sum / width as f64
            });
        }
        Ok(result)
    }
    pub fn selected_zoom(&self, width: u32) -> Option<u32> {
        self.inner
            .info()
            .zoom_headers
            .iter()
            .map(|z| z.reduction_level)
            .filter(|r| *r <= width / 2)
            .max()
    }
    pub fn mean(&mut self, chrom: &str, start: u32, end: u32, mode: StatsMode) -> Result<f64> {
        if mode == StatsMode::Approximate356
            && let Some(reduction) = self.selected_zoom(end - start)
        {
            let path = self.path.clone();
            return catch_unwind(AssertUnwindSafe(|| -> Result<f64> {
                let records = self
                    .inner
                    .get_zoom_interval(chrom, start, end, reduction)
                    .map_err(|e| invalid(e.to_string()))?;
                let mut sum = 0.0f64;
                let mut coverage = 0.0f64;
                for record in records {
                    let r = record.map_err(|e| invalid(e.to_string()))?;
                    let overlap = r.end.min(end).saturating_sub(r.start.max(start));
                    let scalar = f64::from(overlap) / f64::from(r.end - r.start);
                    sum = r.summary.sum.mul_add(scalar, sum);
                    coverage = (r.summary.bases_covered as f64).mul_add(scalar, coverage);
                }
                Ok(if coverage == 0.0 {
                    f64::NAN
                } else {
                    sum / coverage
                })
            }))
            .map_err(|_| invalid(format!("{}: bigWig zoom decoder panicked", path.display())))?;
        }
        let runs = self.full_runs(chrom, start, end)?;
        let mut sum = 0.0;
        let mut covered = 0u64;
        for r in runs {
            let n = r.end.min(end).saturating_sub(r.start.max(start));
            sum += f64::from(r.value) * f64::from(n);
            covered += u64::from(n);
        }
        Ok(if covered == 0 {
            f64::NAN
        } else {
            sum / covered as f64
        })
    }
}

pub(crate) fn write_bedgraph(
    path: &Path,
    bedgraph: &Path,
    dictionary: &Dictionary,
    context: &RunContext,
) -> Result<Vec<u32>> {
    if dictionary.len() > usize::from(u16::MAX) {
        return Err(invalid(
            "bigWig dictionary exceeds the codec's65535-reference limit",
        ));
    }
    let mut count = 0u64;
    let mut total = 0u64;
    use std::io::{BufRead, BufReader};
    for line in BufReader::new(File::open(bedgraph)?).lines() {
        let line = line?;
        let f: Vec<_> = line.split('\t').collect();
        if f.len() != 4 {
            return Err(invalid("invalid staged bedGraph"));
        }
        let s = f[1].parse::<u32>()?;
        let e = f[2].parse::<u32>()?;
        total += u64::from(
            e.checked_sub(s)
                .ok_or_else(|| invalid("reversed staged bedGraph"))?,
        );
        count += 1;
    }
    if count == 0 {
        empty::write(path, dictionary)?;
        let mut reader = BwReader::open(path)?;
        if reader.dictionary != *dictionary {
            return Err(invalid("empty bigWig dictionary round-trip mismatch"));
        }
        for chrom in dictionary {
            if !reader.full_runs(&chrom.name, 0, chrom.len)?.is_empty() {
                return Err(invalid("empty bigWig contains intervals"));
            }
        }
        return Ok(Vec::new());
    }
    let mean = (total / count).max(1);
    let first = u32::try_from(
        mean.checked_mul(16)
            .ok_or_else(|| invalid("zoom reduction overflow"))?,
    )
    .map_err(|_| invalid("zoom reduction overflow"))?
    .max(10);
    let max_len = dictionary.iter().map(|c| c.len).max().unwrap_or(0);
    let levels: Vec<u32> = std::iter::successors(Some(first.min(max_len)), |r| r.checked_mul(4))
        .take(10)
        .take_while(|r| *r <= max_len)
        .collect();
    let file = File::create(path)?;
    let mut writer = BigWigWrite::new(
        file,
        dictionary.iter().map(|c| (c.name.clone(), c.len)).collect(),
    );
    writer.options.manual_zoom_sizes = Some(Vec::new());
    writer.options.inmemory = false;
    writer.options.channel_size = context.max_inflight.max(1);
    let runtime = tokio::runtime::Builder::new_multi_thread()
        .worker_threads(context.threads.get())
        .build()?;
    let input = source::SignalSource::open(bedgraph, dictionary)?;
    catch_unwind(AssertUnwindSafe(|| writer.write(input, runtime)))
        .map_err(|_| invalid("bigWig writer panicked; output not published"))?
        .map_err(|e| invalid(format!("writing {}: {e}", path.display())))?;
    let reopened = BwReader::open(path)?;
    let ids = dictionary
        .iter()
        .enumerate()
        .map(|(id, c)| (c.name.clone(), id as u32))
        .collect();
    if reopened.dictionary.len() != dictionary.len() {
        return Err(invalid("bigWig writer omitted dictionary entries"));
    }
    zoom::install(path, bedgraph, dictionary, &levels, &ids, context)
}
