use crate::{
    cli::{BamArgs, TrackArgs},
    grid,
    mask::MaskIndex,
    model::*,
};
use noodles::csi::binning_index::ReferenceSequence as _;
use noodles::{
    core::{Position, Region as QueryRegion},
    sam,
};
use rsomics_bamio::raw::{self, RawRecord, RawRecordEncoder};
use rsomics_common::Result;
use std::{collections::HashSet, num::NonZeroUsize, path::Path};

pub(crate) mod geometry;
pub(crate) mod shift;

pub(crate) fn dictionary(path: &Path, threads: NonZeroUsize) -> Result<(Dictionary, u64)> {
    let mut indexed = rsomics_bamio::open_indexed_alignment(path, None)?;
    indexed.read_header()?;
    let mut reader = rsomics_bamio::open_with_workers(path, threads)?;
    let header = reader.read_header()?;
    let dictionary = header_dictionary(&header)?;
    if let Some(counts) = index_mapped_counts(path, dictionary.len())? {
        let mapped = counts.into_iter().try_fold(0u64, |total, n| {
            total
                .checked_add(n)
                .ok_or_else(|| invalid("mapped index count overflow"))
        })?;
        return Ok((dictionary, mapped));
    }
    let mut mapped = 0u64;
    let mut record = RawRecord::default();
    while raw::read_record(reader.get_mut(), &mut record)? != 0 {
        if record.flags() & 4 == 0 {
            validate_reference(&record, &dictionary)?;
            mapped = mapped
                .checked_add(1)
                .ok_or_else(|| invalid("mapped read count overflow"))?;
        }
    }
    Ok((dictionary, mapped))
}

pub(crate) fn index_mapped_counts(path: &Path, references: usize) -> Result<Option<Vec<u64>>> {
    let appended = std::path::PathBuf::from(format!("{}.bai", path.display()));
    let alternative = path.with_extension("bai");
    let selected = if appended.try_exists()? {
        Some(appended)
    } else if alternative.try_exists()? {
        Some(alternative)
    } else {
        None
    };
    let Some(selected) = selected else {
        return Ok(None);
    };
    let index = noodles::bam::bai::fs::read(selected)?;
    if index.reference_sequences().len() != references {
        return Err(invalid("BAM index and header reference counts differ"));
    }
    let mut counts = Vec::with_capacity(references);
    for reference in index.reference_sequences() {
        let Some(metadata) = reference.metadata() else {
            return Ok(None);
        };
        counts.push(metadata.mapped_record_count());
    }
    Ok(Some(counts))
}

pub(crate) fn header_dictionary(header: &sam::Header) -> Result<Dictionary> {
    let mut names = HashSet::new();
    header
        .reference_sequences()
        .iter()
        .map(|(name, seq)| {
            let name = String::from_utf8(name.to_vec())
                .map_err(|_| invalid("BAM chromosome name is not UTF-8"))?;
            if !names.insert(name.clone()) {
                return Err(invalid("duplicate BAM chromosome name"));
            }
            let len = u32::try_from(usize::from(seq.length()))
                .map_err(|_| invalid("BAM chromosome length exceeds u32"))?;
            if len == 0 {
                return Err(invalid("BAM chromosome length is zero"));
            }
            Ok(Chromosome { name, len })
        })
        .collect()
}

pub(crate) fn validate_reference(record: &RawRecord, dictionary: &Dictionary) -> Result<()> {
    let tid = usize::try_from(record.reference_sequence_id())
        .map_err(|_| invalid("mapped BAM record has negative reference ID"))?;
    let chrom = dictionary
        .get(tid)
        .ok_or_else(|| invalid("BAM record reference ID exceeds dictionary"))?;
    let pos = u32::try_from(record.alignment_start())
        .map_err(|_| invalid("mapped BAM record has negative alignment start"))?;
    if pos >= chrom.len {
        return Err(invalid(
            "mapped BAM alignment starts outside its chromosome",
        ));
    }
    Ok(())
}

pub(crate) struct QueryReader {
    reader: rsomics_bamio::IndexedAlignmentReader,
    pub header: sam::Header,
    encoder: RawRecordEncoder,
}
impl QueryReader {
    pub fn open(path: &Path) -> Result<Self> {
        let mut reader = rsomics_bamio::open_indexed_alignment(path, None)?;
        let header = reader.read_header()?;
        Ok(Self {
            reader,
            header,
            encoder: RawRecordEncoder::new(),
        })
    }
    pub fn visit(
        &mut self,
        chrom: &str,
        start: u32,
        end: u32,
        mut visit: impl FnMut(&RawRecord) -> Result<()>,
    ) -> Result<()> {
        if start >= end {
            return Ok(());
        }
        let start = Position::try_from(
            usize::try_from(start)
                .map_err(|_| invalid("query start overflow"))?
                .checked_add(1)
                .ok_or_else(|| invalid("query start overflow"))?,
        )
        .map_err(|_| invalid("invalid query start"))?;
        let end =
            Position::try_from(usize::try_from(end).map_err(|_| invalid("query end overflow"))?)
                .map_err(|_| invalid("invalid query end"))?;
        let query = QueryRegion::new(chrom.as_bytes(), start..=end);
        for result in self.reader.query(&self.header, &query)? {
            let record = result?;
            let raw = self.encoder.encode(&self.header, record.as_ref())?;
            visit(&raw)?;
        }
        Ok(())
    }
}

#[derive(Default)]
pub(crate) struct FilterState {
    start: Option<i32>,
    keys: HashSet<(i64, i64, i32, bool)>,
}

pub(crate) fn template_length(record: &RawRecord, signed: bool) -> Result<i64> {
    let tlen = i64::from(record.template_length());
    if tlen != 0 {
        return Ok(if signed { tlen } else { tlen.abs() });
    }
    record
        .decoded_cigar()?
        .iter()
        .filter(|(op, _)| matches!(op, 0 | 2 | 7 | 8))
        .try_fold(0i64, |n, (_, len)| {
            n.checked_add(i64::from(*len))
                .ok_or_else(|| invalid("fragment length overflow"))
        })
}

pub(crate) fn rna_accepts(
    record: &RawRecord,
    strand: Option<StrandFilter>,
    normalization: bool,
) -> bool {
    let flag = record.flags();
    match strand {
        None => true,
        Some(StrandFilter::Forward) if flag & 1 != 0 && normalization => {
            (flag & 128 == 128 && flag & 16 == 0) || (flag & 64 == 64 && flag & 32 == 0)
        }
        Some(StrandFilter::Forward) if flag & 1 != 0 => flag & 144 == 128 || flag & 96 == 64,
        Some(StrandFilter::Reverse) if flag & 1 != 0 => flag & 144 == 144 || flag & 96 == 96,
        Some(StrandFilter::Forward) => flag & 16 != 0,
        Some(StrandFilter::Reverse) => flag & 16 == 0,
    }
}

pub(crate) fn accept(
    record: &RawRecord,
    policy: &BamArgs,
    state: &mut FilterState,
    strand: Option<StrandFilter>,
    normalization: bool,
) -> Result<bool> {
    let flags = record.flags();
    if flags & 4 != 0
        || record.mapping_quality() < policy.min_mapq
        || flags & policy.include_flags != policy.include_flags
        || flags & policy.exclude_flags != 0
    {
        return Ok(false);
    }
    let length = template_length(record, false)?;
    if length < i64::from(policy.min_fragment_length)
        || (policy.max_fragment_length != 0 && length > i64::from(policy.max_fragment_length))
    {
        return Ok(false);
    }
    if policy.ignore_duplicates {
        // getTLen is absolute in this source path, including reverse mates.
        let start = i64::from(record.alignment_start());
        let end = if record.reference_sequence_id() != record.mate_reference_sequence_id() {
            i64::from(record.mate_alignment_start())
        } else {
            start
                .checked_add(length)
                .ok_or_else(|| invalid("duplicate fragment coordinate overflow"))?
        };
        let key = (
            start,
            end,
            record.mate_reference_sequence_id(),
            flags & 16 != 0,
        );
        if state.start == Some(record.alignment_start()) && state.keys.contains(&key) {
            return Ok(false);
        }
        if state.start != Some(record.alignment_start()) {
            state.keys.clear();
        }
        state.start = Some(record.alignment_start());
        state.keys.insert(key);
    }
    Ok(rna_accepts(record, strand, normalization))
}

pub(crate) fn query_bounds(
    chrom: &str,
    start: u32,
    end: u32,
    extension: u32,
    len: u32,
    mask: &MaskIndex,
) -> (u32, u32) {
    let mut left = start.saturating_sub(extension);
    let mut right = end.saturating_add(extension).min(len);
    if extension > 0
        && let Some(spans) = mask.lookup(chrom)
    {
        for &(s, e) in spans {
            if s < start && left < e {
                left = left.max(e);
            }
            if s < right && end < e {
                right = right.min(s);
            }
        }
    }
    (left, right)
}

pub(crate) struct CountProfile {
    policy: BamArgs,
    geometry: geometry::Geometry,
}
impl CountProfile {
    pub(crate) fn resolve(
        path: &Path,
        bam: &BamArgs,
        track: Option<&TrackArgs>,
        mask: &MaskIndex,
        context: &RunContext,
    ) -> Result<Self> {
        let mut policy = bam.clone();
        if track.is_some_and(|t| t.mnase) {
            if policy.min_fragment_length == 0 {
                policy.min_fragment_length = 130;
            }
            if policy.max_fragment_length == 0 {
                policy.max_fragment_length = 200;
            }
        }
        let geometry = geometry::Geometry::resolve(path, &policy, track, mask, context)?;
        Ok(Self { policy, geometry })
    }
}
pub(crate) fn count_task(
    path: &Path,
    source_chrom: &str,
    task: &Task,
    bin_size: u32,
    profile: &CountProfile,
    mask: &MaskIndex,
) -> Result<BinValues> {
    let windows = grid::windows(task, bin_size, 0)?;
    let mut difference = vec![
        0i64;
        windows
            .len()
            .checked_add(1)
            .ok_or_else(|| invalid("bin count allocation overflow"))?
    ];
    let mut reader = QueryReader::open(path)?;
    let dict = header_dictionary(&reader.header)?;
    let chrom = dict
        .iter()
        .find(|c| c.name == source_chrom)
        .ok_or_else(|| invalid(format!("BAM chromosome not found: {source_chrom}")))?;
    let geometry = &profile.geometry;
    let (left, right) = query_bounds(
        source_chrom,
        task.span.start,
        task.span.end,
        geometry.fetch_extension(),
        chrom.len,
        mask,
    );
    let mut state = FilterState::default();
    let mut blocks = Vec::new();
    let mut scratch = Vec::new();
    reader.visit(source_chrom, left, right, |record| {
        if !accept(record, &profile.policy, &mut state, None, false)? {
            return Ok(());
        }
        geometry.blocks(record, chrom.len, &mut scratch, &mut blocks)?;
        let mut last_end = 0usize;
        for block in &blocks {
            let start = block.start.max(task.span.start);
            let end = block.end.min(task.span.end);
            if start >= end {
                continue;
            }
            let first = usize::try_from((start - task.grid_origin) / bin_size)
                .map_err(|_| invalid("bin index overflow"))?
                .max(last_end);
            let stop = usize::try_from((end - task.grid_origin).div_ceil(bin_size))
                .map_err(|_| invalid("bin index overflow"))?
                .min(windows.len());
            if first >= stop {
                continue;
            }
            difference[first] = difference[first]
                .checked_add(1)
                .ok_or_else(|| invalid("bin count overflow"))?;
            difference[stop] = difference[stop]
                .checked_sub(1)
                .ok_or_else(|| invalid("bin count overflow"))?;
            last_end = stop;
        }
        Ok(())
    })?;
    let mut current = 0i64;
    let values = difference[..windows.len()]
        .iter()
        .map(|&delta| {
            current = current
                .checked_add(delta)
                .ok_or_else(|| invalid("bin count overflow"))?;
            if current < 0 {
                return Err(invalid("negative alignment bin count"));
            }
            Ok(current as f64)
        })
        .collect::<Result<Vec<_>>>()?;
    Ok(BinValues {
        task: task.clone(),
        windows,
        values,
    })
}

pub(crate) fn region_counts(
    path: &Path,
    regions: &[Region],
    profile: &CountProfile,
    mask: &MaskIndex,
) -> Result<Vec<f64>> {
    let mut reader = QueryReader::open(path)?;
    let dict = header_dictionary(&reader.header)?;
    let geometry = &profile.geometry;
    let mut blocks = Vec::new();
    let mut scratch = Vec::new();
    let mut values = Vec::with_capacity(regions.len());
    for region in regions {
        let source = grid::annotation_chrom(&dict, &region.chrom)
            .ok_or_else(|| invalid(format!("BAM chromosome not found: {}", region.chrom)))?;
        let mut count = 0u64;
        for exon in &region.exons {
            if mask.overlaps(&source.name, exon.start, exon.end) {
                continue;
            }
            let (left, right) = query_bounds(
                &source.name,
                exon.start,
                exon.end,
                geometry.fetch_extension(),
                source.len,
                mask,
            );
            let mut state = FilterState::default();
            reader.visit(&source.name, left, right, |record| {
                if !accept(record, &profile.policy, &mut state, None, false)? {
                    return Ok(());
                }
                geometry.blocks(record, source.len, &mut scratch, &mut blocks)?;
                if blocks
                    .iter()
                    .any(|b| b.start < exon.end && exon.start < b.end)
                {
                    count = count
                        .checked_add(1)
                        .ok_or_else(|| invalid("region count overflow"))?;
                }
                Ok(())
            })?;
        }
        values.push(count as f64);
    }
    Ok(values)
}
