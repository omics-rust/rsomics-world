use super::template_length;
use crate::model::invalid;
use noodles::{
    core::Position,
    sam::{
        self,
        alignment::{
            RecordBuf,
            record::{
                Flags, MappingQuality,
                cigar::{Op, op::Kind},
            },
            record_buf::Cigar,
        },
    },
};
use rsomics_bamio::raw::{RawRecord, RawRecordEncoder};
use rsomics_common::Result;

pub(crate) fn shifts(explicit: &[i32], atac: bool) -> Result<Option<[i64; 4]>> {
    Ok(match explicit {
        [] if atac => Some([4, -5, 5, -4]),
        [] => None,
        [a, b] => Some([i64::from(*a), i64::from(*b), -i64::from(*b), -i64::from(*a)]),
        [a, b, c, d] => Some([i64::from(*a), i64::from(*b), i64::from(*c), i64::from(*d)]),
        _ => return Err(invalid("shift requires exactly two or four values")),
    })
}

pub(crate) fn apply(
    record: &RawRecord,
    chrom_len: u32,
    shift: [i64; 4],
    header: &sam::Header,
    encoder: &mut RawRecordEncoder,
) -> Result<Option<RawRecord>> {
    let flags = record.flags();
    if flags & 2 == 0 {
        return Ok(None);
    }
    let cigar = record.decoded_cigar()?;
    let trailing = cigar
        .iter()
        .rev()
        .find(|(op, _)| *op != 5)
        .filter(|(op, _)| *op == 4)
        .map_or(0, |(_, n)| i64::from(*n));
    let query_end = i64::try_from(record.sequence_len())
        .map_err(|_| invalid("query length exceeds i64"))?
        - trailing;
    let mut start = i64::from(record.alignment_start());
    let mut end = start + query_end;
    let reverse = flags & 16 != 0;
    let read2 = flags & 128 != 0;
    let delta = if reverse && !read2 {
        end -= shift[2];
        shift[3] - shift[2]
    } else if reverse {
        end += shift[1];
        shift[1] - shift[0]
    } else if !read2 {
        start += shift[0];
        shift[1] - shift[0]
    } else {
        start -= shift[3];
        shift[3] - shift[2]
    };
    if end - start < 1 {
        if reverse {
            start = end - 1;
        } else {
            end = start + 1;
        }
    }
    start = start.max(0);
    end = end.min(i64::from(chrom_len));
    if end - start < 1 {
        return Ok(None);
    }
    let tlen = template_length(record, true)?;
    let tlen = i32::try_from(if tlen < 0 { tlen - delta } else { tlen + delta })
        .map_err(|_| invalid("shifted BAM TLEN exceeds i32"))?;
    let mut mate = i64::from(record.mate_alignment_start());
    if reverse {
        if read2 {
            mate += shift[0];
        } else {
            mate -= shift[3];
        }
    }
    if mate < -1 || mate > i64::from(i32::MAX) {
        return Err(invalid(
            "shifted mate position is outside the BAM coordinate range",
        ));
    }
    let tid = usize::try_from(record.reference_sequence_id())
        .map_err(|_| invalid("shifted record has invalid reference ID"))?;
    let start = Position::try_from(
        usize::try_from(start + 1).map_err(|_| invalid("shifted alignment position overflow"))?,
    )
    .map_err(|_| invalid("shifted alignment position is invalid"))?;
    let length = usize::try_from(
        end - i64::try_from(usize::from(start))
            .map_err(|_| invalid("shift coordinate overflow"))?
            + 1,
    )
    .map_err(|_| invalid("shifted CIGAR length overflow"))?;
    let mut builder = RecordBuf::builder()
        .set_name(record.name().to_vec())
        .set_flags(Flags::from(flags))
        .set_reference_sequence_id(tid)
        .set_alignment_start(start)
        .set_cigar(
            [Op::new(Kind::Match, length)]
                .into_iter()
                .collect::<Cigar>(),
        )
        .set_template_length(tlen);
    if let Some(mapq) = MappingQuality::new(record.mapping_quality()) {
        builder = builder.set_mapping_quality(mapq);
    }
    if record.mate_reference_sequence_id() >= 0 {
        builder = builder.set_mate_reference_sequence_id(
            usize::try_from(record.mate_reference_sequence_id())
                .map_err(|_| invalid("mate reference ID overflow"))?,
        );
    }
    if mate >= 0 {
        builder = builder.set_mate_alignment_start(
            Position::try_from(
                usize::try_from(mate + 1).map_err(|_| invalid("mate position overflow"))?,
            )
            .map_err(|_| invalid("invalid shifted mate position"))?,
        );
    }
    encoder.encode(header, &builder.build()).map(Some)
}
