use super::{QueryReader, header_dictionary, rna_accepts};
use crate::{
    cli::{BamArgs, TrackArgs},
    mask::MaskIndex,
    model::*,
};
use rsomics_bamio::raw::RawRecord;
use rsomics_common::Result;
use std::{ops::Range, path::Path};

pub(crate) struct Geometry {
    extension: Option<u32>,
    max_pair: u32,
    center: bool,
    offset: Vec<i32>,
    strand: Option<StrandFilter>,
    mnase: bool,
}

pub(crate) fn inferred_query_length(record: &RawRecord) -> Result<u32> {
    record
        .decoded_cigar()?
        .iter()
        .filter(|(op, _)| matches!(op, 0 | 1 | 4 | 7 | 8))
        .try_fold(0u32, |n, (_, len)| {
            n.checked_add(*len)
                .ok_or_else(|| invalid("BAM query length overflow"))
        })
}
pub(crate) fn reference_end(record: &RawRecord) -> Result<i64> {
    record
        .decoded_cigar()?
        .iter()
        .filter(|(op, _)| matches!(op, 0 | 2 | 3 | 7 | 8))
        .try_fold(i64::from(record.alignment_start()), |n, (_, len)| {
            n.checked_add(i64::from(*len))
                .ok_or_else(|| invalid("BAM reference coordinate overflow"))
        })
}
pub(crate) fn proper_pair(record: &RawRecord, max_pair: u32) -> bool {
    let flags = record.flags();
    flags & 2 != 0
        && record.reference_sequence_id() == record.mate_reference_sequence_id()
        && i64::from(record.template_length()).abs() <= i64::from(max_pair)
        && (flags & 16 != 0) != (flags & 32 != 0)
        && if flags & 16 != 0 {
            record.alignment_start() >= record.mate_alignment_start()
        } else {
            record.alignment_start() <= record.mate_alignment_start()
        }
}
pub(crate) fn aligned_blocks(record: &RawRecord, blocks: &mut Vec<Range<i64>>) -> Result<()> {
    blocks.clear();
    let mut pos = i64::from(record.alignment_start());
    for (op, len) in record.decoded_cigar()? {
        match op {
            0 | 7 | 8 => {
                let end = pos
                    .checked_add(i64::from(len))
                    .ok_or_else(|| invalid("CIGAR coordinate overflow"))?;
                blocks.push(pos..end);
                pos = end;
            }
            2 | 3 => {
                pos = pos
                    .checked_add(i64::from(len))
                    .ok_or_else(|| invalid("CIGAR coordinate overflow"))?
            }
            1 | 4 | 5 | 6 => {}
            _ => return Err(invalid("unknown BAM CIGAR operation")),
        }
    }
    Ok(())
}
pub(crate) fn median(values: &mut [f64]) -> Result<f64> {
    if values.is_empty() {
        return Err(invalid(
            "cannot estimate length from an empty alignment population",
        ));
    }
    values.sort_by(f64::total_cmp);
    let middle = values.len() / 2;
    Ok(if values.len().is_multiple_of(2) {
        (values[middle - 1] + values[middle]) / 2.0
    } else {
        values[middle]
    })
}
pub(crate) fn sampled_lengths(path: &Path, mask: &MaskIndex) -> Result<(Option<f64>, f64, usize)> {
    let mut reader = QueryReader::open(path)?;
    let dict = header_dictionary(&reader.header)?;
    let mut distance = 2_000_000.0f64;
    let mut sampled = Vec::new();
    while sampled.len() < 1000 && distance > 1.0 {
        distance /= 2.0;
        sampled.clear();
        let chunk = (50_000.0 + distance) as u32;
        for chrom in &dict {
            let mut cursor = 0u32;
            while cursor < chrom.len {
                let stop = cursor.saturating_add(chunk).min(chrom.len);
                for (start, end) in mask.subtract(&chrom.name, cursor, stop) {
                    let sampled_end =
                        ((f64::from(end) - distance).max(f64::from(start) + 1.0)) as u32;
                    let mut paired = Vec::new();
                    let mut fallback = Vec::new();
                    reader.visit(&chrom.name, start, sampled_end.min(chrom.len), |record| {
                        if record.flags() & 4 == 0 {
                            let value = (
                                i64::from(record.template_length()).abs() as f64,
                                f64::from(inferred_query_length(record)?),
                            );
                            fallback.push(value);
                            if record.flags() & 2 != 0 && record.flags() & 64 != 0 {
                                paired.push(value);
                            }
                        }
                        Ok(())
                    })?;
                    sampled.extend(if paired.is_empty() { fallback } else { paired });
                }
                cursor = stop;
            }
        }
    }
    let mut fragments: Vec<_> = sampled.iter().map(|v| v.0).collect();
    let fragment = if fragments.iter().sum::<f64>() > 0.0 {
        Some(median(&mut fragments)?)
    } else {
        None
    };
    let mut reads: Vec<_> = sampled.iter().map(|v| v.1).collect();
    Ok((fragment, median(&mut reads)?, sampled.len()))
}
impl Geometry {
    pub fn resolve(
        path: &Path,
        bam: &BamArgs,
        track: Option<&TrackArgs>,
        mask: &MaskIndex,
        _context: &RunContext,
    ) -> Result<Self> {
        let mnase = track.is_some_and(|t| t.mnase);
        let lengths = if bam.extend_reads.is_some() || mnase {
            Some(sampled_lengths(path, mask)?)
        } else {
            None
        };
        let mut extension = bam.extend_reads;
        if let Some(request) = extension {
            let (fragment, read, _) =
                lengths.ok_or_else(|| invalid("missing operation length sample"))?;
            extension = if request == 0 {
                Some(fragment.ok_or_else(|| {
                    invalid("read extension estimation requires a paired-end library")
                })? as u32)
            } else if f64::from(request) < read {
                None
            } else if request > 2000 {
                return Err(invalid("read extension must not exceed 2000"));
            } else {
                Some(request)
            };
        }
        if mnase && lengths.and_then(|l| l.0).is_none() {
            return Err(invalid("MNase requires a paired-end library"));
        }
        let strand = track.and_then(|t| t.rna_strand);
        let mut offset = track.map_or_else(Vec::new, |t| t.offset.clone());
        if strand.is_some() && offset.is_empty() {
            offset = vec![1, -1];
        }
        if offset.first() == Some(&0)
            || offset.len() > 2
            || offset.len() == 2 && offset[1] > 0 && offset[1] < offset[0]
        {
            return Err(invalid("invalid 1-based alignment offset"));
        }
        let max_pair = if bam.max_fragment_length != 0 {
            bam.max_fragment_length
        } else {
            extension.map_or(1000, |n| n.saturating_mul(4))
        };
        Ok(Self {
            extension,
            max_pair,
            center: bam.center_reads,
            offset,
            strand,
            mnase,
        })
    }
    pub fn fetch_extension(&self) -> u32 {
        if self.extension.is_some() {
            self.max_pair
        } else {
            0
        }
    }
    pub fn blocks(
        &self,
        record: &RawRecord,
        chrom_len: u32,
        scratch: &mut Vec<Range<i64>>,
        out: &mut Vec<Range<u32>>,
    ) -> Result<()> {
        out.clear();
        let result = self.raw_blocks(record, scratch);
        if result.is_ok() {
            for block in scratch {
                let start = block.start.max(0).min(i64::from(chrom_len)) as u32;
                let end = block.end.max(0).min(i64::from(chrom_len)) as u32;
                if start < end {
                    out.push(start..end);
                }
            }
        }
        result
    }
    fn raw_blocks(&self, record: &RawRecord, blocks: &mut Vec<Range<i64>>) -> Result<()> {
        aligned_blocks(record, blocks)?;
        if self.mnase {
            if record.flags() & 2 == 0
                || record.flags() & 16 != 0
                || i64::from(record.template_length()).abs() <= 1
            {
                blocks.clear();
                return Ok(());
            }
            let len = i64::from(record.template_length());
            let start = f64::from(record.alignment_start()) + len as f64 / 2.0 - 1.0;
            let end = start + if len % 2 == 0 { 2.0 } else { 3.0 };
            blocks.clear();
            blocks.push(start.floor() as i64..end.ceil() as i64);
        } else if !self.offset.is_empty() {
            if !rna_accepts(record, self.strand, false) {
                blocks.clear();
                return Ok(());
            }
            self.offset_blocks(record, blocks)?;
        } else if let Some(extension) = self.extension {
            let start = i64::from(record.alignment_start());
            let end = reference_end(record)?;
            let reverse = record.flags() & 16 != 0;
            let (mut left, mut right) = if proper_pair(record, self.max_pair) {
                if reverse {
                    (i64::from(record.mate_alignment_start()), end)
                } else {
                    (start, start + i64::from(record.template_length()).abs())
                }
            } else if reverse {
                (end - i64::from(extension), end)
            } else {
                (start, start + i64::from(extension))
            };
            if self.center {
                let query = i64::from(inferred_query_length(record)?);
                left = ((right + left) as f64 / 2.0 - query as f64 / 2.0) as i64;
                right = left + query;
            }
            if left >= right {
                return Err(invalid("extended alignment has empty or reversed geometry"));
            }
            blocks.clear();
            blocks.push(left..right);
        }
        Ok(())
    }
    fn offset_blocks(&self, record: &RawRecord, blocks: &mut Vec<Range<i64>>) -> Result<()> {
        let block_len: i64 = blocks.iter().map(|b| b.end - b.start).sum();
        let query = i64::from(inferred_query_length(record)?);
        let start = i64::from(record.alignment_start());
        let end = reference_end(record)?;
        let reverse = record.flags() & 16 != 0;
        if let Some(extension) = self.extension {
            let extra = if proper_pair(record, self.max_pair) {
                if reverse {
                    i64::from(record.mate_alignment_start())..start
                } else {
                    end..end + i64::from(record.template_length()).abs() - query
                }
            } else if reverse {
                (start - i64::from(extension) + query).max(0)..start
            } else {
                end..end + i64::from(extension) - query
            };
            if extra.start < extra.end {
                if reverse {
                    blocks.insert(0, extra);
                } else {
                    blocks.push(extra);
                }
            }
        }
        let total: i64 = blocks.iter().map(|b| b.end - b.start).sum();
        let center_start = if self.center {
            (total - block_len).div_euclid(2)
        } else {
            0
        };
        let slice_len = if self.center { block_len } else { total };
        let first = i64::from(self.offset[0]);
        let raw_start = if first > 0 { first - 1 } else { first };
        let raw_end = if self.offset.len() == 1 {
            if first == -1 {
                slice_len
            } else {
                raw_start + 1
            }
        } else {
            let v = i64::from(self.offset[1]);
            if v < 0 {
                if v == -1 { slice_len } else { v + 1 }
            } else {
                v
            }
        };
        let normalize = |v: i64| {
            if v < 0 {
                (slice_len + v).max(0)
            } else {
                v.min(slice_len)
            }
        };
        let left = normalize(raw_start);
        let right = normalize(raw_end);
        if left >= right {
            blocks.clear();
            return Ok(());
        }
        let mut wanted_start = center_start + left;
        let mut wanted_end = center_start + right;
        if reverse {
            let a = total - wanted_end;
            wanted_end = total - wanted_start;
            wanted_start = a;
        }
        let mut offset = 0;
        let mut selected = Vec::new();
        for block in blocks.iter() {
            let width = block.end - block.start;
            let a = wanted_start.max(offset);
            let b = wanted_end.min(offset + width);
            if a < b {
                selected.push(block.start + a - offset..block.start + b - offset);
            }
            offset += width;
        }
        *blocks = selected;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use rsomics_bamio::raw::RawRecordEncoder;
    fn raw(line: &str) -> RawRecord {
        let source = format!("@SQ\tSN:chr1\tLN:1000\n{line}\n");
        let mut reader = noodles::sam::io::Reader::new(source.as_bytes());
        let header = reader.read_header().unwrap();
        let record = reader.record_bufs(&header).next().unwrap().unwrap();
        RawRecordEncoder::new().encode(&header, &record).unwrap()
    }
    #[test]
    fn spliced_offsets_pair_centers_and_mnase() {
        let record = raw("r\t0\tchr1\t101\t60\t3S5M2I5M10D4=20N6X2S\t*\t0\t0\t*\t*");
        let mut blocks = Vec::new();
        aligned_blocks(&record, &mut blocks).unwrap();
        assert_eq!(blocks, [100..105, 105..110, 120..124, 144..150]);
        assert_eq!(inferred_query_length(&record).unwrap(), 27);
        let mut geometry = Geometry {
            extension: None,
            max_pair: 1000,
            center: false,
            offset: vec![8, 17],
            strand: None,
            mnase: false,
        };
        let mut scratch = Vec::new();
        let mut out = Vec::new();
        geometry
            .blocks(&record, 1000, &mut scratch, &mut out)
            .unwrap();
        assert_eq!(out, [107..110, 120..124, 144..147]);
        geometry.offset = vec![-3, -1];
        geometry
            .blocks(&record, 1000, &mut scratch, &mut out)
            .unwrap();
        assert_eq!(out, std::iter::once(147..150).collect::<Vec<_>>());
        let record = raw("r\t99\tchr1\t101\t60\t20M\t=\t180\t100\t*\t*");
        geometry.offset.clear();
        geometry.extension = Some(100);
        geometry.center = true;
        geometry
            .blocks(&record, 1000, &mut scratch, &mut out)
            .unwrap();
        assert_eq!(out, std::iter::once(140..160).collect::<Vec<_>>());
        geometry.mnase = true;
        geometry
            .blocks(&record, 1000, &mut scratch, &mut out)
            .unwrap();
        assert_eq!(out, std::iter::once(149..151).collect::<Vec<_>>());
        let record = raw("r\t99\tchr1\t101\t60\t20M\t=\t180\t101\t*\t*");
        geometry
            .blocks(&record, 1000, &mut scratch, &mut out)
            .unwrap();
        assert_eq!(out, std::iter::once(149..153).collect::<Vec<_>>());
    }
}
