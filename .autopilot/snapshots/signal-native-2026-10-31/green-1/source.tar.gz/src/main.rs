fn main() -> std::process::ExitCode {
    rsomics_signal::run_cli()
}
