use crate::{
    alignments::{
        self, FilterState, QueryReader,
        geometry::{inferred_query_length, median, sampled_lengths},
    },
    cli::{BamArgs, CompareArgs, NormalizeArgs, TrackArgs},
    grid::{self, DictionaryProfile},
    mask::MaskIndex,
    model::*,
};
use rsomics_bamio::raw::{self, RawRecord};
use rsomics_common::Result;
use serde_json::{Value, json};
use std::path::Path;

pub(crate) struct ScaleReport {
    pub factors: Vec<f64>,
    pub details: Value,
}

fn needs_sample(bam: &BamArgs, strand: Option<StrandFilter>) -> bool {
    bam.min_mapq > 0
        || bam.include_flags != 0
        || bam.exclude_flags != 0
        || bam.min_fragment_length > 0
        || bam.max_fragment_length > 0
        || strand.is_some()
}

fn population(
    path: &Path,
    bam: &BamArgs,
    normalization: &NormalizeArgs,
    strand: Option<StrandFilter>,
    mask: &MaskIndex,
    context: &RunContext,
) -> Result<(f64, Value)> {
    mask.validate_normalization()?;
    let mut reader = rsomics_bamio::open_with_workers(path, context.threads)?;
    let header = reader.read_header()?;
    let dictionary = alignments::header_dictionary(&header)?;
    let indexed_counts = if mask.spans.is_empty() {
        alignments::index_mapped_counts(path, dictionary.len())?
    } else {
        None
    };
    let mut total = 0u64;
    let mut blacklisted = 0u64;
    let mut record = RawRecord::default();
    if let Some(counts) = indexed_counts {
        for (chrom, n) in dictionary.iter().zip(counts) {
            if !normalization.ignore_for_normalization.contains(&chrom.name) {
                total = total
                    .checked_add(n)
                    .ok_or_else(|| invalid("normalization index count overflow"))?;
            }
        }
    } else {
        while raw::read_record(reader.get_mut(), &mut record)? != 0 {
            if record.flags() & 4 != 0 {
                continue;
            }
            alignments::validate_reference(&record, &dictionary)?;
            let chrom = &dictionary[record.reference_sequence_id() as usize];
            if normalization.ignore_for_normalization.contains(&chrom.name) {
                continue;
            }
            total = total
                .checked_add(1)
                .ok_or_else(|| invalid("normalization count overflow"))?;
            if let Some(spans) = mask.spans.get(&chrom.name) {
                let start = i64::from(record.alignment_start());
                let end = start + i64::from(inferred_query_length(&record)?) - 1;
                if spans.iter().any(|&(s, e)| {
                    start >= i64::from(s) && start < i64::from(e) && end <= i64::from(e)
                }) {
                    blacklisted = blacklisted
                        .checked_add(1)
                        .ok_or_else(|| invalid("blacklist count overflow"))?;
                }
            }
        }
    }
    let mut sampled = 0u64;
    let mut filtered = 0u64;
    let active = needs_sample(bam, strand);
    let desired = if normalization.exact_scaling || total < 1_000_000 {
        total
    } else {
        (total as f64 * 0.1).max(1_000_000.0) as u64
    };
    let chunk = if desired == total {
        55_000u32
    } else {
        2_000_000
    };
    if active {
        let mut query = QueryReader::open(path)?;
        for offset in 0..chunk.div_ceil(50_000) {
            if sampled >= desired {
                break;
            }
            for chrom in &dictionary {
                if normalization.ignore_for_normalization.contains(&chrom.name) {
                    continue;
                }
                let mut cursor = 0u32;
                while cursor < chrom.len {
                    let stop = cursor.saturating_add(chunk).min(chrom.len);
                    for (left, right) in mask.subtract(&chrom.name, cursor, stop) {
                        let start = left.saturating_add(offset * 50_000);
                        let end = right.min(start.saturating_add(50_000));
                        let mut state = FilterState::default();
                        query.visit(&chrom.name, start, end, |record| {
                            sampled = sampled
                                .checked_add(1)
                                .ok_or_else(|| invalid("normalization sample count overflow"))?;
                            if record.flags() & 4 == 0
                                && !alignments::accept(record, bam, &mut state, strand, true)?
                            {
                                filtered = filtered.checked_add(1).ok_or_else(|| {
                                    invalid("normalization filtered count overflow")
                                })?;
                            }
                            Ok(())
                        })?;
                    }
                    cursor = stop;
                }
            }
        }
    }
    let fraction = if !active || sampled == 0 {
        1.0
    } else {
        1.0 - filtered as f64 / sampled as f64
    };
    let kept = total
        .checked_sub(blacklisted)
        .ok_or_else(|| invalid("blacklist population exceeds mapped alignments"))?
        as f64
        * fraction;
    Ok((
        kept,
        json!({"mapped_total": total, "blacklisted": blacklisted, "sampled": sampled, "filtered": filtered, "fraction_kept": fraction, "kept": kept, "exact_requested": normalization.exact_scaling, "sampling_active":active, "sample_chunk_length":chunk, "ignore_for_normalization":normalization.ignore_for_normalization}),
    ))
}

fn normalized(
    path: &Path,
    bam: &BamArgs,
    normalization: &NormalizeArgs,
    strand: Option<StrandFilter>,
    scale_bin: (f64, u32),
    mask: &MaskIndex,
    context: &RunContext,
) -> Result<(f64, Value)> {
    let (scale, bin) = scale_bin;
    let (kept, mut details) = population(path, bam, normalization, strand, mask, context)?;
    if kept <= 0.0 {
        return Err(invalid("normalization has no kept mapped alignments"));
    }
    let factor = match normalization.normalize {
        Normalization::None => scale,
        Normalization::Cpm => scale / (kept / 1e6),
        Normalization::Bpm => {
            let tile = f64::from(bin) / 1000.0;
            scale / ((kept / tile / 1e6) * tile)
        }
        Normalization::Rpkm => scale / ((kept / 1e6) * (f64::from(bin) / 1000.0)),
        Normalization::Rpgc => {
            let genome = normalization
                .effective_genome_size
                .filter(|n| *n > 0)
                .ok_or_else(|| invalid("RPGC requires positive effective genome size"))?;
            let (fragment, read, samples) = sampled_lengths(path, mask)?;
            let length = match bam.extend_reads {
                Some(0) => fragment.ok_or_else(|| {
                    invalid("RPGC estimated extension requires paired-end alignments")
                })?,
                Some(n) if n <= 2000 => f64::from(n),
                Some(_) => return Err(invalid("RPGC extension exceeds 2000")),
                None => read.trunc(),
            };
            if length <= 0.0 {
                return Err(invalid("RPGC sampled read/fragment length is zero"));
            }
            details["fragment_length"] = json!(length);
            details["length_samples"] = json!(samples);
            scale / (kept * length / genome as f64)
        }
    };
    details["factor"] = json!(factor);
    details["normalization"] = json!(normalization.normalize);
    Ok((factor, details))
}

pub(crate) fn track_scale(
    args: &TrackArgs,
    mask: &MaskIndex,
    context: &RunContext,
) -> Result<ScaleReport> {
    if args.normalization.normalize == Normalization::None {
        return Ok(ScaleReport {
            factors: vec![args.scale],
            details: json!({"normalization":"none","factor":args.scale,"population_scanned":false}),
        });
    }
    let (factor, details) = normalized(
        &args.bam,
        &args.bam_options,
        &args.normalization,
        args.rna_strand,
        (args.scale, args.bin_size),
        mask,
        context,
    )?;
    Ok(ScaleReport {
        factors: vec![factor],
        details,
    })
}

pub(crate) fn compare_scales(
    args: &CompareArgs,
    mask: &MaskIndex,
    context: &RunContext,
) -> Result<ScaleReport> {
    if let Some(text) = &args.scale_factors {
        let factors = text
            .split(':')
            .map(str::parse::<f64>)
            .collect::<std::result::Result<Vec<_>, _>>()?;
        if factors.len() != 2 || factors.iter().any(|n| !n.is_finite()) {
            return Err(invalid("BAM compare requires two finite scale factors"));
        }
        return Ok(ScaleReport {
            factors,
            details: json!({"method":"manual"}),
        });
    }
    if args.normalization.normalize == Normalization::Rpgc {
        return Err(invalid("RPGC is not supported for compare"));
    }
    if args.normalization.normalize != Normalization::None && args.scale_method != ScaleMethod::None
    {
        return Err(invalid("normalization requires scale-method none"));
    }
    if args.scale_method == ScaleMethod::Ses {
        return ses(args, mask, context);
    }
    if args.scale_method == ScaleMethod::ReadCount {
        let mut populations = Vec::new();
        let mut details = Vec::new();
        for path in [&args.first, &args.second] {
            let (n, report) = population(
                path,
                &args.bam_options,
                &args.normalization,
                None,
                mask,
                context,
            )?;
            populations.push(n);
            details.push(report);
        }
        if populations.iter().any(|n| *n <= 0.0) {
            return Err(invalid(
                "readCount scaling requires mapped alignments in both files",
            ));
        }
        let min = populations[0].min(populations[1]);
        return Ok(ScaleReport {
            factors: populations.iter().map(|n| min / n).collect(),
            details: json!({"method":"readCount","populations":details}),
        });
    }
    if args.normalization.normalize == Normalization::None {
        return Ok(ScaleReport {
            factors: vec![1.0, 1.0],
            details: json!({"method":"none"}),
        });
    }
    let mut factors = Vec::new();
    let mut details = Vec::new();
    for path in [&args.first, &args.second] {
        let (factor, report) = normalized(
            path,
            &args.bam_options,
            &args.normalization,
            None,
            (1.0, args.bin_size),
            mask,
            context,
        )?;
        factors.push(factor);
        details.push(report);
    }
    Ok(ScaleReport {
        factors,
        details: json!({"method":"normalization", "populations":details}),
    })
}

fn ses(args: &CompareArgs, mask: &MaskIndex, context: &RunContext) -> Result<ScaleReport> {
    if args.number_of_samples == 0 || args.sample_length == 0 {
        return Err(invalid(
            "SES requires positive sample length and sample count",
        ));
    }
    let (first, first_count) = alignments::dictionary(&args.first, context.threads)?;
    let (second, second_count) = alignments::dictionary(&args.second, context.threads)?;
    let mut mapping = grid::reconcile(&[first, second], DictionaryProfile::BamCount)?;
    mapping.dictionary.retain(|chrom| {
        !args
            .normalization
            .ignore_for_normalization
            .contains(&chrom.name)
    });
    if mapping.dictionary.is_empty() {
        return Err(invalid("no chromosomes remain for SES normalization"));
    }
    let genome: u64 = mapping.dictionary.iter().map(|c| u64::from(c.len)).sum();
    let step = (genome
        / u64::try_from(args.number_of_samples)
            .map_err(|_| invalid("SES sample count overflow"))?)
    .max(1);
    if step as f64 > genome as f64 / mapping.dictionary.len() as f64 {
        return Err(invalid(
            "SES number-of-samples is too small for chromosome lengths",
        ));
    }
    let max_mapped = first_count.max(second_count);
    let chunk = if max_mapped == 0 {
        args.sample_length.saturating_mul(10000)
    } else {
        ((step as f64 * 1000.0 / (max_mapped as f64 / genome as f64 * 2.0)) as u32)
            .max(u32::try_from(step).map_err(|_| invalid("SES step exceeds u32"))?)
            .max(args.sample_length)
    };
    let tasks = grid::plan_tasks(&mapping.dictionary, chunk, None, mask, None)?;
    let mut regions = Vec::new();
    for task in tasks {
        let chrom = &mapping.dictionary[task.span.chrom];
        let mut start = task.span.start;
        while start < task.span.end {
            let mut end = start.saturating_add(args.sample_length);
            if end > task.span.end && step != u64::from(args.sample_length) {
                break;
            }
            end = end.min(task.span.end);
            if !mask.overlaps(&chrom.name, start, end) {
                regions.push(Region {
                    row_id: regions.len(),
                    chrom: chrom.name.clone(),
                    exons: std::iter::once(start..end).collect(),
                    name: String::new(),
                    strand: '.',
                    score: "0".into(),
                    group: 0,
                    source_order: regions.len(),
                });
            }
            start = match start
                .checked_add(u32::try_from(step).map_err(|_| invalid("SES step exceeds u32"))?)
            {
                Some(n) => n,
                None => break,
            };
        }
    }
    let unfiltered = BamArgs::default();
    let profile = alignments::CountProfile::resolve(&args.first, &unfiltered, None, mask, context)?;
    let mut counts = Vec::new();
    for path in [&args.first, &args.second] {
        counts.push(alignments::region_counts(path, &regions, &profile, mask)?);
    }
    let sites = regions.len();
    if sites == 0 {
        return Err(invalid("SES sampled no complete regions"));
    }
    let mut medians = Vec::new();
    let mut means = Vec::new();
    let mut stds = Vec::new();
    for column in &mut counts {
        let mean = column.iter().sum::<f64>() / sites as f64;
        means.push(mean);
        stds.push((column.iter().map(|v| (v - mean).powi(2)).sum::<f64>() / sites as f64).sqrt());
        medians.push(median(column)?);
    }
    if medians.contains(&0.0) {
        return Err(invalid(
            "SES median coverage is zero; select a larger sample or covered region",
        ));
    }
    let mut cumulative = counts.clone();
    for column in &mut cumulative {
        let mut total = 0.0;
        for value in column {
            total += *value;
            *value = total;
        }
    }
    let p_total = cumulative[0][sites - 1];
    let q_total = cumulative[1][sites - 1];
    if p_total == 0.0 || q_total == 0.0 {
        return Err(invalid("SES sampled empty coverage population"));
    }
    let mut max_index = 0usize;
    let mut max_diff = -1.0;
    for (i, (p, q)) in cumulative[0].iter().zip(&cumulative[1]).enumerate() {
        let diff = (p / p_total - q / q_total).abs();
        if diff > max_diff {
            max_diff = diff;
            max_index = i;
        }
    }
    max_index = (max_index as f64 * 0.8) as usize;
    while max_index < sites && (cumulative[0][max_index] == 0.0 || cumulative[1][max_index] == 0.0)
    {
        max_index += 1;
    }
    if max_index == sites {
        return Err(invalid("SES has no common positive cumulative population"));
    }
    let sums = [cumulative[0][max_index], cumulative[1][max_index]];
    let min = sums[0].min(sums[1]);
    let factors = vec![min / sums[0], min / sums[1]];
    let mean_ses: Vec<_> = counts
        .iter()
        .map(|v| {
            if max_index == 0 {
                Value::Null
            } else {
                json!(v[..max_index].iter().sum::<f64>() / max_index as f64)
            }
        })
        .collect();
    Ok(ScaleReport {
        factors,
        details: json!({"method":"SES","sites_sampled":sites,"sample_length":args.sample_length,"sample_step":step,"sample_chunk":chunk,"population":"unfiltered aligned blocks","mean":means,"median":medians,"std":stds,"meanSES":mean_ses,"max_index":max_index,"cumulative_counts":sums}),
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cli::{Cli, Command};
    use clap::Parser;
    use std::num::NonZeroUsize;
    #[test]
    fn source_populations_and_ses() {
        let context = RunContext::new(NonZeroUsize::new(2).unwrap()).unwrap();
        let root = crate::test_fixtures::fixture_root();
        let unused_normalization_output = context.scratch.join("unused-normalization-output");
        let raw = root.join("generated-inputs/a.raw.bam");
        let base = [
            "signal",
            "track",
            "--bam",
            raw.to_str().unwrap(),
            "--out",
            unused_normalization_output.to_str().unwrap(),
            "--normalize",
            "CPM",
            "--bin-size",
            "20",
        ];
        let Command::Track(mut args) = Cli::parse_from(base).into_command() else {
            unreachable!()
        };
        let mask = MaskIndex::default();
        let report = track_scale(&args, &mask, &context).unwrap();
        assert_eq!(report.details["kept"], 82.0);
        assert_eq!(report.factors, [12195.121951219511]);
        args.bam_options.ignore_duplicates = true;
        let report = track_scale(&args, &mask, &context).unwrap();
        assert_eq!(report.details["sampled"], 0);
        assert_eq!(report.details["kept"], 82.0);
        args.bam_options.ignore_duplicates = false;
        args.bam_options.min_mapq = 20;
        args.bam_options.exclude_flags = 2816;
        args.normalization.exact_scaling = true;
        let report = track_scale(&args, &mask, &context).unwrap();
        assert_eq!(report.details["kept"], 78.0);
        assert!((report.factors[0] - 12820.51282051282).abs() < 1e-10);
        args.bam_options = BamArgs::default();
        let mask = MaskIndex::load(&[root.join("inputs/authored/blacklist.bed")]).unwrap();
        let report = track_scale(&args, &mask, &context).unwrap();
        assert_eq!(report.details["blacklisted"], 2);
        assert_eq!(report.details["kept"], 80.0);
        args.normalization.normalize = Normalization::Rpgc;
        args.normalization.effective_genome_size = Some(2000);
        let report = track_scale(&args, &MaskIndex::default(), &context).unwrap();
        assert!((report.factors[0] - 0.4065040650406504).abs() < 1e-12);
        let a = root.join("generated-inputs/a.source.bam");
        let b = root.join("generated-inputs/b.source.bam");
        let unused_scale_output = context.scratch.join("unused-scale-output");
        let Command::Compare(mut args) = Cli::parse_from([
            "signal",
            "compare",
            "--input",
            "bam",
            "--first",
            a.to_str().unwrap(),
            "--second",
            b.to_str().unwrap(),
            "--out",
            unused_scale_output.to_str().unwrap(),
            "--sample-length",
            "50",
            "--number-of-samples",
            "24",
        ])
        .into_command() else {
            unreachable!()
        };
        let report = compare_scales(&args, &MaskIndex::default(), &context).unwrap();
        assert_eq!(report.factors, [1.0, 64.0 / 124.0]);
        args.scale_method = ScaleMethod::Ses;
        let report = compare_scales(&args, &MaskIndex::default(), &context).unwrap();
        assert_eq!(report.factors, [1.0, 0.5]);
        assert_eq!(report.details["sites_sampled"], 24);
        args.bam_options.min_mapq = 255;
        args.bam_options.exclude_flags = u16::MAX;
        assert_eq!(
            compare_scales(&args, &MaskIndex::default(), &context)
                .unwrap()
                .factors,
            [1.0, 0.5]
        );
    }
}
