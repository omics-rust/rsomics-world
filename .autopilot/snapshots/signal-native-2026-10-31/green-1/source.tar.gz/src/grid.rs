use crate::mask::MaskIndex;
use crate::model::{Dictionary, Span, Task, invalid};
use rsomics_common::Result;

#[derive(Clone, Copy)]
pub(crate) enum DictionaryProfile {
    BamCount,
    BwArithmetic,
    BwSummary,
}
pub(crate) struct DictionaryMapping {
    pub dictionary: Dictionary,
    pub names: Vec<Vec<String>>,
}
pub(crate) fn reconcile(
    inputs: &[Dictionary],
    profile: DictionaryProfile,
) -> Result<DictionaryMapping> {
    let first = inputs
        .first()
        .ok_or_else(|| invalid("no input dictionaries"))?;
    let mut dict = first.clone();
    let mut names = vec![Vec::new(); inputs.len()];
    for (i, input) in inputs.iter().enumerate().skip(1) {
        let alias = !matches!(profile, DictionaryProfile::BwArithmetic)
            && !dict
                .iter()
                .any(|c| input.iter().any(|x| x.name == c.name && x.len == c.len));
        dict.retain_mut(|c| {
            let search = if alias {
                toggle_chr(&c.name)
            } else {
                c.name.clone()
            };
            if let Some(other) = input.iter().find(|x| {
                x.name == search
                    && (matches!(profile, DictionaryProfile::BwArithmetic) || x.len == c.len)
            }) {
                if matches!(profile, DictionaryProfile::BwArithmetic) {
                    c.len = c.len.min(other.len);
                }
                true
            } else {
                false
            }
        });
        if alias {
            eprintln!(
                "warning: chromosome names differ in sample {}; applying chr-prefix fallback",
                i + 1
            );
        }
    }
    if matches!(profile, DictionaryProfile::BwSummary) {
        dict.sort_by(|a, b| a.name.cmp(&b.name));
    }
    if dict.is_empty() {
        return Err(invalid("no common chromosome names and lengths"));
    }
    for (i, input) in inputs.iter().enumerate() {
        names[i] = dict
            .iter()
            .map(|c| {
                if input.iter().any(|x| x.name == c.name) {
                    c.name.clone()
                } else {
                    toggle_chr(&c.name)
                }
            })
            .collect();
    }
    Ok(DictionaryMapping {
        dictionary: dict,
        names,
    })
}
pub(crate) fn toggle_chr(name: &str) -> String {
    name.strip_prefix("chr")
        .map_or_else(|| format!("chr{name}"), str::to_owned)
}
pub(crate) fn annotation_alias(name: &str) -> String {
    match name {
        "MT" => "chrM".into(),
        "chrM" => "MT".into(),
        _ => toggle_chr(name),
    }
}
pub(crate) fn annotation_chrom<'a>(
    dict: &'a Dictionary,
    name: &str,
) -> Option<&'a crate::model::Chromosome> {
    dict.iter().find(|c| c.name == name).or_else(|| {
        let alias = annotation_alias(name);
        dict.iter().find(|c| c.name == alias)
    })
}
pub(crate) fn plan_tasks(
    dict: &Dictionary,
    chunk: u32,
    region: Option<&str>,
    mask: &MaskIndex,
    tile: Option<u32>,
) -> Result<Vec<Task>> {
    if chunk == 0 {
        return Err(invalid("chunk length must be positive"));
    }
    let filter = region
        .map(|r| {
            let f: Vec<_> = r.split(':').collect();
            if f.len() > 3 {
                return Err(invalid("region must be chromosome[:start[:end]]"));
            }
            let start = if f.len() > 1 {
                f[1].replace(',', "").parse::<u32>()?
            } else {
                0
            };
            let end = if f.len() > 2 {
                Some(f[2].replace(',', "").parse::<u32>()?)
            } else {
                None
            };
            let chrom = annotation_chrom(dict, f[0])
                .ok_or_else(|| invalid(format!("unknown region chromosome: {}", f[0])))?;
            let end = end.unwrap_or(chrom.len).min(chrom.len);
            if start > end {
                return Err(invalid("region start exceeds its clipped end"));
            }
            let (start, rounded_end) = if let Some(tile) = tile.filter(|n| *n > 0) {
                (
                    start - start % tile,
                    u64::from(end) + u64::from(tile - end % tile),
                )
            } else {
                (start, u64::from(end))
            };
            let mut length = (rounded_end - u64::from(start)).min(1_000_000) as u32;
            if let Some(tile) = tile.filter(|n| *n > 0 && *n < length) {
                length -= length % tile;
            }
            Ok((chrom.name.clone(), start, end, length))
        })
        .transpose()?;
    let mut tasks = Vec::new();
    for (chrom, c) in dict.iter().enumerate() {
        if filter.as_ref().is_some_and(|x| x.0 != c.name) {
            continue;
        }
        let start = filter.as_ref().map_or(0, |x| x.1);
        let end = filter.as_ref().map(|x| x.2).unwrap_or(c.len).min(c.len);
        if start >= end {
            continue;
        }
        let mut cursor = start;
        let chunk = filter.as_ref().map_or(chunk, |x| x.3);
        while cursor < end {
            let stop = cursor.saturating_add(chunk).min(end);
            for span in mask.task_spans(
                dict,
                Span {
                    chrom,
                    start: cursor,
                    end: stop,
                },
            ) {
                tasks.push(Task {
                    ordinal: tasks.len(),
                    grid_origin: span.start,
                    span,
                });
            }
            cursor = stop;
        }
    }
    if tasks.is_empty() {
        return Err(invalid("no genomic tasks remain"));
    }
    Ok(tasks)
}
pub(crate) fn windows(task: &Task, bin: u32, distance: u32) -> Result<Vec<Span>> {
    Ok(window_blocks(task, bin, distance, false, usize::MAX)?
        .flatten()
        .collect())
}
pub(crate) fn window_blocks(
    task: &Task,
    bin: u32,
    distance: u32,
    complete: bool,
    block_rows: usize,
) -> Result<impl Iterator<Item = Vec<Span>> + '_> {
    if bin == 0 {
        return Err(invalid("bin size must be positive"));
    }
    let step = bin
        .checked_add(distance)
        .ok_or_else(|| invalid("bin step overflow"))?;
    let mut start = task.grid_origin;
    Ok(std::iter::from_fn(move || {
        let mut out = Vec::new();
        while out.len() < block_rows && start < task.span.end {
            let end = start.saturating_add(bin);
            if complete && task.span.end - start < bin {
                start = task.span.end;
                break;
            }
            out.push(Span {
                chrom: task.span.chrom,
                start,
                end: end.min(task.span.end),
            });
            start = start.checked_add(step).unwrap_or(task.span.end);
        }
        (!out.is_empty()).then_some(out)
    }))
}
