use crate::model::{RunContext, invalid};
use rsomics_common::Result;
use std::sync::{
    Mutex,
    atomic::{AtomicUsize, Ordering},
};

pub(crate) fn ordered_map<T: Sync, R: Send>(
    items: &[T],
    context: &RunContext,
    function: impl Fn(&T) -> Result<R> + Sync,
) -> Result<Vec<R>> {
    let mut output = Vec::with_capacity(items.len());
    for batch in items.chunks(context.max_inflight.max(1)) {
        let next = AtomicUsize::new(0);
        let results: Vec<_> = (0..batch.len()).map(|_| Mutex::new(None)).collect();
        std::thread::scope(|scope| {
            let mut handles = Vec::new();
            for _ in 0..context.threads.get().min(batch.len()) {
                let next = &next;
                let results = &results;
                let function = &function;
                handles.push(scope.spawn(move || {
                    loop {
                        let i = next.fetch_add(1, Ordering::Relaxed);
                        if i >= batch.len() {
                            break;
                        }
                        let result = function(&batch[i]);
                        *results[i]
                            .lock()
                            .map_err(|_| invalid("worker result lock poisoned"))? = Some(result);
                    }
                    Ok::<(), rsomics_common::RsomicsError>(())
                }));
            }
            for handle in handles {
                handle
                    .join()
                    .map_err(|_| invalid("signal worker panicked; outputs not published"))??;
            }
            Ok::<(), rsomics_common::RsomicsError>(())
        })?;
        for result in results {
            output.push(
                result
                    .into_inner()
                    .map_err(|_| invalid("worker result lock poisoned"))?
                    .ok_or_else(|| invalid("worker omitted result"))??,
            );
        }
    }
    Ok(output)
}
