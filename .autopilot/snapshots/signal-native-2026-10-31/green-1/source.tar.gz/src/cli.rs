use crate::model::*;
use clap::{Args, FromArgMatches, Parser, Subcommand, parser::ValueSource};
use std::num::NonZeroUsize;
use std::path::PathBuf;

#[derive(Debug, Parser)]
#[command(
    name = "rsomics-signal",
    version,
    about = "Genome signal tracks, arithmetic and region matrices"
)]
pub(crate) struct Cli {
    #[command(flatten)]
    threads: rsomics_common::ThreadArgs,
    #[command(subcommand)]
    pub command: Command,
}
impl Cli {
    pub(crate) fn into_command(mut self) -> Command {
        let threads = self.threads.requested().unwrap_or(NonZeroUsize::MIN);
        let execution = match &mut self.command {
            Command::Track(args) => &mut args.execution,
            Command::Compare(args) => &mut args.execution,
            Command::Average(args) => &mut args.execution,
            Command::Filter(args) => &mut args.execution,
            Command::Summarize { mode } => match mode {
                SummaryCommand::Bins(args) | SummaryCommand::Regions(args) => &mut args.execution,
            },
            Command::Matrix { mode } => match mode {
                MatrixCommand::Reference(args) | MatrixCommand::Scale(args) => &mut args.execution,
            },
        };
        execution.threads = threads;
        self.command
    }
}
pub(crate) fn parse() -> (Cli, rsomics_common::Result<()>) {
    let matches = rsomics_help::command::<Cli>().get_matches();
    let cli = Cli::from_arg_matches(&matches).unwrap_or_else(|error| error.exit());
    let validation = mode_flags(&matches);
    (cli, validation)
}
fn mode_flags(matches: &clap::ArgMatches) -> rsomics_common::Result<()> {
    let read_flags = [
        "extend_reads",
        "center_reads",
        "ignore_duplicates",
        "min_mapq",
        "include_flags",
        "exclude_flags",
        "min_fragment_length",
        "max_fragment_length",
    ];
    let reject = |matches: &clap::ArgMatches, flags: &[&str]| -> rsomics_common::Result<()> {
        for flag in flags {
            if matches.value_source(flag) == Some(ValueSource::CommandLine) {
                return Err(invalid(format!(
                    "--{} is not available for this input mode",
                    flag.replace('_', "-")
                )));
            }
        }
        Ok(())
    };
    if let Some(m) = matches.subcommand_matches("compare")
        && m.get_one::<InputKind>("input") == Some(&InputKind::Bigwig)
    {
        reject(m, &read_flags)?;
        reject(
            m,
            &[
                "normalize",
                "effective_genome_size",
                "exact_scaling",
                "ignore_for_normalization",
                "scale_method",
                "sample_length",
                "number_of_samples",
                "smooth_length",
            ],
        )?;
    }
    if let Some(m) = matches
        .subcommand_matches("summarize")
        .and_then(|m| m.subcommand().map(|(_, m)| m))
    {
        if m.get_one::<InputKind>("input") == Some(&InputKind::Bigwig) {
            reject(m, &read_flags)?;
            reject(m, &["scaling_factors", "genome_chunk_size"])?;
        } else {
            reject(m, &["chromosomes_to_skip"])?;
        }
    }
    Ok(())
}
#[derive(Debug, Subcommand)]
pub(crate) enum Command {
    /// Create a binned signal track from indexed BAM.
    Track(TrackArgs),
    /// Compare two BAM or bigWig signals.
    Compare(CompareArgs),
    /// Average scaled bigWig signals.
    Average(AverageArgs),
    /// Summarize multiple samples into a NumPy matrix.
    Summarize {
        #[command(subcommand)]
        mode: SummaryCommand,
    },
    /// Construct a multi-sample, multi-group signal matrix.
    Matrix {
        #[command(subcommand)]
        mode: MatrixCommand,
    },
    /// Filter alignments, shift fragments and write BAM or fragment BED.
    Filter(FilterArgs),
}
#[derive(Clone, Debug, Args)]
pub(crate) struct ExecutionArgs {
    #[arg(skip=NonZeroUsize::MIN)]
    pub threads: NonZeroUsize,
    #[arg(long)]
    pub region: Option<String>,
    #[arg(long, num_args=1..)]
    pub blacklist: Vec<PathBuf>,
    #[arg(long)]
    pub verbose: bool,
    #[arg(long)]
    pub report: Option<PathBuf>,
}
#[derive(Clone, Debug, Default, Args)]
pub(crate) struct BamArgs {
    #[arg(long, num_args=0..=1, default_missing_value="0")]
    pub extend_reads: Option<u32>,
    #[arg(long)]
    pub center_reads: bool,
    #[arg(long)]
    pub ignore_duplicates: bool,
    #[arg(long, default_value_t = 0)]
    pub min_mapq: u8,
    #[arg(long, default_value_t = 0)]
    pub include_flags: u16,
    #[arg(long, default_value_t = 0)]
    pub exclude_flags: u16,
    #[arg(long, default_value_t = 0)]
    pub min_fragment_length: u32,
    #[arg(long, default_value_t = 0)]
    pub max_fragment_length: u32,
}
#[derive(Clone, Debug, Args)]
pub(crate) struct NormalizeArgs {
    #[arg(long, value_enum, default_value = "none")]
    pub normalize: Normalization,
    #[arg(long)]
    pub effective_genome_size: Option<u64>,
    #[arg(long)]
    pub exact_scaling: bool,
    #[arg(long, num_args=1..)]
    pub ignore_for_normalization: Vec<String>,
}
#[derive(Clone, Debug, Args)]
pub(crate) struct TrackArgs {
    #[arg(long)]
    pub bam: PathBuf,
    #[arg(long)]
    pub out: PathBuf,
    #[arg(long, value_enum, default_value = "bigwig")]
    pub format: TrackFormat,
    #[arg(long, default_value_t = 50)]
    pub bin_size: u32,
    #[arg(long, default_value_t = 1.0)]
    pub scale: f64,
    #[arg(long)]
    pub skip_nas: bool,
    #[arg(long)]
    pub smooth_length: Option<u32>,
    #[arg(long, num_args=1..=2, allow_negative_numbers=true)]
    pub offset: Vec<i32>,
    #[arg(long, value_enum)]
    pub rna_strand: Option<StrandFilter>,
    #[arg(long)]
    pub mnase: bool,
    #[command(flatten)]
    pub bam_options: BamArgs,
    #[command(flatten)]
    pub normalization: NormalizeArgs,
    #[command(flatten)]
    pub execution: ExecutionArgs,
}
#[derive(Clone, Debug, Args)]
pub(crate) struct CompareArgs {
    #[arg(long, value_enum)]
    pub input: InputKind,
    #[arg(long)]
    pub first: PathBuf,
    #[arg(long)]
    pub second: PathBuf,
    #[arg(long)]
    pub out: PathBuf,
    #[arg(long, value_enum, default_value = "bigwig")]
    pub format: TrackFormat,
    #[arg(long, default_value_t = 50)]
    pub bin_size: u32,
    #[arg(long, value_enum, default_value = "log2")]
    pub operation: ArithmeticOp,
    #[arg(long, num_args=1..=2, default_values=["1"], allow_negative_numbers=true)]
    pub pseudocount: Vec<f64>,
    #[arg(long)]
    pub scale_factors: Option<String>,
    #[arg(long, value_enum, default_value = "readCount")]
    pub scale_method: ScaleMethod,
    #[arg(long, default_value_t = 1000)]
    pub sample_length: u32,
    #[arg(long, default_value_t = 100000)]
    pub number_of_samples: usize,
    #[arg(long)]
    pub skip_zero_over_zero: bool,
    #[arg(long)]
    pub skip_nas: bool,
    #[arg(long)]
    pub fixed_step: bool,
    #[arg(long)]
    pub smooth_length: Option<u32>,
    #[command(flatten)]
    pub bam_options: BamArgs,
    #[command(flatten)]
    pub normalization: NormalizeArgs,
    #[command(flatten)]
    pub execution: ExecutionArgs,
}
#[derive(Clone, Debug, Args)]
pub(crate) struct AverageArgs {
    #[arg(long, num_args=1..)]
    pub bigwig: Vec<PathBuf>,
    #[arg(long)]
    pub out: PathBuf,
    #[arg(long, value_enum, default_value = "bigwig")]
    pub format: TrackFormat,
    #[arg(long, default_value_t = 50)]
    pub bin_size: u32,
    #[arg(long)]
    pub scale_factors: Option<String>,
    #[arg(long)]
    pub skip_nas: bool,
    #[command(flatten)]
    pub execution: ExecutionArgs,
}
#[derive(Clone, Debug, Default, Args)]
pub(crate) struct AnnotationArgs {
    #[arg(long)]
    pub metagene: bool,
    #[arg(long, default_value = "transcript")]
    pub transcript_id: String,
    #[arg(long, default_value = "exon")]
    pub exon_id: String,
    #[arg(long, default_value = "transcript_id")]
    pub transcript_id_designator: String,
}
#[derive(Debug, Subcommand)]
pub(crate) enum SummaryCommand {
    Bins(SummaryArgs),
    Regions(SummaryArgs),
}
#[derive(Clone, Debug, Args)]
pub(crate) struct SummaryArgs {
    #[arg(long, value_enum)]
    pub input: InputKind,
    #[arg(long, num_args=1..)]
    pub files: Vec<PathBuf>,
    #[arg(long)]
    pub out: PathBuf,
    #[arg(long, num_args=1..)]
    pub regions: Vec<PathBuf>,
    #[arg(long, default_value_t = 10000)]
    pub bin_size: u32,
    #[arg(long, default_value_t = 0)]
    pub distance_between_bins: u32,
    #[arg(long, num_args=1..)]
    pub labels: Vec<String>,
    #[arg(long)]
    pub smart_labels: bool,
    #[arg(long)]
    pub raw_counts: Option<PathBuf>,
    #[arg(long)]
    pub scaling_factors: Option<PathBuf>,
    #[arg(long)]
    pub genome_chunk_size: Option<u32>,
    #[arg(long, num_args=1..)]
    pub chromosomes_to_skip: Vec<String>,
    #[command(flatten)]
    pub bam_options: BamArgs,
    #[command(flatten)]
    pub annotation: AnnotationArgs,
    #[command(flatten)]
    pub execution: ExecutionArgs,
}
#[derive(Debug, Subcommand)]
pub(crate) enum MatrixCommand {
    Reference(MatrixArgs),
    Scale(MatrixArgs),
}
#[derive(Clone, Debug, Args)]
pub(crate) struct MatrixArgs {
    #[arg(long, num_args=1..)]
    pub bigwig: Vec<PathBuf>,
    #[arg(long, num_args=1..)]
    pub regions: Vec<PathBuf>,
    #[arg(long)]
    pub out: PathBuf,
    #[arg(long, value_enum, default_value = "TSS")]
    pub reference_point: RefPoint,
    #[arg(long)]
    pub before: Option<u32>,
    #[arg(long)]
    pub after: Option<u32>,
    #[arg(long)]
    pub body_length: Option<u32>,
    #[arg(long, default_value_t = 0)]
    pub unscaled_5prime: u32,
    #[arg(long, default_value_t = 0)]
    pub unscaled_3prime: u32,
    #[arg(long, default_value_t = 10)]
    pub bin_size: u32,
    #[arg(long)]
    pub nan_after_end: bool,
    #[arg(long, value_enum, default_value = "mean")]
    pub average_type_bins: Reducer,
    #[arg(long)]
    pub missing_as_zero: bool,
    #[arg(long)]
    pub skip_zeros: bool,
    #[arg(long, allow_negative_numbers = true)]
    pub min_threshold: Option<f64>,
    #[arg(long, allow_negative_numbers = true)]
    pub max_threshold: Option<f64>,
    #[arg(long, default_value_t = 1.0, allow_negative_numbers = true)]
    pub scale: f64,
    #[arg(long, value_enum, default_value = "keep")]
    pub sort_regions: SortRegions,
    #[arg(long, value_enum, default_value = "mean")]
    pub sort_using: SortUsing,
    #[arg(long, num_args=1..)]
    pub sort_using_samples: Vec<usize>,
    #[arg(long, num_args=1..)]
    pub labels: Vec<String>,
    #[arg(long)]
    pub smart_labels: bool,
    #[arg(long)]
    pub matrix_tsv: Option<PathBuf>,
    #[arg(long)]
    pub sorted_regions: Option<PathBuf>,
    #[arg(long, default_value = "TSS")]
    pub start_label: String,
    #[arg(long, default_value = "TES")]
    pub end_label: String,
    #[arg(long)]
    pub quiet: bool,
    #[command(flatten)]
    pub annotation: AnnotationArgs,
    #[command(flatten)]
    pub execution: ExecutionArgs,
}
#[derive(Clone, Debug, Args)]
pub(crate) struct FilterArgs {
    #[arg(long)]
    pub bam: PathBuf,
    #[arg(long)]
    pub out: PathBuf,
    #[arg(long, value_enum, default_value = "bam")]
    pub format: FilterFormat,
    #[arg(long)]
    pub filtered_out: Option<PathBuf>,
    #[arg(long)]
    pub metrics: Option<PathBuf>,
    #[arg(long)]
    pub label: Option<String>,
    #[arg(long)]
    pub smart_labels: bool,
    #[arg(long, num_args=2..=4, allow_negative_numbers=true)]
    pub shift: Vec<i32>,
    #[arg(long)]
    pub atac_shift: bool,
    #[arg(long, value_enum)]
    pub rna_strand: Option<StrandFilter>,
    #[arg(long, default_value_t = 1000000)]
    pub genome_chunk_length: u32,
    #[command(flatten)]
    pub bam_options: BamArgs,
    #[command(flatten)]
    pub execution: ExecutionArgs,
}
