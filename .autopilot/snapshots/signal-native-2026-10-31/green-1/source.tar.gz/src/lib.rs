#[path = "operations/filter.rs"]
mod alignment_filter;
mod alignments;
mod bigwig;
mod cli;
mod execute;
mod grid;
mod mask;
mod model;
mod normalization;
mod operations;
mod output;
mod plan;
mod reduce;
mod regions;
#[cfg(test)]
#[path = "../tests/support/fixtures.rs"]
mod test_fixtures;

/// Runs the signal product command-line application.
pub fn run_cli() -> std::process::ExitCode {
    let (cli, input_mode_validation) = cli::parse();
    rsomics_common::run(
        &rsomics_common::OutputArgs::default(),
        rsomics_common::ToolMeta {
            name: "rsomics-signal",
            version: env!("CARGO_PKG_VERSION"),
        },
        || {
            input_mode_validation?;
            match plan::validate(cli.into_command())? {
                cli::Command::Track(args) => operations::tracks::track(args),
                cli::Command::Compare(args) => operations::tracks::compare(args),
                cli::Command::Average(args) => operations::tracks::average(args),
                cli::Command::Summarize { mode } => match mode {
                    cli::SummaryCommand::Bins(args) => operations::summarize::run(args, false),
                    cli::SummaryCommand::Regions(args) => operations::summarize::run(args, true),
                },
                cli::Command::Matrix { mode } => match mode {
                    cli::MatrixCommand::Reference(args) => operations::matrix::run(args, false),
                    cli::MatrixCommand::Scale(args) => operations::matrix::run(args, true),
                },
                cli::Command::Filter(args) => alignment_filter::run(args),
            }
        },
    )
}

#[cfg(test)]
mod feasibility {
    use crate::{
        bigwig::{BwReader, StatsMode},
        cli::BamArgs,
        grid,
        mask::MaskIndex,
        model::*,
        output::RunSink,
    };
    use std::num::NonZeroUsize;
    fn values(reader: &mut BwReader, chrom: &str, len: u32) -> Vec<f64> {
        let mut values = vec![f64::NAN; len as usize];
        for run in reader.full_runs(chrom, 0, len).unwrap() {
            values[run.start as usize..run.end as usize].fill(f64::from(run.value));
        }
        values
    }
    #[test]
    fn native_track_bigwig_summary_spine() {
        let root = crate::test_fixtures::fixture_root();
        let context = RunContext::new(NonZeroUsize::new(2).unwrap()).unwrap();
        let scratch = tempfile::Builder::new()
            .prefix("signal-native-spine-")
            .tempdir_in(&context.scratch)
            .unwrap();
        let bam = root.join("generated-inputs/a.source.bam");
        let (dictionary, mapped) = crate::alignments::dictionary(&bam, context.threads).unwrap();
        assert_eq!(mapped, 64);
        let mask = MaskIndex::default();
        let tasks = grid::plan_tasks(&dictionary, 10000000, None, &mask, Some(20)).unwrap();
        let profile = crate::alignments::CountProfile::resolve(
            &bam,
            &BamArgs::default(),
            None,
            &mask,
            &context,
        )
        .unwrap();
        let results = crate::execute::ordered_map(&tasks, &context, |task| {
            crate::alignments::count_task(
                &bam,
                &dictionary[task.span.chrom].name,
                task,
                20,
                &profile,
                &mask,
            )
        })
        .unwrap();
        let graph = scratch.path().join("track.bedgraph");
        let mut sink = RunSink::new(std::fs::File::create(&graph).unwrap(), &dictionary, false);
        for result in results {
            for (window, value) in result.windows.into_iter().zip(result.values) {
                sink.push(window, Some(value * 15625.0)).unwrap();
            }
            sink.gap().unwrap();
        }
        sink.finish().unwrap();
        let bw = scratch.path().join("track.bw");
        let levels = crate::bigwig::write_bedgraph(&bw, &graph, &dictionary, &context).unwrap();
        let mut reader = BwReader::open(&bw).unwrap();
        assert_eq!(reader.dictionary, dictionary);
        assert!(!levels.is_empty());
        let original: serde_json::Value = serde_json::from_reader(
            std::fs::File::open(root.join("calls/track-values-a-bigwig/observation.json")).unwrap(),
        )
        .unwrap();
        for c in &dictionary {
            let values = values(&mut reader, &c.name, c.len);
            let source = original["result"]["data"][&c.name]["values"]
                .as_array()
                .unwrap();
            assert_eq!(values.len(), source.len());
            for (index, (native, source)) in values.iter().zip(source).enumerate() {
                assert_eq!(*native, source.as_f64().unwrap(), "{}:{}", c.name, index);
            }
        }
        let exact = reader.mean("chr1", 17, 1813, StatsMode::Exact).unwrap();
        assert!((exact - 42907.85077951002).abs() < 1e-8);
        assert!(
            (reader
                .mean("chr1", 17, 1813, StatsMode::Approximate356)
                .unwrap()
                - 41302.48134566038)
                .abs()
                < 1e-8
        );
        let mut imported = BwReader::open(&root.join("generated-inputs/zoom.bw")).unwrap();
        assert!(
            (imported
                .mean("chr1", 0, 20003, StatsMode::Approximate356)
                .unwrap()
                - 2.985)
                .abs()
                < 1e-12
        );
        assert!(
            (imported.mean("chr1", 0, 20003, StatsMode::Exact).unwrap() - 2.9975).abs() < 1e-12
        );
        let sparse_graph = scratch.path().join("sparse.bedgraph");
        let mut sparse = std::fs::File::create(&sparse_graph).unwrap();
        use std::io::Write;
        for run in imported.full_runs("chr1", 0, 20003).unwrap() {
            writeln!(
                sparse,
                "chr1\t{}\t{}\t{}",
                run.start,
                run.end,
                crate::reduce::format_g(f64::from(run.value))
            )
            .unwrap();
        }
        sparse.flush().unwrap();
        let native_sparse = scratch.path().join("sparse-native.bw");
        let native_levels = crate::bigwig::write_bedgraph(
            &native_sparse,
            &sparse_graph,
            &imported.dictionary,
            &context,
        )
        .unwrap();
        let mut native_sparse_reader = BwReader::open(&native_sparse).unwrap();
        let native_default = native_sparse_reader
            .mean("chr1", 0, 20003, StatsMode::Approximate356)
            .unwrap();
        assert_eq!(native_levels, vec![80]);
        assert!((native_default - 2.985).abs() < 1e-12);
        eprintln!(
            "native DeepTools356 zoom profile: sparse reductions={native_levels:?}, approximate={native_default}; pinned source-on-native hosted gate remains pending"
        );
        assert!(
            (native_sparse_reader
                .mean("chr1", 0, 20003, StatsMode::Exact)
                .unwrap()
                - 2.9975)
                .abs()
                < 1e-12
        );
        eprintln!(
            "retained native spine outputs: {}",
            scratch.keep().display()
        );
    }
}
