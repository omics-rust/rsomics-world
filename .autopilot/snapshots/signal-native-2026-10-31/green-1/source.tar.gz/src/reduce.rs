use crate::model::{ArithmeticOp, Reducer};
pub(crate) fn reduce(values: &[f64], reducer: Reducer, mask_invalid: bool) -> f64 {
    let mut v: Vec<f64> = values
        .iter()
        .copied()
        .filter(|v| !mask_invalid || v.is_finite())
        .collect();
    if v.is_empty() {
        return f64::NAN;
    }
    if v.iter().any(|x| x.is_nan()) {
        return f64::NAN;
    }
    let sum = v.iter().sum::<f64>();
    match reducer {
        Reducer::Mean => sum / v.len() as f64,
        Reducer::Sum => sum,
        Reducer::Min => v.iter().copied().fold(f64::INFINITY, f64::min),
        Reducer::Max => v.iter().copied().fold(f64::NEG_INFINITY, f64::max),
        Reducer::Median => {
            v.sort_by(f64::total_cmp);
            if v.len() % 2 == 1 {
                v[v.len() / 2]
            } else {
                (v[v.len() / 2 - 1] + v[v.len() / 2]) / 2.0
            }
        }
        Reducer::Std => {
            let m = sum / v.len() as f64;
            (v.iter().map(|x| (x - m).powi(2)).sum::<f64>() / v.len() as f64).sqrt()
        }
    }
}
pub(crate) fn arithmetic(
    values: [f64; 2],
    scales: [f64; 2],
    pseudocount: [f64; 2],
    operation: ArithmeticOp,
) -> f64 {
    let a = values[0] * scales[0];
    let b = values[1] * scales[1];
    if a.is_nan() || b.is_nan() {
        return f64::NAN;
    }
    match operation {
        ArithmeticOp::Subtract => a - b,
        ArithmeticOp::Add => a + b,
        ArithmeticOp::Mean => (a + b) / 2.0,
        ArithmeticOp::First => a,
        ArithmeticOp::Second => b,
        ArithmeticOp::Ratio => (a + pseudocount[0]) / (b + pseudocount[1]),
        ArithmeticOp::Log2 => ((a + pseudocount[0]) / (b + pseudocount[1])).log2(),
        ArithmeticOp::ReciprocalRatio => {
            let r = (a + pseudocount[0]) / (b + pseudocount[1]);
            if r >= 1.0 { r } else { -1.0 / r }
        }
    }
}
pub(crate) fn format_g(v: f64) -> String {
    if v.is_nan() {
        return "nan".into();
    }
    if v.is_infinite() {
        return if v > 0.0 { "inf" } else { "-inf" }.into();
    }
    if v == 0.0 {
        return "0".into();
    }
    let sci = format!("{v:.5e}");
    let (mantissa, exp) = sci
        .split_once('e')
        .expect("Rust scientific format contains exponent");
    let exponent: i32 = exp.parse().expect("Rust scientific exponent is integer");
    if !(-4..6).contains(&exponent) {
        return format!(
            "{}e{}{:02}",
            mantissa.trim_end_matches('0').trim_end_matches('.'),
            if exponent >= 0 { "+" } else { "-" },
            exponent.abs()
        );
    }
    let decimals = (5 - exponent).max(0) as usize;
    let s = format!("{v:.decimals$}");
    if s.contains('.') {
        s.trim_end_matches('0').trim_end_matches('.').to_owned()
    } else {
        s
    }
}
