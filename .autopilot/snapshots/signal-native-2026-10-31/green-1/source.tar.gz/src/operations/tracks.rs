use crate::{
    alignments,
    bigwig::{BwReader, write_bedgraph},
    cli::{AverageArgs, CompareArgs, ExecutionArgs, TrackArgs},
    execute::ordered_map,
    grid::{self, DictionaryProfile},
    mask::MaskIndex,
    model::*,
    output::{OutputSet, RunSink},
    reduce::arithmetic,
};
use rsomics_common::Result;
use serde_json::{Value, json};
use std::{io::Write, path::PathBuf};

fn bam_chunk(dict: &Dictionary, mapped: &[u64], bin: u32) -> Result<u32> {
    if bin == 0 {
        return Err(invalid("bin size must be positive"));
    }
    let length = dict.iter().map(|c| u64::from(c.len)).sum::<u64>();
    let max = mapped.iter().copied().max().unwrap_or(0);
    let chunk = if max == 0 {
        5_000_000
    } else {
        (2_000_000.0 / (max as f64 / length as f64 * mapped.len() as f64)).min(5_000_000.0) as u32
    };
    let aligned = chunk - chunk % bin;
    if aligned == 0 {
        return Err(invalid(
            "coverage density produces a zero source task length",
        ));
    }
    Ok(aligned)
}
fn smooth(values: &[f64], index: usize, bin: u32, length: Option<u32>) -> f64 {
    let Some(length) = length.filter(|l| *l > bin) else {
        return values[index];
    };
    let tiles = length / bin;
    let left = (tiles - 1).div_ceil(2) as usize;
    let right = ((tiles - 1) / 2 + 1) as usize;
    let range = &values[index.saturating_sub(left)..index.saturating_add(right).min(values.len())];
    range.iter().sum::<f64>() / range.len() as f64
}
struct TrackOutput {
    files: OutputSet,
    format: TrackFormat,
    report: bool,
}
impl TrackOutput {
    fn stage(
        out: &std::path::Path,
        format: TrackFormat,
        inputs: &[PathBuf],
        execution: &ExecutionArgs,
    ) -> Result<Self> {
        let mut paths = vec![out.to_owned()];
        if let Some(path) = &execution.report {
            paths.push(path.clone());
        }
        let mut inputs = inputs.to_vec();
        inputs.extend(execution.blacklist.clone());
        Ok(Self {
            files: OutputSet::stage(&paths, &inputs)?,
            format,
            report: execution.report.is_some(),
        })
    }
}
fn publish(
    graph: &std::path::Path,
    dict: &Dictionary,
    context: &RunContext,
    mut output: TrackOutput,
    mut report: Value,
) -> Result<Value> {
    if output.format == TrackFormat::Bedgraph {
        let mut file = std::fs::File::open(graph)?;
        std::io::copy(&mut file, output.files.writer(0))?;
    } else {
        let zooms = write_bedgraph(output.files.path(0), graph, dict, context)?;
        report["native_zoom_reductions"] = json!(zooms);
        report["zoom_qualification"] =
            json!("same-file source and connected writer interop pending hosted gate");
    }
    if output.report {
        serde_json::to_writer_pretty(output.files.writer(1), &report)
            .map_err(|e| invalid(e.to_string()))?;
        output.files.writer(1).write_all(b"\n")?;
    }
    output.files.commit()?;
    Ok(report)
}
pub(crate) fn track(args: TrackArgs) -> Result<Value> {
    let output = TrackOutput::stage(
        &args.out,
        args.format,
        std::slice::from_ref(&args.bam),
        &args.execution,
    )?;
    super::bam_index(&args.bam)?;
    let context = RunContext::new(args.execution.threads)?;
    let mask = MaskIndex::load(&args.execution.blacklist)?;
    let (dictionary, mapped) = alignments::dictionary(&args.bam, context.threads)?;
    let chunk = bam_chunk(&dictionary, &[mapped], args.bin_size)?;
    let scale = crate::normalization::track_scale(&args, &mask, &context)?;
    let profile = alignments::CountProfile::resolve(
        &args.bam,
        &args.bam_options,
        Some(&args),
        &mask,
        &context,
    )?;
    let tasks = grid::plan_tasks(
        &dictionary,
        chunk,
        args.execution.region.as_deref(),
        &mask,
        Some(args.bin_size),
    )?;
    let spool = tempfile::NamedTempFile::new_in(&context.scratch)?;
    let mut sink = RunSink::new(spool.reopen()?, &dictionary, false);
    let mut processed_grid = Vec::new();
    for batch in tasks.chunks(context.max_inflight) {
        let results = ordered_map(batch, &context, |task| {
            alignments::count_task(
                &args.bam,
                &dictionary[task.span.chrom].name,
                task,
                args.bin_size,
                &profile,
                &mask,
            )
        })?;
        for mut result in results {
            if args.execution.report.is_some() {
                processed_grid.push(json!({"ordinal":result.task.ordinal,"span":result.task.span,"grid_origin":result.task.grid_origin}));
            }
            if args.skip_nas {
                for value in &mut result.values {
                    if *value == 0.0 {
                        *value = f64::NAN;
                    }
                }
            }
            for (i, window) in result.windows.iter().enumerate() {
                let value =
                    smooth(&result.values, i, args.bin_size, args.smooth_length) * scale.factors[0];
                sink.push(*window, Some(value))?;
            }
            sink.gap()?;
        }
    }
    sink.finish()?;
    let report = json!({"operation":"track","input":args.bam,"mapped":mapped,"scale":scale.details,"factors":scale.factors,"tasks":tasks.len(),"processed_grid":processed_grid,"threads":context.threads.get(),"compatibility_profile":"deepTools3.5.6","known_incompatibilities":["SIGNAL-356-ZERO-TAIL"]});
    publish(spool.path(), &dictionary, &context, output, report)
}
pub(crate) fn compare(args: CompareArgs) -> Result<Value> {
    let output = TrackOutput::stage(
        &args.out,
        args.format,
        &[args.first.clone(), args.second.clone()],
        &args.execution,
    )?;
    let context = RunContext::new(args.execution.threads)?;
    let mask = MaskIndex::load(&args.execution.blacklist)?;
    let inputs = vec![args.first.clone(), args.second.clone()];
    let sources = if args.input == InputKind::Bigwig {
        inputs
            .iter()
            .map(|p| BwReader::open(p))
            .collect::<Result<Vec<_>>>()?
    } else {
        Vec::new()
    };
    let mut mapped = Vec::new();
    let dictionaries = if args.input == InputKind::Bam {
        for p in &inputs {
            super::bam_index(p)?;
        }
        inputs
            .iter()
            .map(|p| {
                alignments::dictionary(p, context.threads).map(|(d, n)| {
                    mapped.push(n);
                    d
                })
            })
            .collect::<Result<Vec<_>>>()?
    } else {
        sources.iter().map(|r| r.dictionary.clone()).collect()
    };
    let mapping = grid::reconcile(
        &dictionaries,
        if args.input == InputKind::Bam {
            DictionaryProfile::BamCount
        } else {
            DictionaryProfile::BwArithmetic
        },
    )?;
    let profile = if args.input == InputKind::Bam {
        Some(alignments::CountProfile::resolve(
            &args.first,
            &args.bam_options,
            None,
            &mask,
            &context,
        )?)
    } else {
        None
    };
    let scaling = if args.input == InputKind::Bam {
        crate::normalization::compare_scales(&args, &mask, &context)?
    } else {
        crate::normalization::ScaleReport {
            factors: super::factors(args.scale_factors.as_deref(), 2, false)?,
            details: json!({"method":"manual"}),
        }
    };
    let chunk = if args.input == InputKind::Bam {
        bam_chunk(&dictionaries[0], &mapped, args.bin_size)?
    } else {
        10_000_000
    };
    let tasks = grid::plan_tasks(
        &mapping.dictionary,
        chunk,
        args.execution.region.as_deref(),
        &mask,
        Some(args.bin_size),
    )?;
    let pc = [
        args.pseudocount[0],
        *args.pseudocount.get(1).unwrap_or(&args.pseudocount[0]),
    ];
    let scales = [scaling.factors[0], scaling.factors[1]];
    let spool = tempfile::NamedTempFile::new_in(&context.scratch)?;
    let mut sink = RunSink::new(spool.reopen()?, &mapping.dictionary, args.fixed_step);
    for batch in tasks.chunks(context.max_inflight) {
        let results = ordered_map(batch, &context, |task| -> Result<_> {
            let windows = grid::windows(task, args.bin_size, 0)?;
            let mut samples = Vec::new();
            for (i, input) in inputs.iter().enumerate() {
                samples.push(if args.input == InputKind::Bam {
                    alignments::count_task(
                        input,
                        &mapping.names[i][task.span.chrom],
                        task,
                        args.bin_size,
                        profile
                            .as_ref()
                            .ok_or_else(|| invalid("missing BAM operation geometry"))?,
                        &mask,
                    )?
                    .values
                } else {
                    sources[i].reopen()?.bin_means(
                        &mapping.names[i][task.span.chrom],
                        &windows.iter().map(|w| (w.start, w.end)).collect::<Vec<_>>(),
                        !args.skip_nas,
                    )?
                });
                if args.input == InputKind::Bam && args.skip_nas {
                    for value in samples
                        .last_mut()
                        .ok_or_else(|| invalid("missing BAM sample"))?
                    {
                        if *value == 0.0 {
                            *value = f64::NAN;
                        }
                    }
                }
            }
            let values = (0..windows.len())
                .map(|i| {
                    let values = [
                        smooth(&samples[0], i, args.bin_size, args.smooth_length),
                        smooth(&samples[1], i, args.bin_size, args.smooth_length),
                    ];
                    if args.skip_zero_over_zero && values.iter().all(|v| *v == 0.0) {
                        None
                    } else {
                        Some(arithmetic(values, scales, pc, args.operation))
                    }
                })
                .collect::<Vec<_>>();
            Ok((windows, values))
        })?;
        for (windows, values) in results {
            for (window, value) in windows.into_iter().zip(values) {
                sink.push(window, value)?;
            }
            sink.gap()?;
        }
    }
    sink.finish()?;
    let report = json!({"operation":"compare","input_kind":args.input,"factors":scaling.factors,"scaling":scaling.details,"tasks":tasks.len(),"threads":context.threads.get(),"known_incompatibilities":["SIGNAL-356-ARITHMETIC-LOSS","SIGNAL-356-ZERO-TAIL"]});
    publish(spool.path(), &mapping.dictionary, &context, output, report)
}
pub(crate) fn average(args: AverageArgs) -> Result<Value> {
    let output = TrackOutput::stage(&args.out, args.format, &args.bigwig, &args.execution)?;
    let context = RunContext::new(args.execution.threads)?;
    let mask = MaskIndex::load(&args.execution.blacklist)?;
    let sources = args
        .bigwig
        .iter()
        .map(|p| BwReader::open(p))
        .collect::<Result<Vec<_>>>()?;
    let dictionaries = sources
        .iter()
        .map(|r| r.dictionary.clone())
        .collect::<Vec<_>>();
    let mapping = grid::reconcile(&dictionaries, DictionaryProfile::BwArithmetic)?;
    let factors = super::factors(args.scale_factors.as_deref(), args.bigwig.len(), true)?;
    let tasks = grid::plan_tasks(
        &mapping.dictionary,
        10_000_000,
        args.execution.region.as_deref(),
        &mask,
        Some(args.bin_size),
    )?;
    let spool = tempfile::NamedTempFile::new_in(&context.scratch)?;
    let mut sink = RunSink::new(spool.reopen()?, &mapping.dictionary, false);
    for batch in tasks.chunks(context.max_inflight) {
        let results = ordered_map(batch, &context, |task| -> Result<_> {
            let windows = grid::windows(task, args.bin_size, 0)?;
            let coordinates = windows.iter().map(|w| (w.start, w.end)).collect::<Vec<_>>();
            let mut values = vec![0.0; windows.len()];
            for (i, source) in sources.iter().enumerate() {
                let sample = source.reopen()?.bin_means(
                    &mapping.names[i][task.span.chrom],
                    &coordinates,
                    !args.skip_nas,
                )?;
                for (v, s) in values.iter_mut().zip(sample) {
                    *v += s * factors[i];
                }
            }
            for v in &mut values {
                *v /= args.bigwig.len() as f64;
            }
            Ok((windows, values))
        })?;
        for (windows, values) in results {
            for (window, value) in windows.into_iter().zip(values) {
                sink.push(window, Some(value))?;
            }
            sink.gap()?;
        }
    }
    sink.finish()?;
    let report = json!({"operation":"average","samples":args.bigwig.len(),"factors":factors,"tasks":tasks.len(),"threads":context.threads.get(),"known_incompatibilities":["SIGNAL-356-ARITHMETIC-LOSS","SIGNAL-356-ZERO-TAIL"]});
    publish(spool.path(), &mapping.dictionary, &context, output, report)
}
