use crate::{
    alignments::{self, FilterState, QueryReader, shift},
    cli::FilterArgs,
    execute::ordered_map,
    grid,
    mask::MaskIndex,
    model::*,
    output::OutputSet,
};
use noodles::sam::header::record::value::{
    Map,
    map::{Program, program::tag},
};
use rsomics_bamio::raw::{self, RawRecord, RawRecordEncoder};
use rsomics_common::Result;
use serde_json::{Value, json};
use std::{
    fs::File,
    io::{BufReader, BufWriter, Write},
};

struct TaskOutput {
    passed: tempfile::NamedTempFile,
    rejected: tempfile::NamedTempFile,
    total: u64,
    filtered: u64,
    dropped: u64,
}

pub(crate) fn run(args: FilterArgs) -> Result<Value> {
    if args.bam_options.extend_reads.is_some() || args.bam_options.center_reads {
        return Err(invalid(
            "filter does not support coverage extension or centering",
        ));
    }
    if args.genome_chunk_length == 0 {
        return Err(invalid("filter genome chunk length must be positive"));
    }
    let context = RunContext::new(args.execution.threads)?;
    let mask = MaskIndex::load(&args.execution.blacklist)?;
    let shifts = shift::shifts(&args.shift, args.atac_shift)?;
    let mut initial = rsomics_bamio::open_with_workers(&args.bam, context.threads)?;
    let mut header = initial.read_header()?;
    let dictionary = alignments::header_dictionary(&header)?;
    let mut program = Map::<Program>::default();
    program
        .other_fields_mut()
        .insert(tag::NAME, "rsomics-signal".into());
    program
        .other_fields_mut()
        .insert(tag::VERSION, env!("CARGO_PKG_VERSION").into());
    program.other_fields_mut().insert(
        tag::COMMAND_LINE,
        std::env::args().collect::<Vec<_>>().join(" ").into(),
    );
    header.programs_mut().add("rsomics-signal", program)?;
    // Opening the index is mandatory even when all chromosomes are masked.
    QueryReader::open(&args.bam)?;
    let mut initial_records = 0u64;
    let mut input_record = RawRecord::default();
    while raw::read_record(initial.get_mut(), &mut input_record)? != 0 {
        initial_records = initial_records
            .checked_add(1)
            .ok_or_else(|| invalid("initial alignment count overflow"))?;
    }
    let tasks = grid::plan_tasks(
        &dictionary,
        args.genome_chunk_length,
        args.execution.region.as_deref(),
        &mask,
        None,
    )?;
    let mut outputs = vec![args.out.clone()];
    let rejected_index = args.filtered_out.as_ref().map(|p| {
        outputs.push(p.clone());
        outputs.len() - 1
    });
    let metrics_index = args.metrics.as_ref().map(|p| {
        outputs.push(p.clone());
        outputs.len() - 1
    });
    let report_index = args.execution.report.as_ref().map(|p| {
        outputs.push(p.clone());
        outputs.len() - 1
    });
    let mut inputs = vec![args.bam.clone()];
    inputs.extend(args.execution.blacklist.clone());
    let mut staged = OutputSet::stage(&outputs, &inputs)?;
    let mut bam_output = if args.format == FilterFormat::Bam {
        let mut writer = rsomics_bamio::create_with_workers(staged.path(0), context.threads)?;
        writer.write_header(&header)?;
        Some(writer)
    } else {
        None
    };
    let mut rejected_output = if let Some(index) = rejected_index {
        let mut writer = rsomics_bamio::create_with_workers(staged.path(index), context.threads)?;
        writer.write_header(&header)?;
        Some(writer)
    } else {
        None
    };
    let mut total_seen = 0u64;
    let mut filtered = 0u64;
    let mut dropped = 0u64;
    let mut passed = 0u64;
    let mut fragments = 0u64;
    let mut last_position = None;
    let mut coordinate_ordered = true;
    for batch in tasks.chunks(context.max_inflight.max(1)) {
        let results = ordered_map(batch, &context, |task| {
            let mut reader = QueryReader::open(&args.bam)?;
            let chrom = &dictionary[task.span.chrom];
            let mut kept_file = tempfile::Builder::new()
                .prefix("signal-filter-passed-")
                .tempfile_in(&context.scratch)?;
            let mut rejected_file = tempfile::Builder::new()
                .prefix("signal-filter-rejected-")
                .tempfile_in(&context.scratch)?;
            let mut kept = BufWriter::new(kept_file.as_file_mut());
            let mut rejected = BufWriter::new(rejected_file.as_file_mut());
            let mut state = FilterState::default();
            let mut encoder = RawRecordEncoder::new();
            let mut total = 0u64;
            let mut n_filtered = 0u64;
            let mut n_dropped = 0u64;
            reader.visit(&chrom.name, task.span.start, task.span.end, |record| {
                if i64::from(record.alignment_start()) < i64::from(task.span.start) {
                    return Ok(());
                }
                total = total
                    .checked_add(1)
                    .ok_or_else(|| invalid("filter task count overflow"))?;
                if !alignments::accept(
                    record,
                    &args.bam_options,
                    &mut state,
                    args.rna_strand,
                    false,
                )? {
                    n_filtered = n_filtered
                        .checked_add(1)
                        .ok_or_else(|| invalid("filter rejected count overflow"))?;
                    if rejected_index.is_some() {
                        raw::write_record(&mut rejected, record)?;
                    }
                    return Ok(());
                }
                if let Some(shifts) = shifts {
                    if let Some(transformed) =
                        shift::apply(record, chrom.len, shifts, &header, &mut encoder)?
                    {
                        raw::write_record(&mut kept, &transformed)?;
                    } else {
                        n_dropped = n_dropped
                            .checked_add(1)
                            .ok_or_else(|| invalid("shift dropped count overflow"))?;
                    }
                } else {
                    raw::write_record(&mut kept, record)?;
                }
                Ok(())
            })?;
            kept.flush()?;
            rejected.flush()?;
            drop(kept);
            drop(rejected);
            Ok(TaskOutput {
                passed: kept_file,
                rejected: rejected_file,
                total,
                filtered: n_filtered,
                dropped: n_dropped,
            })
        })?;
        for result in results {
            total_seen = total_seen
                .checked_add(result.total)
                .ok_or_else(|| invalid("filter count overflow"))?;
            filtered = filtered
                .checked_add(result.filtered)
                .ok_or_else(|| invalid("filter count overflow"))?;
            dropped = dropped
                .checked_add(result.dropped)
                .ok_or_else(|| invalid("filter count overflow"))?;
            let mut reader = BufReader::new(File::open(result.passed.path())?);
            let mut record = RawRecord::default();
            while raw::read_record(&mut reader, &mut record)? != 0 {
                let position = (record.reference_sequence_id(), record.alignment_start());
                if last_position.is_some_and(|last| position < last) {
                    coordinate_ordered = false;
                }
                last_position = Some(position);
                passed = passed
                    .checked_add(1)
                    .ok_or_else(|| invalid("passed alignment count overflow"))?;
                if let Some(writer) = bam_output.as_mut() {
                    raw::write_record(writer.get_mut(), &record)?;
                } else {
                    let length = alignments::template_length(&record, true)?;
                    if length > 0 {
                        let chrom = dictionary
                            .get(
                                usize::try_from(record.reference_sequence_id())
                                    .map_err(|_| invalid("fragment reference ID is negative"))?,
                            )
                            .ok_or_else(|| {
                                invalid("fragment reference ID is outside dictionary")
                            })?;
                        let start = i64::from(record.alignment_start());
                        let end = (start + length).min(i64::from(chrom.len));
                        if end > start {
                            writeln!(staged.writer(0), "{}\t{}\t{}", chrom.name, start, end)?;
                            fragments = fragments
                                .checked_add(1)
                                .ok_or_else(|| invalid("fragment row count overflow"))?;
                        }
                    }
                }
            }
            if let Some(writer) = rejected_output.as_mut() {
                let mut reader = BufReader::new(File::open(result.rejected.path())?);
                while raw::read_record(&mut reader, &mut record)? != 0 {
                    raw::write_record(writer.get_mut(), &record)?;
                }
            }
        }
    }
    if let Some(writer) = bam_output {
        writer.into_inner().finish()?;
    }
    if let Some(writer) = rejected_output {
        writer.into_inner().finish()?;
    }
    if !coordinate_ordered {
        eprintln!(
            "warning: shifted alignments are not coordinate ordered; output was not sorted or indexed"
        );
    }
    if let Some(index) = metrics_index {
        let label = if args.smart_labels {
            args.bam
                .file_stem()
                .ok_or_else(|| invalid("input BAM has no sample name"))?
                .to_string_lossy()
                .into_owned()
        } else {
            args.label
                .clone()
                .unwrap_or_else(|| args.bam.to_string_lossy().into_owned())
        };
        writeln!(
            staged.writer(index),
            "#bamFilterReads --filterMetrics\n#File\tReads Remaining\tTotal Initial Reads\n{}\t{}\t{}",
            label,
            total_seen - filtered,
            initial_records
        )?;
    }
    let report = json!({"operation":"filter","input":args.bam,"format":args.format,"initial_records":initial_records,"total_seen":total_seen,"filtered":filtered,"metrics_remaining":total_seen-filtered,"shift_dropped":dropped,"passed_alignments":passed,"fragment_rows":fragments,"shift":shifts,"coordinate_ordered":coordinate_ordered,"hidden_sort":false,"index_written":false,"threads":context.threads.get(),"tasks":tasks.len(),"rejected_payload":"original","shifted_payload":if shifts.is_some(){"match-only CIGAR; sequence, quality and tags removed"}else{"original"}});
    if let Some(index) = report_index {
        serde_json::to_writer_pretty(staged.writer(index), &report)
            .map_err(|e| invalid(e.to_string()))?;
        staged.writer(index).write_all(b"\n")?;
    }
    staged.commit()?;
    Ok(report)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cli::{Cli, Command};
    use clap::Parser;
    use std::num::NonZeroUsize;
    #[test]
    fn source_filter_payloads_and_bed_rejected_transaction() {
        let root = crate::test_fixtures::fixture_root();
        let scratch = tempfile::Builder::new()
            .prefix("signal-filter-check-")
            .tempdir_in(std::env::temp_dir())
            .unwrap();
        let input = root.join("generated-inputs/a.raw.bam");
        let out = scratch.path().join("passed.bed");
        let rejected = scratch.path().join("rejected.bam");
        let metrics = scratch.path().join("metrics.tsv");
        let Command::Filter(args) = Cli::parse_from([
            "signal",
            "filter",
            "--bam",
            input.to_str().unwrap(),
            "--out",
            out.to_str().unwrap(),
            "--filtered-out",
            rejected.to_str().unwrap(),
            "--metrics",
            metrics.to_str().unwrap(),
            "--format",
            "fragments-bed",
            "--min-mapq",
            "20",
            "--exclude-flags",
            "2816",
            "--atac-shift",
            "--genome-chunk-length",
            "256",
            "--threads",
            "2",
        ])
        .into_command() else {
            unreachable!()
        };
        let report = run(args).unwrap();
        assert_eq!(report["filtered"], 4);
        assert_eq!(report["shift_dropped"], 14);
        assert_eq!(report["passed_alignments"], 64);
        assert_eq!(report["fragment_rows"], 32);
        assert_eq!(std::fs::read_to_string(&out).unwrap().lines().count(), 32);
        let mut reader = rsomics_bamio::open_with_workers(&rejected, NonZeroUsize::MIN).unwrap();
        reader.read_header().unwrap();
        let mut actual = Vec::new();
        let mut record = RawRecord::default();
        while raw::read_record(reader.get_mut(), &mut record).unwrap() != 0 {
            actual.push(record.as_bytes().to_vec());
        }
        let mut reader = rsomics_bamio::open_with_workers(
            &root.join("results/a.excluded.bam"),
            NonZeroUsize::MIN,
        )
        .unwrap();
        reader.read_header().unwrap();
        let mut expected = Vec::new();
        while raw::read_record(reader.get_mut(), &mut record).unwrap() != 0 {
            expected.push(record.as_bytes().to_vec());
        }
        assert_eq!(actual, expected);
        assert!(
            std::fs::read_to_string(&metrics)
                .unwrap()
                .contains("\t78\t83\n")
        );
        let before_passed = std::fs::read(&out).unwrap();
        let before_rejected = std::fs::read(&rejected).unwrap();
        let before_metrics = std::fs::read(&metrics).unwrap();
        let Command::Filter(args) = Cli::parse_from([
            "signal",
            "filter",
            "--bam",
            input.to_str().unwrap(),
            "--out",
            out.to_str().unwrap(),
            "--filtered-out",
            rejected.to_str().unwrap(),
            "--metrics",
            metrics.to_str().unwrap(),
            "--shift",
            "-1000",
            "0",
            "--format",
            "fragments-bed",
        ])
        .into_command() else {
            unreachable!()
        };
        assert!(run(args).is_err());
        assert_eq!(std::fs::read(&out).unwrap(), before_passed);
        assert_eq!(std::fs::read(&rejected).unwrap(), before_rejected);
        assert_eq!(std::fs::read(&metrics).unwrap(), before_metrics);
    }
}
