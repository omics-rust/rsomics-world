use crate::{
    alignments::{self, CountProfile},
    bigwig::{BwReader, StatsMode},
    cli::SummaryArgs,
    execute::ordered_map,
    grid::{self, DictionaryMapping, DictionaryProfile},
    mask::MaskIndex,
    model::*,
    output::{OutputSet, npz},
};
use rsomics_common::Result;
use serde_json::{Value, json};
use std::io::{BufWriter, Read, Seek, Write};

const SUMMARY_BUDGET: usize = 64 * 1024 * 1024;

struct RowSpool {
    values: BufWriter<std::fs::File>,
    raw: Option<BufWriter<std::fs::File>>,
    rows: usize,
    columns: usize,
}
impl RowSpool {
    fn new(context: &RunContext, labels: &[String], raw: bool) -> Result<Self> {
        let mut raw = if raw {
            Some(BufWriter::new(tempfile::tempfile_in(&context.scratch)?))
        } else {
            None
        };
        if let Some(out) = &mut raw {
            write!(out, "#'chr'\t'start'\t'end'")?;
            for label in labels {
                write!(out, "\t'{label}'")?;
            }
            writeln!(out)?;
        }
        Ok(Self {
            values: BufWriter::new(tempfile::tempfile_in(&context.scratch)?),
            raw,
            rows: 0,
            columns: labels.len(),
        })
    }
    fn push(&mut self, row: DataRow) -> Result<()> {
        for value in &row.values {
            self.values.write_all(&value.to_le_bytes())?;
        }
        if let Some(out) = &mut self.raw {
            write!(
                out,
                "{}\t{}\t{}",
                row.chrom,
                row.starts
                    .iter()
                    .map(u32::to_string)
                    .collect::<Vec<_>>()
                    .join(","),
                row.ends
                    .iter()
                    .map(u32::to_string)
                    .collect::<Vec<_>>()
                    .join(",")
            )?;
            for value in row.values {
                write!(out, "\t{}", float_text(value))?;
            }
            writeln!(out)?;
        }
        self.rows = self
            .rows
            .checked_add(1)
            .ok_or_else(|| invalid("summary row count overflow"))?;
        Ok(())
    }
    fn finish(&mut self) -> Result<()> {
        self.values.flush()?;
        if let Some(raw) = &mut self.raw {
            raw.flush()?;
        }
        Ok(())
    }
    fn factors(&mut self) -> Result<Vec<f64>> {
        if self.rows > SUMMARY_BUDGET / 8 {
            return Err(invalid(
                "exact summary scaling factors exceed the private 64 MiB selection budget; omit --scaling-factors for this shape",
            ));
        }
        let mut factors = Vec::with_capacity(self.columns);
        let mut row = vec![0.0f64; self.columns];
        for sample in 0..self.columns {
            self.values.get_mut().rewind()?;
            let mut logs = Vec::with_capacity(self.rows);
            for _ in 0..self.rows {
                for value in &mut row {
                    let mut bytes = [0; 8];
                    self.values.get_mut().read_exact(&mut bytes)?;
                    *value = f64::from_le_bytes(bytes);
                }
                if row.iter().all(|v| *v > 0.0) {
                    let mean = row.iter().map(|v| v.ln()).sum::<f64>() / self.columns as f64;
                    logs.push(row[sample].ln() - mean);
                }
            }
            let median = if logs.is_empty() {
                f64::NAN
            } else {
                alignments::geometry::median(&mut logs)?
            };
            factors.push((-median).exp());
        }
        Ok(factors)
    }
}
pub(crate) fn run(args: SummaryArgs, regions_mode: bool) -> Result<Value> {
    if args.bin_size == 0 {
        return Err(invalid("bin size must be positive"));
    }
    if regions_mode && args.regions.is_empty() {
        return Err(invalid("summarize regions requires --regions"));
    }
    if !regions_mode && !args.regions.is_empty() {
        return Err(invalid("--regions is only valid in summarize regions"));
    }
    let context = RunContext::new(args.execution.threads)?;
    let row_bytes = args
        .files
        .len()
        .checked_mul(16)
        .and_then(|n| n.checked_add(512))
        .ok_or_else(|| invalid("summary row shape overflow"))?;
    let block_rows = (SUMMARY_BUDGET / context.max_inflight.max(1) / row_bytes).min(4096);
    if block_rows == 0 {
        return Err(invalid(
            "summary row/worker shape exceeds the private 64 MiB execution budget",
        ));
    }
    let mask = MaskIndex::load(&args.execution.blacklist)?;
    let labels = super::labels(&args.files, &args.labels, args.smart_labels)?;
    let sources = if args.input == InputKind::Bigwig {
        args.files
            .iter()
            .map(|p| BwReader::open(p))
            .collect::<Result<Vec<_>>>()?
    } else {
        Vec::new()
    };
    let mut mapped = Vec::new();
    let dictionaries = if args.input == InputKind::Bam {
        args.files
            .iter()
            .map(|path| {
                super::bam_index(path)?;
                alignments::dictionary(path, context.threads).map(|(d, n)| {
                    mapped.push(n);
                    d
                })
            })
            .collect::<Result<Vec<_>>>()?
    } else {
        sources.iter().map(|r| r.dictionary.clone()).collect()
    };
    let profile = if args.input == InputKind::Bam {
        Some(CountProfile::resolve(
            &args.files[0],
            &args.bam_options,
            None,
            &mask,
            &context,
        )?)
    } else {
        None
    };
    let mut mapping = grid::reconcile(
        &dictionaries,
        if args.input == InputKind::Bam {
            DictionaryProfile::BamCount
        } else {
            DictionaryProfile::BwSummary
        },
    )?;
    if !args.chromosomes_to_skip.is_empty() {
        let kept = mapping
            .dictionary
            .iter()
            .enumerate()
            .filter(|(_, c)| !args.chromosomes_to_skip.contains(&c.name))
            .map(|(i, _)| i)
            .collect::<Vec<_>>();
        mapping.dictionary = kept
            .iter()
            .map(|&i| mapping.dictionary[i].clone())
            .collect();
        for names in &mut mapping.names {
            *names = kept.iter().map(|&i| names[i].clone()).collect();
        }
    }
    let genome = mapping
        .dictionary
        .iter()
        .map(|c| u64::from(c.len))
        .sum::<u64>();
    let chunk = if args.input == InputKind::Bam {
        if let Some(size) = args.genome_chunk_size {
            size
        } else {
            let step = u64::from(
                args.bin_size
                    .checked_add(args.distance_between_bins)
                    .ok_or_else(|| invalid("summary step overflow"))?,
            );
            let max = mapped.iter().copied().max().unwrap_or(0);
            if max == 0 {
                args.bin_size.saturating_mul(10000)
            } else {
                ((step as f64 * 1000.0 / (max as f64 / genome as f64 * args.files.len() as f64))
                    as u32)
                    .max(step as u32)
                    .max(args.bin_size)
            }
        }
    } else {
        let chunk = genome.max(1_000_000).min(u64::from(u32::MAX)) as u32;
        chunk - chunk % args.bin_size
    };
    let tasks = grid::plan_tasks(
        &mapping.dictionary,
        chunk,
        args.execution.region.as_deref(),
        &mask,
        Some(args.bin_size),
    )?;
    let contiguous_bam =
        !regions_mode && args.input == InputKind::Bam && args.distance_between_bins == 0;
    if contiguous_bam {
        let bytes_per_bin = args
            .files
            .len()
            .checked_mul(16)
            .and_then(|n| n.checked_add(128))
            .ok_or_else(|| invalid("BAM summary task shape overflow"))?;
        let inflight = context.max_inflight.min(tasks.len()).max(1);
        for task in &tasks {
            let bins = (task.span.end - task.grid_origin).div_ceil(args.bin_size) as usize;
            if bins
                .checked_mul(bytes_per_bin)
                .and_then(|n| n.checked_mul(inflight))
                .is_none_or(|n| n > SUMMARY_BUDGET)
            {
                return Err(invalid(format!(
                    "BAM contiguous summary task {}:{}-{} has {bins} bins and exceeds the private 64 MiB task/in-flight allocation budget; choose explicit --genome-chunk-size or fewer --threads",
                    mapping.dictionary[task.span.chrom].name, task.span.start, task.span.end
                )));
            }
        }
    }
    let mut input_statistics = Vec::new();
    if args.input == InputKind::Bigwig && args.execution.report.is_some() {
        let task = &tasks[0];
        let end = task.span.start.saturating_add(10000).min(task.span.end);
        let number = |v: f64| {
            if v.is_finite() {
                json!(v)
            } else {
                json!({"nonfinite":if v.is_nan(){"nan"}else if v.is_sign_positive(){"inf"}else{"-inf"}})
            }
        };
        for (sample, source) in sources.iter().enumerate() {
            let mut reader = source.reopen()?;
            let chrom = &mapping.names[sample][task.span.chrom];
            let approximate =
                reader.mean(chrom, task.span.start, end, StatsMode::Approximate356)?;
            let exact = reader.mean(chrom, task.span.start, end, StatsMode::Exact)?;
            input_statistics.push(json!({"path":source.path,"chromosome":chrom,"start":task.span.start,"end":end,"zoom_reduction":reader.selected_zoom(end-task.span.start),"default":number(approximate),"exact":number(exact)}));
        }
    }
    let mut outputs = vec![args.out.clone()];
    let raw = args.raw_counts.as_ref().map(|p| {
        outputs.push(p.clone());
        outputs.len() - 1
    });
    let scaling = args.scaling_factors.as_ref().map(|p| {
        outputs.push(p.clone());
        outputs.len() - 1
    });
    let report_index = args.execution.report.as_ref().map(|p| {
        outputs.push(p.clone());
        outputs.len() - 1
    });
    let mut inputs = args.files.clone();
    inputs.extend(args.regions.clone());
    inputs.extend(args.execution.blacklist.clone());
    let mut staged = OutputSet::stage(&outputs, &inputs)?;
    let mut spool = RowSpool::new(&context, &labels, raw.is_some())?;
    if regions_mode {
        let loaded = crate::regions::load(&args.regions, &args.annotation)?;
        for task in &tasks {
            let name = &mapping.dictionary[task.span.chrom].name;
            let ids = loaded
                .by_chrom
                .get(name)
                .or_else(|| loaded.by_chrom.get(&grid::annotation_alias(name)));
            let Some(ids) = ids else {
                continue;
            };
            for ids in ids.chunks(block_rows) {
                let selected = ids
                    .iter()
                    .filter_map(|&i| {
                        let region = &loaded.regions[i];
                        let start = region.exons[0].start;
                        (start >= task.span.start && start < task.span.end).then(|| {
                            let mut region = region.clone();
                            region.chrom = name.clone();
                            region
                        })
                    })
                    .collect::<Vec<_>>();
                if selected.is_empty() {
                    continue;
                }
                if let Some(profile) = &profile {
                    let columns = ordered_map(&args.files, &context, |path| {
                        alignments::region_counts(path, &selected, profile, &mask)
                    })?;
                    for (i, region) in selected.iter().enumerate() {
                        spool.push(region_row(region, columns.iter().map(|c| c[i]).collect()))?;
                    }
                } else {
                    let rows = ordered_map(
                        &selected.chunks(32).collect::<Vec<_>>(),
                        &context,
                        |regions| {
                            let mut readers = sources
                                .iter()
                                .map(BwReader::reopen)
                                .collect::<Result<Vec<_>>>()?;
                            regions
                                .iter()
                                .map(|region| {
                                    let mut values = Vec::with_capacity(readers.len());
                                    for (sample, reader) in readers.iter_mut().enumerate() {
                                        let mut sum = 0.0;
                                        let mut length = 0u64;
                                        for exon in &region.exons {
                                            let width = exon.end - exon.start;
                                            sum += reader.mean(
                                                &mapping.names[sample][task.span.chrom],
                                                exon.start,
                                                exon.end,
                                                StatsMode::Approximate356,
                                            )? * f64::from(width);
                                            length += u64::from(width);
                                        }
                                        values.push(sum / length as f64);
                                    }
                                    let mut row = region_row(region, values);
                                    row.chrom = mapping
                                        .names
                                        .last()
                                        .ok_or_else(|| invalid("summary has no samples"))?
                                        [task.span.chrom]
                                        .clone();
                                    Ok(row)
                                })
                                .collect::<Result<Vec<_>>>()
                        },
                    )?;
                    for row in rows.into_iter().flatten() {
                        spool.push(row)?;
                    }
                }
            }
        }
    } else if contiguous_bam {
        let profile = profile
            .as_ref()
            .ok_or_else(|| invalid("missing BAM operation geometry"))?;
        for batch in tasks.chunks(context.max_inflight) {
            let results = ordered_map(batch, &context, |task| {
                args.files
                    .iter()
                    .enumerate()
                    .map(|(sample, path)| {
                        Ok(alignments::count_task(
                            path,
                            &mapping.names[sample][task.span.chrom],
                            task,
                            args.bin_size,
                            profile,
                            &mask,
                        )?
                        .values)
                    })
                    .collect::<Result<Vec<_>>>()
            })?;
            for (task, columns) in batch.iter().zip(results) {
                let mut row_index = 0;
                for windows in grid::window_blocks(task, args.bin_size, 0, false, block_rows)? {
                    for window in windows {
                        spool.push(DataRow {
                            chrom: mapping.dictionary[window.chrom].name.clone(),
                            starts: vec![window.start],
                            ends: vec![window.end],
                            name: String::new(),
                            score: "0".into(),
                            strand: '.',
                            group: 0,
                            source_order: 0,
                            values: columns.iter().map(|c| c[row_index]).collect(),
                        })?;
                        row_index += 1;
                    }
                }
            }
        }
    } else {
        let mut pending = Vec::with_capacity(context.max_inflight);
        for task in &tasks {
            for windows in grid::window_blocks(
                task,
                args.bin_size,
                args.distance_between_bins,
                args.input == InputKind::Bam && args.distance_between_bins > 0,
                block_rows,
            )? {
                pending.push(windows);
                if pending.len() == context.max_inflight {
                    write_bins(
                        &pending,
                        &args,
                        &mapping,
                        profile.as_ref(),
                        &sources,
                        &mask,
                        &context,
                        &mut spool,
                    )?;
                    pending.clear();
                }
            }
        }
        if !pending.is_empty() {
            write_bins(
                &pending,
                &args,
                &mapping,
                profile.as_ref(),
                &sources,
                &mask,
                &context,
                &mut spool,
            )?;
        }
    }
    if spool.rows == 0 {
        return Err(invalid("no summary rows remain"));
    }
    spool.finish()?;
    if let Some(index) = scaling {
        if args.input != InputKind::Bam {
            return Err(invalid("scaling factors output is BAM-summary only"));
        }
        let factors = spool.factors()?;
        let mut out = BufWriter::new(staged.writer(index));
        writeln!(out, "sample\tscalingFactor")?;
        for (label, factor) in labels.iter().zip(factors) {
            writeln!(out, "{label}\t{factor:6.4}")?;
        }
        out.flush()?;
    }
    spool.values.get_mut().rewind()?;
    npz::write(
        staged.writer(0),
        spool.values.get_mut(),
        spool.rows,
        &labels,
    )?;
    if let Some(index) = raw {
        let raw = spool
            .raw
            .as_mut()
            .ok_or_else(|| invalid("missing raw summary spool"))?;
        raw.get_mut().rewind()?;
        std::io::copy(raw.get_mut(), staged.writer(index))?;
    }
    let report = json!({"operation":"summarize","input_kind":args.input,"mode":if regions_mode{"regions"}else{"bins"},"rows":spool.rows,"samples":labels,"task_chunk_size":chunk,"statistics":if args.input==InputKind::Bigwig{"approximate356"}else{"read counts"},"input_statistics":input_statistics,"threads":context.threads.get(),"numeric_spool_bytes":spool.rows as u64 * labels.len() as u64 * 8,"row_block_limit":block_rows,"execution_budget_bytes":SUMMARY_BUDGET});
    if let Some(index) = report_index {
        serde_json::to_writer_pretty(staged.writer(index), &report)
            .map_err(|e| invalid(e.to_string()))?;
        staged.writer(index).write_all(b"\n")?;
    }
    staged.commit()?;
    Ok(report)
}
#[allow(clippy::too_many_arguments)]
fn write_bins(
    blocks: &[Vec<Span>],
    args: &SummaryArgs,
    mapping: &DictionaryMapping,
    profile: Option<&CountProfile>,
    sources: &[BwReader],
    mask: &MaskIndex,
    context: &RunContext,
    spool: &mut RowSpool,
) -> Result<()> {
    let rows = ordered_map(blocks, context, |windows| {
        let mut columns = Vec::with_capacity(args.files.len());
        for (sample, path) in args.files.iter().enumerate() {
            if let Some(profile) = profile {
                let regions = windows
                    .iter()
                    .map(|w| Region {
                        row_id: 0,
                        chrom: mapping.names[sample][w.chrom].clone(),
                        exons: std::iter::once(w.start..w.end).collect(),
                        name: String::new(),
                        score: "0".into(),
                        strand: '.',
                        group: 0,
                        source_order: 0,
                    })
                    .collect::<Vec<_>>();
                columns.push(alignments::region_counts(path, &regions, profile, mask)?);
            } else {
                let mut reader = sources[sample].reopen()?;
                columns.push(
                    windows
                        .iter()
                        .map(|w| {
                            reader.mean(
                                &mapping.names[sample][w.chrom],
                                w.start,
                                w.end,
                                StatsMode::Approximate356,
                            )
                        })
                        .collect::<Result<Vec<_>>>()?,
                );
            }
        }
        windows
            .iter()
            .enumerate()
            .map(|(i, w)| {
                Ok(DataRow {
                    chrom: if args.input == InputKind::Bigwig {
                        mapping
                            .names
                            .last()
                            .ok_or_else(|| invalid("summary has no samples"))?[w.chrom]
                            .clone()
                    } else {
                        mapping.dictionary[w.chrom].name.clone()
                    },
                    starts: vec![w.start],
                    ends: vec![w.end],
                    name: String::new(),
                    score: "0".into(),
                    strand: '.',
                    group: 0,
                    source_order: 0,
                    values: columns.iter().map(|c| c[i]).collect(),
                })
            })
            .collect::<Result<Vec<_>>>()
    })?;
    for row in rows.into_iter().flatten() {
        spool.push(row)?;
    }
    Ok(())
}
fn region_row(region: &Region, values: Vec<f64>) -> DataRow {
    DataRow {
        chrom: region.chrom.clone(),
        starts: region.exons.iter().map(|r| r.start).collect(),
        ends: region.exons.iter().map(|r| r.end).collect(),
        name: region.name.clone(),
        score: region.score.clone(),
        strand: region.strand,
        group: region.group,
        source_order: region.source_order,
        values,
    }
}
fn float_text(value: f64) -> String {
    if value.is_nan() {
        "nan".into()
    } else if value == f64::INFINITY {
        "inf".into()
    } else if value == f64::NEG_INFINITY {
        "-inf".into()
    } else if value.fract() == 0.0 {
        format!("{value:.1}")
    } else {
        value.to_string()
    }
}
