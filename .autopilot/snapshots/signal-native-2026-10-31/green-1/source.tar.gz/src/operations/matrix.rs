use crate::{
    bigwig::BwReader,
    cli::MatrixArgs,
    mask::MaskIndex,
    model::{
        DataRow, MatrixData, Reducer, RefPoint, Region, RunContext, SortRegions, SortUsing, invalid,
    },
    output::{OutputSet, matrix as writer},
    regions::{
        self,
        windows::{self, Geometry, WindowPlan},
    },
};
use rsomics_common::{Context, Result};
use serde_json::{Value, json};
use std::{
    cmp::Ordering,
    io::{Seek, Write},
    ops::Range,
};

pub(crate) fn run(args: MatrixArgs, scale_mode: bool) -> Result<Value> {
    if args.bigwig.is_empty() {
        return Err(invalid("matrix requires at least one bigWig"));
    }
    if !args.scale.is_finite()
        || args.min_threshold.is_some_and(|v| !v.is_finite())
        || args.max_threshold.is_some_and(|v| !v.is_finite())
    {
        return Err(invalid("matrix scale and thresholds must be finite"));
    }
    if args.execution.region.is_some() {
        return Err(invalid("matrix does not accept --region"));
    }
    if args
        .sort_using_samples
        .iter()
        .any(|n| *n == 0 || *n > args.bigwig.len())
    {
        return Err(invalid(
            "sort-using-samples indices must be between 1 and the sample count",
        ));
    }
    let geometry = Geometry::new(&args, scale_mode)?;
    let width = geometry.columns()?;
    let columns = width
        .checked_mul(args.bigwig.len())
        .ok_or_else(|| invalid("matrix shape overflow"))?;
    let row_bytes = columns
        .checked_mul(8)
        .ok_or_else(|| invalid("matrix row byte count overflow"))?;
    if row_bytes > 64 * 1024 * 1024 {
        return Err(invalid(
            "matrix row exceeds the private 64 MiB execution budget",
        ));
    }
    let labels = super::labels(&args.bigwig, &args.labels, true)?;
    let mut outputs = vec![args.out.clone()];
    let tsv = args.matrix_tsv.as_ref().map(|p| {
        outputs.push(p.clone());
        outputs.len() - 1
    });
    let bed = args.sorted_regions.as_ref().map(|p| {
        outputs.push(p.clone());
        outputs.len() - 1
    });
    let report = args.execution.report.as_ref().map(|p| {
        outputs.push(p.clone());
        outputs.len() - 1
    });
    let mut inputs = args.bigwig.clone();
    inputs.extend(args.regions.clone());
    inputs.extend(args.execution.blacklist.clone());
    let mut staged = OutputSet::stage(&outputs, &inputs)?;
    let context = RunContext::new(args.execution.threads)?;
    let mut spool = tempfile::tempfile_in(&context.scratch)?;
    let mut regions = regions::load(&args.regions, &args.annotation)?;
    let mask = MaskIndex::load(&args.execution.blacklist)?;
    let sources = args
        .bigwig
        .iter()
        .map(|p| BwReader::open(p))
        .collect::<Result<Vec<_>>>()?;
    let population = crate::grid::reconcile(
        &sources
            .iter()
            .map(|s| s.dictionary.clone())
            .collect::<Vec<_>>(),
        crate::grid::DictionaryProfile::BwSummary,
    )?
    .dictionary;
    let mut rows = Vec::new();
    let mut offsets = Vec::new();
    let mut keys = Vec::new();
    let mut excluded_blacklist = 0usize;
    let mut excluded_missing = 0usize;
    let mut short = 0usize;
    let mut threshold = 0usize;
    let mut zero = 0usize;
    let mut missing_sample_rows = 0usize;
    let mut eligible = Vec::new();
    for region in &mut regions.regions {
        let start = region
            .exons
            .first()
            .ok_or_else(|| invalid("region has no exons"))?
            .start;
        let alternate = windows::alternate_chrom(&region.chrom);
        let owner = population
            .iter()
            .find(|c| c.name == region.chrom)
            .or_else(|| population.iter().find(|c| c.name == alternate));
        let Some(owner) = owner else {
            excluded_missing += 1;
            if !args.quiet {
                eprintln!(
                    "Warning: region {} has no matching signal chromosome",
                    region.name
                );
            }
            continue;
        };
        if start >= owner.len {
            excluded_missing += 1;
            continue;
        }
        region.chrom = owner.name.clone();
        // mapReduce's trimOverlap ownership is by feature start, including blacklist subranges.
        if mask.contains_start(&region.chrom, start) {
            excluded_blacklist += 1;
            continue;
        }
        eligible.push(region.clone());
    }
    let batch_size = context
        .max_inflight
        .saturating_mul(32)
        .min((64 * 1024 * 1024 / row_bytes).max(1))
        .max(1);
    for batch in eligible.chunks(batch_size) {
        let task_size = (batch.len() / context.threads.get()).clamp(1, 32);
        let tasks: Vec<_> = batch.chunks(task_size).collect();
        let computed = crate::execute::ordered_map(&tasks, &context, |regions| {
            let mut readers = sources
                .iter()
                .map(BwReader::reopen)
                .collect::<Result<Vec<_>>>()?;
            regions
                .iter()
                .map(|region| compute_region(region, geometry, width, columns, &args, &mut readers))
                .collect::<Result<Vec<_>>>()
        })?;
        for (region, (mut values, is_short, missing)) in
            batch.iter().zip(computed.into_iter().flatten())
        {
            missing_sample_rows += missing;
            if is_short {
                short += 1;
                if !args.quiet {
                    eprintln!(
                        "Warning: region {} has a body shorter than one bin after unscaled ends; retaining an empty row",
                        region.name
                    );
                }
            }
            let has_nan = values.iter().any(|v| v.is_nan());
            if !has_nan
                && (args
                    .min_threshold
                    .is_some_and(|t| values.iter().copied().fold(f64::INFINITY, f64::min) <= t)
                    || args.max_threshold.is_some_and(|t| {
                        values.iter().copied().fold(f64::NEG_INFINITY, f64::max) >= t
                    }))
            {
                threshold += 1;
                continue;
            }
            for v in &mut values {
                *v *= args.scale;
            }
            let mean = crate::reduce::reduce(&values, Reducer::Mean, true);
            if args.skip_zeros && (!mean.is_finite() || mean == 0.0) {
                zero += 1;
                continue;
            }
            keys.push(sort_key(region, &values, width, &args));
            offsets.push(spool.stream_position()?);
            for value in values {
                spool.write_all(&value.to_le_bytes())?;
            }
            rows.push(DataRow {
                chrom: region.chrom.clone(),
                starts: region.exons.iter().map(|e| e.start).collect(),
                ends: region.exons.iter().map(|e| e.end).collect(),
                name: region.name.clone(),
                score: region.score.clone(),
                strand: region.strand,
                group: region.group,
                source_order: region.source_order,
                values: vec![],
            });
        }
    }
    spool.flush()?;
    let spool_bytes = spool.stream_position()?;
    if rows.is_empty() {
        return Err(invalid(
            "no matrix regions remain after source population and row filters",
        ));
    }
    let mut order: Vec<_> = (0..rows.len()).collect();
    order.sort_by(|a, b| {
        let group = rows[*a].group.cmp(&rows[*b].group);
        if group != Ordering::Equal {
            return group;
        }
        if args.sort_regions == SortRegions::No {
            return rows[*a]
                .chrom
                .cmp(&rows[*b].chrom)
                .then_with(|| rows[*a].starts.cmp(&rows[*b].starts))
                .then_with(|| rows[*a].ends.cmp(&rows[*b].ends))
                .then_with(|| rows[*a].name.cmp(&rows[*b].name))
                .then_with(|| rows[*a].source_order.cmp(&rows[*b].source_order));
        }
        if matches!(
            args.sort_regions,
            SortRegions::Ascend | SortRegions::Descend
        ) {
            let key = nan_last(keys[*a], keys[*b]);
            let key = if args.sort_regions == SortRegions::Descend {
                key.reverse()
            } else {
                key
            };
            if key != Ordering::Equal {
                return key;
            }
        }
        rows[*a].source_order.cmp(&rows[*b].source_order)
    });
    let mut ordered = Vec::with_capacity(rows.len());
    let mut ordered_offsets = Vec::with_capacity(rows.len());
    let mut row_slots: Vec<_> = rows.into_iter().map(Some).collect();
    for index in order {
        ordered.push(
            row_slots[index]
                .take()
                .ok_or_else(|| invalid("matrix sort repeated a row"))?,
        );
        ordered_offsets.push(offsets[index]);
    }
    let mut group_labels = Vec::new();
    let mut group_boundaries = vec![0];
    let mut previous = None;
    for (i, row) in ordered.iter_mut().enumerate() {
        if previous != Some(row.group) {
            if previous.is_some() {
                group_boundaries.push(i);
            }
            previous = Some(row.group);
            group_labels.push(regions.group_labels[row.group].clone());
        }
        row.group = group_labels.len() - 1;
    }
    group_boundaries.push(ordered.len());
    let parameters = parameters(&args, geometry);
    let data = MatrixData {
        rows: ordered,
        labels,
        group_labels,
        sample_boundaries: (0..=args.bigwig.len()).map(|n| n * width).collect(),
        group_boundaries,
        parameters,
    };
    writer::gzip(staged.writer(0), &data, &mut spool, &ordered_offsets)?;
    if let Some(i) = tsv {
        writer::tsv(staged.writer(i), &data, &mut spool, &ordered_offsets)?;
    }
    if let Some(i) = bed {
        writer::sorted_bed(staged.writer(i), &data)?;
    }
    let result = json!({"operation":if scale_mode {"matrix-scale"} else {"matrix-reference"},"rows":data.rows.len(),"columns":columns,"sample_boundaries":data.sample_boundaries,"group_boundaries":data.group_boundaries,"sample_labels":data.labels,"group_labels":data.group_labels,"excluded_missing_chromosome_or_start":excluded_missing,"excluded_blacklist":excluded_blacklist,"short_body_rows":short,"threshold_exclusions":threshold,"zero_exclusions":zero,"missing_sample_rows":missing_sample_rows,"row_spool_bytes":spool_bytes,"threads":context.threads.get()});
    if let Some(i) = report {
        serde_json::to_writer_pretty(staged.writer(i), &result)
            .map_err(|e| invalid(format!("writing matrix report: {e}")))?;
        staged.writer(i).flush()?;
    }
    staged.commit()?;
    Ok(result)
}

fn compute_region(
    region: &Region,
    geometry: Geometry,
    width: usize,
    columns: usize,
    args: &MatrixArgs,
    sources: &mut [BwReader],
) -> Result<(Vec<f64>, bool, usize)> {
    let plan = windows::plan(region, geometry)?;
    let mut values = Vec::with_capacity(columns);
    let mut missing_samples = 0;
    for source in sources {
        let (mut block, missing) = sample(
            source,
            &region.chrom,
            &plan,
            width,
            args.average_type_bins,
            args.missing_as_zero,
        )
        .rs_with_context(|| format!("matrix region {} on {}", region.name, region.chrom))?;
        missing_samples += usize::from(missing);
        if plan.reverse {
            block.reverse();
        }
        values.extend(block);
    }
    Ok((values, plan.short, missing_samples))
}

fn parameters(args: &MatrixArgs, g: Geometry) -> Value {
    let n = args.bigwig.len();
    let point = if g.body > 0 {
        Value::Null
    } else {
        json!(match g.point {
            RefPoint::Tss => "TSS",
            RefPoint::Tes => "TES",
            RefPoint::Center => "center",
        })
    };
    json!({"upstream":vec![g.before;n],"downstream":vec![g.after;n],"body":vec![g.body;n],"bin size":vec![g.bin;n],"ref point":vec![point;n],"verbose":args.execution.verbose,"bin avg type":format!("{:?}",args.average_type_bins).to_lowercase(),"missing data as zero":args.missing_as_zero,"min threshold":args.min_threshold,"max threshold":args.max_threshold,"scale":args.scale,"skip zeros":args.skip_zeros,"nan after end":args.nan_after_end,"proc number":args.execution.threads.get(),"sort regions":format!("{:?}",args.sort_regions).to_lowercase(),"sort using":if args.sort_using==SortUsing::RegionLength {"region_length".into()} else {format!("{:?}",args.sort_using).to_lowercase()},"unscaled 5 prime":vec![g.u5;n],"unscaled 3 prime":vec![g.u3;n]})
}
fn nan_last(a: f64, b: f64) -> Ordering {
    match (a.is_nan(), b.is_nan()) {
        (true, true) => Ordering::Equal,
        (true, false) => Ordering::Greater,
        (false, true) => Ordering::Less,
        _ => a.total_cmp(&b),
    }
}
fn sort_key(region: &Region, values: &[f64], width: usize, args: &MatrixArgs) -> f64 {
    if args.sort_using == SortUsing::RegionLength {
        return region
            .exons
            .iter()
            .map(|e| f64::from(e.end - e.start))
            .sum();
    }
    let chosen: Vec<_> = if args.sort_using_samples.is_empty() {
        values.to_vec()
    } else {
        args.sort_using_samples
            .iter()
            .flat_map(|n| values[(*n - 1) * width..*n * width].iter().copied())
            .collect()
    };
    let reducer = match args.sort_using {
        SortUsing::Mean => Reducer::Mean,
        SortUsing::Median => Reducer::Median,
        SortUsing::Min => Reducer::Min,
        SortUsing::Max => Reducer::Max,
        SortUsing::Sum => Reducer::Sum,
        SortUsing::RegionLength => unreachable!(),
    };
    if reducer == Reducer::Sum && chosen.iter().all(|v| !v.is_finite()) {
        0.0
    } else {
        crate::reduce::reduce(&chosen, reducer, true)
    }
}

fn sample(
    source: &mut BwReader,
    chrom: &str,
    plan: &WindowPlan,
    width: usize,
    reducer: Reducer,
    zero: bool,
) -> Result<(Vec<f64>, bool)> {
    if plan.short {
        return Ok((vec![if zero { 0.0 } else { f64::NAN }; width], false));
    }
    let alternate = windows::alternate_chrom(chrom);
    let mapping = source
        .dictionary
        .iter()
        .find(|c| c.name == chrom)
        .or_else(|| source.dictionary.iter().find(|c| c.name == alternate))
        .map(|c| (c.name.clone(), c.len));
    let missing = mapping.is_none();
    let mut output = vec![f64::NAN; plan.pad_left];
    let mut zone_offset = 0u64;
    for zone in &plan.zones {
        if zone.bins == 0 {
            continue;
        }
        let size = windows::length(&zone.blocks);
        let step = size as f64 / zone.bins as f64;
        for i in 0..zone.bins {
            let start = (zone_offset as f64 + i as f64 * step) as u64 - zone_offset;
            let end = if i + 1 == zone.bins {
                size
            } else {
                (zone_offset as f64 + (i + 1) as f64 * step) as u64 - zone_offset
            };
            let blocks = windows::slice(&zone.blocks, start, end.max(start + 1).min(size));
            output.push(bin(source, mapping.as_ref(), &blocks, reducer, zero)?);
        }
        zone_offset += size;
    }
    output.extend(std::iter::repeat_n(f64::NAN, plan.pad_right));
    if output.len() != width {
        return Err(invalid(format!(
            "matrix window produced {} bins, expected {width}",
            output.len()
        )));
    }
    Ok((output, missing))
}
fn bin(
    source: &mut BwReader,
    mapping: Option<&(String, u32)>,
    blocks: &[Range<i64>],
    reducer: Reducer,
    zero: bool,
) -> Result<f64> {
    let mut pieces = Vec::new();
    for block in blocks {
        let mut cursor = block.start;
        while cursor < block.end {
            let end = (cursor + 1_048_576).min(block.end);
            let mut covered = 0u64;
            if let Some((chrom, len)) = mapping {
                let s = cursor.max(0).min(i64::from(*len)) as u32;
                let e = end.max(0).min(i64::from(*len)) as u32;
                if s < e {
                    for run in source.full_runs(chrom, s, e)? {
                        let length = u64::from(run.end.min(e).saturating_sub(run.start.max(s)));
                        if length == 0 {
                            continue;
                        }
                        covered += length;
                        let value = f64::from(run.value);
                        if value.is_finite() {
                            pieces.push((value, length));
                        } else if zero && value.is_nan() {
                            pieces.push((0.0, length));
                        }
                    }
                }
            }
            if zero {
                let missing = (end - cursor) as u64 - covered;
                if missing > 0 {
                    pieces.push((0.0, missing));
                }
            }
            if pieces.len() > 4_194_304 {
                return Err(invalid(
                    "matrix bin exceeds private 64 MiB reduction budget",
                ));
            }
            cursor = end;
        }
    }
    Ok(weighted(&mut pieces, reducer))
}
fn weighted(pieces: &mut [(f64, u64)], reducer: Reducer) -> f64 {
    let count: u64 = pieces.iter().map(|p| p.1).sum();
    if count == 0 {
        return f64::NAN;
    }
    let sum = pieces.iter().map(|p| p.0 * p.1 as f64).sum::<f64>();
    match reducer {
        Reducer::Mean => sum / count as f64,
        Reducer::Sum => sum,
        Reducer::Min => pieces.iter().map(|p| p.0).fold(f64::INFINITY, f64::min),
        Reducer::Max => pieces.iter().map(|p| p.0).fold(f64::NEG_INFINITY, f64::max),
        Reducer::Std => {
            let mean = sum / count as f64;
            (pieces
                .iter()
                .map(|p| (p.0 - mean).powi(2) * p.1 as f64)
                .sum::<f64>()
                / count as f64)
                .sqrt()
        }
        Reducer::Median => {
            pieces.sort_by(|a, b| a.0.total_cmp(&b.0));
            let mut at = 0;
            let mut left = None;
            let mut right = None;
            for (v, n) in pieces {
                let next = at + *n;
                if at <= (count - 1) / 2 && next > (count - 1) / 2 {
                    left = Some(*v);
                }
                if at <= count / 2 && next > count / 2 {
                    right = Some(*v);
                }
                at = next;
            }
            match (left, right) {
                (Some(a), Some(b)) => (a + b) / 2.0,
                _ => f64::NAN,
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use clap::Parser;
    use std::{
        fs::File,
        io::{BufRead, BufReader},
    };
    #[test]
    fn weighted_population_reductions() {
        assert_eq!(weighted(&mut [(1.0, 2), (3.0, 2)], Reducer::Median), 2.0);
        assert_eq!(weighted(&mut [(1.0, 2), (3.0, 2)], Reducer::Std), 1.0);
        assert_eq!(weighted(&mut [(1.0, 2), (3.0, 2)], Reducer::Sum), 8.0);
        assert!(weighted(&mut [], Reducer::Sum).is_nan());
    }

    #[test]
    fn retained_matrix_geometry_and_serialization() {
        let root = crate::test_fixtures::fixture_root();
        let dir = tempfile::Builder::new()
            .prefix("signal-matrix-native-")
            .tempdir_in(std::env::temp_dir())
            .unwrap();
        for (name, mode, regions, before, after, signals, extra) in [
            (
                "reference",
                "reference",
                "groups.bed",
                "50",
                "100",
                ["compare-bw.bw", "average.bw"],
                vec![],
            ),
            (
                "scale",
                "scale",
                "groups.bed",
                "50",
                "50",
                ["compare-bw.bw", "average.bw"],
                vec![
                    "--body-length",
                    "200",
                    "--unscaled-5prime",
                    "20",
                    "--unscaled-3prime",
                    "20",
                ],
            ),
            (
                "bed12",
                "reference",
                "exons.bed",
                "50",
                "50",
                ["a.cpm.bw", "b.cpm.bw"],
                vec!["--metagene", "--reference-point", "center"],
            ),
            (
                "gtf",
                "scale",
                "regions.gtf",
                "20",
                "20",
                ["a.cpm.bw", "b.cpm.bw"],
                vec!["--metagene", "--body-length", "200"],
            ),
        ] {
            let output = dir.path().join(format!("{name}.gz"));
            let source: Value = serde_json::from_reader(
                File::open(root.join(format!("calls/matrix-{name}-arrays/observation.json")))
                    .unwrap(),
            )
            .unwrap();
            let mut cli = vec![
                "rsomics-signal".into(),
                "matrix".into(),
                mode.into(),
                "--bigwig".into(),
                root.join("results")
                    .join(signals[0])
                    .to_string_lossy()
                    .into_owned(),
                root.join("results")
                    .join(signals[1])
                    .to_string_lossy()
                    .into_owned(),
                "--regions".into(),
                root.join("inputs/authored")
                    .join(regions)
                    .to_string_lossy()
                    .into_owned(),
                "--out".into(),
                output.to_string_lossy().into_owned(),
                "--before".into(),
                before.into(),
                "--after".into(),
                after.into(),
                "--labels".into(),
            ];
            cli.extend(
                source["result"]["header"]["sample_labels"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .map(|v| v.as_str().unwrap().to_owned()),
            );
            cli.extend(extra.into_iter().map(str::to_owned));
            let crate::cli::Command::Matrix { mode } =
                crate::cli::Cli::try_parse_from(cli).unwrap().into_command()
            else {
                panic!("matrix command");
            };
            let (mut args, scale) = match mode {
                crate::cli::MatrixCommand::Reference(a) => (a, false),
                crate::cli::MatrixCommand::Scale(a) => (a, true),
            };
            args.matrix_tsv = Some(dir.path().join(format!("{name}.tsv")));
            args.sorted_regions = Some(dir.path().join(format!("{name}.bed")));
            let mut parallel = args.clone();
            parallel.execution.threads = std::num::NonZeroUsize::new(4).unwrap();
            parallel.out = dir.path().join(format!("{name}.threads4.gz"));
            parallel.matrix_tsv = None;
            parallel.sorted_regions = None;
            run(args, scale).unwrap();
            run(parallel.clone(), scale).unwrap();
            let bed = std::fs::read(dir.path().join(format!("{name}.bed"))).unwrap();
            assert_eq!(
                bed,
                std::fs::read(root.join(format!("results/matrix-{name}.bed"))).unwrap(),
                "{name} sorted BED source schema"
            );
            let decoder = flate2::read::GzDecoder::new(File::open(&output).unwrap());
            let mut lines = BufReader::new(decoder).lines();
            let first = lines.next().unwrap().unwrap();
            let header: Value = serde_json::from_str(&first[1..]).unwrap();
            for key in [
                "sample_boundaries",
                "group_boundaries",
                "sample_labels",
                "group_labels",
                "body",
                "bin size",
                "upstream",
                "downstream",
                "ref point",
                "unscaled 5 prime",
                "unscaled 3 prime",
            ] {
                assert_eq!(header[key], source["result"]["header"][key], "{name} {key}");
            }
            let rows = lines
                .map(|l| {
                    l.unwrap()
                        .split('\t')
                        .map(str::to_owned)
                        .collect::<Vec<_>>()
                })
                .collect::<Vec<_>>();
            let parallel_rows = BufReader::new(flate2::read::GzDecoder::new(
                File::open(parallel.out).unwrap(),
            ))
            .lines()
            .skip(1)
            .map(|l| {
                l.unwrap()
                    .split('\t')
                    .map(str::to_owned)
                    .collect::<Vec<_>>()
            })
            .collect::<Vec<_>>();
            assert_eq!(rows, parallel_rows, "{name} thread equality");
            let expected = source["result"]["rows"].as_array().unwrap();
            assert_eq!(rows.len(), expected.len(), "{name}");
            for (row, expected) in rows.iter().zip(expected) {
                for i in 0..6 {
                    assert_eq!(
                        row[i],
                        expected["identity"][i].as_str().unwrap(),
                        "{name} identity"
                    );
                }
                for (native, expected) in
                    row[6..].iter().zip(expected["values"].as_array().unwrap())
                {
                    let native = native.parse::<f64>().unwrap();
                    if expected["nonfinite"] == "nan" {
                        assert!(native.is_nan(), "{name}");
                    } else {
                        let expected = expected.as_f64().unwrap();
                        assert!(
                            (native - expected).abs() <= 0.5e-6 + expected.abs() * 1e-12,
                            "{name} {native} != {expected}"
                        );
                    }
                }
            }
        }
        eprintln!(
            "retained matrix correspondence outputs: {}",
            dir.keep().display()
        );
    }
}
