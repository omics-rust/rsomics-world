pub(crate) mod matrix;
pub(crate) mod summarize;
pub(crate) mod tracks;

use crate::model::invalid;
use rsomics_common::Result;
use std::path::{Path, PathBuf};

pub(crate) fn labels(paths: &[PathBuf], provided: &[String], smart: bool) -> Result<Vec<String>> {
    if !provided.is_empty() {
        if paths.len() != provided.len() {
            return Err(invalid("sample label count must equal input count"));
        }
        return Ok(provided.to_vec());
    }
    paths
        .iter()
        .map(|p| {
            let name = if smart { p.file_stem() } else { p.file_name() }
                .ok_or_else(|| invalid(format!("cannot label {}", p.display())))?;
            Ok(name.to_string_lossy().into_owned())
        })
        .collect()
}
pub(crate) fn factors(raw: Option<&str>, n: usize, broadcast: bool) -> Result<Vec<f64>> {
    let mut factors = if let Some(raw) = raw {
        raw.split(':')
            .map(str::parse::<f64>)
            .collect::<std::result::Result<Vec<_>, _>>()?
    } else {
        vec![1.0; n]
    };
    if factors.len() == 1 && broadcast {
        factors.resize(n, factors[0]);
    }
    if factors.len() != n || factors.iter().any(|x| !x.is_finite()) {
        return Err(invalid(
            "scale factors must be finite and match the input count",
        ));
    }
    Ok(factors)
}
pub(crate) fn bam_index(path: &Path) -> Result<()> {
    let appended = PathBuf::from(format!("{}.bai", path.display()));
    let csi = PathBuf::from(format!("{}.csi", path.display()));
    if !appended.is_file() && !path.with_extension("bai").is_file() && !csi.is_file() {
        return Err(invalid(format!("indexed BAM required: {}", path.display())));
    }
    Ok(())
}
