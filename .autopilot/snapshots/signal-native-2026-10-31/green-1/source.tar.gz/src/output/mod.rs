use crate::{
    model::{Dictionary, SignalRun, Span, invalid},
    reduce::format_g,
};
use rsomics_common::{AtomicFile, Result, reject_output_alias};
use std::{
    fs::File,
    io::{BufWriter, Write},
    path::{Path, PathBuf},
};
pub(crate) mod matrix;
pub(crate) mod npz;

pub(crate) struct OutputSet {
    pub files: Vec<AtomicFile>,
}
impl OutputSet {
    pub fn validate(outputs: &[PathBuf], inputs: &[PathBuf]) -> Result<()> {
        for (i, out) in outputs.iter().enumerate() {
            for input in inputs {
                reject_output_alias(out, [input.as_path()])?;
            }
            for other in &outputs[..i] {
                reject_output_alias(out, [other.as_path()])?;
            }
        }
        Ok(())
    }
    pub fn stage(outputs: &[PathBuf], inputs: &[PathBuf]) -> Result<Self> {
        Self::validate(outputs, inputs)?;
        Ok(Self {
            files: outputs.iter().map(AtomicFile::new).collect::<Result<_>>()?,
        })
    }
    pub fn path(&self, i: usize) -> &Path {
        self.files[i].temporary_path()
    }
    pub fn writer(&mut self, i: usize) -> &mut File {
        self.files[i].file_mut()
    }
    pub fn commit(self) -> Result<()> {
        AtomicFile::commit_all(self.files)
    }
}
pub(crate) struct RunSink<W: Write> {
    output: BufWriter<W>,
    dictionary: Dictionary,
    pending: Option<SignalRun>,
    fixed: bool,
}
impl<W: Write> RunSink<W> {
    pub fn new(writer: W, dictionary: &Dictionary, fixed: bool) -> Self {
        Self {
            output: BufWriter::new(writer),
            dictionary: dictionary.clone(),
            pending: None,
            fixed,
        }
    }
    fn write(&mut self, r: SignalRun) -> Result<()> {
        let chrom = self
            .dictionary
            .get(r.span.chrom)
            .ok_or_else(|| invalid("invalid output chromosome ID"))?;
        writeln!(
            self.output,
            "{}\t{}\t{}\t{}",
            chrom.name,
            r.span.start,
            r.span.end,
            format_g(r.value)
        )?;
        Ok(())
    }
    pub fn gap(&mut self) -> Result<()> {
        if let Some(r) = self.pending.take()
            && !r.value.is_nan()
        {
            self.write(r)?;
        }
        Ok(())
    }
    pub fn push(&mut self, span: Span, value: Option<f64>) -> Result<()> {
        let Some(value) = value else {
            return self.gap();
        };
        if self.fixed {
            self.gap()?;
            return self.write(SignalRun { span, value });
        }
        if value.is_nan() {
            return self.gap();
        }
        if let Some(r) = self.pending.as_mut()
            && r.span.chrom == span.chrom
            && r.span.end == span.start
            && r.value == value
        {
            r.span.end = span.end;
            return Ok(());
        }
        self.gap()?;
        self.pending = Some(SignalRun { span, value });
        Ok(())
    }
    pub fn finish(mut self) -> Result<()> {
        self.gap()?;
        self.output.flush()?;
        Ok(())
    }
}
