use crate::model::invalid;
use rsomics_common::Result;
use std::io::{Read, Seek, Write};
use zip::{CompressionMethod, ZipWriter, write::SimpleFileOptions};

fn header(descr: &str, shape: &str) -> Result<Vec<u8>> {
    let text = format!("{{'descr': '{descr}', 'fortran_order': False, 'shape': {shape}, }}");
    let padding = (64 - (10 + text.len() + 1) % 64) % 64;
    let mut output = Vec::from(&b"\x93NUMPY\x01\x00"[..]);
    let length = u16::try_from(text.len() + padding + 1)
        .map_err(|_| invalid("NPY header exceeds version1 bounds"))?;
    output.extend(length.to_le_bytes());
    output.extend(text.as_bytes());
    output.extend(std::iter::repeat_n(b' ', padding));
    output.push(b'\n');
    Ok(output)
}
pub(crate) fn write<W: Write + Seek>(
    output: W,
    mut values: impl Read,
    rows: usize,
    labels: &[String],
) -> Result<()> {
    let bytes = rows
        .checked_mul(labels.len())
        .and_then(|n| n.checked_mul(8))
        .ok_or_else(|| invalid("summary NPY shape overflow"))?;
    let mut archive = ZipWriter::new(output);
    let options = SimpleFileOptions::default()
        .compression_method(CompressionMethod::Deflated)
        .large_file(true);
    archive
        .start_file("matrix.npy", options)
        .map_err(|e| invalid(e.to_string()))?;
    archive.write_all(&header("<f8", &format!("({}, {})", rows, labels.len()))?)?;
    if std::io::copy(&mut values, &mut archive)? != bytes as u64 {
        return Err(invalid(
            "summary numeric spool disagrees with its NPY shape",
        ));
    }
    archive
        .start_file("labels.npy", options)
        .map_err(|e| invalid(e.to_string()))?;
    let width = labels
        .iter()
        .map(|l| l.chars().count())
        .max()
        .unwrap_or(1)
        .max(1);
    archive.write_all(&header(
        &format!("<U{width}"),
        &format!("({},)", labels.len()),
    )?)?;
    for label in labels {
        let mut count = 0;
        for c in label.chars() {
            archive.write_all(&(c as u32).to_le_bytes())?;
            count += 1;
        }
        for _ in count..width {
            archive.write_all(&0u32.to_le_bytes())?;
        }
    }
    archive.finish().map_err(|e| invalid(e.to_string()))?;
    Ok(())
}
