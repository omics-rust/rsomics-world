use crate::model::{MatrixData, invalid};
use flate2::{Compression, write::GzEncoder};
use rsomics_common::Result;
use std::io::{Read, Seek, SeekFrom, Write};

pub(crate) fn row_values(
    spool: &mut (impl Read + Seek),
    offset: u64,
    columns: usize,
) -> Result<Vec<f64>> {
    spool.seek(SeekFrom::Start(offset))?;
    let mut values = Vec::with_capacity(columns);
    for _ in 0..columns {
        let mut b = [0; 8];
        spool.read_exact(&mut b)?;
        values.push(f64::from_le_bytes(b));
    }
    Ok(values)
}
pub(crate) fn gzip(
    writer: impl Write,
    data: &MatrixData,
    spool: &mut (impl Read + Seek),
    offsets: &[u64],
) -> Result<()> {
    let mut out = GzEncoder::new(writer, Compression::default());
    let mut header = data.parameters.clone();
    header["sample_labels"] = serde_json::json!(&data.labels);
    header["group_labels"] = serde_json::json!(&data.group_labels);
    header["sample_boundaries"] = serde_json::json!(&data.sample_boundaries);
    header["group_boundaries"] = serde_json::json!(&data.group_boundaries);
    writeln!(
        out,
        "@{}",
        serde_json::to_string(&header)
            .map_err(|e| invalid(format!("serializing matrix header: {e}")))?
    )?;
    let columns = *data
        .sample_boundaries
        .last()
        .ok_or_else(|| invalid("empty matrix samples"))?;
    for (row, offset) in data.rows.iter().zip(offsets) {
        write!(
            out,
            "{}\t{}\t{}\t{}\t{}\t{}",
            row.chrom,
            joined(&row.starts),
            joined(&row.ends),
            row.name,
            row.score,
            row.strand
        )?;
        for value in row_values(spool, *offset, columns)? {
            write!(out, "\t{}", decimal(value))?;
        }
        writeln!(out)?;
    }
    out.try_finish()?;
    out.finish()?.flush()?;
    Ok(())
}
pub(crate) fn sorted_bed(mut out: impl Write, data: &MatrixData) -> Result<()> {
    writeln!(
        out,
        "#chrom\tstart\tend\tname\tscore\tstrand\tthickStart\tthickEnd\titemRGB\tblockCount\tblockSizes\tblockStart\tdeepTools_group"
    )?;
    for row in &data.rows {
        let start = *row
            .starts
            .first()
            .ok_or_else(|| invalid("empty matrix exon starts"))?;
        let end = *row
            .ends
            .last()
            .ok_or_else(|| invalid("empty matrix exon ends"))?;
        let sizes: Vec<_> = row
            .starts
            .iter()
            .zip(&row.ends)
            .map(|(s, e)| e - s)
            .collect();
        // The pinned save_BED contract subtracts the first digit of its joined starts string.
        let origin = start.to_string().as_bytes()[0] - b'0';
        let relative: Vec<_> = row.starts.iter().map(|s| s - u32::from(origin)).collect();
        let label = data
            .group_labels
            .get(row.group)
            .ok_or_else(|| invalid("invalid matrix group"))?;
        writeln!(
            out,
            "{}\t{start}\t{end}\t{}\t{}\t{}\t{start}\t{end}\t0\t{}\t{}\t{}\t{label}",
            row.chrom,
            row.name,
            row.score,
            row.strand,
            row.starts.len(),
            joined(&sizes),
            joined(&relative)
        )?;
    }
    out.flush()?;
    Ok(())
}
pub(crate) fn tsv(
    mut out: impl Write,
    data: &MatrixData,
    spool: &mut (impl Read + Seek),
    offsets: &[u64],
) -> Result<()> {
    let mut labels: Vec<String> = data
        .group_labels
        .iter()
        .zip(data.group_boundaries.windows(2))
        .map(|(label, b)| format!("{label}:{}", b[1] - b[0]))
        .collect();
    writeln!(out, "#{}", labels.join("\t"))?;
    let scalar = |key: &str| -> Result<String> {
        let v = &data.parameters[key];
        let v = if v.is_array() { &v[0] } else { v };
        Ok(v.as_u64()
            .ok_or_else(|| invalid(format!("invalid matrix parameter {key}")))?
            .to_string())
    };
    writeln!(
        out,
        "#downstream:{}\tupstream:{}\tbody:{}\tbin size:{}\tunscaled 5 prime:{}\tunscaled 3 prime:{}",
        scalar("downstream")?,
        scalar("upstream")?,
        scalar("body")?,
        scalar("bin size")?,
        scalar("unscaled 5 prime")?,
        scalar("unscaled 3 prime")?
    )?;
    for (label, boundaries) in data.labels.iter().zip(data.sample_boundaries.windows(2)) {
        labels.extend(std::iter::repeat_n(
            label.to_owned(),
            boundaries[1] - boundaries[0],
        ));
    }
    writeln!(out, "{}", labels.join("\t"))?;
    let columns = *data
        .sample_boundaries
        .last()
        .ok_or_else(|| invalid("empty matrix samples"))?;
    for offset in offsets {
        let values = row_values(spool, *offset, columns)?;
        for (i, v) in values.into_iter().enumerate() {
            if i > 0 {
                write!(out, "\t")?;
            }
            write!(out, "{}", general4(v))?;
        }
        writeln!(out)?;
    }
    out.flush()?;
    Ok(())
}
fn joined(values: &[u32]) -> String {
    values
        .iter()
        .map(u32::to_string)
        .collect::<Vec<_>>()
        .join(",")
}
fn decimal(value: f64) -> String {
    if value.is_nan() {
        "nan".into()
    } else if value.is_infinite() {
        if value > 0.0 {
            "inf".into()
        } else {
            "-inf".into()
        }
    } else {
        format!("{value:.6}")
    }
}
fn general4(value: f64) -> String {
    if !value.is_finite() {
        return decimal(value);
    }
    if value == 0.0 {
        return if value.is_sign_negative() {
            "-0".into()
        } else {
            "0".into()
        };
    }
    let sci = format!("{value:.3e}");
    let (mantissa, exp) = sci
        .split_once('e')
        .expect("Rust scientific format has exponent");
    let exp: i32 = exp.parse().expect("Rust scientific exponent is numeric");
    if !(-4..4).contains(&exp) {
        return format!(
            "{}e{}{:02}",
            mantissa.trim_end_matches('0').trim_end_matches('.'),
            if exp >= 0 { "+" } else { "-" },
            exp.abs()
        );
    }
    let decimals = (3 - exp).max(0) as usize;
    let raw = format!("{value:.decimals$}");
    if raw.contains('.') {
        raw.trim_end_matches('0').trim_end_matches('.').into()
    } else {
        raw
    }
}
