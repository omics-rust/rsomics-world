use clap::ValueEnum;
use rsomics_common::{Result, RsomicsError};
use serde::Serialize;
use std::num::NonZeroUsize;
use std::ops::Range;
use std::path::PathBuf;

pub(crate) fn invalid(message: impl Into<String>) -> RsomicsError {
    RsomicsError::InvalidInput(message.into())
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
pub(crate) struct Chromosome {
    pub name: String,
    pub len: u32,
}
pub(crate) type Dictionary = Vec<Chromosome>;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
pub(crate) struct Span {
    pub chrom: usize,
    pub start: u32,
    pub end: u32,
}

#[derive(Clone, Copy, Debug)]
pub(crate) struct SignalRun {
    pub span: Span,
    pub value: f64,
}
#[derive(Clone, Debug)]
pub(crate) struct Task {
    pub ordinal: usize,
    pub span: Span,
    pub grid_origin: u32,
}
#[derive(Clone, Debug)]
pub(crate) struct BinValues {
    pub task: Task,
    pub windows: Vec<Span>,
    pub values: Vec<f64>,
}
#[derive(Clone, Debug, Serialize)]
pub(crate) struct Region {
    pub row_id: usize,
    pub chrom: String,
    pub exons: Vec<Range<u32>>,
    pub name: String,
    pub strand: char,
    pub score: String,
    pub group: usize,
    pub source_order: usize,
}
#[derive(Clone, Debug, Default)]
pub(crate) struct RegionSet {
    pub regions: Vec<Region>,
    pub group_labels: Vec<String>,
    pub region_names: std::collections::HashSet<String>,
    pub region_suffixes: std::collections::HashMap<String, usize>,
    pub chromosomes: std::collections::HashSet<String>,
    pub by_chrom: std::collections::HashMap<String, Vec<usize>>,
    pub group_ids: std::collections::HashMap<String, usize>,
    pub group_names: std::collections::HashSet<String>,
    pub group_suffixes: std::collections::HashMap<String, usize>,
}
#[derive(Clone, Debug)]
pub(crate) struct DataRow {
    pub chrom: String,
    pub starts: Vec<u32>,
    pub ends: Vec<u32>,
    pub name: String,
    pub score: String,
    pub strand: char,
    pub group: usize,
    pub source_order: usize,
    pub values: Vec<f64>,
}
#[derive(Clone, Debug)]
pub(crate) struct MatrixData {
    pub rows: Vec<DataRow>,
    pub labels: Vec<String>,
    pub group_labels: Vec<String>,
    pub sample_boundaries: Vec<usize>,
    pub group_boundaries: Vec<usize>,
    pub parameters: serde_json::Value,
}
#[derive(Clone, Debug)]
pub(crate) struct RunContext {
    pub threads: NonZeroUsize,
    pub scratch: PathBuf,
    pub max_inflight: usize,
}
impl RunContext {
    pub fn new(threads: NonZeroUsize) -> Result<Self> {
        let scratch = std::env::temp_dir();
        Ok(Self {
            threads,
            scratch,
            max_inflight: threads.get().saturating_mul(2),
        })
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, ValueEnum, Serialize)]
pub(crate) enum InputKind {
    Bam,
    Bigwig,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, ValueEnum, Serialize)]
pub(crate) enum TrackFormat {
    Bedgraph,
    Bigwig,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, ValueEnum, Serialize)]
pub(crate) enum FilterFormat {
    Bam,
    FragmentsBed,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, ValueEnum, Serialize)]
pub(crate) enum Normalization {
    None,
    #[value(name = "CPM")]
    Cpm,
    #[value(name = "BPM")]
    Bpm,
    #[value(name = "RPKM")]
    Rpkm,
    #[value(name = "RPGC")]
    Rpgc,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, ValueEnum, Serialize)]
pub(crate) enum ScaleMethod {
    #[value(name = "readCount")]
    ReadCount,
    #[value(name = "SES")]
    Ses,
    None,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, ValueEnum, Serialize)]
pub(crate) enum ArithmeticOp {
    Log2,
    Ratio,
    Subtract,
    Add,
    Mean,
    ReciprocalRatio,
    First,
    Second,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, ValueEnum, Serialize)]
pub(crate) enum Reducer {
    Mean,
    Median,
    Min,
    Max,
    Std,
    Sum,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, ValueEnum, Serialize)]
pub(crate) enum RefPoint {
    #[value(name = "TSS")]
    Tss,
    #[value(name = "TES")]
    Tes,
    Center,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, ValueEnum, Serialize)]
pub(crate) enum StrandFilter {
    Forward,
    Reverse,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, ValueEnum, Serialize)]
pub(crate) enum SortRegions {
    Keep,
    No,
    Ascend,
    Descend,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, ValueEnum, Serialize)]
pub(crate) enum SortUsing {
    Mean,
    Median,
    Min,
    Max,
    Sum,
    #[value(name = "region_length")]
    RegionLength,
}
