# Signal implementation provenance

This private owning crate implements the complete adopted first-six workflow. Retired team-owned crates are implementation/test assets, not dependencies or revived installation units. No inherited Cargo.lock modification is copied. This crate's Cargo.lock is newly resolved from published packages.

| Source and pinned revision | Selected assets and destination | Disposition |
| --- | --- | --- |
| rsomics-bam-compare `5fea94174d64d46ae0d35661604a38af2e69ca02` | aligned M/=/X blocks, D/N splitting and once-per-read-bin counting ideas; `alignments`, source-profile `grid` | refactor then merge; reject whole-dictionary-equality and zero-denominator special-case policies contradicted by pinned source |
| rsomics-bam-signal `78921394417918cd2d5c1af8b22a15eb3a31cd9e` | track/run/output path and fixture intent; `operations/tracks` | refactor then merge, not an old CLI wrapper |
| rsomics-bigwig-compare `5ddcf9db6ecd72920fc0fdd19c61dde752bf4ad7`, rsomics-bigwig-average `c6e1f55c7c9ec14d0541d3f2707f8fce6a2ee47f` | arithmetic order and decimal-format/run-emission concepts; `reduce`, `output`, `operations/tracks` | refactor; dense chromosome arrays and defective finalization discarded; general-format exponent threshold reconciled with source |
| rsomics-multibigwig-summary `f78846e2561a59620a148153e5105c1d24fcdd1c`, rsomics-bbi `3d85c7f0892b249277849b90961fa43ff82fa866` | sparse sweep/statistical reduction concepts and original fixtures; private `bigwig` | refactor numerical ideas only; no unchecked retired cursor/decompression parser copied |
| rsomics-multibam-summary `23655983059e7c0367c77909d7d4a41bea3ca6d7` | source task-grid/region/count/export assets; `operations/summarize` | refactor, complete native NPZ contract |
| rsomics-compute-matrix `830d44d98b991dec61f56bf2682851aa1915ec97` | reference/scale reducer/window fixtures; private regions/matrix | refactor; replace singular sample/group model |
| rsomics-alignment-sieve `d65a23fbac4caba831b28b7b89c322129f76950d`, rsomics-atac-shift `6dbd1c30d99ac8233cbeb01a738e789ee22ee5cb` | filters/shift formulas and original inputs; private alignments/filter | refactor; no malformed-row skip or manual byte-splice transform admission |
| rsomics-coverage-core `2dd61704c330fb53267a55b8bec9216559e04d9c` | counting test/benchmark intent | no continuous D/N-spanning production kernel |

Primary semantic oracle: deepTools3.5.6 commit `ea0f68bb4a1587d713dacb3791861308751ef7d0`, MIT. Actual installed-source lifecycle is retained run41192955170/report `9b520a38db6aa2426ded5ebefc7004966b663fd8064b3b4165fff9ffea65adca`. Original report, typed observations and source bytes remain external immutable inputs, not native goldens manufactured by this implementation.

Private codec: published bigtools0.5.8 (MIT), archive `af1b9bbf6596d602e472a23ed5aa5d611fb04f14e7772226fb61c720e806202e`, release `89bf6243a9d733236afe672d2d5245e1ecb4cae3`; actual dependency graph is recorded in this Cargo.lock. No public codec API is introduced.

Narrow writer/statistics primary-source reference: PyPI pybigwig0.3.24 source archive `bf0b6a025a77a1d34c9dc8f134f661780407ffea9c53d18f785e5f1e95b4983f` (75247bytes), including bundled libBigWig `bwWrite.c` read-byte hash `3286f4017562d6428d2225d87b6a0db746046d9ea5e343003a8ac585b7a2a43f` and `bwStats.c` `70e6421d4f23204efcb785d39a7a111929d4a8f0a6d17f232a9c0010eeebaa07`. These source bodies and MIT license are retained at `/Volumes/KIOXIA/Developments/tmp/signal-native-bw-source-20261031.Brnw85/`; no Python/C source was built or executed. Source read informs native approximation compatibility, not a claim of hosted same-file interoperability.

Known native corrections are fixed in the adopted control-plane plan: SIGNAL-356-ARITHMETIC-LOSS, SIGNAL-356-ZERO-TAIL and SIGNAL-356-FILTER-BED-REJECTED. BPM/normalization/aliases/nonfinite and shifted-record metadata are not silently corrected.

Nonempty BBI full-resolution encoding, chromosome tree and full index remain bigtools-owned. Product-private `bigwig/zoom.rs` ports the exact bundled libBigWig buffer/accumulator/level semantics and reuses the retired team's R-tree encoding layout as a bounded zoom-only overlay. It does not decode arbitrary user BBI headers or replace the full codec. `bigwig/source.rs` uses bigtools's public BBIDataSource to preserve dictionary entries with no emitted intervals.

Parent authorized a minimal empty-only format branch `bigwig/empty.rs`, using the retired team's checked header/chromosome-tree/empty-leaf layout because the candidate's zero-section index writer is unsupported. This branch writes no interval/sentinel; its independent-reader/local workflow proof is retained, and pinned-source hosted interop remains required. The adapter explicitly bounds dictionaries to65535 entries before either encoding branch to avoid the candidate single-leaf u16 count truncation.

The source sortedBED first-digit-relative-offset defect is an observed optional-output anomaly, not an adopted additional public incompatibility or bug-emulation default. Parent owns the single pending decision and release gate.

The whole-feature correction wave retains the above donors and licenses. Product-private bigwig/preflight.rs is a narrow original structural admission parser grounded in the actual bigtools0.5.8 allocation bodies and retained bundled libBigWig header/tree layouts; it does not copy or replace the signal decoder. Its bounded partition handoff report is /Volumes/KIOXIA/Developments/tmp/signal-bbi-preflight-20261031.OQbnY8/REPORT.md, SHA9c079676804ae3eca599c4260db2c375929ed57d36f79346895d1d342281edc8. Coordinator integrates this with same-file admission and unchanged-file worker reopens, external summary spools, persistent annotation indexes and first-input operation geometry. No new public API, dependency or source license was introduced.
