use std::fs::{self, File};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Output};

use noodles_bgzf as bgzf;

#[path = "common/sparse_bcf.rs"]
mod sparse_fixture;

fn binary() -> PathBuf {
    PathBuf::from(env!("CARGO_BIN_EXE_rsomics-vcf"))
}

fn fixture() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/index.vcf")
}

fn run(command: &mut Command) -> Output {
    let output = command.output().unwrap();
    assert!(
        output.status.success(),
        "status={:?}\nstdout={}\nstderr={}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    output
}

fn assert_bcftools_1_24() {
    let output = run(Command::new("bcftools").arg("--version"));
    assert!(String::from_utf8_lossy(&output.stdout).starts_with("bcftools 1.24\n"));
}

fn bgzip(source: &[u8], destination: &Path) {
    let mut writer = bgzf::io::Writer::new(File::create(destination).unwrap());
    writer.write_all(source).unwrap();
    writer.try_finish().unwrap();
}

fn corrupt_bcf_reference_type(input: &Path, output: &Path) {
    let mut data = Vec::new();
    bgzf::io::Reader::new(File::open(input).unwrap())
        .read_to_end(&mut data)
        .unwrap();
    let header_length =
        usize::try_from(u32::from_le_bytes(data[5..9].try_into().unwrap())).unwrap();
    let record_start = 9 + header_length;
    let id_start = record_start + 8 + 24;
    let id_length = usize::from(data[id_start] >> 4);
    data[id_start + 1 + id_length] = 0x11;
    bgzip(&data, output);
}

fn query(path: &Path, region: &str) -> Vec<u8> {
    run(Command::new("bcftools")
        .args(["view", "-H", "-r", region])
        .arg(path))
    .stdout
}

#[test]
#[ignore = "release oracle: requires bcftools 1.24"]
fn vcf_indexes_match_bcftools_region_queries_and_stats() {
    assert_bcftools_1_24();
    let directory = tempfile::tempdir().unwrap();
    let ours = directory.path().join("ours.vcf.gz");
    let oracle = directory.path().join("oracle.vcf.gz");
    bgzip(&fs::read(fixture()).unwrap(), &ours);
    fs::copy(&ours, &oracle).unwrap();

    run(Command::new(binary()).args(["index", ours.to_str().unwrap()]));
    run(Command::new("bcftools").args(["index", "-c"]).arg(&oracle));
    for region in [
        "chr1:20000-20000",
        "chr1:75000-75000",
        "chr1:151000-151000",
        "chr1:196000-196000",
        "chr1:205000-205000",
        "chr2:100000-100000",
        "chr2:130000-130000",
    ] {
        assert_eq!(query(&ours, region), query(&oracle, region), "{region}");
    }
    assert_eq!(
        run(Command::new(binary()).args(["index", "--stats", ours.to_str().unwrap()])).stdout,
        run(Command::new("bcftools")
            .args(["index", "--stats"])
            .arg(&oracle))
        .stdout
    );

    fs::remove_file(format!("{}.csi", ours.display())).unwrap();
    run(Command::new(binary()).args(["index", "--tbi", ours.to_str().unwrap()]));
    for region in ["chr1:151000-151000", "chr2:100000-100000"] {
        assert_eq!(query(&ours, region), query(&oracle, region), "{region}");
    }
}

#[test]
#[ignore = "release oracle: requires bcftools 1.24"]
fn custom_csi_and_bcf_match_bcftools_region_queries() {
    assert_bcftools_1_24();
    let directory = tempfile::tempdir().unwrap();
    let ours_vcf = directory.path().join("ours.vcf.gz");
    let oracle_vcf = directory.path().join("oracle.vcf.gz");
    bgzip(&fs::read(fixture()).unwrap(), &ours_vcf);
    fs::copy(&ours_vcf, &oracle_vcf).unwrap();

    run(Command::new(binary()).args(["index", "--min-shift", "18", ours_vcf.to_str().unwrap()]));
    run(Command::new("bcftools")
        .args(["index", "--min-shift", "18"])
        .arg(&oracle_vcf));
    for region in ["chr1:151000-151000", "chr2:100000-100000"] {
        assert_eq!(query(&ours_vcf, region), query(&oracle_vcf, region));
    }

    let ours_bcf = directory.path().join("ours.bcf");
    let oracle_bcf = directory.path().join("oracle.bcf");
    run(Command::new("bcftools")
        .args(["view", "-Ob", "-o", ours_bcf.to_str().unwrap()])
        .arg(&oracle_vcf));
    fs::copy(&ours_bcf, &oracle_bcf).unwrap();
    run(Command::new(binary()).args(["index", ours_bcf.to_str().unwrap()]));
    run(Command::new("bcftools")
        .args(["index", "-c"])
        .arg(&oracle_bcf));
    for region in ["chr1:151000-151000", "chr2:100000-100000"] {
        assert_eq!(query(&ours_bcf, region), query(&oracle_bcf, region));
    }
    assert_eq!(
        run(Command::new(binary()).args(["index", "--stats", "--all", ours_bcf.to_str().unwrap()]))
            .stdout,
        run(Command::new("bcftools")
            .args(["index", "--stats", "--all"])
            .arg(&oracle_bcf))
        .stdout
    );
}

#[test]
#[ignore = "release oracle: requires bcftools 1.24"]
fn malformed_bcf_is_rejected_like_bcftools() {
    assert_bcftools_1_24();
    let directory = tempfile::tempdir().unwrap();
    let vcf = directory.path().join("input.vcf.gz");
    let valid = directory.path().join("valid.bcf");
    let malformed = directory.path().join("malformed.bcf");
    bgzip(&fs::read(fixture()).unwrap(), &vcf);
    run(Command::new("bcftools")
        .args(["view", "-Ob", "-o", valid.to_str().unwrap()])
        .arg(&vcf));
    corrupt_bcf_reference_type(&valid, &malformed);

    let ours = Command::new(binary())
        .args(["index", malformed.to_str().unwrap()])
        .output()
        .unwrap();
    let oracle = Command::new("bcftools")
        .args(["index", "-c"])
        .arg(&malformed)
        .output()
        .unwrap();
    assert!(!ours.status.success());
    assert!(!oracle.status.success());
}

#[test]
#[ignore = "release oracle: requires bcftools 1.24"]
fn sparse_bcf_indexes_interoperate_with_bcftools_including_empty_tail_queries() {
    assert_bcftools_1_24();
    for empty in [false, true] {
        let directory = tempfile::tempdir().unwrap();
        let source = directory.path().join("sparse.vcf");
        let oracle = directory.path().join("oracle.bcf");
        sparse_fixture::write_vcf(&source, empty);
        run(Command::new("bcftools")
            .args(["view", "--no-version", "-Ob", "-o"])
            .arg(&oracle)
            .arg(&source));
        sparse_fixture::assert_bcf(&oracle, empty);
        run(Command::new("bcftools").arg("index").arg(&oracle));
        let index = noodles_csi::fs::read(oracle.with_extension("bcf.csi")).unwrap();
        assert_eq!(index.reference_sequences().len(), if empty { 0 } else { 6 });
        let expected_stats = if empty {
            b"".as_slice()
        } else {
            b"chrB\t100\t2\nchrA\t200\t1\n".as_slice()
        };
        let expected_all = if empty {
            b"chrB\t100\t.\nchrA\t200\t.\nempty\t300\t.\n".as_slice()
        } else {
            b"chrB\t100\t2\nchrA\t200\t1\nempty\t300\t.\n".as_slice()
        };
        let mut inputs = vec![oracle];
        for threads in ["0", "2"] {
            let ours = directory.path().join(format!("ours-{threads}.bcf"));
            fs::copy(&inputs[0], &ours).unwrap();
            run(Command::new(binary())
                .args(["index", "--threads", threads])
                .arg(&ours));
            inputs.push(ours);
        }
        for input in &inputs {
            assert_eq!(
                run(Command::new("bcftools")
                    .args(["index", "--stats"])
                    .arg(input))
                .stdout,
                expected_stats
            );
            assert_eq!(
                run(Command::new(binary()).args(["index", "--stats"]).arg(input)).stdout,
                expected_stats
            );
            assert_eq!(
                run(Command::new(binary())
                    .args(["index", "--stats", "--all"])
                    .arg(input))
                .stdout,
                expected_all
            );
            let ours_count = run(Command::new(binary())
                .args(["index", "--nrecords"])
                .arg(input));
            assert_eq!(ours_count.stdout, if empty { b"0\n" } else { b"3\n" });
            assert_eq!(
                ours_count.stdout,
                run(Command::new("bcftools")
                    .args(["index", "--nrecords"])
                    .arg(input))
                .stdout
            );
            for (region, expected) in [
                ("chrB:10", "chrB\t10\tb1\tA\tC\t.\tPASS\t.\n"),
                ("chrA:30", "chrA\t30\ta1\tT\tA\t.\tPASS\t.\n"),
                ("empty:1", ""),
                ("empty:1,chrB:10", "chrB\t10\tb1\tA\tC\t.\tPASS\t.\n"),
            ] {
                let expected = if empty { "" } else { expected }.as_bytes();
                assert_eq!(query(input, region), expected, "{input:?}, {region}");
                assert_eq!(
                    run(Command::new(binary())
                        .args(["view", "--no-header", "-r", region])
                        .arg(input))
                    .stdout,
                    expected,
                    "{input:?}, {region}"
                );
                let concat = run(Command::new(binary())
                    .args(["concat", "-a", "-r", region])
                    .arg(input));
                let body: Vec<u8> = concat
                    .stdout
                    .split_inclusive(|byte| *byte == b'\n')
                    .filter(|line| !line.starts_with(b"#"))
                    .flatten()
                    .copied()
                    .collect();
                assert_eq!(body, expected, "{input:?}, {region}");
            }
        }
    }
}
