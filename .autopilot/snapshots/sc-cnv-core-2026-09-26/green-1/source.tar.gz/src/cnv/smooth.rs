use super::model::CnvState;
use super::normalize::median;
use rsomics_common::{Result, RsomicsError};

pub(crate) fn triangular(state: &mut CnvState, window_length: usize) -> Result<()> {
    let gene_count = state.gene_count();
    let value_count = state.values.len();
    let radius = window_length / 2;
    let mut replacement = Vec::new();
    replacement
        .try_reserve_exact(value_count)
        .map_err(|_| RsomicsError::InvalidInput("smoothing allocation failed".into()))?;
    replacement.resize(value_count, 0.0);

    let mut start = 0;
    while start < gene_count {
        let chromosome = &state.genes[start].chromosome;
        let mut end = start + 1;
        while end < gene_count && state.genes[end].chromosome == *chromosome {
            end += 1;
        }
        for cell in 0..state.cell_count() {
            let offset = cell * gene_count;
            if end - start == 1 {
                replacement[offset + start] = state.values[offset + start];
                continue;
            }
            for gene in start..end {
                let left = gene.saturating_sub(radius).max(start);
                let right = gene.saturating_add(radius).min(end - 1);
                let mut weighted = 0.0;
                let mut weight_total = 0.0;
                for neighbor in left..=right {
                    let distance = gene.abs_diff(neighbor);
                    let weight = (radius + 1 - distance) as f64;
                    weighted += state.values[offset + neighbor] * weight;
                    weight_total += weight;
                    if !weighted.is_finite() || !weight_total.is_finite() {
                        return Err(nonfinite());
                    }
                }
                let value = weighted / weight_total;
                if !value.is_finite() {
                    return Err(nonfinite());
                }
                replacement[offset + gene] = value;
            }
        }
        start = end;
    }
    state.values = replacement;
    Ok(())
}

pub(crate) fn center_cells(state: &mut CnvState, scratch: &mut [f64]) -> Result<()> {
    let genes = state.gene_count();
    for column in state.values.chunks_exact_mut(genes) {
        scratch[..genes].copy_from_slice(column);
        let center = median(&mut scratch[..genes])?;
        for value in column {
            *value -= center;
            if !value.is_finite() {
                return Err(nonfinite());
            }
        }
    }
    Ok(())
}

fn nonfinite() -> RsomicsError {
    RsomicsError::InvalidInput("smoothing or centering result is nonfinite".into())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cnv::{Cell, Gene};

    fn state(chromosomes: &[&str], values: Vec<f64>) -> CnvState {
        let genes = chromosomes
            .iter()
            .enumerate()
            .map(|(index, chromosome)| Gene {
                id: format!("g{index}"),
                chromosome: (*chromosome).into(),
                start: index as u64 + 1,
                end: index as u64 + 1,
            })
            .collect();
        CnvState {
            genes,
            cells: vec![Cell {
                id: "c".into(),
                group: "g".into(),
            }],
            values,
        }
    }

    fn close(actual: f64, expected: f64) {
        assert!(
            (actual - expected).abs() < 1e-12,
            "actual={actual}, expected={expected}"
        );
    }

    #[test]
    fn two_gene_window_101_has_independent_weighted_witness() {
        let mut state = state(&["chr1", "chr1"], vec![0.0, 10.0]);
        triangular(&mut state, 101).unwrap();
        close(state.values[0], 500.0 / 101.0);
        close(state.values[1], 510.0 / 101.0);
    }

    #[test]
    fn singleton_is_copied_and_chromosomes_do_not_bleed() {
        let mut state = state(&["chr1", "chr1", "chr2"], vec![0.0, 10.0, 1000.0]);
        triangular(&mut state, 101).unwrap();
        close(state.values[0], 500.0 / 101.0);
        close(state.values[1], 510.0 / 101.0);
        assert_eq!(state.values[2], 1000.0);
    }

    #[test]
    fn constant_windows_of_lengths_100_101_and_102_stay_constant() {
        for length in [100, 101, 102] {
            let mut state = state(&vec!["chr1"; length], vec![7.0; length]);
            triangular(&mut state, 101).unwrap();
            for actual in state.values {
                close(actual, 7.0);
            }
        }
    }

    #[test]
    fn symmetric_linear_window_centers_are_preserved() {
        for length in [101, 102] {
            let mut state = state(
                &vec!["chr1"; length],
                (0..length).map(|i| i as f64).collect(),
            );
            triangular(&mut state, 101).unwrap();
            close(state.values[50], 50.0);
            if length == 102 {
                close(state.values[51], 51.0);
            }
        }
    }

    #[test]
    fn cell_centering_uses_global_gene_median() {
        let mut state = state(&["chr1", "chr1", "chr2"], vec![0.0, 4.0, 10.0]);
        let mut scratch = vec![0.0; 3];
        center_cells(&mut state, &mut scratch).unwrap();
        assert_eq!(state.values, [-4.0, 0.0, 6.0]);
    }
}
