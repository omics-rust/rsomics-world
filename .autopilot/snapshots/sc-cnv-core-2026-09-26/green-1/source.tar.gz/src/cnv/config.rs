use super::model::PreparedCounts;
use rsomics_common::{Result, RsomicsError};
use std::collections::HashSet;

#[derive(Clone, Debug)]
pub enum ReferenceMode {
    AllCells,
    GroupBounds(Vec<String>),
    GroupMean(Vec<String>),
}

#[derive(Clone, Debug)]
pub struct PreprocessConfig {
    pub cutoff: f64,
    pub min_cells_per_gene: usize,
    pub window_length: usize,
    pub max_centered_threshold: f64,
    pub references: ReferenceMode,
    pub max_numeric_bytes: usize,
}

pub(crate) enum ResolvedReferences {
    AllCells,
    Bounds(Vec<Vec<usize>>),
    Mean(Vec<Vec<usize>>),
}

impl PreprocessConfig {
    pub(crate) fn validate(&self, input: &PreparedCounts) -> Result<ResolvedReferences> {
        if !self.cutoff.is_finite() || self.cutoff < 0.0 {
            return Err(RsomicsError::ConfigError(
                "cutoff must be finite and nonnegative".into(),
            ));
        }
        if self.min_cells_per_gene == 0 {
            return Err(RsomicsError::ConfigError(
                "min_cells_per_gene must be positive".into(),
            ));
        }
        if self.window_length == 0 || self.window_length % 2 == 0 {
            return Err(RsomicsError::ConfigError(
                "window_length must be positive and odd".into(),
            ));
        }
        if !self.max_centered_threshold.is_finite() || self.max_centered_threshold <= 0.0 {
            return Err(RsomicsError::ConfigError(
                "max_centered_threshold must be finite and positive".into(),
            ));
        }

        let genes = input.state().gene_count();
        let cells = input.state().cell_count();
        let values = genes.checked_mul(cells).ok_or_else(budget_overflow)?;
        let elements = values
            .checked_mul(3)
            .and_then(|n| genes.checked_mul(4).and_then(|g| n.checked_add(g)))
            .and_then(|n| n.checked_add(cells))
            .ok_or_else(budget_overflow)?;
        let bytes = elements
            .checked_mul(std::mem::size_of::<f64>())
            .ok_or_else(budget_overflow)?;
        if bytes > self.max_numeric_bytes {
            return Err(RsomicsError::ConfigError(format!(
                "numerical workspace budget requires {bytes} bytes, limit is {}",
                self.max_numeric_bytes
            )));
        }

        match &self.references {
            ReferenceMode::AllCells => Ok(ResolvedReferences::AllCells),
            ReferenceMode::GroupBounds(names) => {
                Ok(ResolvedReferences::Bounds(resolve_groups(names, input)?))
            }
            ReferenceMode::GroupMean(names) => {
                Ok(ResolvedReferences::Mean(resolve_groups(names, input)?))
            }
        }
    }
}

fn budget_overflow() -> RsomicsError {
    RsomicsError::ConfigError("numerical workspace size overflows".into())
}

fn resolve_groups(names: &[String], input: &PreparedCounts) -> Result<Vec<Vec<usize>>> {
    if names.is_empty() {
        return Err(RsomicsError::ConfigError(
            "named references cannot be empty".into(),
        ));
    }
    let mut seen = HashSet::new();
    let mut groups = Vec::new();
    groups
        .try_reserve_exact(names.len())
        .map_err(|_| RsomicsError::ConfigError("reference group allocation failed".into()))?;
    for name in names {
        if name.is_empty() || !seen.insert(name.as_str()) {
            return Err(RsomicsError::ConfigError(
                "reference names must be nonempty and unique".into(),
            ));
        }
        let mut indices = Vec::new();
        for (index, cell) in input.state().cells().iter().enumerate() {
            if cell.group == *name {
                indices.try_reserve(1).map_err(|_| {
                    RsomicsError::ConfigError("reference index allocation failed".into())
                })?;
                indices.push(index);
            }
        }
        if indices.is_empty() {
            return Err(RsomicsError::ConfigError(format!(
                "reference group {name} is missing"
            )));
        }
        groups.push(indices);
    }
    Ok(groups)
}
