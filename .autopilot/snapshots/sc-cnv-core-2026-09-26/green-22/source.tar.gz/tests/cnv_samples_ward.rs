#[path = "../src/cnv/samples/condensed.rs"]
mod condensed;
#[path = "../src/cnv/samples/ward.rs"]
mod ward;

use std::collections::HashSet;
use ward::{required_workspace, ward_d2};

const FIXTURE: &str = include_str!("fixtures/infercnv-1.28.0/ward/trees.tsv");

fn fields<'a>(line: &'a str, label: &str) -> Vec<&'a str> {
    let mut parts = line.split('\t');
    assert_eq!(parts.next(), Some(label));
    parts.collect()
}

#[test]
fn all_152_installed_trees_match_exactly() {
    let lines: Vec<_> = FIXTURE.lines().collect();
    assert_eq!(lines.len(), 152 * 6);
    let mut identities = HashSet::new();
    let mut pairs = 0;
    let mut max_leaves = 0;
    for record in lines.chunks_exact(6) {
        let header = fields(record[0], "tree");
        assert_eq!(header.len(), 2);
        let identity = header[0];
        assert!(identities.insert(identity));
        let n: usize = header[1].parse().unwrap();
        let distances: Vec<f64> = fields(record[1], "distances")
            .iter()
            .map(|s| s.parse().unwrap())
            .collect();
        assert_eq!(distances.len(), n * (n - 1) / 2);
        let merge: Vec<[i32; 2]> = fields(record[2], "merge")
            .iter()
            .map(|s| {
                let values: Vec<_> = s.split(',').map(|v| v.parse().unwrap()).collect();
                values.try_into().unwrap()
            })
            .collect();
        let height: Vec<f64> = fields(record[3], "heights")
            .iter()
            .map(|s| s.parse().unwrap())
            .collect();
        let order: Vec<usize> = fields(record[4], "order")
            .iter()
            .map(|s| s.parse::<usize>().unwrap().checked_sub(1).unwrap())
            .collect();
        assert_eq!(record[5], "end");
        assert_eq!(merge.len(), n - 1);
        assert_eq!(height.len(), n - 1);
        assert_eq!(order.len(), n);
        let before: Vec<_> = distances.iter().map(|v| v.to_bits()).collect();
        let actual = ward_d2(&distances, n, 8 * 1024 * 1024)
            .unwrap_or_else(|error| panic!("{identity}: {error}"));
        assert_eq!(actual.merge, merge, "{identity} merge");
        assert_eq!(actual.order, order, "{identity} order");
        assert_eq!(actual.height.len(), height.len());
        for (row, (&actual, &expected)) in actual.height.iter().zip(&height).enumerate() {
            assert_eq!(
                actual.to_bits(),
                expected.to_bits(),
                "{identity} height row {row}: {actual:.17e} != {expected:.17e}"
            );
        }
        assert_eq!(
            distances.iter().map(|v| v.to_bits()).collect::<Vec<_>>(),
            before
        );
        pairs += distances.len();
        max_leaves = max_leaves.max(n);
        eprintln!(
            "exact Ward tree {identity}: leaves={n}, merges={}",
            merge.len()
        );
    }
    assert_eq!(identities.len(), 152);
    assert_eq!(pairs, 107331);
    assert_eq!(max_leaves, 142);
}

#[test]
fn two_leaves_and_predecessor_biased_ties() {
    let two = ward_d2(&[3.0], 2, 10000).unwrap();
    assert_eq!(two.merge, [[-1, -2]]);
    assert_eq!(two.height, [3.0]);
    assert_eq!(two.order, [0, 1]);
    let three = ward_d2(&[1.0, 0.5, 0.5], 3, 10000).unwrap();
    assert_eq!(three.merge, [[-1, -3], [-2, 1]]);
    assert_eq!(three.height, [0.5, 0.8660254037844386]);
    assert_eq!(three.order, [1, 0, 2]);
    let zero = ward_d2(&[0.0, -0.0, 0.0], 3, 10000).unwrap();
    assert_eq!(zero.merge, [[-1, -2], [-3, 1]]);
    assert_eq!(zero.order, [2, 0, 1]);
    assert!(zero.height.iter().all(|h| h.to_bits() == 0));
}

#[test]
fn pooled_six_leaf_chain_retains_equal_height_merge_order() {
    let distances = [
        2.0, 0.5, 1.5, 0.5, 1.0, 2.5, 0.5, 1.5, 1.0, 2.0, 1.0, 1.5, 1.0, 0.5, 0.5,
    ];
    let tree = ward_d2(&distances, 6, 10000).unwrap();
    assert_eq!(tree.merge, [[-1, -3], [-2, -4], [-5, -6], [1, 3], [2, 4]]);
    assert_eq!(tree.order, [1, 3, 0, 2, 4, 5]);
    let height = [
        "0.5",
        "0.5",
        "0.5",
        "1.4142135623730951",
        "2.4494897427831779",
    ]
    .map(|value| value.parse::<f64>().unwrap());
    assert_eq!(tree.height, height);
}

#[test]
fn finite_dynamic_range_and_squared_underflow_are_not_clamped() {
    for scale in [1e-200, 1.0, 1e100] {
        let tree = ward_d2(&[scale, scale * 0.5, scale * 0.5], 3, 10000).unwrap();
        assert_eq!(tree.merge.len(), 2);
        assert!(tree.height.iter().all(|h| h.is_finite() && *h >= 0.0));
        let mut order = tree.order;
        order.sort_unstable();
        assert_eq!(order, [0, 1, 2]);
    }
}

#[test]
fn rejects_shapes_dimensions_and_unsafe_arithmetic() {
    for leaves in [0, 1, i32::MAX as usize + 1, usize::MAX] {
        assert!(ward_d2(&[], leaves, usize::MAX).is_err());
        assert!(required_workspace(leaves).is_err());
    }
    assert!(ward_d2(&[], 2, usize::MAX).is_err());
    assert!(ward_d2(&[1.0, 2.0], 2, usize::MAX).is_err());
    assert!(ward_d2(&[1.0], 3, usize::MAX).is_err());
    assert!(required_workspace(i32::MAX as usize).is_err());
    for distance in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY, -1.0, f64::MAX] {
        assert!(ward_d2(&[distance], 2, usize::MAX).is_err());
    }
    assert!(ward_d2(&[1e154, 1e154, 1e154], 3, usize::MAX).is_err());
}

#[test]
fn exact_requested_workspace_boundary_includes_outputs_and_scratch() {
    let n = 3;
    let usize_bytes = std::mem::size_of::<usize>();
    let expected = 3 * 8
        + 2 * (n + 1) * usize_bytes
        + n * usize_bytes
        + n * 8
        + (n - 1) * (3 * usize_bytes + 8)
        + (2 * n - 1) * usize_bytes
        + (n - 1) * 8
        + (n - 1) * 8
        + n * usize_bytes
        + n * 4;
    assert_eq!(required_workspace(n).unwrap(), expected);
    assert!(ward_d2(&[1.0, 0.5, 0.5], n, expected).is_ok());
    assert!(ward_d2(&[1.0, 0.5, 0.5], n, expected - 1).is_err());
    assert!(ward_d2(&[1.0, 0.5, 0.5], n, 0).is_err());
}
