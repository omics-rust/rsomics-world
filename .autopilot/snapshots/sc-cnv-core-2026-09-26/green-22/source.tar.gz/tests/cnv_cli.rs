use flate2::{Compression, write::GzEncoder};
use serde_json::{Value, json};
use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};
use std::sync::atomic::{AtomicUsize, Ordering};

static NEXT_FIXTURE: AtomicUsize = AtomicUsize::new(0);

struct Fixture(PathBuf);

impl Drop for Fixture {
    fn drop(&mut self) {
        fs::remove_dir_all(&self.0).unwrap();
    }
}

impl Fixture {
    fn new() -> Self {
        let root = std::env::temp_dir().join(format!(
            "rsomics-cnv-cli-{}-{}",
            std::process::id(),
            NEXT_FIXTURE.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir(&root).unwrap();
        fs::write(
            root.join("counts.tsv"),
            "gene\to1\tr1\to2\to3\ng2\t2\t6\t4\t8\ng1\t8\t4\t6\t2\n",
        )
        .unwrap();
        fs::write(
            root.join("positions.tsv"),
            "g1\tchr1\t1\t2\ng2\tchr1\t3\t4\n",
        )
        .unwrap();
        fs::write(
            root.join("annotations.tsv"),
            "o1\tZ\nr1\tref\no2\tA\no3\tZ\n",
        )
        .unwrap();
        Self(root)
    }

    fn command(&self, output: &Path) -> Command {
        let mut command = Command::new(env!("CARGO_BIN_EXE_rsomics-sc"));
        command
            .args(["cnv", "samples", "--counts"])
            .arg(self.0.join("counts.tsv"))
            .arg("--positions")
            .arg(self.0.join("positions.tsv"))
            .arg("--annotations")
            .arg(self.0.join("annotations.tsv"))
            .arg("--output")
            .arg(output)
            .args([
                "--threads",
                "1",
                "--reference",
                "ref",
                "--cutoff",
                "0",
                "--min-cells-per-gene",
                "1",
                "--window-length",
                "1",
                "--z-score-filter",
                "0",
            ]);
        command
    }

    fn gzip_inputs(&self) {
        for name in ["counts.tsv", "positions.tsv", "annotations.tsv"] {
            let path = self.0.join(name);
            let raw = fs::read(&path).unwrap();
            let mut encoder = GzEncoder::new(Vec::new(), Compression::default());
            encoder.write_all(&raw).unwrap();
            fs::write(path, encoder.finish().unwrap()).unwrap();
        }
    }
}

fn success(output: Output) -> Output {
    assert!(
        output.status.success(),
        "stdout={} stderr={}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    output
}

#[test]
fn tiny_raw_workflow_retains_identities_groups_trees_and_column_major_expression() {
    let fixture = Fixture::new();
    let report_path = fixture.0.join("samples.json");
    let output = success(
        fixture
            .command(&report_path)
            .arg("--include-expression")
            .output()
            .unwrap(),
    );
    assert!(output.stdout.is_empty());
    let report: Value = serde_json::from_slice(&fs::read(report_path).unwrap()).unwrap();
    assert_eq!(report["schema"], "rsomics-sc.cnv.samples.v1");
    assert_eq!(report["index_basis"]["genes"], 0);
    assert_eq!(report["index_basis"]["cells"], 0);
    assert_eq!(report["genes"][0]["id"], "g1");
    assert_eq!(report["genes"][1]["id"], "g2");
    assert_eq!(report["cells"][1], json!({"id":"r1", "group":"ref"}));
    assert_eq!(report["selected_gene_indices"], json!([0, 1]));
    assert!(report["outlier_gene_indices"].is_null());
    assert_eq!(report["groups"][0]["name"], "all_observations");
    assert_eq!(report["groups"][1]["name"], "ref");
    let mut members = report["groups"][0]["member_indices"]
        .as_array()
        .unwrap()
        .clone();
    members.sort_by_key(|value| value.as_u64().unwrap());
    assert_eq!(members, json!([0, 2, 3]).as_array().unwrap().clone());
    assert_eq!(
        report["groups"][0]["tree"]["merge"]
            .as_array()
            .unwrap()
            .len(),
        2
    );
    assert_eq!(
        report["groups"][0]["tree"]["order"]
            .as_array()
            .unwrap()
            .len(),
        3
    );
    assert!(report["groups"][1]["tree"].is_null());
    assert_eq!(report["groups"][1]["member_indices"], json!([1]));
    assert_eq!(report["expression"]["step"], 14);
    assert_eq!(report["expression"]["layout"], "column-major");
    assert_eq!(report["expression"]["shape"], json!([2, 4]));
    assert_eq!(report["expression"]["values"].as_array().unwrap().len(), 8);
    assert!(
        report["expression"]["values"]
            .as_array()
            .unwrap()
            .iter()
            .all(|v| v.as_f64().unwrap().is_finite())
    );

    fixture.gzip_inputs();
    let grouped_path = fixture.0.join("grouped.json");
    success(
        fixture
            .command(&grouped_path)
            .args(["--cluster-by-groups", "--include-expression"])
            .output()
            .unwrap(),
    );
    let grouped: Value = serde_json::from_slice(&fs::read(grouped_path).unwrap()).unwrap();
    assert_eq!(grouped["genes"], report["genes"]);
    assert_eq!(grouped["cells"], report["cells"]);
    assert_eq!(grouped["expression"], report["expression"]);
    assert_eq!(grouped["groups"][0]["name"], "A");
    assert_eq!(grouped["groups"][1]["name"], "Z");
    assert_eq!(grouped["groups"][2]["name"], "ref");
    assert!(
        grouped["groups"]
            .as_array()
            .unwrap()
            .iter()
            .all(|group| group["tree"].is_null())
    );
}

#[test]
fn mandatory_nested_help_comes_from_the_actual_command_tree() {
    for args in [
        vec!["--help"],
        vec!["cnv", "--help"],
        vec!["cnv", "samples", "--help"],
    ] {
        let output = success(
            Command::new(env!("CARGO_BIN_EXE_rsomics-sc"))
                .args(args)
                .output()
                .unwrap(),
        );
        let help = String::from_utf8(output.stdout).unwrap();
        assert!(help.contains("Usage:"), "{help}");
        assert!(help.contains("samples") || help.contains("cnv"), "{help}");
    }
    let output = Command::new(env!("CARGO_BIN_EXE_rsomics-sc"))
        .args(["cnv", "samples"])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert!(String::from_utf8_lossy(&output.stderr).contains("--counts"));
}

#[test]
fn invalid_config_and_output_aliases_preserve_inputs_and_existing_report() {
    let fixture = Fixture::new();
    let report = fixture.0.join("samples.json");
    fs::write(&report, b"prior report\n").unwrap();
    let output = fixture
        .command(&report)
        .args(["--max-numeric-bytes", "0"])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert_eq!(fs::read(&report).unwrap(), b"prior report\n");
    for name in ["counts.tsv", "positions.tsv", "annotations.tsv"] {
        let path = fixture.0.join(name);
        let before = fs::read(&path).unwrap();
        let output = fixture.command(&path).output().unwrap();
        assert!(!output.status.success());
        assert_eq!(fs::read(&path).unwrap(), before);
    }
}

#[test]
fn json_envelope_is_separate_from_the_report_and_rejects_stdout_report() {
    let fixture = Fixture::new();
    let report = fixture.0.join("samples.json");
    let output = success(fixture.command(&report).arg("--json").output().unwrap());
    let envelope: Value = serde_json::from_slice(&output.stdout).unwrap();
    assert_eq!(envelope["status"], "ok");
    assert_eq!(envelope["result"]["operation"], "cnv.samples");
    assert_eq!(envelope["result"]["genes"], 2);
    assert_eq!(envelope["result"]["threads"], 1);
    assert!(envelope["result"].get("expression").is_none());
    let report: Value = serde_json::from_slice(&fs::read(report).unwrap()).unwrap();
    assert!(report.get("expression").is_none());
    let output = fixture
        .command(Path::new("-"))
        .arg("--json")
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert!(output.stdout.is_empty());
    let envelope: Value = serde_json::from_slice(&output.stderr).unwrap();
    assert_eq!(envelope["status"], "error");
    let output = success(fixture.command(Path::new("-")).output().unwrap());
    let report: Value = serde_json::from_slice(&output.stdout).unwrap();
    assert_eq!(report["schema"], "rsomics-sc.cnv.samples.v1");
}

#[test]
fn denoise_persists_step_22_without_changing_step_14_or_samples() {
    let fixture = Fixture::new();
    let baseline_path = fixture.0.join("before-denoise.json");
    success(
        fixture
            .command(&baseline_path)
            .arg("--include-expression")
            .output()
            .unwrap(),
    );
    let baseline: Value = serde_json::from_slice(&fs::read(baseline_path).unwrap()).unwrap();
    for include in [false, true] {
        let path = fixture.0.join(format!("denoised-{include}.json"));
        let mut command = fixture.command(&path);
        command.args(["--denoise", "--noise-filter", "0.5"]);
        if include {
            command.arg("--include-expression");
        }
        success(command.output().unwrap());
        let report: Value = serde_json::from_slice(&fs::read(path).unwrap()).unwrap();
        for field in [
            "genes",
            "cells",
            "input_groups",
            "groups",
            "selected_gene_indices",
        ] {
            assert_eq!(report[field], baseline[field]);
        }
        if include {
            assert_eq!(report["expression"], baseline["expression"]);
        } else {
            assert!(report.get("expression").is_none());
        }
        let denoised = &report["denoised"];
        assert_eq!(denoised["expression"]["step"], 22);
        assert_eq!(denoised["expression"]["shape"], json!([2, 4]));
        assert_eq!(denoised["expression"]["layout"], "column-major");
        assert_eq!(denoised["bounds"], json!({"center": 1.0, "threshold": 0.5}));
        let values = denoised["expression"]["values"].as_array().unwrap();
        let original = baseline["expression"]["values"].as_array().unwrap();
        assert_eq!(&values[..2], &original[..2]);
        assert!(values[2..].iter().all(|value| value.as_f64() == Some(1.0)));
        assert_ne!(values, original);
    }
}

#[test]
fn denoise_sd_zero_still_uses_logistic_when_requested() {
    let fixture = Fixture::new();
    let path = fixture.0.join("logistic.json");
    success(
        fixture
            .command(&path)
            .args(["--denoise", "--noise-logistic", "--include-expression"])
            .output()
            .unwrap(),
    );
    let report: Value = serde_json::from_slice(&fs::read(path).unwrap()).unwrap();
    assert_eq!(
        report["denoised"]["bounds"],
        json!({"center": 1.0, "threshold": 0.0})
    );
    assert_eq!(report["settings"]["denoise"]["sd_amplifier"], 1.5);
    assert_eq!(report["settings"]["denoise"]["noise_logistic"], true);
    let before = report["expression"]["values"][5].as_f64().unwrap();
    let after = report["denoised"]["expression"]["values"][5]
        .as_f64()
        .unwrap();
    assert!(before < after && after < 1.0);
}

#[cfg(feature = "external-infercnv-samples-oracle")]
#[test]
fn canonical_raw_cli_preserves_selection_and_results_across_worker_counts() {
    let root = std::env::var_os("RSOMICS_INFER_CNV_ORACLE_ROOT")
        .filter(|value| !value.is_empty())
        .expect("RSOMICS_INFER_CNV_ORACLE_ROOT is required");
    let root = PathBuf::from(root).join("inputs");
    let fixture = Fixture::new();
    let mut reports = Vec::new();
    for workers in [1, 4] {
        let path = fixture.0.join(format!("canonical-{workers}.json"));
        success(
            Command::new(env!("CARGO_BIN_EXE_rsomics-sc"))
                .args(["cnv", "samples", "--counts"])
                .arg(root.join("canonical-full.tsv"))
                .arg("--positions")
                .arg(root.join("gencode_downsampled.EXAMPLE_ONLY_DONT_REUSE.txt"))
                .arg("--annotations")
                .arg(root.join("oligodendroglioma_annotations_downsampled.txt"))
                .args([
                    "--reference",
                    "Microglia/Macrophage",
                    "--reference",
                    "Oligodendrocytes (non-malignant)",
                    "--cutoff",
                    "1",
                    "--include-expression",
                    "--threads",
                ])
                .arg(workers.to_string())
                .arg("--output")
                .arg(&path)
                .output()
                .unwrap(),
        );
        let mut report: Value = serde_json::from_slice(&fs::read(path).unwrap()).unwrap();
        assert_eq!(report["genes"].as_array().unwrap().len(), 8508);
        assert_eq!(report["cells"].as_array().unwrap().len(), 184);
        assert_eq!(
            report["selected_gene_indices"].as_array().unwrap().len(),
            6187
        );
        assert_eq!(
            report["outlier_gene_indices"].as_array().unwrap().len(),
            2321
        );
        assert_eq!(report["groups"].as_array().unwrap().len(), 3);
        let mut coverage = Vec::new();
        for (group, (name, expected)) in report["groups"].as_array().unwrap().iter().zip([
            ("all_observations", 142),
            ("Microglia/Macrophage", 19),
            ("Oligodendrocytes (non-malignant)", 23),
        ]) {
            assert_eq!(group["name"], name);
            let members = group["member_indices"].as_array().unwrap();
            assert_eq!(members.len(), expected);
            assert_eq!(
                group["tree"]["merge"].as_array().unwrap().len(),
                expected - 1
            );
            coverage.extend(members.iter().map(|value| value.as_u64().unwrap()));
        }
        coverage.sort_unstable();
        assert_eq!(coverage, (0..184).collect::<Vec<_>>());
        assert_eq!(report["settings"]["threads"], workers);
        report["settings"]["threads"] = Value::Null;
        reports.push(report);
    }
    assert_eq!(reports[0], reports[1]);
    eprintln!(
        "canonical raw CLI: 8508 genes, 184 cells, 6187 selected genes, identical 1/4-worker results"
    );
}
