#[path = "../src/cnv/samples/condensed.rs"]
mod condensed;
#[path = "../src/cnv/samples/distance.rs"]
mod distance;
#[path = "../src/cnv/parallel.rs"]
mod parallel;

use distance::CellProfiles;

#[test]
fn small_columns_and_permuted_groups_preserve_condensed_order() {
    let values = [0.0, 0.0, 3.0, 4.0, 0.0, 4.0, 3.0, 0.0];
    let before = values.map(f64::to_bits);
    let profiles = CellProfiles::new(&values, 2, 4).unwrap();
    assert_eq!(profiles.distances(&[0, 1, 2], 24).unwrap(), [5.0, 4.0, 3.0]);
    assert_eq!(profiles.distances(&[2, 0, 3], 24).unwrap(), [4.0, 5.0, 3.0]);
    assert_eq!(profiles.distances(&[3, 1], 8).unwrap(), [4.0]);
    assert_eq!(values.map(f64::to_bits), before);
}

#[test]
fn zero_features_and_equal_profiles_produce_positive_zero() {
    let empty = CellProfiles::new(&[], 0, 4).unwrap();
    assert!(
        empty
            .distances(&[3, 0, 2], 24)
            .unwrap()
            .iter()
            .all(|v| v.to_bits() == 0)
    );
    let equal = CellProfiles::new(&[2.0, -0.0, 2.0, 0.0], 2, 2).unwrap();
    assert_eq!(equal.distances(&[1, 0], 8).unwrap()[0].to_bits(), 0);
}

#[test]
fn separate_even_and_odd_reductions_are_not_a_sequential_sum() {
    let expected = "10000000000000002".parse::<f64>().unwrap().sqrt();
    for features in [4, 5] {
        let mut values = vec![0.0; features];
        values.extend([1e8, 1.0, 1.0, 1.0, 1.0].into_iter().take(features));
        let profiles = CellProfiles::new(&values, features, 2).unwrap();
        let actual = profiles.distances(&[0, 1], 8).unwrap()[0];
        assert_eq!(actual.to_bits(), expected.to_bits());
        assert_ne!(actual.to_bits(), 1e8_f64.to_bits());
    }
    let odd = CellProfiles::new(&[0.0, 0.0, 0.0, 2.0, 3.0, 6.0], 3, 2).unwrap();
    assert_eq!(odd.distances(&[0, 1], 8).unwrap(), [7.0]);
}

#[test]
fn rejects_invalid_shapes_all_nonfinite_values_and_indices() {
    for (values, features, cells) in [
        (&[][..], 0, 0),
        (&[0.0][..], 1, 2),
        (&[][..], usize::MAX, 2),
    ] {
        assert!(CellProfiles::new(values, features, cells).is_err());
    }
    for value in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
        assert!(CellProfiles::new(&[0.0, value], 1, 2).is_err());
    }
    let values = [1.0, 2.0, 3.0];
    let profiles = CellProfiles::new(&values, 1, 3).unwrap();
    for indices in [
        &[][..],
        &[0][..],
        &[0, 0][..],
        &[2, 1, 2][..],
        &[0, 3][..],
        &[usize::MAX, 0][..],
    ] {
        assert!(profiles.distances(indices, usize::MAX).is_err());
    }
}

#[test]
fn finite_input_arithmetic_overflow_fails_and_underflow_remains_zero() {
    for (values, features) in [
        (vec![f64::MAX, -f64::MAX], 1),
        (vec![0.0, 1e200], 1),
        (vec![0.0, 0.0, 0.0, 0.0, 1e154, 1e154, 1e154, 1e154], 4),
    ] {
        let profiles = CellProfiles::new(&values, features, 2).unwrap();
        assert!(profiles.distances(&[0, 1], 8).is_err());
    }
    let profiles = CellProfiles::new(&[0.0, 1e-200], 1, 2).unwrap();
    assert_eq!(profiles.distances(&[0, 1], 8).unwrap()[0].to_bits(), 0);
}

#[test]
fn exact_output_budget_and_shared_condensed_contract() {
    let profiles = CellProfiles::new(&[0.0, 1.0, 2.0], 1, 3).unwrap();
    assert!(profiles.distances(&[0, 1, 2], 24).is_ok());
    assert!(profiles.distances(&[0, 1, 2], 23).is_err());
    assert!(profiles.distances(&[0, 1], 7).is_err());
    for n in 2..12 {
        let mut next = 0;
        for i in 0..n {
            for j in i + 1..n {
                assert_eq!(condensed::condensed_index(n, i, j), next);
                assert_eq!(condensed::condensed_index(n, j, i), next);
                next += 1;
            }
        }
        assert_eq!(condensed::pair_count(n).unwrap(), next);
    }
    for n in [0, 1, i32::MAX as usize + 1, usize::MAX] {
        assert!(condensed::pair_count(n).is_err());
    }
}

#[test]
fn parallel_chunks_preserve_every_pair_bit_and_propagate_arithmetic_errors() {
    let features = 101;
    let cells = 19;
    let values = (0..features * cells)
        .map(|index| ((index * 17) % 997) as f64 / 13.0)
        .collect::<Vec<_>>();
    let profiles = CellProfiles::new(&values, features, cells).unwrap();
    let indices = (0..cells).rev().collect::<Vec<_>>();
    let expected = profiles.distances(&indices, usize::MAX).unwrap();
    for workers in [1, 2, 4, 64] {
        let actual = profiles
            .distances_with_threads(&indices, usize::MAX, workers)
            .unwrap();
        assert_eq!(
            actual
                .iter()
                .map(|value| value.to_bits())
                .collect::<Vec<_>>(),
            expected
                .iter()
                .map(|value| value.to_bits())
                .collect::<Vec<_>>()
        );
    }
    assert!(
        profiles
            .distances_with_threads(&indices, usize::MAX, 0)
            .is_err()
    );
    let overflow = CellProfiles::new(&[f64::MAX, -f64::MAX, 0.0], 1, 3).unwrap();
    assert!(overflow.distances_with_threads(&[0, 1, 2], 24, 2).is_err());
}
