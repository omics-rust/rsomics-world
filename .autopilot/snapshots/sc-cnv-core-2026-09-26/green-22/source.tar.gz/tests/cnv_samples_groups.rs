use rsomics_sc::cnv::{
    CreatedInput, CreationConfig, InputPaths, PreparedCounts, SamplesConfig, create_input, samples,
};
use std::fs;
use std::path::PathBuf;
use std::sync::atomic::{AtomicUsize, Ordering};

static NEXT_FIXTURE: AtomicUsize = AtomicUsize::new(0);

struct Fixture(PathBuf);

impl Fixture {
    fn create(
        counts: &str,
        positions: &str,
        annotations: &str,
        references: &[&str],
    ) -> CreatedInput {
        let fixture = Self(std::env::temp_dir().join(format!(
            "rsomics-cnv-samples-{}-{}",
            std::process::id(),
            NEXT_FIXTURE.fetch_add(1, Ordering::Relaxed)
        )));
        fs::create_dir(&fixture.0).unwrap();
        let counts_path = fixture.0.join("counts.tsv");
        let positions_path = fixture.0.join("positions.tsv");
        let annotations_path = fixture.0.join("annotations.tsv");
        fs::write(&counts_path, counts).unwrap();
        fs::write(&positions_path, positions).unwrap();
        fs::write(&annotations_path, annotations).unwrap();
        create_input(
            InputPaths {
                counts: &counts_path,
                positions: &positions_path,
                annotations: &annotations_path,
            },
            &CreationConfig {
                reference_groups: references.iter().map(|name| (*name).into()).collect(),
                excluded_chromosomes: vec![],
                min_counts_per_cell: 1.0,
                max_counts_per_cell: f64::INFINITY,
                max_numeric_bytes: 1 << 20,
                max_record_bytes: 4096,
            },
        )
        .unwrap()
    }
}

impl Drop for Fixture {
    fn drop(&mut self) {
        fs::remove_dir_all(&self.0).unwrap();
    }
}

fn config(grouped: bool) -> SamplesConfig {
    SamplesConfig {
        cluster_by_groups: grouped,
        z_score_filter: 0.0,
        threads: 1,
        max_workspace_bytes: 1 << 20,
    }
}

#[test]
fn created_maps_determine_group_order_and_pooled_global_members() {
    let input = Fixture::create(
        "gene\tc0\tr\tc2\tc3\ng\t1\t9\t2\t4\n",
        "g\tchr1\t1\t2\n",
        "c0\tZ\nr\tref\nc2\tA\nc3\tZ\n",
        &["ref"],
    );
    let state = input.prepared_counts().state();
    let grouped = samples(state, &input, &config(true)).unwrap();
    assert_eq!(
        grouped
            .groups
            .iter()
            .map(|g| g.name.as_str())
            .collect::<Vec<_>>(),
        ["A", "Z", "ref"]
    );
    assert_eq!(grouped.groups[0].member_indices, [2]);
    assert_eq!(grouped.groups[1].member_indices, [0, 3]);
    assert!(grouped.groups.iter().all(|g| g.tree.is_none()));

    let pooled = samples(state, &input, &config(false)).unwrap();
    assert_eq!(pooled.groups[0].name, "all_observations");
    assert_eq!(pooled.groups[0].subcluster_name, "all_observations_s1");
    let tree = pooled.groups[0].tree.as_ref().unwrap();
    assert_eq!(tree.merge, [[-1, -2], [-3, 1]]);
    assert_eq!(tree.order, [2, 0, 1]);
    assert_eq!(tree.height[0], 1.0);
    assert_eq!(pooled.groups[0].member_indices, [3, 2, 0]);
    assert_eq!(pooled.groups[1].name, "ref");
    assert_eq!(pooled.groups[1].member_indices, [1]);
}

#[test]
fn reference_only_has_no_fabricated_empty_observation_group() {
    let input = Fixture::create(
        "gene\tc0\tc1\tc2\ng\t1\t2\t4\n",
        "g\tchr1\t1\t2\n",
        "c0\tref\nc1\tref\nc2\tref\n",
        &["ref"],
    );
    for grouped in [true, false] {
        let result = samples(input.prepared_counts().state(), &input, &config(grouped)).unwrap();
        assert_eq!(result.groups.len(), 1);
        assert_eq!(result.groups[0].name, "ref");
        assert_eq!(result.groups[0].subcluster_name, "ref_s1");
        assert_eq!(result.groups[0].member_indices, [2, 0, 1]);
        assert_eq!(result.groups[0].tree.as_ref().unwrap().order, [2, 0, 1]);
    }
}

#[test]
fn observations_precede_the_requested_reference_order() {
    let input = Fixture::create(
        "gene\tr0\to\tr1\ng\t1\t2\t3\n",
        "g\tchr1\t1\t2\n",
        "r0\tfirst\no\tobs\nr1\tlast\n",
        &["last", "first"],
    );
    for grouped in [true, false] {
        let result = samples(input.prepared_counts().state(), &input, &config(grouped)).unwrap();
        assert_eq!(result.groups[0].member_indices, [1]);
        assert_eq!(result.groups[1].name, "last");
        assert_eq!(result.groups[1].member_indices, [2]);
        assert_eq!(result.groups[2].name, "first");
        assert_eq!(result.groups[2].member_indices, [0]);
    }
}

#[test]
fn constant_reference_filter_is_temporary_and_zero_gene_trees_remain_valid() {
    let input = Fixture::create(
        "gene\to1\to2\to3\tr1\tr2\ng1\t1\t2\t4\t1\t1\ng2\t1\t3\t5\t1\t1\n",
        "g1\tchr1\t1\t2\ng2\tchr1\t3\t4\n",
        "o1\tobs\no2\tobs\no3\tobs\nr1\tref\nr2\tref\n",
        &["ref"],
    );
    let state = input.prepared_counts().state();
    let before = state
        .values()
        .iter()
        .map(|x| x.to_bits())
        .collect::<Vec<_>>();
    let mut options = config(true);
    options.z_score_filter = 0.2;
    let result = samples(state, &input, &options).unwrap();
    assert_eq!(result.outlier_gene_indices, Some(vec![]));
    assert!(result.selected_gene_indices.is_empty());
    assert_eq!(result.groups[0].member_indices, [2, 0, 1]);
    assert_eq!(result.groups[0].tree.as_ref().unwrap().height, [0.0, 0.0]);
    assert_eq!(result.groups[1].member_indices, [3, 4]);
    assert_eq!(
        state
            .values()
            .iter()
            .map(|x| x.to_bits())
            .collect::<Vec<_>>(),
        before
    );
    assert_eq!(input.observation_groups()[0].cell_indices(), [0, 1, 2]);
    assert_eq!(input.reference_groups()[0].cell_indices(), [3, 4]);
}

#[test]
fn selected_profiles_and_both_selection_buffers_share_the_kernel_budget() {
    let input = Fixture::create(
        "gene\to1\to2\to3\tr1\tr2\ng1\t1\t2\t4\t1\t1\ng2\t2\t2\t2\t1\t1\ng3\t100\t200\t300\t5\t5\n",
        "g1\tchr1\t1\t2\ng2\tchr1\t3\t4\ng3\tchr1\t5\t6\n",
        "o1\tobs\no2\tobs\no3\tobs\nr1\tref\nr2\tref\n",
        &["ref"],
    );
    let state = input.prepared_counts().state();
    for (grouped, exact) in [(true, 460), (false, 484)] {
        let mut options = config(grouped);
        options.z_score_filter = 0.8;
        options.max_workspace_bytes = exact;
        let result = samples(state, &input, &options).unwrap();
        assert_eq!(result.outlier_gene_indices, Some(vec![2]));
        assert_eq!(result.selected_gene_indices, [0, 1]);
        assert_eq!(result.groups[0].member_indices, [2, 0, 1]);
        assert_eq!(result.groups[0].tree.as_ref().unwrap().height[0], 1.0);
        assert_eq!(state.gene_count(), 3);
        assert_eq!(state.value(2, 2), Some(300.0));
        options.max_workspace_bytes -= 1;
        assert!(samples(state, &input, &options).is_err());
    }
}

#[test]
fn mismatched_cell_identity_fails_before_singleton_bypass() {
    let input = Fixture::create("gene\tc\ng\t1\n", "g\tchr1\t1\t2\n", "c\tobs\n", &[]);
    let original = input.prepared_counts().state();
    let mut cells = original.cells().to_vec();
    cells[0].id = "different".into();
    let changed = PreparedCounts::new(original.genes().to_vec(), cells, vec![1.0]).unwrap();
    assert!(samples(changed.state(), &input, &config(true)).is_err());
}

#[test]
fn pooled_reference_name_collision_fails_explicitly_but_grouped_is_valid() {
    let input = Fixture::create(
        "gene\to\tr\ng\t1\t2\n",
        "g\tchr1\t1\t2\n",
        "o\tobs\nr\tall_observations\n",
        &["all_observations"],
    );
    let state = input.prepared_counts().state();
    assert!(samples(state, &input, &config(true)).is_ok());
    let message = samples(state, &input, &config(false))
        .unwrap_err()
        .to_string();
    assert!(message.contains("all_observations"));
    assert!(message.contains("pooled"));
}

#[test]
fn budget_includes_prior_trees_and_members_and_pooled_indices() {
    let input = Fixture::create(
        "gene\ta0\tb0\tr\ta1\tb1\ta2\tb2\ng\t1\t1\t1\t1\t1\t1\t1\n",
        "g\tchr1\t1\t2\n",
        "a0\tA\nb0\tB\nr\tref\na1\tA\nb1\tB\na2\tA\nb2\tB\n",
        &["ref"],
    );
    let state = input.prepared_counts().state();
    for (grouped, exact) in [(true, 420), (false, 904)] {
        let mut options = config(grouped);
        options.max_workspace_bytes = exact;
        assert!(samples(state, &input, &options).is_ok());
        options.max_workspace_bytes -= 1;
        assert!(samples(state, &input, &options).is_err());
    }
}
