use super::CreatedInput;
use super::model::CnvState;
use super::parallel::for_chunks;
use rsomics_common::{Result, RsomicsError};

#[derive(Clone, Copy, Debug)]
pub enum NoiseFilter {
    Fixed(f64),
    ReferenceSd(f64),
}

#[derive(Clone, Copy, Debug)]
pub struct DenoiseConfig {
    filter: NoiseFilter,
    logistic: bool,
    threads: usize,
    max_numeric_bytes: usize,
}

impl DenoiseConfig {
    pub fn new(
        filter: NoiseFilter,
        logistic: bool,
        threads: usize,
        max_numeric_bytes: usize,
    ) -> Result<Self> {
        let valid_filter = match filter {
            NoiseFilter::Fixed(value) => value.is_finite(),
            NoiseFilter::ReferenceSd(value) => value.is_finite() && value >= 0.0,
        };
        if !valid_filter {
            return Err(RsomicsError::ConfigError(
                "noise filter must be finite; SD amplifier must also be nonnegative".into(),
            ));
        }
        if threads == 0 || max_numeric_bytes == 0 {
            return Err(RsomicsError::ConfigError(
                "denoise worker count and numeric byte limit must be positive".into(),
            ));
        }
        Ok(Self {
            filter,
            logistic,
            threads,
            max_numeric_bytes,
        })
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct NoiseBounds {
    pub center: f64,
    pub threshold: f64,
}

/// Step-22 values in the source state's unchanged gene/cell order.
#[derive(Debug)]
pub struct Denoised {
    values: Vec<f64>,
    bounds: Option<NoiseBounds>,
}

impl Denoised {
    pub fn values(&self) -> &[f64] {
        &self.values
    }

    pub fn bounds(&self) -> Option<NoiseBounds> {
        self.bounds
    }
}

pub fn denoise(state: &CnvState, input: &CreatedInput, config: &DenoiseConfig) -> Result<Denoised> {
    if state.cells() != input.prepared_counts().state().cells() {
        return Err(RsomicsError::InvalidInput(
            "Denoise state cell identities differ from created input".into(),
        ));
    }
    let proxy_count = if input.reference_groups().is_empty() {
        state.cell_count()
    } else {
        0
    };
    let references = input
        .reference_groups()
        .iter()
        .flat_map(|group| group.cell_indices().iter().copied())
        .chain(0..proxy_count);
    denoise_values(state.values(), state.gene_count(), references, config)
}

fn denoise_values(
    source: &[f64],
    genes: usize,
    references: impl Iterator<Item = usize> + Clone,
    config: &DenoiseConfig,
) -> Result<Denoised> {
    if std::mem::size_of_val(source) > config.max_numeric_bytes {
        return Err(RsomicsError::InvalidInput(
            "denoised values exceed the numeric byte limit".into(),
        ));
    }
    let bounds = noise_bounds(source, genes, references, config.filter)?;
    let mut values = Vec::new();
    values
        .try_reserve_exact(source.len())
        .map_err(|_| RsomicsError::InvalidInput("denoising allocation failed".into()))?;
    values.extend_from_slice(source);
    if let Some(bounds) = bounds {
        let cells = values.len() / genes;
        let workers = config.threads.min(cells);
        let chunk_len = cells.div_ceil(workers) * genes;
        for_chunks(&mut values, chunk_len, |_, output| {
            transform(output, bounds, config.logistic)
        })?;
    }
    Ok(Denoised { values, bounds })
}

fn noise_bounds(
    values: &[f64],
    genes: usize,
    references: impl Iterator<Item = usize> + Clone,
    filter: NoiseFilter,
) -> Result<Option<NoiseBounds>> {
    if matches!(filter, NoiseFilter::Fixed(width) if width <= 0.0) {
        return Ok(None);
    }
    let count = references.clone().count();
    let columns = references
        .clone()
        .map(|cell| &values[cell * genes..(cell + 1) * genes]);
    let center = mean(
        columns.clone().flat_map(|column| column.iter().copied()),
        count * genes,
    )?;
    let threshold = match filter {
        NoiseFilter::Fixed(width) => width,
        NoiseFilter::ReferenceSd(amplifier) => {
            if genes < 2 {
                return Err(RsomicsError::InvalidInput(
                    "SD denoising requires at least two genes".into(),
                ));
            }
            let mut average_sd = 0.0;
            for column in columns {
                let average = mean(column.iter().copied(), genes)?;
                let squares = column
                    .iter()
                    .map(|value| (value - average).powi(2))
                    .sum::<f64>();
                average_sd += (squares / (genes - 1) as f64).sqrt() / count as f64;
            }
            average_sd * amplifier
        }
    };
    if !threshold.is_finite() {
        return Err(nonfinite());
    }
    Ok(Some(NoiseBounds { center, threshold }))
}

fn mean(values: impl Iterator<Item = f64> + Clone, count: usize) -> Result<f64> {
    let count = count as f64;
    let average = values.clone().map(|value| value / count).sum::<f64>();
    let corrected = average + values.map(|value| (value - average) / count).sum::<f64>();
    if !corrected.is_finite() {
        return Err(nonfinite());
    }
    Ok(corrected)
}

fn transform(values: &mut [f64], bounds: NoiseBounds, logistic: bool) -> Result<()> {
    let NoiseBounds { center, threshold } = bounds;
    if logistic {
        for value in values {
            let deviation = (*value - center).abs();
            let weight = 1.0 / (1.0 + (-20.0 * (deviation - threshold)).exp());
            if *value > center {
                *value = center + weight * deviation;
            } else if *value < center {
                *value = center - weight * deviation;
            }
            if !value.is_finite() {
                return Err(nonfinite());
            }
        }
    } else {
        let lower = center - threshold;
        let upper = center + threshold;
        for value in values {
            if *value > lower && *value < upper {
                *value = center;
            }
        }
    }
    Ok(())
}

fn nonfinite() -> RsomicsError {
    RsomicsError::InvalidInput("denoising reduction or result is nonfinite".into())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn config(filter: NoiseFilter, logistic: bool, threads: usize) -> DenoiseConfig {
        DenoiseConfig::new(filter, logistic, threads, 4096).unwrap()
    }

    fn close(actual: f64, expected: f64) {
        assert!((actual - expected).abs() < 1e-12, "{actual} != {expected}");
    }

    #[test]
    fn hard_filter_uses_one_pooled_center_and_keeps_exact_bounds() {
        let values = [0.0, 2.0, 2.0, 4.0, 4.0, 6.0, 3.0, 3.5];
        let output =
            denoise_values(&values, 2, 0..3, &config(NoiseFilter::Fixed(1.0), false, 1)).unwrap();
        assert_eq!(
            output.bounds(),
            Some(NoiseBounds {
                center: 3.0,
                threshold: 1.0
            })
        );
        assert_eq!(output.values(), [0.0, 2.0, 2.0, 4.0, 4.0, 6.0, 3.0, 3.0]);
        assert_eq!(values[7], 3.5);
    }

    #[test]
    fn sd_width_is_mean_cell_sd_across_genes_not_gene_sd_across_cells() {
        let values = [0.9, 1.1, 1.8, 2.2, 1.5, 1.7];
        let output = denoise_values(
            &values,
            2,
            0..2,
            &config(NoiseFilter::ReferenceSd(1.5), false, 1),
        )
        .unwrap();
        let bounds = output.bounds().unwrap();
        close(bounds.center, 1.5);
        close(bounds.threshold, 0.3181980515339464);
        assert_eq!(output.values(), [0.9, 1.1, 1.5, 2.2, 1.5, 1.5]);
    }

    #[test]
    fn logistic_midpoint_and_tails_match_independent_values() {
        let values = [1.0, 1.0, 0.8, 1.2, 0.5, 1.5];
        let output =
            denoise_values(&values, 2, 0..1, &config(NoiseFilter::Fixed(0.2), true, 1)).unwrap();
        for (&actual, expected) in
            output
                .values()
                .iter()
                .zip([1.0, 1.0, 0.9, 1.1, 0.5012363115783174, 1.4987636884216826])
        {
            close(actual, expected);
        }
    }

    #[test]
    fn fixed_nonpositive_bypasses_but_sd_zero_still_applies_logistic() {
        let values = [1.0, 1.0, 0.8, 1.2];
        for threshold in [0.0, -1.0] {
            let output = denoise_values(
                &values,
                2,
                0..1,
                &config(NoiseFilter::Fixed(threshold), true, 2),
            )
            .unwrap();
            assert_eq!(output.bounds(), None);
            assert_eq!(output.values(), values);
        }
        let output = denoise_values(
            &values,
            2,
            0..1,
            &config(NoiseFilter::ReferenceSd(1.5), true, 2),
        )
        .unwrap();
        assert_eq!(
            output.bounds(),
            Some(NoiseBounds {
                center: 1.0,
                threshold: 0.0
            })
        );
        close(output.values()[2], 0.8035972419924183);
        close(output.values()[3], 1.1964027580075817);
    }

    #[test]
    fn uneven_column_chunks_are_bitwise_identical_across_workers() {
        let values: Vec<_> = (0..21).map(|i| 0.5 + i as f64 / 19.0).collect();
        for filter in [NoiseFilter::Fixed(0.3), NoiseFilter::ReferenceSd(1.5)] {
            for logistic in [false, true] {
                let serial =
                    denoise_values(&values, 3, 0..2, &config(filter, logistic, 1)).unwrap();
                for workers in [2, 4, 16] {
                    let parallel =
                        denoise_values(&values, 3, 0..2, &config(filter, logistic, workers))
                            .unwrap();
                    assert_eq!(parallel.bounds(), serial.bounds());
                    let actual: Vec<_> = parallel.values().iter().map(|x| x.to_bits()).collect();
                    let expected: Vec<_> = serial.values().iter().map(|x| x.to_bits()).collect();
                    assert_eq!(actual, expected);
                }
            }
        }
    }

    #[test]
    fn invalid_configuration_insufficient_budget_and_undefined_sd_fail() {
        for (filter, threads, budget) in [
            (NoiseFilter::Fixed(f64::NAN), 1, 4096),
            (NoiseFilter::Fixed(f64::INFINITY), 1, 4096),
            (NoiseFilter::ReferenceSd(-1.0), 1, 4096),
            (NoiseFilter::ReferenceSd(1.5), 0, 4096),
            (NoiseFilter::ReferenceSd(1.5), 1, 0),
        ] {
            assert!(DenoiseConfig::new(filter, false, threads, budget).is_err());
        }
        let small_budget = DenoiseConfig::new(NoiseFilter::Fixed(0.1), false, 1, 15).unwrap();
        assert!(denoise_values(&[1.0, 2.0], 2, 0..1, &small_budget).is_err());
        assert!(
            denoise_values(
                &[1.0, 2.0],
                1,
                0..1,
                &config(NoiseFilter::ReferenceSd(1.5), false, 1)
            )
            .is_err()
        );
    }
}
