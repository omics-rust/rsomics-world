use super::distance::CellProfiles;
use rsomics_common::{Result, RsomicsError};
use std::mem::size_of;

pub(crate) struct GeneSelection {
    pub(crate) outliers: Option<Vec<usize>>,
    pub(crate) selected: Vec<usize>,
}

fn invalid(message: &str) -> RsomicsError {
    RsomicsError::InvalidInput(message.into())
}

pub(crate) fn required_workspace(
    features: usize,
    reference_count: usize,
    active: bool,
) -> Result<usize> {
    let validation = reference_count.checked_mul(size_of::<usize>());
    let outputs = features
        .checked_mul(if active { 2 } else { 1 })
        .and_then(|count| count.checked_mul(size_of::<usize>()));
    match (validation, outputs) {
        (Some(validation), Some(outputs)) => Ok(validation.max(outputs)),
        _ => Err(invalid("Gene filtering workspace size overflows")),
    }
}

fn indices(length: usize) -> Result<Vec<usize>> {
    let mut values = Vec::new();
    values
        .try_reserve_exact(length)
        .map_err(|_| invalid("Gene filtering workspace allocation failed"))?;
    Ok(values)
}

fn corrected_mean(values: impl Iterator<Item = f64> + Clone, count: usize) -> Result<f64> {
    let total: f64 = values.clone().sum();
    let mean = total / count as f64;
    let correction: f64 = values.map(|value| value - mean).sum();
    let corrected = mean + correction / count as f64;
    if !total.is_finite() || !correction.is_finite() || !corrected.is_finite() {
        return Err(invalid("Gene filtering mean arithmetic is not finite"));
    }
    Ok(corrected)
}

pub(crate) fn select_genes(
    profiles: &CellProfiles<'_>,
    references: &[usize],
    z_score_filter: f64,
    max_workspace_bytes: usize,
) -> Result<GeneSelection> {
    if !z_score_filter.is_finite() {
        return Err(invalid("Gene filter argument must be finite"));
    }
    let features = profiles.feature_count();
    let active = z_score_filter > 0.0 && !references.is_empty();
    if required_workspace(features, references.len(), active)? > max_workspace_bytes {
        return Err(invalid("Gene filtering exceeds the workspace budget"));
    }
    let mut sorted = indices(references.len())?;
    sorted.extend_from_slice(references);
    sorted.sort_unstable();
    if sorted
        .last()
        .is_some_and(|&index| index >= profiles.cell_count())
        || sorted.windows(2).any(|pair| pair[0] == pair[1])
    {
        return Err(invalid("Reference indices must be distinct and in range"));
    }
    drop(sorted);

    let mut selected = indices(features)?;
    if !active {
        selected.extend(0..features);
        return Ok(GeneSelection {
            outliers: None,
            selected,
        });
    }
    let mut outliers = indices(features)?;
    let count = features
        .checked_mul(references.len())
        .filter(|&count| count > 1)
        .ok_or_else(|| invalid("Active gene filtering requires at least two reference values"))?;
    let values = references
        .iter()
        .flat_map(|&index| profiles.column(index).iter().copied());
    let mean = corrected_mean(values.clone(), count)?;
    let covariance_mean = corrected_mean(values.clone(), count)?;
    let sum: f64 = values
        .clone()
        .map(|value| {
            let delta = value - covariance_mean;
            delta * delta
        })
        .sum();
    let variance = sum / (count - 1) as f64;
    if !sum.is_finite() || !variance.is_finite() {
        return Err(invalid("Gene filtering variance arithmetic is not finite"));
    }
    let sd = variance.sqrt();
    if sd == 0.0 {
        let first = profiles.column(references[0])[0];
        if values.clone().any(|value| value != first) {
            return Err(invalid("Nonconstant reference variance underflows to zero"));
        }
        return Ok(GeneSelection {
            outliers: Some(outliers),
            selected,
        });
    }

    for gene in 0..features {
        let scores = references
            .iter()
            .map(|&index| ((profiles.column(index)[gene] - mean) / sd).abs());
        let score = corrected_mean(scores, references.len())?;
        if score >= 0.8 {
            outliers.push(gene);
        }
    }
    // R's negative integer(0) subscript selects no rows, not all rows.
    if !outliers.is_empty() {
        let mut excluded = outliers.iter().copied().peekable();
        for gene in 0..features {
            if excluded.peek() == Some(&gene) {
                excluded.next();
            } else {
                selected.push(gene);
            }
        }
    }
    Ok(GeneSelection {
        outliers: Some(outliers),
        selected,
    })
}
