use rsomics_common::{Result, RsomicsError};

pub(crate) fn pair_count(leaves: usize) -> Result<usize> {
    if leaves < 2 || leaves > i32::MAX as usize {
        return Err(RsomicsError::InvalidInput(
            "Ward.D2 requires 2..=i32::MAX leaves".into(),
        ));
    }
    leaves
        .checked_mul(leaves - 1)
        .map(|pairs| pairs / 2)
        .ok_or_else(|| RsomicsError::InvalidInput("Ward.D2 dimensions overflow".into()))
}

pub(crate) fn condensed_index(n: usize, a: usize, b: usize) -> usize {
    let (i, j) = if a < b { (a, b) } else { (b, a) };
    n * i - i * (i + 1) / 2 + j - i - 1
}
