use super::condensed::{condensed_index, pair_count};
use rsomics_common::{Result, RsomicsError};
use std::mem::size_of;

#[derive(Debug)]
pub(crate) struct Dendrogram {
    pub(crate) merge: Vec<[i32; 2]>,
    pub(crate) height: Vec<f64>,
    pub(crate) order: Vec<usize>,
}

struct RawMerge {
    left: usize,
    right: usize,
    height: f64,
    ordinal: usize,
}

impl RawMerge {
    fn new(left: usize, right: usize, squared_height: f64, ordinal: usize) -> Self {
        Self {
            left,
            right,
            height: squared_height.sqrt(),
            ordinal,
        }
    }
}

fn invalid(message: &str) -> RsomicsError {
    RsomicsError::InvalidInput(message.into())
}

pub(crate) fn required_workspace(leaves: usize) -> Result<usize> {
    let pairs = pair_count(leaves)?;
    let buffers = [
        (pairs, size_of::<f64>()),
        (leaves + 1, size_of::<usize>()),
        (leaves + 1, size_of::<usize>()),
        (leaves, size_of::<usize>()),
        (leaves, size_of::<f64>()),
        (leaves - 1, size_of::<RawMerge>()),
        (2 * leaves - 1, size_of::<usize>()),
        (leaves - 1, size_of::<[i32; 2]>()),
        (leaves - 1, size_of::<f64>()),
        (leaves, size_of::<usize>()),
        (leaves, size_of::<i32>()),
    ];
    buffers
        .into_iter()
        .try_fold(0usize, |total, (count, size)| {
            count
                .checked_mul(size)
                .and_then(|bytes| total.checked_add(bytes))
                .ok_or_else(|| invalid("Ward.D2 workspace size overflows"))
        })
}

fn reserved<T>(length: usize) -> Result<Vec<T>> {
    let mut values = Vec::new();
    values
        .try_reserve_exact(length)
        .map_err(|_| invalid("Ward.D2 workspace allocation failed"))?;
    Ok(values)
}

fn zeros<T: Default + Clone>(length: usize) -> Result<Vec<T>> {
    let mut values = reserved(length)?;
    values.resize(length, T::default());
    Ok(values)
}

pub(crate) fn ward_d2(
    distances: &[f64],
    leaves: usize,
    max_workspace_bytes: usize,
) -> Result<Dendrogram> {
    let pairs = pair_count(leaves)?;
    if distances.len() != pairs {
        return Err(invalid(
            "Ward.D2 condensed distance length does not match leaves",
        ));
    }
    if required_workspace(leaves)? > max_workspace_bytes {
        return Err(invalid("Ward.D2 exceeds the numeric workspace budget"));
    }
    if distances
        .iter()
        .any(|&v| !v.is_finite() || v < 0.0 || !(v * v).is_finite())
    {
        return Err(invalid(
            "Ward.D2 distances and their squares must be finite and nonnegative",
        ));
    }

    let mut squared = reserved::<f64>(pairs)?;
    squared.extend(distances.iter().map(|v| v * v));
    let mut successors = zeros::<usize>(leaves + 1)?;
    let mut predecessors = zeros::<usize>(leaves + 1)?;
    for i in 0..leaves {
        successors[i] = i + 1;
        predecessors[i + 1] = i;
    }
    let mut chain = zeros::<usize>(leaves)?;
    let mut members = zeros::<f64>(leaves)?;
    members.fill(1.0);
    let mut merges = reserved::<RawMerge>(leaves - 1)?;
    let mut tip = 0;
    let mut start = 0;

    for ordinal in 0..leaves - 1 {
        let (mut left, mut right, mut minimum);
        if tip <= 3 {
            left = start;
            chain[0] = left;
            tip = 1;
            right = successors[left];
            minimum = squared[condensed_index(leaves, left, right)];
            let mut i = successors[right];
            while i < leaves {
                let distance = squared[condensed_index(leaves, left, i)];
                if distance < minimum {
                    minimum = distance;
                    right = i;
                }
                i = successors[i];
            }
        } else {
            tip -= 3;
            left = chain[tip - 1];
            right = chain[tip];
            minimum = squared[condensed_index(leaves, left, right)];
        }

        loop {
            chain[tip] = right;
            let mut i = start;
            while i < right {
                let distance = squared[condensed_index(leaves, i, right)];
                if distance < minimum {
                    minimum = distance;
                    left = i;
                }
                i = successors[i];
            }
            i = successors[right];
            while i < leaves {
                let distance = squared[condensed_index(leaves, right, i)];
                if distance < minimum {
                    minimum = distance;
                    left = i;
                }
                i = successors[i];
            }
            right = left;
            left = chain[tip];
            tip += 1;
            if right == chain[tip - 2] {
                break;
            }
        }

        merges.push(RawMerge::new(left, right, minimum, ordinal));
        if left > right {
            std::mem::swap(&mut left, &mut right);
        }
        let s = members[left];
        let t = members[right];
        members[right] += s;
        if left == start {
            start = successors[left];
        } else {
            successors[predecessors[left]] = successors[left];
            predecessors[successors[left]] = predecessors[left];
        }
        successors[left] = 0;

        let mut i = start;
        while i < leaves {
            if i != right {
                let a = squared[condensed_index(leaves, i, left)];
                let target = condensed_index(leaves, i, right);
                let b = squared[target];
                let v = members[i];
                let updated = ((v + s) * a - v * minimum + (v + t) * b) / (s + t + v);
                if !updated.is_finite() || updated < 0.0 {
                    return Err(invalid("Ward.D2 update is nonfinite or negative"));
                }
                squared[target] = updated;
            }
            i = successors[i];
        }
    }
    dendrogram(merges, leaves)
}

fn root(parents: &mut [usize], mut node: usize) -> usize {
    let mut top = node;
    while parents[top] != 0 {
        top = parents[top];
    }
    while parents[node] != 0 {
        let next = parents[node];
        parents[node] = top;
        node = next;
    }
    top
}

fn r_node(node: usize, leaves: usize) -> i32 {
    if node < leaves {
        -(node as i32) - 1
    } else {
        (node - leaves + 1) as i32
    }
}

fn dendrogram(mut raw: Vec<RawMerge>, leaves: usize) -> Result<Dendrogram> {
    raw.sort_unstable_by(|a, b| {
        a.height
            .total_cmp(&b.height)
            .then_with(|| a.ordinal.cmp(&b.ordinal))
    });
    let mut parents = zeros::<usize>(2 * leaves - 1)?;
    let mut merge = reserved::<[i32; 2]>(leaves - 1)?;
    let mut height = reserved::<f64>(leaves - 1)?;
    for (row, item) in raw.iter().enumerate() {
        let a = root(&mut parents, item.left);
        let b = root(&mut parents, item.right);
        parents[a] = leaves + row;
        parents[b] = leaves + row;
        let (left, right) = if a < b { (a, b) } else { (b, a) };
        merge.push([r_node(left, leaves), r_node(right, leaves)]);
        height.push(item.height);
    }
    let mut stack = reserved::<i32>(leaves)?;
    let mut order = reserved::<usize>(leaves)?;
    stack.push((leaves - 1) as i32);
    while let Some(node) = stack.pop() {
        if node < 0 {
            order.push((-node - 1) as usize);
        } else {
            let [left, right] = merge[node as usize - 1];
            stack.push(right);
            stack.push(left);
        }
    }
    Ok(Dendrogram {
        merge,
        height,
        order,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rounded_square_root_ties_keep_raw_merge_order() {
        let low = 1.0f64;
        let high = f64::from_bits(low.to_bits() + 1);
        assert!(high > low);
        assert_eq!(high.sqrt().to_bits(), low.sqrt().to_bits());
        let raw = vec![
            RawMerge::new(2, 3, high, 0),
            RawMerge::new(0, 1, low, 1),
            RawMerge::new(1, 3, 16.0, 2),
        ];
        let tree = dendrogram(raw, 4).unwrap();
        assert_eq!(tree.merge, [[-3, -4], [-1, -2], [1, 2]]);
        assert_eq!(tree.order, [2, 3, 0, 1]);
        assert_eq!(tree.height, [1.0, 1.0, 4.0]);
    }
}
