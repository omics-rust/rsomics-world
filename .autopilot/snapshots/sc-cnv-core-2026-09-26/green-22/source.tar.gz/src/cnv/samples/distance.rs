use super::condensed::{condensed_index, pair_count};
use super::parallel::for_chunks;
use rsomics_common::{Result, RsomicsError};
use std::mem::size_of;

pub(crate) struct CellProfiles<'a> {
    values: &'a [f64],
    features: usize,
    cells: usize,
}

fn invalid(message: &str) -> RsomicsError {
    RsomicsError::InvalidInput(message.into())
}

impl<'a> CellProfiles<'a> {
    #[cfg(test)]
    #[allow(dead_code)]
    pub(crate) fn new(values: &'a [f64], features: usize, cells: usize) -> Result<Self> {
        if cells == 0 || features.checked_mul(cells) != Some(values.len()) {
            return Err(invalid("Cell profile dimensions do not match values"));
        }
        if values.iter().any(|value| !value.is_finite()) {
            return Err(invalid("Cell profiles must be finite"));
        }
        Ok(Self::validated(values, features, cells))
    }

    pub(crate) fn validated(values: &'a [f64], features: usize, cells: usize) -> Self {
        Self {
            values,
            features,
            cells,
        }
    }

    pub(crate) fn feature_count(&self) -> usize {
        self.features
    }

    pub(crate) fn cell_count(&self) -> usize {
        self.cells
    }

    #[cfg(test)]
    #[allow(dead_code)]
    pub(crate) fn distances(
        &self,
        indices: &[usize],
        max_numeric_bytes: usize,
    ) -> Result<Vec<f64>> {
        self.distances_with_threads(indices, max_numeric_bytes, 1)
    }

    pub(crate) fn distances_with_threads(
        &self,
        indices: &[usize],
        max_numeric_bytes: usize,
        threads: usize,
    ) -> Result<Vec<f64>> {
        if threads == 0 {
            return Err(invalid("Distance worker count must be positive"));
        }
        let pairs = pair_count(indices.len())?;
        let bytes = pairs
            .checked_mul(size_of::<f64>())
            .ok_or_else(|| invalid("Distance output size overflows"))?;
        if bytes > max_numeric_bytes {
            return Err(invalid("Distances exceed the numeric output budget"));
        }
        for (position, &index) in indices.iter().enumerate() {
            if index >= self.cell_count() || indices[..position].contains(&index) {
                return Err(invalid("Cell indices must be distinct and in range"));
            }
        }
        let mut distances = Vec::new();
        distances
            .try_reserve_exact(pairs)
            .map_err(|_| invalid("Distance output allocation failed"))?;
        distances.resize(pairs, 0.0);
        let workers = threads.min(indices.len() - 1);
        if workers == 1 || self.features == 0 {
            for (i, &left) in indices.iter().enumerate() {
                for (j, &right) in indices.iter().enumerate().skip(i + 1) {
                    distances[condensed_index(indices.len(), i, j)] = self.distance(left, right)?;
                }
            }
            return Ok(distances);
        }
        let chunk_size = pairs.div_ceil(workers);
        for_chunks(&mut distances, chunk_size, |chunk, output| {
            let (mut left, mut right) = pair_at_offset(indices.len(), chunk * chunk_size);
            for value in output {
                *value = self.distance(indices[left], indices[right])?;
                right += 1;
                if right == indices.len() {
                    left += 1;
                    right = left + 1;
                }
            }
            Ok(())
        })?;
        Ok(distances)
    }

    fn distance(&self, left: usize, right: usize) -> Result<f64> {
        let left = self.column(left);
        let right = self.column(right);
        let mut even = 0.0;
        let mut odd = 0.0;
        let mut feature = 0;
        while feature + 1 < self.features {
            let a = left[feature] - right[feature];
            let b = left[feature + 1] - right[feature + 1];
            even += a * a;
            odd += b * b;
            feature += 2;
        }
        if feature < self.features {
            let a = left[feature] - right[feature];
            even += a * a;
        }
        let distance = (even + odd).sqrt();
        if !distance.is_finite() {
            return Err(invalid("Distance arithmetic is not finite"));
        }
        Ok(distance)
    }

    pub(crate) fn column(&self, index: usize) -> &[f64] {
        let start = index * self.feature_count();
        &self.values[start..start + self.feature_count()]
    }
}

fn pair_at_offset(n: usize, offset: usize) -> (usize, usize) {
    let start = |row| n * row - row * (row + 1) / 2;
    let (mut low, mut high) = (0, n - 1);
    while low + 1 < high {
        let mid = low + (high - low) / 2;
        if start(mid) <= offset {
            low = mid;
        } else {
            high = mid;
        }
    }
    (low, low + 1 + offset - start(low))
}
