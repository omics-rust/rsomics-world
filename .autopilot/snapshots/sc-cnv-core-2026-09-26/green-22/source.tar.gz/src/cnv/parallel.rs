use rsomics_common::{Result, RsomicsError};

pub(crate) fn for_chunks<T: Send, F>(output: &mut [T], chunk_len: usize, task: F) -> Result<()>
where
    F: Fn(usize, &mut [T]) -> Result<()> + Sync,
{
    if chunk_len == 0 {
        return Err(RsomicsError::InvalidInput(
            "CNV worker chunk length must be positive".into(),
        ));
    }
    if output.is_empty() {
        return Ok(());
    }
    if output.len() <= chunk_len {
        return task(0, output);
    }
    let task = &task;
    std::thread::scope(|scope| {
        let mut handles = Vec::new();
        handles
            .try_reserve_exact(output.len().div_ceil(chunk_len))
            .map_err(|_| RsomicsError::InvalidInput("CNV worker allocation failed".into()))?;
        let mut result = Ok(());
        for (chunk, output) in output.chunks_mut(chunk_len).enumerate() {
            match std::thread::Builder::new().spawn_scoped(scope, move || task(chunk, output)) {
                Ok(handle) => handles.push(handle),
                Err(error) => {
                    result = Err(RsomicsError::Io(error));
                    break;
                }
            }
        }
        for handle in handles {
            let worker = handle
                .join()
                .map_err(|_| RsomicsError::InvalidInput("CNV worker panicked".into()))
                .and_then(|result| result);
            if result.is_ok() {
                result = worker;
            }
        }
        result
    })
}
