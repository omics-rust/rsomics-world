use super::model::{CnvState, Gene};
use super::normalize::median;
use super::parallel::for_chunks;
use rsomics_common::{Result, RsomicsError};

pub(crate) fn triangular(state: &mut CnvState, window_length: usize, threads: usize) -> Result<()> {
    let gene_count = state.gene_count();
    let value_count = state.values.len();
    let radius = window_length / 2;
    let mut replacement = Vec::new();
    replacement
        .try_reserve_exact(value_count)
        .map_err(|_| RsomicsError::InvalidInput("smoothing allocation failed".into()))?;
    replacement.resize(value_count, 0.0);

    let workers = threads.min(state.cell_count());
    let chunk_len = state.cell_count().div_ceil(workers) * gene_count;
    for_chunks(&mut replacement, chunk_len, |chunk, output| {
        let start = chunk * chunk_len;
        smooth_columns(
            &state.values[start..start + output.len()],
            output,
            &state.genes,
            radius,
        )
    })?;
    state.values = replacement;
    Ok(())
}

fn smooth_columns(input: &[f64], output: &mut [f64], genes: &[Gene], radius: usize) -> Result<()> {
    let gene_count = genes.len();
    let mut start = 0;
    while start < gene_count {
        let chromosome = &genes[start].chromosome;
        let mut end = start + 1;
        while end < gene_count && genes[end].chromosome == *chromosome {
            end += 1;
        }
        for (column, smoothed) in input
            .chunks_exact(gene_count)
            .zip(output.chunks_exact_mut(gene_count))
        {
            if end - start == 1 {
                smoothed[start] = column[start];
                continue;
            }
            for (offset, result) in smoothed[start..end].iter_mut().enumerate() {
                let gene = start + offset;
                let left = gene.saturating_sub(radius).max(start);
                let right = gene.saturating_add(radius).min(end - 1);
                let mut weighted = 0.0;
                let mut weight_total = 0.0;
                for (offset, &value) in column[left..=right].iter().enumerate() {
                    let distance = gene.abs_diff(left + offset);
                    let weight = (radius + 1 - distance) as f64;
                    weighted += value * weight;
                    weight_total += weight;
                }
                let value = weighted / weight_total;
                if !weight_total.is_finite() || !value.is_finite() {
                    return Err(nonfinite());
                }
                *result = value;
            }
        }
        start = end;
    }
    Ok(())
}

pub(crate) fn center_cells(state: &mut CnvState, scratch: &mut [f64]) -> Result<()> {
    let genes = state.gene_count();
    for column in state.values.chunks_exact_mut(genes) {
        scratch[..genes].copy_from_slice(column);
        let center = median(&mut scratch[..genes])?;
        for value in column {
            *value -= center;
            if !value.is_finite() {
                return Err(nonfinite());
            }
        }
    }
    Ok(())
}

fn nonfinite() -> RsomicsError {
    RsomicsError::InvalidInput("smoothing or centering result is nonfinite".into())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cnv::{Cell, Gene};

    fn state(chromosomes: &[&str], values: Vec<f64>) -> CnvState {
        let genes = chromosomes
            .iter()
            .enumerate()
            .map(|(index, chromosome)| Gene {
                id: format!("g{index}"),
                chromosome: (*chromosome).into(),
                start: index as u64 + 1,
                end: index as u64 + 1,
            })
            .collect();
        CnvState {
            genes,
            cells: vec![Cell {
                id: "c".into(),
                group: "g".into(),
            }],
            values,
        }
    }

    fn close(actual: f64, expected: f64) {
        assert!(
            (actual - expected).abs() < 1e-12,
            "actual={actual}, expected={expected}"
        );
    }

    #[test]
    fn two_gene_window_101_has_independent_weighted_witness() {
        let mut state = state(&["chr1", "chr1"], vec![0.0, 10.0]);
        triangular(&mut state, 101, 1).unwrap();
        close(state.values[0], 500.0 / 101.0);
        close(state.values[1], 510.0 / 101.0);
    }

    #[test]
    fn singleton_is_copied_and_chromosomes_do_not_bleed() {
        let mut state = state(&["chr1", "chr1", "chr2"], vec![0.0, 10.0, 1000.0]);
        triangular(&mut state, 101, 1).unwrap();
        close(state.values[0], 500.0 / 101.0);
        close(state.values[1], 510.0 / 101.0);
        assert_eq!(state.values[2], 1000.0);
    }

    #[test]
    fn constant_windows_of_lengths_100_101_and_102_stay_constant() {
        for length in [100, 101, 102] {
            let mut state = state(&vec!["chr1"; length], vec![7.0; length]);
            triangular(&mut state, 101, 1).unwrap();
            for actual in state.values {
                close(actual, 7.0);
            }
        }
    }

    #[test]
    fn linear_windows_of_lengths_100_101_and_102_match_hand_derived_centers() {
        for length in [100, 101, 102] {
            let mut state = state(
                &vec!["chr1"; length],
                (0..length).map(|i| i as f64).collect(),
            );
            triangular(&mut state, 101, 1).unwrap();
            match length {
                100 => {
                    close(state.values[49], 49.0 + 1.0 / 52.0);
                    close(state.values[50], 50.0 - 1.0 / 52.0);
                }
                101 => close(state.values[50], 50.0),
                102 => {
                    close(state.values[50], 50.0);
                    close(state.values[51], 51.0);
                }
                _ => unreachable!(),
            }
        }
    }

    #[test]
    fn complete_columns_match_bitwise_across_worker_counts() {
        let make_state = || {
            let mut state = state(
                &["chr1", "chr1", "chr1", "chr2", "chr3", "chr3", "chr3"],
                (0..49).map(|index| (index as f64 - 23.0) / 7.0).collect(),
            );
            state.cells = (0..7)
                .map(|index| Cell {
                    id: format!("c{index}"),
                    group: "g".into(),
                })
                .collect();
            state
        };
        for window in [1, 3, 101] {
            let mut serial = make_state();
            triangular(&mut serial, window, 1).unwrap();
            let expected: Vec<_> = serial.values.iter().map(|value| value.to_bits()).collect();
            for workers in [2, 4, 16] {
                let mut parallel = make_state();
                triangular(&mut parallel, window, workers).unwrap();
                let actual: Vec<_> = parallel
                    .values
                    .iter()
                    .map(|value| value.to_bits())
                    .collect();
                assert_eq!(actual, expected, "window={window}, workers={workers}");
            }
        }
    }

    #[test]
    fn arithmetic_failure_does_not_replace_the_input_matrix() {
        for workers in [1, 4] {
            let mut state = state(&["chr1", "chr1"], vec![f64::MAX, 0.0, 0.0, 0.0]);
            state.cells.push(Cell {
                id: "c1".into(),
                group: "g".into(),
            });
            let before = state.values.clone();
            assert!(triangular(&mut state, 3, workers).is_err());
            assert_eq!(state.values, before);
        }
    }

    #[test]
    fn cell_centering_uses_global_gene_median() {
        let mut state = state(&["chr1", "chr1", "chr2"], vec![0.0, 4.0, 10.0]);
        let mut scratch = vec![0.0; 3];
        center_cells(&mut state, &mut scratch).unwrap();
        assert_eq!(state.values, [-4.0, 0.0, 6.0]);
    }
}
