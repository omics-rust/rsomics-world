use super::{META, SamplesArgs};
use rsomics_sc::cnv::{
    BayesianPredictions, CellGroup, CnvState, CreatedInput, Denoised, HmmGroup, HmmPredictions,
    Samples,
};
use serde::Serialize;
use std::path::Path;

#[derive(Serialize)]
pub(super) struct SamplesReport<'a> {
    schema: &'static str,
    tool: &'static str,
    tool_version: &'static str,
    index_basis: IndexBasis,
    inputs: ReportInputs<'a>,
    settings: ReportSettings<'a>,
    genes: Vec<GeneView<'a>>,
    cells: Vec<CellView<'a>>,
    input_groups: InputGroups<'a>,
    selected_gene_indices: &'a [usize],
    outlier_gene_indices: Option<&'a [usize]>,
    groups: Vec<GroupView<'a>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    expression: Option<ExpressionView<'a>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    denoised: Option<DenoisedView<'a>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    hmm: Option<HmmView<'a>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    bayesian: Option<BayesianView<'a>>,
}

pub(super) struct AdditionalResults<'a> {
    pub denoised: Option<&'a Denoised>,
    pub hmm: Option<&'a HmmPredictions>,
    pub bayesian: Option<&'a BayesianPredictions>,
}

#[derive(Serialize)]
struct IndexBasis {
    genes: usize,
    cells: usize,
    tree_order: &'static str,
    tree_merge: &'static str,
    member_indices: &'static str,
}

#[derive(Serialize)]
struct ReportInputs<'a> {
    counts: &'a Path,
    positions: &'a Path,
    annotations: &'a Path,
}

#[derive(Serialize)]
struct ReportSettings<'a> {
    reference_groups: &'a [String],
    reference_centering: &'static str,
    excluded_chromosomes: &'a [String],
    min_counts_per_cell: f64,
    max_counts_per_cell: Option<f64>,
    cutoff: f64,
    min_cells_per_gene: usize,
    window_length: usize,
    max_centered_threshold: f64,
    cluster_by_groups: bool,
    z_score_filter: f64,
    max_numeric_bytes_per_stage: usize,
    max_record_bytes: usize,
    threads: usize,
    #[serde(skip_serializing_if = "Option::is_none")]
    denoise: Option<DenoiseSettings>,
    #[serde(skip_serializing_if = "Option::is_none")]
    hmm: Option<HmmSettings>,
    #[serde(skip_serializing_if = "Option::is_none")]
    bayesian: Option<BayesianSettings>,
}

#[derive(Serialize)]
struct BayesianSettings {
    seed: u32,
    max_normal_probability: f64,
}

#[derive(Serialize)]
struct HmmSettings {
    seed: u32,
    transition_probability: f64,
    aggregate_normals: bool,
}

#[derive(Serialize)]
struct HmmView<'a> {
    step: u8,
    model: &'static str,
    grouping: &'static str,
    bayesian_filter: bool,
    region_gene_range: &'static str,
    calibration: CalibrationView<'a>,
    groups: Vec<HmmGroupView<'a>>,
}

#[derive(Serialize)]
struct BayesianView<'a> {
    step: u8,
    model: &'static str,
    sampler: &'static str,
    applied: bool,
    chains: usize,
    burn_in: usize,
    samples_per_chain: usize,
    posterior_indices: &'static str,
    groups: Vec<HmmGroupView<'a>>,
    posteriors: Vec<PosteriorView<'a>>,
}

#[derive(Serialize)]
struct PosteriorView<'a> {
    group_index: usize,
    region_index: usize,
    probabilities: &'a [f64; 6],
    cell_probabilities: &'a [[f64; 6]],
    chain_probabilities: &'a [[f64; 6]; 6],
    removed: bool,
    final_state: u8,
}

#[derive(Serialize)]
struct CalibrationView<'a> {
    means: &'a [f64; 6],
    standard_deviations: &'a [f64; 6],
    log_sd_fits: &'a [[f64; 2]; 6],
    simulated_genes: usize,
    simulated_cells: usize,
}

#[derive(Serialize)]
struct HmmGroupView<'a> {
    name: &'a str,
    member_indices: &'a [usize],
    states: &'a [u8],
    regions: Vec<RegionView<'a>>,
}

#[derive(Serialize)]
struct RegionView<'a> {
    name: &'a str,
    state: u8,
    chromosome: &'a str,
    start: u64,
    end: u64,
    gene_range: [usize; 2],
}

#[derive(Serialize)]
struct DenoiseSettings {
    noise_filter: Option<f64>,
    sd_amplifier: Option<f64>,
    noise_logistic: bool,
}

#[derive(Serialize)]
struct DenoisedView<'a> {
    bounds: Option<BoundsView>,
    expression: ExpressionView<'a>,
}

#[derive(Serialize)]
struct BoundsView {
    center: f64,
    threshold: f64,
}

#[derive(Serialize)]
struct GeneView<'a> {
    id: &'a str,
    chromosome: &'a str,
    start: u64,
    end: u64,
}

#[derive(Serialize)]
struct CellView<'a> {
    id: &'a str,
    group: &'a str,
}

#[derive(Serialize)]
struct InputGroups<'a> {
    observations: Vec<InputGroupView<'a>>,
    references: Vec<InputGroupView<'a>>,
}

#[derive(Serialize)]
struct InputGroupView<'a> {
    name: &'a str,
    cell_indices: &'a [usize],
}

#[derive(Serialize)]
struct GroupView<'a> {
    name: &'a str,
    subcluster_name: &'a str,
    member_indices: &'a [usize],
    tree: Option<TreeView<'a>>,
}

#[derive(Serialize)]
struct TreeView<'a> {
    merge: &'a [[i32; 2]],
    height: &'a [f64],
    order: &'a [usize],
}

#[derive(Serialize)]
struct ExpressionView<'a> {
    step: u8,
    layout: &'static str,
    shape: [usize; 2],
    values: &'a [f64],
}

impl<'a> SamplesReport<'a> {
    pub(super) fn new(
        args: &'a SamplesArgs,
        input: &'a CreatedInput,
        state: &'a CnvState,
        samples: &'a Samples,
        additional: AdditionalResults<'a>,
        threads: usize,
    ) -> Self {
        Self {
            schema: "rsomics-sc.cnv.samples.v1",
            tool: META.name,
            tool_version: META.version,
            index_basis: IndexBasis {
                genes: 0,
                cells: 0,
                tree_order: "zero-based local leaves; zip order with member_indices to map leaves to report cells",
                tree_merge: "signed R hclust: -k denotes one-based local leaf k; +k denotes one-based merge row k",
                member_indices: "zero-based report cells in tree traversal order; unclustered groups retain input order",
            },
            inputs: ReportInputs {
                counts: &args.counts,
                positions: &args.positions,
                annotations: &args.annotations,
            },
            settings: ReportSettings {
                reference_groups: &args.references,
                reference_centering: if args.references.is_empty() {
                    "all-cells"
                } else if args.reference_mean {
                    "group-mean"
                } else {
                    "group-bounds"
                },
                excluded_chromosomes: &args.excluded_chromosomes,
                min_counts_per_cell: args.min_counts_per_cell.max(1.0),
                max_counts_per_cell: args
                    .max_counts_per_cell
                    .is_finite()
                    .then_some(args.max_counts_per_cell),
                cutoff: args.cutoff,
                min_cells_per_gene: args.min_cells_per_gene,
                window_length: args.window_length,
                max_centered_threshold: args.max_centered_threshold,
                cluster_by_groups: args.cluster_by_groups,
                z_score_filter: args.z_score_filter,
                max_numeric_bytes_per_stage: args.max_numeric_bytes,
                max_record_bytes: args.max_record_bytes,
                threads,
                denoise: args.denoise.then_some(DenoiseSettings {
                    noise_filter: args.noise_filter,
                    sd_amplifier: args
                        .noise_filter
                        .is_none()
                        .then_some(args.sd_amplifier.unwrap_or(1.5)),
                    noise_logistic: args.noise_logistic,
                }),
                hmm: args.hmm.then_some(HmmSettings {
                    seed: args.hmm_seed,
                    transition_probability: args.hmm_transition_prob,
                    aggregate_normals: args.hspike_aggregate_normals,
                }),
                bayesian: args.bayes.then_some(BayesianSettings {
                    seed: args.bayes_seed,
                    max_normal_probability: args.bayes_max_p_normal,
                }),
            },
            genes: state
                .genes()
                .iter()
                .map(|gene| GeneView {
                    id: &gene.id,
                    chromosome: &gene.chromosome,
                    start: gene.start,
                    end: gene.end,
                })
                .collect(),
            cells: state
                .cells()
                .iter()
                .map(|cell| CellView {
                    id: &cell.id,
                    group: &cell.group,
                })
                .collect(),
            input_groups: InputGroups {
                observations: input_group_views(input.observation_groups()),
                references: input_group_views(input.reference_groups()),
            },
            selected_gene_indices: &samples.selected_gene_indices,
            outlier_gene_indices: samples.outlier_gene_indices.as_deref(),
            groups: samples
                .groups
                .iter()
                .map(|group| GroupView {
                    name: &group.name,
                    subcluster_name: &group.subcluster_name,
                    member_indices: &group.member_indices,
                    tree: group.tree.as_ref().map(|tree| TreeView {
                        merge: &tree.merge,
                        height: &tree.height,
                        order: &tree.order,
                    }),
                })
                .collect(),
            expression: args.include_expression.then_some(ExpressionView {
                step: 14,
                layout: "column-major",
                shape: [state.gene_count(), state.cell_count()],
                values: state.values(),
            }),
            denoised: additional.denoised.map(|values| DenoisedView {
                bounds: values.bounds().map(|bounds| BoundsView {
                    center: bounds.center,
                    threshold: bounds.threshold,
                }),
                expression: ExpressionView {
                    step: 22,
                    layout: "column-major",
                    shape: [state.gene_count(), state.cell_count()],
                    values: values.values(),
                },
            }),
            hmm: additional.hmm.map(|predictions| HmmView {
                step: 17,
                model: "i6",
                grouping: "samples",
                bayesian_filter: false,
                region_gene_range: "zero-based half-open indices in report genes; neutral state is 3",
                calibration: CalibrationView {
                    means: &predictions.calibration.means,
                    standard_deviations: &predictions.calibration.standard_deviations,
                    log_sd_fits: &predictions.calibration.log_sd_fits,
                    simulated_genes: predictions.calibration.simulated_genes,
                    simulated_cells: predictions.calibration.simulated_cells,
                },
                groups: hmm_group_views(&predictions.groups),
            }),
            bayesian: additional.bayesian.map(|predictions| BayesianView {
                step: 19,
                model: "i6-shared-dirichlet-normal",
                sampler: "collapsed-gibbs",
                applied: predictions.applied,
                chains: predictions.sampling.chains,
                burn_in: predictions.sampling.burn_in,
                samples_per_chain: predictions.sampling.samples_per_chain,
                posterior_indices: "zero-based original hmm group/region indexes; cell probabilities follow the original group's member_indices",
                groups: hmm_group_views(&predictions.groups),
                posteriors: predictions.regions.iter().map(|posterior| PosteriorView {
                    group_index: posterior.group_index,
                    region_index: posterior.region_index,
                    probabilities: &posterior.probabilities,
                    cell_probabilities: &posterior.cell_probabilities,
                    chain_probabilities: &posterior.chain_probabilities,
                    removed: posterior.removed,
                    final_state: posterior.final_state,
                }).collect(),
            }),
        }
    }
}

fn hmm_group_views(groups: &[HmmGroup]) -> Vec<HmmGroupView<'_>> {
    groups
        .iter()
        .map(|group| HmmGroupView {
            name: &group.name,
            member_indices: &group.member_indices,
            states: &group.states,
            regions: group
                .regions
                .iter()
                .map(|region| RegionView {
                    name: &region.name,
                    state: region.state,
                    chromosome: &region.chromosome,
                    start: region.start,
                    end: region.end,
                    gene_range: [region.gene_start, region.gene_end],
                })
                .collect(),
        })
        .collect()
}

fn input_group_views(groups: &[CellGroup]) -> Vec<InputGroupView<'_>> {
    groups
        .iter()
        .map(|group| InputGroupView {
            name: group.name(),
            cell_indices: group.cell_indices(),
        })
        .collect()
}
