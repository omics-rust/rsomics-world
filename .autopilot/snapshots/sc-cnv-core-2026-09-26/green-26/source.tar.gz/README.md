# rsomics-sc

This is an unreleased product-local numerical core, not a usable inferCNV replacement. It accepts prepared dense, column-major stage-1 counts or creates them from strict explicit-header UTF-8 count TSV and headerless position/annotation TSV, plain or gzip, preserving ordered cell groups. The non-HMM numerical path runs through step 14.

Source-pinned infercnv 1.28.0 synthetic and canonical shipped-example creation/pre-clustering comparisons have passed debug and release on Linux/macOS x86_64/aarch64. Original implicit count headers, arbitrary R decimal/threshold equivalence, general R table/locale behavior, RDS/sparse input and sampling remain excluded.

Separate [canonical warm raw-creation evidence](https://github.com/omics-rust/rsomics-world/blob/main/.autopilot/state/infercnv-ingestion-accepted-2026-10-22.md) passes exact output checks and strict timing separation on one Linux x86_64 shipped example. It does not establish representative-cohort, cold-I/O, factory peak-memory or full-workflow performance. Prepared-input measurements remain a different experiment.

A private Euclidean distance view and Ward.D2 kernel reproduce all107331 original distances and152 computed-vector trees from original R states, now including native temporary gene selection across52 routes, with exact binary64 distances/heights, merges and leaf order in native debug/release on Linux/macOS x86_64/aarch64. This is bounded correctness evidence, not general R precision or clustering performance. The adapted fastcluster code retains its original BSD notice in THIRD_PARTY_NOTICES.

The unpublished samples/Ward workflow connects raw inputs through preprocessing and grouped/pooled clustering, with a unified `rsomics-help` CLI, column-parallel chromosome smoothing and parallel pairwise distances. Native run40309311228 passes debug/release on all four platform classes,116 tests per profile. Its canonical raw-input CLI case retains8508 genes/184 cells/6187 selected genes and produces identical1/4-worker reports including the complete expression matrix. This is not a full inferCNV replacement or a public release.

Optional step-22 denoising now supports fixed thresholds, reference-SD thresholds, and hard or logistic transforms. Actual raw-input infercnv1.28.0 comparisons pass15 configurations across grouped references, no-reference proxy cells and the shipped full example, with identical native1/4-worker reports. Step-14 expression, identities, selected genes and clustering results remain unchanged. Final native run40324825127 passes125 tests per debug/release profile on all four platform classes. This is workflow compatibility evidence, not a denoise speed comparison or biological validation.

Grouped-sample i6 HMM inference now connects raw counts to hidden-spike calibration, separate step-17 state paths and CNV regions. Native run40484702873 passes debug/release on all four platform classes,131 tests per profile, strict Clippy, and24 actual raw-workflow comparisons: three real reference/proxy/aggregation cases at1/4 workers on each platform. States, memberships and all four upstream report projections match. This is a bounded non-Bayesian workflow, not full inferCNV or upstream-default behavior.

[Canonical whole-CLI measurements](https://github.com/omics-rust/rsomics-world/blob/main/.autopilot/state/infercnv-matrix-parallel-2026-10-26.md) on one four-CPU Linux runner give median0.39/0.31s at1/4 workers (1.26x), with about57.6/57.9MiB median peak RSS. Timing ranges overlap. This warm-input small-cohort result does not establish stable larger-cohort or upstream replacement performance.

[A real4,103-cell GBM case](https://github.com/omics-rust/rsomics-world/blob/main/.autopilot/state/infercnv-real-cohort-2026-10-26.md) retains9,465 genes and completes the full samples CLI in median131.53/53.32s at1/4 workers (2.47x), with complete timing-range separation and2.17GiB median peak RSS for both. All12 reports agree. This uses warm inputs and all cells as reference on a busy four-CPU-pinned host; it is not an upstream R comparison or biological CNV validation.

Unreleased workflow invocation:

```sh
rsomics-sc cnv samples \
  --counts counts.tsv --positions gene-order.tsv --annotations groups.tsv \
  --reference normal --threads 4 --output samples.json --include-expression
```

The self-contained JSON report contains cell/gene identities, ordered input maps, selected clustering genes, signed Ward merges, leaf order and global memberships. `--include-expression` retains the unmodified step-14 column-major matrix. `--json` emits only the shared command summary on stdout and requires a named report. Positive `--z-score-filter` enables the upstream fixed 0.8 rule; zero disables it. A pooled reference named `all_observations` explicitly fails instead of reproducing the upstream duplicated-observation bug.

Add `--denoise` for the default1.5 SD-amplifier hard filter, `--noise-filter WIDTH` for a fixed width, or `--noise-logistic` for logistic filtering. An explicit `--sd-amplifier` conflicts with a fixed width. The center pools all reference values, using all cells when references are absent; SD width uses the average per-reference-cell sample SD across genes. Fixed zero/negative widths bypass filtering. A separate `denoised` report member always retains the step-22 matrix when requested, independently of `--include-expression`.

Add `--hmm --cluster-by-groups` for grouped-sample i6 inference. `--hmm-seed` accepts0 through2147483647 (default0), `--hmm-transition-prob` defaults to1e-6, and `--hspike-aggregate-normals` pools the reference groups for simulation. Without references, all observation cells supply the simulation proxy. Calibration starts before log transformation, not from denoised expression. Group/chromosome decoding and numerical preprocessing use the requested workers; random calibration draws keep a reproducible serial order.

The optional `hmm` report member contains one state per retained gene in each group's `states`, plus non-neutral `regions`. Integer states1..6 correspond to simulated multipliers0.01,0.5,1,1.5,2,3; state3 is neutral. Calibration arrays use this same order. `standard_deviations` measures transformed-spike dispersion, while `log_sd_fits` contains `[intercept, slope]` for log(SD) against log(cell count); decoding uses the median of the six group-fitted SDs. Region `gene_range` values are zero-based half-open indexes into report `genes`; genomic start/end coordinates remain those of the input. Region numbering includes omitted neutral runs, so IDs can have gaps. This JSON can be projected to the upstream cell-group, region, gene and genes-used tables; it is not a byte-compatible upstream output directory.

The numeric byte limit is per stage, not a process-memory limit; metadata, thread stacks and retained prior stages are excluded. Subcluster discovery, i3/per-cell inference, Bayesian filtering, plots and general persisted-state import remain unimplemented. Current comparisons do not establish arbitrary-input R precision equivalence, paired HMM performance advantage, full upstream-default behavior or biological validity.
