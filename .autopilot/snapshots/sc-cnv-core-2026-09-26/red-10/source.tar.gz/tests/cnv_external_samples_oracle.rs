#[path = "../src/cnv/samples/condensed.rs"]
mod condensed;
#[path = "../src/cnv/samples/distance.rs"]
mod distance;
#[path = "../src/cnv/samples/ward.rs"]
mod ward;

use distance::CellProfiles;
use std::collections::HashSet;
use std::io::{BufRead, BufReader};
use std::path::{Component, Path, PathBuf};

const PROFILES: &str = include_str!("fixtures/infercnv-1.28.0/ward/profiles.tsv");
const TREES: &str = include_str!("fixtures/infercnv-1.28.0/ward/trees.tsv");

struct Profile<'a> {
    identity: &'a str,
    matrix: &'a str,
    features: usize,
    cells: usize,
    indices: Vec<usize>,
}

fn profiles() -> Vec<Profile<'static>> {
    let mut lines = PROFILES.lines();
    assert_eq!(lines.next(), Some("tree\tmatrix\tfeatures\tcells\tindices"));
    lines
        .map(|line| {
            let fields: Vec<_> = line.split('\t').collect();
            assert_eq!(fields.len(), 5);
            assert!(!fields[0].is_empty());
            assert!(
                Path::new(fields[1])
                    .components()
                    .all(|p| matches!(p, Component::Normal(_)))
            );
            assert!(!fields[1].is_empty());
            Profile {
                identity: fields[0],
                matrix: fields[1],
                features: fields[2].parse().unwrap(),
                cells: fields[3].parse().unwrap(),
                indices: fields[4].split(',').map(|s| s.parse().unwrap()).collect(),
            }
        })
        .collect()
}

fn matrix(root: &Path, profile: &Profile<'_>) -> Vec<f64> {
    let file = std::fs::File::open(root.join(profile.matrix)).unwrap();
    let mut lines = BufReader::new(file).lines();
    let header = lines.next().unwrap().unwrap();
    let names: Vec<_> = header.split('\t').collect();
    assert_eq!(names.len(), profile.cells + 1);
    assert_eq!(names[0], "gene");
    assert!(names[1..].iter().all(|name| !name.is_empty()));
    assert_eq!(
        names[1..].iter().collect::<HashSet<_>>().len(),
        profile.cells
    );
    let mut genes = HashSet::new();
    let mut values = vec![0.0; profile.features.checked_mul(profile.cells).unwrap()];
    let mut rows = 0;
    for line in lines {
        let line = line.unwrap();
        assert!(
            rows < profile.features,
            "extra matrix row: {}",
            profile.identity
        );
        let fields: Vec<_> = line.split('\t').collect();
        assert_eq!(fields.len(), profile.cells + 1);
        assert!(!fields[0].is_empty() && genes.insert(fields[0].to_owned()));
        for (cell, field) in fields[1..].iter().enumerate() {
            let value: f64 = field.parse().unwrap();
            assert!(value.is_finite());
            values[cell * profile.features + rows] = value;
        }
        rows += 1;
    }
    assert_eq!(rows, profile.features, "{} matrix rows", profile.identity);
    values
}

fn fields<'a>(line: &'a str, label: &str) -> Vec<&'a str> {
    let mut parts = line.split('\t');
    assert_eq!(parts.next(), Some(label));
    parts.collect()
}

#[test]
fn all_original_distances_and_computed_vector_trees_match_exactly() {
    let root = std::env::var_os("RSOMICS_INFER_CNV_SAMPLES_ROOT")
        .filter(|value| !value.is_empty())
        .expect("RSOMICS_INFER_CNV_SAMPLES_ROOT is required");
    let root = PathBuf::from(root);
    assert!(root.is_dir());
    let profiles = profiles();
    let trees: Vec<_> = TREES.lines().collect();
    assert_eq!(profiles.len(), 152);
    assert_eq!(trees.len(), profiles.len() * 6);
    let mut identities = HashSet::new();
    let mut index = 0;
    let mut matrices = 0;
    let mut total_pairs = 0;
    while index < profiles.len() {
        let first = &profiles[index];
        let values = matrix(&root, first);
        let view = CellProfiles::new(&values, first.features, first.cells).unwrap();
        matrices += 1;
        while index < profiles.len() && profiles[index].matrix == first.matrix {
            let profile = &profiles[index];
            assert_eq!(
                (profile.features, profile.cells),
                (first.features, first.cells)
            );
            assert!(identities.insert(profile.identity));
            let record = &trees[index * 6..index * 6 + 6];
            let header = fields(record[0], "tree");
            assert_eq!(header.len(), 2);
            assert_eq!(header[0], profile.identity);
            let n: usize = header[1].parse().unwrap();
            assert_eq!(n, profile.indices.len());
            let actual = view.distances(&profile.indices, 8 * 1024 * 1024).unwrap();
            let expected = fields(record[1], "distances");
            assert_eq!(actual.len(), expected.len());
            for (pair, (&actual, expected)) in actual.iter().zip(&expected).enumerate() {
                let expected: f64 = expected.parse().unwrap();
                assert_eq!(
                    actual.to_bits(),
                    expected.to_bits(),
                    "{} pair {pair}: {actual:.17e} != {expected:.17e}",
                    profile.identity
                );
            }
            let tree = ward::ward_d2(&actual, n, 8 * 1024 * 1024).unwrap();
            let merge: Vec<[i32; 2]> = fields(record[2], "merge")
                .iter()
                .map(|s| {
                    let children: Vec<i32> = s.split(',').map(|v| v.parse().unwrap()).collect();
                    children.try_into().unwrap()
                })
                .collect();
            assert_eq!(tree.merge, merge, "{} merge", profile.identity);
            let heights = fields(record[3], "heights");
            assert_eq!(tree.height.len(), heights.len());
            for (row, (&actual, expected)) in tree.height.iter().zip(&heights).enumerate() {
                let expected: f64 = expected.parse().unwrap();
                assert_eq!(
                    actual.to_bits(),
                    expected.to_bits(),
                    "{} height row {row}",
                    profile.identity
                );
            }
            let order: Vec<usize> = fields(record[4], "order")
                .iter()
                .map(|s| s.parse::<usize>().unwrap().checked_sub(1).unwrap())
                .collect();
            assert_eq!(tree.order, order, "{} order", profile.identity);
            assert_eq!(record[5], "end");
            total_pairs += actual.len();
            println!(
                "exact computed tree {}: features={}, cells={}, leaves={n}, pairs={}, merges={}",
                profile.identity,
                profile.features,
                profile.cells,
                actual.len(),
                tree.merge.len()
            );
            index += 1;
        }
    }
    assert_eq!(identities.len(), 152);
    assert_eq!(matrices, 52);
    assert_eq!(total_pairs, 107331);
    println!("exact samples totals: trees=152 matrices=52 pairs=107331");
}
