# inferCNV oracle tests

Default tests use the small, checked-in synthetic fixtures. The shipped-example
conformance test is opt-in and requires a separately acquired, verified oracle
bundle; no large fixture or upstream package code is stored in this repository.

After verifying the accepted receipt, artifact and bundle manifest, set
`RSOMICS_INFER_CNV_ORACLE_ROOT` to the extracted `shipped-bundle` directory
containing `subset/` and `full/`. Then run:

```sh
cargo test --locked --features external-infercnv-oracle --test cnv_external_oracle -- --nocapture
```

Selecting this target without the environment variable or required data fails.
The test compares stages 1, 2, 3, 4, 8, 9, 10, 11, 12 and 14 for both cases
using `abs(actual - expected) <= 1e-12 + 1e-12 * abs(expected)` and prints
per-stage maximum absolute and scaled errors. It tests only the prepared-count
pre-clustering core, not raw-input parsing, downstream inferCNV workflow,
biological truth or performance.
