use rsomics_sc::cnv::{Cell, Gene};
use std::collections::BTreeMap;
use std::fs;
use std::path::{Path, PathBuf};

const STEPS: [u8; 10] = [1, 2, 3, 4, 8, 9, 10, 11, 12, 14];

pub struct ExpectedStage {
    genes: Vec<Gene>,
    cells: Vec<Cell>,
    values: Vec<f64>,
}

impl ExpectedStage {
    pub fn genes(&self) -> &[Gene] {
        &self.genes
    }

    pub fn cells(&self) -> &[Cell] {
        &self.cells
    }

    pub fn values(&self) -> &[f64] {
        &self.values
    }
}

pub struct Fixture {
    stages: BTreeMap<u8, ExpectedStage>,
}

impl Fixture {
    pub fn load(profile: &str) -> Self {
        assert!(matches!(
            profile,
            "single_reference" | "grouped_bounds" | "grouped_mean" | "no_reference"
        ));
        let root = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("tests/fixtures/infercnv-1.28.0")
            .join(profile);
        Self::load_from_root(&root).unwrap_or_else(|error| panic!("{error}"))
    }

    pub fn load_from_root(root: &Path) -> Result<Self, String> {
        let mut stages = BTreeMap::new();
        for step in STEPS {
            let stem = format!("{step:02}");
            let gene_path = root.join(format!("{stem}.genes.tsv"));
            let cell_path = root.join(format!("{stem}.cells.tsv"));
            let expression_path = root.join(format!("{stem}.tsv"));
            let genes = parse_genes(&read_table(&gene_path)?, &gene_path)?;
            let cells = parse_cells(&read_table(&cell_path)?, &cell_path)?;
            let values = parse_expression(
                &read_table(&expression_path)?,
                &expression_path,
                &genes,
                &cells,
            )?;
            stages.insert(
                step,
                ExpectedStage {
                    genes,
                    cells,
                    values,
                },
            );
        }
        Ok(Self { stages })
    }

    pub fn stage(&self, step: u8) -> &ExpectedStage {
        self.stages.get(&step).unwrap()
    }
}

fn read_table(path: &Path) -> Result<String, String> {
    fs::read_to_string(path).map_err(|error| format!("{}: {error}", path.display()))
}

fn parse_genes(table: &str, path: &Path) -> Result<Vec<Gene>, String> {
    let mut lines = table.lines();
    if lines.next() != Some("gene\tchr\tstart\tstop") {
        return Err(format!("{}: invalid gene header", path.display()));
    }
    let mut genes = Vec::new();
    for (index, line) in lines.enumerate() {
        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 4 {
            return Err(format!(
                "{}: invalid gene row {}",
                path.display(),
                index + 2
            ));
        }
        let start = fields[2].parse::<u64>().map_err(|error| {
            format!("{}: gene row {} start: {error}", path.display(), index + 2)
        })?;
        let end = fields[3]
            .parse::<u64>()
            .map_err(|error| format!("{}: gene row {} stop: {error}", path.display(), index + 2))?;
        genes.push(Gene {
            id: fields[0].into(),
            chromosome: fields[1].into(),
            start,
            end,
        });
    }
    if genes.is_empty() {
        return Err(format!("{}: no genes", path.display()));
    }
    Ok(genes)
}

fn parse_cells(table: &str, path: &Path) -> Result<Vec<Cell>, String> {
    let mut lines = table.lines();
    if lines.next() != Some("cell\tgroup\trole") {
        return Err(format!("{}: invalid cell header", path.display()));
    }
    let mut cells = Vec::new();
    for (index, line) in lines.enumerate() {
        let fields: Vec<_> = line.split('\t').collect();
        if fields.len() != 3 {
            return Err(format!(
                "{}: invalid cell row {}",
                path.display(),
                index + 2
            ));
        }
        cells.push(Cell {
            id: fields[0].into(),
            group: fields[1].into(),
        });
    }
    if cells.is_empty() {
        return Err(format!("{}: no cells", path.display()));
    }
    Ok(cells)
}

fn parse_expression(
    table: &str,
    path: &Path,
    genes: &[Gene],
    cells: &[Cell],
) -> Result<Vec<f64>, String> {
    let mut rows = table.lines();
    let header = rows
        .next()
        .ok_or_else(|| format!("{}: missing expression header", path.display()))?
        .split('\t')
        .collect::<Vec<_>>();
    if header.len() != cells.len() + 1
        || header[0] != "gene"
        || !header[1..]
            .iter()
            .zip(cells)
            .all(|(observed, cell)| *observed == cell.id.as_str())
    {
        return Err(format!(
            "{}: expression cell header mismatch",
            path.display()
        ));
    }
    let value_count = genes
        .len()
        .checked_mul(cells.len())
        .ok_or_else(|| format!("{}: expression shape overflow", path.display()))?;
    let mut values = vec![0.0; value_count];
    let mut row_count = 0;
    for (gene_index, line) in rows.enumerate() {
        let gene = genes.get(gene_index).ok_or_else(|| {
            format!(
                "{}: extra expression row {}",
                path.display(),
                gene_index + 2
            )
        })?;
        let fields = line.split('\t').collect::<Vec<_>>();
        if fields.len() != cells.len() + 1 || fields[0] != gene.id.as_str() {
            return Err(format!(
                "{}: expression row {} identity or width mismatch",
                path.display(),
                gene_index + 2
            ));
        }
        for cell_index in 0..cells.len() {
            let value: f64 = fields[cell_index + 1].trim().parse().map_err(|error| {
                format!(
                    "{}: expression row {} cell {}: {error}",
                    path.display(),
                    gene_index + 2,
                    cell_index + 1
                )
            })?;
            if !value.is_finite() {
                return Err(format!(
                    "{}: non-finite expression row {} cell {}",
                    path.display(),
                    gene_index + 2,
                    cell_index + 1
                ));
            }
            values[cell_index * genes.len() + gene_index] = value;
        }
        row_count += 1;
    }
    if row_count != genes.len() {
        return Err(format!(
            "{}: expected {} expression rows, found {row_count}",
            path.display(),
            genes.len()
        ));
    }
    Ok(values)
}
