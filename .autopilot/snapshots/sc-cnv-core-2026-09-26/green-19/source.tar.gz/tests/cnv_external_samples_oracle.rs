#[path = "../src/cnv/samples/condensed.rs"]
mod condensed;
#[path = "../src/cnv/samples/distance.rs"]
mod distance;
#[path = "../src/cnv/samples/filter.rs"]
mod filter;
#[path = "../src/cnv/samples/ward.rs"]
mod ward;

use distance::CellProfiles;
use std::collections::HashSet;
use std::io::{BufRead, BufReader};
use std::path::{Component, Path, PathBuf};

const PROFILES: &str = include_str!("fixtures/infercnv-1.28.0/ward/profiles.tsv");
const TREES: &str = include_str!("fixtures/infercnv-1.28.0/ward/trees.tsv");
const FILTER_ROUTES: &str = include_str!("fixtures/infercnv-1.28.0/ward/filter-routes.tsv");

struct Profile<'a> {
    identity: &'a str,
    matrix: &'a str,
    features: usize,
    cells: usize,
    indices: Vec<usize>,
}

fn profiles() -> Vec<Profile<'static>> {
    let mut lines = PROFILES.lines();
    assert_eq!(lines.next(), Some("tree\tmatrix\tfeatures\tcells\tindices"));
    lines
        .map(|line| {
            let fields: Vec<_> = line.split('\t').collect();
            assert_eq!(fields.len(), 5);
            assert!(!fields[0].is_empty());
            assert!(
                Path::new(fields[1])
                    .components()
                    .all(|p| matches!(p, Component::Normal(_)))
            );
            assert!(!fields[1].is_empty());
            Profile {
                identity: fields[0],
                matrix: fields[1],
                features: fields[2].parse().unwrap(),
                cells: fields[3].parse().unwrap(),
                indices: fields[4].split(',').map(|s| s.parse().unwrap()).collect(),
            }
        })
        .collect()
}

fn matrix(root: &Path, profile: &Profile<'_>) -> Vec<f64> {
    let file = std::fs::File::open(root.join(profile.matrix)).unwrap();
    let mut lines = BufReader::new(file).lines();
    let header = lines.next().unwrap().unwrap();
    let names: Vec<_> = header.split('\t').collect();
    assert_eq!(names.len(), profile.cells + 1);
    assert_eq!(names[0], "gene");
    assert!(names[1..].iter().all(|name| !name.is_empty()));
    assert_eq!(
        names[1..].iter().collect::<HashSet<_>>().len(),
        profile.cells
    );
    let mut genes = HashSet::new();
    let mut values = vec![0.0; profile.features.checked_mul(profile.cells).unwrap()];
    let mut rows = 0;
    for line in lines {
        let line = line.unwrap();
        assert!(
            rows < profile.features,
            "extra matrix row: {}",
            profile.identity
        );
        let fields: Vec<_> = line.split('\t').collect();
        assert_eq!(fields.len(), profile.cells + 1);
        assert!(!fields[0].is_empty() && genes.insert(fields[0].to_owned()));
        for (cell, field) in fields[1..].iter().enumerate() {
            let value: f64 = field.parse().unwrap();
            assert!(value.is_finite());
            values[cell * profile.features + rows] = value;
        }
        rows += 1;
    }
    assert_eq!(rows, profile.features, "{} matrix rows", profile.identity);
    values
}

fn fields<'a>(line: &'a str, label: &str) -> Vec<&'a str> {
    let mut parts = line.split('\t');
    assert_eq!(parts.next(), Some(label));
    parts.collect()
}

#[test]
fn all_original_distances_and_computed_vector_trees_match_exactly() {
    let root = std::env::var_os("RSOMICS_INFER_CNV_SAMPLES_ROOT")
        .filter(|value| !value.is_empty())
        .expect("RSOMICS_INFER_CNV_SAMPLES_ROOT is required");
    let root = PathBuf::from(root);
    assert!(root.is_dir());
    let profiles = profiles();
    let trees: Vec<_> = TREES.lines().collect();
    assert_eq!(profiles.len(), 152);
    assert_eq!(trees.len(), profiles.len() * 6);
    let mut identities = HashSet::new();
    let mut index = 0;
    let mut matrices = 0;
    let mut total_pairs = 0;
    while index < profiles.len() {
        let first = &profiles[index];
        let values = matrix(&root, first);
        let view = CellProfiles::new(&values, first.features, first.cells).unwrap();
        matrices += 1;
        while index < profiles.len() && profiles[index].matrix == first.matrix {
            let profile = &profiles[index];
            assert_eq!(
                (profile.features, profile.cells),
                (first.features, first.cells)
            );
            assert!(identities.insert(profile.identity));
            let record = &trees[index * 6..index * 6 + 6];
            let header = fields(record[0], "tree");
            assert_eq!(header.len(), 2);
            assert_eq!(header[0], profile.identity);
            let n: usize = header[1].parse().unwrap();
            assert_eq!(n, profile.indices.len());
            let actual = view.distances(&profile.indices, 8 * 1024 * 1024).unwrap();
            let expected = fields(record[1], "distances");
            assert_eq!(actual.len(), expected.len());
            for (pair, (&actual, expected)) in actual.iter().zip(&expected).enumerate() {
                let expected: f64 = expected.parse().unwrap();
                assert_eq!(
                    actual.to_bits(),
                    expected.to_bits(),
                    "{} pair {pair}: {actual:.17e} != {expected:.17e}",
                    profile.identity
                );
            }
            let tree = ward::ward_d2(&actual, n, 8 * 1024 * 1024).unwrap();
            let merge: Vec<[i32; 2]> = fields(record[2], "merge")
                .iter()
                .map(|s| {
                    let children: Vec<i32> = s.split(',').map(|v| v.parse().unwrap()).collect();
                    children.try_into().unwrap()
                })
                .collect();
            assert_eq!(tree.merge, merge, "{} merge", profile.identity);
            let heights = fields(record[3], "heights");
            assert_eq!(tree.height.len(), heights.len());
            for (row, (&actual, expected)) in tree.height.iter().zip(&heights).enumerate() {
                let expected: f64 = expected.parse().unwrap();
                assert_eq!(
                    actual.to_bits(),
                    expected.to_bits(),
                    "{} height row {row}",
                    profile.identity
                );
            }
            let order: Vec<usize> = fields(record[4], "order")
                .iter()
                .map(|s| s.parse::<usize>().unwrap().checked_sub(1).unwrap())
                .collect();
            assert_eq!(tree.order, order, "{} order", profile.identity);
            assert_eq!(record[5], "end");
            total_pairs += actual.len();
            println!(
                "exact computed tree {}: features={}, cells={}, leaves={n}, pairs={}, merges={}",
                profile.identity,
                profile.features,
                profile.cells,
                actual.len(),
                tree.merge.len()
            );
            index += 1;
        }
    }
    assert_eq!(identities.len(), 152);
    assert_eq!(matrices, 52);
    assert_eq!(total_pairs, 107331);
    println!("exact samples totals: trees=152 matrices=52 pairs=107331");
}

struct FilterRoute<'a> {
    identity: &'a str,
    expression: &'a str,
    genes: &'a str,
    cells: &'a str,
    maps: &'a str,
    filtered_expression: &'a str,
    features: usize,
    cell_count: usize,
    references: Vec<usize>,
    argument: f64,
    active: bool,
    outliers: Option<Vec<usize>>,
    selected: Vec<usize>,
}

fn indices(value: &str) -> Vec<usize> {
    if value == "[]" {
        Vec::new()
    } else {
        assert!(!value.is_empty());
        value
            .split(',')
            .map(|index| index.parse().unwrap())
            .collect()
    }
}

fn filter_routes() -> Vec<FilterRoute<'static>> {
    let mut lines = FILTER_ROUTES.lines();
    assert_eq!(
        lines.next(),
        Some(concat!(
            "route\texpression\tgenes\tcells\tmaps\tfiltered_expression\tfeatures\tcell_count",
            "\treference_indices\tz_score_filter\tfilter_guard_active\toutliers\tselected_gene_indices"
        ))
    );
    lines
        .map(|line| {
            let fields: Vec<_> = line.split('\t').collect();
            assert_eq!(fields.len(), 13);
            assert_eq!(fields[0].split('/').count(), 2);
            for relative in &fields[1..6] {
                assert!(!relative.is_empty());
                assert!(
                    Path::new(relative)
                        .components()
                        .all(|part| matches!(part, Component::Normal(_)))
                );
            }
            FilterRoute {
                identity: fields[0],
                expression: fields[1],
                genes: fields[2],
                cells: fields[3],
                maps: fields[4],
                filtered_expression: fields[5],
                features: fields[6].parse().unwrap(),
                cell_count: fields[7].parse().unwrap(),
                references: indices(fields[8]),
                argument: fields[9].parse().unwrap(),
                active: fields[10].parse().unwrap(),
                outliers: (fields[11] != "NULL").then(|| indices(fields[11])),
                selected: indices(fields[12]),
            }
        })
        .collect()
}

fn table(root: &Path, relative: &str, header: &[&str]) -> Vec<Vec<String>> {
    let file = std::fs::File::open(root.join(relative)).unwrap();
    let mut lines = BufReader::new(file).lines();
    assert_eq!(
        lines
            .next()
            .unwrap()
            .unwrap()
            .split('\t')
            .collect::<Vec<_>>(),
        header,
        "{relative} header"
    );
    lines
        .map(|line| {
            let row: Vec<_> = line.unwrap().split('\t').map(str::to_owned).collect();
            assert_eq!(row.len(), header.len(), "{relative} columns");
            row
        })
        .collect()
}

fn source_names(root: &Path, route: &FilterRoute<'_>) -> (Vec<String>, Vec<String>) {
    let genes = table(root, route.genes, &["gene", "chr", "start", "stop"]);
    let cells = table(root, route.cells, &["cell", "group", "role"]);
    let maps = table(root, route.maps, &["role", "group", "index", "cell"]);
    assert_eq!(genes.len(), route.features);
    assert_eq!(cells.len(), route.cell_count);
    assert_eq!(maps.len(), route.cell_count);
    let gene_names: Vec<_> = genes
        .iter()
        .map(|row| {
            assert!(!row[0].is_empty() && !row[1].is_empty());
            assert!(row[2].parse::<i64>().unwrap() <= row[3].parse::<i64>().unwrap());
            row[0].clone()
        })
        .collect();
    let cell_names: Vec<_> = cells.iter().map(|row| row[0].clone()).collect();
    assert!(cell_names.iter().all(|name| !name.is_empty()));
    assert_eq!(
        gene_names.iter().collect::<HashSet<_>>().len(),
        route.features
    );
    assert_eq!(
        cell_names.iter().collect::<HashSet<_>>().len(),
        route.cell_count
    );
    let mut seen = HashSet::new();
    let mut references = Vec::new();
    for row in maps {
        assert!(matches!(row[0].as_str(), "reference" | "observation"));
        let index = row[2].parse::<usize>().unwrap().checked_sub(1).unwrap();
        assert!(index < route.cell_count && seen.insert(index));
        assert_eq!(row[3], cells[index][0]);
        assert_eq!(row[1], cells[index][1]);
        assert_eq!(row[0], cells[index][2]);
        if row[0] == "reference" {
            references.push(index);
        }
    }
    assert_eq!(
        references, route.references,
        "{} reference order",
        route.identity
    );
    (gene_names, cell_names)
}

fn named_matrix(root: &Path, relative: &str, genes: &[String], cells: &[String]) -> Vec<f64> {
    let file = std::fs::File::open(root.join(relative)).unwrap();
    let mut lines = BufReader::new(file).lines();
    let header = lines.next().unwrap().unwrap();
    let columns: Vec<_> = header.split('\t').collect();
    assert_eq!(columns.first(), Some(&"gene"));
    assert_eq!(columns[1..], *cells);
    let mut values = vec![0.0; genes.len().checked_mul(cells.len()).unwrap()];
    let mut rows = 0;
    for line in lines {
        assert!(rows < genes.len(), "{relative} extra row");
        let line = line.unwrap();
        let row: Vec<_> = line.split('\t').collect();
        assert_eq!(row.len(), cells.len() + 1);
        assert_eq!(row[0], genes[rows], "{relative} gene order");
        for (cell, field) in row[1..].iter().enumerate() {
            let value: f64 = field.trim().parse().unwrap();
            assert!(value.is_finite());
            values[cell * genes.len() + rows] = value;
        }
        rows += 1;
    }
    assert_eq!(rows, genes.len(), "{relative} rows");
    values
}

fn assert_native_selected_tree(
    view: &CellProfiles<'_>,
    profile: &Profile<'_>,
    record: &[&str],
) -> usize {
    let header = fields(record[0], "tree");
    assert_eq!(header.len(), 2);
    assert_eq!(header[0], profile.identity);
    let leaves: usize = header[1].parse().unwrap();
    assert_eq!(leaves, profile.indices.len());
    let actual = view.distances(&profile.indices, 8 * 1024 * 1024).unwrap();
    let expected = fields(record[1], "distances");
    assert_eq!(actual.len(), expected.len());
    for (pair, (&actual, expected)) in actual.iter().zip(&expected).enumerate() {
        let expected: f64 = expected.parse().unwrap();
        assert_eq!(
            actual.to_bits(),
            expected.to_bits(),
            "{} pair {pair}",
            profile.identity
        );
    }
    let tree = ward::ward_d2(&actual, leaves, 8 * 1024 * 1024).unwrap();
    let merge: Vec<[i32; 2]> = fields(record[2], "merge")
        .iter()
        .map(|value| {
            value
                .split(',')
                .map(|child| child.parse::<i32>().unwrap())
                .collect::<Vec<_>>()
                .try_into()
                .unwrap()
        })
        .collect();
    assert_eq!(tree.merge, merge, "{} merge", profile.identity);
    let heights = fields(record[3], "heights");
    assert_eq!(tree.height.len(), heights.len());
    for (row, (&actual, expected)) in tree.height.iter().zip(&heights).enumerate() {
        let expected: f64 = expected.parse().unwrap();
        assert_eq!(
            actual.to_bits(),
            expected.to_bits(),
            "{} height {row}",
            profile.identity
        );
    }
    let order: Vec<_> = fields(record[4], "order")
        .iter()
        .map(|value| value.parse::<usize>().unwrap().checked_sub(1).unwrap())
        .collect();
    assert_eq!(tree.order, order, "{} order", profile.identity);
    assert_eq!(record[5], "end");
    println!(
        "exact native-selected tree {}: features={}, cells={}, leaves={leaves}, pairs={}, merges={}",
        profile.identity,
        profile.features,
        profile.cells,
        actual.len(),
        tree.merge.len()
    );
    actual.len()
}

#[test]
fn all_original_unfiltered_routes_select_exact_rows_before_distance_and_ward() {
    let root = std::env::var_os("RSOMICS_INFER_CNV_SAMPLES_ROOT")
        .filter(|value| !value.is_empty())
        .expect("RSOMICS_INFER_CNV_SAMPLES_ROOT is required");
    let root = PathBuf::from(root);
    assert!(root.is_dir());
    let routes = filter_routes();
    let profiles = profiles();
    let trees: Vec<_> = TREES.lines().collect();
    assert_eq!(routes.len(), 52);
    assert_eq!(profiles.len(), 152);
    assert_eq!(trees.len(), 152 * 6);
    let mut route_ids = HashSet::new();
    let mut tree_ids = HashSet::new();
    let mut total_pairs = 0;
    let mut active_routes = 0;
    let mut empty_outliers = 0;
    let mut zero_selected = 0;
    for route in routes {
        assert!(route_ids.insert(route.identity));
        assert_eq!(
            route.active,
            route.argument > 0.0 && !route.references.is_empty()
        );
        let (genes, cells) = source_names(&root, &route);
        let values = named_matrix(&root, route.expression, &genes, &cells);
        let view = CellProfiles::new(&values, route.features, route.cell_count).unwrap();
        let selection =
            filter::select_genes(&view, &route.references, route.argument, 8 * 1024 * 1024)
                .unwrap_or_else(|error| panic!("{} selection: {error}", route.identity));
        assert_eq!(
            selection.outliers, route.outliers,
            "{} outliers",
            route.identity
        );
        assert_eq!(
            selection.selected, route.selected,
            "{} selected",
            route.identity
        );
        active_routes += usize::from(route.active);
        empty_outliers += usize::from(selection.outliers.as_ref().is_some_and(Vec::is_empty));
        zero_selected += usize::from(selection.selected.is_empty());
        let selected_genes: Vec<_> = selection
            .selected
            .iter()
            .map(|&index| genes[index].clone())
            .collect();
        let mut selected_values = Vec::with_capacity(selection.selected.len() * route.cell_count);
        for cell in 0..route.cell_count {
            for &gene in &selection.selected {
                selected_values.push(values[cell * route.features + gene]);
            }
        }
        {
            let expected = named_matrix(&root, route.filtered_expression, &selected_genes, &cells);
            assert_eq!(selected_values.len(), expected.len());
            for (position, (actual, expected)) in selected_values.iter().zip(expected).enumerate() {
                assert_eq!(
                    actual.to_bits(),
                    expected.to_bits(),
                    "{} selected value {position}",
                    route.identity
                );
            }
        }
        let selected_view =
            CellProfiles::new(&selected_values, selection.selected.len(), route.cell_count)
                .unwrap();
        let mut route_trees = 0;
        for (index, profile) in profiles
            .iter()
            .enumerate()
            .filter(|(_, profile)| profile.identity.rsplit_once('/').unwrap().0 == route.identity)
        {
            assert!(tree_ids.insert(profile.identity));
            assert_eq!(profile.matrix, route.filtered_expression);
            assert_eq!(
                (profile.features, profile.cells),
                (selection.selected.len(), route.cell_count)
            );
            total_pairs += assert_native_selected_tree(
                &selected_view,
                profile,
                &trees[index * 6..index * 6 + 6],
            );
            route_trees += 1;
        }
        println!(
            "exact native filter route {}: active={}, features={}, selected={}, cells={}, trees={route_trees}",
            route.identity,
            route.active,
            route.features,
            selection.selected.len(),
            route.cell_count
        );
    }
    assert_eq!(route_ids.len(), 52);
    assert_eq!(tree_ids.len(), 152);
    assert_eq!(active_routes, 20);
    assert_eq!(empty_outliers, 4);
    assert_eq!(zero_selected, 6);
    assert_eq!(total_pairs, 107331);
    println!(
        "exact native filter totals: routes=52 active=20 empty_outliers=4 zero_selected=6 trees=152 pairs=107331"
    );
}
