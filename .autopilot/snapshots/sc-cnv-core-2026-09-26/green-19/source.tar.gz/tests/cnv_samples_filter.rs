#[path = "../src/cnv/samples/condensed.rs"]
mod condensed;
#[path = "../src/cnv/samples/distance.rs"]
mod distance;
#[path = "../src/cnv/samples/filter.rs"]
mod filter;

use distance::CellProfiles;
use std::mem::size_of;

#[test]
fn inactive_guards_preserve_all_rows_and_null_outliers() {
    let values = [f64::MAX, -f64::MAX, 1.0, 2.0, 3.0, 4.0];
    let profiles = CellProfiles::new(&values, 2, 3).unwrap();
    for argument in [0.0, -0.0, -1.0, -f64::MAX] {
        let selection = filter::select_genes(&profiles, &[1, 0], argument, 16).unwrap();
        assert_eq!(selection.outliers, None);
        assert_eq!(selection.selected, [0, 1]);
    }
    for argument in [0.2, 0.8, f64::MAX] {
        let selection = filter::select_genes(&profiles, &[], argument, 16).unwrap();
        assert_eq!(selection.outliers, None);
        assert_eq!(selection.selected, [0, 1]);
    }
}

#[test]
fn invalid_references_are_rejected_even_when_filtering_is_inactive() {
    let profiles = CellProfiles::new(&[1.0, 2.0, 3.0], 1, 3).unwrap();
    for references in [&[0, 0][..], &[2, 1, 2][..], &[3][..], &[usize::MAX, 0][..]] {
        for argument in [0.0, -1.0, 0.8] {
            assert!(filter::select_genes(&profiles, references, argument, usize::MAX).is_err());
        }
    }
}

#[test]
fn nonfinite_arguments_are_rejected_even_without_references() {
    let profiles = CellProfiles::new(&[1.0, 2.0], 1, 2).unwrap();
    for argument in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
        for references in [&[][..], &[0, 1][..]] {
            assert!(filter::select_genes(&profiles, references, argument, usize::MAX).is_err());
        }
    }
}

#[test]
fn original_boundary_columns_use_fixed_threshold_and_leave_input_unchanged() {
    let column = [
        "0.64722581337460472",
        "1.1989999999999998",
        "1.2",
        "1.2010000000000001",
        "2.7989999999999999",
        "2.7999999999999998",
        "2.8010000000000002",
        "3.3527741866253953",
    ]
    .map(|value| value.parse::<f64>().unwrap());
    let values: Vec<_> = column.into_iter().chain(column).collect();
    let before: Vec<_> = values.iter().map(|value| value.to_bits()).collect();
    let profiles = CellProfiles::new(&values, 8, 2).unwrap();
    assert_eq!(profiles.distances(&[1, 0], 8).unwrap(), [0.0]);
    for argument in [f64::from_bits(1), 0.2, 0.8, 5.0, f64::MAX] {
        let selection = filter::select_genes(&profiles, &[0, 1], argument, 128).unwrap();
        assert_eq!(selection.outliers, Some(vec![0, 1, 2, 6, 7]));
        assert_eq!(selection.selected, [3, 4, 5]);
    }
    assert_eq!(
        values
            .iter()
            .map(|value| value.to_bits())
            .collect::<Vec<_>>(),
        before
    );
    assert_eq!(profiles.distances(&[1, 0], 8).unwrap(), [0.0]);
}

#[test]
fn constant_references_yield_active_empty_outliers_and_zero_selected_rows() {
    let values = [2.0, 2.0, 2.0, 2.0, 2.0, 2.0, f64::MAX, -f64::MAX, 0.0];
    let profiles = CellProfiles::new(&values, 3, 3).unwrap();
    let selection = filter::select_genes(&profiles, &[1, 0], 0.8, 48).unwrap();
    assert_eq!(selection.outliers, Some(vec![]));
    assert!(selection.selected.is_empty());
}

#[test]
fn active_sample_count_uses_all_reference_elements_and_requires_two() {
    let empty = CellProfiles::new(&[], 0, 3).unwrap();
    assert!(filter::select_genes(&empty, &[0, 1], 0.8, usize::MAX).is_err());
    let single = CellProfiles::new(&[1.0, 2.0, 3.0], 1, 3).unwrap();
    assert!(filter::select_genes(&single, &[2], 0.8, usize::MAX).is_err());
    let selection = filter::select_genes(&empty, &[], 0.8, 0).unwrap();
    assert_eq!(selection.outliers, None);
    assert!(selection.selected.is_empty());
    let two_elements = CellProfiles::new(&[0.0, 1.0], 2, 1).unwrap();
    let selection = filter::select_genes(&two_elements, &[0], 0.8, 32).unwrap();
    assert_eq!(selection.outliers, Some(vec![]));
    assert!(selection.selected.is_empty());
}

#[test]
fn nonconstant_zero_variance_underflow_is_not_treated_as_constant() {
    for delta in [f64::from_bits(1), 1e-200] {
        let values = [0.0, delta];
        let profiles = CellProfiles::new(&values, 1, 2).unwrap();
        assert!(filter::select_genes(&profiles, &[0, 1], 0.8, 16).is_err());
    }
}

#[test]
fn nonfinite_reference_reductions_corrections_and_variance_are_rejected() {
    for values in [
        vec![f64::MAX, f64::MAX / 2.0],
        vec![f64::MAX, -f64::MAX, -f64::MAX],
        vec![1e200, -1e200],
    ] {
        let references: Vec<_> = (0..values.len()).collect();
        let profiles = CellProfiles::new(&values, 1, values.len()).unwrap();
        assert!(filter::select_genes(&profiles, &references, 0.8, usize::MAX).is_err());
    }
}

#[test]
fn exact_active_and_inactive_output_peaks_are_enforced_for_empty_results() {
    let profiles = CellProfiles::new(&[2.0; 12], 4, 3).unwrap();
    let word = size_of::<usize>();
    assert_eq!(filter::required_workspace(4, 2, true).unwrap(), 8 * word);
    assert_eq!(filter::required_workspace(4, 2, false).unwrap(), 4 * word);
    for (argument, words) in [(0.8, 8), (0.0, 4)] {
        assert!(filter::select_genes(&profiles, &[1, 0], argument, words * word).is_ok());
        assert!(filter::select_genes(&profiles, &[1, 0], argument, words * word - 1).is_err());
    }
}

#[test]
fn exact_reference_validation_peak_is_enforced_on_both_guard_branches() {
    let profiles = CellProfiles::new(&[-2.0, -1.0, 0.0, 1.0, 2.0, 3.0], 1, 6).unwrap();
    let references = [5, 1, 3, 0, 2, 4];
    let before = references;
    let budget = 6 * size_of::<usize>();
    for active in [false, true] {
        assert_eq!(filter::required_workspace(1, 6, active).unwrap(), budget);
        let argument = if active { 0.8 } else { 0.0 };
        assert!(filter::select_genes(&profiles, &references, argument, budget).is_ok());
        assert!(filter::select_genes(&profiles, &references, argument, budget - 1).is_err());
    }
    assert_eq!(references, before);
}

#[test]
fn checked_workspace_arithmetic_rejects_both_index_and_output_overflows() {
    let limit = usize::MAX / size_of::<usize>();
    assert_eq!(filter::required_workspace(0, 0, false).unwrap(), 0);
    assert_eq!(filter::required_workspace(0, 0, true).unwrap(), 0);
    for active in [false, true] {
        assert!(filter::required_workspace(0, limit + 1, active).is_err());
    }
    assert!(filter::required_workspace(limit + 1, 0, false).is_err());
    assert!(filter::required_workspace(limit / 2 + 1, 0, true).is_err());
    assert!(filter::required_workspace(usize::MAX, usize::MAX, true).is_err());
}
