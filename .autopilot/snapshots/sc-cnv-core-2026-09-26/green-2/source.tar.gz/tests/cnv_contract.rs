use rsomics_common::RsomicsError;
use rsomics_sc::cnv::{
    Cell, Gene, PreparedCounts, PreprocessConfig, ReferenceMode, run, run_with_observer,
};

fn genes() -> Vec<Gene> {
    vec![
        Gene {
            id: "a".into(),
            chromosome: "chr1".into(),
            start: 1,
            end: 1,
        },
        Gene {
            id: "b".into(),
            chromosome: "chr1".into(),
            start: 2,
            end: 2,
        },
    ]
}

fn cells() -> Vec<Cell> {
    vec![
        Cell {
            id: "n".into(),
            group: "normal".into(),
        },
        Cell {
            id: "t".into(),
            group: "tumor".into(),
        },
    ]
}

fn input() -> PreparedCounts {
    PreparedCounts::new(genes(), cells(), vec![1.0, 3.0, 3.0, 1.0]).unwrap()
}

fn config(references: ReferenceMode) -> PreprocessConfig {
    PreprocessConfig {
        cutoff: 0.0,
        min_cells_per_gene: 1,
        window_length: 1,
        max_centered_threshold: 3.0,
        references,
        max_numeric_bytes: 4096,
    }
}

fn close(actual: f64, expected: f64) {
    assert!(
        (actual - expected).abs() < 1e-12,
        "actual={actual}, expected={expected}"
    );
}

#[test]
fn single_reference_witness_and_borrowed_input_remain_unchanged() {
    let input = input();
    let output = run(
        &input,
        &config(ReferenceMode::GroupBounds(vec!["normal".into()])),
    )
    .unwrap();
    assert_eq!(output.genes(), genes());
    assert_eq!(output.cells(), cells());
    assert_eq!(output.gene_count(), 2);
    assert_eq!(output.cell_count(), 2);
    assert_eq!(output.values().len(), 4);
    for (actual, expected) in output.values().iter().zip([1.0, 1.0, 2.0, 0.5]) {
        close(*actual, expected);
    }
    assert_eq!(input.state().values(), &[1.0, 3.0, 3.0, 1.0]);
}

#[test]
fn all_cells_proxy_yields_reciprocal_square_root_signals() {
    let input = input();
    let output = run(&input, &config(ReferenceMode::AllCells)).unwrap();
    let root_two = 2.0_f64.sqrt();
    assert_eq!(output.values().len(), 4);
    for (actual, expected) in
        output
            .values()
            .iter()
            .zip([1.0 / root_two, root_two, root_two, 1.0 / root_two])
    {
        close(*actual, expected);
    }
}

#[test]
fn public_value_accessor_uses_gene_then_cell_on_a_non_square_matrix() {
    let third = Gene {
        id: "c".into(),
        chromosome: "chr1".into(),
        start: 3,
        end: 3,
    };
    let mut genes = genes();
    genes.push(third);
    let input = PreparedCounts::new(genes, cells(), vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0]).unwrap();
    assert_eq!(input.state().value(2, 0), Some(3.0));
    assert_eq!(input.state().value(0, 1), Some(4.0));
    assert_eq!(input.state().value(2, 1), Some(6.0));
    assert_eq!(input.state().value(3, 0), None);
}

#[test]
fn named_reference_must_exist_without_implicit_all_cells_fallback() {
    let result = run(
        &input(),
        &config(ReferenceMode::GroupBounds(vec!["normla".into()])),
    );
    assert!(
        matches!(result, Err(RsomicsError::ConfigError(message)) if message.contains("normla"))
    );
}

#[test]
fn empty_and_duplicate_reference_names_are_rejected() {
    for names in [
        vec![],
        vec!["".into()],
        vec!["normal".into(), "normal".into()],
    ] {
        let result = run(&input(), &config(ReferenceMode::GroupMean(names)));
        assert!(matches!(result, Err(RsomicsError::ConfigError(_))));
    }
}

#[test]
fn gene_and_cell_names_must_be_nonempty_and_unique() {
    let mut cases = Vec::new();
    let mut empty_gene = genes();
    empty_gene[0].id.clear();
    cases.push((empty_gene, cells()));
    let mut duplicate_gene = genes();
    duplicate_gene[1].id = "a".into();
    cases.push((duplicate_gene, cells()));
    let mut empty_cell = cells();
    empty_cell[0].id.clear();
    cases.push((genes(), empty_cell));
    let mut duplicate_cell = cells();
    duplicate_cell[1].id = "n".into();
    cases.push((genes(), duplicate_cell));
    let mut empty_group = cells();
    empty_group[0].group.clear();
    cases.push((genes(), empty_group));
    for (genes, cells) in cases {
        assert!(matches!(
            PreparedCounts::new(genes, cells, vec![1.0, 3.0, 3.0, 1.0]),
            Err(RsomicsError::InvalidInput(_))
        ));
    }
}

#[test]
fn counts_must_be_finite_nonnegative_and_match_shape() {
    for bad in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY, -1.0] {
        let mut values = vec![1.0, 3.0, 3.0, 1.0];
        values[0] = bad;
        assert!(matches!(
            PreparedCounts::new(genes(), cells(), values),
            Err(RsomicsError::InvalidInput(_))
        ));
    }
    for values in [vec![1.0, 3.0, 3.0], vec![1.0, 3.0, 3.0, 1.0, 5.0]] {
        assert!(matches!(
            PreparedCounts::new(genes(), cells(), values),
            Err(RsomicsError::InvalidInput(_))
        ));
    }
    assert!(PreparedCounts::new(vec![], cells(), vec![]).is_err());
    assert!(PreparedCounts::new(genes(), vec![], vec![]).is_err());
    assert!(PreparedCounts::new(genes(), cells(), vec![0.0, 0.0, 3.0, 1.0]).is_err());
}

#[test]
fn genomic_order_requires_valid_contiguous_sorted_chromosome_blocks() {
    let mut invalid_coordinate = genes();
    invalid_coordinate[0].start = 3;
    assert!(PreparedCounts::new(invalid_coordinate, cells(), vec![1.0; 4]).is_err());
    let mut zero_coordinate = genes();
    zero_coordinate[0].start = 0;
    zero_coordinate[0].end = 0;
    assert!(PreparedCounts::new(zero_coordinate, cells(), vec![1.0; 4]).is_err());
    let mut no_chromosome = genes();
    no_chromosome[0].chromosome.clear();
    assert!(PreparedCounts::new(no_chromosome, cells(), vec![1.0; 4]).is_err());
    let mut unordered = genes();
    unordered.swap(0, 1);
    assert!(PreparedCounts::new(unordered, cells(), vec![1.0; 4]).is_err());
    let mut repeated = genes();
    repeated[1].chromosome = "chr2".into();
    repeated.push(Gene {
        id: "c".into(),
        chromosome: "chr1".into(),
        start: 3,
        end: 3,
    });
    assert!(PreparedCounts::new(repeated, cells(), vec![1.0; 6]).is_err());
}

#[test]
fn invalid_numeric_configuration_and_insufficient_budget_fail_before_processing() {
    for cutoff in [f64::NAN, f64::INFINITY, -0.1] {
        let mut candidate = config(ReferenceMode::AllCells);
        candidate.cutoff = cutoff;
        assert!(run(&input(), &candidate).is_err());
    }
    for threshold in [f64::NAN, f64::INFINITY, 0.0, -1.0] {
        let mut candidate = config(ReferenceMode::AllCells);
        candidate.max_centered_threshold = threshold;
        assert!(run(&input(), &candidate).is_err());
    }
    let mut candidate = config(ReferenceMode::AllCells);
    candidate.min_cells_per_gene = 0;
    assert!(run(&input(), &candidate).is_err());
    for window in [0, 2] {
        let mut candidate = config(ReferenceMode::AllCells);
        candidate.window_length = window;
        assert!(run(&input(), &candidate).is_err());
    }
    let mut candidate = config(ReferenceMode::AllCells);
    candidate.max_numeric_bytes = 0;
    assert!(run(&input(), &candidate).is_err());
}

#[test]
fn workspace_budget_has_a_checked_exact_boundary() {
    let input = input();
    let mut candidate = config(ReferenceMode::AllCells);
    candidate.max_numeric_bytes = 175;
    assert!(run(&input, &candidate).is_err());
    candidate.max_numeric_bytes = 176;
    assert!(run(&input, &candidate).is_ok());
}

#[test]
fn all_filtered_genes_and_zero_post_filter_depth_fail_loudly() {
    let mut remove_all = config(ReferenceMode::AllCells);
    remove_all.cutoff = 4.0;
    assert!(run(&input(), &remove_all).is_err());

    let input = PreparedCounts::new(genes(), cells(), vec![10.0, 0.0, 0.0, 1.0]).unwrap();
    let mut remove_only_tumor_depth = config(ReferenceMode::AllCells);
    remove_only_tumor_depth.cutoff = 1.0;
    assert!(run(&input, &remove_only_tumor_depth).is_err());
}

#[test]
fn stage_three_uses_post_filter_depth_for_a_surviving_gene_matrix() {
    let mut ordered_genes = genes();
    ordered_genes.push(Gene {
        id: "c".into(),
        chromosome: "chr1".into(),
        start: 3,
        end: 3,
    });
    let input =
        PreparedCounts::new(ordered_genes, cells(), vec![4.0, 2.0, 8.0, 2.0, 2.0, 0.0]).unwrap();
    let mut candidate = config(ReferenceMode::AllCells);
    candidate.min_cells_per_gene = 2;
    let mut observed = Vec::new();
    let mut callbacks = 0;
    run_with_observer(&input, &candidate, |stage, state| {
        if stage.step() == 3 {
            callbacks += 1;
            assert_eq!(state.genes(), genes().as_slice());
            observed.extend_from_slice(state.values());
        }
        Ok(())
    })
    .unwrap();
    assert_eq!(callbacks, 1);
    assert_eq!(observed.len(), 4);
    for (actual, expected) in observed.into_iter().zip([10.0 / 3.0, 5.0 / 3.0, 2.5, 2.5]) {
        close(actual, expected);
    }
}

#[test]
fn observer_receives_exact_order_and_interrupts_before_later_stages() {
    let input = input();
    let mut steps = Vec::new();
    let result = run_with_observer(&input, &config(ReferenceMode::AllCells), |stage, state| {
        steps.push(stage.step());
        assert_eq!(state.cells(), cells());
        if stage.step() == 10 {
            return Err(RsomicsError::InvalidInput("observer stop".into()));
        }
        Ok(())
    });
    assert!(
        matches!(result, Err(RsomicsError::InvalidInput(message)) if message == "observer stop")
    );
    assert_eq!(steps, [1, 2, 3, 4, 8, 9, 10]);
    assert_eq!(input.state().values(), &[1.0, 3.0, 3.0, 1.0]);
}

#[test]
fn group_mean_weights_groups_equally_not_cells() {
    let input = PreparedCounts::new(
        genes(),
        vec![
            Cell {
                id: "a".into(),
                group: "a".into(),
            },
            Cell {
                id: "b1".into(),
                group: "b".into(),
            },
            Cell {
                id: "b2".into(),
                group: "b".into(),
            },
            Cell {
                id: "obs".into(),
                group: "tumor".into(),
            },
        ],
        vec![1.0, 3.0, 2.0, 2.0, 2.0, 2.0, 3.0, 1.0],
    )
    .unwrap();
    let mut stage_eight = Vec::new();
    run_with_observer(
        &input,
        &config(ReferenceMode::GroupMean(vec!["a".into(), "b".into()])),
        |stage, state| {
            if stage.step() == 8 {
                stage_eight.extend_from_slice(state.values());
            }
            Ok(())
        },
    )
    .unwrap();
    close(stage_eight[6], 2.0 - (1.0 + 3.0_f64.log2()) / 2.0);
    close(stage_eight[7], 1.0 - (2.0 + 3.0_f64.log2()) / 2.0);
}

#[test]
fn clamp_saturates_both_signs_but_preserves_values_at_threshold() {
    let input = input();
    for (threshold, expected) in [(0.5, [0.0, 0.0, 0.5, -0.5]), (1.0, [0.0, 0.0, 1.0, -1.0])] {
        let mut candidate = config(ReferenceMode::GroupBounds(vec!["normal".into()]));
        candidate.max_centered_threshold = threshold;
        let mut clamped = Vec::new();
        let mut callbacks = 0;
        run_with_observer(&input, &candidate, |stage, state| {
            if stage.step() == 9 {
                callbacks += 1;
                clamped.extend_from_slice(state.values());
            }
            Ok(())
        })
        .unwrap();
        assert_eq!(callbacks, 1);
        assert_eq!(clamped.len(), 4);
        for (actual, expected) in clamped.into_iter().zip(expected) {
            close(actual, expected);
        }
    }
}
