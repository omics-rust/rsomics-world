# Selected infercnv 1.28.0 numerical fixtures

These 120 expression, gene-order, and cell-group TSVs were copied byte-for-byte from the accepted synthetic oracle artifact, four profiles × ten checkpoints × three TSVs. `sha256-manifest.tsv` lists each copied file's SHA-256, sorted by its relative path. This directory is a selected subset, **not** the complete original bundle. It excludes RDS checkpoints, package source, raw inputs, environment metadata, and the original oracle JSON.

- Original infercnv source commit: `b421d9405c97a309b081ef86d455e976df93eae4`
- Original source archive SHA-256: `b2a1b6f8cc09dc04562513e3cd877b3c97a6efcd5ff92cb5e0763660905e3207`
- Accepted GitHub Actions oracle run: `36216764707`
- Exact control-plane head: `38625af42b55b089678a387b79adf4cc8d4e8a28`
- Original `bundle/sha256-manifest.tsv` SHA-256: `9211aa334c75ac014eca18f8888483c5b881d62b468b8341f9a7baf298e50f57`
- Original artifact ZIP SHA-256: `9152bc2438db96635be7c17116151ff0b3e64fbabc4a4e79050f1a2f3e80ff6d`
- Source directory: `/Volumes/Zane's HDD/rsomics-fixtures/evidence/infercnv-2026-09-26/run-36216764707/artifact/bundle`

The original package/runtime was infercnv 1.28.0, R 4.6.1, Bioconductor 3.23, Ubuntu 24.04.5 x86_64, and OpenBLAS 0.3.26. The upstream run checked stages 1, 2, 3, 4, 8, 9, 10, 11, 12, and 14 only. This is a bounded numerical oracle for prepared counts, not evidence for the complete inferCNV workflow or biological validity.
