use rsomics_sc::cnv::{Cell, Gene};
use std::collections::BTreeMap;
use std::fs;
use std::path::PathBuf;

const STEPS: [u8; 10] = [1, 2, 3, 4, 8, 9, 10, 11, 12, 14];

pub struct ExpectedStage {
    genes: Vec<Gene>,
    cells: Vec<Cell>,
    values: Vec<f64>,
}

impl ExpectedStage {
    pub fn genes(&self) -> &[Gene] {
        &self.genes
    }

    pub fn cells(&self) -> &[Cell] {
        &self.cells
    }

    pub fn values(&self) -> &[f64] {
        &self.values
    }
}

pub struct Fixture {
    stages: BTreeMap<u8, ExpectedStage>,
}

impl Fixture {
    pub fn load(profile: &str) -> Self {
        assert!(matches!(
            profile,
            "single_reference" | "grouped_bounds" | "grouped_mean" | "no_reference"
        ));
        let root = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("tests/fixtures/infercnv-1.28.0")
            .join(profile);
        let mut stages = BTreeMap::new();
        for step in STEPS {
            let stem = format!("{step:02}");
            let gene_table = fs::read_to_string(root.join(format!("{stem}.genes.tsv"))).unwrap();
            let cell_table = fs::read_to_string(root.join(format!("{stem}.cells.tsv"))).unwrap();
            let expression = fs::read_to_string(root.join(format!("{stem}.tsv"))).unwrap();

            let mut genes = Vec::new();
            assert_eq!(gene_table.lines().next().unwrap(), "gene\tchr\tstart\tstop");
            for line in gene_table.lines().skip(1) {
                let fields: Vec<_> = line.split('\t').collect();
                assert_eq!(fields.len(), 4);
                genes.push(Gene {
                    id: fields[0].into(),
                    chromosome: fields[1].into(),
                    start: fields[2].parse().unwrap(),
                    end: fields[3].parse().unwrap(),
                });
            }

            let mut cells = Vec::new();
            assert_eq!(cell_table.lines().next().unwrap(), "cell\tgroup\trole");
            for line in cell_table.lines().skip(1) {
                let fields: Vec<_> = line.split('\t').collect();
                assert_eq!(fields.len(), 3);
                cells.push(Cell {
                    id: fields[0].into(),
                    group: fields[1].into(),
                });
            }

            let mut rows = expression.lines();
            let header = rows.next().unwrap().split('\t').collect::<Vec<_>>();
            assert_eq!(header[0], "gene");
            let expected_cells = cells
                .iter()
                .map(|cell| cell.id.as_str())
                .collect::<Vec<_>>();
            assert_eq!(&header[1..], expected_cells.as_slice());
            let mut values = vec![0.0; genes.len() * cells.len()];
            let mut row_count = 0;
            for (gene_index, line) in rows.enumerate() {
                let fields = line.split('\t').collect::<Vec<_>>();
                assert_eq!(fields.len(), cells.len() + 1);
                assert_eq!(fields[0], genes[gene_index].id.as_str());
                for cell_index in 0..cells.len() {
                    values[cell_index * genes.len() + gene_index] =
                        fields[cell_index + 1].trim().parse().unwrap();
                }
                row_count += 1;
            }
            assert_eq!(row_count, genes.len());
            stages.insert(
                step,
                ExpectedStage {
                    genes,
                    cells,
                    values,
                },
            );
        }
        Self { stages }
    }

    pub fn stage(&self, step: u8) -> &ExpectedStage {
        self.stages.get(&step).unwrap()
    }
}
