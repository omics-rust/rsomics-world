use super::config::PreprocessConfig;
use super::model::{CnvState, PreparedCounts};
use super::{normalize, reference, smooth};
use rsomics_common::{Result, RsomicsError};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Stage {
    Input,
    Filtered,
    DepthNormalized,
    Log2,
    ReferenceCentered,
    Clamped,
    Smoothed,
    CellCentered,
    ReferenceRecentered,
    FoldChange,
}

impl Stage {
    pub fn step(self) -> u8 {
        match self {
            Self::Input => 1,
            Self::Filtered => 2,
            Self::DepthNormalized => 3,
            Self::Log2 => 4,
            Self::ReferenceCentered => 8,
            Self::Clamped => 9,
            Self::Smoothed => 10,
            Self::CellCentered => 11,
            Self::ReferenceRecentered => 12,
            Self::FoldChange => 14,
        }
    }
}

pub fn run(input: &PreparedCounts, config: &PreprocessConfig) -> Result<CnvState> {
    run_with_observer(input, config, |_, _| Ok(()))
}

pub fn run_with_observer(
    input: &PreparedCounts,
    config: &PreprocessConfig,
    mut observer: impl FnMut(Stage, &CnvState) -> Result<()>,
) -> Result<CnvState> {
    let references = config.validate(input)?;
    observer(Stage::Input, input.state())?;

    let mut state = normalize::filter(input, config.cutoff, config.min_cells_per_gene)?;
    observer(Stage::Filtered, &state)?;

    let scratch_len = state.gene_count().max(state.cell_count());
    let mut scratch = Vec::new();
    scratch
        .try_reserve_exact(scratch_len)
        .map_err(|_| RsomicsError::InvalidInput("numerical scratch allocation failed".into()))?;
    scratch.resize(scratch_len, 0.0);

    normalize::normalize_depth(&mut state, &mut scratch)?;
    observer(Stage::DepthNormalized, &state)?;

    normalize::log2_one_plus(&mut state)?;
    observer(Stage::Log2, &state)?;

    reference::subtract(&mut state, &references, &mut scratch)?;
    observer(Stage::ReferenceCentered, &state)?;

    normalize::clamp(&mut state, config.max_centered_threshold);
    observer(Stage::Clamped, &state)?;

    smooth::triangular(&mut state, config.window_length)?;
    observer(Stage::Smoothed, &state)?;

    smooth::center_cells(&mut state, &mut scratch)?;
    observer(Stage::CellCentered, &state)?;

    reference::subtract(&mut state, &references, &mut scratch)?;
    observer(Stage::ReferenceRecentered, &state)?;

    normalize::inverse_log2(&mut state)?;
    observer(Stage::FoldChange, &state)?;
    Ok(state)
}
