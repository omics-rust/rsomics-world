use rsomics_common::{Result, RsomicsError};
use std::collections::HashSet;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Gene {
    pub id: String,
    pub chromosome: String,
    pub start: u64,
    pub end: u64,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Cell {
    pub id: String,
    pub group: String,
}

#[derive(Debug)]
pub struct CnvState {
    pub(crate) genes: Vec<Gene>,
    pub(crate) cells: Vec<Cell>,
    pub(crate) values: Vec<f64>,
}

impl CnvState {
    pub fn genes(&self) -> &[Gene] {
        &self.genes
    }

    pub fn cells(&self) -> &[Cell] {
        &self.cells
    }

    pub fn values(&self) -> &[f64] {
        &self.values
    }

    pub fn gene_count(&self) -> usize {
        self.genes.len()
    }

    pub fn cell_count(&self) -> usize {
        self.cells.len()
    }

    pub fn value(&self, gene: usize, cell: usize) -> Option<f64> {
        if gene >= self.gene_count() || cell >= self.cell_count() {
            None
        } else {
            Some(self.values[cell * self.gene_count() + gene])
        }
    }
}

#[derive(Debug)]
pub struct PreparedCounts {
    state: CnvState,
}

impl PreparedCounts {
    pub fn new(genes: Vec<Gene>, cells: Vec<Cell>, values: Vec<f64>) -> Result<Self> {
        if genes.is_empty() || cells.is_empty() {
            return Err(RsomicsError::InvalidInput(
                "prepared counts require at least one gene and cell".into(),
            ));
        }
        let count = genes
            .len()
            .checked_mul(cells.len())
            .ok_or_else(|| RsomicsError::InvalidInput("prepared count shape overflows".into()))?;
        if values.len() != count {
            return Err(RsomicsError::InvalidInput(format!(
                "prepared count shape expects {count} values, got {}",
                values.len()
            )));
        }

        let mut gene_names = HashSet::new();
        let mut chromosome_names = HashSet::new();
        let mut previous_chromosome: Option<String> = None;
        let mut previous_position = (0, 0);
        for gene in &genes {
            if gene.id.is_empty() || !gene_names.insert(gene.id.clone()) {
                return Err(RsomicsError::InvalidInput(
                    "gene IDs must be nonempty and unique".into(),
                ));
            }
            if gene.chromosome.is_empty()
                || gene.start > gene.end
                || (gene.start == 0 && gene.end == 0)
            {
                return Err(RsomicsError::InvalidInput(format!(
                    "invalid gene coordinates for {}",
                    gene.id
                )));
            }
            if previous_chromosome.as_deref() != Some(gene.chromosome.as_str()) {
                if !chromosome_names.insert(gene.chromosome.clone()) {
                    return Err(RsomicsError::InvalidInput(format!(
                        "chromosome {} occurs in multiple blocks",
                        gene.chromosome
                    )));
                }
                previous_chromosome = Some(gene.chromosome.clone());
            } else if (gene.start, gene.end) < previous_position {
                return Err(RsomicsError::InvalidInput(format!(
                    "genes are unordered within chromosome {}",
                    gene.chromosome
                )));
            }
            previous_position = (gene.start, gene.end);
        }

        let mut cell_names = HashSet::new();
        for cell in &cells {
            if cell.id.is_empty() || !cell_names.insert(cell.id.clone()) || cell.group.is_empty() {
                return Err(RsomicsError::InvalidInput(
                    "cell IDs must be nonempty and unique and groups nonempty".into(),
                ));
            }
        }

        for (index, column) in values.chunks_exact(genes.len()).enumerate() {
            let mut total = 0.0;
            for &value in column {
                if !value.is_finite() || value < 0.0 {
                    return Err(RsomicsError::InvalidInput(
                        "prepared counts must be finite and nonnegative".into(),
                    ));
                }
                total += value;
            }
            if !total.is_finite() || total <= 0.0 {
                return Err(RsomicsError::InvalidInput(format!(
                    "cell {} has zero or nonfinite depth",
                    cells[index].id
                )));
            }
        }
        Ok(Self {
            state: CnvState {
                genes,
                cells,
                values,
            },
        })
    }

    pub fn state(&self) -> &CnvState {
        &self.state
    }
}
