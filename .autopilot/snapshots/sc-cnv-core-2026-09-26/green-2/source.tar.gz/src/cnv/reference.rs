use super::config::ResolvedReferences;
use super::model::CnvState;
use rsomics_common::{Result, RsomicsError};

pub(crate) fn subtract(
    state: &mut CnvState,
    references: &ResolvedReferences,
    scratch: &mut [f64],
) -> Result<()> {
    let genes = state.gene_count();
    let cells = state.cell_count();
    for gene in 0..genes {
        let (lower, upper, mean, bounds) = match references {
            ResolvedReferences::AllCells => {
                let mut sum = 0.0;
                for cell in 0..cells {
                    sum += state.values[cell * genes + gene];
                    if !sum.is_finite() {
                        return Err(nonfinite());
                    }
                }
                let mean = sum / cells as f64;
                (mean, mean, mean, false)
            }
            ResolvedReferences::Bounds(groups) => {
                for (index, group) in groups.iter().enumerate() {
                    scratch[index] = group_mean(state, gene, group)?;
                }
                let lower = scratch[..groups.len()]
                    .iter()
                    .copied()
                    .fold(f64::INFINITY, f64::min);
                let upper = scratch[..groups.len()]
                    .iter()
                    .copied()
                    .fold(f64::NEG_INFINITY, f64::max);
                (lower, upper, 0.0, true)
            }
            ResolvedReferences::Mean(groups) => {
                let mut total = 0.0;
                for group in groups {
                    total += group_mean(state, gene, group)?;
                    if !total.is_finite() {
                        return Err(nonfinite());
                    }
                }
                let mean = total / groups.len() as f64;
                (mean, mean, mean, false)
            }
        };
        for cell in 0..cells {
            let value = &mut state.values[cell * genes + gene];
            *value = if bounds {
                if *value < lower {
                    *value - lower
                } else if *value > upper {
                    *value - upper
                } else {
                    0.0
                }
            } else {
                *value - mean
            };
            if !value.is_finite() {
                return Err(nonfinite());
            }
        }
    }
    Ok(())
}

fn group_mean(state: &CnvState, gene: usize, indices: &[usize]) -> Result<f64> {
    let genes = state.gene_count();
    let mut total = 0.0;
    for &cell in indices {
        total += state.values[cell * genes + gene];
        if !total.is_finite() {
            return Err(nonfinite());
        }
    }
    let mean = total / indices.len() as f64;
    if !mean.is_finite() {
        return Err(nonfinite());
    }
    Ok(mean)
}

fn nonfinite() -> RsomicsError {
    RsomicsError::InvalidInput("reference reduction or result is nonfinite".into())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cnv::{Cell, Gene};

    fn state() -> CnvState {
        CnvState {
            genes: vec![Gene {
                id: "g".into(),
                chromosome: "chr1".into(),
                start: 1,
                end: 1,
            }],
            cells: vec![
                Cell {
                    id: "a".into(),
                    group: "a".into(),
                },
                Cell {
                    id: "b1".into(),
                    group: "b".into(),
                },
                Cell {
                    id: "b2".into(),
                    group: "b".into(),
                },
                Cell {
                    id: "obs".into(),
                    group: "tumor".into(),
                },
            ],
            values: vec![1.0, 3.0, 3.0, 8.0],
        }
    }

    #[test]
    fn group_mean_weights_groups_equally_despite_unequal_cell_counts() {
        let mut state = state();
        let groups = ResolvedReferences::Mean(vec![vec![0], vec![1, 2]]);
        subtract(&mut state, &groups, &mut [0.0; 4]).unwrap();
        assert_eq!(state.values, [-1.0, 1.0, 1.0, 6.0]);
    }

    #[test]
    fn group_bounds_zero_inside_and_subtract_nearest_endpoint_outside() {
        let mut state = state();
        let groups = ResolvedReferences::Bounds(vec![vec![0], vec![1, 2]]);
        subtract(&mut state, &groups, &mut [0.0; 4]).unwrap();
        assert_eq!(state.values, [0.0, 0.0, 0.0, 5.0]);
    }
}
