# rsomics-sc

This is an unreleased product-local numerical core under development, not a usable inferCNV replacement. Its CNV boundary accepts dense, column-major, already selected and genomically ordered stage-1 counts. Raw-file creation, annotated persisted state, clustering, HMM, denoising, plots, performance gates, and a unified product CLI are not implemented. No public binary or package release is available.

The oracle fixtures exercise the pre-clustering numerical checkpoints of source-pinned infercnv 1.28.0 on synthetic input. They do not establish raw-input, downstream-workflow, biological, or real-data compatibility.
