fn main() {
    cc::Build::new()
        .cpp(true)
        .std("c++17")
        .file("cpp/annoy_shim.cpp")
        .include("vendor/annoy")
        .compile("rsomics_annoy");
    println!("cargo:rerun-if-changed=cpp/annoy_shim.cpp");
    println!("cargo:rerun-if-changed=vendor/annoy");
}
