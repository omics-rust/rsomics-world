use std::io;
use std::num::NonZeroUsize;
use std::path::{Path, PathBuf};

mod report;
use report::{AdditionalResults, SamplesReport};

use clap::{Args, Parser, Subcommand, ValueEnum};
use rsomics_common::{
    OutputArgs, Result, RsomicsError, ThreadArgs, ToolMeta, reject_output_alias, write_output,
};
use rsomics_sc::cnv::{
    self, BayesConfig, CreationConfig, DenoiseConfig, DiscoveryConfig, DiscoveryMethod, HmmConfig,
    InputPaths, NoiseFilter, PreprocessConfig, ReferenceMode, SamplesConfig,
};
use serde::Serialize;

pub const META: ToolMeta = ToolMeta {
    name: env!("CARGO_PKG_NAME"),
    version: env!("CARGO_PKG_VERSION"),
};

#[derive(Debug, Parser)]
#[command(
    name = "rsomics-sc",
    version,
    about = "Native single-cell workflows (unreleased)",
    subcommand_required = true,
    arg_required_else_help = true
)]
pub struct Cli {
    #[command(subcommand)]
    command: Command,

    #[command(flatten)]
    pub output: OutputArgs,

    #[command(flatten)]
    threads: ThreadArgs,
}

#[derive(Debug, Subcommand)]
enum Command {
    /// Expression-based copy-number workflows.
    #[command(subcommand)]
    Cnv(CnvCommand),
}

#[derive(Debug, Subcommand)]
enum CnvCommand {
    /// Preprocess raw counts, cluster samples, and optionally infer i6 copy-number states.
    #[command(
        after_help = "Unreleased. HMM supports grouped samples with optional Bayesian refinement. Subclusters, per-cell inference and plots are not implemented."
    )]
    Samples(SamplesArgs),
}

#[derive(Clone, Copy, Debug, ValueEnum)]
enum SubclusterMethod {
    Pca,
    Simple,
}

#[derive(Debug, Args)]
struct SamplesArgs {
    /// Counts TSV: explicit gene-column header followed by cell IDs; plain or gzip.
    #[arg(long)]
    counts: PathBuf,

    /// Headerless gene/chromosome/start/end TSV; plain or gzip.
    #[arg(long)]
    positions: PathBuf,

    /// Headerless cell/group TSV; plain or gzip. IDs are literal, including V1.
    #[arg(long)]
    annotations: PathBuf,

    /// Self-contained JSON report; '-' writes stdout and cannot be used with --json.
    #[arg(short, long)]
    output: PathBuf,

    /// Reference group name; repeat for multiple groups. Omit to use all cells as reference.
    #[arg(long = "reference")]
    references: Vec<String>,

    /// Center by the equally weighted reference-group mean instead of group bounds.
    #[arg(long, requires = "references")]
    reference_mean: bool,

    /// Cluster observation groups separately instead of pooling all observations.
    #[arg(long)]
    cluster_by_groups: bool,

    /// Discover grouped cell subclusters with PCA/SNN or raw-expression kNN.
    #[arg(
        long,
        value_enum,
        requires = "cluster_by_groups",
        conflicts_with = "hmm",
        hide = true
    )]
    subcluster_method: Option<SubclusterMethod>,

    /// Neighbor count for subcluster discovery; groups with no more cells retain one subgroup.
    #[arg(
        long,
        requires = "subcluster_method",
        default_value = "20",
        hide = true
    )]
    subcluster_knn: NonZeroUsize,

    /// Native keyed Leiden seed; does not reproduce the R/igraph random stream.
    #[arg(long, requires = "subcluster_method", default_value_t = 0, hide = true)]
    subcluster_seed: u32,

    /// Infer grouped-sample i6 states and CNV regions.
    #[arg(long, requires = "cluster_by_groups")]
    hmm: bool,

    /// Nonnegative R-compatible integer seed for i6 calibration.
    #[arg(long, requires = "hmm", default_value_t = 0)]
    hmm_seed: u32,

    /// Off-diagonal state transition probability; must be between 0 and 0.2.
    #[arg(long, requires = "hmm", default_value_t = 1e-6)]
    hmm_transition_prob: f64,

    /// Pool reference groups when simulating HMM calibration cells.
    #[arg(long, requires = "hmm")]
    hspike_aggregate_normals: bool,

    /// Refine grouped i6 CNVs with the Bayesian cell-mixture model.
    #[arg(long, requires = "hmm")]
    bayes: bool,

    /// Remove regions above this normal probability in [0, 1]; zero disables Bayesian refinement.
    #[arg(long, requires = "bayes", default_value_t = 0.5)]
    bayes_max_p_normal: f64,

    /// Reproducible native Bayesian seed; does not select JAGS random streams.
    #[arg(long, requires = "bayes", default_value_t = 0)]
    bayes_seed: u32,

    /// Enable reference filtering when positive (fixed upstream cutoff 0.8); zero disables.
    #[arg(long, default_value_t = 0.8)]
    z_score_filter: f64,

    /// Minimum mean raw count across cells for retaining a gene.
    #[arg(long, default_value_t = 0.1)]
    cutoff: f64,

    /// Minimum number of positive-count cells for retaining a gene.
    #[arg(long, default_value_t = 3)]
    min_cells_per_gene: usize,

    /// Positive odd triangular smoothing window, truncated at chromosome ends.
    #[arg(long, default_value_t = 101)]
    window_length: usize,

    /// Positive symmetric clamp threshold for centered log2 expression.
    #[arg(long, default_value_t = 3.0)]
    max_centered_threshold: f64,

    /// Inclusive cell-depth lower bound; values below one are clamped to one.
    #[arg(long, default_value_t = 1.0)]
    min_counts_per_cell: f64,

    /// Inclusive cell-depth upper bound; inf disables the upper bound.
    #[arg(long, default_value = "inf")]
    max_counts_per_cell: f64,

    /// Excluded chromosome labels; replaces defaults. Pass no labels to retain all.
    #[arg(long = "exclude-chromosome", value_delimiter = ',', num_args = 0.., default_values = ["chrX", "chrY", "chrM"])]
    excluded_chromosomes: Vec<String>,

    /// Per-stage numerical/workspace byte ceiling; excludes metadata, retained prior stages, and RSS.
    #[arg(long, default_value_t = 1_073_741_824)]
    max_numeric_bytes: usize,

    /// Maximum decoded TSV record bytes, including CR/LF; not a whole-input memory ceiling.
    #[arg(long, default_value_t = 16_777_216)]
    max_record_bytes: usize,

    /// Include the step-14 expression matrix as column-major values in the JSON report.
    #[arg(long)]
    include_expression: bool,

    /// Denoise after clustering and include the separate step-22 expression matrix.
    #[arg(long)]
    denoise: bool,

    /// Fixed noise half-width; nonpositive disables denoising instead of the default SD rule.
    #[arg(
        long,
        requires = "denoise",
        conflicts_with = "sd_amplifier",
        allow_negative_numbers = true
    )]
    noise_filter: Option<f64>,

    /// Nonnegative multiplier of the mean reference-cell gene SD (default: 1.5).
    #[arg(long, requires = "denoise", conflicts_with = "noise_filter")]
    sd_amplifier: Option<f64>,

    /// Shrink deviations with the upstream logistic curve instead of hard whitening.
    #[arg(long, requires = "denoise")]
    noise_logistic: bool,
}

#[derive(Debug, Serialize)]
pub struct CommandSummary {
    operation: &'static str,
    report: PathBuf,
    genes: usize,
    cells: usize,
    selected_genes: usize,
    groups: usize,
    threads: usize,
}

impl Cli {
    pub fn execute(self) -> Result<CommandSummary> {
        let threads = match self.threads.requested() {
            Some(threads) => threads,
            None => std::thread::available_parallelism()?,
        }
        .get();
        match self.command {
            Command::Cnv(CnvCommand::Samples(args)) => args.execute(self.output.json, threads),
        }
    }
}

impl SamplesArgs {
    fn execute(self, json: bool, threads: usize) -> Result<CommandSummary> {
        let hmm_config = self
            .hmm
            .then(|| {
                HmmConfig::new(
                    self.hmm_seed,
                    self.hmm_transition_prob,
                    self.hspike_aggregate_normals,
                    threads,
                    self.max_numeric_bytes,
                )
            })
            .transpose()?;
        let bayes_config = self
            .bayes
            .then(|| {
                BayesConfig::new(
                    self.bayes_max_p_normal,
                    self.bayes_seed,
                    threads,
                    self.max_numeric_bytes,
                )
            })
            .transpose()?;
        let denoise_config = self
            .denoise
            .then(|| {
                DenoiseConfig::new(
                    self.noise_filter.map_or_else(
                        || NoiseFilter::ReferenceSd(self.sd_amplifier.unwrap_or(1.5)),
                        NoiseFilter::Fixed,
                    ),
                    self.noise_logistic,
                    threads,
                    self.max_numeric_bytes,
                )
            })
            .transpose()?;
        if json && self.output == Path::new("-") {
            return Err(RsomicsError::ConfigError(
                "--json requires a named --output report; stdout is reserved for the result envelope"
                    .into(),
            ));
        }
        reject_output_alias(
            &self.output,
            [
                self.counts.as_path(),
                self.positions.as_path(),
                self.annotations.as_path(),
            ],
        )?;
        let input = cnv::create_input(
            InputPaths {
                counts: &self.counts,
                positions: &self.positions,
                annotations: &self.annotations,
            },
            &CreationConfig {
                reference_groups: self.references.clone(),
                excluded_chromosomes: self.excluded_chromosomes.clone(),
                min_counts_per_cell: self.min_counts_per_cell,
                max_counts_per_cell: self.max_counts_per_cell,
                max_numeric_bytes: self.max_numeric_bytes,
                max_record_bytes: self.max_record_bytes,
            },
        )?;
        let references = if self.references.is_empty() {
            ReferenceMode::AllCells
        } else if self.reference_mean {
            ReferenceMode::GroupMean(self.references.clone())
        } else {
            ReferenceMode::GroupBounds(self.references.clone())
        };
        let preprocess_config = PreprocessConfig {
            cutoff: self.cutoff,
            min_cells_per_gene: self.min_cells_per_gene,
            window_length: self.window_length,
            max_centered_threshold: self.max_centered_threshold,
            references,
            threads,
            max_numeric_bytes: self.max_numeric_bytes,
        };
        let samples_config = SamplesConfig {
            cluster_by_groups: self.cluster_by_groups,
            z_score_filter: self.z_score_filter,
            max_workspace_bytes: self.max_numeric_bytes,
            threads,
        };
        let discovery_config = self.subcluster_method.map(|method| DiscoveryConfig {
            method: match method {
                SubclusterMethod::Pca => DiscoveryMethod::Pca,
                SubclusterMethod::Simple => DiscoveryMethod::Simple,
            },
            k_nn: self.subcluster_knn.get(),
            seed: self.subcluster_seed,
        });
        let (state, samples, predictions, bayesian, discovery) = if let Some(config) = &hmm_config {
            let (result, bayesian) = if let Some(bayes_config) = &bayes_config {
                let result = cnv::hmm_samples_with_bayes(
                    &input,
                    &preprocess_config,
                    &samples_config,
                    config,
                    bayes_config,
                )?;
                (result.hmm, Some(result.bayesian))
            } else {
                (
                    cnv::hmm_samples(&input, &preprocess_config, &samples_config, config)?,
                    None,
                )
            };
            (
                result.state,
                result.samples,
                Some(result.predictions),
                bayesian,
                None,
            )
        } else {
            let state = cnv::run(input.prepared_counts(), &preprocess_config)?;
            if let Some(config) = &discovery_config {
                let result = cnv::discover_samples(&state, &input, &samples_config, config)?;
                (state, result.samples, None, None, Some(result.discovery))
            } else {
                let samples = cnv::samples(&state, &input, &samples_config)?;
                (state, samples, None, None, None)
            }
        };
        let denoised = denoise_config
            .as_ref()
            .map(|config| cnv::denoise(&state, &input, config))
            .transpose()?;
        let report = SamplesReport::new(
            &self,
            &input,
            &state,
            &samples,
            AdditionalResults {
                denoised: denoised.as_ref(),
                hmm: predictions.as_ref(),
                bayesian: bayesian.as_ref(),
                discovery: discovery.as_ref(),
            },
            threads,
        );
        write_output(Some(&self.output), |output| {
            serde_json::to_writer_pretty(&mut *output, &report).map_err(|error| {
                RsomicsError::Io(io::Error::other(format!(
                    "serializing samples report: {error}"
                )))
            })?;
            output.write_all(b"\n").map_err(RsomicsError::Io)
        })?;
        Ok(CommandSummary {
            operation: "cnv.samples",
            report: self.output,
            genes: state.gene_count(),
            cells: state.cell_count(),
            selected_genes: samples.selected_gene_indices.len(),
            groups: samples.groups.len(),
            threads,
        })
    }
}
