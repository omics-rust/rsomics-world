mod graph;
mod leiden;
mod pca;
mod tree;

use super::{
    CnvState, CreatedInput, Group, Prepared, SampleGroup, SampleTree, Samples, SamplesConfig,
    bytes, check_budget, condensed, distance::CellProfiles, groups, invalid, parallel, prepare,
    reserved, sum, tree_bytes, ward,
};
use graph::Graph;
use pca::PcaResult;
use rsomics_common::Result;
use serde::Serialize;
use tree::Forest;

#[derive(Clone, Copy, Debug)]
pub enum DiscoveryMethod {
    Pca,
    Simple,
}

impl DiscoveryMethod {
    fn name(self) -> &'static str {
        match self {
            Self::Pca => "PCA",
            Self::Simple => "simple",
        }
    }
}

#[derive(Clone, Copy, Debug)]
pub struct DiscoveryConfig {
    pub method: DiscoveryMethod,
    pub k_nn: usize,
    pub seed: u32,
}

#[derive(Debug)]
pub struct DiscoverySamples {
    pub samples: Samples,
    pub discovery: Discovery,
}

#[derive(Debug)]
pub struct Discovery {
    config: DiscoveryConfig,
    parents: Vec<Parent>,
}

#[derive(Clone, Copy, Debug, Serialize)]
enum Route {
    #[serde(rename = "PCA")]
    Pca,
    #[serde(rename = "simple")]
    Simple,
    #[serde(rename = "too_few_cells")]
    TooFewCells,
    #[serde(rename = "k_nn_at_least_group_size")]
    NeighborBypass,
}

#[derive(Debug)]
struct Parent {
    name: String,
    member_indices: Vec<usize>,
    route: Route,
    resolution: Option<f64>,
    partition: Option<Vec<usize>>,
    subclusters: Vec<Subcluster>,
    tree: Option<SampleTree>,
    pca: Option<PcaResult>,
    graph: Option<Graph>,
}

#[derive(Debug, Serialize)]
struct Subcluster {
    name: String,
    member_indices: Vec<usize>,
}

#[derive(Serialize)]
pub struct DiscoveryReport<'a> {
    step: u8,
    method: &'static str,
    partition_method: &'static str,
    k_nn: usize,
    seed: u32,
    objective_function: &'static str,
    beta: f64,
    iterations: usize,
    groups: Vec<ParentView<'a>>,
}

#[derive(Serialize)]
struct ParentView<'a> {
    name: &'a str,
    member_indices: &'a [usize],
    route: Route,
    resolution: Option<f64>,
    partition: Option<&'a [usize]>,
    subclusters: &'a [Subcluster],
    tree: Option<TreeView<'a>>,
    pca: Option<PcaView<'a>>,
    graph: Option<GraphView<'a>>,
}

#[derive(Serialize)]
struct TreeView<'a> {
    merge: &'a [[i32; 2]],
    height: &'a [f64],
    order: &'a [usize],
}

impl<'a> From<&'a SampleTree> for TreeView<'a> {
    fn from(tree: &'a SampleTree) -> Self {
        Self {
            merge: &tree.merge,
            height: &tree.height,
            order: &tree.order,
        }
    }
}

#[derive(Serialize)]
struct PcaView<'a> {
    feature_indices: &'a [usize],
    feature_scores: &'a [f64],
    scores: &'a [f64],
    loadings: &'a [f64],
    standard_deviations: &'a [f64],
    components: usize,
}

impl<'a> From<&'a PcaResult> for PcaView<'a> {
    fn from(pca: &'a PcaResult) -> Self {
        Self {
            feature_indices: &pca.feature_indices,
            feature_scores: &pca.feature_scores,
            scores: &pca.scores,
            loadings: &pca.loadings,
            standard_deviations: &pca.standard_deviations,
            components: pca.components,
        }
    }
}

#[derive(Serialize)]
struct GraphView<'a> {
    vertices: usize,
    neighbors: &'a [Vec<usize>],
    edges: &'a [(usize, usize, f64)],
}

impl<'a> From<&'a Graph> for GraphView<'a> {
    fn from(graph: &'a Graph) -> Self {
        Self {
            vertices: graph.vertices,
            neighbors: &graph.neighbors,
            edges: &graph.edges,
        }
    }
}

impl Discovery {
    pub fn report(&self) -> DiscoveryReport<'_> {
        DiscoveryReport {
            step: 15,
            method: self.config.method.name(),
            partition_method: "leiden",
            k_nn: self.config.k_nn,
            seed: self.config.seed,
            objective_function: "CPM",
            beta: 0.01,
            iterations: 2,
            groups: self
                .parents
                .iter()
                .map(|parent| ParentView {
                    name: &parent.name,
                    member_indices: &parent.member_indices,
                    route: parent.route,
                    resolution: parent.resolution,
                    partition: parent.partition.as_deref(),
                    subclusters: &parent.subclusters,
                    tree: parent.tree.as_ref().map(TreeView::from),
                    pca: parent.pca.as_ref().map(PcaView::from),
                    graph: parent.graph.as_ref().map(GraphView::from),
                })
                .collect(),
        }
    }
}

struct GroupOutput {
    parent: Parent,
    groups: Vec<SampleGroup>,
}

struct Plan {
    retained: usize,
    workspace: usize,
}

fn product(left: usize, right: usize) -> Result<usize> {
    left.checked_mul(right)
        .ok_or_else(|| invalid("Discovery workspace size overflows"))
}

fn plan(genes: usize, cells: usize, config: &DiscoveryConfig) -> Result<Plan> {
    let tree = if cells > 1 { tree_bytes(cells)? } else { 0 };
    let tree_workspace = if cells > 2 {
        sum(&[
            bytes::<f64>(condensed::pair_count(cells)?)?,
            ward::required_workspace(cells)?,
            product(cells, 256)?,
        ])?
    } else {
        product(cells, 256)?
    };
    let base = sum(&[product(bytes::<usize>(cells)?, 4)?, product(tree, 2)?])?;
    if cells < 3 || config.k_nn >= cells {
        return Ok(Plan {
            retained: base,
            workspace: tree_workspace,
        });
    }
    let edges = match config.method {
        DiscoveryMethod::Pca => sum(&[condensed::pair_count(cells)?, cells])?,
        DiscoveryMethod::Simple => product(cells, config.k_nn)?,
    };
    let graph = sum(&[
        bytes::<(usize, usize, f64)>(edges)?,
        bytes::<usize>(product(cells, config.k_nn)?)?,
        bytes::<Vec<usize>>(cells)?,
        bytes::<usize>(cells)?,
    ])?;
    let pca_retained = match config.method {
        DiscoveryMethod::Pca => {
            let features = genes.min(2_000);
            sum(&[
                bytes::<usize>(features)?,
                bytes::<f64>(features)?,
                bytes::<f64>(product(features, 10)?)?,
                bytes::<f64>(product(cells, 10)?)?,
                bytes::<f64>(10)?,
            ])?
        }
        DiscoveryMethod::Simple => 0,
    };
    let graph_workspace = sum(&[graph, product(edges, 128)?, product(cells, 256)?])?;
    let numerical_workspace = match config.method {
        DiscoveryMethod::Pca => pca::workspace_bytes(genes, cells)?,
        DiscoveryMethod::Simple => sum(&[graph, bytes::<(f64, usize)>(cells)?])?,
    };
    Ok(Plan {
        retained: sum(&[base, graph, pca_retained])?,
        workspace: numerical_workspace.max(graph_workspace).max(tree_workspace),
    })
}

fn copied<T: Copy>(values: &[T]) -> Result<Vec<T>> {
    let mut copy = reserved(values.len())?;
    copy.extend_from_slice(values);
    Ok(copy)
}

fn copied_tree(tree: &Option<SampleTree>) -> Result<Option<SampleTree>> {
    tree.as_ref()
        .map(|tree| {
            Ok(SampleTree {
                merge: copied(&tree.merge)?,
                height: copied(&tree.height)?,
                order: copied(&tree.order)?,
            })
        })
        .transpose()
}

fn ward_tree(
    profiles: &CellProfiles<'_>,
    members: &[usize],
    budget: usize,
) -> Result<Option<SampleTree>> {
    if members.len() < 2 {
        return Ok(None);
    }
    let distances = bytes::<f64>(condensed::pair_count(members.len())?)?;
    let workspace = ward::required_workspace(members.len())?;
    check_budget(sum(&[distances, workspace])?, budget)?;
    let distances = profiles.distances_with_threads(members, distances, 1)?;
    let tree = ward::ward_d2(&distances, members.len(), workspace)?;
    Ok(Some(SampleTree {
        merge: tree.merge,
        height: tree.height,
        order: tree.order,
    }))
}

fn bypass(profiles: &CellProfiles<'_>, group: Group<'_>, budget: usize) -> Result<GroupOutput> {
    let small = group.indices.len() < 3;
    let name = if small {
        format!("{}_s1", group.name)
    } else {
        group.name.into()
    };
    let tree = if small {
        None
    } else {
        ward_tree(profiles, group.indices, budget)?
    };
    let parent = Parent {
        name: group.name.into(),
        member_indices: copied(group.indices)?,
        route: if small {
            Route::TooFewCells
        } else {
            Route::NeighborBypass
        },
        resolution: None,
        partition: None,
        subclusters: vec![Subcluster {
            name: name.clone(),
            member_indices: copied(group.indices)?,
        }],
        tree: copied_tree(&tree)?,
        pca: None,
        graph: None,
    };
    Ok(GroupOutput {
        parent,
        groups: vec![SampleGroup {
            name: group.name.into(),
            subcluster_name: name,
            member_indices: copied(group.indices)?,
            tree,
        }],
    })
}

fn buckets(partition: &[usize], cells: usize) -> Result<Vec<Vec<usize>>> {
    if partition.len() != cells || partition.iter().any(|&label| label == 0 || label > cells) {
        return Err(invalid("Discovery partition has invalid vertex identities"));
    }
    let count = partition.iter().copied().max().unwrap_or(0);
    let mut sizes = reserved(count)?;
    sizes.resize(count, 0_usize);
    for &label in partition {
        sizes[label - 1] += 1;
    }
    let mut result = reserved(count)?;
    for size in sizes {
        result.push(reserved(size)?);
    }
    for (cell, &label) in partition.iter().enumerate() {
        result[label - 1].push(cell);
    }
    Ok(result)
}

fn discover_group(
    original: &CellProfiles<'_>,
    filtered: &CellProfiles<'_>,
    selected: &[usize],
    group: Group<'_>,
    config: &DiscoveryConfig,
    seed: u32,
    budget: usize,
) -> Result<GroupOutput> {
    if group.indices.len() < 3 || config.k_nn >= group.indices.len() {
        return bypass(filtered, group, budget);
    }
    let pca = match config.method {
        DiscoveryMethod::Pca => Some(pca::pca(original, selected, group.indices, budget)?),
        DiscoveryMethod::Simple => None,
    };
    let graph = match &pca {
        Some(pca) => graph::pca_graph(
            &pca.scores,
            group.indices.len(),
            pca.components,
            config.k_nn,
        )?,
        None => graph::simple_graph(original, selected, group.indices, config.k_nn)?,
    };
    let resolution = (11.98 / group.indices.len() as f64).powf(1.0 / 1.165);
    let partition = leiden::partition(&graph, resolution, seed)?;
    let members = buckets(&partition, group.indices.len())?;
    let mut labels = reserved(members.len())?;
    labels.extend((0..members.len()).filter(|&label| !members[label].is_empty()));
    labels.sort_unstable_by(|&left, &right| {
        members[right]
            .len()
            .cmp(&members[left].len())
            .then(left.cmp(&right))
    });
    let mut forest = Forest::new(group.indices.len())?;
    let mut subclusters = reserved(labels.len())?;
    let mut output = reserved(labels.len())?;
    for label in labels {
        let local = &members[label];
        let mut indices = reserved(local.len())?;
        indices.extend(local.iter().map(|&cell| group.indices[cell]));
        let tree = ward_tree(filtered, &indices, budget)?;
        forest.push(local, tree.as_ref())?;
        let name = format!("{}_s{}", group.name, label + 1);
        subclusters.push(Subcluster {
            name: name.clone(),
            member_indices: copied(&indices)?,
        });
        output.push(SampleGroup {
            name: group.name.into(),
            subcluster_name: name,
            member_indices: indices,
            tree,
        });
    }
    Ok(GroupOutput {
        parent: Parent {
            name: group.name.into(),
            member_indices: copied(group.indices)?,
            route: match config.method {
                DiscoveryMethod::Pca => Route::Pca,
                DiscoveryMethod::Simple => Route::Simple,
            },
            resolution: Some(resolution),
            partition: Some(partition),
            subclusters,
            tree: forest.finish()?,
            pca,
            graph: Some(graph),
        },
        groups: output,
    })
}

/// Discovers grouped cell subclusters without changing the expression or input maps.
/// Reports distinguish parent-local graph/tree positions from global member indices.
pub fn discover_samples(
    state: &CnvState,
    input: &CreatedInput,
    samples: &SamplesConfig,
    config: &DiscoveryConfig,
) -> Result<DiscoverySamples> {
    if !samples.cluster_by_groups {
        return Err(invalid("Discovery currently requires grouped observations"));
    }
    if config.k_nn == 0 {
        return Err(invalid("Discovery neighbor count must be positive"));
    }
    let Prepared {
        selection,
        filtered,
        selection_bytes,
        filtered_bytes,
    } = prepare(state, input, samples)?;
    let original = CellProfiles::validated(state.values(), state.gene_count(), state.cell_count());
    let profiles = match &filtered {
        Some(values) => {
            CellProfiles::validated(values, selection.selected.len(), state.cell_count())
        }
        None => CellProfiles::validated(state.values(), state.gene_count(), state.cell_count()),
    };
    let mut inputs = reserved(input.observation_groups().len() + input.reference_groups().len())?;
    inputs.extend(groups(input));
    let workers = samples.threads.min(inputs.len());
    let chunk_len = inputs.len().div_ceil(workers);
    let mut plans = reserved(inputs.len())?;
    for group in &inputs {
        plans.push(plan(selection.selected.len(), group.indices.len(), config)?);
    }
    let mut active = reserved(plans.len())?;
    active.extend(plans.iter().map(|plan| plan.workspace));
    active.sort_unstable_by(|left, right| right.cmp(left));
    let retained = plans
        .iter()
        .try_fold(0_usize, |total, plan| sum(&[total, plan.retained]))?;
    let working = active
        .iter()
        .take(workers)
        .try_fold(0_usize, |total, &value| sum(&[total, value]))?;
    check_budget(
        sum(&[selection_bytes, filtered_bytes, retained, working])?,
        samples.max_workspace_bytes,
    )?;
    let mut completed = reserved(inputs.len())?;
    completed.resize_with(inputs.len(), || None);
    parallel::for_chunks(&mut completed, chunk_len, |chunk, output| {
        for (offset, slot) in output.iter_mut().enumerate() {
            let index = chunk * chunk_len + offset;
            let seed = config
                .seed
                .wrapping_add((index as u32).wrapping_mul(0x9e37_79b9));
            *slot = Some(discover_group(
                &original,
                &profiles,
                &selection.selected,
                inputs[index],
                config,
                seed,
                plans[index].workspace,
            )?);
        }
        Ok(())
    })?;
    let mut parents = reserved(inputs.len())?;
    let mut output = reserved(state.cell_count())?;
    for group in completed {
        let mut group =
            group.ok_or_else(|| invalid("Discovery worker did not return its parent"))?;
        parents.push(group.parent);
        output.append(&mut group.groups);
    }
    Ok(DiscoverySamples {
        samples: Samples {
            groups: output,
            outlier_gene_indices: selection.outliers,
            selected_gene_indices: selection.selected,
        },
        discovery: Discovery {
            config: *config,
            parents,
        },
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cnv::{CreationConfig, InputPaths, create_input};
    use std::fs;
    use std::path::PathBuf;
    use std::sync::atomic::{AtomicU64, Ordering};

    struct Fixture {
        directory: PathBuf,
        input: CreatedInput,
    }

    impl Drop for Fixture {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.directory);
        }
    }

    fn fixture(groups: &[(&str, &[f64])]) -> Fixture {
        static NEXT: AtomicU64 = AtomicU64::new(0);
        let directory = std::env::temp_dir().join(format!(
            "rsomics-discovery-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir(&directory).unwrap();
        let columns: Vec<_> = groups
            .iter()
            .flat_map(|&(name, values)| values.iter().map(move |&value| (name, value)))
            .collect();
        let mut counts = String::from("gene");
        for cell in 0..columns.len() {
            counts.push_str(&format!("\tc{cell}"));
        }
        counts.push('\n');
        for gene in 0..3 {
            counts.push_str(&format!("g{gene}"));
            for &(_, value) in &columns {
                let value = match gene {
                    0 => 1.0 + value,
                    1 => 2.0 + value * 0.01,
                    _ => 3.0,
                };
                counts.push_str(&format!("\t{value}"));
            }
            counts.push('\n');
        }
        let annotations = columns
            .iter()
            .enumerate()
            .map(|(cell, (name, _))| format!("c{cell}\t{name}\n"))
            .collect::<String>();
        fs::write(directory.join("counts.tsv"), counts).unwrap();
        fs::write(
            directory.join("positions.tsv"),
            "g0\tchr1\t1\t1\ng1\tchr1\t2\t2\ng2\tchr1\t3\t3\n",
        )
        .unwrap();
        fs::write(directory.join("annotations.tsv"), annotations).unwrap();
        let input = create_input(
            InputPaths {
                counts: &directory.join("counts.tsv"),
                positions: &directory.join("positions.tsv"),
                annotations: &directory.join("annotations.tsv"),
            },
            &CreationConfig {
                reference_groups: Vec::new(),
                excluded_chromosomes: Vec::new(),
                min_counts_per_cell: 1.0,
                max_counts_per_cell: f64::INFINITY,
                max_numeric_bytes: 1 << 20,
                max_record_bytes: 1 << 16,
            },
        )
        .unwrap();
        Fixture { directory, input }
    }

    fn options(threads: usize) -> SamplesConfig {
        SamplesConfig {
            cluster_by_groups: true,
            z_score_filter: 0.0,
            threads,
            max_workspace_bytes: 1 << 20,
        }
    }

    #[test]
    fn bypasses_preserve_source_names_member_order_and_absent_graphs() {
        let fixture = fixture(&[("tiny", &[4.0, 1.0]), ("bypass", &[9.0, 2.0, 8.0, 1.0])]);
        let state = fixture.input.prepared_counts().state();
        let before = state.values().to_vec();
        let output = discover_samples(
            state,
            &fixture.input,
            &options(1),
            &DiscoveryConfig {
                method: DiscoveryMethod::Pca,
                k_nn: 4,
                seed: 7,
            },
        )
        .unwrap();
        assert_eq!(state.values(), before);
        let tiny = output
            .discovery
            .parents
            .iter()
            .find(|parent| parent.name == "tiny")
            .unwrap();
        let bypass = output
            .discovery
            .parents
            .iter()
            .find(|parent| parent.name == "bypass")
            .unwrap();
        assert_eq!(tiny.subclusters[0].name, "tiny_s1");
        assert!(tiny.tree.is_none());
        assert_eq!(bypass.subclusters[0].name, "bypass");
        assert_eq!(bypass.subclusters[0].member_indices, [2, 3, 4, 5]);
        assert!(bypass.tree.is_some());
        assert!(
            output
                .discovery
                .parents
                .iter()
                .all(|parent| parent.graph.is_none() && parent.partition.is_none())
        );
        let old = super::super::samples(state, &fixture.input, &options(1)).unwrap();
        assert_eq!(
            old.groups
                .iter()
                .find(|group| group.name == "bypass")
                .unwrap()
                .subcluster_name,
            "bypass_s1"
        );
    }

    #[test]
    fn simple_workflow_keeps_two_cell_ward_subtrees_and_worker_identity() {
        let values = [
            0.0, 10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0, 0.05, 10.05, 20.05, 30.05, 40.05, 50.05,
            60.05, 70.05,
        ];
        let fixture = fixture(&[("alpha", &values), ("beta", &values), ("tiny", &[4.0, 1.0])]);
        let state = fixture.input.prepared_counts().state();
        let configuration = DiscoveryConfig {
            method: DiscoveryMethod::Simple,
            k_nn: 2,
            seed: 11,
        };
        let serial = discover_samples(state, &fixture.input, &options(1), &configuration).unwrap();
        let parallel =
            discover_samples(state, &fixture.input, &options(4), &configuration).unwrap();
        assert_eq!(
            serde_json::to_value(serial.discovery.report()).unwrap(),
            serde_json::to_value(parallel.discovery.report()).unwrap()
        );
        assert_eq!(serial.samples.selected_gene_indices, [0, 1, 2]);
        assert_eq!(serial.samples.groups.len(), 17);
        for (name, offset) in [("alpha", 0), ("beta", 16)] {
            let groups: Vec<_> = serial
                .samples
                .groups
                .iter()
                .filter(|group| group.name == name)
                .collect();
            assert_eq!(groups.len(), 8);
            for (pair, group) in groups.iter().enumerate() {
                assert_eq!(group.member_indices, [offset + pair, offset + pair + 8]);
                let tree = group.tree.as_ref().unwrap();
                assert_eq!(tree.merge, [[-1, -2]]);
                assert_eq!(tree.order, [0, 1]);
                assert!(tree.height[0] > 0.0);
            }
        }
    }
}
