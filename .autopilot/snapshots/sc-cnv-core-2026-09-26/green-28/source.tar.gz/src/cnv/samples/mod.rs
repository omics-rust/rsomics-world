mod condensed;
mod discovery;
mod distance;
mod filter;
mod ward;

use super::{CellGroup, CnvState, CreatedInput, parallel};
use distance::CellProfiles;
use rsomics_common::{Result, RsomicsError};
use std::mem::size_of;

pub use discovery::{
    Discovery, DiscoveryConfig, DiscoveryMethod, DiscoveryReport, DiscoverySamples,
    discover_samples,
};

#[derive(Clone, Copy, Debug)]
pub struct SamplesConfig {
    pub cluster_by_groups: bool,
    pub z_score_filter: f64,
    pub threads: usize,
    /// Bounds additional requested numeric/index buffers, not metadata or RSS.
    pub max_workspace_bytes: usize,
}

#[derive(Debug)]
pub struct Samples {
    pub groups: Vec<SampleGroup>,
    pub outlier_gene_indices: Option<Vec<usize>>,
    pub selected_gene_indices: Vec<usize>,
}

#[derive(Debug)]
pub struct SampleGroup {
    pub name: String,
    pub tree: Option<SampleTree>,
    pub subcluster_name: String,
    pub member_indices: Vec<usize>,
}

#[derive(Debug)]
pub struct SampleTree {
    /// Negative one-based leaves and positive one-based merge rows, as in R.
    pub merge: Vec<[i32; 2]>,
    pub height: Vec<f64>,
    /// Zero-based positions in the supplied group, in leaf traversal order.
    pub order: Vec<usize>,
}

#[derive(Clone, Copy)]
struct Group<'a> {
    name: &'a str,
    indices: &'a [usize],
}

impl<'a> From<&'a CellGroup> for Group<'a> {
    fn from(group: &'a CellGroup) -> Self {
        Self {
            name: group.name(),
            indices: group.cell_indices(),
        }
    }
}

fn invalid(message: &str) -> RsomicsError {
    RsomicsError::InvalidInput(message.into())
}

fn sum(bytes: &[usize]) -> Result<usize> {
    bytes.iter().try_fold(0usize, |total, &value| {
        total
            .checked_add(value)
            .ok_or_else(|| invalid("Samples workspace size overflows"))
    })
}

fn bytes<T>(count: usize) -> Result<usize> {
    count
        .checked_mul(size_of::<T>())
        .ok_or_else(|| invalid("Samples workspace size overflows"))
}

fn check_budget(requested: usize, budget: usize) -> Result<()> {
    if requested > budget {
        return Err(invalid(
            "Samples exceeds the numeric/index workspace budget",
        ));
    }
    Ok(())
}

fn reserved<T>(count: usize) -> Result<Vec<T>> {
    let mut output = Vec::new();
    output
        .try_reserve_exact(count)
        .map_err(|_| invalid("Samples workspace allocation failed"))?;
    Ok(output)
}

fn groups(input: &CreatedInput) -> impl Iterator<Item = Group<'_>> + Clone {
    input
        .observation_groups()
        .iter()
        .chain(input.reference_groups())
        .map(Group::from)
}

fn validate(state: &CnvState, input: &CreatedInput, budget: usize) -> Result<()> {
    if state.cells() != input.prepared_counts().state().cells() {
        return Err(invalid(
            "Samples state cell identities differ from created input",
        ));
    }
    check_budget(bytes::<u8>(state.cell_count())?, budget)?;
    let mut seen = reserved::<u8>(state.cell_count())?;
    seen.resize(state.cell_count(), 0);
    for (position, group) in groups(input).enumerate() {
        if group.name.is_empty()
            || group.indices.is_empty()
            || groups(input)
                .take(position)
                .any(|prior| prior.name == group.name)
        {
            return Err(invalid(
                "Samples groups require unique nonempty names and members",
            ));
        }
        for &index in group.indices {
            if index >= state.cell_count() || seen[index] != 0 {
                return Err(invalid(
                    "Samples group indices must be disjoint and in range",
                ));
            }
            if state.cells()[index].group != group.name {
                return Err(invalid(
                    "Samples group membership disagrees with cell identity",
                ));
            }
            seen[index] = 1;
        }
    }
    if seen.contains(&0) {
        return Err(invalid("Samples groups must cover every state cell"));
    }
    Ok(())
}

fn member_count(groups: &[CellGroup]) -> Result<usize> {
    groups.iter().try_fold(0usize, |count, group| {
        count
            .checked_add(group.cell_indices().len())
            .ok_or_else(|| invalid("Samples group size overflows"))
    })
}

fn flatten(groups: &[CellGroup], count: usize) -> Result<Vec<usize>> {
    let mut indices = reserved(count)?;
    for group in groups {
        indices.extend_from_slice(group.cell_indices());
    }
    Ok(indices)
}

fn tree_bytes(leaves: usize) -> Result<usize> {
    sum(&[
        bytes::<[i32; 2]>(leaves - 1)?,
        bytes::<f64>(leaves - 1)?,
        bytes::<usize>(leaves)?,
    ])
}

fn cluster_group(
    profiles: &CellProfiles<'_>,
    group: Group<'_>,
    occupied: usize,
    budget: usize,
    threads: usize,
) -> Result<(SampleGroup, usize)> {
    let leaves = group.indices.len();
    let members_bytes = bytes::<usize>(leaves)?;
    let tree = if leaves > 2 {
        let distance_bytes = bytes::<f64>(condensed::pair_count(leaves)?)?;
        let workspace = ward::required_workspace(leaves)?;
        check_budget(sum(&[occupied, distance_bytes, workspace])?, budget)?;
        let distances = profiles.distances_with_threads(group.indices, distance_bytes, threads)?;
        let tree = ward::ward_d2(&distances, leaves, workspace)?;
        drop(distances);
        Some(SampleTree {
            merge: tree.merge,
            height: tree.height,
            order: tree.order,
        })
    } else {
        None
    };
    let retained = sum(&[
        members_bytes,
        if tree.is_some() {
            tree_bytes(leaves)?
        } else {
            0
        },
    ])?;
    check_budget(sum(&[occupied, retained])?, budget)?;
    let mut members = reserved(leaves)?;
    if let Some(tree) = &tree {
        members.extend(tree.order.iter().map(|&index| group.indices[index]));
    } else {
        members.extend_from_slice(group.indices);
    }
    Ok((
        SampleGroup {
            name: group.name.into(),
            tree,
            subcluster_name: format!("{}_s1", group.name),
            member_indices: members,
        },
        retained,
    ))
}

struct Prepared {
    selection: filter::GeneSelection,
    filtered: Option<Vec<f64>>,
    selection_bytes: usize,
    filtered_bytes: usize,
}

fn prepare(state: &CnvState, input: &CreatedInput, config: &SamplesConfig) -> Result<Prepared> {
    if config.threads == 0 {
        return Err(invalid("Samples worker count must be positive"));
    }
    if !config.z_score_filter.is_finite() {
        return Err(invalid("Samples gene filter argument must be finite"));
    }
    if !config.cluster_by_groups
        && input
            .reference_groups()
            .iter()
            .any(|group| group.name() == "all_observations")
    {
        return Err(invalid(
            "Samples pooled mode rejects a reference named all_observations (known upstream incompatibility)",
        ));
    }
    let budget = config.max_workspace_bytes;
    validate(state, input, budget)?;
    let profiles = CellProfiles::validated(state.values(), state.gene_count(), state.cell_count());
    let reference_count = member_count(input.reference_groups())?;
    let reference_bytes = bytes::<usize>(reference_count)?;
    let active = config.z_score_filter > 0.0 && reference_count > 0;
    let selection_workspace =
        filter::required_workspace(state.gene_count(), reference_count, active)?;
    check_budget(sum(&[reference_bytes, selection_workspace])?, budget)?;
    let references = flatten(input.reference_groups(), reference_count)?;
    let selection = filter::select_genes(
        &profiles,
        &references,
        config.z_score_filter,
        selection_workspace,
    )?;
    drop(references);
    let selection_bytes = bytes::<usize>(state.gene_count())?
        .checked_mul(if active { 2 } else { 1 })
        .ok_or_else(|| invalid("Samples workspace size overflows"))?;
    let filtered_bytes = if selection.selected.len() == state.gene_count() {
        0
    } else {
        bytes::<f64>(
            selection
                .selected
                .len()
                .checked_mul(state.cell_count())
                .ok_or_else(|| invalid("Samples filtered matrix size overflows"))?,
        )?
    };
    check_budget(sum(&[selection_bytes, filtered_bytes])?, budget)?;
    let filtered = if selection.selected.len() == state.gene_count() {
        None
    } else {
        let mut values = reserved::<f64>(filtered_bytes / size_of::<f64>())?;
        for cell in 0..state.cell_count() {
            values.extend(
                selection
                    .selected
                    .iter()
                    .map(|&gene| profiles.column(cell)[gene]),
            );
        }
        Some(values)
    };
    Ok(Prepared {
        selection,
        filtered,
        selection_bytes,
        filtered_bytes,
    })
}

/// Clusters the borrowed CNV state without changing expression values or group maps.
/// Global members and tree traversal positions are zero-based; merges use R indexing.
pub fn samples(state: &CnvState, input: &CreatedInput, config: &SamplesConfig) -> Result<Samples> {
    let Prepared {
        selection,
        filtered,
        selection_bytes,
        filtered_bytes,
    } = prepare(state, input, config)?;
    let budget = config.max_workspace_bytes;
    let profiles = match &filtered {
        Some(values) => {
            CellProfiles::validated(values, selection.selected.len(), state.cell_count())
        }
        None => CellProfiles::validated(state.values(), state.gene_count(), state.cell_count()),
    };
    let observation_count = if config.cluster_by_groups {
        0
    } else {
        member_count(input.observation_groups())?
    };
    let pooled_bytes = bytes::<usize>(observation_count)?;
    let mut occupied = sum(&[selection_bytes, filtered_bytes, pooled_bytes])?;
    check_budget(occupied, budget)?;
    let pooled = if observation_count > 0 {
        flatten(input.observation_groups(), observation_count)?
    } else {
        Vec::new()
    };
    let group_count = if config.cluster_by_groups {
        input.observation_groups().len()
    } else {
        usize::from(!pooled.is_empty())
    }
    .checked_add(input.reference_groups().len())
    .ok_or_else(|| invalid("Samples group count overflows"))?;
    let mut output = reserved(group_count)?;
    let observation_groups = input.observation_groups().iter().map(Group::from);
    let pooled_group = (!pooled.is_empty()).then_some(Group {
        name: "all_observations",
        indices: &pooled,
    });
    let observations =
        pooled_group
            .into_iter()
            .chain(observation_groups.take(if config.cluster_by_groups {
                input.observation_groups().len()
            } else {
                0
            }));
    for group in observations.chain(input.reference_groups().iter().map(Group::from)) {
        let (result, retained) = cluster_group(&profiles, group, occupied, budget, config.threads)?;
        occupied = sum(&[occupied, retained])?;
        output.push(result);
    }
    Ok(Samples {
        groups: output,
        outlier_gene_indices: selection.outliers,
        selected_gene_indices: selection.selected,
    })
}
