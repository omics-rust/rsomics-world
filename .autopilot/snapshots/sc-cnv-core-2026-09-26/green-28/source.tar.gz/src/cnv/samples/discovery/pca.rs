use super::super::distance::CellProfiles;
use super::super::{invalid, reserved};
use faer::linalg::solvers::SelfAdjointEigen;
use faer::{Mat, Side};
use loess_rs::prelude::Loess;
use rsomics_common::Result;
use std::mem::size_of;

const VARIABLE_FEATURES: usize = 2_000;
const COMPONENTS: usize = 10;

#[derive(Debug)]
pub(super) struct PcaResult {
    pub(super) feature_indices: Vec<usize>,
    pub(super) feature_scores: Vec<f64>,
    pub(super) scores: Vec<f64>,
    pub(super) loadings: Vec<f64>,
    pub(super) standard_deviations: Vec<f64>,
    pub(super) components: usize,
}

struct FeatureStatistics {
    mean: f64,
    variance: f64,
    scale_sd: f64,
}

struct Factors {
    scores: Vec<f64>,
    loadings: Vec<f64>,
    standard_deviations: Vec<f64>,
}

pub(super) fn workspace_bytes(genes: usize, cells: usize) -> Result<usize> {
    let selected = genes.min(VARIABLE_FEATURES);
    let components = cells.min(COMPONENTS);
    let values = genes
        .checked_mul(32)
        .and_then(|value| cells.checked_mul(cells)?.checked_mul(5)?.checked_add(value))
        .and_then(|value| {
            selected
                .checked_mul(cells)?
                .checked_mul(2)?
                .checked_add(value)
        })
        .and_then(|value| selected.checked_mul(components)?.checked_add(value))
        .and_then(|value| cells.checked_mul(components)?.checked_add(value))
        .and_then(|value| value.checked_mul(size_of::<f64>()));
    values.ok_or_else(|| invalid("PCA workspace size overflows"))
}

fn statistics(
    profiles: &CellProfiles<'_>,
    selected_genes: &[usize],
    members: &[usize],
) -> Result<Vec<FeatureStatistics>> {
    let count = members.len() as f64;
    let mut output = reserved(selected_genes.len())?;
    for &gene in selected_genes {
        let mut total = 0.0;
        let mut squares = 0.0;
        let mut nonzero = 0;
        for &cell in members {
            let value = profiles.column(cell)[gene];
            total += value;
            squares += value * value;
            nonzero += usize::from(value != 0.0);
        }
        let mean = total / count;
        let mut variance = 0.0;
        for &cell in members {
            let value = profiles.column(cell)[gene];
            if value != 0.0 {
                variance += (value - mean).powi(2);
            }
        }
        variance = (variance + (members.len() - nonzero) as f64 * mean.powi(2)) / (count - 1.0);
        let scale_sd = ((squares - total * total / count) / (count - 1.0)).sqrt();
        if !mean.is_finite() || !variance.is_finite() || !squares.is_finite() {
            return Err(invalid("PCA feature moments are not finite"));
        }
        output.push(FeatureStatistics {
            mean,
            variance,
            scale_sd: if scale_sd.is_finite() && scale_sd > 0.0 {
                scale_sd
            } else {
                0.0
            },
        });
    }
    Ok(output)
}

fn expected_standard_deviations(statistics: &[FeatureStatistics]) -> Result<Vec<f64>> {
    let mut positions = reserved(statistics.len())?;
    let mut x = reserved(statistics.len())?;
    let mut y = reserved(statistics.len())?;
    for (position, feature) in statistics.iter().enumerate() {
        if feature.variance > 0.0 {
            if feature.mean <= 0.0 {
                return Err(invalid("VST requires positive means for varying features"));
            }
            positions.push(position);
            x.push(feature.mean.log10());
            y.push(feature.variance.log10());
        }
    }
    let fitted = Loess::<f64>::new()
        .fraction(0.3)
        .iterations(0)
        .weight_function("tricube")
        .degree("quadratic")
        .distance_metric("euclidean")
        .surface_mode("interpolation")
        .cell(0.2)
        .zero_weight_fallback("return_none")
        .boundary_policy("noboundary")
        .boundary_degree_fallback(false)
        .build()
        .and_then(|model| model.fit(&x, &y))
        .map_err(|error| invalid(&format!("VST LOESS fit failed: {error}")))?;
    let mut deviations = reserved(statistics.len())?;
    deviations.resize(statistics.len(), 0.0);
    for (position, value) in positions.into_iter().zip(fitted.y) {
        let sd = 10.0_f64.powf(value).sqrt();
        if !sd.is_finite() || sd <= 0.0 {
            return Err(invalid(
                "VST fitted standard deviation is not positive and finite",
            ));
        }
        deviations[position] = sd;
    }
    Ok(deviations)
}

fn vst_score(values: impl Iterator<Item = f64>, count: usize, mean: f64, sd: f64) -> f64 {
    if sd == 0.0 {
        return 0.0;
    }
    let clip = (count as f64).sqrt();
    let mut squares = 0.0;
    let mut nonzero = 0;
    for value in values {
        if value != 0.0 {
            squares += ((value - mean) / sd).min(clip).powi(2);
            nonzero += 1;
        }
    }
    (squares + ((-mean) / sd).powi(2) * (count - nonzero) as f64) / (count - 1) as f64
}

fn rank_features(scores: &[f64], count: usize) -> Result<Vec<usize>> {
    let mut order = reserved(scores.len())?;
    order.extend(0..scores.len());
    order.sort_unstable_by(|&left, &right| {
        scores[right]
            .total_cmp(&scores[left])
            .then_with(|| left.cmp(&right))
    });
    order.truncate(count);
    Ok(order)
}

fn scale_value(value: f64, mean: f64, sd: f64) -> f64 {
    ((value - mean) * (1.0 / sd)).min(10.0)
}

fn matrix(rows: usize, columns: usize, value: impl FnMut(usize, usize) -> f64) -> Result<Mat<f64>> {
    let mut output = Mat::new();
    output
        .try_reserve(rows, columns)
        .map_err(|_| invalid("PCA matrix allocation failed"))?;
    output.resize_with(rows, columns, value);
    Ok(output)
}

fn decompose(scaled: &Mat<f64>, components: usize) -> Result<Factors> {
    let cells = scaled.ncols();
    let genes = scaled.nrows();
    let gram = matrix(cells, cells, |left, right| {
        if left < right {
            0.0
        } else {
            (0..genes)
                .map(|gene| scaled[(gene, left)] * scaled[(gene, right)])
                .sum()
        }
    })?;
    let eigen = SelfAdjointEigen::new(gram.as_ref(), Side::Lower)
        .map_err(|error| invalid(&format!("PCA eigendecomposition failed: {error:?}")))?;
    let eigenvalues = eigen.S().column_vector();
    let eigenvectors = eigen.U();
    let mut order = reserved(cells)?;
    order.extend(0..cells);
    order.sort_unstable_by(|&left, &right| {
        eigenvalues[right]
            .total_cmp(&eigenvalues[left])
            .then_with(|| left.cmp(&right))
    });
    let mut scores = reserved(cells * components)?;
    scores.resize(cells * components, 0.0);
    let mut loadings = reserved(genes * components)?;
    loadings.resize(genes * components, 0.0);
    let mut standard_deviations = reserved(components)?;
    for (pc, &index) in order.iter().take(components).enumerate() {
        let eigenvalue = eigenvalues[index];
        if !eigenvalue.is_finite() {
            return Err(invalid("PCA eigenvalue is not finite"));
        }
        let singular = eigenvalue.max(0.0).sqrt();
        standard_deviations.push(singular / ((cells - 1) as f64).sqrt());
        if singular == 0.0 {
            continue;
        }
        for cell in 0..cells {
            scores[cell * components + pc] = eigenvectors[(cell, index)] * singular;
        }
        for gene in 0..genes {
            loadings[gene * components + pc] = (0..cells)
                .map(|cell| scaled[(gene, cell)] * eigenvectors[(cell, index)])
                .sum::<f64>()
                / singular;
        }
    }
    if scores
        .iter()
        .chain(&loadings)
        .any(|value| !value.is_finite())
    {
        return Err(invalid("PCA factors are not finite"));
    }
    Ok(Factors {
        scores,
        loadings,
        standard_deviations,
    })
}

pub(super) fn pca(
    profiles: &CellProfiles<'_>,
    selected_genes: &[usize],
    members: &[usize],
    max_workspace_bytes: usize,
) -> Result<PcaResult> {
    if members.len() <= COMPONENTS {
        return Err(invalid(
            "PCA requires more than ten cells for ten components",
        ));
    }
    if workspace_bytes(selected_genes.len(), members.len())? > max_workspace_bytes {
        return Err(invalid("PCA exceeds the numeric/index workspace budget"));
    }
    let statistics = statistics(profiles, selected_genes, members)?;
    let expected = expected_standard_deviations(&statistics)?;
    let mut variances = reserved(selected_genes.len())?;
    for (local, &gene) in selected_genes.iter().enumerate() {
        let score = vst_score(
            members.iter().map(|&cell| profiles.column(cell)[gene]),
            members.len(),
            statistics[local].mean,
            expected[local],
        );
        if !score.is_finite() {
            return Err(invalid("VST standardized variance is not finite"));
        }
        variances.push(score);
    }
    let mut order = rank_features(&variances, selected_genes.len().min(VARIABLE_FEATURES))?;
    order.retain(|&gene| statistics[gene].scale_sd > 0.0);
    if order.len() <= COMPONENTS {
        return Err(invalid(
            "PCA requires more than ten varying features for ten components",
        ));
    }
    let scaled = matrix(order.len(), members.len(), |row, column| {
        let local = order[row];
        scale_value(
            profiles.column(members[column])[selected_genes[local]],
            statistics[local].mean,
            statistics[local].scale_sd,
        )
    })?;
    let factors = decompose(&scaled, COMPONENTS)?;
    let mut feature_indices = reserved(order.len())?;
    let mut feature_scores = reserved(order.len())?;
    for local in order {
        feature_indices.push(selected_genes[local]);
        feature_scores.push(variances[local]);
    }
    Ok(PcaResult {
        feature_indices,
        feature_scores,
        scores: factors.scores,
        loadings: factors.loadings,
        standard_deviations: factors.standard_deviations,
        components: COMPONENTS,
    })
}

#[cfg(test)]
mod tests {
    use super::{decompose, rank_features, scale_value, vst_score};
    use faer::mat;

    #[test]
    fn standardized_scores_keep_negative_extremes_and_do_not_recenter_after_clipping() {
        let score = vst_score([1.0, 2.0, 27.0].into_iter(), 3, 10.0, 1.0);
        assert!((score - 74.0).abs() < 1e-12);
        assert_eq!(scale_value(-99.0, 0.0, 1.0), -99.0);
        assert_eq!(scale_value(99.0, 0.0, 1.0), 10.0);
    }

    #[test]
    fn cell_gram_pca_retains_variance_weighted_geometry_and_feature_loadings() {
        let scaled = mat![[-1.0, 0.0, 1.0], [1.0, -2.0, 1.0]];
        let result = decompose(&scaled, 2).unwrap();
        assert!((result.standard_deviations[0] - 3.0_f64.sqrt()).abs() < 1e-12);
        assert!((result.standard_deviations[1] - 1.0).abs() < 1e-12);
        for (left, right, squared_distance) in [(0, 1, 10.0), (0, 2, 4.0), (1, 2, 10.0)] {
            let actual: f64 = (0..2)
                .map(|pc| (result.scores[left * 2 + pc] - result.scores[right * 2 + pc]).powi(2))
                .sum();
            assert!((actual - squared_distance).abs() < 1e-11);
        }
        for cell in 0..3 {
            for feature in 0..2 {
                let reconstructed: f64 = (0..2)
                    .map(|pc| result.scores[cell * 2 + pc] * result.loadings[feature * 2 + pc])
                    .sum();
                assert!((reconstructed - scaled[(feature, cell)]).abs() < 1e-12);
            }
        }
    }

    #[test]
    fn equal_variable_feature_scores_keep_input_gene_order() {
        assert_eq!(rank_features(&[0.0, 3.0, 3.0, 1.0], 3).unwrap(), [1, 2, 3]);
    }
}
