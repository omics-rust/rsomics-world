use super::super::{distance::CellProfiles, invalid, reserved};
use rsomics_common::Result;

#[derive(Debug)]
pub(super) struct Graph {
    pub vertices: usize,
    pub edges: Vec<(usize, usize, f64)>,
    pub neighbors: Vec<Vec<usize>>,
}

fn neighbor_count(cells: usize, k: usize) -> Result<usize> {
    if cells == 0 || k == 0 || k > cells {
        return Err(invalid(
            "Neighbor count must be positive and no greater than the cell count",
        ));
    }
    cells
        .checked_mul(k)
        .ok_or_else(|| invalid("Neighbor output size overflows"))
}

pub(super) fn pca_graph(scores: &[f64], cells: usize, dims: usize, k: usize) -> Result<Graph> {
    shared_graph(bridge::neighbors(scores, cells, dims, k)?, k)
}

#[allow(unsafe_code)]
mod bridge {
    use super::{invalid, neighbor_count, reserved};
    use rsomics_common::Result;
    use std::ffi::{CStr, c_char};

    unsafe extern "C" {
        fn rsomics_annoy_knn(
            scores: *const f64,
            cells: i32,
            dims: i32,
            k: i32,
            neighbors: *mut i32,
            error: *mut c_char,
            error_capacity: usize,
        ) -> i32;
    }

    pub(super) fn neighbors(
        scores: &[f64],
        cells: usize,
        dims: usize,
        k: usize,
    ) -> Result<Vec<Vec<usize>>> {
        let count = neighbor_count(cells, k)?;
        if dims == 0 || cells.checked_mul(dims) != Some(scores.len()) {
            return Err(invalid("PCA score dimensions do not match graph input"));
        }
        let cells_i32 = i32::try_from(cells).map_err(|_| invalid("Too many cells for Annoy"))?;
        let dims_i32 =
            i32::try_from(dims).map_err(|_| invalid("Too many PCA components for Annoy"))?;
        let k_i32 = i32::try_from(k).map_err(|_| invalid("Too many neighbors for Annoy"))?;
        let mut output = reserved(count)?;
        output.resize(count, 0_i32);
        let mut error: [c_char; 512] = [0; 512];
        // Both buffers cover the checked dimensions; C++ catches exceptions and never retains them.
        let status = unsafe {
            rsomics_annoy_knn(
                scores.as_ptr(),
                cells_i32,
                dims_i32,
                k_i32,
                output.as_mut_ptr(),
                error.as_mut_ptr(),
                error.len(),
            )
        };
        if status != 0 {
            // The zeroed buffer and bounded C++ error writer always leave a terminating NUL.
            let message = unsafe { CStr::from_ptr(error.as_ptr()) }.to_string_lossy();
            return Err(invalid(&format!(
                "Annoy neighborhood construction failed: {message}"
            )));
        }
        let mut neighbors = reserved(cells)?;
        for row in output.chunks_exact(k) {
            let mut values = reserved(k)?;
            for &index in row {
                if index < 0 || index >= cells_i32 {
                    return Err(invalid("Annoy returned an out-of-range neighbor"));
                }
                values.push(index as usize);
            }
            neighbors.push(values);
        }
        Ok(neighbors)
    }
}

fn shared_graph(neighbors: Vec<Vec<usize>>, k: usize) -> Result<Graph> {
    let cells = neighbors.len();
    let mut offsets = reserved(cells + 1)?;
    offsets.resize(cells + 1, 0_usize);
    for row in &neighbors {
        for &neighbor in row {
            offsets[neighbor + 1] += 1;
        }
    }
    for cell in 0..cells {
        offsets[cell + 1] += offsets[cell];
    }
    let mut postings = reserved(offsets[cells])?;
    postings.resize(offsets[cells], 0_usize);
    let mut cursor = reserved(cells)?;
    cursor.extend_from_slice(&offsets[..cells]);
    for (row, own) in neighbors.iter().enumerate() {
        for &neighbor in own {
            postings[cursor[neighbor]] = row;
            cursor[neighbor] += 1;
        }
    }
    let mut overlap = reserved(cells)?;
    overlap.resize(cells, 0_usize);
    let mut touched = reserved(cells)?;
    let mut edges = Vec::new();
    let k = k as f64;
    for (row, own) in neighbors.iter().enumerate() {
        for &neighbor in own {
            for &other in &postings[offsets[neighbor]..offsets[neighbor + 1]] {
                if other >= row {
                    if overlap[other] == 0 {
                        touched.push(other);
                    }
                    overlap[other] += 1;
                }
            }
        }
        touched.sort_unstable();
        edges
            .try_reserve(touched.len())
            .map_err(|_| invalid("SNN edge allocation failed"))?;
        for &other in &touched {
            let shared = overlap[other] as f64;
            let weight = shared / (k + (k - shared));
            if weight >= 1.0 / 15.0 {
                edges.push((row, other, weight));
            }
            overlap[other] = 0;
        }
        touched.clear();
    }
    Ok(Graph {
        vertices: cells,
        edges,
        neighbors,
    })
}

pub(super) fn simple_graph(
    profiles: &CellProfiles<'_>,
    selected_genes: &[usize],
    members: &[usize],
    k: usize,
) -> Result<Graph> {
    let cells = members.len();
    let count = neighbor_count(cells, k)?;
    let mut neighbors = reserved(cells)?;
    let mut candidates = reserved(cells)?;
    let compare = |left: &(f64, usize), right: &(f64, usize)| {
        left.0.total_cmp(&right.0).then(left.1.cmp(&right.1))
    };
    for &member in members {
        candidates.clear();
        let left = profiles.column(member);
        for (position, &other) in members.iter().enumerate() {
            let right = profiles.column(other);
            let mut squared_distance = 0.0;
            for &gene in selected_genes {
                let difference = left[gene] - right[gene];
                squared_distance += difference * difference;
            }
            if !squared_distance.is_finite() {
                return Err(invalid("Simple-neighbor distance arithmetic is not finite"));
            }
            candidates.push((squared_distance, position));
        }
        candidates.select_nth_unstable_by(k - 1, compare);
        candidates[..k].sort_unstable_by(compare);
        let mut own = reserved(k)?;
        own.extend(candidates[..k].iter().map(|&(_, position)| position));
        neighbors.push(own);
    }
    let mut edges = reserved(count)?;
    for (row, own) in neighbors.iter().enumerate() {
        for &other in own {
            edges.push((row.min(other), row.max(other), 1.0));
        }
    }
    edges.sort_unstable_by_key(|&(left, right, _)| (left, right));
    edges.dedup_by(|left, right| left.0 == right.0 && left.1 == right.1);
    Ok(Graph {
        vertices: cells,
        edges,
        neighbors,
    })
}

#[cfg(test)]
mod tests {
    use super::{pca_graph, shared_graph, simple_graph};
    use crate::cnv::samples::distance::CellProfiles;

    #[test]
    fn snn_uses_shared_neighbor_jaccard_and_keeps_pruning_boundary_and_loops() {
        let graph = shared_graph(
            vec![vec![0, 1], vec![1, 2], vec![2, 3], vec![3, 4], vec![4, 0]],
            2,
        )
        .unwrap();
        assert_eq!(
            graph.edges,
            vec![
                (0, 0, 1.0),
                (0, 1, 1.0 / 3.0),
                (0, 4, 1.0 / 3.0),
                (1, 1, 1.0),
                (1, 2, 1.0 / 3.0),
                (2, 2, 1.0),
                (2, 3, 1.0 / 3.0),
                (3, 3, 1.0),
                (3, 4, 1.0 / 3.0),
                (4, 4, 1.0),
            ]
        );
        let boundary = shared_graph(
            (0..15)
                .map(|row| {
                    if row < 7 {
                        (0..8).collect()
                    } else {
                        (7..15).collect()
                    }
                })
                .collect(),
            8,
        )
        .unwrap();
        assert_eq!(boundary.edges.len(), 120);
        assert!(boundary.edges.contains(&(0, 14, 1.0 / 15.0)));
        let pruned = shared_graph(
            (0..18)
                .map(|row| {
                    if row < 9 {
                        (0..9).collect()
                    } else {
                        (8..17).collect()
                    }
                })
                .collect(),
            9,
        )
        .unwrap();
        assert_eq!(pruned.edges.len(), 90);
        assert!(
            !pruned
                .edges
                .iter()
                .any(|&(left, right, _)| left < 9 && right >= 9)
        );
    }

    #[test]
    fn simple_graph_uses_original_selected_features_and_undirected_union() {
        let values = [99.0, 11.0, -3.0, 0.0, 8.0, 30.0, 1.0, 1.0];
        let profiles = CellProfiles::new(&values, 2, 4).unwrap();
        let graph = simple_graph(&profiles, &[1], &[1, 3, 0, 2], 2).unwrap();
        assert_eq!(
            graph.neighbors,
            vec![vec![0, 1], vec![1, 0], vec![2, 1], vec![3, 2]]
        );
        assert_eq!(
            graph.edges,
            vec![
                (0, 0, 1.0),
                (0, 1, 1.0),
                (1, 1, 1.0),
                (1, 2, 1.0),
                (2, 2, 1.0),
                (2, 3, 1.0),
                (3, 3, 1.0),
            ]
        );
    }

    #[test]
    fn annoy_bridge_reads_cell_major_scores_and_returns_unmodified_neighborhoods() {
        let scores = [0.0, 0.0, 0.05, 0.0, 10.0, 10.0, 10.05, 10.0];
        let graph = pca_graph(&scores, 4, 2, 2).unwrap();
        assert_eq!(graph.vertices, 4);
        assert_eq!(
            graph.neighbors,
            vec![vec![0, 1], vec![1, 0], vec![2, 3], vec![3, 2]]
        );
        assert_eq!(
            graph.edges,
            vec![
                (0, 0, 1.0),
                (0, 1, 1.0),
                (1, 1, 1.0),
                (2, 2, 1.0),
                (2, 3, 1.0),
                (3, 3, 1.0),
            ]
        );
    }
}
