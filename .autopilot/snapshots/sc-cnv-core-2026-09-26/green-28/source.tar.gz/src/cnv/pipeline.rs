use super::config::{PreprocessConfig, ResolvedReferences};
use super::model::{CnvState, PreparedCounts};
use super::{normalize, reference, smooth};
use rsomics_common::{Result, RsomicsError};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Stage {
    Input,
    Filtered,
    DepthNormalized,
    Log2,
    ReferenceCentered,
    Clamped,
    Smoothed,
    CellCentered,
    ReferenceRecentered,
    FoldChange,
}

impl Stage {
    pub fn step(self) -> u8 {
        match self {
            Self::Input => 1,
            Self::Filtered => 2,
            Self::DepthNormalized => 3,
            Self::Log2 => 4,
            Self::ReferenceCentered => 8,
            Self::Clamped => 9,
            Self::Smoothed => 10,
            Self::CellCentered => 11,
            Self::ReferenceRecentered => 12,
            Self::FoldChange => 14,
        }
    }
}

pub fn run(input: &PreparedCounts, config: &PreprocessConfig) -> Result<CnvState> {
    run_with_observer(input, config, |_, _| Ok(()))
}

pub fn run_with_observer(
    input: &PreparedCounts,
    config: &PreprocessConfig,
    mut observer: impl FnMut(Stage, &CnvState) -> Result<()>,
) -> Result<CnvState> {
    let references = config.validate(input)?;
    observer(Stage::Input, input.state())?;

    let mut state = normalize::filter(input, config.cutoff, config.min_cells_per_gene)?;
    observer(Stage::Filtered, &state)?;

    let mut scratch = scratch(&state)?;

    normalize::normalize_depth(&mut state, &mut scratch)?;
    observer(Stage::DepthNormalized, &state)?;

    finish(&mut state, config, &references, &mut scratch, &mut observer)?;
    Ok(state)
}

pub(crate) fn finish_from_depth(
    mut state: CnvState,
    config: &PreprocessConfig,
    references: &ResolvedReferences,
) -> Result<CnvState> {
    let mut scratch = scratch(&state)?;
    finish(&mut state, config, references, &mut scratch, &mut |_, _| {
        Ok(())
    })?;
    Ok(state)
}

fn scratch(state: &CnvState) -> Result<Vec<f64>> {
    let count = state.gene_count().max(state.cell_count());
    let mut values = Vec::new();
    values
        .try_reserve_exact(count)
        .map_err(|_| RsomicsError::InvalidInput("numerical scratch allocation failed".into()))?;
    values.resize(count, 0.0);
    Ok(values)
}

fn finish(
    state: &mut CnvState,
    config: &PreprocessConfig,
    references: &ResolvedReferences,
    scratch: &mut [f64],
    observer: &mut impl FnMut(Stage, &CnvState) -> Result<()>,
) -> Result<()> {
    normalize::log2_one_plus(state)?;
    observer(Stage::Log2, state)?;

    reference::subtract(state, references, scratch)?;
    observer(Stage::ReferenceCentered, state)?;

    normalize::clamp(state, config.max_centered_threshold);
    observer(Stage::Clamped, state)?;

    smooth::triangular(state, config.window_length, config.threads)?;
    observer(Stage::Smoothed, state)?;

    smooth::center_cells(state, scratch)?;
    observer(Stage::CellCentered, state)?;

    reference::subtract(state, references, scratch)?;
    observer(Stage::ReferenceRecentered, state)?;

    normalize::inverse_log2(state)?;
    observer(Stage::FoldChange, state)?;
    Ok(())
}
