use rsomics_common::{Result, RsomicsError};

use super::log_normal::log_survival;

pub(super) struct Model {
    means: [f64; 6],
    sd: f64,
    log_stay: f64,
    log_switch: f64,
}

impl Model {
    pub(super) fn new(means: [f64; 6], mut sds: [f64; 6], transition: f64) -> Result<Self> {
        if means.iter().any(|mean| !mean.is_finite())
            || sds.iter().any(|sd| !sd.is_finite() || *sd < 0.0)
        {
            return Err(invalid(
                "HMM calibration requires finite means and nonnegative SDs",
            ));
        }
        sds.sort_by(f64::total_cmp);
        let sd = sds[2] + (sds[3] - sds[2]) / 2.0;
        if sd <= 0.0 {
            return Err(invalid("HMM calibration median SD must be positive"));
        }
        Ok(Self {
            means,
            sd,
            log_stay: (1.0 - 5.0 * transition).ln(),
            log_switch: transition.ln(),
        })
    }

    pub(super) fn decode(&self, observations: &[f64]) -> Result<Vec<u8>> {
        if observations.is_empty() {
            return Err(invalid("HMM decoding requires at least one observation"));
        }
        let length = observations.len();
        let mut path = Vec::new();
        path.try_reserve_exact(length)
            .map_err(|_| invalid("HMM path allocation failed"))?;
        path.resize(length, 3);
        if length == 1 {
            return Ok(path);
        }
        let mut predecessors = Vec::new();
        predecessors
            .try_reserve_exact(length - 1)
            .map_err(|_| invalid("HMM predecessor allocation failed"))?;

        let mut scores = self.emissions(observations[0])?;
        for (state, score) in scores.iter_mut().enumerate() {
            *score += if state == 2 {
                self.log_stay
            } else {
                self.log_switch
            };
        }
        for &observation in &observations[1..] {
            let emissions = self.emissions(observation)?;
            let mut next = [0.0; 6];
            let mut row = [0_u8; 6];
            for state in 0..6 {
                let mut best = scores[0] + self.transition(0, state);
                let mut previous = 0;
                for (candidate, &score) in scores.iter().enumerate().skip(1) {
                    let value = score + self.transition(candidate, state);
                    if value > best {
                        best = value;
                        previous = candidate;
                    }
                }
                next[state] = best + emissions[state];
                row[state] = previous as u8;
            }
            predecessors.push(row);
            scores = next;
        }
        // Upstream rejects even one unreachable final state, not only an unreachable path.
        if scores.iter().any(|score| !score.is_finite()) {
            return Err(invalid(
                "HMM final scores contain an unreachable or nonfinite state",
            ));
        }
        let mut state = 0;
        for candidate in 1..6 {
            if scores[candidate] > scores[state] {
                state = candidate;
            }
        }
        path[length - 1] = state as u8 + 1;
        for position in (0..length - 1).rev() {
            state = usize::from(predecessors[position][state]);
            path[position] = state as u8 + 1;
        }
        Ok(path)
    }

    fn transition(&self, previous: usize, state: usize) -> f64 {
        if previous == state {
            self.log_stay
        } else {
            self.log_switch
        }
    }

    fn emissions(&self, observation: f64) -> Result<[f64; 6]> {
        let mut weights = [0.0; 6];
        let mut total = 0.0;
        for (weight, mean) in weights.iter_mut().zip(self.means) {
            let deviation = (observation - mean).abs() / self.sd;
            let log_tail = log_survival(deviation);
            if !log_tail.is_finite() || log_tail >= 0.0 {
                return Err(invalid("HMM emission normal tail is nonfinite"));
            }
            *weight = -1.0 / log_tail;
            total += *weight;
        }
        for weight in &mut weights {
            *weight = (*weight / total).ln();
            if !weight.is_finite() {
                return Err(invalid("HMM normalized emission is nonfinite"));
            }
        }
        Ok(weights)
    }
}

fn invalid(message: &str) -> RsomicsError {
    RsomicsError::InvalidInput(message.into())
}

#[cfg(test)]
mod tests {
    use super::Model;

    #[test]
    fn neutral_path_and_singleton_use_neutral_state() {
        let model = Model::new([-2.0, -1.0, 0.0, 1.0, 2.0, 3.0], [0.1; 6], 0.01).unwrap();
        assert_eq!(model.decode(&[0.0; 4]).unwrap(), [3, 3, 3, 3]);
        assert_eq!(model.decode(&[3.0]).unwrap(), [3]);
        assert!(model.decode(&[]).is_err());
    }

    #[test]
    fn equal_emissions_preserve_first_maximum_and_transition_policy() {
        let no_stay = Model::new([0.0; 6], [1.0; 6], 0.2).unwrap();
        assert_eq!(no_stay.decode(&[0.0; 2]).unwrap(), [2, 1]);
        assert_eq!(no_stay.decode(&[0.0; 3]).unwrap(), [1, 2, 1]);
        let no_switch = Model::new([0.0; 6], [1.0; 6], 0.0).unwrap();
        assert!(no_switch.decode(&[0.0; 2]).is_err());
    }

    #[test]
    fn concentrated_emissions_can_overcome_neutral_initialization() {
        let model = Model::new([-2.0, -1.0, 0.0, 1.0, 2.0, 3.0], [0.1; 6], 0.01).unwrap();
        assert_eq!(model.decode(&[-2.0, -2.0, 3.0, 3.0]).unwrap(), [1, 1, 6, 6]);
    }

    #[test]
    fn shared_median_sd_and_finite_tails_preserve_normalized_emissions() {
        let model = Model::new(
            [0.0, 0.0, 0.0, 0.0, 0.0, 3.0],
            [0.0, 1.0, 2.0, 4.0, 8.0, 9.0],
            0.01,
        )
        .unwrap();
        assert!((model.emissions(0.0).unwrap()[5] - (-2.658_871_440_537_415)).abs() < 1e-12);
        let emissions = model.emissions(120.0).unwrap();
        assert!((emissions.iter().map(|value| value.exp()).sum::<f64>() - 1.0).abs() < 1e-12);
        assert_eq!(model.decode(&[120.0; 3]).unwrap(), [3, 3, 3]);
        assert!(Model::new([0.0; 6], [0.0; 6], 0.01).is_err());
        assert!(Model::new([f64::NAN; 6], [1.0; 6], 0.01).is_err());
        assert!(model.decode(&[f64::MAX, -f64::MAX]).is_err());
    }
}
