use super::moments::{self, Sum};
use super::rng::CalibrationRng;
use super::simulate::Spike;
use super::{HmmConfig, invalid, reserved};
use rsomics_common::Result;
use std::num::NonZeroUsize;

#[derive(Debug)]
pub struct Calibration {
    pub means: [f64; 6],
    pub standard_deviations: [f64; 6],
    pub log_sd_fits: [[f64; 2]; 6],
    pub simulated_genes: usize,
    pub simulated_cells: usize,
}

impl Calibration {
    pub(super) fn fit(spike: &Spike, rng: &mut CalibrationRng, config: &HmmConfig) -> Result<Self> {
        let mut model = Self {
            means: [0.0; 6],
            standard_deviations: [0.0; 6],
            log_sd_fits: [[0.0; 2]; 6],
            simulated_genes: spike.state.gene_count(),
            simulated_cells: spike.state.cell_count(),
        };
        for state in [2, 0, 1, 3, 4, 5] {
            let genes: usize = spike
                .blocks
                .iter()
                .filter(|block| block.state == state)
                .map(|block| block.range.len())
                .sum();
            let count = genes
                .checked_mul(spike.observations.len())
                .ok_or_else(|| invalid("calibration distribution size overflows"))?;
            let bytes = count
                .checked_mul(8)
                .ok_or_else(|| invalid("calibration distribution size overflows"))?;
            config.check_budget(bytes)?;
            let mut values = reserved(count)?;
            for block in spike.blocks.iter().filter(|block| block.state == state) {
                for cell in &spike.observations {
                    let offset = cell * spike.state.gene_count();
                    values.extend_from_slice(
                        &spike.state.values()[offset + block.range.start..offset + block.range.end],
                    );
                }
            }
            let (mean, variance) = moments::mean_variance(values.iter().copied(), count)?;
            model.means[state] = mean;
            model.standard_deviations[state] = variance.sqrt();
            model.log_sd_fits[state] = bootstrap_fit(&values, rng)?;
        }
        Ok(model)
    }

    pub(super) fn group_sds(&self, cells: usize) -> [f64; 6] {
        let log_cells = (cells as f64).ln();
        std::array::from_fn(|state| {
            let [intercept, slope] = self.log_sd_fits[state];
            (intercept + slope * log_cells).exp()
        })
    }
}

fn bootstrap_fit(values: &[f64], rng: &mut CalibrationRng) -> Result<[f64; 2]> {
    let population = NonZeroUsize::new(values.len())
        .ok_or_else(|| invalid("calibration distribution is empty"))?;
    let mut x = Vec::with_capacity(99);
    let mut y = Vec::with_capacity(99);
    for cells in 1..=100 {
        let mut sums = vec![Sum::default(); cells];
        for _ in 0..100 {
            for sum in &mut sums {
                sum.add(values[rng.index(population)]);
            }
        }
        if cells == 1 {
            continue;
        }
        // Upstream rowMeans averages replicates, not the sampled cells.
        let means: Vec<_> = sums.iter().map(|sum| sum.finish() / 100.0).collect();
        let (_, variance) = moments::mean_variance(means.iter().copied(), cells)?;
        let log_sd = variance.sqrt().ln();
        if !log_sd.is_finite() {
            return Err(invalid("bootstrap calibration has a nonfinite log SD"));
        }
        x.push((cells as f64).ln());
        y.push(log_sd);
    }
    let mean_x = moments::mean(x.iter().copied(), x.len())?;
    let mean_y = moments::mean(y.iter().copied(), y.len())?;
    let mut covariance = Sum::default();
    let mut squares = Sum::default();
    for (x, y) in x.iter().zip(&y) {
        covariance.add((x - mean_x) * (y - mean_y));
        squares.add((x - mean_x).powi(2));
    }
    let slope = covariance.finish() / squares.finish();
    let intercept = mean_y - slope * mean_x;
    if !intercept.is_finite() || !slope.is_finite() {
        return Err(invalid("calibration regression is nonfinite"));
    }
    Ok([intercept, slope])
}
