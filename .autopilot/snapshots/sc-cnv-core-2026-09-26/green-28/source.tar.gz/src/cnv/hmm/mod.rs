mod bayes;
mod calibrate;
mod decode;
mod log_normal;
mod moments;
mod normal;
mod regions;
pub(crate) mod rng;
mod simulate;
mod spline;

pub use bayes::{
    BayesConfig, BayesSampling, BayesianPredictions, BayesianSamples, RegionPosterior,
    hmm_samples_with_bayes,
};
pub use calibrate::Calibration;
pub use regions::CnvRegion;

use super::{CnvState, CreatedInput, PreprocessConfig, ReferenceMode, Samples, SamplesConfig};
use super::{Stage, parallel, pipeline};
use decode::Model;
use rng::CalibrationRng;
use rsomics_common::{Result, RsomicsError};
use std::ops::Range;

#[derive(Clone, Copy, Debug)]
pub struct HmmConfig {
    seed: u32,
    transition: f64,
    aggregate_normals: bool,
    threads: usize,
    max_numeric_bytes: usize,
}

impl HmmConfig {
    pub fn new(
        seed: u32,
        transition: f64,
        aggregate_normals: bool,
        threads: usize,
        max_numeric_bytes: usize,
    ) -> Result<Self> {
        if seed > i32::MAX as u32 {
            return Err(invalid("HMM seed must fit a nonnegative R integer"));
        }
        if !transition.is_finite() || !(0.0..=0.2).contains(&transition) {
            return Err(invalid(
                "HMM transition probability must be between 0 and 0.2",
            ));
        }
        if threads == 0 || max_numeric_bytes == 0 {
            return Err(invalid("HMM workers and workspace budget must be positive"));
        }
        Ok(Self {
            seed,
            transition,
            aggregate_normals,
            threads,
            max_numeric_bytes,
        })
    }

    fn check_budget(&self, bytes: usize) -> Result<()> {
        if bytes > self.max_numeric_bytes {
            return Err(invalid("HMM exceeds the numerical workspace budget"));
        }
        Ok(())
    }
}

#[derive(Debug)]
pub struct HmmSamples {
    pub state: CnvState,
    pub samples: Samples,
    pub predictions: HmmPredictions,
}

#[derive(Debug)]
pub struct HmmPredictions {
    pub calibration: Calibration,
    pub groups: Vec<HmmGroup>,
}

#[derive(Debug)]
pub struct HmmGroup {
    pub name: String,
    pub member_indices: Vec<usize>,
    pub states: Vec<u8>,
    pub regions: Vec<CnvRegion>,
}

/// Runs grouped-sample i6 inference without Bayesian filtering or changing expression values.
pub fn hmm_samples(
    input: &CreatedInput,
    preprocess: &PreprocessConfig,
    samples_config: &SamplesConfig,
    config: &HmmConfig,
) -> Result<HmmSamples> {
    if !samples_config.cluster_by_groups {
        return Err(invalid(
            "HMM samples currently requires grouped sample clustering",
        ));
    }
    let reference_names: Vec<_> = input
        .reference_groups()
        .iter()
        .map(|group| group.name())
        .collect();
    let matching_references = match &preprocess.references {
        ReferenceMode::AllCells => reference_names.is_empty(),
        ReferenceMode::GroupBounds(names) | ReferenceMode::GroupMean(names) => {
            names.iter().map(String::as_str).eq(reference_names)
        }
    };
    if !matching_references {
        return Err(invalid(
            "HMM preprocessing references differ from created input",
        ));
    }
    let mut rng = CalibrationRng::new(config.seed);
    let mut spike = None;
    let state =
        pipeline::run_with_observer(input.prepared_counts(), preprocess, |stage, state| {
            if stage == Stage::DepthNormalized {
                spike = Some(simulate::simulate(
                    state, input, preprocess, config, &mut rng,
                )?);
            }
            Ok(())
        })?;
    let mut spike = spike.ok_or_else(|| invalid("HMM did not reach depth normalization"))?;
    spike.state = pipeline::finish_from_depth(spike.state, preprocess, &spike.references)?;
    let calibration = Calibration::fit(&spike, &mut rng, config)?;
    drop(spike);
    let samples = super::samples(&state, input, samples_config)?;
    let predictions = predict(&state, input, &samples, calibration, config)?;
    Ok(HmmSamples {
        state,
        samples,
        predictions,
    })
}

struct DecodeTask<'a> {
    group: usize,
    range: Range<usize>,
    output: &'a mut [u8],
}

fn predict(
    state: &CnvState,
    input: &CreatedInput,
    samples: &Samples,
    calibration: Calibration,
    config: &HmmConfig,
) -> Result<HmmPredictions> {
    let groups: Vec<_> = input
        .observation_groups()
        .iter()
        .chain(input.reference_groups())
        .collect();
    let genes = state.gene_count();
    let count = genes
        .checked_mul(groups.len())
        .ok_or_else(|| invalid("HMM profile size overflows"))?;
    let bytes = count
        .checked_mul(9)
        .and_then(|n| {
            genes
                .checked_mul(7)
                .and_then(|m| m.checked_mul(config.threads.min(groups.len())))
                .and_then(|m| n.checked_add(m))
        })
        .ok_or_else(|| invalid("HMM prediction workspace size overflows"))?;
    config.check_budget(bytes)?;
    let mut profiles = reserved(count)?;
    profiles.resize(count, 0.0);
    let chunk = count.div_ceil(config.threads.min(count));
    parallel::for_chunks(&mut profiles, chunk, |part, output| {
        for (offset, value) in output.iter_mut().enumerate() {
            let index = part * chunk + offset;
            let members = groups[index / genes].cell_indices();
            let gene = index % genes;
            *value = moments::mean(
                members
                    .iter()
                    .map(|cell| state.values()[cell * genes + gene]),
                members.len(),
            )?;
        }
        Ok(())
    })?;
    let models: Vec<_> = groups
        .iter()
        .map(|group| {
            Model::new(
                calibration.means,
                calibration.group_sds(group.cell_indices().len()),
                config.transition,
            )
        })
        .collect::<Result<_>>()?;
    let mut chromosomes = Vec::new();
    let mut start = 0;
    while start < genes {
        let mut end = start + 1;
        while end < genes && state.genes()[end].chromosome == state.genes()[start].chromosome {
            end += 1;
        }
        chromosomes.push(start..end);
        start = end;
    }
    let mut states = reserved(count)?;
    states.resize(count, 3_u8);
    let mut tasks = Vec::new();
    for (group, output) in states.chunks_exact_mut(genes).enumerate() {
        let mut remaining = output;
        for range in &chromosomes {
            let (output, rest) = remaining.split_at_mut(range.len());
            tasks.push(DecodeTask {
                group,
                range: range.clone(),
                output,
            });
            remaining = rest;
        }
    }
    let chunk = tasks.len().div_ceil(config.threads.min(tasks.len()));
    parallel::for_chunks(&mut tasks, chunk, |_, tasks| {
        for task in tasks {
            let start = task.group * genes + task.range.start;
            let end = task.group * genes + task.range.end;
            task.output
                .copy_from_slice(&models[task.group].decode(&profiles[start..end])?);
        }
        Ok(())
    })?;
    drop(tasks);
    drop(profiles);
    drop(models);
    let mut counter = 0;
    let mut predictions = reserved(groups.len())?;
    for (index, group) in samples.groups.iter().enumerate() {
        let path = states[index * genes..(index + 1) * genes].to_vec();
        let regions = regions::regions(state.genes(), &path, &mut counter)?;
        predictions.push(HmmGroup {
            name: format!("{}.{}", group.name, group.subcluster_name),
            member_indices: group.member_indices.clone(),
            states: path,
            regions,
        });
    }
    Ok(HmmPredictions {
        calibration,
        groups: predictions,
    })
}

fn invalid(message: &str) -> RsomicsError {
    RsomicsError::InvalidInput(message.into())
}

fn reserved<T>(count: usize) -> Result<Vec<T>> {
    let mut values = Vec::new();
    values
        .try_reserve_exact(count)
        .map_err(|_| invalid("HMM workspace allocation failed"))?;
    Ok(values)
}
