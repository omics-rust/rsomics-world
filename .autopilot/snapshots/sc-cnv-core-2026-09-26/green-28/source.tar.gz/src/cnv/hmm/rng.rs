use super::normal::quantile;
use std::num::NonZeroUsize;

pub(crate) struct CalibrationRng {
    state: [u32; 624],
    position: usize,
}

impl CalibrationRng {
    pub(crate) fn new(seed: u32) -> Self {
        let advance = |state: u32| state.wrapping_mul(69_069).wrapping_add(1);
        let mut value = seed;
        for _ in 0..51 {
            value = advance(value);
        }
        let mut state = [0; 624];
        for word in &mut state {
            value = advance(value);
            *word = value;
        }
        Self {
            state,
            position: 624,
        }
    }

    fn word(&mut self) -> u32 {
        if self.position == 624 {
            for i in 0..624 {
                let joined =
                    (self.state[i] & 0x8000_0000) | (self.state[(i + 1) % 624] & 0x7fff_ffff);
                let parity = if joined & 1 == 0 { 0 } else { 0x9908_b0df };
                self.state[i] = self.state[(i + 397) % 624] ^ (joined >> 1) ^ parity;
            }
            self.position = 0;
        }
        let mut word = self.state[self.position];
        self.position += 1;
        word ^= word >> 11;
        word ^= (word << 7) & 0x9d2c_5680;
        word ^= (word << 15) & 0xefc6_0000;
        word ^= word >> 18;
        word
    }

    pub(crate) fn uniform(&mut self) -> f64 {
        let word = self.word();
        if word == 0 {
            0.5 / f64::from(u32::MAX)
        } else {
            f64::from(word) / 4_294_967_296.0
        }
    }

    pub(super) fn normal(&mut self, mean: f64, sd: f64) -> f64 {
        if sd == 0.0 {
            return mean;
        }
        let high = (134_217_728.0 * self.uniform()).floor();
        let probability = (high + self.uniform()) / 134_217_728.0;
        mean + sd * quantile(probability)
    }

    pub(crate) fn index(&mut self, count: NonZeroUsize) -> usize {
        let bits = usize::BITS - (count.get() - 1).leading_zeros();
        let mask = ((1_u128 << bits) - 1) as u64;
        loop {
            let mut draw = 0.0;
            for _ in (0..=bits).step_by(16) {
                draw = 65_536.0 * draw + (65_536.0 * self.uniform()).floor();
            }
            let index = (draw as u64 & mask) as usize;
            if index < count.get() {
                return index;
            }
        }
    }
}

#[cfg(test)]
#[allow(clippy::excessive_precision)]
mod tests {
    use super::CalibrationRng;
    use std::num::NonZeroUsize;

    #[test]
    fn mixed_stream_matches_r_461() {
        let mut rng = CalibrationRng::new(17);
        for expected in [
            0.15505083324387670_f64,
            0.96837880881503224,
            0.46826308593153954,
            0.77681965171359479,
        ] {
            assert_eq!(rng.uniform().to_bits(), expected.to_bits());
        }
        for expected in [
            -0.23298702195762605,
            -0.81726793367602024,
            0.77209083920020372,
        ] {
            assert!((rng.normal(0.0, 1.0) - expected).abs() < 1e-14);
        }
        let count = NonZeroUsize::new(7).unwrap();
        for expected in [1, 5, 6, 0, 3] {
            assert_eq!(rng.index(count), expected);
        }
    }

    #[test]
    fn degenerate_draws_and_twist_boundary_keep_r_stream() {
        let mut rng = CalibrationRng::new(123);
        assert_eq!(rng.normal(42.0, 0.0), 42.0);
        assert_eq!(rng.index(NonZeroUsize::new(1).unwrap()), 0);
        assert_eq!(rng.uniform(), 0.78830513544380665);
        for _ in 0..621 {
            rng.uniform();
        }
        for expected in [
            0.37681641685776412,
            0.042108048684895039,
            0.36441108165308833,
        ] {
            assert_eq!(rng.uniform(), expected);
        }
    }
}
