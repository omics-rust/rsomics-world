use super::moments::{self, Sum};
use super::rng::CalibrationRng;
use super::spline::Spline;
use super::{HmmConfig, invalid, reserved};
use crate::cnv::config::{PreprocessConfig, ReferenceMode, ResolvedReferences};
use crate::cnv::{Cell, CnvState, CreatedInput, Gene, normalize, parallel};
use rsomics_common::Result;
use std::num::NonZeroUsize;
use std::ops::Range;

pub(super) const LEVELS: [f64; 6] = [0.01, 0.5, 1.0, 1.5, 2.0, 3.0];
const CELLS: usize = 100;

pub(super) struct Block {
    pub range: Range<usize>,
    pub state: usize,
}

pub(super) struct Spike {
    pub state: CnvState,
    pub references: ResolvedReferences,
    pub observations: Vec<usize>,
    pub blocks: Vec<Block>,
}

#[derive(Clone, Copy, Default)]
struct GeneMoments {
    mean: f64,
    variance: f64,
    dropout: f64,
}

pub(super) fn simulate(
    state: &CnvState,
    input: &CreatedInput,
    preprocess: &PreprocessConfig,
    config: &HmmConfig,
    rng: &mut CalibrationRng,
) -> Result<Spike> {
    let proxy = input.reference_groups().is_empty();
    let pooled: Vec<_> = if proxy {
        input.observation_groups()
    } else {
        input.reference_groups()
    }
    .iter()
    .flat_map(|group| group.cell_indices().iter().copied())
    .collect();
    let normal_groups: Vec<(&str, &[usize])> = if proxy || config.aggregate_normals {
        vec![("normalsToUse", &pooled)]
    } else {
        input
            .reference_groups()
            .iter()
            .map(|group| (group.name(), group.cell_indices()))
            .collect()
    };
    let fit_groups: Vec<&[usize]> = if proxy {
        vec![&pooled]
    } else {
        input
            .observation_groups()
            .iter()
            .chain(input.reference_groups())
            .map(|group| group.cell_indices())
            .collect()
    };
    let genes = state.gene_count().max(4400);
    let cells = normal_groups
        .len()
        .checked_mul(2 * CELLS)
        .ok_or_else(|| invalid("simulated cell count overflows"))?;
    let values_count = genes
        .checked_mul(cells)
        .ok_or_else(|| invalid("simulated matrix shape overflows"))?;
    let table_count = state
        .gene_count()
        .checked_mul(fit_groups.len())
        .ok_or_else(|| invalid("calibration table size overflows"))?;
    let bytes = values_count
        .checked_mul(24)
        .and_then(|n| table_count.checked_mul(384).and_then(|m| n.checked_add(m)))
        .and_then(|n| genes.checked_mul(80).and_then(|m| n.checked_add(m)))
        .and_then(|n| cells.checked_mul(64).and_then(|m| n.checked_add(m)))
        .and_then(|n| n.checked_add(65_536))
        .ok_or_else(|| invalid("calibration workspace size overflows"))?;
    config.check_budget(bytes)?;
    let (variance_curve, dropout_curve) = curves(state, &fit_groups, config, table_count)?;
    let mut source_indices = reserved(genes)?;
    let population = NonZeroUsize::new(state.gene_count())
        .ok_or_else(|| invalid("calibration needs retained genes"))?;
    for _ in 0..genes {
        source_indices.push(rng.index(population));
    }

    let labels = [
        "chrA", "chr_0", "chr_B", "chr_0pt5", "chr_C", "chr_1pt5", "chr_D", "chr_2pt0", "chr_E",
        "chr_3pt0", "chr_F",
    ];
    let levels = [2, 0, 2, 1, 2, 3, 2, 4, 2, 5, 2];
    let mut blocks = Vec::with_capacity(labels.len());
    let mut fake_genes = Vec::with_capacity(genes);
    for (i, (label, level)) in labels.iter().zip(levels).enumerate() {
        let start = fake_genes.len();
        let count = if i + 1 == labels.len() {
            genes - 4000
        } else {
            400
        };
        for position in 1..=count {
            fake_genes.push(Gene {
                id: format!("gene_{}", fake_genes.len() + 1),
                chromosome: (*label).into(),
                start: position as u64,
                end: position as u64,
            });
        }
        blocks.push(Block {
            range: start..fake_genes.len(),
            state: level,
        });
    }
    let mut values = reserved(values_count)?;
    let mut fake_cells = Vec::with_capacity(cells);
    let mut references = Vec::with_capacity(normal_groups.len());
    let mut observations = Vec::with_capacity(cells / 2);
    for (name, indices) in &normal_groups {
        let base = fake_cells.len();
        let mut original_means = reserved(state.gene_count())?;
        for gene in 0..state.gene_count() {
            original_means.push(moments::mean(
                indices
                    .iter()
                    .map(|cell| state.values()[cell * state.gene_count() + gene]),
                indices.len(),
            )?);
        }
        let means: Vec<_> = source_indices
            .iter()
            .map(|index| {
                let value = original_means[*index];
                if value == 0.0 { 1e-3 } else { value }
            })
            .collect();
        let mut spiked = means.clone();
        for block in &blocks {
            if block.state != 2 {
                for value in &mut spiked[block.range.clone()] {
                    *value *= LEVELS[block.state];
                }
            }
        }
        for (prefix, means) in [("simnorm_cell_", &means), ("spike_tumor_cell_", &spiked)] {
            let group = format!("{prefix}{name}");
            values.extend(matrix(means, &variance_curve, &dropout_curve, rng)?);
            fake_cells.extend((1..=CELLS).map(|i| Cell {
                id: format!("{group}{i}"),
                group: group.clone(),
            }));
        }
        references.push((base..base + CELLS).collect());
        observations.extend(base + CELLS..base + 2 * CELLS);
    }
    let last_group = normal_groups
        .last()
        .ok_or_else(|| invalid("calibration has no cell groups"))?
        .1;
    let mut depths = reserved(last_group.len())?;
    for cell in last_group {
        let mut sum = Sum::default();
        for value in &state.values()[cell * state.gene_count()..(cell + 1) * state.gene_count()] {
            sum.add(*value);
        }
        depths.push(sum.finish());
    }
    let target = normalize::median(&mut depths)?;
    let mut simulated = CnvState {
        genes: fake_genes,
        cells: fake_cells,
        values,
    };
    normalize::normalize_depth_to(&mut simulated, target)?;
    Ok(Spike {
        state: simulated,
        references: match &preprocess.references {
            ReferenceMode::GroupMean(_) => ResolvedReferences::Mean(references),
            _ => ResolvedReferences::Bounds(references),
        },
        observations,
        blocks,
    })
}

fn curves(
    state: &CnvState,
    groups: &[&[usize]],
    config: &HmmConfig,
    count: usize,
) -> Result<(Spline, Spline)> {
    let mut table = reserved(count)?;
    table.resize(count, GeneMoments::default());
    let chunk = count.div_ceil(config.threads.min(count));
    parallel::for_chunks(&mut table, chunk, |part, output| {
        for (offset, row) in output.iter_mut().enumerate() {
            let index = part * chunk + offset;
            let gene = index % state.gene_count();
            let members = groups[index / state.gene_count()];
            let values = members
                .iter()
                .map(|cell| state.values()[cell * state.gene_count() + gene]);
            let (mean, variance) = moments::mean_variance(values.clone(), members.len())?;
            let zeros = values.filter(|value| *value == 0.0).count();
            *row = GeneMoments {
                mean,
                variance,
                dropout: zeros as f64 / members.len() as f64,
            };
        }
        Ok(())
    })?;
    let x: Vec<_> = table.iter().map(|row| (row.mean + 1.0).ln()).collect();
    let y: Vec<_> = table.iter().map(|row| (row.variance + 1.0).ln()).collect();
    let variance = Spline::fit(&x, &y)?;
    let positive: Vec<_> = table.iter().filter(|row| row.mean > 0.0).collect();
    let x: Vec<_> = positive.iter().map(|row| row.mean.ln()).collect();
    let y: Vec<_> = positive.iter().map(|row| row.dropout).collect();
    let dropout = Spline::fit(&x, &y)?;
    Ok((variance, dropout))
}

fn matrix(
    means: &[f64],
    variance: &Spline,
    dropout: &Spline,
    rng: &mut CalibrationRng,
) -> Result<Vec<f64>> {
    let mut parameters = reserved(means.len())?;
    for mean in means {
        let prediction = variance.predict((mean + 1.0).ln());
        let variance = prediction.exp() - 1.0;
        if !variance.is_finite() {
            return Err(invalid("simulated gene variance is nonfinite"));
        }
        parameters.push((*mean, variance.max(0.0).sqrt()));
    }
    let mut values = reserved(means.len() * CELLS)?;
    for _ in 0..CELLS {
        for (mean, sd) in &parameters {
            let value = rng.normal(*mean, *sd);
            values.push(if value < 0.0 {
                0.0
            } else {
                value.round_ties_even()
            });
        }
    }
    for gene in 0..means.len() {
        let row = (0..CELLS).map(|cell| values[cell * means.len() + gene]);
        let mean = moments::mean(row.clone(), CELLS)?;
        let zeros = row.filter(|value| *value == 0.0).count();
        let probability = dropout.predict(mean.ln());
        let adjustment = (probability * CELLS as f64 - zeros as f64) / (CELLS - zeros) as f64;
        if adjustment.is_nan() {
            return Err(invalid("simulated dropout probability is NaN"));
        }
        let adjustment = adjustment.max(0.0);
        for cell in 0..CELLS {
            if rng.uniform() <= adjustment {
                values[cell * means.len() + gene] = 0.0;
            }
        }
    }
    Ok(values)
}
