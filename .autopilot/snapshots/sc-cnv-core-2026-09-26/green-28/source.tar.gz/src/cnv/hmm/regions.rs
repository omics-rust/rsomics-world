use crate::cnv::Gene;
use rsomics_common::{Result, RsomicsError};

#[derive(Debug)]
pub struct CnvRegion {
    pub name: String,
    pub state: u8,
    pub chromosome: String,
    pub start: u64,
    pub end: u64,
    pub gene_start: usize,
    pub gene_end: usize,
}

pub(super) fn regions(
    genes: &[Gene],
    states: &[u8],
    counter: &mut usize,
) -> Result<Vec<CnvRegion>> {
    if genes.len() != states.len() {
        return Err(RsomicsError::InvalidInput(format!(
            "HMM region emission requires one state per gene: {} genes, {} states",
            genes.len(),
            states.len()
        )));
    }

    let mut predictions = Vec::new();
    let mut chromosome_start = 0;
    while chromosome_start < genes.len() {
        let chromosome = &genes[chromosome_start].chromosome;
        let mut chromosome_end = chromosome_start + 1;
        while chromosome_end < genes.len() && genes[chromosome_end].chromosome == *chromosome {
            chromosome_end += 1;
        }
        if chromosome_end - chromosome_start >= 2 {
            let mut gene_start = chromosome_start;
            while gene_start < chromosome_end {
                let state = states[gene_start];
                let mut gene_end = gene_start + 1;
                let mut start = genes[gene_start].start;
                let mut end = genes[gene_start].end;
                while gene_end < chromosome_end && states[gene_end] == state {
                    start = start.min(genes[gene_end].start);
                    end = end.max(genes[gene_end].end);
                    gene_end += 1;
                }
                // Neutral runs occupy IDs even though they are not predictions.
                *counter = counter.checked_add(1).ok_or_else(|| {
                    RsomicsError::InvalidInput("HMM region counter overflows".into())
                })?;
                if state != 3 {
                    predictions.push(CnvRegion {
                        name: format!("{chromosome}-region_{counter}"),
                        state,
                        chromosome: chromosome.clone(),
                        start,
                        end,
                        gene_start,
                        gene_end,
                    });
                }
                gene_start = gene_end;
            }
        }
        chromosome_start = chromosome_end;
    }
    Ok(predictions)
}

#[cfg(test)]
mod tests {
    use super::*;

    type RegionBounds<'a> = (&'a str, u8, &'a str, u64, u64, usize, usize);

    fn gene(id: &str, chromosome: &str, start: u64, end: u64) -> Gene {
        Gene {
            id: id.into(),
            chromosome: chromosome.into(),
            start,
            end,
        }
    }

    fn bounds(regions: &[CnvRegion]) -> Vec<RegionBounds<'_>> {
        regions
            .iter()
            .map(|region| {
                (
                    region.name.as_str(),
                    region.state,
                    region.chromosome.as_str(),
                    region.start,
                    region.end,
                    region.gene_start,
                    region.gene_end,
                )
            })
            .collect()
    }

    #[test]
    fn neutral_gaps_and_singleton_chromosomes_preserve_global_group_numbering() {
        let genes = [
            gene("a", "chr1", 10, 20),
            gene("b", "chr1", 30, 40),
            gene("c", "chr1", 50, 60),
            gene("d", "chr1", 70, 80),
            gene("e", "chr2", 1, 9),
            gene("f", "chr3", 100, 110),
            gene("g", "chr3", 120, 130),
        ];
        let mut counter = 0;
        let first = regions(&genes, &[1, 3, 1, 1, 2, 3, 6], &mut counter).unwrap();
        assert_eq!(
            bounds(&first),
            vec![
                ("chr1-region_1", 1, "chr1", 10, 20, 0, 1),
                ("chr1-region_3", 1, "chr1", 50, 80, 2, 4),
                ("chr3-region_5", 6, "chr3", 120, 130, 6, 7),
            ]
        );
        assert_eq!(counter, 5);

        let second = regions(&genes, &[3, 3, 3, 3, 2, 6, 6], &mut counter).unwrap();
        assert_eq!(
            bounds(&second),
            vec![("chr3-region_7", 6, "chr3", 100, 130, 5, 7)]
        );
        assert_eq!(counter, 7);
    }

    #[test]
    fn nested_genes_use_the_maximum_end_not_the_last_end() {
        let genes = [
            gene("outer", "chr1", 10, 500),
            gene("inner", "chr1", 20, 100),
            gene("last", "chr1", 30, 80),
        ];
        let mut counter = 0;
        let result = regions(&genes, &[2, 2, 2], &mut counter).unwrap();
        assert_eq!(
            bounds(&result),
            vec![("chr1-region_1", 2, "chr1", 10, 500, 0, 3)]
        );
        assert_eq!(counter, 1);
    }

    #[test]
    fn mismatched_lengths_fail_before_changing_the_counter() {
        let genes = [gene("a", "chr1", 10, 20), gene("b", "chr1", 30, 40)];
        let mut counter = 7;
        assert!(regions(&genes, &[1], &mut counter).is_err());
        assert!(regions(&genes, &[1, 2, 3], &mut counter).is_err());
        assert_eq!(counter, 7);
    }
}
