use rsomics_common::{Result, RsomicsError};

#[derive(Clone, Copy, Default)]
pub(super) struct Sum {
    value: f64,
    correction: f64,
}

impl Sum {
    pub(super) fn add(&mut self, value: f64) {
        let next = self.value + value;
        self.correction += if self.value.abs() >= value.abs() {
            (self.value - next) + value
        } else {
            (value - next) + self.value
        };
        self.value = next;
    }

    pub(super) fn finish(&self) -> f64 {
        self.value + self.correction
    }
}

pub(super) fn mean(values: impl Iterator<Item = f64> + Clone, count: usize) -> Result<f64> {
    let mut sum = Sum::default();
    for value in values.clone() {
        sum.add(value);
    }
    let mean = sum.finish() / count as f64;
    let mut correction = Sum::default();
    for value in values {
        correction.add(value - mean);
    }
    let mean = mean + correction.finish() / count as f64;
    if !mean.is_finite() {
        return Err(invalid());
    }
    Ok(mean)
}

pub(super) fn mean_variance(
    values: impl Iterator<Item = f64> + Clone,
    count: usize,
) -> Result<(f64, f64)> {
    let mean = mean(values.clone(), count)?;
    let mut squares = Sum::default();
    for value in values {
        squares.add((value - mean).powi(2));
    }
    let variance = squares.finish() / (count as f64 - 1.0);
    if !variance.is_finite() || variance < 0.0 {
        return Err(invalid());
    }
    Ok((mean, variance))
}

fn invalid() -> RsomicsError {
    RsomicsError::InvalidInput(
        "calibration moments are nonfinite; variance requires at least two values".into(),
    )
}
