#![allow(clippy::excessive_precision)]

pub(super) fn log_survival(deviation: f64) -> f64 {
    let x = deviation * std::f64::consts::FRAC_1_SQRT_2;
    if x < 1.0 {
        let squared = x * x;
        let erf = x * polynomial(squared, &T) / monic_polynomial(squared, &U);
        return (-erf).ln_1p() - std::f64::consts::LN_2;
    }
    let log_ratio = if x < 8.0 {
        (polynomial(x, &P) / monic_polynomial(x, &Q)).ln()
    } else {
        // Reciprocal evaluation avoids polynomial overflow before the log tail overflows.
        let inverse = x.recip();
        let numerator = reciprocal_polynomial(inverse, &R);
        let denominator = 1.0 + inverse * reciprocal_polynomial(inverse, &S);
        -x.ln() + (numerator / denominator).ln()
    };
    -x * x + log_ratio - std::f64::consts::LN_2
}

fn polynomial(x: f64, coefficients: &[f64]) -> f64 {
    coefficients[1..]
        .iter()
        .fold(coefficients[0], |value, coefficient| {
            value * x + coefficient
        })
}

fn monic_polynomial(x: f64, coefficients: &[f64]) -> f64 {
    coefficients
        .iter()
        .fold(1.0, |value, coefficient| value * x + coefficient)
}

fn reciprocal_polynomial(inverse: f64, coefficients: &[f64]) -> f64 {
    coefficients
        .iter()
        .rev()
        .fold(0.0, |value, coefficient| value * inverse + coefficient)
}

const T: [f64; 5] = [
    9.604_973_739_870_516_387_49e0,
    9.002_601_972_038_426_892_17e1,
    2.232_005_345_946_843_192_26e3,
    7.003_325_141_128_050_754_73e3,
    5.559_230_130_103_949_627_68e4,
];
const U: [f64; 5] = [
    3.356_171_416_475_030_996_47e1,
    5.213_579_497_801_526_797_95e2,
    4.594_323_829_709_801_279_87e3,
    2.262_900_006_138_909_342_46e4,
    4.926_739_426_086_359_210_86e4,
];
const P: [f64; 9] = [
    2.461_969_814_735_305_125_24e-10,
    5.641_895_648_310_688_219_77e-1,
    7.463_210_564_422_699_126_87e0,
    4.863_719_709_856_813_666_14e1,
    1.965_208_329_560_770_982_42e2,
    5.264_451_949_954_773_586_31e2,
    9.345_285_271_719_576_075_40e2,
    1.027_551_886_895_157_102_72e3,
    5.575_353_353_693_993_275_26e2,
];
const Q: [f64; 8] = [
    1.322_819_511_547_449_925_08e1,
    8.670_721_408_859_897_423_29e1,
    3.549_377_788_878_198_910_62e2,
    9.757_085_017_432_054_897_53e2,
    1.823_909_166_879_097_362_89e3,
    2.246_337_608_187_109_817_92e3,
    1.656_663_091_941_613_501_82e3,
    5.575_353_408_177_276_755_46e2,
];
const R: [f64; 6] = [
    5.641_895_835_477_550_739_84e-1,
    1.275_366_707_599_781_044_16e0,
    5.019_050_422_511_804_774_14e0,
    6.160_210_979_930_535_851_95e0,
    7.409_742_699_504_489_391_60e0,
    2.978_866_653_721_002_406_70e0,
];
const S: [f64; 6] = [
    2.260_528_632_201_172_765_90e0,
    9.396_035_249_380_014_346_73e0,
    1.204_895_398_080_966_566_05e1,
    1.708_144_507_475_658_972_22e1,
    9.608_968_090_632_858_781_98e0,
    3.369_076_451_000_815_160_50e0,
];

#[cfg(test)]
mod tests {
    use super::log_survival;

    #[test]
    fn normal_tail_stays_finite_after_probability_underflow() {
        assert_eq!(log_survival(0.0), -std::f64::consts::LN_2);
        assert!((log_survival(1.0) - (-1.841_021_645_009_263_4)).abs() < 2e-14);
        assert!((log_survival(40.0) - (-804.608_442_013_753_8)).abs() < 2e-12);
    }
}
