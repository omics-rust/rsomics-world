use super::super::{invalid, reserved, rng::CalibrationRng};
use rsomics_common::Result;

pub(super) const CHAINS: usize = 6;
pub(super) const BURN_IN: usize = 700;
pub(super) const SAMPLES: usize = 1000;

pub(super) struct Posterior {
    pub probabilities: [f64; 6],
    pub cell_probabilities: Vec<[f64; 6]>,
    pub chain_probabilities: [[f64; 6]; 6],
}

pub(super) fn stream_seed(seed: u32, stream: usize) -> u32 {
    let mut key = seed ^ 0x91e1_0da5;
    for byte in (stream as u64).to_le_bytes() {
        key = (key.rotate_left(7) ^ u32::from(byte)).wrapping_mul(0x9e37_79b1);
        key ^= key >> 13;
    }
    key ^= key >> 16;
    key = key.wrapping_mul(0x85eb_ca77);
    key ^ (key >> 15)
}

pub(super) fn sample(log_likelihoods: &[[f64; 6]], seed: u32) -> Result<Posterior> {
    if log_likelihoods.is_empty() {
        return Err(invalid("Bayesian region requires at least one cell"));
    }
    let cells = log_likelihoods.len();
    let mut scaled_likelihoods = reserved(cells)?;
    for likelihoods in log_likelihoods {
        if likelihoods
            .iter()
            .any(|value| value.is_nan() || *value == f64::INFINITY)
        {
            return Err(invalid(
                "Bayesian log likelihood must be finite or negative infinity",
            ));
        }
        let maximum = likelihoods
            .iter()
            .copied()
            .fold(f64::NEG_INFINITY, f64::max);
        if maximum == f64::NEG_INFINITY {
            return Err(invalid("Bayesian cell has zero likelihood in every state"));
        }
        scaled_likelihoods.push(likelihoods.map(|value| (value - maximum).exp()));
    }

    let mut assignments = reserved(cells)?;
    assignments.resize(cells, 0_usize);
    let mut cell_counts = reserved(cells)?;
    cell_counts.resize(cells, [0_u32; 6]);
    let mut cell_probabilities = reserved(cells)?;
    let mut chain_probabilities = [[0.0; 6]; CHAINS];
    let mut total_counts = [0_u128; 6];

    for (chain, probabilities) in chain_probabilities.iter_mut().enumerate() {
        assignments.fill(chain);
        let mut counts = [0_usize; 6];
        counts[chain] = cells;
        let mut kept_counts = [0_u128; 6];
        let mut rng = CalibrationRng::new(stream_seed(seed, chain));
        for sweep in 0..BURN_IN + SAMPLES {
            for (cell, (assignment, likelihoods)) in
                assignments.iter_mut().zip(&scaled_likelihoods).enumerate()
            {
                counts[*assignment] -= 1;
                let mut weights = [0.0; 6];
                let mut maximum = 0.0;
                let mut selected = 0;
                for (state, ((weight, likelihood), count)) in
                    weights.iter_mut().zip(likelihoods).zip(&counts).enumerate()
                {
                    *weight = likelihood * (*count as f64 + 1.0);
                    if *weight > maximum {
                        maximum = *weight;
                        selected = state;
                    }
                }
                let draw = rng.uniform() * weights.iter().sum::<f64>();
                let mut cumulative = 0.0;
                for (state, weight) in weights.iter().enumerate() {
                    cumulative += weight;
                    if draw < cumulative {
                        selected = state;
                        break;
                    }
                }
                *assignment = selected;
                counts[selected] += 1;
                if sweep >= BURN_IN {
                    cell_counts[cell][selected] += 1;
                }
            }
            if sweep >= BURN_IN {
                for (kept, count) in kept_counts.iter_mut().zip(counts) {
                    *kept += count as u128;
                }
            }
        }
        let denominator = SAMPLES as u128 * (cells as u128 + 6);
        for (state, probability) in probabilities.iter_mut().enumerate() {
            *probability = (kept_counts[state] + SAMPLES as u128) as f64 / denominator as f64;
            total_counts[state] += kept_counts[state];
        }
    }

    let draws = (CHAINS * SAMPLES) as u128;
    let denominator = draws * (cells as u128 + 6);
    let probabilities = total_counts.map(|count| (count + draws) as f64 / denominator as f64);
    for counts in cell_counts {
        cell_probabilities.push(counts.map(|count| f64::from(count) / draws as f64));
    }
    Ok(Posterior {
        probabilities,
        cell_probabilities,
        chain_probabilities,
    })
}

#[cfg(test)]
mod tests {
    use super::sample;

    #[test]
    fn concentrated_cells_keep_dirichlet_mass_and_half_threshold() {
        let likelihood = [-1000.0, -1000.0, 0.0, -1000.0, -1000.0, -1000.0];
        for (cells, expected) in [
            (
                1,
                [
                    1.0 / 7.0,
                    1.0 / 7.0,
                    2.0 / 7.0,
                    1.0 / 7.0,
                    1.0 / 7.0,
                    1.0 / 7.0,
                ],
            ),
            (4, [0.1, 0.1, 0.5, 0.1, 0.1, 0.1]),
        ] {
            let posterior = sample(&vec![likelihood; cells], 17).unwrap();
            assert_eq!(posterior.probabilities, expected);
            for probability in posterior.cell_probabilities {
                assert_eq!(probability, [0.0, 0.0, 1.0, 0.0, 0.0, 0.0]);
            }
            for probability in posterior.chain_probabilities {
                assert_eq!(probability, expected);
            }
            if cells == 4 {
                let filtered = posterior.probabilities[2] > 0.5;
                assert!(!filtered);
            }
        }
    }

    #[test]
    fn one_cell_matches_analytic_categorical_and_mixture_posteriors() {
        let likelihood = [
            0.0,
            2.0_f64.ln(),
            3.0_f64.ln(),
            4.0_f64.ln(),
            5.0_f64.ln(),
            6.0_f64.ln(),
        ];
        let posterior = sample(&[likelihood], 31).unwrap();
        let expected_cells = [
            1.0 / 21.0,
            2.0 / 21.0,
            3.0 / 21.0,
            4.0 / 21.0,
            5.0 / 21.0,
            6.0 / 21.0,
        ];
        let expected_mixture = [
            22.0 / 147.0,
            23.0 / 147.0,
            24.0 / 147.0,
            25.0 / 147.0,
            26.0 / 147.0,
            27.0 / 147.0,
        ];
        assert_eq!(posterior.cell_probabilities.len(), 1);
        for (probability, expected) in posterior.cell_probabilities[0].iter().zip(expected_cells) {
            assert!((probability - expected).abs() < 0.04);
        }
        for (probability, expected) in posterior.probabilities.iter().zip(expected_mixture) {
            assert!((probability - expected).abs() < 0.006);
        }
        for probability in posterior.chain_probabilities {
            assert!(probability.iter().all(|value| value.is_finite()));
            assert!((probability.iter().sum::<f64>() - 1.0).abs() < 1e-14);
        }
    }
}
