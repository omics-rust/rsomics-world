mod sampler;

use super::moments::{self, Sum};
use super::{
    Calibration, CnvRegion, CnvState, CreatedInput, HmmConfig, HmmGroup, HmmPredictions,
    HmmSamples, PreprocessConfig, SamplesConfig, invalid, reserved,
};
use crate::cnv::parallel;
use rsomics_common::Result;
use std::mem::size_of;

#[derive(Clone, Copy, Debug)]
pub struct BayesConfig {
    max_normal_probability: f64,
    seed: u32,
    threads: usize,
    max_numeric_bytes: usize,
}

impl BayesConfig {
    pub fn new(
        max_normal_probability: f64,
        seed: u32,
        threads: usize,
        max_numeric_bytes: usize,
    ) -> Result<Self> {
        if !max_normal_probability.is_finite() || !(0.0..=1.0).contains(&max_normal_probability) {
            return Err(invalid(
                "Bayesian maximum normal probability must be between zero and one",
            ));
        }
        if threads == 0 || max_numeric_bytes == 0 {
            return Err(invalid(
                "Bayesian workers and numerical workspace budget must be positive",
            ));
        }
        Ok(Self {
            max_normal_probability,
            seed,
            threads,
            max_numeric_bytes,
        })
    }
}

#[derive(Debug)]
pub struct BayesianPredictions {
    pub applied: bool,
    pub sampling: BayesSampling,
    pub groups: Vec<HmmGroup>,
    pub regions: Vec<RegionPosterior>,
}

#[derive(Clone, Copy, Debug)]
pub struct BayesSampling {
    pub chains: usize,
    pub burn_in: usize,
    pub samples_per_chain: usize,
}

impl Default for BayesSampling {
    fn default() -> Self {
        Self {
            chains: sampler::CHAINS,
            burn_in: sampler::BURN_IN,
            samples_per_chain: sampler::SAMPLES,
        }
    }
}

#[derive(Debug)]
pub struct BayesianSamples {
    pub hmm: HmmSamples,
    pub bayesian: BayesianPredictions,
}

/// Returns original grouped-i6 predictions alongside Bayesian-filtered states and regions.
pub fn hmm_samples_with_bayes(
    input: &CreatedInput,
    preprocess: &PreprocessConfig,
    samples: &SamplesConfig,
    hmm_config: &HmmConfig,
    config: &BayesConfig,
) -> Result<BayesianSamples> {
    let hmm = super::hmm_samples(input, preprocess, samples, hmm_config)?;
    let bayesian = run(&hmm.state, &hmm.predictions, config)?;
    Ok(BayesianSamples { hmm, bayesian })
}

#[derive(Debug)]
pub struct RegionPosterior {
    pub group_index: usize,
    pub region_index: usize,
    pub probabilities: [f64; 6],
    pub cell_probabilities: Vec<[f64; 6]>,
    pub chain_probabilities: [[f64; 6]; 6],
    pub removed: bool,
    pub final_state: u8,
}

struct Likelihood {
    means: [f64; 6],
    log_sds: [f64; 6],
    precisions: [f64; 6],
}

impl Likelihood {
    fn new(calibration: &Calibration) -> Result<Self> {
        if calibration.means.iter().any(|mean| !mean.is_finite())
            || calibration
                .standard_deviations
                .iter()
                .any(|sd| !sd.is_finite() || *sd <= 0.0)
        {
            return Err(invalid(
                "Bayesian calibration needs finite means and positive raw spike SDs",
            ));
        }
        let precisions = calibration.standard_deviations.map(|sd| 1.0 / (sd * sd));
        if precisions
            .iter()
            .any(|value| !value.is_finite() || *value <= 0.0)
        {
            return Err(invalid("Bayesian raw spike precision is nonfinite or zero"));
        }
        Ok(Self {
            means: calibration.means,
            log_sds: calibration.standard_deviations.map(f64::ln),
            precisions,
        })
    }

    fn cell(&self, values: &[f64]) -> Result<[f64; 6]> {
        let mean = moments::mean(values.iter().copied(), values.len())?;
        let mut squares = Sum::default();
        for value in values {
            squares.add((value - mean).powi(2));
        }
        let sum = squares.finish();
        let count = values.len() as f64;
        let likelihoods = std::array::from_fn(|state| {
            -count * self.log_sds[state]
                - 0.5 * self.precisions[state] * (sum + count * (mean - self.means[state]).powi(2))
        });
        if likelihoods.iter().any(|value| !value.is_finite()) {
            return Err(invalid("Bayesian normal log likelihood is nonfinite"));
        }
        Ok(likelihoods)
    }
}

fn workspace(input: &HmmPredictions, config: &BayesConfig, active: bool) -> Result<usize> {
    let overflow = || invalid("Bayesian numerical workspace size overflows");
    let mut regions = 0usize;
    let mut cells = 0usize;
    let mut largest_group = 0;
    let mut clones = 0usize;
    for group in &input.groups {
        regions = regions
            .checked_add(group.regions.len())
            .ok_or_else(overflow)?;
        let count = group
            .regions
            .len()
            .checked_mul(group.member_indices.len())
            .ok_or_else(overflow)?;
        cells = cells.checked_add(count).ok_or_else(overflow)?;
        if !group.regions.is_empty() {
            largest_group = largest_group.max(group.member_indices.len());
        }
        clones = clones
            .checked_add(group.states.len())
            .and_then(|n| {
                group
                    .member_indices
                    .len()
                    .checked_mul(size_of::<usize>())
                    .and_then(|m| n.checked_add(m))
            })
            .and_then(|n| {
                group
                    .regions
                    .len()
                    .checked_mul(size_of::<CnvRegion>())
                    .and_then(|m| n.checked_add(m))
            })
            .ok_or_else(overflow)?;
    }
    let required = if active {
        regions
            .checked_mul(size_of::<RegionPosterior>())
            .and_then(|n| {
                cells
                    .checked_mul(size_of::<[f64; 6]>())
                    .and_then(|m| n.checked_add(m))
            })
            .and_then(|n| {
                largest_group
                    .checked_mul(128)
                    .and_then(|m| m.checked_mul(config.threads.min(regions)))
                    .and_then(|m| n.checked_add(m))
            })
            .and_then(|n| n.checked_add(clones))
            .ok_or_else(overflow)?
    } else {
        clones
    };
    if required > config.max_numeric_bytes {
        return Err(invalid(
            "Bayesian operation exceeds the numerical workspace budget",
        ));
    }
    Ok(regions)
}

fn copy_groups(input: &[HmmGroup]) -> Result<Vec<HmmGroup>> {
    let mut output = reserved(input.len())?;
    for group in input {
        let mut states = reserved(group.states.len())?;
        states.extend_from_slice(&group.states);
        let mut members = reserved(group.member_indices.len())?;
        members.extend_from_slice(&group.member_indices);
        let mut regions = reserved(group.regions.len())?;
        for region in &group.regions {
            regions.push(CnvRegion {
                name: region.name.clone(),
                state: region.state,
                chromosome: region.chromosome.clone(),
                start: region.start,
                end: region.end,
                gene_start: region.gene_start,
                gene_end: region.gene_end,
            });
        }
        output.push(HmmGroup {
            name: group.name.clone(),
            member_indices: members,
            states,
            regions,
        });
    }
    Ok(output)
}

pub(super) fn run(
    state: &CnvState,
    input: &HmmPredictions,
    config: &BayesConfig,
) -> Result<BayesianPredictions> {
    let mut states = input.groups.iter().flat_map(|group| &group.states);
    let multiple_states = states
        .next()
        .is_some_and(|first| states.any(|state| state != first));
    let active = config.max_normal_probability > 0.0 && multiple_states;
    let count = workspace(input, config, active)?;
    if count == 0 || !active {
        return Ok(BayesianPredictions {
            applied: false,
            sampling: BayesSampling::default(),
            groups: copy_groups(&input.groups)?,
            regions: Vec::new(),
        });
    }
    let model = Likelihood::new(&input.calibration)?;
    let mut posteriors = reserved(count)?;
    for (group_index, group) in input.groups.iter().enumerate() {
        for region_index in 0..group.regions.len() {
            posteriors.push(RegionPosterior {
                group_index,
                region_index,
                probabilities: [0.0; 6],
                cell_probabilities: Vec::new(),
                chain_probabilities: [[0.0; 6]; 6],
                removed: false,
                final_state: 3,
            });
        }
    }
    let chunk = count.div_ceil(config.threads.min(count));
    parallel::for_chunks(&mut posteriors, chunk, |part, output| {
        for (offset, posterior) in output.iter_mut().enumerate() {
            let group = &input.groups[posterior.group_index];
            let region = &group.regions[posterior.region_index];
            let mut likelihoods = reserved(group.member_indices.len())?;
            for cell in &group.member_indices {
                let start = cell * state.gene_count() + region.gene_start;
                let end = cell * state.gene_count() + region.gene_end;
                likelihoods.push(model.cell(&state.values()[start..end])?);
            }
            let sampled = sampler::sample(
                &likelihoods,
                sampler::stream_seed(config.seed, part * chunk + offset),
            )?;
            posterior.probabilities = sampled.probabilities;
            posterior.cell_probabilities = sampled.cell_probabilities;
            posterior.chain_probabilities = sampled.chain_probabilities;
            posterior.removed = posterior.probabilities[2] > config.max_normal_probability;
            if !posterior.removed {
                let mut maximum = 0;
                for candidate in 1..6 {
                    if posterior.probabilities[candidate] > posterior.probabilities[maximum] {
                        maximum = candidate;
                    }
                }
                posterior.final_state = maximum as u8 + 1;
            }
        }
        Ok(())
    })?;
    let mut groups = copy_groups(&input.groups)?;
    for posterior in &posteriors {
        let group = &mut groups[posterior.group_index];
        let region = &mut group.regions[posterior.region_index];
        group.states[region.gene_start..region.gene_end].fill(posterior.final_state);
        region.state = posterior.final_state;
    }
    let mut index = 0;
    for group in &mut groups {
        group.regions.retain(|_| {
            let keep = !posteriors[index].removed;
            index += 1;
            keep
        });
    }
    Ok(BayesianPredictions {
        applied: true,
        sampling: BayesSampling::default(),
        groups,
        regions: posteriors,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cnv::{Cell, Gene};

    fn fixture() -> (CnvState, HmmPredictions) {
        let state = CnvState {
            genes: (0..4)
                .map(|i| Gene {
                    id: format!("g{i}"),
                    chromosome: "chr1".into(),
                    start: i + 1,
                    end: i + 1,
                })
                .collect(),
            cells: (0..11)
                .map(|i| Cell {
                    id: format!("c{i}"),
                    group: "input".into(),
                })
                .collect(),
            values: vec![1.0; 44],
        };
        let predictions = HmmPredictions {
            calibration: super::super::Calibration {
                means: [0.01, 0.5, 1.0, 1.5, 2.0, 3.0],
                standard_deviations: [0.01; 6],
                log_sd_fits: [[0.0; 2]; 6],
                simulated_genes: 4400,
                simulated_cells: 200,
            },
            groups: vec![
                HmmGroup {
                    name: "four".into(),
                    member_indices: (0..4).collect(),
                    states: vec![2, 2, 3, 3],
                    regions: vec![CnvRegion {
                        name: "chr1-region_1".into(),
                        state: 2,
                        chromosome: "chr1".into(),
                        start: 1,
                        end: 2,
                        gene_start: 0,
                        gene_end: 2,
                    }],
                },
                HmmGroup {
                    name: "seven".into(),
                    member_indices: (4..11).collect(),
                    states: vec![3, 3, 2, 2],
                    regions: vec![CnvRegion {
                        name: "chr1-region_3".into(),
                        state: 2,
                        chromosome: "chr1".into(),
                        start: 3,
                        end: 4,
                        gene_start: 2,
                        gene_end: 4,
                    }],
                },
            ],
        };
        (state, predictions)
    }

    #[test]
    fn posterior_filter_preserves_original_ids_and_retained_neutral_maxima() {
        let (state, predictions) = fixture();
        let result = run(
            &state,
            &predictions,
            &BayesConfig::new(0.5, 19, 4, 1_048_576).unwrap(),
        )
        .unwrap();
        assert!(result.applied);
        assert_eq!(result.regions[0].probabilities[2], 0.5);
        assert!(!result.regions[0].removed);
        assert_eq!(result.regions[0].final_state, 3);
        assert_eq!(result.groups[0].regions[0].name, "chr1-region_1");
        assert_eq!(result.groups[0].regions[0].state, 3);
        assert_eq!(result.groups[0].states, [3, 3, 3, 3]);
        assert_eq!(result.regions[1].probabilities[2], 8.0 / 13.0);
        assert!(result.regions[1].removed);
        assert!(result.groups[1].regions.is_empty());
        assert_eq!(result.groups[1].states, [3, 3, 3, 3]);
        assert_eq!(predictions.groups[0].states, [2, 2, 3, 3]);
        assert_eq!(predictions.groups[1].regions[0].name, "chr1-region_3");
        assert_eq!(state.values(), &[1.0; 44]);
    }

    #[test]
    fn disabled_or_empty_bayesian_work_keeps_existing_predictions() {
        let (state, mut predictions) = fixture();
        let disabled = run(
            &state,
            &predictions,
            &BayesConfig::new(0.0, 19, 1, 1_048_576).unwrap(),
        )
        .unwrap();
        assert!(!disabled.applied);
        assert!(disabled.regions.is_empty());
        assert_eq!(disabled.groups[0].states, predictions.groups[0].states);
        for group in &mut predictions.groups {
            group.states.fill(3);
            group.regions.clear();
        }
        let empty = run(
            &state,
            &predictions,
            &BayesConfig::new(0.5, 19, 1, 1_048_576).unwrap(),
        )
        .unwrap();
        assert!(!empty.applied);
        assert!(empty.regions.is_empty());
        assert!(
            empty
                .groups
                .iter()
                .all(|group| group.states == [3, 3, 3, 3])
        );
    }

    #[test]
    fn only_a_globally_single_state_bypasses_bayesian_refinement() {
        let (state, mut predictions) = fixture();
        for (index, group) in predictions.groups.iter_mut().enumerate() {
            group.states.fill(2);
            let region = &mut group.regions[0];
            region.name = format!("chr1-region_{}", index + 1);
            region.state = 2;
            region.start = 1;
            region.end = 4;
            region.gene_start = 0;
            region.gene_end = 4;
        }
        let config = BayesConfig::new(0.5, 19, 4, 1_048_576).unwrap();
        let skipped = run(&state, &predictions, &config).unwrap();
        assert!(!skipped.applied);
        assert!(skipped.regions.is_empty());
        assert!(skipped.groups.iter().all(|group| group.states == [2; 4]));
        assert_eq!(skipped.groups[1].regions[0].name, "chr1-region_2");
        predictions.groups[1].states.fill(4);
        predictions.groups[1].regions[0].state = 4;
        let distinct = run(&state, &predictions, &config).unwrap();
        assert!(distinct.applied);
        assert_eq!(distinct.regions.len(), 2);
    }
}
