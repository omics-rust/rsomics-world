#include <algorithm>
#include <cerrno>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <fcntl.h>
#include <limits>
#include <new>
#include <queue>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <type_traits>
#include <unistd.h>
#include <vector>

static void* rsomics_annoy_realloc(void* pointer, std::size_t bytes) {
    void* result = std::realloc(pointer, bytes);
    if (result == nullptr && bytes != 0) {
        throw std::bad_alloc();
    }
    return result;
}

// The pristine header dereferences realloc's result without checking allocation failure.
#define realloc(pointer, bytes) rsomics_annoy_realloc(pointer, bytes)
#include "annoylib.h"
#undef realloc
#include "kissrandom.h"

static int fail(char* error, std::size_t capacity, const char* message) noexcept {
    if (capacity != 0) {
        std::snprintf(error, capacity, "%s", message);
    }
    return 1;
}

extern "C" int rsomics_annoy_knn(
    const double* scores,
    std::int32_t cells,
    std::int32_t dims,
    std::int32_t k,
    std::int32_t* neighbors,
    char* error,
    std::size_t error_capacity
) noexcept {
    try {
        using Index = Annoy::AnnoyIndex<std::int32_t, float, Annoy::Euclidean,
            Kiss64Random, Annoy::AnnoyIndexSingleThreadedBuildPolicy>;
        const auto count = static_cast<std::size_t>(cells) * static_cast<std::size_t>(dims);
        std::vector<float> values(count);
        for (std::size_t i = 0; i < count; ++i) {
            values[i] = static_cast<float>(scores[i]);
            if (!std::isfinite(values[i])) {
                return fail(error, error_capacity, "PCA scores must be finite float32 values");
            }
        }
        Index index(dims);
        for (std::int32_t cell = 0; cell < cells; ++cell) {
            if (!index.add_item(cell, values.data() + static_cast<std::size_t>(cell) * dims)) {
                return fail(error, error_capacity, "Annoy rejected an input cell");
            }
        }
        if (!index.build(50, 1)) {
            return fail(error, error_capacity, "Annoy index build failed");
        }
        std::vector<std::int32_t> found;
        found.reserve(static_cast<std::size_t>(k));
        for (std::int32_t cell = 0; cell < cells; ++cell) {
            found.clear();
            index.get_nns_by_vector(values.data() + static_cast<std::size_t>(cell) * dims,
                static_cast<std::size_t>(k), -1, &found, nullptr);
            if (found.size() != static_cast<std::size_t>(k)) {
                return fail(error, error_capacity, "Annoy returned fewer neighbors than requested");
            }
            std::copy(found.begin(), found.end(), neighbors + static_cast<std::size_t>(cell) * k);
        }
        return 0;
    } catch (const std::bad_alloc&) {
        return fail(error, error_capacity, "Annoy workspace allocation failed");
    } catch (const std::exception& exception) {
        return fail(error, error_capacity, exception.what());
    } catch (...) {
        return fail(error, error_capacity, "Unknown exception while constructing Annoy neighborhoods");
    }
}
