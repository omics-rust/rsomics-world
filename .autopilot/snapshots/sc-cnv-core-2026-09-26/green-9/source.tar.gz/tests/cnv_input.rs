use flate2::{Compression, write::GzEncoder};
use rsomics_sc::cnv::{CreatedInput, CreationConfig, InputPaths, create_input};
use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};

static NEXT_FIXTURE: AtomicUsize = AtomicUsize::new(0);

#[test]
fn literal_v1_annotation_is_a_cell_not_an_inferred_header() {
    let fixture = Fixture::new(
        b"gene\tV1\tc\ng\t2\t3\n",
        b"g\tchr1\t1\t2\n",
        b"V1\tliteral\nc\tother\n",
    );
    let created = fixture.create(&config()).unwrap();
    assert_eq!(created.prepared_counts().state().cell_count(), 2);
    assert_eq!(created.prepared_counts().state().cells()[0].id, "V1");
    assert_eq!(created.prepared_counts().state().values(), [2.0, 3.0]);
    assert_eq!(created.observation_groups()[0].name(), "literal");
    assert_eq!(created.observation_groups()[0].cell_indices(), [0]);
}

#[test]
fn unknown_first_v1_annotation_is_not_silently_discarded() {
    let fixture = Fixture::new(
        b"gene\tc\ng\t3\n",
        b"g\tchr1\t1\t2\n",
        b"V1\tliteral\nc\tother\n",
    );
    assert_context(
        fixture.create(&config()).unwrap_err(),
        &fixture.annotations,
        1,
    );
}

struct Fixture {
    root: PathBuf,
    counts: PathBuf,
    positions: PathBuf,
    annotations: PathBuf,
}

impl Fixture {
    fn new(counts: &[u8], positions: &[u8], annotations: &[u8]) -> Self {
        let root = std::env::temp_dir().join(format!(
            "rsomics-cnv-input-{}-{}",
            std::process::id(),
            NEXT_FIXTURE.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir(&root).unwrap();
        let fixture = Self {
            counts: root.join("counts.tsv"),
            positions: root.join("positions.tsv"),
            annotations: root.join("annotations.tsv"),
            root,
        };
        fs::write(&fixture.counts, counts).unwrap();
        fs::write(&fixture.positions, positions).unwrap();
        fs::write(&fixture.annotations, annotations).unwrap();
        fixture
    }

    fn create(&self, config: &CreationConfig) -> rsomics_common::Result<CreatedInput> {
        create_input(
            InputPaths {
                counts: &self.counts,
                positions: &self.positions,
                annotations: &self.annotations,
            },
            config,
        )
    }
}

impl Drop for Fixture {
    fn drop(&mut self) {
        fs::remove_dir_all(&self.root).unwrap();
    }
}

fn config() -> CreationConfig {
    CreationConfig {
        reference_groups: vec![],
        excluded_chromosomes: vec![],
        min_counts_per_cell: 1.0,
        max_counts_per_cell: f64::INFINITY,
        max_numeric_bytes: 1 << 20,
        max_record_bytes: 4096,
    }
}

fn minimal() -> Fixture {
    Fixture::new(b"gene\tc\ng\t1\n", b"g\tchr1\t1\t2\n", b"c\tgroup\n")
}

fn assert_context(error: impl std::fmt::Display, path: &Path, record: usize) {
    let message = error.to_string();
    assert!(message.contains(path.to_str().unwrap()), "{message}");
    assert!(message.contains(&format!("record {record}")), "{message}");
}

#[test]
fn stable_ties_use_expression_order_and_position_only_genes_set_chromosome_rank() {
    let fixture = Fixture::new(
        b"gene\tb\ta\nz\t1\t2\na\t3\t4\nx\t5\t6\n",
        b"absent\tchr2\t1\t2\na\tchr1\t10\t20\nx\tchr2\t3\t4\nz\tchr1\t10\t20\n",
        b"a\tA\nb\tZ\n",
    );
    let created = fixture.create(&config()).unwrap();
    let state = created.prepared_counts().state();
    assert_eq!(
        state
            .genes()
            .iter()
            .map(|g| g.id.as_str())
            .collect::<Vec<_>>(),
        ["x", "z", "a"]
    );
    assert_eq!(state.values(), [5.0, 1.0, 3.0, 6.0, 2.0, 4.0]);
    assert_eq!(
        state
            .cells()
            .iter()
            .map(|c| c.id.as_str())
            .collect::<Vec<_>>(),
        ["b", "a"]
    );
    assert_eq!(created.observation_groups()[0].name(), "A");
    assert_eq!(created.observation_groups()[0].cell_indices(), [1]);
    assert_eq!(created.observation_groups()[1].name(), "Z");
    assert_eq!(created.observation_groups()[1].cell_indices(), [0]);
}

#[test]
fn references_follow_requested_order_and_observations_are_bytewise_sorted() {
    let fixture = Fixture::new(
        b"gene\tc0\tc1\tc2\tc3\tc4\ng\t1\t2\t3\t4\t5\n",
        b"g\tchr1\t1\t2\n",
        "c4\té\nc3\ta\nc2\tZ\nc1\tref1\nc0\tref2\n".as_bytes(),
    );
    let mut candidate = config();
    candidate.reference_groups = vec!["ref1".into(), "ref2".into()];
    let created = fixture.create(&candidate).unwrap();
    assert_eq!(created.reference_groups()[0].name(), "ref1");
    assert_eq!(created.reference_groups()[0].cell_indices(), [1]);
    assert_eq!(created.reference_groups()[1].name(), "ref2");
    assert_eq!(created.reference_groups()[1].cell_indices(), [0]);
    assert_eq!(
        created
            .observation_groups()
            .iter()
            .map(|g| g.name())
            .collect::<Vec<_>>(),
        ["Z", "a", "é"]
    );
    let pointer = created.prepared_counts().state().values().as_ptr();
    assert_eq!(
        created.into_prepared_counts().state().values().as_ptr(),
        pointer
    );
}

#[test]
fn count_limits_are_inclusive_after_gene_reduction_and_unannotated_cells_are_removed() {
    let fixture = Fixture::new(
        b"gene\tlow\tmin\tmax\thigh\tother\ng\t1\t2\t3\t4\t2\ndrop\t100\t100\t100\t100\t100\n",
        b"g\tchr1\t1\t2\n",
        b"low\tN\nmin\tN\nmax\tT\nhigh\tT\n",
    );
    let mut candidate = config();
    candidate.min_counts_per_cell = 2.0;
    candidate.max_counts_per_cell = 3.0;
    let created = fixture.create(&candidate).unwrap();
    assert_eq!(created.prepared_counts().state().values(), [2.0, 3.0]);
    assert_eq!(created.prepared_counts().state().cells()[0].id, "min");
    assert_eq!(created.prepared_counts().state().cells()[1].id, "max");
    assert!(created.reference_groups().is_empty());
}

#[test]
fn excluded_chromosomes_and_zero_positions_do_not_establish_rank_or_depth() {
    let fixture = Fixture::new(
        b"gene\tc\nx\t100\nz\t100\nb\t2\na\t3\n",
        b"x\tchrX\t1\t2\nz\tchrA\t0\t0\nb\tchrB\t1\t2\na\tchrA\t1\t2\n",
        b"c\tG\n",
    );
    let mut candidate = config();
    candidate.excluded_chromosomes = vec!["chrX".into()];
    candidate.max_counts_per_cell = 5.0;
    let created = fixture.create(&candidate).unwrap();
    assert_eq!(created.prepared_counts().state().genes()[0].id, "b");
    assert_eq!(created.prepared_counts().state().values(), [2.0, 3.0]);
}

#[test]
fn minimum_depth_is_clamped_to_one() {
    let fixture = Fixture::new(
        b"gene\tzero\thalf\tone\ng\t0\t0.5\t1\n",
        b"g\tchr1\t1\t2\n",
        b"zero\tG\nhalf\tG\none\tG\n",
    );
    let mut candidate = config();
    candidate.min_counts_per_cell = 0.0;
    let created = fixture.create(&candidate).unwrap();
    assert_eq!(created.prepared_counts().state().cells()[0].id, "one");
    assert_eq!(created.prepared_counts().state().cell_count(), 1);
}

#[test]
fn unknown_annotations_fail_against_original_header_before_filtering() {
    let fixture = Fixture::new(b"gene\tc\ng\t0\n", b"g\tchr1\t1\t2\n", b"missing\tG\n");
    assert_context(
        fixture.create(&config()).unwrap_err(),
        &fixture.annotations,
        1,
    );
}

#[test]
fn requested_reference_groups_cannot_silently_disappear() {
    for references in [vec!["absent".into()], vec!["G".into()]] {
        let fixture = Fixture::new(
            b"gene\tc\td\ng\t0\t1\n",
            b"g\tchr1\t1\t2\n",
            b"c\tG\nd\tT\n",
        );
        let mut candidate = config();
        candidate.reference_groups = references;
        assert!(fixture.create(&candidate).is_err());
    }
}

#[test]
fn malformed_discarded_counts_are_not_skipped() {
    for value in ["NaN", "inf", "-1", "bad", "", " 1", "1 "] {
        let counts = format!("gene\tc\ng\t1\nnot_joined\t{value}\n");
        let fixture = Fixture::new(counts.as_bytes(), b"g\tchr1\t1\t2\n", b"c\tG\n");
        assert_context(fixture.create(&config()).unwrap_err(), &fixture.counts, 3);
    }
}

#[test]
fn invalid_excluded_positions_are_not_skipped() {
    for row in [
        "x\tchrX\t3\t2",
        "x\tchrX\t-1\t2",
        "x\tchrX\t1\t",
        "x\tchrX\t1\t2\textra",
    ] {
        let positions = format!("g\tchr1\t1\t2\n{row}\n");
        let fixture = Fixture::new(b"gene\tc\ng\t1\n", positions.as_bytes(), b"c\tG\n");
        let mut candidate = config();
        candidate.excluded_chromosomes = vec!["chrX".into()];
        assert_context(
            fixture.create(&candidate).unwrap_err(),
            &fixture.positions,
            2,
        );
    }
}

#[test]
fn duplicate_ids_and_empty_fields_fail_with_record_context() {
    for counts in [
        b"gene\tc\tc\ng\t1\t1\n".as_slice(),
        b"gene\t\ng\t1\n".as_slice(),
        b"\tc\ng\t1\n".as_slice(),
        b"gene\tc\ng\t1\ng\t2\n".as_slice(),
        b"gene\tc\n\t1\n".as_slice(),
        b"gene\tc\ng\t1\textra\n".as_slice(),
    ] {
        let fixture = Fixture::new(counts, b"g\tchr1\t1\t2\n", b"c\tG\n");
        let error = fixture.create(&config()).unwrap_err().to_string();
        assert!(error.contains(fixture.counts.to_str().unwrap()));
        assert!(error.contains("record "));
    }
    let fixture = Fixture::new(
        b"gene\tc\ng\t1\n",
        b"g\tchr1\t1\t2\ng\tchrX\t0\t0\n",
        b"c\tG\n",
    );
    assert_context(
        fixture.create(&config()).unwrap_err(),
        &fixture.positions,
        2,
    );
    for annotations in [
        b"c\tG\nc\tT\n".as_slice(),
        b"c\t\n".as_slice(),
        b"c\tG\textra\n".as_slice(),
    ] {
        let fixture = Fixture::new(b"gene\tc\ng\t1\n", b"g\tchr1\t1\t2\n", annotations);
        assert!(fixture.create(&config()).is_err());
    }
}

#[test]
fn strict_utf8_and_blank_records_are_rejected() {
    for counts in [
        b"gene\tc\ng\t1\n\n".as_slice(),
        b"gene\tc\n\xff\t1\n".as_slice(),
    ] {
        let fixture = Fixture::new(counts, b"g\tchr1\t1\t2\n", b"c\tG\n");
        assert!(fixture.create(&config()).is_err());
    }
}

#[test]
fn crlf_and_unterminated_final_records_preserve_identifiers() {
    let fixture = Fixture::new(b"gene\tc\r\ng\t1", b"g\tchr1\t1\t2\r\n", b"c\tG");
    assert_eq!(
        fixture
            .create(&config())
            .unwrap()
            .prepared_counts()
            .state()
            .values(),
        [1.0]
    );
}

#[test]
fn totals_are_compensated_in_genomic_order() {
    let fixture = Fixture::new(
        b"gene\tc\nsmall1\t1\nbig\t9007199254740992\nsmall2\t1\n",
        b"big\tchr1\t1\t1\nsmall1\tchr1\t2\t2\nsmall2\tchr1\t3\t3\n",
        b"c\tG\n",
    );
    let mut candidate = config();
    candidate.min_counts_per_cell = 9007199254740994.0;
    candidate.max_counts_per_cell = 9007199254740994.0;
    let created = fixture.create(&candidate).unwrap();
    assert_eq!(
        created.prepared_counts().state().values(),
        [9007199254740992.0, 1.0, 1.0]
    );
}

#[test]
fn decimal_values_use_native_binary64_parsing() {
    let fixture = Fixture::new(
        b"gene\tc\ng\t0.076439\nh\t1\n",
        b"g\tchr1\t1\t1\nh\tchr1\t2\t2\n",
        b"c\tG\n",
    );
    let created = fixture.create(&config()).unwrap();
    assert_eq!(
        created.prepared_counts().state().values()[0].to_bits(),
        0x3fb3_9181_9d23_91d5
    );
}

#[test]
fn overlapping_numeric_workspace_has_a_checked_exact_boundary() {
    let fixture = minimal();
    let mut candidate = config();
    candidate.max_numeric_bytes = 31;
    assert!(fixture.create(&candidate).is_err());
    candidate.max_numeric_bytes = 32;
    assert!(fixture.create(&candidate).is_ok());
}

#[test]
fn unjoined_rows_do_not_consume_numeric_workspace() {
    let fixture = Fixture::new(
        b"gene\tc\ng\t1\na\t3\nb\t4\n",
        b"g\tchr1\t1\t2\n",
        b"c\tG\n",
    );
    let mut candidate = config();
    candidate.max_numeric_bytes = 32;
    assert!(fixture.create(&candidate).is_ok());
}

#[test]
fn record_limits_apply_independently_to_each_decoded_input() {
    for (counts, positions, annotations, failing_file, record) in [
        (
            "gene\tc\nlonggene\t1\n",
            "g\tC\t1\t2\n",
            "c\tG\n",
            "counts.tsv",
            2,
        ),
        (
            "gene\tc\ng\t1\n",
            "g\tlongchromosome\t1\t2\n",
            "c\tG\n",
            "positions.tsv",
            1,
        ),
        (
            "gene\tc\ng\t1\n",
            "g\tC\t1\t2\n",
            "c\tlonggroup\n",
            "annotations.tsv",
            1,
        ),
    ] {
        let fixture = Fixture::new(
            counts.as_bytes(),
            positions.as_bytes(),
            annotations.as_bytes(),
        );
        let mut candidate = config();
        candidate.max_record_bytes = 8;
        assert_context(
            fixture.create(&candidate).unwrap_err(),
            &fixture.root.join(failing_file),
            record,
        );
    }
    let fixture = minimal();
    let mut candidate = config();
    candidate.max_record_bytes = 11;
    assert!(fixture.create(&candidate).is_ok());
}

#[test]
fn gzip_counts_reach_eof_and_detect_truncation_checksum_and_trailing_garbage() {
    let bytes = [
        31, 139, 8, 0, 0, 0, 0, 0, 2, 255, 75, 79, 205, 75, 229, 76, 230, 74, 231, 52, 228, 2, 0,
        149, 51, 236, 247, 11, 0, 0, 0,
    ];
    let mut fixture = minimal();
    fixture.counts = fixture.root.join("counts.tsv.gz");
    fs::write(&fixture.counts, bytes).unwrap();
    assert!(fixture.create(&config()).is_ok());
    for corrupted in [
        bytes[..bytes.len() - 3].to_vec(),
        {
            let mut data = bytes.to_vec();
            data[23] ^= 1;
            data
        },
        {
            let mut data = bytes.to_vec();
            data.push(0xff);
            data
        },
    ] {
        fs::write(&fixture.counts, corrupted).unwrap();
        let message = fixture.create(&config()).unwrap_err().to_string();
        assert!(message.contains(fixture.counts.to_str().unwrap()));
        assert!(message.contains("record "));
    }
    let mut candidate = config();
    candidate.max_record_bytes = 8;
    fs::write(&fixture.positions, b"g\tC\t1\t2\n").unwrap();
    let mut encoder = GzEncoder::new(Vec::new(), Compression::fast());
    encoder.write_all(b"gene\tc\nlonggene\t1\n").unwrap();
    fs::write(&fixture.counts, encoder.finish().unwrap()).unwrap();
    assert_context(fixture.create(&candidate).unwrap_err(), &fixture.counts, 2);
}

#[test]
fn invalid_configuration_fails_before_opening_paths() {
    let fixture = minimal();
    for references in [vec!["".into()], vec!["G".into(), "G".into()]] {
        let mut candidate = config();
        candidate.reference_groups = references;
        assert!(fixture.create(&candidate).is_err());
    }
    for minimum in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
        let mut candidate = config();
        candidate.min_counts_per_cell = minimum;
        assert!(fixture.create(&candidate).is_err());
    }
    for maximum in [f64::NAN, f64::NEG_INFINITY, 0.5] {
        let mut candidate = config();
        candidate.max_counts_per_cell = maximum;
        assert!(fixture.create(&candidate).is_err());
    }
    for (numeric, record) in [(0, 4096), (4096, 0)] {
        let mut candidate = config();
        candidate.max_numeric_bytes = numeric;
        candidate.max_record_bytes = record;
        assert!(fixture.create(&candidate).is_err());
    }
}

#[test]
fn empty_reduction_empty_annotation_and_nonfinite_total_fail_loudly() {
    for (counts, positions, annotations) in [
        ("gene\tc\ng\t1\n", "other\tchr1\t1\t2\n", "c\tG\n"),
        ("gene\tc\ng\t1\n", "g\tchr1\t1\t2\n", ""),
        (
            "gene\tc\ng\t1.7976931348623157e308\nh\t1.7976931348623157e308\n",
            "g\tchr1\t1\t1\nh\tchr1\t2\t2\n",
            "c\tG\n",
        ),
    ] {
        let fixture = Fixture::new(
            counts.as_bytes(),
            positions.as_bytes(),
            annotations.as_bytes(),
        );
        assert!(fixture.create(&config()).is_err());
    }
}

#[test]
fn gzip_positions_and_annotations_decode_fully_and_detect_corrupt_eof() {
    let positions = [
        31, 139, 8, 0, 0, 0, 0, 0, 2, 255, 75, 231, 76, 206, 40, 50, 228, 52, 228, 52, 226, 2, 0,
        173, 113, 191, 123, 11, 0, 0, 0,
    ];
    let annotations = [
        31, 139, 8, 0, 0, 0, 0, 0, 2, 255, 75, 230, 76, 47, 202, 47, 45, 224, 2, 0, 169, 108, 168,
        198, 8, 0, 0, 0,
    ];
    let mut fixture = minimal();
    fixture.positions = fixture.root.join("positions.tsv.gz");
    fixture.annotations = fixture.root.join("annotations.tsv.gz");
    fs::write(&fixture.positions, positions).unwrap();
    fs::write(&fixture.annotations, annotations).unwrap();
    assert!(fixture.create(&config()).is_ok());
    fs::write(&fixture.positions, &positions[..positions.len() - 1]).unwrap();
    let error = fixture.create(&config()).unwrap_err().to_string();
    assert!(error.contains(fixture.positions.to_str().unwrap()));
    assert!(error.contains("record "));
    fs::write(&fixture.positions, positions).unwrap();
    let mut corrupted = annotations;
    corrupted[20] ^= 1;
    fs::write(&fixture.annotations, corrupted).unwrap();
    let error = fixture.create(&config()).unwrap_err().to_string();
    assert!(error.contains(fixture.annotations.to_str().unwrap()));
    assert!(error.contains("record "));
}

#[test]
fn numeric_peak_charges_original_columns_and_only_retained_output_columns() {
    let fixture = Fixture::new(
        b"gene\tc\tunannotated\ng\t1\t2\n",
        b"g\tchr1\t1\t2\n",
        b"c\tG\n",
    );
    let mut candidate = config();
    candidate.max_numeric_bytes = 55;
    assert!(fixture.create(&candidate).is_err());
    candidate.max_numeric_bytes = 56;
    assert!(fixture.create(&candidate).is_ok());
}

#[test]
fn implicit_counts_header_is_not_inferred() {
    let fixture = Fixture::new(b"c\ng\t1\n", b"g\tchr1\t1\t2\n", b"c\tG\n");
    assert_context(fixture.create(&config()).unwrap_err(), &fixture.counts, 1);
}

#[test]
fn missing_input_paths_report_the_exact_file_and_first_record() {
    let mut fixture = minimal();
    for input in ["counts", "positions", "annotations"] {
        let old_counts = fixture.counts.clone();
        let old_positions = fixture.positions.clone();
        let old_annotations = fixture.annotations.clone();
        let missing = fixture.root.join(format!("missing-{input}.tsv"));
        match input {
            "counts" => fixture.counts = missing.clone(),
            "positions" => fixture.positions = missing.clone(),
            _ => fixture.annotations = missing.clone(),
        }
        assert_context(fixture.create(&config()).unwrap_err(), &missing, 1);
        fixture.counts = old_counts;
        fixture.positions = old_positions;
        fixture.annotations = old_annotations;
    }
}
