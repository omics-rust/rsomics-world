use super::model::{Cell, Gene, PreparedCounts};
use flate2::bufread::MultiGzDecoder;
use rsomics_common::{Result, RsomicsError};
use std::collections::{HashMap, HashSet};
use std::fs::File;
use std::io::{self, BufRead, BufReader};
use std::path::Path;

/// Strict UTF-8 TSV inputs, each plain or gzip-compressed.
#[derive(Clone, Copy, Debug)]
pub struct InputPaths<'a> {
    pub counts: &'a Path,
    pub positions: &'a Path,
    pub annotations: &'a Path,
}

#[derive(Clone, Debug)]
pub struct CreationConfig {
    pub reference_groups: Vec<String>,
    pub excluded_chromosomes: Vec<String>,
    /// The inclusive lower depth bound is clamped to one.
    pub min_counts_per_cell: f64,
    /// Positive infinity disables the inclusive upper depth bound.
    pub max_counts_per_cell: f64,
    /// Bounds retained numerical capacities, compensated totals and final values
    /// at their overlapping peak; it does not bound metadata or process memory.
    pub max_numeric_bytes: usize,
    /// Maximum decoded record bytes, including any CR/LF terminator.
    /// This is a record limit, not a whole-input text-memory limit.
    pub max_record_bytes: usize,
}

#[derive(Debug)]
pub struct CellGroup {
    name: String,
    cell_indices: Vec<usize>,
}

impl CellGroup {
    pub fn name(&self) -> &str {
        &self.name
    }

    pub fn cell_indices(&self) -> &[usize] {
        &self.cell_indices
    }
}

#[derive(Debug)]
pub struct CreatedInput {
    prepared_counts: PreparedCounts,
    reference_groups: Vec<CellGroup>,
    observation_groups: Vec<CellGroup>,
}

impl CreatedInput {
    pub fn prepared_counts(&self) -> &PreparedCounts {
        &self.prepared_counts
    }

    pub fn reference_groups(&self) -> &[CellGroup] {
        &self.reference_groups
    }

    pub fn observation_groups(&self) -> &[CellGroup] {
        &self.observation_groups
    }

    pub fn into_prepared_counts(self) -> PreparedCounts {
        self.prepared_counts
    }
}

struct Position {
    gene: Gene,
    chromosome_rank: usize,
}

struct Row {
    position: Position,
    expression_rank: usize,
    values: Vec<f64>,
}

struct Counts {
    cell_ids: Vec<String>,
    rows: Vec<Row>,
    row_bytes: usize,
}

/// Joins genes, filters cells and returns column-major prepared counts and groups.
/// Counts use deterministic native `f64` parsing, not R's decimal parser.
/// Arbitrary fractional lexical and threshold equivalence with R is not promised.
/// Headerless annotation IDs are literal; a first `V1` row is not discarded.
pub fn create_input(paths: InputPaths<'_>, config: &CreationConfig) -> Result<CreatedInput> {
    validate_config(config)?;
    let positions = read_positions(paths.positions, config)?;
    let mut counts = read_counts(paths.counts, positions, config)?;
    let annotations = read_annotations(paths.annotations, &counts.cell_ids, config)?;
    if counts.rows.is_empty() {
        return Err(invalid_record(
            paths.counts,
            1,
            "no genes retain genomic positions",
        ));
    }
    counts.rows.sort_unstable_by_key(|row| {
        (
            row.position.chromosome_rank,
            row.position.gene.start,
            row.position.gene.end,
            row.expression_rank,
        )
    });
    let totals = cell_totals(&counts, config)?;
    let mut retained = Vec::new();
    let mut cells = Vec::new();
    for (index, id) in counts.cell_ids.iter().enumerate() {
        let (sum, correction) = totals[index];
        let total = sum + correction;
        if !total.is_finite() {
            return Err(invalid_record(
                paths.counts,
                1,
                &format!("cell {id} has a nonfinite reduced count total"),
            ));
        }
        if total >= config.min_counts_per_cell.max(1.0)
            && total <= config.max_counts_per_cell
            && let Some(group) = annotations.get(id)
        {
            reserve(&mut retained, 1)?;
            reserve(&mut cells, 1)?;
            retained.push(index);
            cells.push(Cell {
                id: owned(id)?,
                group: owned(group)?,
            });
        }
    }
    if cells.is_empty() {
        return Err(invalid_record(
            paths.annotations,
            1,
            "no annotated cells retain allowed counts",
        ));
    }
    let (reference_groups, observation_groups) = resolve_groups(&cells, config)?;
    let output_elements = counts
        .rows
        .len()
        .checked_mul(cells.len())
        .ok_or_else(budget_overflow)?;
    let total_bytes = numeric_bytes(totals.capacity(), std::mem::size_of::<(f64, f64)>())?;
    let occupied = counts
        .row_bytes
        .checked_add(total_bytes)
        .ok_or_else(budget_overflow)?;
    let mut values = allocate_numeric::<f64>(output_elements, occupied, config)?;
    for index in retained {
        for row in &counts.rows {
            values.push(row.values[index]);
        }
    }
    let mut genes = Vec::new();
    reserve(&mut genes, counts.rows.len())?;
    for row in counts.rows {
        genes.push(row.position.gene);
    }
    let prepared_counts = PreparedCounts::new(genes, cells, values)?;
    Ok(CreatedInput {
        prepared_counts,
        reference_groups,
        observation_groups,
    })
}

fn validate_config(config: &CreationConfig) -> Result<()> {
    if !config.min_counts_per_cell.is_finite()
        || config.max_counts_per_cell.is_nan()
        || config.max_counts_per_cell < config.min_counts_per_cell.max(1.0)
    {
        return Err(RsomicsError::ConfigError(
            "count limits require a finite minimum and an upper bound at least max(1, minimum)"
                .into(),
        ));
    }
    if config.max_numeric_bytes == 0 || config.max_record_bytes == 0 {
        return Err(RsomicsError::ConfigError(
            "numeric and record byte limits must be positive".into(),
        ));
    }
    let mut seen = HashSet::new();
    for name in &config.reference_groups {
        seen.try_reserve(1).map_err(allocation_error)?;
        if name.is_empty() || !seen.insert(name.as_str()) {
            return Err(RsomicsError::ConfigError(
                "reference names must be nonempty and unique".into(),
            ));
        }
    }
    Ok(())
}

fn read_positions(path: &Path, config: &CreationConfig) -> Result<HashMap<String, Position>> {
    let mut records = Records::open(path, config.max_record_bytes)?;
    let mut seen = HashSet::new();
    let mut ranks = HashMap::new();
    let mut positions = HashMap::new();
    while let Some((record, line)) = records.next()? {
        let fields = fields::<4>(line, path, record)?;
        let [id, chromosome, start, end] = fields;
        seen.try_reserve(1).map_err(allocation_error)?;
        if !seen.insert(owned(id)?) {
            return Err(invalid_record(path, record, "duplicate gene ID"));
        }
        let start = coordinate(start, path, record)?;
        let end = coordinate(end, path, record)?;
        if start > end {
            return Err(invalid_record(path, record, "gene start exceeds end"));
        }
        if config
            .excluded_chromosomes
            .iter()
            .any(|label| label == chromosome)
            || (start == 0 && end == 0)
        {
            continue;
        }
        let rank = match ranks.get(chromosome) {
            Some(&rank) => rank,
            None => {
                let rank = ranks.len();
                ranks.try_reserve(1).map_err(allocation_error)?;
                ranks.insert(owned(chromosome)?, rank);
                rank
            }
        };
        positions.try_reserve(1).map_err(allocation_error)?;
        positions.insert(
            owned(id)?,
            Position {
                gene: Gene {
                    id: owned(id)?,
                    chromosome: owned(chromosome)?,
                    start,
                    end,
                },
                chromosome_rank: rank,
            },
        );
    }
    Ok(positions)
}

fn read_counts(
    path: &Path,
    mut positions: HashMap<String, Position>,
    config: &CreationConfig,
) -> Result<Counts> {
    let mut records = Records::open(path, config.max_record_bytes)?;
    let Some((record, header)) = records.next()? else {
        return Err(invalid_record(path, 1, "missing counts header"));
    };
    let mut header_fields = header.split('\t');
    if header_fields.next().is_none_or(str::is_empty) {
        return Err(invalid_record(
            path,
            record,
            "missing explicit gene-column header",
        ));
    }
    let mut cell_ids = Vec::new();
    let mut cell_names = HashSet::new();
    for id in header_fields {
        cell_names.try_reserve(1).map_err(allocation_error)?;
        if id.is_empty() || !cell_names.insert(owned(id)?) {
            return Err(invalid_record(
                path,
                record,
                "cell IDs must be nonempty and unique",
            ));
        }
        reserve(&mut cell_ids, 1)?;
        cell_ids.push(owned(id)?);
    }
    if cell_ids.is_empty() {
        return Err(invalid_record(path, record, "counts header has no cells"));
    }
    let totals_bytes = numeric_bytes(cell_ids.len(), std::mem::size_of::<(f64, f64)>())?;
    check_budget(totals_bytes, config)?;
    let mut rows = Vec::new();
    let mut seen = HashSet::new();
    let mut row_bytes = 0usize;
    while let Some((record, line)) = records.next()? {
        let mut fields = line.split('\t');
        let id = fields
            .next()
            .ok_or_else(|| invalid_record(path, record, "missing gene ID"))?;
        seen.try_reserve(1).map_err(allocation_error)?;
        if id.is_empty() || !seen.insert(owned(id)?) {
            return Err(invalid_record(
                path,
                record,
                "gene IDs must be nonempty and unique",
            ));
        }
        let position = positions.remove(id);
        let mut values = if position.is_some() {
            allocate_numeric::<f64>(
                cell_ids.len(),
                row_bytes
                    .checked_add(totals_bytes)
                    .ok_or_else(budget_overflow)?,
                config,
            )?
        } else {
            Vec::new()
        };
        for _ in &cell_ids {
            let token = fields
                .next()
                .ok_or_else(|| invalid_record(path, record, "counts row has too few fields"))?;
            let value: f64 = token
                .parse()
                .map_err(|_| invalid_record(path, record, "invalid native f64 count"))?;
            if !value.is_finite() || value < 0.0 {
                return Err(invalid_record(
                    path,
                    record,
                    "counts must be finite and nonnegative",
                ));
            }
            if position.is_some() {
                values.push(value);
            }
        }
        if fields.next().is_some() {
            return Err(invalid_record(
                path,
                record,
                "counts row has too many fields",
            ));
        }
        if let Some(position) = position {
            row_bytes = row_bytes
                .checked_add(numeric_bytes(
                    values.capacity(),
                    std::mem::size_of::<f64>(),
                )?)
                .ok_or_else(budget_overflow)?;
            reserve(&mut rows, 1)?;
            rows.push(Row {
                position,
                expression_rank: seen.len(),
                values,
            });
        }
    }
    Ok(Counts {
        cell_ids,
        rows,
        row_bytes,
    })
}

fn read_annotations(
    path: &Path,
    cell_ids: &[String],
    config: &CreationConfig,
) -> Result<HashMap<String, String>> {
    let mut cells = HashSet::new();
    cells
        .try_reserve(cell_ids.len())
        .map_err(allocation_error)?;
    cells.extend(cell_ids.iter().map(String::as_str));
    let mut records = Records::open(path, config.max_record_bytes)?;
    let mut annotations = HashMap::new();
    while let Some((record, line)) = records.next()? {
        let [id, group] = fields::<2>(line, path, record)?;
        if !cells.contains(id) {
            return Err(invalid_record(
                path,
                record,
                &format!("annotation cell {id} is absent from original counts header"),
            ));
        }
        annotations.try_reserve(1).map_err(allocation_error)?;
        if annotations.insert(owned(id)?, owned(group)?).is_some() {
            return Err(invalid_record(path, record, "duplicate annotation cell ID"));
        }
    }
    Ok(annotations)
}

fn cell_totals(counts: &Counts, config: &CreationConfig) -> Result<Vec<(f64, f64)>> {
    let mut totals = allocate_numeric(counts.cell_ids.len(), counts.row_bytes, config)?;
    totals.resize(counts.cell_ids.len(), (0.0f64, 0.0f64));
    for row in &counts.rows {
        for ((sum, correction), &value) in totals.iter_mut().zip(&row.values) {
            let next = *sum + value;
            *correction += if sum.abs() >= value.abs() {
                (*sum - next) + value
            } else {
                (value - next) + *sum
            };
            *sum = next;
        }
    }
    Ok(totals)
}

fn resolve_groups(
    cells: &[Cell],
    config: &CreationConfig,
) -> Result<(Vec<CellGroup>, Vec<CellGroup>)> {
    let mut references = Vec::new();
    reserve(&mut references, config.reference_groups.len())?;
    for name in &config.reference_groups {
        references.push(CellGroup {
            name: owned(name)?,
            cell_indices: Vec::new(),
        });
    }
    let mut observations: Vec<CellGroup> = Vec::new();
    for (index, cell) in cells.iter().enumerate() {
        if let Some(group) = references.iter_mut().find(|group| group.name == cell.group) {
            reserve(&mut group.cell_indices, 1)?;
            group.cell_indices.push(index);
        } else if let Some(group) = observations
            .iter_mut()
            .find(|group| group.name == cell.group)
        {
            reserve(&mut group.cell_indices, 1)?;
            group.cell_indices.push(index);
        } else {
            let mut indices = Vec::new();
            reserve(&mut indices, 1)?;
            indices.push(index);
            reserve(&mut observations, 1)?;
            observations.push(CellGroup {
                name: owned(&cell.group)?,
                cell_indices: indices,
            });
        }
    }
    for group in &references {
        if group.cell_indices.is_empty() {
            return Err(RsomicsError::ConfigError(format!(
                "reference group {} has no retained cells",
                group.name
            )));
        }
    }
    observations.sort_unstable_by(|a, b| a.name.as_bytes().cmp(b.name.as_bytes()));
    Ok((references, observations))
}

fn fields<'a, const N: usize>(line: &'a str, path: &Path, record: usize) -> Result<[&'a str; N]> {
    let mut fields = line.split('\t');
    let mut result = [""; N];
    for slot in &mut result {
        *slot = fields
            .next()
            .filter(|value| !value.is_empty())
            .ok_or_else(|| invalid_record(path, record, "record has missing or empty fields"))?;
    }
    if fields.next().is_some() {
        return Err(invalid_record(path, record, "record has too many fields"));
    }
    Ok(result)
}

fn coordinate(token: &str, path: &Path, record: usize) -> Result<u64> {
    if !token.bytes().all(|byte| byte.is_ascii_digit()) {
        return Err(invalid_record(
            path,
            record,
            "coordinates must be unsigned decimal integers",
        ));
    }
    token
        .parse()
        .map_err(|_| invalid_record(path, record, "coordinate exceeds u64 range"))
}

fn owned(value: &str) -> Result<String> {
    let mut string = String::new();
    string
        .try_reserve_exact(value.len())
        .map_err(allocation_error)?;
    string.push_str(value);
    Ok(string)
}

fn reserve<T>(values: &mut Vec<T>, additional: usize) -> Result<()> {
    values.try_reserve(additional).map_err(allocation_error)
}

fn allocation_error(error: std::collections::TryReserveError) -> RsomicsError {
    RsomicsError::ConfigError(format!("input allocation failed: {error}"))
}

fn budget_overflow() -> RsomicsError {
    RsomicsError::ConfigError("input numeric workspace size overflows".into())
}

fn numeric_bytes(elements: usize, size: usize) -> Result<usize> {
    elements.checked_mul(size).ok_or_else(budget_overflow)
}

fn check_budget(bytes: usize, config: &CreationConfig) -> Result<()> {
    if bytes > config.max_numeric_bytes {
        return Err(RsomicsError::ConfigError(format!(
            "input numeric workspace requires {bytes} bytes, limit is {}",
            config.max_numeric_bytes
        )));
    }
    Ok(())
}

fn allocate_numeric<T>(
    elements: usize,
    occupied: usize,
    config: &CreationConfig,
) -> Result<Vec<T>> {
    let requested = numeric_bytes(elements, std::mem::size_of::<T>())?;
    check_budget(
        occupied
            .checked_add(requested)
            .ok_or_else(budget_overflow)?,
        config,
    )?;
    let mut values = Vec::new();
    values
        .try_reserve_exact(elements)
        .map_err(allocation_error)?;
    let allocated = numeric_bytes(values.capacity(), std::mem::size_of::<T>())?;
    check_budget(
        occupied
            .checked_add(allocated)
            .ok_or_else(budget_overflow)?,
        config,
    )?;
    Ok(values)
}

fn invalid_record(path: &Path, record: usize, detail: &str) -> RsomicsError {
    RsomicsError::InvalidInput(format!("{}: record {record}: {detail}", path.display()))
}

fn io_record(path: &Path, record: usize, error: io::Error) -> RsomicsError {
    RsomicsError::Io(io::Error::new(
        error.kind(),
        format!("{}: record {record}: {error}", path.display()),
    ))
}

struct Records<'a> {
    path: &'a Path,
    input: Box<dyn BufRead>,
    buffer: Vec<u8>,
    record: usize,
    limit: usize,
}

impl<'a> Records<'a> {
    fn open(path: &'a Path, limit: usize) -> Result<Self> {
        let file = File::open(path).map_err(|error| io_record(path, 1, error))?;
        let mut input = BufReader::new(file);
        let magic = input
            .fill_buf()
            .map_err(|error| io_record(path, 1, error))?
            .starts_with(&[0x1f, 0x8b]);
        let input: Box<dyn BufRead> =
            if magic || path.extension().is_some_and(|extension| extension == "gz") {
                Box::new(BufReader::new(MultiGzDecoder::new(input)))
            } else {
                Box::new(input)
            };
        Ok(Self {
            path,
            input,
            buffer: Vec::new(),
            record: 0,
            limit,
        })
    }

    fn next(&mut self) -> Result<Option<(usize, &str)>> {
        self.buffer.clear();
        let record = self
            .record
            .checked_add(1)
            .ok_or_else(|| invalid_record(self.path, self.record, "record number overflows"))?;
        let mut terminated = false;
        loop {
            let available = self
                .input
                .fill_buf()
                .map_err(|error| io_record(self.path, record, error))?;
            if available.is_empty() {
                break;
            }
            let take = match available.iter().position(|&byte| byte == b'\n') {
                Some(index) => {
                    terminated = true;
                    index + 1
                }
                None => available.len(),
            };
            let length = self.buffer.len().checked_add(take).ok_or_else(|| {
                invalid_record(self.path, record, "decoded record length overflows")
            })?;
            if length > self.limit {
                return Err(invalid_record(
                    self.path,
                    record,
                    &format!("decoded record exceeds {} bytes", self.limit),
                ));
            }
            self.buffer
                .try_reserve_exact(take)
                .map_err(allocation_error)?;
            self.buffer.extend_from_slice(&available[..take]);
            self.input.consume(take);
            if terminated {
                break;
            }
        }
        if self.buffer.is_empty() {
            return Ok(None);
        }
        self.record = record;
        if terminated {
            self.buffer.pop();
            if self.buffer.last() == Some(&b'\r') {
                self.buffer.pop();
            }
        }
        let line = std::str::from_utf8(&self.buffer)
            .map_err(|_| invalid_record(self.path, record, "record is not UTF-8"))?;
        Ok(Some((record, line)))
    }
}
