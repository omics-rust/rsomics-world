# Captured Ward.D2 trees

trees.tsv is generated without numeric rewriting from the accepted original
samples-clustering witness of run36707344893, infercnv1.28.0 source
b421d9405c97a309b081ef86d455e976df93eae4, fastcluster1.3.0/parallelDist0.2.7.
Witness SHA25626333ff388b0916d79736c7b3370b9f907fb943ca918a92ef5529a4d8bdfd304.
Fixture SHA25633617f00dc77608c3dab25623cf2143f4fa49ae4aa073940d0df5fff546b7236
(2126033bytes). Provenance and immutable acceptance receipt are in rsomics-world
.autopilot/oracles/infercnv-samples-clustering-witness-2026-09-30.json.

The deterministic extractor is rsomics-world/scripts/extract_infercnv_ward_fixtures.py.
It retains all152 trees/107331 distances from36 cases/52 routes/160 groups;
eight small groups legitimately have no tree. No payload deduplication occurs.
Cases are lexicographically ordered, then isolated/full_run, then group index.

Each tree has six LF TSV rows: tree identity/leaf count; distances; comma-paired
R merges; heights; one-based R leaf order; end. Condensed pair order is R lower
column, equivalent to symmetric upper row. Scalar strings are original exports,
not independently recalculated values. Positive-filter trees are valid kernel
inputs but do not establish native filtering or Euclidean arithmetic.

This is a private tree-kernel correctness gate, not step15 integration,
whole-inferCNV, biological, performance or release evidence.
