#[allow(
    dead_code,
    reason = "contract tests exercise private trial interfaces without its process entry point"
)]
#[path = "../benches/ingestion_trial/mod.rs"]
mod trial;

#[cfg(target_os = "linux")]
use std::collections::BTreeMap;
#[cfg(target_os = "linux")]
use std::ffi::OsString;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::{Duration, Instant};
use trial::{Args, CpuSample, InputCase, Inputs, RegionMetrics};

static NEXT: AtomicUsize = AtomicUsize::new(0);

struct TempRoot(PathBuf);

impl TempRoot {
    fn new() -> Self {
        let path = std::env::temp_dir().join(format!(
            "rsomics-ingestion-trial-contract-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir(&path).unwrap();
        Self(path)
    }
}

impl Drop for TempRoot {
    fn drop(&mut self) {
        fs::remove_dir_all(&self.0).unwrap();
    }
}

fn cpu(user_micros: u64, system_micros: u64) -> CpuSample {
    CpuSample {
        user_micros,
        system_micros,
    }
}

#[test]
fn only_three_positional_arguments_are_accepted() {
    let valid = vec!["artifact".into(), "plain".into(), "output".into()];
    let parsed = Args::parse(&valid).unwrap();
    assert_eq!(parsed.artifact_root, Path::new("artifact"));
    assert_eq!(parsed.output, Path::new("output"));
    assert_eq!(parsed.case, InputCase::Plain);
    assert!(Args::parse(&valid[..2]).is_err());
    let mut extra = valid;
    extra.push("pair-index".into());
    assert!(Args::parse(&extra).is_err());
    assert!(Args::parse(&["".into(), "plain".into(), "output".into()]).is_err());
    assert!(Args::parse(&["artifact".into(), "plain".into(), "".into()]).is_err());
}

#[test]
fn case_names_are_literal_and_closed() {
    assert_eq!(
        Args::parse(&["root".into(), "gzip".into(), "out".into()])
            .unwrap()
            .case,
        InputCase::Gzip
    );
    for invalid in ["GZIP", "plain ", "subset", "", "r-first"] {
        assert!(Args::parse(&["root".into(), invalid.into(), "out".into()]).is_err());
    }
}

#[test]
fn paths_match_the_current_frozen_receipt_layout() {
    let root = Path::new("artifact");
    let plain = Inputs::new(root, InputCase::Plain);
    let gzip = Inputs::new(root, InputCase::Gzip);
    assert_eq!(
        plain.counts,
        root.join("shipped-bundle/inputs/canonical-full.tsv")
    );
    assert_eq!(
        gzip.counts,
        root.join("ingestion-witness/shipped_full/counts.tsv.gz")
    );
    assert_eq!(
        plain.positions,
        root.join("shipped-bundle/inputs/gencode_downsampled.EXAMPLE_ONLY_DONT_REUSE.txt")
    );
    assert_eq!(
        plain.annotations,
        root.join("shipped-bundle/inputs/oligodendroglioma_annotations_downsampled.txt")
    );
    assert_eq!(plain.expected_full, root.join("shipped-bundle/full"));
    assert_eq!(
        plain.expected_maps,
        root.join("ingestion-witness/shipped_full/plain/maps.tsv")
    );
    assert_eq!(plain.plain_counts, gzip.plain_counts);
    assert_eq!(plain.positions, gzip.positions);
    assert_eq!(plain.annotations, gzip.annotations);
    assert_eq!(plain.expected_full, gzip.expected_full);
    assert_eq!(plain.expected_maps, gzip.expected_maps);
}

#[test]
fn configuration_retains_requested_references_and_bounded_limits() {
    let config = trial::creation_config(vec!["r_b".into(), "r_a".into()]);
    assert_eq!(config.reference_groups, ["r_b", "r_a"]);
    assert_eq!(config.excluded_chromosomes, ["chrX", "chrY", "chrM"]);
    assert_eq!(config.min_counts_per_cell, 1.0);
    assert_eq!(config.max_counts_per_cell, f64::INFINITY);
    assert_eq!(config.max_numeric_bytes, 268_435_456);
    assert_eq!(config.max_record_bytes, 1_048_576);
}

#[test]
fn input_case_must_agree_with_actual_magic() {
    let root = TempRoot::new();
    let plain = root.0.join("plain.tsv");
    let gzip = root.0.join("compressed.tsv");
    fs::write(&plain, b"gene\tc\nG\t1\n").unwrap();
    fs::write(&gzip, [0x1f, 0x8b, 0]).unwrap();
    InputCase::Plain.check_magic(&plain).unwrap();
    InputCase::Gzip.check_magic(&gzip).unwrap();
    assert!(InputCase::Gzip.check_magic(&plain).is_err());
    assert!(InputCase::Plain.check_magic(&gzip).is_err());
    fs::write(&plain, b"g").unwrap();
    assert!(InputCase::Plain.check_magic(&plain).is_err());
}

#[test]
fn region_cpu_deltas_have_explicit_seconds_and_no_child_work() {
    let metrics = RegionMetrics::checked(
        0.25,
        cpu(1_000_000, 3),
        cpu(1_500_000, 8),
        cpu(100, 20),
        cpu(100, 20),
        4096,
    )
    .unwrap();
    assert_eq!(metrics.wall_seconds, 0.25);
    assert_eq!(metrics.user_seconds, 0.5);
    assert_eq!(metrics.system_seconds, 0.000_005);
    assert_eq!(metrics.child_user_seconds, 0.0);
    assert_eq!(metrics.child_system_seconds, 0.0);
    assert_eq!(metrics.returned_rss_bytes, 4096);
}

#[test]
fn invalid_wall_or_rss_cannot_be_a_sample() {
    for wall in [0.0, -1.0, f64::NAN, f64::INFINITY] {
        assert!(
            RegionMetrics::checked(wall, cpu(0, 0), cpu(0, 0), cpu(0, 0), cpu(0, 0), 1).is_err()
        );
    }
    assert!(RegionMetrics::checked(1.0, cpu(0, 0), cpu(0, 0), cpu(0, 0), cpu(0, 0), 0).is_err());
}

#[test]
fn decreased_self_or_child_cpu_is_rejected() {
    for (before, after, child_before, child_after) in [
        (cpu(2, 0), cpu(1, 0), cpu(0, 0), cpu(0, 0)),
        (cpu(0, 2), cpu(0, 1), cpu(0, 0), cpu(0, 0)),
        (cpu(0, 0), cpu(0, 0), cpu(2, 0), cpu(1, 0)),
        (cpu(0, 0), cpu(0, 0), cpu(0, 2), cpu(0, 1)),
    ] {
        assert!(
            RegionMetrics::checked(1.0, before, after, child_before, child_after, 1024).is_err()
        );
    }
}

#[test]
fn unexpected_child_cpu_is_rejected_not_subtracted() {
    for after in [cpu(1, 0), cpu(0, 1)] {
        let error = RegionMetrics::checked(1.0, cpu(0, 0), cpu(10, 10), cpu(0, 0), after, 1024)
            .unwrap_err();
        assert!(error.contains("unexpected child CPU"));
    }
}

#[test]
fn elapsed_clock_direction_is_checked() {
    let start = Instant::now();
    let end = start + Duration::from_millis(250);
    assert_eq!(trial::checked_elapsed(start, end).unwrap(), 0.25);
    assert!(trial::checked_elapsed(end, start).is_err());
}

#[test]
fn thread_snapshot_requires_one_positive_counter() {
    assert_eq!(
        trial::parse_threads("Name:\ttrial\nThreads:\t3\nVmRSS:\t4 kB\n").unwrap(),
        3
    );
    for invalid in [
        "",
        "Threads: 0\n",
        "Threads: -1\n",
        "Threads: +1\n",
        "Threads: one\n",
        "Threads: 1 extra\n",
        "Threads: 1\nThreads: 2\n",
        "Threads: 18446744073709551616\n",
    ] {
        assert!(trial::parse_threads(invalid).is_err(), "{invalid:?}");
    }
}

#[test]
fn metadata_tables_are_exclusive_and_literal() {
    let root = TempRoot::new();
    let path = root.0.join("runtime.tsv");
    let rows = vec![("quoted".into(), " a\"b ".into())];
    trial::write_table(&path, &rows).unwrap();
    let before = fs::read(&path).unwrap();
    assert_eq!(before, b"key\tvalue\nquoted\t a\"b \n");
    assert!(trial::write_table(&path, &rows).is_err());
    assert_eq!(fs::read(path).unwrap(), before);
}

#[test]
fn metadata_separators_fail_before_file_creation() {
    let root = TempRoot::new();
    for (index, invalid) in ["bad\tfield", "bad\nrow", "bad\rrow"]
        .into_iter()
        .enumerate()
    {
        let path = root.0.join(format!("invalid-{index}.tsv"));
        assert!(trial::write_table(&path, &[("key".into(), invalid.into())]).is_err());
        assert!(!path.exists());
    }
}

#[test]
fn entry_point_requires_the_bounded_native_host() {
    assert_eq!(
        trial::require_measurement_host().is_ok(),
        cfg!(all(target_os = "linux", target_arch = "x86_64"))
    );
}

#[cfg(target_os = "linux")]
fn populate(root: &Path) {
    use flate2::{Compression, write::GzEncoder};
    use std::io::Write;
    let counts =
        "gene\tc_a\tc_obs\tc_b\nG_X\t100\t100\t100\nG_A\t-0\t3.75\t5.125\nG_B\t2.5\t4\t6.5\n";
    let rows = [
        (trial::PLAIN_COUNTS, counts),
        (
            trial::POSITIONS,
            "G_X\tchrX\t1\t2\nG_A\tchr1\t10\t20\nG_B\tchr2\t30\t40\n",
        ),
        (trial::ANNOTATIONS, "c_a\tr_a\nc_obs\to\nc_b\tr_b\n"),
        (
            "shipped-bundle/full/01.tsv",
            "gene\tc_a\tc_obs\tc_b\nG_A\t-0\t3.75\t5.125\nG_B\t2.5\t4\t6.5\n",
        ),
        (
            "shipped-bundle/full/01.genes.tsv",
            "gene\tchr\tstart\tstop\nG_A\tchr1\t10\t20\nG_B\tchr2\t30\t40\n",
        ),
        (
            "shipped-bundle/full/01.cells.tsv",
            "cell\tgroup\trole\nc_a\tr_a\treference\nc_obs\to\tobservation\nc_b\tr_b\treference\n",
        ),
        (
            trial::EXPECTED_MAPS,
            "role\tgroup\tindex\tcell\nreference\tr_b\t3\tc_b\nreference\tr_a\t1\tc_a\nobservation\to\t2\tc_obs\n",
        ),
    ];
    for (relative, text) in rows {
        let path = root.join(relative);
        fs::create_dir_all(path.parent().unwrap()).unwrap();
        fs::write(path, text).unwrap();
    }
    let gzip = root.join(trial::GZIP_COUNTS);
    fs::create_dir_all(gzip.parent().unwrap()).unwrap();
    let mut encoder = GzEncoder::new(Vec::new(), Compression::default());
    encoder.write_all(counts.as_bytes()).unwrap();
    fs::write(gzip, encoder.finish().unwrap()).unwrap();
}

#[cfg(target_os = "linux")]
fn table(path: &Path) -> BTreeMap<String, String> {
    let text = fs::read_to_string(path).unwrap();
    let mut lines = text.lines();
    assert_eq!(lines.next(), Some("key\tvalue"));
    let mut fields = BTreeMap::new();
    for line in lines {
        let (key, value) = line.split_once('\t').unwrap();
        assert!(fields.insert(key.to_owned(), value.to_owned()).is_none());
    }
    fields
}

#[cfg(target_os = "linux")]
#[test]
fn real_plain_and_gzip_trials_validate_both_factory_returns() {
    for case in [InputCase::Plain, InputCase::Gzip] {
        let root = TempRoot::new();
        populate(&root.0);
        let args = Args {
            artifact_root: root.0.clone(),
            case,
            output: root.0.join("trial"),
        };
        let argv = vec![
            OsString::from("contract-trial"),
            args.artifact_root.clone().into_os_string(),
            case.name().into(),
            args.output.clone().into_os_string(),
        ];
        trial::run_trial(&args, &argv).unwrap();
        for file in ["expression.tsv", "genes.tsv", "cells.tsv", "maps.tsv"] {
            assert_eq!(
                fs::read(args.output.join("warm").join(file)).unwrap(),
                fs::read(args.output.join("measured").join(file)).unwrap()
            );
        }
        assert_eq!(
            fs::read(args.output.join("warm/maps.tsv")).unwrap(),
            fs::read(root.0.join(trial::EXPECTED_MAPS)).unwrap()
        );
        let metrics = table(&args.output.join("metrics.tsv"));
        assert_eq!(metrics.len(), 12);
        assert_eq!(metrics["input_case"], case.name());
        assert_eq!(metrics["measurement"], "raw_creation");
        assert!(metrics["region_wall_seconds"].parse::<f64>().unwrap() > 0.0);
        assert!(metrics["baseline_rss_bytes"].parse::<u64>().unwrap() > 0);
        assert!(metrics["returned_rss_bytes"].parse::<u64>().unwrap() > 0);
        assert_eq!(
            metrics["region_child_user_seconds"].parse::<f64>().unwrap(),
            0.0
        );
        assert_eq!(
            metrics["region_child_system_seconds"]
                .parse::<f64>()
                .unwrap(),
            0.0
        );
        let runtime = table(&args.output.join("runtime.tsv"));
        assert_eq!(runtime["reference_group_1"], "r_b");
        assert_eq!(runtime["reference_group_2"], "r_a");
        assert_eq!(runtime["returned_genes"], "2");
        assert_eq!(runtime["returned_cells"], "3");
        assert_eq!(runtime["required_input_run_id"], "36707344893");
        assert_eq!(runtime["required_input_artifact_id"], "11092988090");
        assert!(runtime["observed_threads_before"].parse::<u64>().unwrap() > 0);
        assert!(runtime["observed_threads_returned"].parse::<u64>().unwrap() > 0);
        assert!(args.output.join("io.lifetime.txt").is_file());
    }
}

#[cfg(target_os = "linux")]
#[test]
fn warm_validation_failure_does_not_produce_a_sample() {
    let root = TempRoot::new();
    populate(&root.0);
    let path = root.0.join("shipped-bundle/full/01.tsv");
    fs::write(&path, fs::read_to_string(&path).unwrap().replace("-0", "0")).unwrap();
    let args = Args {
        artifact_root: root.0.clone(),
        case: InputCase::Plain,
        output: root.0.join("failed"),
    };
    let error = trial::run_trial(&args, &[]).unwrap_err();
    assert!(error.contains("warm validation"));
    assert!(!args.output.join("metrics.tsv").exists());
    assert!(!args.output.join("warm").exists());
    assert!(!args.output.join("measured").exists());
}

#[cfg(target_os = "linux")]
#[test]
fn factory_parse_failure_is_not_a_timing_sample() {
    let root = TempRoot::new();
    populate(&root.0);
    let path = root.0.join(trial::PLAIN_COUNTS);
    fs::write(
        &path,
        fs::read_to_string(&path).unwrap().replace("-0", "NaN"),
    )
    .unwrap();
    let args = Args {
        artifact_root: root.0.clone(),
        case: InputCase::Plain,
        output: root.0.join("failed"),
    };
    let error = trial::run_trial(&args, &[]).unwrap_err();
    assert!(error.contains("warm creation"));
    assert!(!args.output.join("metrics.tsv").exists());
    assert!(!args.output.join("measured").exists());
}

#[cfg(target_os = "linux")]
#[test]
fn existing_trial_directory_preserves_its_prior_bytes() {
    let root = TempRoot::new();
    populate(&root.0);
    let args = Args {
        artifact_root: root.0.clone(),
        case: InputCase::Plain,
        output: root.0.join("existing"),
    };
    fs::create_dir(&args.output).unwrap();
    fs::write(args.output.join("sentinel"), "keep").unwrap();
    assert!(trial::run_trial(&args, &[]).is_err());
    assert_eq!(
        fs::read_to_string(args.output.join("sentinel")).unwrap(),
        "keep"
    );
    assert_eq!(fs::read_dir(args.output).unwrap().count(), 1);
}
