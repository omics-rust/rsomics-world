#[allow(
    dead_code,
    reason = "this trial reuses only checked counters and environment formatting"
)]
#[path = "../support/mod.rs"]
mod counters;
#[cfg(target_os = "linux")]
#[path = "../ingestion_support/mod.rs"]
mod creation;

use rsomics_sc::cnv::{CreationConfig, InputPaths};
use std::ffi::{OsStr, OsString};
use std::fs::{File, OpenOptions};
use std::io::{BufWriter, Read, Write};
use std::path::{Path, PathBuf};
use std::time::Instant;

#[cfg(target_os = "linux")]
use nix::sys::resource::{UsageWho, getrusage};
#[cfg(target_os = "linux")]
use rsomics_sc::cnv::{CreatedInput, create_input};
#[cfg(target_os = "linux")]
use std::fs;

type Result<T> = std::result::Result<T, String>;

pub const PLAIN_COUNTS: &str = "shipped-bundle/inputs/canonical-full.tsv";
pub const GZIP_COUNTS: &str = "ingestion-witness/shipped_full/counts.tsv.gz";
pub const POSITIONS: &str = "shipped-bundle/inputs/gencode_downsampled.EXAMPLE_ONLY_DONT_REUSE.txt";
pub const ANNOTATIONS: &str = "shipped-bundle/inputs/oligodendroglioma_annotations_downsampled.txt";
pub const EXPECTED_FULL: &str = "shipped-bundle/full";
pub const EXPECTED_MAPS: &str = "ingestion-witness/shipped_full/plain/maps.tsv";

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum InputCase {
    Plain,
    Gzip,
}

impl InputCase {
    fn parse(value: &OsStr) -> Result<Self> {
        if value == "plain" {
            Ok(Self::Plain)
        } else if value == "gzip" {
            Ok(Self::Gzip)
        } else {
            Err("input case must be plain or gzip".into())
        }
    }

    pub fn name(self) -> &'static str {
        match self {
            Self::Plain => "plain",
            Self::Gzip => "gzip",
        }
    }

    pub fn check_magic(self, path: &Path) -> Result<()> {
        let mut file = File::open(path).map_err(|error| format!("{}: {error}", path.display()))?;
        let mut magic = [0_u8; 2];
        file.read_exact(&mut magic)
            .map_err(|error| format!("{}: {error}", path.display()))?;
        if (magic == [0x1f, 0x8b]) != (self == Self::Gzip) {
            return Err(format!(
                "{}: file magic disagrees with input case",
                path.display()
            ));
        }
        Ok(())
    }
}

#[derive(Debug)]
pub struct Args {
    pub artifact_root: PathBuf,
    pub case: InputCase,
    pub output: PathBuf,
}

impl Args {
    pub fn parse(values: &[OsString]) -> Result<Self> {
        if values.len() != 3 || values[0].is_empty() || values[2].is_empty() {
            return Err(
                "usage: cnv_ingestion_matched ARTIFACT_ROOT plain|gzip NEW_OUTPUT_DIR".into(),
            );
        }
        Ok(Self {
            artifact_root: PathBuf::from(&values[0]),
            case: InputCase::parse(&values[1])?,
            output: PathBuf::from(&values[2]),
        })
    }
}

pub struct Inputs {
    pub counts: PathBuf,
    pub plain_counts: PathBuf,
    pub positions: PathBuf,
    pub annotations: PathBuf,
    pub expected_full: PathBuf,
    pub expected_maps: PathBuf,
}

impl Inputs {
    pub fn new(root: &Path, case: InputCase) -> Self {
        Self {
            counts: root.join(match case {
                InputCase::Plain => PLAIN_COUNTS,
                InputCase::Gzip => GZIP_COUNTS,
            }),
            plain_counts: root.join(PLAIN_COUNTS),
            positions: root.join(POSITIONS),
            annotations: root.join(ANNOTATIONS),
            expected_full: root.join(EXPECTED_FULL),
            expected_maps: root.join(EXPECTED_MAPS),
        }
    }

    pub fn paths(&self) -> InputPaths<'_> {
        InputPaths {
            counts: &self.counts,
            positions: &self.positions,
            annotations: &self.annotations,
        }
    }
}

pub fn creation_config(reference_names: Vec<String>) -> CreationConfig {
    CreationConfig {
        reference_groups: reference_names,
        excluded_chromosomes: vec!["chrX".into(), "chrY".into(), "chrM".into()],
        min_counts_per_cell: 1.0,
        max_counts_per_cell: f64::INFINITY,
        max_numeric_bytes: 256 * 1024 * 1024,
        max_record_bytes: 1024 * 1024,
    }
}

#[derive(Clone, Copy, Debug)]
pub struct CpuSample {
    pub user_micros: u64,
    pub system_micros: u64,
}

#[derive(Debug)]
pub struct RegionMetrics {
    pub wall_seconds: f64,
    pub user_seconds: f64,
    pub system_seconds: f64,
    pub child_user_seconds: f64,
    pub child_system_seconds: f64,
    pub returned_rss_bytes: u64,
}

impl RegionMetrics {
    pub fn checked(
        wall_seconds: f64,
        before: CpuSample,
        after: CpuSample,
        child_before: CpuSample,
        child_after: CpuSample,
        returned_rss_bytes: u64,
    ) -> Result<Self> {
        if !wall_seconds.is_finite() || wall_seconds <= 0.0 || returned_rss_bytes == 0 {
            return Err("region requires positive finite wall time and positive live RSS".into());
        }
        let delta = |before, after| {
            counters::checked_counter_delta(before, after).map(|micros| micros as f64 / 1_000_000.0)
        };
        let user_seconds = delta(before.user_micros, after.user_micros)?;
        let system_seconds = delta(before.system_micros, after.system_micros)?;
        let child_user_seconds = delta(child_before.user_micros, child_after.user_micros)?;
        let child_system_seconds = delta(child_before.system_micros, child_after.system_micros)?;
        if child_user_seconds != 0.0 || child_system_seconds != 0.0 {
            return Err("unexpected child CPU work during creation".into());
        }
        Ok(Self {
            wall_seconds,
            user_seconds,
            system_seconds,
            child_user_seconds,
            child_system_seconds,
            returned_rss_bytes,
        })
    }
}

pub fn checked_elapsed(start: Instant, end: Instant) -> Result<f64> {
    end.checked_duration_since(start)
        .map(|duration| duration.as_secs_f64())
        .ok_or_else(|| "wall clock reversed".into())
}

pub fn parse_threads(text: &str) -> Result<u64> {
    let mut count = None;
    for line in text.lines() {
        let Some(value) = line.strip_prefix("Threads:") else {
            continue;
        };
        if count.is_some() {
            return Err("duplicate process thread count".into());
        }
        let mut fields = value.split_whitespace();
        let token = fields
            .next()
            .ok_or_else(|| "missing process thread count".to_owned())?;
        if token.is_empty()
            || !token.bytes().all(|byte| byte.is_ascii_digit())
            || fields.next().is_some()
        {
            return Err("invalid process thread count".into());
        }
        let value = token
            .parse::<u64>()
            .map_err(|error| format!("process thread count: {error}"))?;
        if value == 0 {
            return Err("process thread count must be positive".into());
        }
        count = Some(value);
    }
    count.ok_or_else(|| "missing process thread count".into())
}

pub fn write_table(path: &Path, rows: &[(String, String)]) -> Result<()> {
    for (key, value) in rows {
        for field in [key, value] {
            counters::format_env_value(Some(OsString::from(field.as_str())))?;
        }
    }
    let result = (|| {
        let file = OpenOptions::new().write(true).create_new(true).open(path)?;
        let mut writer = BufWriter::new(file);
        writeln!(writer, "key\tvalue")?;
        for (key, value) in rows {
            writeln!(writer, "{key}\t{value}")?;
        }
        writer.flush()
    })();
    result.map_err(|error| format!("{}: {error}", path.display()))
}

pub fn require_measurement_host() -> Result<()> {
    if cfg!(all(target_os = "linux", target_arch = "x86_64")) {
        Ok(())
    } else {
        Err("cnv_ingestion_matched requires native Linux x86_64".into())
    }
}

pub fn run_env() -> Result<()> {
    require_measurement_host()?;
    let argv: Vec<_> = std::env::args_os().collect();
    let args = Args::parse(&argv[1..])?;
    run_trial(&args, &argv)
}

#[cfg(not(target_os = "linux"))]
pub fn run_trial(_args: &Args, _argv: &[OsString]) -> Result<()> {
    Err("trial counters require Linux procfs and getrusage".into())
}

#[cfg(target_os = "linux")]
fn read_current_rss() -> Result<u64> {
    let path = "/proc/self/smaps_rollup";
    let text = fs::read_to_string(path).map_err(|error| format!("{path}: {error}"))?;
    counters::parse_rss_bytes(&text).map_err(|error| format!("{path}: {error}"))
}

#[cfg(target_os = "linux")]
fn read_process_threads() -> Result<u64> {
    let path = "/proc/self/status";
    let text = fs::read_to_string(path).map_err(|error| format!("{path}: {error}"))?;
    parse_threads(&text).map_err(|error| format!("{path}: {error}"))
}

#[cfg(target_os = "linux")]
fn process_cpu(who: UsageWho) -> Result<CpuSample> {
    let usage = getrusage(who).map_err(|error| format!("getrusage: {error}"))?;
    let user = usage.user_time();
    let system = usage.system_time();
    Ok(CpuSample {
        user_micros: counters::checked_cpu_micros(user.tv_sec(), user.tv_usec())?,
        system_micros: counters::checked_cpu_micros(system.tv_sec(), system.tv_usec())?,
    })
}

#[cfg(target_os = "linux")]
fn measure_creation(
    paths: InputPaths<'_>,
    config: &CreationConfig,
) -> Result<(CreatedInput, RegionMetrics)> {
    let child_before = process_cpu(UsageWho::RUSAGE_CHILDREN)?;
    let self_before = process_cpu(UsageWho::RUSAGE_SELF)?;
    let start = Instant::now();
    let created =
        create_input(paths, config).map_err(|error| format!("measured creation: {error}"))?;
    let end = Instant::now();
    let self_after = process_cpu(UsageWho::RUSAGE_SELF)?;
    let child_after = process_cpu(UsageWho::RUSAGE_CHILDREN)?;
    let returned_rss_bytes = read_current_rss()?;
    let metrics = RegionMetrics::checked(
        checked_elapsed(start, end)?,
        self_before,
        self_after,
        child_before,
        child_after,
        returned_rss_bytes,
    )?;
    Ok((created, metrics))
}

#[cfg(target_os = "linux")]
pub fn run_trial(args: &Args, argv: &[OsString]) -> Result<()> {
    let preparation_start = Instant::now();
    let artifact_root = fs::canonicalize(&args.artifact_root)
        .map_err(|error| format!("{}: {error}", args.artifact_root.display()))?;
    let output =
        std::path::absolute(&args.output).map_err(|error| format!("output path: {error}"))?;
    let inputs = Inputs::new(&artifact_root, args.case);
    args.case.check_magic(&inputs.counts)?;
    let expected = creation::load_expected(&inputs.expected_full, &inputs.expected_maps)?;
    let config = creation_config(expected.reference_names());
    let path_value = |path: &Path| counters::format_env_value(Some(path.as_os_str().to_owned()));
    let file_bytes = |path: &Path| {
        fs::metadata(path)
            .map(|metadata| metadata.len())
            .map_err(|error| format!("{}: {error}", path.display()))
    };
    let mut runtime = vec![
        ("schema_version".into(), "1".into()),
        ("measurement".into(), "raw_creation".into()),
        ("implementation".into(), "rust".into()),
        ("factory".into(), "rsomics_sc::cnv::create_input".into()),
        ("product_version".into(), env!("CARGO_PKG_VERSION").into()),
        ("operating_system".into(), std::env::consts::OS.into()),
        ("architecture".into(), std::env::consts::ARCH.into()),
        (
            "build_assertions".into(),
            cfg!(debug_assertions).to_string(),
        ),
        ("input_case".into(), args.case.name().into()),
        (
            "required_input_receipt".into(),
            "infercnv-ingestion-measurement-input-2026-09-30.json".into(),
        ),
        ("required_input_run_id".into(), "36707344893".into()),
        ("required_input_artifact_id".into(), "11092988090".into()),
        (
            "required_input_artifact_sha256".into(),
            "2481188b6f3d058d154bf16df9297a9eca261c6df84280e7d16569c92da28bd8".into(),
        ),
        (
            "required_input_receipt_sha256".into(),
            "3bee1dc582a321f16cb173c757e955dc620a911a891f4051f8bae68dc856dc0b".into(),
        ),
        ("artifact_root".into(), path_value(&artifact_root)?),
        ("counts_path".into(), path_value(&inputs.counts)?),
        ("positions_path".into(), path_value(&inputs.positions)?),
        ("annotations_path".into(), path_value(&inputs.annotations)?),
        (
            "expected_full_path".into(),
            path_value(&inputs.expected_full)?,
        ),
        (
            "expected_maps_path".into(),
            path_value(&inputs.expected_maps)?,
        ),
        (
            "input_selected_file_bytes".into(),
            file_bytes(&inputs.counts)?.to_string(),
        ),
        (
            "input_decoded_count_bytes".into(),
            file_bytes(&inputs.plain_counts)?.to_string(),
        ),
        (
            "decoded_bytes_binding".into(),
            "canonical plain file length; gzip equality checked by external controller".into(),
        ),
        (
            "input_authentication".into(),
            "external controller must verify receipt paths and hashes before and after all trials"
                .into(),
        ),
        (
            "max_numeric_bytes".into(),
            config.max_numeric_bytes.to_string(),
        ),
        (
            "max_record_bytes".into(),
            config.max_record_bytes.to_string(),
        ),
        ("min_counts_per_cell".into(), "1".into()),
        ("max_counts_per_cell".into(), "Inf".into()),
        (
            "count_representation".into(),
            "native f64 column-major".into(),
        ),
        (
            "numeric_parity_scope".into(),
            "frozen canonical receipt; not arbitrary R-decimal parsing".into(),
        ),
        ("factory_warmups_per_process".into(), "1".into()),
        ("measured_factory_calls_per_process".into(), "1".into()),
        (
            "warm_regime".into(),
            "filesystem and allocation warm; no controlled cold cache".into(),
        ),
        (
            "reclamation_before_baseline".into(),
            "drop warm CreatedInput and ExpectedCreation; no allocator trimming".into(),
        ),
        (
            "retained_preparation".into(),
            "paths/config/runtime metadata and possible allocator-retained pages".into(),
        ),
        (
            "cpu_counter_scope".into(),
            "getrusage self and reaped children; bracketing calls outside wall timer".into(),
        ),
        (
            "rss_scope".into(),
            "baseline and live return snapshots; neither is a transient factory peak".into(),
        ),
        (
            "whole_process_metrics".into(),
            "external monitor; includes warmup validation and exports".into(),
        ),
        (
            "thread_observation".into(),
            "procfs snapshots; no claim of continuous single-thread execution".into(),
        ),
        (
            "io_snapshot_scope".into(),
            "whole-process lifetime after both validated exports before metadata writes".into(),
        ),
        (
            "io_rchar_wchar".into(),
            "bytes from read/write-like syscalls including instrumentation".into(),
        ),
        (
            "io_syscr_syscw".into(),
            "read/write-like syscall counts".into(),
        ),
        (
            "io_read_write_bytes".into(),
            "Linux storage-layer accounting; cached physical reads may be zero".into(),
        ),
        (
            "io_cancelled_write_bytes".into(),
            "Linux accounting of dirty writes cancelled before storage".into(),
        ),
        ("pid".into(), std::process::id().to_string()),
        (
            "executable_path".into(),
            path_value(
                &std::env::current_exe().map_err(|error| format!("current executable: {error}"))?,
            )?,
        ),
    ];
    for (index, argument) in argv.iter().enumerate() {
        runtime.push((
            format!("argv_{index}"),
            counters::format_env_value(Some(argument.clone()))?,
        ));
    }
    for (index, reference) in config.reference_groups.iter().enumerate() {
        runtime.push((format!("reference_group_{}", index + 1), reference.clone()));
    }
    for (index, chromosome) in config.excluded_chromosomes.iter().enumerate() {
        runtime.push((
            format!("excluded_chromosome_{}", index + 1),
            chromosome.clone(),
        ));
    }
    for key in [
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "BLIS_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
        "RAYON_NUM_THREADS",
    ] {
        runtime.push((
            key.into(),
            counters::format_env_value(std::env::var_os(key))?,
        ));
    }

    fs::create_dir(&output).map_err(|error| format!("{}: {error}", output.display()))?;
    let warm =
        create_input(inputs.paths(), &config).map_err(|error| format!("warm creation: {error}"))?;
    creation::validate_created(&warm, &expected)
        .map_err(|error| format!("warm validation: {error}"))?;
    creation::write_creation(&output.join("warm"), &warm)?;
    drop(warm);
    drop(expected);
    let threads_before = read_process_threads()?;
    let baseline_rss_bytes = read_current_rss()?;
    let preparation_end = Instant::now();
    let (measured, metrics) = measure_creation(inputs.paths(), &config)?;
    let threads_returned = read_process_threads()?;

    let expected = creation::load_expected(&inputs.expected_full, &inputs.expected_maps)?;
    creation::validate_created(&measured, &expected)
        .map_err(|error| format!("measured validation: {error}"))?;
    creation::write_creation(&output.join("measured"), &measured)?;
    runtime.push((
        "returned_genes".into(),
        measured.prepared_counts().state().gene_count().to_string(),
    ));
    runtime.push((
        "returned_cells".into(),
        measured.prepared_counts().state().cell_count().to_string(),
    ));
    runtime.push(("observed_threads_before".into(), threads_before.to_string()));
    runtime.push((
        "observed_threads_returned".into(),
        threads_returned.to_string(),
    ));

    let io_path = "/proc/self/io";
    let io = fs::read(io_path).map_err(|error| format!("{io_path}: {error}"))?;
    let destination = output.join("io.lifetime.txt");
    let mut io_file = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&destination)
        .map_err(|error| format!("{}: {error}", destination.display()))?;
    io_file
        .write_all(&io)
        .and_then(|()| io_file.flush())
        .map_err(|error| format!("{}: {error}", destination.display()))?;
    write_table(&output.join("runtime.tsv"), &runtime)?;
    write_table(
        &output.join("metrics.tsv"),
        &[
            ("schema_version".into(), "1".into()),
            ("measurement".into(), "raw_creation".into()),
            ("implementation".into(), "rust".into()),
            ("input_case".into(), args.case.name().into()),
            (
                "preparation_wall_seconds".into(),
                format!(
                    "{:.17e}",
                    checked_elapsed(preparation_start, preparation_end)?
                ),
            ),
            (
                "region_wall_seconds".into(),
                format!("{:.17e}", metrics.wall_seconds),
            ),
            (
                "region_user_seconds".into(),
                format!("{:.17e}", metrics.user_seconds),
            ),
            (
                "region_system_seconds".into(),
                format!("{:.17e}", metrics.system_seconds),
            ),
            (
                "region_child_user_seconds".into(),
                format!("{:.17e}", metrics.child_user_seconds),
            ),
            (
                "region_child_system_seconds".into(),
                format!("{:.17e}", metrics.child_system_seconds),
            ),
            ("baseline_rss_bytes".into(), baseline_rss_bytes.to_string()),
            (
                "returned_rss_bytes".into(),
                metrics.returned_rss_bytes.to_string(),
            ),
        ],
    )
}
