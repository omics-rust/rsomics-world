#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
#[path = "ingestion_trial/mod.rs"]
mod trial;

fn main() {
    #[cfg(all(target_os = "linux", target_arch = "x86_64"))]
    if let Err(error) = trial::run_env() {
        eprintln!("cnv_ingestion_matched: {error}");
        std::process::exit(1);
    }
    #[cfg(not(all(target_os = "linux", target_arch = "x86_64")))]
    {
        eprintln!("cnv_ingestion_matched requires native Linux x86_64");
        std::process::exit(1);
    }
}
