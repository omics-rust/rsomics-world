use super::condensed::{condensed_index, pair_count};
use rsomics_common::{Result, RsomicsError};
use std::mem::size_of;

pub(crate) struct CellProfiles<'a> {
    values: &'a [f64],
    features: usize,
    cells: usize,
}

fn invalid(message: &str) -> RsomicsError {
    RsomicsError::InvalidInput(message.into())
}

impl<'a> CellProfiles<'a> {
    pub(crate) fn new(values: &'a [f64], features: usize, cells: usize) -> Result<Self> {
        if cells == 0 || features.checked_mul(cells) != Some(values.len()) {
            return Err(invalid("Cell profile dimensions do not match values"));
        }
        if values.iter().any(|value| !value.is_finite()) {
            return Err(invalid("Cell profiles must be finite"));
        }
        Ok(Self {
            values,
            features,
            cells,
        })
    }

    pub(crate) fn feature_count(&self) -> usize {
        self.features
    }

    pub(crate) fn cell_count(&self) -> usize {
        self.cells
    }

    pub(crate) fn distances(
        &self,
        indices: &[usize],
        max_numeric_bytes: usize,
    ) -> Result<Vec<f64>> {
        let pairs = pair_count(indices.len())?;
        let bytes = pairs
            .checked_mul(size_of::<f64>())
            .ok_or_else(|| invalid("Distance output size overflows"))?;
        if bytes > max_numeric_bytes {
            return Err(invalid("Distances exceed the numeric output budget"));
        }
        for (position, &index) in indices.iter().enumerate() {
            if index >= self.cell_count() || indices[..position].contains(&index) {
                return Err(invalid("Cell indices must be distinct and in range"));
            }
        }
        let mut distances = Vec::new();
        distances
            .try_reserve_exact(pairs)
            .map_err(|_| invalid("Distance output allocation failed"))?;
        distances.resize(pairs, 0.0);
        for (i, &left) in indices.iter().enumerate() {
            let left = self.column(left);
            for (j, &right) in indices.iter().enumerate().skip(i + 1) {
                let right = self.column(right);
                let mut even = 0.0;
                let mut odd = 0.0;
                let mut feature = 0;
                while feature + 1 < self.features {
                    let a = left[feature] - right[feature];
                    let b = left[feature + 1] - right[feature + 1];
                    even += a * a;
                    odd += b * b;
                    feature += 2;
                }
                if feature < self.features {
                    let a = left[feature] - right[feature];
                    even += a * a;
                }
                let distance = (even + odd).sqrt();
                if !distance.is_finite() {
                    return Err(invalid("Distance arithmetic is not finite"));
                }
                distances[condensed_index(indices.len(), i, j)] = distance;
            }
        }
        Ok(distances)
    }

    pub(crate) fn column(&self, index: usize) -> &[f64] {
        let start = index * self.feature_count();
        &self.values[start..start + self.feature_count()]
    }
}
