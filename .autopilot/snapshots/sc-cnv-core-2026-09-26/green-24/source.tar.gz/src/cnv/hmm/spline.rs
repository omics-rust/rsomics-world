use super::moments::Sum;
use rsomics_common::{Result, RsomicsError};

type Band = Vec<[f64; 4]>;

pub(super) struct Spline {
    knots: Vec<f64>,
    coefficients: Vec<f64>,
    origin: f64,
    range: f64,
}

impl Spline {
    pub(super) fn fit(x: &[f64], y: &[f64]) -> Result<Self> {
        let geometry = Geometry::new(x, y)?;
        let mut lower = -1.5;
        let mut upper = 1.5;
        let golden = 0.381_966_011_250_105_15;
        let mut best = lower + golden * (upper - lower);
        let mut second = best;
        let mut third = best;
        let mut latest = geometry.evaluate(best)?;
        let mut best_score = latest.score;
        let mut second_score = best_score;
        let mut third_score = best_score;
        let mut step = 0.0_f64;
        let mut previous_span = 0.0_f64;
        for _ in 0..500 {
            let midpoint = (lower + upper) * 0.5;
            let tolerance = 2e-8 * best.abs() + 1e-4 / 3.0;
            let twice_tolerance = 2.0 * tolerance;
            if (best - midpoint).abs() <= twice_tolerance - (upper - lower) * 0.5 {
                break;
            }
            let mut use_golden = true;
            if previous_span.abs() > tolerance {
                let first_term = (best - second) * (best_score - third_score);
                let second_term = (best - third) * (best_score - second_score);
                let mut numerator = (best - third) * second_term - (best - second) * first_term;
                let mut denominator = 2.0 * (second_term - first_term);
                if denominator > 0.0 {
                    numerator = -numerator;
                }
                denominator = denominator.abs();
                let span = previous_span;
                previous_span = step;
                if numerator.abs() < (0.5 * denominator * span).abs()
                    && numerator > denominator * (lower - best)
                    && numerator < denominator * (upper - best)
                {
                    step = numerator / denominator;
                    let proposed = best + step;
                    if proposed - lower < twice_tolerance || upper - proposed < twice_tolerance {
                        step = if midpoint >= best {
                            tolerance
                        } else {
                            -tolerance
                        };
                    }
                    use_golden = false;
                }
            }
            if use_golden {
                previous_span = if best >= midpoint {
                    lower - best
                } else {
                    upper - best
                };
                step = golden * previous_span;
            }
            let trial = best
                + if step.abs() >= tolerance {
                    step
                } else {
                    if step >= 0.0 { tolerance } else { -tolerance }
                };
            latest = geometry.evaluate(trial)?;
            let score = latest.score;
            if score <= best_score {
                if trial >= best {
                    lower = best;
                } else {
                    upper = best;
                }
                third = second;
                third_score = second_score;
                second = best;
                second_score = best_score;
                best = trial;
                best_score = score;
            } else {
                if trial < best {
                    lower = trial;
                } else {
                    upper = trial;
                }
                if score <= second_score || second == best {
                    third = second;
                    third_score = second_score;
                    second = trial;
                    second_score = score;
                } else if score <= third_score || third == best || third == second {
                    third = trial;
                    third_score = score;
                }
            }
        }
        if latest.coefficients.iter().any(|value| !value.is_finite()) {
            return Err(error("smoothing-spline coefficients are nonfinite"));
        }
        // Upstream predictions retain the last evaluated fit, not the best search point.
        Ok(Self {
            knots: geometry.knots,
            coefficients: latest.coefficients,
            origin: geometry.origin,
            range: geometry.range,
        })
    }

    pub(super) fn predict(&self, value: f64) -> f64 {
        let normalized = (value - self.origin) / self.range;
        let evaluation = basis(&self.knots, normalized.clamp(0.0, 1.0));
        let fitted = dot(&evaluation.value, &self.coefficients, evaluation.start);
        if normalized < 0.0 {
            fitted
                + (value - self.origin)
                    * (dot(&evaluation.first, &self.coefficients, evaluation.start) / self.range)
        } else if normalized > 1.0 {
            fitted
                + (value - (self.origin + self.range))
                    * (dot(&evaluation.first, &self.coefficients, evaluation.start) / self.range)
        } else {
            fitted
        }
    }
}

#[derive(Clone, Copy)]
struct Evaluation {
    start: usize,
    value: [f64; 4],
    first: [f64; 4],
    second: [f64; 4],
}

fn basis(knots: &[f64], point: f64) -> Evaluation {
    let span = knots
        .partition_point(|knot| *knot <= point)
        .saturating_sub(1)
        .clamp(3, knots.len() - 5);
    basis_on_span(knots, point, span)
}

fn basis_on_span(knots: &[f64], point: f64, span: usize) -> Evaluation {
    let mut value = [1.0, 0.0, 0.0, 0.0];
    let mut first = [0.0; 4];
    let mut second = [0.0; 4];
    for degree in 1..=3 {
        let mut next_value = [0.0; 4];
        let mut next_first = [0.0; 4];
        let mut next_second = [0.0; 4];
        for offset in 0..=degree {
            let index = span - degree + offset;
            if offset > 0 {
                let width = knots[index + degree] - knots[index];
                if width != 0.0 {
                    next_value[offset] += (point - knots[index]) / width * value[offset - 1];
                    next_first[offset] += degree as f64 / width * value[offset - 1];
                    next_second[offset] += degree as f64 / width * first[offset - 1];
                }
            }
            if offset < degree {
                let width = knots[index + degree + 1] - knots[index + 1];
                if width != 0.0 {
                    next_value[offset] +=
                        (knots[index + degree + 1] - point) / width * value[offset];
                    next_first[offset] -= degree as f64 / width * value[offset];
                    next_second[offset] -= degree as f64 / width * first[offset];
                }
            }
        }
        value = next_value;
        first = next_first;
        second = next_second;
    }
    Evaluation {
        start: span - 3,
        value,
        first,
        second,
    }
}

fn dot(values: &[f64; 4], coefficients: &[f64], start: usize) -> f64 {
    values
        .iter()
        .zip(&coefficients[start..start + 4])
        .map(|(value, coefficient)| value * coefficient)
        .sum()
}

struct Row {
    point: f64,
    target: f64,
    weight: f64,
    basis: Evaluation,
}

struct Geometry {
    rows: Vec<Row>,
    knots: Vec<f64>,
    gram: Band,
    penalty: Band,
    rhs: Vec<f64>,
    origin: f64,
    range: f64,
    residual: f64,
    total_weight: f64,
    ratio: f64,
}

struct Bucket {
    key: f64,
    point: f64,
    count: usize,
    y: Sum,
    squares: Sum,
}

impl Geometry {
    fn new(x: &[f64], y: &[f64]) -> Result<Self> {
        if x.len() != y.len() || x.len() < 4 || x.iter().chain(y).any(|value| !value.is_finite()) {
            return Err(error(
                "smoothing-spline inputs must be finite paired observations",
            ));
        }
        let mut points: Vec<_> = x.iter().copied().zip(y.iter().copied()).collect();
        points.sort_by(|left, right| left.0.total_cmp(&right.0));
        let quantile = |probability: f64| {
            let position = (points.len() - 1) as f64 * probability;
            let lower = position.floor() as usize;
            let upper = position.ceil() as usize;
            let fraction = position - lower as f64;
            (1.0 - fraction) * points[lower].0 + fraction * points[upper].0
        };
        let tolerance = 1e-6 * (quantile(0.75) - quantile(0.25));
        if !tolerance.is_finite() || tolerance <= 0.0 {
            return Err(error(
                "smoothing-spline x tolerance must be positive and finite",
            ));
        }
        let mut total = Sum::default();
        for value in x {
            total.add(*value);
        }
        let mean = total.finish() / x.len() as f64;
        let mut correction = Sum::default();
        for value in x {
            correction.add(*value - mean);
        }
        let mean = mean + correction.finish() / x.len() as f64;
        let mut buckets: Vec<Bucket> = Vec::new();
        for (point, target) in points {
            let key = ((point - mean) / tolerance).round_ties_even();
            if buckets.last().is_none_or(|bucket| bucket.key != key) {
                buckets.push(Bucket {
                    key,
                    point,
                    count: 0,
                    y: Sum::default(),
                    squares: Sum::default(),
                });
            }
            let last = buckets.len() - 1;
            buckets[last].count += 1;
            buckets[last].y.add(target);
            buckets[last].squares.add(target * target);
        }
        if buckets.len() < 4 {
            return Err(error(
                "smoothing-spline fitting requires four distinct x buckets",
            ));
        }
        let origin = buckets[0].point;
        let range = buckets[buckets.len() - 1].point - origin;
        if !range.is_finite() || range <= 0.0 {
            return Err(error("smoothing-spline range must be positive and finite"));
        }
        let count = buckets.len();
        let knot_count = default_knots(count);
        let mut knots = vec![0.0; 3];
        let stride = (count - 1) as f64 / (knot_count - 1) as f64;
        for i in 0..knot_count {
            let index = if i + 1 == knot_count {
                count - 1
            } else {
                (1.0 + i as f64 * stride) as usize - 1
            };
            knots.push((buckets[index].point - origin) / range);
        }
        knots.extend_from_slice(&[1.0; 3]);
        let size = knot_count + 2;
        let mut gram = vec![[0.0; 4]; size];
        let mut penalty = vec![[0.0; 4]; size];
        let mut rhs = vec![0.0; size];
        let mut residual = Sum::default();
        let mut total_weight = Sum::default();
        let mut rows = Vec::with_capacity(count);
        for bucket in buckets {
            let count = bucket.count as f64;
            let target = bucket.y.finish() / count;
            residual.add(bucket.squares.finish() - count * target * target);
            let point = (bucket.point - origin) / range;
            let evaluated = basis(&knots, point);
            let weight = count.sqrt();
            let squared_weight = weight * weight;
            total_weight.add(squared_weight);
            for i in 0..4 {
                let row = evaluated.start + i;
                rhs[row] += squared_weight * evaluated.value[i] * target;
                for j in i..4 {
                    gram[row][j - i] += squared_weight * evaluated.value[i] * evaluated.value[j];
                }
            }
            rows.push(Row {
                point,
                target,
                weight,
                basis: evaluated,
            });
        }
        for span in 3..size {
            let width = knots[span + 1] - knots[span];
            if width == 0.0 {
                continue;
            }
            let left = basis_on_span(&knots, knots[span], span);
            let right = basis_on_span(&knots, knots[span + 1], span);
            let change: [f64; 4] = std::array::from_fn(|i| right.second[i] - left.second[i]);
            for i in 0..4 {
                for j in i..4 {
                    // The upstream roughness convention uses 0.3330 rather than 1/3.
                    penalty[left.start + i][j - i] += width
                        * (left.second[i] * left.second[j]
                            + (change[i] * left.second[j] + change[j] * left.second[i]) * 0.5
                            + 0.3330 * (change[i] * change[j]));
                }
            }
        }
        let ratio = (2..size - 3).map(|i| gram[i][0]).sum::<f64>()
            / (2..size - 3).map(|i| penalty[i][0]).sum::<f64>();
        Ok(Self {
            rows,
            knots,
            gram,
            penalty,
            rhs,
            origin,
            range,
            residual: residual.finish(),
            total_weight: total_weight.finish(),
            ratio,
        })
    }

    fn evaluate(&self, smoothing: f64) -> Result<Candidate> {
        let lambda = self.ratio * 16.0_f64.powf(6.0 * smoothing - 2.0);
        let matrix: Band = self
            .gram
            .iter()
            .zip(&self.penalty)
            .map(|(gram, penalty)| std::array::from_fn(|i| gram[i] + lambda * penalty[i]))
            .collect();
        let factor = cholesky(matrix)?;
        let coefficients = solve(&factor, &self.rhs);
        let inverse = selected_inverse(&factor);
        let mut residual = self.residual;
        let mut degrees = 0.0;
        for row in &self.rows {
            let fitted = dot(&row.basis.value, &coefficients, row.basis.start);
            residual += ((row.target - fitted) * row.weight).powi(2);
            let leverage = if row.point == 1.0 {
                basis(&self.knots, 1.0 - 1e-11)
            } else {
                row.basis
            };
            let mut variance = 0.0;
            for i in 0..4 {
                for j in 0..4 {
                    variance += leverage.value[i]
                        * leverage.value[j]
                        * band_value(&inverse, leverage.start + i, leverage.start + j);
                }
            }
            degrees += row.weight * row.weight * variance;
        }
        let score = (residual / self.total_weight) / (1.0 - degrees / self.total_weight).powi(2);
        Ok(Candidate {
            coefficients,
            score: if score.is_finite() { score } else { 2e100 },
        })
    }
}

fn default_knots(count: usize) -> usize {
    let n = count as f64;
    match count {
        0..50 => count,
        50..200 => (50.0 * 2.0_f64.powf((n - 50.0) / 150.0)) as usize,
        200..800 => (100.0 * 1.4_f64.powf((n - 200.0) / 600.0)) as usize,
        800..3200 => (140.0 * (200.0_f64 / 140.0).powf((n - 800.0) / 2400.0)) as usize,
        _ => (200.0 + (n - 3200.0).powf(0.2)) as usize,
    }
}

struct Candidate {
    coefficients: Vec<f64>,
    score: f64,
}

fn cholesky(mut matrix: Band) -> Result<Band> {
    let size = matrix.len();
    for i in 0..size {
        let mut diagonal = matrix[i][0];
        for previous in i.saturating_sub(3)..i {
            diagonal -= matrix[previous][i - previous].powi(2);
        }
        if diagonal <= 0.0 || !diagonal.is_finite() {
            return Err(error("smoothing-spline system is not positive definite"));
        }
        matrix[i][0] = diagonal.sqrt();
        for j in i + 1..(i + 4).min(size) {
            let mut value = matrix[i][j - i];
            for previous in j.saturating_sub(3)..i {
                value -= matrix[previous][i - previous] * matrix[previous][j - previous];
            }
            matrix[i][j - i] = value / matrix[i][0];
        }
    }
    Ok(matrix)
}

fn solve(factor: &Band, rhs: &[f64]) -> Vec<f64> {
    let mut values = rhs.to_vec();
    for i in 0..values.len() {
        let mut value = values[i];
        for previous in i.saturating_sub(3)..i {
            value -= factor[previous][i - previous] * values[previous];
        }
        values[i] = value / factor[i][0];
    }
    for i in (0..values.len()).rev() {
        let mut value = values[i];
        for next in i + 1..(i + 4).min(values.len()) {
            value -= factor[i][next - i] * values[next];
        }
        values[i] = value / factor[i][0];
    }
    values
}

fn band_value(matrix: &Band, row: usize, column: usize) -> f64 {
    if row <= column {
        matrix[row][column - row]
    } else {
        matrix[column][row - column]
    }
}

fn selected_inverse(factor: &Band) -> Band {
    let size = factor.len();
    let mut inverse = vec![[0.0; 4]; size];
    for i in (0..size).rev() {
        let end = (i + 4).min(size);
        for j in i + 1..end {
            let mut value = 0.0;
            for next in i + 1..end {
                value += factor[i][next - i] * band_value(&inverse, next, j);
            }
            inverse[i][j - i] = -value / factor[i][0];
        }
        let mut diagonal = 1.0 / factor[i][0];
        for next in i + 1..end {
            diagonal -= factor[i][next - i] * inverse[i][next - i];
        }
        inverse[i][0] = diagonal / factor[i][0];
    }
    inverse
}

fn error(message: &str) -> RsomicsError {
    RsomicsError::InvalidInput(message.into())
}

#[cfg(test)]
mod tests {
    use super::{Geometry, Spline};

    #[test]
    fn grouped_gcv_fit_and_linear_extrapolation_match_r_461() {
        let x = [
            4., 4., 7., 7., 8., 9., 10., 10., 10., 11., 11., 12., 12., 12., 12., 13., 13., 13.,
            13., 14., 14., 14., 14., 15., 15., 15., 16., 16., 17., 17., 17., 18., 18., 18., 18.,
            19., 19., 19., 20., 20., 20., 20., 20., 22., 23., 24., 24., 24., 24., 25.,
        ];
        let y = [
            2., 10., 4., 22., 16., 10., 18., 26., 34., 17., 28., 14., 20., 24., 28., 26., 34., 34.,
            46., 26., 36., 60., 80., 20., 26., 54., 32., 40., 32., 40., 50., 42., 56., 76., 84.,
            36., 46., 68., 32., 48., 52., 56., 64., 66., 54., 70., 92., 93., 120., 85.,
        ];
        let fit = Spline::fit(&x, &y).unwrap();
        for (point, expected) in [
            (0., -11.658511327631874),
            (4., 1.6578086081859746),
            (12., 29.050517859962152),
            (25., 84.103687515356086),
            (30., 108.05486196323386),
        ] {
            assert!((fit.predict(point) - expected).abs() < 1e-7);
        }
    }

    #[test]
    fn roughness_preserves_the_upstream_integration_convention() {
        let geometry = Geometry::new(&[0., 1., 2., 3.], &[1., 2., 0., 4.]).unwrap();
        assert!((geometry.penalty[0][0] - 323.676).abs() < 1e-10);
    }
}
