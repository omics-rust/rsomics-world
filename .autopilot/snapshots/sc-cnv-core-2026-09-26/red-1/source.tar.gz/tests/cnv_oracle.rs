mod support;

use rsomics_sc::cnv::{PreparedCounts, PreprocessConfig, ReferenceMode, run_with_observer};
use support::Fixture;

#[test]
fn all_four_profiles_match_every_saved_preclustering_checkpoint() {
    for profile in [
        "single_reference",
        "grouped_bounds",
        "grouped_mean",
        "no_reference",
    ] {
        let fixture = Fixture::load(profile);
        let first = fixture.stage(1);
        let input = PreparedCounts::new(
            first.genes().to_vec(),
            first.cells().to_vec(),
            first.values().to_vec(),
        )
        .unwrap();
        let references = match profile {
            "single_reference" => ReferenceMode::GroupBounds(vec!["normal_a".into()]),
            "grouped_bounds" => {
                ReferenceMode::GroupBounds(vec!["normal_a".into(), "normal_b".into()])
            }
            "grouped_mean" => ReferenceMode::GroupMean(vec!["normal_a".into(), "normal_b".into()]),
            "no_reference" => ReferenceMode::AllCells,
            _ => unreachable!(),
        };
        let config = PreprocessConfig {
            cutoff: 0.1,
            min_cells_per_gene: 3,
            window_length: 101,
            max_centered_threshold: 3.0,
            references,
            max_numeric_bytes: 1_000_000,
        };
        let mut steps = Vec::new();
        let mut observed_final = Vec::new();
        let output = run_with_observer(&input, &config, |stage, actual| {
            steps.push(stage.step());
            let expected = fixture.stage(stage.step());
            assert_eq!(
                actual.genes(),
                expected.genes(),
                "{profile} step {} genes",
                stage.step()
            );
            assert_eq!(
                actual.cells(),
                expected.cells(),
                "{profile} step {} cells",
                stage.step()
            );
            assert_eq!(actual.values().len(), expected.values().len());
            for (index, (a, e)) in actual.values().iter().zip(expected.values()).enumerate() {
                assert!(
                    (a - e).abs() <= 1e-12 + 1e-12 * e.abs(),
                    "{profile} step {} value {index}: actual={a}, expected={e}",
                    stage.step()
                );
            }
            if stage.step() == 14 {
                observed_final.extend_from_slice(actual.values());
            }
            Ok(())
        })
        .unwrap();
        assert_eq!(steps, [1, 2, 3, 4, 8, 9, 10, 11, 12, 14]);
        assert_eq!(output.values(), observed_final);
        assert_eq!(input.state().values(), first.values());
    }
}
