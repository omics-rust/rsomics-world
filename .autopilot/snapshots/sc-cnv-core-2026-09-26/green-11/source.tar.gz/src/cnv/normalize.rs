use super::model::{CnvState, PreparedCounts};
use rsomics_common::{Result, RsomicsError};

pub(crate) fn filter(input: &PreparedCounts, cutoff: f64, minimum: usize) -> Result<CnvState> {
    let source = input.state();
    let gene_count = source.gene_count();
    let cell_count = source.cell_count();
    let mut retained = Vec::new();
    retained
        .try_reserve_exact(gene_count)
        .map_err(allocation_error)?;
    for gene in 0..gene_count {
        let mut total = 0.0;
        let mut detected = 0;
        for cell in 0..cell_count {
            let value = source.values[cell * gene_count + gene];
            total += value;
            detected += usize::from(value > 0.0);
        }
        if !total.is_finite() {
            return Err(RsomicsError::InvalidInput("gene mean is nonfinite".into()));
        }
        if total / cell_count as f64 >= cutoff && detected >= minimum {
            retained.push(gene);
        }
    }
    if retained.is_empty() {
        return Err(RsomicsError::InvalidInput("all genes were filtered".into()));
    }

    let new_count = retained
        .len()
        .checked_mul(cell_count)
        .ok_or_else(|| RsomicsError::InvalidInput("filtered count shape overflows".into()))?;
    let mut values = Vec::new();
    values
        .try_reserve_exact(new_count)
        .map_err(allocation_error)?;
    for cell in 0..cell_count {
        let mut depth = 0.0;
        for &gene in &retained {
            let value = source.values[cell * gene_count + gene];
            depth += value;
            values.push(value);
        }
        if !depth.is_finite() || depth <= 0.0 {
            return Err(RsomicsError::InvalidInput(format!(
                "cell {} has zero or nonfinite post-filter depth",
                source.cells[cell].id
            )));
        }
    }
    let genes = retained.iter().map(|&i| source.genes[i].clone()).collect();
    Ok(CnvState {
        genes,
        cells: source.cells.clone(),
        values,
    })
}

pub(crate) fn normalize_depth(state: &mut CnvState, scratch: &mut [f64]) -> Result<()> {
    let gene_count = state.gene_count();
    let cell_count = state.cell_count();
    for (cell, column) in state.values.chunks_exact(gene_count).enumerate() {
        scratch[cell] = checked_sum(column)?;
    }
    let target = median(&mut scratch[..cell_count])?;
    for column in state.values.chunks_exact_mut(gene_count) {
        let depth = checked_sum(column)?;
        if depth <= 0.0 {
            return Err(RsomicsError::InvalidInput(
                "zero post-filter cell depth".into(),
            ));
        }
        let factor = target / depth;
        if !factor.is_finite() {
            return Err(RsomicsError::InvalidInput(
                "depth scale is nonfinite".into(),
            ));
        }
        for value in column {
            *value *= factor;
            if !value.is_finite() {
                return Err(RsomicsError::InvalidInput(
                    "normalized count is nonfinite".into(),
                ));
            }
        }
    }
    Ok(())
}

pub(crate) fn log2_one_plus(state: &mut CnvState) -> Result<()> {
    for value in &mut state.values {
        *value = (1.0 + *value).log2();
        if !value.is_finite() {
            return Err(RsomicsError::InvalidInput(
                "log-transformed count is nonfinite".into(),
            ));
        }
    }
    Ok(())
}

pub(crate) fn clamp(state: &mut CnvState, threshold: f64) {
    for value in &mut state.values {
        *value = value.clamp(-threshold, threshold);
    }
}

pub(crate) fn inverse_log2(state: &mut CnvState) -> Result<()> {
    for value in &mut state.values {
        *value = value.exp2();
        if !value.is_finite() {
            return Err(RsomicsError::InvalidInput(
                "fold change is nonfinite".into(),
            ));
        }
    }
    Ok(())
}

pub(crate) fn median(values: &mut [f64]) -> Result<f64> {
    if values.is_empty() || values.iter().any(|value| !value.is_finite()) {
        return Err(RsomicsError::InvalidInput(
            "median input is empty or nonfinite".into(),
        ));
    }
    values.sort_unstable_by(f64::total_cmp);
    let middle = values.len() / 2;
    let median = if values.len().is_multiple_of(2) {
        values[middle - 1].midpoint(values[middle])
    } else {
        values[middle]
    };
    if !median.is_finite() {
        return Err(RsomicsError::InvalidInput("median is nonfinite".into()));
    }
    Ok(median)
}

fn checked_sum(values: &[f64]) -> Result<f64> {
    let mut sum = 0.0;
    for &value in values {
        sum += value;
        if !sum.is_finite() {
            return Err(RsomicsError::InvalidInput(
                "numeric reduction is nonfinite".into(),
            ));
        }
    }
    Ok(sum)
}

fn allocation_error(_: std::collections::TryReserveError) -> RsomicsError {
    RsomicsError::InvalidInput("numerical allocation failed".into())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cnv::{Cell, Gene};

    #[test]
    fn median_preserves_two_identical_smallest_subnormals_exactly() {
        let tiny = f64::from_bits(1);
        let mut values = [tiny, tiny];
        assert_eq!(median(&mut values).unwrap().to_bits(), tiny.to_bits());
    }

    #[test]
    fn median_rounds_adjacent_subnormals_to_even_exactly() {
        let mut values = [f64::from_bits(1), f64::from_bits(2)];
        assert_eq!(median(&mut values).unwrap().to_bits(), 2);
    }

    #[test]
    fn clamp_preserves_interior_and_exact_thresholds_and_saturates_both_sides() {
        let mut state = CnvState {
            genes: (0..7)
                .map(|i| Gene {
                    id: format!("g{i}"),
                    chromosome: "chr1".into(),
                    start: i + 1,
                    end: i + 1,
                })
                .collect(),
            cells: vec![Cell {
                id: "c".into(),
                group: "g".into(),
            }],
            values: vec![-2.0, -1.0, -0.25, 0.0, 0.25, 1.0, 2.0],
        };
        clamp(&mut state, 1.0);
        assert_eq!(state.values, [-1.0, -1.0, -0.25, 0.0, 0.25, 1.0, 1.0]);
    }
}
