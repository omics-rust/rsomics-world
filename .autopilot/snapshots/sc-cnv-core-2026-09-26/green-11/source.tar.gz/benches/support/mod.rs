use rsomics_sc::cnv::CnvState;
use std::ffi::OsString;
use std::fs::{File, OpenOptions};
use std::io::{BufWriter, Write};
use std::path::Path;

const REFERENCE_GROUPS: [&str; 2] = ["Microglia/Macrophage", "Oligodendrocytes (non-malignant)"];

pub fn parse_rss_bytes(smaps_rollup: &str) -> Result<u64, String> {
    let mut rss = None;
    for line in smaps_rollup.lines() {
        let mut fields = line.split_whitespace();
        if fields.next() != Some("Rss:") {
            continue;
        }
        if rss.is_some() {
            return Err("duplicate Rss counter".into());
        }
        let value = fields
            .next()
            .ok_or_else(|| "Rss counter is missing".to_string())?
            .parse::<u64>()
            .map_err(|error| format!("invalid Rss counter: {error}"))?;
        if value == 0 || fields.next() != Some("kB") || fields.next().is_some() {
            return Err("Rss counter must be one positive kB value".into());
        }
        rss = Some(
            value
                .checked_mul(1024)
                .ok_or_else(|| "Rss byte count overflows".to_string())?,
        );
    }
    rss.ok_or_else(|| "Rss counter is missing".into())
}

pub fn checked_cpu_micros(seconds: i64, microseconds: i64) -> Result<u64, String> {
    let seconds = u64::try_from(seconds).map_err(|_| "negative CPU seconds".to_string())?;
    let microseconds =
        u64::try_from(microseconds).map_err(|_| "negative CPU microseconds".to_string())?;
    if microseconds >= 1_000_000 {
        return Err("CPU microseconds must be below one second".into());
    }
    seconds
        .checked_mul(1_000_000)
        .and_then(|whole| whole.checked_add(microseconds))
        .ok_or_else(|| "CPU duration overflows microseconds".into())
}

pub fn checked_counter_delta(before: u64, after: u64) -> Result<u64, String> {
    after
        .checked_sub(before)
        .ok_or_else(|| "CPU counter decreased".into())
}

pub fn format_env_value(value: Option<OsString>) -> Result<String, String> {
    let Some(value) = value else {
        return Ok("<unset>".into());
    };
    let value = value
        .into_string()
        .map_err(|_| "environment value is not valid UTF-8".to_string())?;
    if value
        .chars()
        .any(|character| matches!(character, '\t' | '\n' | '\r'))
    {
        return Err("environment value contains a TSV row or field separator".into());
    }
    Ok(value)
}

pub fn write_final_stage(root: &Path, state: &CnvState) -> Result<(), String> {
    write_genes(&root.join("14.genes.tsv"), state)?;
    write_cells(&root.join("14.cells.tsv"), state)?;
    write_expression(&root.join("14.tsv"), state)
}

fn new_writer(path: &Path) -> Result<BufWriter<File>, String> {
    OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)
        .map(BufWriter::new)
        .map_err(|error| format!("{}: {error}", path.display()))
}

fn write_genes(path: &Path, state: &CnvState) -> Result<(), String> {
    let mut writer = new_writer(path)?;
    writeln!(writer, "gene\tchr\tstart\tstop")
        .map_err(|error| format!("{}: {error}", path.display()))?;
    for gene in state.genes() {
        writeln!(
            writer,
            "{}\t{}\t{}\t{}",
            gene.id, gene.chromosome, gene.start, gene.end
        )
        .map_err(|error| format!("{}: {error}", path.display()))?;
    }
    writer
        .flush()
        .map_err(|error| format!("{}: {error}", path.display()))
}

fn write_cells(path: &Path, state: &CnvState) -> Result<(), String> {
    let mut writer = new_writer(path)?;
    writeln!(writer, "cell\tgroup\trole")
        .map_err(|error| format!("{}: {error}", path.display()))?;
    for cell in state.cells() {
        let role = if REFERENCE_GROUPS.contains(&cell.group.as_str()) {
            "reference"
        } else {
            "observation"
        };
        writeln!(writer, "{}\t{}\t{role}", cell.id, cell.group)
            .map_err(|error| format!("{}: {error}", path.display()))?;
    }
    writer
        .flush()
        .map_err(|error| format!("{}: {error}", path.display()))
}

fn write_expression(path: &Path, state: &CnvState) -> Result<(), String> {
    let mut writer = new_writer(path)?;
    write!(writer, "gene").map_err(|error| format!("{}: {error}", path.display()))?;
    for cell in state.cells() {
        write!(writer, "\t{}", cell.id).map_err(|error| format!("{}: {error}", path.display()))?;
    }
    writeln!(writer).map_err(|error| format!("{}: {error}", path.display()))?;
    let gene_count = state.gene_count();
    for (gene_index, gene) in state.genes().iter().enumerate() {
        write!(writer, "{}", gene.id).map_err(|error| format!("{}: {error}", path.display()))?;
        for cell_index in 0..state.cell_count() {
            let value = state.values()[cell_index * gene_count + gene_index];
            write!(writer, "\t{value:.17e}")
                .map_err(|error| format!("{}: {error}", path.display()))?;
        }
        writeln!(writer).map_err(|error| format!("{}: {error}", path.display()))?;
    }
    writer
        .flush()
        .map_err(|error| format!("{}: {error}", path.display()))
}
