#[allow(
    dead_code,
    reason = "only the single-stage loader is needed from the shared ten-stage fixture API"
)]
#[path = "../../tests/support/mod.rs"]
mod oracle;

use oracle::ExpectedStage;
use rsomics_sc::cnv::{CellGroup, CreatedInput, PreparedCounts};
use std::collections::HashSet;
use std::fs::{self, File, OpenOptions};
use std::io::{self, BufWriter, Write};
use std::path::Path;

type Result<T> = std::result::Result<T, String>;

#[derive(Clone, Copy, PartialEq, Eq)]
enum Role {
    Reference,
    Observation,
}

impl Role {
    fn parse(value: &str) -> Result<Self> {
        match value {
            "reference" => Ok(Self::Reference),
            "observation" => Ok(Self::Observation),
            _ => Err(format!("invalid role {value:?}")),
        }
    }
}

struct ExpectedGroup {
    name: String,
    indices: Vec<usize>,
}

pub struct ExpectedCreation {
    stage: ExpectedStage,
    references: Vec<ExpectedGroup>,
    observations: Vec<ExpectedGroup>,
}

impl ExpectedCreation {
    pub fn reference_names(&self) -> Vec<String> {
        self.references
            .iter()
            .map(|group| group.name.clone())
            .collect()
    }
}

fn literal(value: &str) -> Result<()> {
    if value
        .bytes()
        .any(|byte| matches!(byte, b'\t' | b'\n' | b'\r'))
    {
        return Err("literal TSV field contains a separator".into());
    }
    Ok(())
}

fn rows(path: &Path, header: &str, width: usize) -> Result<Vec<Vec<String>>> {
    let text = fs::read_to_string(path).map_err(|error| format!("{}: {error}", path.display()))?;
    let mut lines = text.lines();
    if lines.next() != Some(header) {
        return Err(format!("{}: invalid header", path.display()));
    }
    lines
        .enumerate()
        .map(|(index, line)| {
            let fields: Vec<String> = line.split('\t').map(str::to_owned).collect();
            if fields.len() != width
                || fields
                    .iter()
                    .any(|field| field.is_empty() || literal(field).is_err())
            {
                return Err(format!("{}: invalid row {}", path.display(), index + 2));
            }
            Ok(fields)
        })
        .collect()
}

fn validate_stage(root: &Path, stage: &ExpectedStage) -> Result<()> {
    PreparedCounts::new(
        stage.genes().to_vec(),
        stage.cells().to_vec(),
        stage.values().to_vec(),
    )
    .map_err(|error| format!("{}: invalid expected creation: {error}", root.display()))?;

    let path = root.join("01.genes.tsv");
    let gene_rows = rows(&path, "gene\tchr\tstart\tstop", 4)?;
    for (index, row) in gene_rows.iter().enumerate() {
        for token in [&row[2], &row[3]] {
            if !token.bytes().all(|byte| byte.is_ascii_digit()) {
                return Err(format!(
                    "{}: non-decimal coordinate at row {}",
                    path.display(),
                    index + 2
                ));
            }
        }
    }
    for gene in stage.genes() {
        literal(&gene.id)?;
        literal(&gene.chromosome)?;
    }
    for cell in stage.cells() {
        literal(&cell.id)?;
        literal(&cell.group)?;
    }
    Ok(())
}

pub fn load_expected(full_dir: &Path, maps_path: &Path) -> Result<ExpectedCreation> {
    let stage = ExpectedStage::load(full_dir, 1)?;
    validate_stage(full_dir, &stage)?;
    let cells = stage.cells();

    let path = full_dir.join("01.cells.tsv");
    let cell_rows = rows(&path, "cell\tgroup\trole", 3)?;
    if cell_rows.len() != cells.len() {
        return Err(format!("{}: cell count mismatch", path.display()));
    }
    let mut roles = Vec::with_capacity(cells.len());
    for (index, (row, cell)) in cell_rows.iter().zip(cells).enumerate() {
        if row[0] != cell.id || row[1] != cell.group {
            return Err(format!(
                "{}: identity mismatch at row {}",
                path.display(),
                index + 2
            ));
        }
        roles.push(
            Role::parse(&row[2])
                .map_err(|error| format!("{}: row {}: {error}", path.display(), index + 2))?,
        );
    }

    let map_rows = rows(maps_path, "role\tgroup\tindex\tcell", 4)?;
    let mut references: Vec<ExpectedGroup> = Vec::new();
    let mut observations: Vec<ExpectedGroup> = Vec::new();
    let mut names = HashSet::new();
    let mut covered = vec![false; cells.len()];
    let mut observations_started = false;

    for (row_index, row) in map_rows.iter().enumerate() {
        let fail =
            |message: &str| format!("{}: row {}: {message}", maps_path.display(), row_index + 2);
        let role = Role::parse(&row[0]).map_err(|error| fail(&error))?;
        if !row[2].bytes().all(|byte| byte.is_ascii_digit()) {
            return Err(fail("invalid one-based index"));
        }
        let index = row[2]
            .parse::<usize>()
            .ok()
            .and_then(|value| value.checked_sub(1))
            .filter(|&value| value < cells.len())
            .ok_or_else(|| fail("index out of range"))?;
        if cells[index].id != row[3] || cells[index].group != row[1] || roles[index] != role {
            return Err(fail("cell, group or role mismatch"));
        }
        if covered[index] {
            return Err(fail("duplicate cell coverage"));
        }
        covered[index] = true;

        let groups = match role {
            Role::Reference => {
                if observations_started {
                    return Err(fail("reference follows observation"));
                }
                &mut references
            }
            Role::Observation => {
                observations_started = true;
                &mut observations
            }
        };
        let starts_group = groups.last().is_none_or(|group| group.name != row[1]);
        if starts_group {
            if !names.insert(row[1].clone()) {
                return Err(fail("split or cross-role group"));
            }
            if role == Role::Observation
                && groups
                    .last()
                    .is_some_and(|group| group.name.as_bytes() >= row[1].as_bytes())
            {
                return Err(fail("unordered observation groups"));
            }
            groups.push(ExpectedGroup {
                name: row[1].clone(),
                indices: Vec::new(),
            });
        }
        let group = groups.last_mut().unwrap();
        if group
            .indices
            .last()
            .is_some_and(|&previous| previous >= index)
        {
            return Err(fail("unordered group members"));
        }
        group.indices.push(index);
    }

    if covered.iter().any(|&covered| !covered) {
        return Err(format!("{}: incomplete cell coverage", maps_path.display()));
    }
    Ok(ExpectedCreation {
        stage,
        references,
        observations,
    })
}

fn compare_groups(role: &str, actual: &[CellGroup], expected: &[ExpectedGroup]) -> Result<()> {
    if actual.len() != expected.len() {
        return Err(format!("{role} group count differs"));
    }
    for (index, (actual, expected)) in actual.iter().zip(expected).enumerate() {
        if actual.name() != expected.name || actual.cell_indices() != expected.indices {
            return Err(format!("{role} group differs at position {}", index + 1));
        }
    }
    Ok(())
}

pub fn validate_created(created: &CreatedInput, expected: &ExpectedCreation) -> Result<()> {
    let actual = created.prepared_counts().state();
    if actual.genes() != expected.stage.genes() {
        return Err("creation genes or coordinates differ".into());
    }
    if actual.cells() != expected.stage.cells() {
        return Err("creation cells or groups differ".into());
    }
    if actual.values().len() != expected.stage.values().len() {
        return Err("creation expression length differs".into());
    }
    for (index, (&actual, &expected)) in actual
        .values()
        .iter()
        .zip(expected.stage.values())
        .enumerate()
    {
        if actual.to_bits() != expected.to_bits() {
            return Err(format!("creation count bits differ at offset {index}"));
        }
    }
    compare_groups(
        "reference",
        created.reference_groups(),
        &expected.references,
    )?;
    compare_groups(
        "observation",
        created.observation_groups(),
        &expected.observations,
    )
}

fn emit(path: &Path, write: impl FnOnce(&mut BufWriter<File>) -> io::Result<()>) -> Result<()> {
    let result = (|| {
        let file = OpenOptions::new().write(true).create_new(true).open(path)?;
        let mut writer = BufWriter::new(file);
        write(&mut writer)?;
        writer.flush()
    })();
    result.map_err(|error| format!("{}: {error}", path.display()))
}

pub fn write_creation(new_output_dir: &Path, created: &CreatedInput) -> Result<()> {
    let state = created.prepared_counts().state();
    for gene in state.genes() {
        literal(&gene.id)?;
        literal(&gene.chromosome)?;
    }
    for cell in state.cells() {
        literal(&cell.id)?;
        literal(&cell.group)?;
    }

    let mut roles = vec!["observation"; state.cell_count()];
    for group in created.reference_groups() {
        for &index in group.cell_indices() {
            roles[index] = "reference";
        }
    }
    fs::create_dir(new_output_dir)
        .map_err(|error| format!("{}: {error}", new_output_dir.display()))?;

    emit(&new_output_dir.join("genes.tsv"), |writer| {
        writeln!(writer, "gene\tchr\tstart\tstop")?;
        for gene in state.genes() {
            writeln!(
                writer,
                "{}\t{}\t{}\t{}",
                gene.id, gene.chromosome, gene.start, gene.end
            )?;
        }
        Ok(())
    })?;
    emit(&new_output_dir.join("cells.tsv"), |writer| {
        writeln!(writer, "cell\tgroup\trole")?;
        for (cell, role) in state.cells().iter().zip(&roles) {
            writeln!(writer, "{}\t{}\t{role}", cell.id, cell.group)?;
        }
        Ok(())
    })?;
    emit(&new_output_dir.join("expression.tsv"), |writer| {
        write!(writer, "gene")?;
        for cell in state.cells() {
            write!(writer, "\t{}", cell.id)?;
        }
        writeln!(writer)?;
        for (gene_index, gene) in state.genes().iter().enumerate() {
            write!(writer, "{}", gene.id)?;
            for cell_index in 0..state.cell_count() {
                let value = state.values()[cell_index * state.gene_count() + gene_index];
                write!(writer, "\t{value:.17e}")?;
            }
            writeln!(writer)?;
        }
        Ok(())
    })?;
    emit(&new_output_dir.join("maps.tsv"), |writer| {
        writeln!(writer, "role\tgroup\tindex\tcell")?;
        for (role, groups) in [
            ("reference", created.reference_groups()),
            ("observation", created.observation_groups()),
        ] {
            for group in groups {
                for &index in group.cell_indices() {
                    writeln!(
                        writer,
                        "{role}\t{}\t{}\t{}",
                        group.name(),
                        index + 1,
                        state.cells()[index].id
                    )?;
                }
            }
        }
        Ok(())
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::{AtomicUsize, Ordering};

    static NEXT: AtomicUsize = AtomicUsize::new(0);

    #[test]
    fn writer_error_keeps_partial_file_and_path_context() {
        let root = std::env::temp_dir().join(format!(
            "rsomics-ingestion-writer-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir(&root).unwrap();
        let path = root.join("partial.tsv");
        let error = emit(&path, |writer| {
            writeln!(writer, "partial")?;
            writer.flush()?;
            Err(io::Error::other("injected writer failure"))
        })
        .unwrap_err();
        assert!(error.contains(&path.display().to_string()));
        assert!(error.contains("injected writer failure"));
        assert_eq!(fs::read_to_string(&path).unwrap(), "partial\n");
        fs::remove_dir_all(&root).unwrap();
    }
}
