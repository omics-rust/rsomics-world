#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
#[allow(
    dead_code,
    reason = "the ten-stage fixture API is used by tests, not this benchmark"
)]
#[path = "../tests/support/mod.rs"]
mod fixture_support;

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
mod support;

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
use fixture_support::ExpectedStage;
#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
use nix::sys::resource::{UsageWho, getrusage};
#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
use rsomics_sc::cnv::{self, CnvState, PreparedCounts, PreprocessConfig, ReferenceMode};
#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
use std::fs::{self, File, OpenOptions};
#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
use std::io::{BufWriter, Write};
#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
use std::path::Path;
#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
use std::time::{Duration, Instant};

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
const REFERENCE_GROUPS: [&str; 2] = ["Microglia/Macrophage", "Oligodendrocytes (non-malignant)"];

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
#[derive(Clone, Copy)]
struct CpuSample {
    user_micros: u64,
    system_micros: u64,
}

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
struct Metrics {
    preparation_wall_seconds: f64,
    region_wall_seconds: f64,
    region_user_seconds: f64,
    region_system_seconds: f64,
    region_child_user_seconds: f64,
    region_child_system_seconds: f64,
    baseline_rss_bytes: u64,
}

fn main() {
    if let Err(error) = run_trial() {
        eprintln!("cnv_matched: {error}");
        std::process::exit(1);
    }
}

#[cfg(not(all(target_os = "linux", target_arch = "x86_64")))]
fn run_trial() -> Result<(), String> {
    Err("cnv_matched requires native Linux x86_64".into())
}

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
fn run_trial() -> Result<(), String> {
    let preparation_start = Instant::now();
    let mut args = std::env::args_os().skip(1);
    let case_root = args.next().ok_or_else(usage)?;
    let output_root = args.next().ok_or_else(usage)?;
    if args.next().is_some() {
        return Err(usage());
    }
    let case_root = Path::new(&case_root);
    let output_root = Path::new(&output_root);
    fs::create_dir(output_root).map_err(|error| format!("{}: {error}", output_root.display()))?;

    let first = ExpectedStage::load(case_root, 1)?;
    if (first.genes().len(), first.cells().len()) != (9_939, 184) {
        return Err(format!(
            "stage 1 must be the full accepted example (9939 genes x 184 cells), found {} x {}",
            first.genes().len(),
            first.cells().len()
        ));
    }
    let input = PreparedCounts::new(
        first.genes().to_vec(),
        first.cells().to_vec(),
        first.values().to_vec(),
    )
    .map_err(|error| format!("stage 1 prepared counts: {error}"))?;
    drop(first);
    let config = PreprocessConfig {
        cutoff: 1.0,
        min_cells_per_gene: 3,
        window_length: 101,
        max_centered_threshold: 3.0,
        references: ReferenceMode::GroupBounds(REFERENCE_GROUPS.map(str::to_string).to_vec()),
        max_numeric_bytes: 256 * 1024 * 1024,
    };
    let preparation_end = Instant::now();
    let preparation_wall_seconds = checked_elapsed(preparation_start, preparation_end)?;

    let warm = cnv::run(&input, &config).map_err(|error| format!("warm-up: {error}"))?;
    drop(warm);
    let baseline_rss_bytes = read_current_rss()?;
    let child_before = process_cpu(UsageWho::RUSAGE_CHILDREN)?;
    let self_before = process_cpu(UsageWho::RUSAGE_SELF)?;
    let start = Instant::now();
    let output = cnv::run(&input, &config).map_err(|error| format!("measured call: {error}"))?;
    let end = Instant::now();
    let self_after = process_cpu(UsageWho::RUSAGE_SELF)?;
    let child_after = process_cpu(UsageWho::RUSAGE_CHILDREN)?;
    let region_wall_seconds = checked_elapsed(start, end)?;
    if region_wall_seconds <= 0.0 {
        return Err("measured wall duration must be positive".into());
    }
    let region_user_seconds =
        checked_delta_seconds(self_before.user_micros, self_after.user_micros)?;
    let region_system_seconds =
        checked_delta_seconds(self_before.system_micros, self_after.system_micros)?;
    let region_child_user_seconds =
        checked_delta_seconds(child_before.user_micros, child_after.user_micros)?;
    let region_child_system_seconds =
        checked_delta_seconds(child_before.system_micros, child_after.system_micros)?;
    if region_child_user_seconds != 0.0 || region_child_system_seconds != 0.0 {
        return Err("unexpected child CPU work during the measured call".into());
    }
    let metrics = Metrics {
        preparation_wall_seconds,
        region_wall_seconds,
        region_user_seconds,
        region_system_seconds,
        region_child_user_seconds,
        region_child_system_seconds,
        baseline_rss_bytes,
    };

    let original = ExpectedStage::load(case_root, 1)?;
    verify_exact("original stage 1", input.state(), &original)?;
    drop(original);
    let expected = ExpectedStage::load(case_root, 14)?;
    if (expected.genes().len(), expected.cells().len()) != (8_508, 184) {
        return Err(format!(
            "stage 14 must be the full accepted example (8508 genes x 184 cells), found {} x {}",
            expected.genes().len(),
            expected.cells().len()
        ));
    }
    verify_final(&output, &expected)?;
    support::write_final_stage(output_root, &output)?;
    write_runtime(output_root)?;
    write_metrics(output_root, &metrics)?;
    Ok(())
}

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
fn usage() -> String {
    "usage: cnv_matched CASE_DIRECTORY NEW_OUTPUT_DIRECTORY".into()
}

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
fn checked_elapsed(start: Instant, end: Instant) -> Result<f64, String> {
    let duration: Duration = end
        .checked_duration_since(start)
        .ok_or_else(|| "wall clock reversed".to_string())?;
    let seconds = duration.as_secs_f64();
    if !seconds.is_finite() || seconds < 0.0 {
        return Err("invalid wall duration".into());
    }
    Ok(seconds)
}

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
fn read_current_rss() -> Result<u64, String> {
    let path = "/proc/self/smaps_rollup";
    let text = fs::read_to_string(path).map_err(|error| format!("{path}: {error}"))?;
    support::parse_rss_bytes(&text).map_err(|error| format!("{path}: {error}"))
}

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
fn process_cpu(who: UsageWho) -> Result<CpuSample, String> {
    let usage = getrusage(who).map_err(|error| format!("getrusage: {error}"))?;
    let user = usage.user_time();
    let system = usage.system_time();
    Ok(CpuSample {
        user_micros: support::checked_cpu_micros(user.tv_sec(), user.tv_usec())?,
        system_micros: support::checked_cpu_micros(system.tv_sec(), system.tv_usec())?,
    })
}

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
fn checked_delta_seconds(before: u64, after: u64) -> Result<f64, String> {
    let micros = support::checked_counter_delta(before, after)?;
    Ok(micros as f64 / 1_000_000.0)
}

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
fn verify_exact(label: &str, actual: &CnvState, expected: &ExpectedStage) -> Result<(), String> {
    if actual.genes() != expected.genes() {
        return Err(format!("{label}: gene identities changed"));
    }
    if actual.cells() != expected.cells() {
        return Err(format!("{label}: cell identities changed"));
    }
    if actual.values() != expected.values() {
        return Err(format!("{label}: expression values changed"));
    }
    Ok(())
}

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
fn verify_final(actual: &CnvState, expected: &ExpectedStage) -> Result<(), String> {
    if actual.genes() != expected.genes() {
        return Err("stage 14 gene identities differ from the accepted oracle".into());
    }
    if actual.cells() != expected.cells() {
        return Err("stage 14 cell identities differ from the accepted oracle".into());
    }
    if actual.values().len() != expected.values().len() {
        return Err("stage 14 expression shape differs from the accepted oracle".into());
    }
    for (index, (&observed, &oracle)) in actual.values().iter().zip(expected.values()).enumerate() {
        let absolute = (observed - oracle).abs();
        let tolerance = 1e-12 + 1e-12 * oracle.abs();
        if !observed.is_finite()
            || !oracle.is_finite()
            || !absolute.is_finite()
            || absolute > tolerance
        {
            return Err(format!(
                "stage 14 value {index} differs: actual={observed}, expected={oracle}, abs_delta={absolute}, tolerance={tolerance}"
            ));
        }
    }
    Ok(())
}

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
fn new_writer(path: &Path) -> Result<BufWriter<File>, String> {
    OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)
        .map(BufWriter::new)
        .map_err(|error| format!("{}: {error}", path.display()))
}

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
fn write_metrics(root: &Path, metrics: &Metrics) -> Result<(), String> {
    let path = root.join("metrics.tsv");
    let mut writer = new_writer(&path)?;
    writeln!(writer, "metric\tvalue").map_err(|error| format!("{}: {error}", path.display()))?;
    writeln!(writer, "schema_version\t1")
        .map_err(|error| format!("{}: {error}", path.display()))?;
    writeln!(writer, "implementation\trust")
        .map_err(|error| format!("{}: {error}", path.display()))?;
    for (key, value) in [
        ("preparation_wall_seconds", metrics.preparation_wall_seconds),
        ("region_wall_seconds", metrics.region_wall_seconds),
        ("region_user_seconds", metrics.region_user_seconds),
        ("region_system_seconds", metrics.region_system_seconds),
        (
            "region_child_user_seconds",
            metrics.region_child_user_seconds,
        ),
        (
            "region_child_system_seconds",
            metrics.region_child_system_seconds,
        ),
    ] {
        writeln!(writer, "{key}\t{value:.17e}")
            .map_err(|error| format!("{}: {error}", path.display()))?;
    }
    writeln!(writer, "baseline_rss_bytes\t{}", metrics.baseline_rss_bytes)
        .map_err(|error| format!("{}: {error}", path.display()))?;
    writer
        .flush()
        .map_err(|error| format!("{}: {error}", path.display()))
}

#[cfg(all(target_os = "linux", target_arch = "x86_64"))]
fn write_runtime(root: &Path) -> Result<(), String> {
    let path = root.join("runtime.tsv");
    let mut writer = new_writer(&path)?;
    writeln!(writer, "key\tvalue").map_err(|error| format!("{}: {error}", path.display()))?;
    for (key, value) in [
        ("product", "rsomics-sc"),
        ("product_version", env!("CARGO_PKG_VERSION")),
        ("architecture", "x86_64"),
        ("operating_system", "linux"),
        ("cutoff", "1"),
        ("min_cells_per_gene", "3"),
        ("window_length", "101"),
        ("max_centered_threshold", "3"),
        ("reference_mode", "group_bounds"),
        ("reference_group_1", REFERENCE_GROUPS[0]),
        ("reference_group_2", REFERENCE_GROUPS[1]),
        ("max_numeric_bytes", "268435456"),
        ("native_worker_threads", "1"),
    ] {
        writeln!(writer, "{key}\t{value}")
            .map_err(|error| format!("{}: {error}", path.display()))?;
    }
    for key in [
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "BLIS_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
        "RAYON_NUM_THREADS",
    ] {
        let value = support::format_env_value(std::env::var_os(key))
            .map_err(|error| format!("{key}: {error}"))?;
        writeln!(writer, "{key}\t{value}")
            .map_err(|error| format!("{}: {error}", path.display()))?;
    }
    writer
        .flush()
        .map_err(|error| format!("{}: {error}", path.display()))
}
