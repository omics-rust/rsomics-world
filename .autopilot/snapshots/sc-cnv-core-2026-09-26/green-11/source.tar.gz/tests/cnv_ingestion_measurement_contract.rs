#[path = "../benches/ingestion_support/mod.rs"]
mod ingestion;

use flate2::{Compression, write::GzEncoder};
use ingestion::{ExpectedCreation, load_expected, validate_created, write_creation};
use rsomics_sc::cnv::{CreatedInput, CreationConfig, InputPaths, create_input};
use std::fs;
use std::io::Write;
use std::path::PathBuf;
use std::sync::atomic::{AtomicUsize, Ordering};

static NEXT: AtomicUsize = AtomicUsize::new(0);

struct TempRoot(PathBuf);

impl TempRoot {
    fn new() -> Self {
        let path = std::env::temp_dir().join(format!(
            "rsomics-ingestion-contract-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir(&path).unwrap();
        Self(path)
    }
}

impl Drop for TempRoot {
    fn drop(&mut self) {
        fs::remove_dir_all(&self.0).unwrap();
    }
}

struct Fixture {
    root: TempRoot,
    genes: [&'static str; 2],
    chromosomes: [&'static str; 2],
    cells: Vec<&'static str>,
    groups: Vec<&'static str>,
}

impl Fixture {
    fn new(extra_cell: bool, quoted: bool) -> Self {
        let mut cells = if quoted {
            vec![" c\"a ", "细胞\"obs", "c_b"]
        } else {
            vec!["c_a", "c_obs", "c_b"]
        };
        let mut groups = if quoted {
            vec![" r\"a ", " o\"q ", "r_b"]
        } else {
            vec!["r_a", "o", "r_b"]
        };
        if extra_cell {
            cells.push("c_a2");
            groups.push(groups[0]);
        }
        let fixture = Self {
            root: TempRoot::new(),
            genes: if quoted {
                [" G\"A ", "G_B"]
            } else {
                ["G_A", "G_B"]
            },
            chromosomes: if quoted {
                [" ch\"r1 ", "chr2"]
            } else {
                ["chr1", "chr2"]
            },
            cells,
            groups,
        };
        let expression = fixture.expression();
        fs::write(fixture.path("counts.tsv"), expression).unwrap();
        fs::write(
            fixture.path("positions.tsv"),
            format!(
                "{}\t{}\t10\t20\n{}\t{}\t30\t40\n",
                fixture.genes[0], fixture.chromosomes[0], fixture.genes[1], fixture.chromosomes[1]
            ),
        )
        .unwrap();
        let annotations: String = fixture
            .cells
            .iter()
            .zip(&fixture.groups)
            .map(|(cell, group)| format!("{cell}\t{group}\n"))
            .collect();
        fs::write(fixture.path("annotations.tsv"), annotations).unwrap();
        fixture.write_expected(&fixture.references());
        fixture
    }

    fn path(&self, name: &str) -> PathBuf {
        self.root.0.join(name)
    }

    fn references(&self) -> Vec<String> {
        vec!["r_b".into(), self.groups[0].into()]
    }

    fn expression(&self) -> String {
        let values = [["-0", "2.5"], ["3.75", "4"], ["5.125", "6.5"], ["7", "8"]];
        let mut text = format!("gene\t{}\n", self.cells.join("\t"));
        for (row, gene) in self.genes.iter().enumerate() {
            text.push_str(gene);
            for column in values.iter().take(self.cells.len()) {
                text.push('\t');
                text.push_str(column[row]);
            }
            text.push('\n');
        }
        text
    }

    fn write_expected(&self, references: &[String]) {
        fs::write(self.path("01.tsv"), self.expression()).unwrap();
        fs::write(
            self.path("01.genes.tsv"),
            format!(
                "gene\tchr\tstart\tstop\n{}\t{}\t10\t20\n{}\t{}\t30\t40\n",
                self.genes[0], self.chromosomes[0], self.genes[1], self.chromosomes[1]
            ),
        )
        .unwrap();

        let is_reference = |group: &str| references.iter().any(|name| name == group);
        let mut cells = "cell\tgroup\trole\n".to_owned();
        for (cell, group) in self.cells.iter().zip(&self.groups) {
            let role = if is_reference(group) {
                "reference"
            } else {
                "observation"
            };
            cells.push_str(&format!("{cell}\t{group}\t{role}\n"));
        }
        fs::write(self.path("01.cells.tsv"), cells).unwrap();

        let mut observations: Vec<&str> = self
            .groups
            .iter()
            .copied()
            .filter(|group| !is_reference(group))
            .collect();
        observations.sort_unstable_by(|a, b| a.as_bytes().cmp(b.as_bytes()));
        observations.dedup();
        let mut maps = "role\tgroup\tindex\tcell\n".to_owned();
        for (role, names) in [
            (
                "reference",
                references.iter().map(String::as_str).collect::<Vec<_>>(),
            ),
            ("observation", observations),
        ] {
            for name in names {
                for (index, (&cell, &group)) in self.cells.iter().zip(&self.groups).enumerate() {
                    if group == name {
                        maps.push_str(&format!("{role}\t{name}\t{}\t{cell}\n", index + 1));
                    }
                }
            }
        }
        fs::write(self.path("expected.maps.tsv"), maps).unwrap();
    }

    fn expected(&self) -> Result<ExpectedCreation, String> {
        load_expected(&self.root.0, &self.path("expected.maps.tsv"))
    }

    fn create(&self, references: &[String]) -> CreatedInput {
        let counts = self.path("counts.tsv");
        let positions = self.path("positions.tsv");
        let annotations = self.path("annotations.tsv");
        create_input(
            InputPaths {
                counts: &counts,
                positions: &positions,
                annotations: &annotations,
            },
            &CreationConfig {
                reference_groups: references.to_vec(),
                excluded_chromosomes: Vec::new(),
                min_counts_per_cell: 1.0,
                max_counts_per_cell: f64::INFINITY,
                max_numeric_bytes: 1 << 20,
                max_record_bytes: 1 << 16,
            },
        )
        .unwrap()
    }

    fn replace(&self, file: &str, from: &str, to: &str) {
        let path = self.path(file);
        let text = fs::read_to_string(&path).unwrap();
        assert!(
            text.contains(from),
            "{file}: missing replacement target {from:?}"
        );
        fs::write(path, text.replace(from, to)).unwrap();
    }

    fn assert_roundtrip(&self, references: &[String]) {
        let created = self.create(references);
        validate_created(&created, &self.expected().unwrap()).unwrap();
        let output = self.path("export");
        write_creation(&output, &created).unwrap();

        let mut names: Vec<_> = fs::read_dir(&output)
            .unwrap()
            .map(|entry| entry.unwrap().file_name().into_string().unwrap())
            .collect();
        names.sort();
        assert_eq!(
            names,
            ["cells.tsv", "expression.tsv", "genes.tsv", "maps.tsv"]
        );
        assert_eq!(
            fs::read(output.join("cells.tsv")).unwrap(),
            fs::read(self.path("01.cells.tsv")).unwrap()
        );
        assert_eq!(
            fs::read(output.join("genes.tsv")).unwrap(),
            fs::read(self.path("01.genes.tsv")).unwrap()
        );
        assert_eq!(
            fs::read(output.join("maps.tsv")).unwrap(),
            fs::read(self.path("expected.maps.tsv")).unwrap()
        );

        let reload = self.path("reload");
        fs::create_dir(&reload).unwrap();
        for (from, to) in [
            ("expression.tsv", "01.tsv"),
            ("genes.tsv", "01.genes.tsv"),
            ("cells.tsv", "01.cells.tsv"),
        ] {
            fs::copy(output.join(from), reload.join(to)).unwrap();
        }
        let expected = load_expected(&reload, &output.join("maps.tsv")).unwrap();
        validate_created(&created, &expected).unwrap();
    }
}

#[test]
fn exact_column_major_values_and_reference_request_order() {
    let fixture = Fixture::new(false, false);
    let created = fixture.create(&fixture.references());
    let actual: Vec<_> = created
        .prepared_counts()
        .state()
        .values()
        .iter()
        .map(|value| value.to_bits())
        .collect();
    let wanted: Vec<_> = [-0.0_f64, 2.5, 3.75, 4.0, 5.125, 6.5]
        .into_iter()
        .map(f64::to_bits)
        .collect();
    assert_eq!(actual, wanted);
    assert_eq!(created.reference_groups()[0].name(), "r_b");
    assert_eq!(created.reference_groups()[0].cell_indices(), [2]);
    assert_eq!(created.reference_groups()[1].name(), "r_a");
    assert_eq!(created.reference_groups()[1].cell_indices(), [0]);
    assert_eq!(
        fs::read_to_string(fixture.path("expected.maps.tsv")).unwrap(),
        "role\tgroup\tindex\tcell\nreference\tr_b\t3\tc_b\nreference\tr_a\t1\tc_a\nobservation\to\t2\tc_obs\n"
    );
    fixture.assert_roundtrip(&fixture.references());
}

#[test]
fn noncontiguous_group_members_preserve_cell_column_order() {
    let fixture = Fixture::new(true, false);
    let created = fixture.create(&fixture.references());
    assert_eq!(created.reference_groups()[1].cell_indices(), [0, 3]);
    assert_eq!(
        fs::read_to_string(fixture.path("expected.maps.tsv")).unwrap(),
        "role\tgroup\tindex\tcell\nreference\tr_b\t3\tc_b\nreference\tr_a\t1\tc_a\nreference\tr_a\t4\tc_a2\nobservation\to\t2\tc_obs\n"
    );
    fixture.assert_roundtrip(&fixture.references());
}

#[test]
fn negative_zero_is_not_positive_zero() {
    let fixture = Fixture::new(false, false);
    let created = fixture.create(&fixture.references());
    fixture.replace("01.tsv", "-0", "0");
    let expected = fixture.expected().unwrap();
    let error = validate_created(&created, &expected).unwrap_err();
    assert!(error.contains("bits differ at offset 0"));
}

#[test]
fn one_ulp_difference_is_rejected() {
    let fixture = Fixture::new(false, false);
    let created = fixture.create(&fixture.references());
    let adjacent = f64::from_bits(2.5_f64.to_bits() + 1);
    fixture.replace("01.tsv", "2.5", &format!("{adjacent:.17e}"));
    let error = validate_created(&created, &fixture.expected().unwrap()).unwrap_err();
    assert!(error.contains("bits differ at offset 1"));
}

#[test]
fn changed_actual_reference_request_is_rejected() {
    let fixture = Fixture::new(false, false);
    let created = fixture.create(&["r_a".into(), "r_b".into()]);
    let expected = fixture.expected().unwrap();
    assert_eq!(expected.reference_names(), ["r_b", "r_a"]);
    assert!(
        validate_created(&created, &expected)
            .unwrap_err()
            .contains("reference group")
    );
}

#[test]
fn valid_expected_reference_order_is_preserved_not_sorted() {
    let fixture = Fixture::new(false, false);
    let references = vec!["r_a".into(), "r_b".into()];
    fixture.write_expected(&references);
    assert_eq!(
        fixture.expected().unwrap().reference_names(),
        ["r_a", "r_b"]
    );
    fixture.assert_roundtrip(&references);
}

#[test]
fn literal_quotes_spaces_and_unicode_survive_export() {
    let fixture = Fixture::new(true, true);
    let created = fixture.create(&fixture.references());
    assert_eq!(created.prepared_counts().state().genes()[0].id, " G\"A ");
    assert_eq!(
        created.prepared_counts().state().genes()[0].chromosome,
        " ch\"r1 "
    );
    assert_eq!(created.prepared_counts().state().cells()[0].id, " c\"a ");
    assert_eq!(created.prepared_counts().state().cells()[1].id, "细胞\"obs");
    assert_eq!(created.reference_groups()[1].name(), " r\"a ");
    fixture.assert_roundtrip(&fixture.references());
}

#[test]
fn no_reference_groups_export_all_observation_roles() {
    let fixture = Fixture::new(true, false);
    let references = Vec::new();
    fixture.write_expected(&references);
    let created = fixture.create(&references);
    assert!(created.reference_groups().is_empty());
    assert_eq!(
        created
            .observation_groups()
            .iter()
            .map(|group| group.name())
            .collect::<Vec<_>>(),
        ["o", "r_a", "r_b"]
    );
    fixture.assert_roundtrip(&references);
}

#[test]
fn all_reference_groups_export_no_observation_roles() {
    let fixture = Fixture::new(true, false);
    let references = vec!["r_b".into(), "r_a".into(), "o".into()];
    fixture.write_expected(&references);
    let created = fixture.create(&references);
    assert!(created.observation_groups().is_empty());
    fixture.assert_roundtrip(&references);
}

#[test]
fn missing_expected_files_return_contextual_errors() {
    for name in [
        "01.tsv",
        "01.genes.tsv",
        "01.cells.tsv",
        "expected.maps.tsv",
    ] {
        let fixture = Fixture::new(false, false);
        fs::rename(fixture.path(name), fixture.path(&format!("{name}.saved"))).unwrap();
        let error = fixture.expected().err().unwrap();
        assert!(error.contains(&fixture.path(name).display().to_string()));
    }
}

#[test]
fn zero_depth_expected_cell_is_rejected() {
    let fixture = Fixture::new(false, false);
    fixture.replace("01.tsv", "2.5", "0");
    let error = fixture.expected().err().unwrap();
    assert!(error.contains("zero or nonfinite depth"));
}

#[test]
fn overflowing_depth_expected_cell_is_rejected() {
    let fixture = Fixture::new(false, false);
    fixture.replace("01.tsv", "-0", "1.7976931348623157e308");
    fixture.replace("01.tsv", "2.5", "1.7976931348623157e308");
    let error = fixture.expected().err().unwrap();
    assert!(error.contains("zero or nonfinite depth"));
}

#[test]
fn gzip_magic_input_roundtrips_exact_creation_exports() {
    let fixture = Fixture::new(true, false);
    let path = fixture.path("counts.tsv");
    let original = fs::read(&path).unwrap();
    let mut encoder = GzEncoder::new(Vec::new(), Compression::default());
    encoder.write_all(&original).unwrap();
    let compressed = encoder.finish().unwrap();
    assert!(compressed.starts_with(&[0x1f, 0x8b]));
    fs::write(path, compressed).unwrap();
    fixture.assert_roundtrip(&fixture.references());
}

macro_rules! invalid_map {
    ($name:ident, $body:literal) => {
        #[test]
        fn $name() {
            let fixture = Fixture::new(true, false);
            fs::write(
                fixture.path("expected.maps.tsv"),
                concat!("role\tgroup\tindex\tcell\n", $body),
            )
            .unwrap();
            assert!(fixture.expected().is_err());
        }
    };
}

invalid_map!(
    unknown_map_role,
    "unknown\tr_b\t3\tc_b\nreference\tr_a\t1\tc_a\nreference\tr_a\t4\tc_a2\nobservation\to\t2\tc_obs\n"
);
invalid_map!(
    zero_map_index,
    "reference\tr_b\t0\tc_b\nreference\tr_a\t1\tc_a\nreference\tr_a\t4\tc_a2\nobservation\to\t2\tc_obs\n"
);
invalid_map!(
    out_of_range_map_index,
    "reference\tr_b\t5\tc_b\nreference\tr_a\t1\tc_a\nreference\tr_a\t4\tc_a2\nobservation\to\t2\tc_obs\n"
);
invalid_map!(
    nondecimal_map_index,
    "reference\tr_b\t+3\tc_b\nreference\tr_a\t1\tc_a\nreference\tr_a\t4\tc_a2\nobservation\to\t2\tc_obs\n"
);
invalid_map!(
    wrong_map_cell,
    "reference\tr_b\t3\tc_a\nreference\tr_a\t1\tc_a\nreference\tr_a\t4\tc_a2\nobservation\to\t2\tc_obs\n"
);
invalid_map!(
    wrong_map_group,
    "reference\tr_a\t3\tc_b\nreference\tr_a\t1\tc_a\nreference\tr_a\t4\tc_a2\nobservation\to\t2\tc_obs\n"
);
invalid_map!(
    wrong_map_role,
    "observation\tr_b\t3\tc_b\nreference\tr_a\t1\tc_a\nreference\tr_a\t4\tc_a2\nobservation\to\t2\tc_obs\n"
);
invalid_map!(
    duplicate_map_cell,
    "reference\tr_b\t3\tc_b\nreference\tr_a\t1\tc_a\nreference\tr_a\t1\tc_a\nreference\tr_a\t4\tc_a2\nobservation\to\t2\tc_obs\n"
);
invalid_map!(
    missing_map_cell,
    "reference\tr_b\t3\tc_b\nreference\tr_a\t1\tc_a\nreference\tr_a\t4\tc_a2\n"
);
invalid_map!(
    split_map_group,
    "reference\tr_a\t1\tc_a\nreference\tr_b\t3\tc_b\nreference\tr_a\t4\tc_a2\nobservation\to\t2\tc_obs\n"
);
invalid_map!(
    reference_after_observation,
    "reference\tr_b\t3\tc_b\nobservation\to\t2\tc_obs\nreference\tr_a\t1\tc_a\nreference\tr_a\t4\tc_a2\n"
);
invalid_map!(
    reversed_map_members,
    "reference\tr_b\t3\tc_b\nreference\tr_a\t4\tc_a2\nreference\tr_a\t1\tc_a\nobservation\to\t2\tc_obs\n"
);

#[test]
fn unordered_observation_groups_are_rejected() {
    let fixture = Fixture::new(true, false);
    fixture.write_expected(&[]);
    fs::write(
        fixture.path("expected.maps.tsv"),
        "role\tgroup\tindex\tcell\nobservation\tr_b\t3\tc_b\nobservation\tr_a\t1\tc_a\nobservation\tr_a\t4\tc_a2\nobservation\to\t2\tc_obs\n",
    )
    .unwrap();
    assert!(fixture.expected().is_err());
}

macro_rules! invalid_expected {
    ($name:ident, $file:literal, $from:literal, $to:literal) => {
        #[test]
        fn $name() {
            let fixture = Fixture::new(false, false);
            fixture.replace($file, $from, $to);
            assert!(fixture.expected().is_err());
        }
    };
}

invalid_expected!(
    cell_role_is_checked_independently,
    "01.cells.tsv",
    "c_a\tr_a\treference",
    "c_a\tr_a\tobservation"
);
invalid_expected!(
    unknown_cell_role,
    "01.cells.tsv",
    "c_a\tr_a\treference",
    "c_a\tr_a\tunknown"
);
invalid_expected!(
    empty_cell_group,
    "01.cells.tsv",
    "c_a\tr_a\treference",
    "c_a\t\treference"
);
invalid_expected!(
    literal_tab_in_identity_is_not_unquoted,
    "01.cells.tsv",
    "c_a\tr_a",
    "c\ta\tr_a"
);
invalid_expected!(
    literal_carriage_return_in_identity_is_rejected,
    "01.cells.tsv",
    "c_a\tr_a",
    "c\ra\tr_a"
);
invalid_expected!(
    reversed_coordinates,
    "01.genes.tsv",
    "chr1\t10\t20",
    "chr1\t21\t20"
);
invalid_expected!(
    zero_zero_coordinates,
    "01.genes.tsv",
    "chr1\t10\t20",
    "chr1\t0\t0"
);
invalid_expected!(
    nondecimal_coordinates,
    "01.genes.tsv",
    "chr1\t10\t20",
    "chr1\t+10\t20"
);
invalid_expected!(
    coordinate_overflow,
    "01.genes.tsv",
    "chr1\t10\t20",
    "chr1\t18446744073709551616\t20"
);
invalid_expected!(empty_chromosome, "01.genes.tsv", "G_A\tchr1", "G_A\t");
invalid_expected!(negative_expected_count, "01.tsv", "-0", "-1");
invalid_expected!(nonfinite_expected_count, "01.tsv", "-0", "NaN");
invalid_expected!(
    malformed_expression_width,
    "01.tsv",
    "G_A\t-0\t3.75\t5.125",
    "G_A\t-0\t3.75"
);

#[test]
fn changed_gene_identity_is_rejected() {
    let fixture = Fixture::new(false, false);
    let created = fixture.create(&fixture.references());
    fixture.replace("01.genes.tsv", "G_A", "G_X");
    fixture.replace("01.tsv", "G_A", "G_X");
    assert!(validate_created(&created, &fixture.expected().unwrap()).is_err());
}

#[test]
fn changed_chromosome_is_rejected() {
    let fixture = Fixture::new(false, false);
    let created = fixture.create(&fixture.references());
    fixture.replace("01.genes.tsv", "chr1", "chrX");
    assert!(validate_created(&created, &fixture.expected().unwrap()).is_err());
}

#[test]
fn changed_valid_coordinate_is_rejected() {
    let fixture = Fixture::new(false, false);
    let created = fixture.create(&fixture.references());
    fixture.replace("01.genes.tsv", "chr1\t10\t20", "chr1\t11\t20");
    assert!(validate_created(&created, &fixture.expected().unwrap()).is_err());
}

#[test]
fn changed_cell_identity_is_rejected() {
    let fixture = Fixture::new(false, false);
    let created = fixture.create(&fixture.references());
    for file in ["01.cells.tsv", "01.tsv", "expected.maps.tsv"] {
        fixture.replace(file, "c_a", "c_x");
    }
    assert!(validate_created(&created, &fixture.expected().unwrap()).is_err());
}

#[test]
fn changed_cell_group_is_rejected() {
    let fixture = Fixture::new(false, false);
    let created = fixture.create(&fixture.references());
    for file in ["01.cells.tsv", "expected.maps.tsv"] {
        fixture.replace(file, "r_a", "r_x");
    }
    assert!(validate_created(&created, &fixture.expected().unwrap()).is_err());
}

#[test]
fn changed_gene_row_order_is_rejected() {
    let fixture = Fixture::new(false, false);
    let created = fixture.create(&fixture.references());
    fs::write(
        fixture.path("01.genes.tsv"),
        "gene\tchr\tstart\tstop\nG_B\tchr2\t30\t40\nG_A\tchr1\t10\t20\n",
    )
    .unwrap();
    fs::write(
        fixture.path("01.tsv"),
        "gene\tc_a\tc_obs\tc_b\nG_B\t2.5\t4\t6.5\nG_A\t-0\t3.75\t5.125\n",
    )
    .unwrap();
    assert!(validate_created(&created, &fixture.expected().unwrap()).is_err());
}

#[test]
fn changed_cell_column_order_is_rejected() {
    let fixture = Fixture::new(false, false);
    let created = fixture.create(&fixture.references());
    fs::write(
        fixture.path("01.cells.tsv"),
        "cell\tgroup\trole\nc_obs\to\tobservation\nc_a\tr_a\treference\nc_b\tr_b\treference\n",
    )
    .unwrap();
    fs::write(
        fixture.path("01.tsv"),
        "gene\tc_obs\tc_a\tc_b\nG_A\t3.75\t-0\t5.125\nG_B\t4\t2.5\t6.5\n",
    )
    .unwrap();
    fs::write(
        fixture.path("expected.maps.tsv"),
        "role\tgroup\tindex\tcell\nreference\tr_b\t3\tc_b\nreference\tr_a\t2\tc_a\nobservation\to\t1\tc_obs\n",
    ).unwrap();
    assert!(validate_created(&created, &fixture.expected().unwrap()).is_err());
}

#[test]
fn existing_empty_export_directory_is_rejected() {
    let fixture = Fixture::new(false, false);
    let created = fixture.create(&fixture.references());
    let output = fixture.path("existing");
    fs::create_dir(&output).unwrap();
    assert!(write_creation(&output, &created).is_err());
    assert_eq!(fs::read_dir(output).unwrap().count(), 0);
}

#[test]
fn existing_nonempty_export_directory_is_preserved() {
    let fixture = Fixture::new(false, false);
    let created = fixture.create(&fixture.references());
    let output = fixture.path("existing");
    fs::create_dir(&output).unwrap();
    fs::write(output.join("sentinel"), "keep").unwrap();
    assert!(write_creation(&output, &created).is_err());
    assert_eq!(fs::read_to_string(output.join("sentinel")).unwrap(), "keep");
    assert_eq!(fs::read_dir(output).unwrap().count(), 1);
}

#[test]
fn repeated_export_preserves_all_previous_bytes() {
    let fixture = Fixture::new(false, false);
    let created = fixture.create(&fixture.references());
    let output = fixture.path("export");
    write_creation(&output, &created).unwrap();
    let files = ["expression.tsv", "genes.tsv", "cells.tsv", "maps.tsv"];
    let before: Vec<_> = files
        .iter()
        .map(|file| fs::read(output.join(file)).unwrap())
        .collect();
    assert!(write_creation(&output, &created).is_err());
    let after: Vec<_> = files
        .iter()
        .map(|file| fs::read(output.join(file)).unwrap())
        .collect();
    assert_eq!(before, after);
}

#[test]
fn missing_export_parent_returns_contextual_error() {
    let fixture = Fixture::new(false, false);
    let created = fixture.create(&fixture.references());
    let output = fixture.path("missing").join("export");
    let error = write_creation(&output, &created).unwrap_err();
    assert!(error.contains(&output.display().to_string()));
    assert!(!fixture.path("missing").exists());
}

macro_rules! separator_export {
    ($name:ident, $(($file:literal, $from:literal, $to:literal)),+ $(,)?) => {
        #[test]
        fn $name() {
            let fixture = Fixture::new(false, false);
            $(fixture.replace($file, $from, $to);)+
            let created = fixture.create(&fixture.references());
            let output = fixture.path("export");
            assert!(write_creation(&output, &created).is_err());
            assert!(!output.exists());
        }
    };
}

separator_export!(
    gene_separator_is_rejected_before_export_creation,
    ("counts.tsv", "G_A", "G\rA"),
    ("positions.tsv", "G_A", "G\rA")
);
separator_export!(
    chromosome_separator_is_rejected_before_export_creation,
    ("positions.tsv", "chr1", "ch\rr1")
);
separator_export!(
    cell_separator_is_rejected_before_export_creation,
    ("counts.tsv", "c_a", "c\ra"),
    ("annotations.tsv", "c_a", "c\ra")
);

#[test]
fn group_separator_is_rejected_before_export_creation() {
    let fixture = Fixture::new(false, false);
    fixture.replace("annotations.tsv", "r_a", "r\ra");
    let created = fixture.create(&["r_b".into(), "r\ra".into()]);
    let output = fixture.path("export");
    assert!(write_creation(&output, &created).is_err());
    assert!(!output.exists());
}
