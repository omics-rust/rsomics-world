mod support;

#[path = "../benches/support/mod.rs"]
mod measurement;

use rsomics_sc::cnv::{Cell, Gene, PreparedCounts};
use std::ffi::OsString;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};
use support::{ExpectedStage, Fixture};

static NEXT_ROOT: AtomicUsize = AtomicUsize::new(0);

struct TempRoot(PathBuf);

impl TempRoot {
    fn new() -> Self {
        let sequence = NEXT_ROOT.fetch_add(1, Ordering::Relaxed);
        let path = std::env::temp_dir().join(format!(
            "rsomics-sc-cnv-measurement-{}-{sequence}",
            std::process::id()
        ));
        fs::create_dir(&path).unwrap();
        Self(path)
    }

    fn path(&self) -> &Path {
        &self.0
    }

    fn write_stage(&self, step: u8) {
        let stem = format!("{step:02}");
        fs::write(
            self.0.join(format!("{stem}.genes.tsv")),
            "gene\tchr\tstart\tstop\nG_A\tchr1\t10\t20\nG_B\tchr2\t30\t40\n",
        )
        .unwrap();
        fs::write(
            self.0.join(format!("{stem}.cells.tsv")),
            "cell\tgroup\trole\nC_A\tnormal\treference\nC_B\ttumor\tobservation\n",
        )
        .unwrap();
        fs::write(
            self.0.join(format!("{stem}.tsv")),
            "gene\tC_A\tC_B\nG_A\t1.25\t3.75\nG_B\t2.5\t4\n",
        )
        .unwrap();
    }
}

impl Drop for TempRoot {
    fn drop(&mut self) {
        fs::remove_dir_all(&self.0).unwrap();
    }
}

#[test]
fn one_stage_loader_accepts_a_directory_without_the_other_nine_stages() {
    let root = TempRoot::new();
    root.write_stage(1);

    let stage = ExpectedStage::load(root.path(), 1).unwrap();
    assert_eq!(stage.genes()[0].id, "G_A");
    assert_eq!(stage.genes()[1].id, "G_B");
    assert_eq!(stage.cells()[0].id, "C_A");
    assert_eq!(stage.cells()[1].group, "tumor");
    assert_eq!(stage.values(), &[1.25, 2.5, 3.75, 4.0]);
}

#[test]
fn ten_stage_fixture_entry_still_loads_the_final_checkpoint() {
    let fixture = Fixture::load("single_reference");
    assert_eq!(fixture.stage(14).genes()[0].id, "G001");
}

#[test]
fn one_stage_loader_rejects_unrecognized_steps_even_if_files_exist() {
    let root = TempRoot::new();
    root.write_stage(5);

    assert!(ExpectedStage::load(root.path(), 0).is_err());
    assert!(ExpectedStage::load(root.path(), 5).is_err());
}

#[test]
fn one_stage_loader_reports_missing_file_and_malformed_row() {
    let root = TempRoot::new();
    root.write_stage(1);
    fs::remove_file(root.path().join("01.cells.tsv")).unwrap();

    let missing = ExpectedStage::load(root.path(), 1).err().unwrap();
    assert!(missing.contains("01.cells.tsv"), "{missing}");

    root.write_stage(1);
    fs::write(
        root.path().join("01.tsv"),
        "gene\tC_A\tC_B\nG_A\t1.25\nG_B\t2.5\t4\n",
    )
    .unwrap();
    let malformed = ExpectedStage::load(root.path(), 1).err().unwrap();
    assert!(malformed.contains("01.tsv"), "{malformed}");
}

#[test]
fn rss_requires_one_positive_kib_counter() {
    assert_eq!(
        measurement::parse_rss_bytes("Size: 20 kB\nRss: 17 kB\nPss: 15 kB\n").unwrap(),
        17_408
    );
    for text in [
        "",
        "Size: 1 kB\n",
        "Rss: 1 MB\n",
        "Rss: 0 kB\n",
        "Rss: 1 kB\nRss: 2 kB\n",
        "Rss: 17 kB trailing\n",
        "Rss: 18446744073709551615 kB\n",
        "Rss: no-number kB\n",
    ] {
        assert!(measurement::parse_rss_bytes(text).is_err(), "{text}");
    }
}

#[test]
fn cpu_units_and_deltas_are_checked() {
    assert_eq!(measurement::checked_cpu_micros(2, 3).unwrap(), 2_000_003);
    assert!(measurement::checked_cpu_micros(-1, 0).is_err());
    assert!(measurement::checked_cpu_micros(0, -1).is_err());
    assert!(measurement::checked_cpu_micros(0, 1_000_000).is_err());
    assert!(measurement::checked_cpu_micros(i64::MAX, 0).is_err());
    assert_eq!(measurement::checked_counter_delta(7, 12).unwrap(), 5);
    assert_eq!(measurement::checked_counter_delta(7, 7).unwrap(), 0);
    assert!(measurement::checked_counter_delta(12, 7).is_err());
}

#[test]
fn absent_environment_value_is_marked_unset() {
    assert_eq!(measurement::format_env_value(None).unwrap(), "<unset>");
}

#[test]
fn valid_environment_value_is_preserved() {
    assert_eq!(
        measurement::format_env_value(Some(OsString::from("1"))).unwrap(),
        "1"
    );
}

#[cfg(unix)]
#[test]
fn present_non_utf8_environment_value_is_rejected() {
    use std::os::unix::ffi::OsStringExt;

    let value = OsString::from_vec(vec![0xff]);
    assert!(measurement::format_env_value(Some(value)).is_err());
}

#[test]
fn environment_value_cannot_break_runtime_tsv_rows() {
    for value in ["1\t2", "1\n2", "1\r2"] {
        assert!(
            measurement::format_env_value(Some(OsString::from(value))).is_err(),
            "{value:?}"
        );
    }
}

#[test]
fn final_export_keeps_identities_roles_and_column_major_values() {
    let root = TempRoot::new();
    let state = PreparedCounts::new(
        vec![
            Gene {
                id: "G_A".into(),
                chromosome: "chr1".into(),
                start: 10,
                end: 20,
            },
            Gene {
                id: "G_B".into(),
                chromosome: "chr2".into(),
                start: 30,
                end: 40,
            },
        ],
        vec![
            Cell {
                id: "C_A".into(),
                group: "Microglia/Macrophage".into(),
            },
            Cell {
                id: "C_B".into(),
                group: "tumor".into(),
            },
            Cell {
                id: "C_C".into(),
                group: "Oligodendrocytes (non-malignant)".into(),
            },
        ],
        vec![1.234_567_890_123_456_7, 2.5, 3.75, 4.0, 5.125, 6.5],
    )
    .unwrap();

    measurement::write_final_stage(root.path(), state.state()).unwrap();

    assert_eq!(
        fs::read_to_string(root.path().join("14.genes.tsv")).unwrap(),
        "gene\tchr\tstart\tstop\nG_A\tchr1\t10\t20\nG_B\tchr2\t30\t40\n"
    );
    assert_eq!(
        fs::read_to_string(root.path().join("14.cells.tsv")).unwrap(),
        "cell\tgroup\trole\nC_A\tMicroglia/Macrophage\treference\nC_B\ttumor\tobservation\nC_C\tOligodendrocytes (non-malignant)\treference\n"
    );

    let table = fs::read_to_string(root.path().join("14.tsv")).unwrap();
    let mut rows = table.lines();
    assert_eq!(rows.next(), Some("gene\tC_A\tC_B\tC_C"));
    for (line, expected_gene, expected_values) in [
        (
            rows.next().unwrap(),
            "G_A",
            [1.234_567_890_123_456_7, 3.75, 5.125],
        ),
        (rows.next().unwrap(), "G_B", [2.5, 4.0, 6.5]),
    ] {
        let fields = line.split('\t').collect::<Vec<_>>();
        assert_eq!(fields.len(), 4);
        assert_eq!(fields[0], expected_gene);
        let observed = fields[1..]
            .iter()
            .map(|value| value.parse::<f64>().unwrap())
            .collect::<Vec<_>>();
        assert_eq!(observed, expected_values);
    }
    assert!(rows.next().is_none());
}
