# inferCNV oracle tests

Default tests use the small, checked-in synthetic fixtures. The shipped-example
conformance test is opt-in and requires a separately acquired, verified oracle
bundle; no large fixture or upstream package code is stored in this repository.

After verifying the accepted receipt, artifact and bundle manifest, set
`RSOMICS_INFER_CNV_ORACLE_ROOT` to the extracted `shipped-bundle` directory
containing `subset/` and `full/`. Then run:

```sh
cargo test --locked --features external-infercnv-oracle --test cnv_external_oracle -- --nocapture
```

Selecting this target without the environment variable or required data fails.
The test compares stages 1, 2, 3, 4, 8, 9, 10, 11, 12 and 14 for both cases
using `abs(actual - expected) <= 1e-12 + 1e-12 * abs(expected)` and prints
per-stage maximum absolute and scaled errors. It tests only the prepared-count
pre-clustering core, not raw-input parsing, downstream inferCNV workflow,
biological truth or performance.

## Private prepared-input measurement

The `infercnv-measurement` feature is non-default and adds no product command or
public API. Its portable contract tests cover the single-stage fixture reader,
checked resource-counter helpers and final TSV export:

```sh
cargo test --locked --features infercnv-measurement --test cnv_measurement_contract -- --nocapture
```

The `cnv_matched` target is a harness-free executable. It is compiled explicitly
with `cargo check --locked --all-features --bench cnv_matched`; do not use
`cargo test --all-targets --all-features` to run it as an ordinary test. Actual
measurement runs only on native Linux x86_64 and requires the accepted full
example case directory with `01.*` and `14.*` stage files. Invoke the built
release executable directly with two arguments:

```text
cnv_matched CASE_DIRECTORY NEW_OUTPUT_DIRECTORY
```

The output directory must not exist. Each successful process writes
`metrics.tsv`, `runtime.tsv`, `14.tsv`, `14.genes.tsv` and `14.cells.tsv`.
`metrics.tsv` separates preparation wall time, timed-region wall/self/child CPU
and current pre-region RSS; it does not report lifetime peak memory. The
external matched-trial driver owns startup limits, whole-process GNU time,
fresh-process trial ordering, pinned input checks and final cross-language
statistics. These measurements concern the accepted prepared-input step-14
preprocessing path only, not downstream CNV calling or larger cohorts.
