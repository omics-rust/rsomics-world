pub mod support;

use rsomics_sc::cnv::{
    CnvState, CreationConfig, InputPaths, PreparedCounts, PreprocessConfig, ReferenceMode,
    create_input, run_with_observer,
};
use std::path::PathBuf;
use support::{ExpectedStage, Fixture};

const STEPS: [u8; 10] = [1, 2, 3, 4, 8, 9, 10, 11, 12, 14];

#[test]
fn synthetic_raw_inputs_match_grouped_and_no_reference_oracles() {
    let root = std::env::var_os("RSOMICS_INFER_CNV_ORACLE_ROOT")
        .filter(|value| !value.is_empty())
        .expect("RSOMICS_INFER_CNV_ORACLE_ROOT is required");
    let root = PathBuf::from(root).parent().unwrap().join("bundle");
    let counts = root.join("inputs/counts.tsv");
    let positions = root.join("inputs/gene_order.tsv");
    let annotations = root.join("inputs/annotations.tsv");
    for profile in ["grouped_bounds", "no_reference"] {
        let fixture = Fixture::load_from_root(&root.join(profile)).unwrap();
        let reference_names = if profile == "grouped_bounds" {
            vec!["normal_a".to_owned(), "normal_b".to_owned()]
        } else {
            vec![]
        };
        let creation = CreationConfig {
            reference_groups: reference_names.clone(),
            excluded_chromosomes: vec!["chrX".into(), "chrY".into(), "chrM".into()],
            min_counts_per_cell: 1.0,
            max_counts_per_cell: f64::INFINITY,
            max_numeric_bytes: 1_000_000,
            max_record_bytes: 1024 * 1024,
        };
        let created = create_input(
            InputPaths {
                counts: &counts,
                positions: &positions,
                annotations: &annotations,
            },
            &creation,
        )
        .unwrap();
        let first = fixture.stage(1);
        assert_eq!(created.prepared_counts().state().genes(), first.genes());
        assert_eq!(created.prepared_counts().state().cells(), first.cells());
        assert_eq!(created.prepared_counts().state().values(), first.values());
        assert_eq!(created.reference_groups().len(), reference_names.len());
        let mut observation_names: Vec<_> = first
            .cells()
            .iter()
            .filter(|cell| !reference_names.contains(&cell.group))
            .map(|cell| cell.group.clone())
            .collect();
        observation_names.sort();
        observation_names.dedup();
        assert_eq!(created.observation_groups().len(), observation_names.len());
        for (actual, name) in created
            .reference_groups()
            .iter()
            .zip(&reference_names)
            .chain(created.observation_groups().iter().zip(&observation_names))
        {
            assert_eq!(actual.name(), name);
            let expected: Vec<_> = first
                .cells()
                .iter()
                .enumerate()
                .filter_map(|(index, cell)| (cell.group == *name).then_some(index))
                .collect();
            assert_eq!(actual.cell_indices(), expected);
        }
        let config = PreprocessConfig {
            cutoff: 0.1,
            min_cells_per_gene: 3,
            window_length: 101,
            max_centered_threshold: 3.0,
            references: if reference_names.is_empty() {
                ReferenceMode::AllCells
            } else {
                ReferenceMode::GroupBounds(reference_names)
            },
            max_numeric_bytes: 1_000_000,
        };
        let mut steps = Vec::new();
        let output = run_with_observer(created.prepared_counts(), &config, |stage, actual| {
            steps.push(stage.step());
            let (delta, scaled) = compare_stage(profile, stage.step(), actual, fixture.stage(stage.step()));
            eprintln!("raw oracle {profile} step {}: max_abs_delta={delta:.17e} max_scaled_delta={scaled:.17e}", stage.step());
            Ok(())
        }).unwrap();
        assert_eq!(steps, STEPS);
        compare_stage(profile, 14, &output, fixture.stage(14));
    }
}

#[test]
fn canonical_raw_inputs_preserve_creation_maps_and_downstream_checkpoints() {
    let root = std::env::var_os("RSOMICS_INFER_CNV_ORACLE_ROOT")
        .filter(|value| !value.is_empty())
        .expect("RSOMICS_INFER_CNV_ORACLE_ROOT is required");
    let root = PathBuf::from(root);
    let references = vec![
        "Microglia/Macrophage".to_owned(),
        "Oligodendrocytes (non-malignant)".to_owned(),
    ];
    let positions = root.join("inputs/gencode_downsampled.EXAMPLE_ONLY_DONT_REUSE.txt");
    let annotations = root.join("inputs/oligodendroglioma_annotations_downsampled.txt");
    for case in ["subset", "full"] {
        let fixture = Fixture::load_from_root(&root.join(case)).unwrap();
        let counts = root.join(format!("inputs/canonical-{case}.tsv"));
        let creation = CreationConfig {
            reference_groups: references.clone(),
            excluded_chromosomes: vec!["chrX".into(), "chrY".into(), "chrM".into()],
            min_counts_per_cell: 1.0,
            max_counts_per_cell: f64::INFINITY,
            max_numeric_bytes: 256 * 1024 * 1024,
            max_record_bytes: 1024 * 1024,
        };
        let created = create_input(
            InputPaths {
                counts: &counts,
                positions: &positions,
                annotations: &annotations,
            },
            &creation,
        )
        .unwrap_or_else(|error| panic!("{case} raw input: {error}"));
        let first = fixture.stage(1);
        assert_eq!(created.prepared_counts().state().genes(), first.genes());
        assert_eq!(created.prepared_counts().state().cells(), first.cells());
        assert_eq!(created.prepared_counts().state().values(), first.values());
        assert_eq!(created.reference_groups().len(), references.len());
        let mut groups = Vec::new();
        for cell in first.cells() {
            if !references.contains(&cell.group) && !groups.contains(&cell.group) {
                groups.push(cell.group.clone());
            }
        }
        groups.sort();
        assert_eq!(created.observation_groups().len(), groups.len());
        for (actual, expected) in created
            .reference_groups()
            .iter()
            .zip(&references)
            .chain(created.observation_groups().iter().zip(&groups))
        {
            assert_eq!(actual.name(), expected);
            let expected_indices: Vec<_> = first
                .cells()
                .iter()
                .enumerate()
                .filter_map(|(index, cell)| (cell.group == *expected).then_some(index))
                .collect();
            assert_eq!(actual.cell_indices(), expected_indices);
        }
        let config = PreprocessConfig {
            cutoff: 1.0,
            min_cells_per_gene: 3,
            window_length: 101,
            max_centered_threshold: 3.0,
            references: ReferenceMode::GroupBounds(references.clone()),
            max_numeric_bytes: 256 * 1024 * 1024,
        };
        let mut steps = Vec::new();
        let output = run_with_observer(created.prepared_counts(), &config, |stage, actual| {
            steps.push(stage.step());
            let (delta, scaled) = compare_stage(case, stage.step(), actual, fixture.stage(stage.step()));
            eprintln!("raw oracle {case} step {}: max_abs_delta={delta:.17e} max_scaled_delta={scaled:.17e}", stage.step());
            Ok(())
        }).unwrap();
        assert_eq!(steps, STEPS);
        compare_stage(case, 14, &output, fixture.stage(14));
    }
}

fn compare_stage(case: &str, step: u8, actual: &CnvState, expected: &ExpectedStage) -> (f64, f64) {
    assert_eq!(
        actual.gene_count(),
        expected.genes().len(),
        "{case} step {step} gene count"
    );
    assert_eq!(
        actual.cell_count(),
        expected.cells().len(),
        "{case} step {step} cell count"
    );
    assert_eq!(actual.genes(), expected.genes(), "{case} step {step} genes");
    assert_eq!(actual.cells(), expected.cells(), "{case} step {step} cells");
    assert_eq!(
        actual.values().len(),
        expected.values().len(),
        "{case} step {step} value count"
    );

    let mut max_abs = 0.0_f64;
    let mut max_scaled = 0.0_f64;
    for (index, (&observed, &oracle)) in actual.values().iter().zip(expected.values()).enumerate() {
        assert!(
            observed.is_finite() && oracle.is_finite(),
            "{case} step {step} value {index} is nonfinite: actual={observed}, expected={oracle}"
        );
        let delta = (observed - oracle).abs();
        let tolerance = 1e-12 + 1e-12 * oracle.abs();
        assert!(
            delta.is_finite() && delta <= tolerance,
            "{case} step {step} value {index}: actual={observed}, expected={oracle}, abs_delta={delta}, tolerance={tolerance}"
        );
        max_abs = max_abs.max(delta);
        max_scaled = max_scaled.max(delta / tolerance);
    }
    (max_abs, max_scaled)
}

#[test]
fn shipped_cases_match_every_saved_preclustering_checkpoint() {
    let root = std::env::var_os("RSOMICS_INFER_CNV_ORACLE_ROOT")
        .filter(|value| !value.is_empty())
        .expect("RSOMICS_INFER_CNV_ORACLE_ROOT is required");
    let root = PathBuf::from(root);

    for case in ["subset", "full"] {
        let case_root = root.join(case);
        let fixture =
            Fixture::load_from_root(&case_root).unwrap_or_else(|error| panic!("{case}: {error}"));
        let first = fixture.stage(1);
        let input = PreparedCounts::new(
            first.genes().to_vec(),
            first.cells().to_vec(),
            first.values().to_vec(),
        )
        .unwrap_or_else(|error| panic!("{case}: prepared counts: {error}"));
        let config = PreprocessConfig {
            cutoff: 1.0,
            min_cells_per_gene: 3,
            window_length: 101,
            max_centered_threshold: 3.0,
            references: ReferenceMode::GroupBounds(vec![
                "Microglia/Macrophage".into(),
                "Oligodendrocytes (non-malignant)".into(),
            ]),
            max_numeric_bytes: 256 * 1024 * 1024,
        };
        let mut steps = Vec::new();
        let mut observed_final = None;
        let output = run_with_observer(&input, &config, |stage, actual| {
            let step = stage.step();
            steps.push(step);
            let expected = fixture.stage(step);
            let (max_abs, max_scaled) = compare_stage(case, step, actual, expected);
            eprintln!(
                "external oracle {case} step {step}: max_abs_delta={max_abs:.17e} max_scaled_delta={max_scaled:.17e}"
            );
            if step == 14 {
                observed_final = Some((
                    actual.genes().to_vec(),
                    actual.cells().to_vec(),
                    actual.values().to_vec(),
                ));
            }
            Ok(())
        })
        .unwrap_or_else(|error| panic!("{case}: native pipeline: {error}"));

        assert_eq!(steps.as_slice(), STEPS.as_slice(), "{case} stage sequence");
        let (observed_genes, observed_cells, observed_values) =
            observed_final.expect("stage 14 must be observed");
        assert_eq!(
            output.genes(),
            observed_genes.as_slice(),
            "{case} final genes"
        );
        assert_eq!(
            output.cells(),
            observed_cells.as_slice(),
            "{case} final cells"
        );
        assert_eq!(output.gene_count(), observed_genes.len());
        assert_eq!(output.cell_count(), observed_cells.len());
        assert_eq!(
            output.values(),
            observed_values.as_slice(),
            "{case} final values"
        );
        compare_stage(case, 14, &output, fixture.stage(14));

        assert_eq!(input.state().genes(), first.genes(), "{case} input genes");
        assert_eq!(input.state().cells(), first.cells(), "{case} input cells");
        assert_eq!(input.state().gene_count(), first.genes().len());
        assert_eq!(input.state().cell_count(), first.cells().len());
        assert_eq!(
            input.state().values(),
            first.values(),
            "{case} input values"
        );
    }
}
