mod support;

use rsomics_sc::cnv::{Cell, Gene};
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};
use support::Fixture;

const STEPS: [u8; 10] = [1, 2, 3, 4, 8, 9, 10, 11, 12, 14];
static NEXT_FIXTURE: AtomicUsize = AtomicUsize::new(0);

struct FixtureRoot(PathBuf);

impl FixtureRoot {
    fn new() -> Self {
        let sequence = NEXT_FIXTURE.fetch_add(1, Ordering::Relaxed);
        let root = std::env::temp_dir().join(format!(
            "rsomics-sc-cnv-reader-{}-{sequence}",
            std::process::id()
        ));
        fs::create_dir(&root).unwrap();
        for step in STEPS {
            let stem = format!("{step:02}");
            fs::write(
                root.join(format!("{stem}.genes.tsv")),
                "gene\tchr\tstart\tstop\nG1\tchr1\t1\t2\n",
            )
            .unwrap();
            fs::write(
                root.join(format!("{stem}.cells.tsv")),
                "cell\tgroup\trole\nC1\tnormal\treference\n",
            )
            .unwrap();
            fs::write(root.join(format!("{stem}.tsv")), "gene\tC1\nG1\t1\n").unwrap();
        }
        Self(root)
    }

    fn path(&self) -> &Path {
        &self.0
    }

    fn replace(&self, filename: &str, contents: &str) {
        fs::write(self.0.join(filename), contents).unwrap();
    }
}

impl Drop for FixtureRoot {
    fn drop(&mut self) {
        fs::remove_dir_all(&self.0).unwrap();
    }
}

fn load_error(root: &FixtureRoot) -> String {
    Fixture::load_from_root(root.path())
        .err()
        .expect("malformed fixture must return an error")
}

#[test]
fn explicit_root_preserves_rectangular_stage_identities_and_column_major_values() {
    let root = FixtureRoot::new();
    for (step, first_value) in [
        (1, 101),
        (2, 102),
        (3, 103),
        (4, 104),
        (8, 108),
        (9, 109),
        (10, 110),
        (11, 111),
        (12, 112),
        (14, 114),
    ] {
        let stem = format!("{step:02}");
        root.replace(
            &format!("{stem}.genes.tsv"),
            "gene\tchr\tstart\tstop\nG1\tchr1\t10\t20\nG2\tchr19\t30\t40\n",
        );
        root.replace(
            &format!("{stem}.cells.tsv"),
            "cell\tgroup\trole\nC1\tnormal_a\treference\nC2\ttumor\tobservation\nC3\tnormal_b\treference\n",
        );
        root.replace(
            &format!("{stem}.tsv"),
            &format!("gene\tC1\tC2\tC3\nG1\t{first_value}\t12\t13\nG2\t21\t22\t23\n"),
        );
    }

    let fixture = Fixture::load_from_root(root.path()).expect("valid explicit-root fixture");
    let expected_genes = [
        Gene {
            id: "G1".into(),
            chromosome: "chr1".into(),
            start: 10,
            end: 20,
        },
        Gene {
            id: "G2".into(),
            chromosome: "chr19".into(),
            start: 30,
            end: 40,
        },
    ];
    let expected_cells = [
        Cell {
            id: "C1".into(),
            group: "normal_a".into(),
        },
        Cell {
            id: "C2".into(),
            group: "tumor".into(),
        },
        Cell {
            id: "C3".into(),
            group: "normal_b".into(),
        },
    ];
    for (step, first_value) in [
        (1, 101.0),
        (2, 102.0),
        (3, 103.0),
        (4, 104.0),
        (8, 108.0),
        (9, 109.0),
        (10, 110.0),
        (11, 111.0),
        (12, 112.0),
        (14, 114.0),
    ] {
        let stage = fixture.stage(step);
        assert_eq!(
            stage.genes(),
            expected_genes.as_slice(),
            "stage {step} genes"
        );
        assert_eq!(
            stage.cells(),
            expected_cells.as_slice(),
            "stage {step} cells"
        );
        assert_eq!(
            stage.values(),
            &[first_value, 21.0, 12.0, 22.0, 13.0, 23.0],
            "stage {step} values"
        );
    }
}

#[test]
fn checked_in_synthetic_profile_still_loads_through_default_entry() {
    let fixture = Fixture::load("single_reference");
    let first = fixture.stage(1);
    assert_eq!(first.genes()[0].id, "G001");
    assert_eq!(first.genes()[0].chromosome, "chrGain");
    assert_eq!((first.genes()[0].start, first.genes()[0].end), (100, 149));
    assert_eq!(first.cells()[0].id, "GAIN3");
    assert_eq!(first.cells()[0].group, "gain_obs");
    assert_eq!(first.values()[0], 49.0);
}

#[test]
fn missing_required_stage_file_returns_path_error() {
    let root = FixtureRoot::new();
    fs::remove_file(root.path().join("14.cells.tsv")).unwrap();

    let error = load_error(&root);
    assert!(error.contains("14.cells.tsv"), "{error}");
}

#[test]
fn mismatched_expression_cell_header_is_rejected() {
    let root = FixtureRoot::new();
    root.replace("01.tsv", "gene\tWRONG_CELL\nG1\t1\n");

    let error = load_error(&root);
    assert!(error.contains("01.tsv"), "{error}");
}

#[test]
fn extra_expression_row_is_rejected_without_indexing_past_genes() {
    let root = FixtureRoot::new();
    root.replace("01.tsv", "gene\tC1\nG1\t1\nG2\t2\n");

    let error = load_error(&root);
    assert!(error.contains("01.tsv"), "{error}");
}

#[test]
fn empty_expression_table_is_rejected() {
    let root = FixtureRoot::new();
    root.replace("01.tsv", "");

    let error = load_error(&root);
    assert!(error.contains("01.tsv"), "{error}");
}

#[test]
fn invalid_gene_coordinate_is_rejected() {
    let root = FixtureRoot::new();
    root.replace(
        "01.genes.tsv",
        "gene\tchr\tstart\tstop\nG1\tchr1\tnot-a-position\t2\n",
    );

    let error = load_error(&root);
    assert!(error.contains("01.genes.tsv"), "{error}");
}

#[test]
fn nonfinite_expression_value_is_rejected() {
    let root = FixtureRoot::new();
    root.replace("01.tsv", "gene\tC1\nG1\tNaN\n");

    let error = load_error(&root);
    assert!(error.contains("01.tsv"), "{error}");
}
