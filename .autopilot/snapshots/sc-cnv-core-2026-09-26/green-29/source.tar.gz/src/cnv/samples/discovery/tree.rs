use super::super::{SampleTree, invalid, reserved};
use rsomics_common::Result;

#[derive(Clone, Copy)]
enum Node {
    Leaf(usize),
    Merge {
        left: usize,
        right: usize,
        height: f64,
    },
}

pub(super) struct Forest {
    nodes: Vec<Node>,
    root: Option<usize>,
    root_edge: Option<f64>,
    leaves: usize,
}

impl Forest {
    pub(super) fn new(leaves: usize) -> Result<Self> {
        if leaves == 0 || leaves > i32::MAX as usize {
            return Err(invalid(
                "Discovery tree requires one through i32::MAX leaves",
            ));
        }
        let count = leaves
            .checked_mul(2)
            .and_then(|count| count.checked_sub(1))
            .ok_or_else(|| invalid("Discovery tree size overflows"))?;
        let mut nodes = reserved(count)?;
        nodes.extend((0..leaves).map(Node::Leaf));
        Ok(Self {
            nodes,
            root: None,
            root_edge: None,
            leaves,
        })
    }

    fn height(&self, node: usize) -> f64 {
        match self.nodes[node] {
            Node::Leaf(_) => 0.0,
            Node::Merge { height, .. } => height,
        }
    }

    pub(super) fn push(&mut self, members: &[usize], tree: Option<&SampleTree>) -> Result<()> {
        let root = if members.len() == 1 {
            members[0]
        } else {
            let tree = tree.ok_or_else(|| invalid("Discovery subtree has no Ward tree"))?;
            let mut branches = reserved(tree.merge.len())?;
            for (&[left, right], &height) in tree.merge.iter().zip(&tree.height) {
                let node = |code: i32| {
                    if code < 0 {
                        members[(-code - 1) as usize]
                    } else {
                        branches[(code - 1) as usize]
                    }
                };
                let left = node(left);
                let right = node(right);
                let id = self.nodes.len();
                self.nodes.push(Node::Merge {
                    left,
                    right,
                    height,
                });
                branches.push(id);
            }
            *branches
                .last()
                .ok_or_else(|| invalid("Discovery Ward subtree is empty"))?
        };
        self.root = Some(match self.root {
            None => root,
            Some(previous) => {
                let height = if members.len() == 1 {
                    self.height(previous) + 2.0 * self.root_edge.unwrap_or(1.0)
                } else {
                    self.root_edge = Some(0.0);
                    self.height(root).max(self.height(previous)) + 2.0
                };
                let id = self.nodes.len();
                self.nodes.push(Node::Merge {
                    left: root,
                    right: previous,
                    height,
                });
                id
            }
        });
        Ok(())
    }

    pub(super) fn finish(self) -> Result<Option<SampleTree>> {
        let Some(root) = self.root else {
            return Err(invalid("Discovery parent tree has no subclusters"));
        };
        if self.leaves == 1 {
            return Ok(None);
        }
        let mut stack = reserved(self.nodes.len())?;
        let mut merges = reserved(self.leaves - 1)?;
        let mut order = reserved(self.leaves)?;
        stack.push((root, false));
        while let Some((node, visited)) = stack.pop() {
            match self.nodes[node] {
                Node::Leaf(index) => order.push(index),
                Node::Merge { left, right, .. } => {
                    if visited {
                        merges.push(node);
                    } else {
                        stack.push((node, true));
                        stack.push((right, false));
                        stack.push((left, false));
                    }
                }
            }
        }
        merges.sort_by(|&left, &right| self.height(left).total_cmp(&self.height(right)));
        let mut rows = reserved(self.nodes.len())?;
        rows.resize(self.nodes.len(), 0_i32);
        let mut merge = reserved(merges.len())?;
        let mut height = reserved(merges.len())?;
        for node in merges {
            let Node::Merge {
                left,
                right,
                height: value,
            } = self.nodes[node]
            else {
                return Err(invalid("Discovery merge order contains a leaf"));
            };
            let code = |id: usize| match self.nodes[id] {
                Node::Leaf(index) => -((index + 1) as i32),
                Node::Merge { .. } => rows[id],
            };
            merge.push([code(left), code(right)]);
            height.push(value);
            rows[node] = merge.len() as i32;
        }
        Ok(Some(SampleTree {
            merge,
            height,
            order,
        }))
    }
}

#[cfg(test)]
mod tests {
    use super::Forest;
    use crate::cnv::SampleTree;

    #[test]
    fn singleton_heights_follow_phylo_root_edge_consumption() {
        let first = SampleTree {
            merge: vec![[-1, -2]],
            height: vec![2.0],
            order: vec![0, 1],
        };
        let second = SampleTree {
            merge: vec![[-1, -2]],
            height: vec![4.0],
            order: vec![0, 1],
        };
        let mut forest = Forest::new(6).unwrap();
        forest.push(&[0, 3], Some(&first)).unwrap();
        forest.push(&[1, 2], Some(&second)).unwrap();
        forest.push(&[4], None).unwrap();
        forest.push(&[5], None).unwrap();
        let tree = forest.finish().unwrap().unwrap();
        assert_eq!(tree.merge, [[-1, -4], [-2, -3], [2, 1], [-5, 3], [-6, 4]]);
        assert_eq!(tree.height, [2.0, 4.0, 6.0, 6.0, 6.0]);
        assert_eq!(tree.order, [5, 4, 1, 2, 0, 3]);

        let mut forest = Forest::new(4).unwrap();
        forest.push(&[0, 1], Some(&first)).unwrap();
        forest.push(&[2], None).unwrap();
        forest.push(&[3], None).unwrap();
        let tree = forest.finish().unwrap().unwrap();
        assert_eq!(tree.merge, [[-1, -2], [-3, 1], [-4, 2]]);
        assert_eq!(tree.height, [2.0, 4.0, 6.0]);
        assert_eq!(tree.order, [3, 2, 0, 1]);
    }
}
