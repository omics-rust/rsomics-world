// Portions adapted from Microsoft network_partitions, licensed under MIT.
// Copyright (c) Microsoft Corporation.

use super::graph::Graph;
use crate::cnv::hmm::rng::CalibrationRng;
use rsomics_common::{Result, RsomicsError};
use std::collections::VecDeque;
use std::num::NonZeroUsize;

const BETA: f64 = 0.01;
pub(super) const RESTARTS: usize = 8;

struct Network {
    mass: Vec<f64>,
    loops: Vec<f64>,
    offsets: Vec<usize>,
    neighbors: Vec<usize>,
    weights: Vec<f64>,
}

struct Incident {
    weights: Vec<f64>,
    touched: Vec<usize>,
    present: Vec<bool>,
}

fn invalid(message: &str) -> RsomicsError {
    RsomicsError::InvalidInput(message.into())
}

fn allocated<T>(count: usize) -> Result<Vec<T>> {
    let mut values = Vec::new();
    values
        .try_reserve_exact(count)
        .map_err(|_| invalid("Leiden workspace allocation failed"))?;
    Ok(values)
}

fn filled<T: Clone>(count: usize, value: T) -> Result<Vec<T>> {
    let mut values = allocated(count)?;
    values.resize(count, value);
    Ok(values)
}

fn identities(count: usize) -> Result<Vec<usize>> {
    let mut values = allocated(count)?;
    values.extend(0..count);
    Ok(values)
}

fn copied<T: Copy>(values: &[T]) -> Result<Vec<T>> {
    let mut result = allocated(values.len())?;
    result.extend_from_slice(values);
    Ok(result)
}

fn project(labels: &[usize], mapping: &[usize]) -> Result<Vec<usize>> {
    let mut result = allocated(mapping.len())?;
    result.extend(mapping.iter().map(|&vertex| labels[vertex]));
    Ok(result)
}

fn canonicalize(labels: &[usize]) -> Result<Vec<usize>> {
    let mut mapping = filled(labels.len(), usize::MAX)?;
    let mut result = allocated(labels.len())?;
    let mut next = 0;
    for &label in labels {
        if mapping[label] == usize::MAX {
            mapping[label] = next;
            next += 1;
        }
        result.push(mapping[label]);
    }
    Ok(result)
}

fn cluster_count(labels: &[usize]) -> usize {
    labels.iter().copied().max().map_or(0, |label| label + 1)
}

fn shuffled(count: usize, rng: &mut CalibrationRng) -> Result<Vec<usize>> {
    let mut order = identities(count)?;
    for right in (1..count).rev() {
        let bound = NonZeroUsize::new(right + 1).unwrap();
        let other = rng.index(bound);
        order.swap(right, other);
    }
    Ok(order)
}

impl Network {
    fn from_graph(graph: &Graph) -> Result<Self> {
        Self::from_edges(filled(graph.vertices, 1.0)?, &graph.edges)
    }

    fn from_edges(mass: Vec<f64>, edges: &[(usize, usize, f64)]) -> Result<Self> {
        let count = mass.len();
        let offset_count = count
            .checked_add(1)
            .ok_or_else(|| invalid("Leiden graph size overflows"))?;
        let mut offsets = filled(offset_count, 0usize)?;
        let mut loops = filled(count, 0.0)?;
        let mut total = 0.0;
        for &(left, right, weight) in edges {
            if left > right || right >= count || !weight.is_finite() || weight < 0.0 {
                return Err(invalid("Leiden graph contains an invalid weighted edge"));
            }
            total += weight;
            if left == right {
                loops[left] += weight;
            } else if weight > 0.0 {
                offsets[left + 1] += 1;
                offsets[right + 1] += 1;
            }
        }
        if !total.is_finite() {
            return Err(invalid("Leiden graph weight sum is not finite"));
        }
        for index in 1..offsets.len() {
            offsets[index] = offsets[index]
                .checked_add(offsets[index - 1])
                .ok_or_else(|| invalid("Leiden adjacency size overflows"))?;
        }
        let mut neighbors = filled(offsets[count], 0usize)?;
        let mut weights = filled(offsets[count], 0.0)?;
        let mut cursor = copied(&offsets[..count])?;
        for &(left, right, weight) in edges {
            if left != right && weight > 0.0 {
                for (source, target) in [(left, right), (right, left)] {
                    let index = cursor[source];
                    neighbors[index] = target;
                    weights[index] = weight;
                    cursor[source] += 1;
                }
            }
        }
        Ok(Self {
            mass,
            loops,
            offsets,
            neighbors,
            weights,
        })
    }

    fn len(&self) -> usize {
        self.mass.len()
    }

    fn incident(&self, vertex: usize) -> impl Iterator<Item = (usize, f64)> + '_ {
        let range = self.offsets[vertex]..self.offsets[vertex + 1];
        self.neighbors[range.clone()]
            .iter()
            .copied()
            .zip(self.weights[range].iter().copied())
    }
}

impl Incident {
    fn new(count: usize) -> Result<Self> {
        Ok(Self {
            weights: filled(count, 0.0)?,
            touched: allocated(count)?,
            present: filled(count, false)?,
        })
    }

    fn clear(&mut self) {
        for &cluster in &self.touched {
            self.weights[cluster] = 0.0;
            self.present[cluster] = false;
        }
        self.touched.clear();
    }

    fn add(&mut self, cluster: usize, weight: f64) {
        if !self.present[cluster] {
            self.present[cluster] = true;
            self.touched.push(cluster);
        }
        self.weights[cluster] += weight;
    }
}

fn move_nodes(
    network: &Network,
    labels: &mut [usize],
    resolution: f64,
    rng: &mut CalibrationRng,
) -> Result<()> {
    let count = network.len();
    let mut mass = filled(count, 0.0)?;
    let mut sizes = filled(count, 0usize)?;
    for (vertex, &cluster) in labels.iter().enumerate() {
        mass[cluster] += network.mass[vertex];
        sizes[cluster] += 1;
    }
    let mut unused = allocated(count)?;
    unused.extend((0..count).rev().filter(|&cluster| sizes[cluster] == 0));
    let mut queue = VecDeque::new();
    queue
        .try_reserve_exact(count)
        .map_err(|_| invalid("Leiden work queue allocation failed"))?;
    queue.extend(shuffled(count, rng)?);
    let mut queued = filled(count, true)?;
    let mut incident = Incident::new(count)?;
    while let Some(vertex) = queue.pop_front() {
        queued[vertex] = false;
        let previous = labels[vertex];
        let weight = network.mass[vertex];
        mass[previous] -= weight;
        sizes[previous] -= 1;
        if sizes[previous] == 0 {
            unused.push(previous);
        }
        let empty = *unused
            .last()
            .ok_or_else(|| invalid("Leiden has no empty cluster after removing a vertex"))?;
        incident.clear();
        incident.add(previous, 0.0);
        incident.add(empty, 0.0);
        for (neighbor, edge) in network.incident(vertex) {
            incident.add(labels[neighbor], edge);
        }
        let mut chosen = previous;
        let mut best = incident.weights[previous] - resolution * weight * mass[previous];
        for &candidate in &incident.touched {
            let gain = incident.weights[candidate] - resolution * weight * mass[candidate];
            if gain > best {
                chosen = candidate;
                best = gain;
            }
        }
        if sizes[chosen] == 0 && unused.pop() != Some(chosen) {
            return Err(invalid("Leiden empty-cluster bookkeeping differs"));
        }
        mass[chosen] += weight;
        sizes[chosen] += 1;
        labels[vertex] = chosen;
        if chosen != previous {
            for (neighbor, _) in network.incident(vertex) {
                if labels[neighbor] != chosen && !queued[neighbor] {
                    queue.push_back(neighbor);
                    queued[neighbor] = true;
                }
            }
        }
    }
    let canonical = canonicalize(labels)?;
    labels.copy_from_slice(&canonical);
    Ok(())
}

fn sample_candidate(candidates: &[(usize, f64)], rng: &mut CalibrationRng) -> usize {
    let maximum = candidates
        .iter()
        .map(|&(_, gain)| gain)
        .fold(0.0_f64, f64::max);
    let total: f64 = candidates
        .iter()
        .map(|&(_, gain)| ((gain - maximum) / BETA).exp())
        .sum();
    let mut threshold = rng.uniform() * total;
    for &(cluster, gain) in candidates {
        threshold -= ((gain - maximum) / BETA).exp();
        if threshold < 0.0 {
            return cluster;
        }
    }
    candidates[candidates.len() - 1].0
}

fn refine(
    network: &Network,
    parents: &[usize],
    resolution: f64,
    rng: &mut CalibrationRng,
) -> Result<Vec<usize>> {
    let count = network.len();
    let mut labels = identities(count)?;
    let mut mass = copied(&network.mass)?;
    let mut sizes = filled(count, 1usize)?;
    let mut parent_mass = filled(count, 0.0)?;
    let mut degree = filled(count, 0.0)?;
    for (vertex, node_degree) in degree.iter_mut().enumerate() {
        parent_mass[parents[vertex]] += network.mass[vertex];
        *node_degree = network
            .incident(vertex)
            .filter(|&(neighbor, _)| parents[neighbor] == parents[vertex])
            .map(|(_, edge)| edge)
            .sum();
    }
    let mut external = copied(&degree)?;
    let mut incident = Incident::new(count)?;
    let mut candidates = allocated(count)?;
    for vertex in shuffled(count, rng)? {
        let parent = parents[vertex];
        let total = parent_mass[parent];
        let weight = network.mass[vertex];
        if sizes[vertex] != 1 || external[vertex] < resolution * weight * (total - weight) {
            continue;
        }
        mass[vertex] = 0.0;
        sizes[vertex] = 0;
        external[vertex] = 0.0;
        incident.clear();
        incident.add(vertex, 0.0);
        for (neighbor, edge) in network.incident(vertex) {
            if parents[neighbor] == parent {
                incident.add(labels[neighbor], edge);
            }
        }
        candidates.clear();
        for &candidate in &incident.touched {
            if external[candidate] >= resolution * mass[candidate] * (total - mass[candidate]) {
                let gain = incident.weights[candidate] - resolution * weight * mass[candidate];
                if gain >= 0.0 {
                    candidates.push((candidate, gain));
                }
            }
        }
        if candidates.is_empty() {
            return Err(invalid("Leiden refinement lost its singleton candidate"));
        }
        let chosen = sample_candidate(&candidates, rng);
        let shared = incident.weights[chosen];
        external[chosen] = (external[chosen] - shared) + (degree[vertex] - shared);
        mass[chosen] += weight;
        sizes[chosen] += 1;
        labels[vertex] = chosen;
    }
    canonicalize(&labels)
}

fn aggregate(
    network: &Network,
    refined: &[usize],
    parents: &[usize],
) -> Result<(Network, Vec<usize>)> {
    let count = cluster_count(refined);
    let mut mass = filled(count, 0.0)?;
    let mut initial = filled(count, usize::MAX)?;
    let capacity = (network.neighbors.len() / 2)
        .checked_add(network.len())
        .ok_or_else(|| invalid("Leiden aggregate edge count overflows"))?;
    let mut edges = allocated(capacity)?;
    for (vertex, &cluster) in refined.iter().enumerate() {
        mass[cluster] += network.mass[vertex];
        if initial[cluster] != usize::MAX && initial[cluster] != parents[vertex] {
            return Err(invalid("Leiden refinement crossed an original community"));
        }
        initial[cluster] = parents[vertex];
        if network.loops[vertex] > 0.0 {
            edges.push((cluster, cluster, network.loops[vertex]));
        }
        for (neighbor, weight) in network.incident(vertex) {
            if neighbor > vertex {
                let other = refined[neighbor];
                edges.push((cluster.min(other), cluster.max(other), weight));
            }
        }
    }
    edges.sort_unstable_by_key(|&(left, right, _)| (left, right));
    let mut retained = 0;
    for index in 0..edges.len() {
        let (left, right, weight) = edges[index];
        if retained > 0 && edges[retained - 1].0 == left && edges[retained - 1].1 == right {
            edges[retained - 1].2 += weight;
        } else {
            edges[retained] = (left, right, weight);
            retained += 1;
        }
    }
    edges.truncate(retained);
    Ok((Network::from_edges(mass, &edges)?, canonicalize(&initial)?))
}

fn iteration(
    original: &Network,
    initial: &[usize],
    resolution: f64,
    rng: &mut CalibrationRng,
) -> Result<Vec<usize>> {
    let mut network: Option<Network> = None;
    let mut labels = copied(initial)?;
    let mut mapping = identities(original.len())?;
    loop {
        let current = network.as_ref().unwrap_or(original);
        move_nodes(current, &mut labels, resolution, rng)?;
        if cluster_count(&labels) == current.len() {
            return project(&labels, &mapping);
        }
        let refined = refine(current, &labels, resolution, rng)?;
        if cluster_count(&refined) == current.len() {
            move_nodes(current, &mut labels, resolution, rng)?;
            return project(&labels, &mapping);
        }
        let (next, next_labels) = aggregate(current, &refined, &labels)?;
        for vertex in &mut mapping {
            *vertex = refined[*vertex];
        }
        network = Some(next);
        labels = next_labels;
    }
}

fn quality(network: &Network, labels: &[usize], resolution: f64) -> Result<f64> {
    let mut mass = filled(network.len(), 0.0)?;
    let mut internal = 0.0;
    for (vertex, &cluster) in labels.iter().enumerate() {
        mass[cluster] += network.mass[vertex];
        internal += network.loops[vertex];
        for (neighbor, weight) in network.incident(vertex) {
            if neighbor > vertex && labels[neighbor] == cluster {
                internal += weight;
            }
        }
    }
    Ok(2.0 * internal - resolution * mass.iter().map(|value| value * value).sum::<f64>())
}

fn trial(network: &Network, resolution: f64, seed: u32) -> Result<Vec<usize>> {
    let mut labels = identities(network.len())?;
    let mut rng = CalibrationRng::new(seed);
    for _ in 0..2 {
        labels = iteration(network, &labels, resolution, &mut rng)?;
    }
    canonicalize(&labels)
}

pub(super) fn partition(graph: &Graph, resolution: f64, seed: u32) -> Result<Vec<usize>> {
    if graph.vertices == 0 {
        return Err(invalid("Leiden graph is empty"));
    }
    let count = graph.vertices as f64;
    if !resolution.is_finite() || resolution <= 0.0 || !(resolution * count * count).is_finite() {
        return Err(invalid(
            "Leiden resolution is outside the finite positive range",
        ));
    }
    let network = Network::from_graph(graph)?;
    let mut labels = trial(&network, resolution, seed)?;
    let mut best = quality(&network, &labels, resolution)?;
    for restart in 1..RESTARTS {
        let trial_seed = seed.wrapping_add((restart as u32).wrapping_mul(0x85eb_ca6b));
        let candidate = trial(&network, resolution, trial_seed)?;
        let score = quality(&network, &candidate, resolution)?;
        if score > best {
            labels = candidate;
            best = score;
        }
    }
    for cluster in &mut labels {
        *cluster += 1;
    }
    Ok(labels)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn graph(vertices: usize, edges: &[(usize, usize, f64)]) -> Graph {
        Graph {
            vertices,
            edges: edges.to_vec(),
            neighbors: vec![Vec::new(); vertices],
        }
    }

    #[test]
    fn weighted_cpm_keeps_dense_blocks_and_ignores_constant_self_loop_offsets() {
        let edges = [
            (0, 0, 13.0),
            (0, 1, 1.0),
            (0, 2, 1.0),
            (1, 1, 7.0),
            (1, 2, 1.0),
            (2, 2, 3.0),
            (2, 3, 0.1),
            (3, 3, 9.0),
            (3, 4, 1.0),
            (3, 5, 1.0),
            (4, 4, 5.0),
            (4, 5, 1.0),
            (5, 5, 11.0),
            (6, 6, 100.0),
        ];
        let graph = graph(7, &edges);
        let expected = vec![1, 1, 1, 2, 2, 2, 3];
        assert_eq!(partition(&graph, 0.6, 23).unwrap(), expected);
        assert_eq!(partition(&graph, 0.6, 23).unwrap(), expected);
        let network = Network::from_graph(&graph).unwrap();
        assert!((quality(&network, &[0, 0, 0, 1, 1, 1, 2], 0.6).unwrap() - 296.6).abs() < 1e-12);
    }

    #[test]
    fn refinement_splits_disconnected_parent_and_preserves_aggregated_masses_and_edges() {
        let graph = graph(
            6,
            &[
                (0, 1, 1.0),
                (0, 2, 1.0),
                (1, 2, 1.0),
                (3, 4, 1.0),
                (3, 5, 1.0),
                (4, 5, 1.0),
            ],
        );
        let network = Network::from_graph(&graph).unwrap();
        let mut rng = CalibrationRng::new(17);
        let labels = refine(&network, &[0; 6], 0.1, &mut rng).unwrap();
        assert_eq!(labels, [0, 0, 0, 1, 1, 1]);
        let (aggregate, initial) = aggregate(&network, &labels, &[0; 6]).unwrap();
        assert_eq!(aggregate.mass, [3.0, 3.0]);
        assert_eq!(aggregate.loops, [3.0, 3.0]);
        assert!(aggregate.neighbors.is_empty());
        assert_eq!(initial, [0, 0]);
        let mut separated = initial;
        move_nodes(&aggregate, &mut separated, 0.1, &mut rng).unwrap();
        assert_eq!(canonicalize(&separated).unwrap(), [0, 1]);
    }

    #[test]
    fn refinement_uses_temperature_sampling_without_exponential_overflow() {
        let mut rng = CalibrationRng::new(17);
        let candidates = [(0, 1_000.0), (1, 1_000.01)];
        let mut lower_gain = 0;
        for _ in 0..2_000 {
            lower_gain += usize::from(sample_candidate(&candidates, &mut rng) == 0);
        }
        assert!((400..650).contains(&lower_gain), "{lower_gain}");
    }
}
