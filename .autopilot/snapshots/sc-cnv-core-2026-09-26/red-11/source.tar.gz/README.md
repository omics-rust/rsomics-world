# rsomics-sc

This is an unreleased product-local numerical core, not a usable inferCNV replacement. It accepts prepared dense, column-major stage-1 counts or creates them from strict explicit-header UTF-8 count TSV and headerless position/annotation TSV, plain or gzip, preserving ordered cell groups. The non-HMM numerical path runs through step 14.

Source-pinned infercnv 1.28.0 synthetic and canonical shipped-example creation/pre-clustering comparisons have passed debug and release on Linux/macOS x86_64/aarch64. Original implicit count headers, arbitrary R decimal/threshold equivalence, general R table/locale behavior, RDS/sparse input and sampling remain excluded.

Separate [canonical warm raw-creation evidence](https://github.com/omics-rust/rsomics-world/blob/main/.autopilot/state/infercnv-ingestion-accepted-2026-10-22.md) passes exact output checks and strict timing separation on one Linux x86_64 shipped example. It does not establish representative-cohort, cold-I/O, factory peak-memory or full-workflow performance. Prepared-input measurements remain a different experiment.

A private Euclidean distance view and Ward.D2 kernel reproduce all107331 original distances and152 computed-vector trees from the original R-selected matrices, with exact binary64 distances/heights, merges and leaf order, in native debug/release on Linux/macOS x86_64/aarch64. They are not exposed by the library. Gene filtering, samples-group integration and end-to-end trees remain separate gates; positive-filter inputs already use R-selected genes. This is correctness evidence, not clustering performance. The adapted fastcluster code retains its original BSD notice in THIRD_PARTY_NOTICES.

Annotated persisted state, integrated clustering, HMM, denoising, plots and a unified product CLI are not implemented. These bounded checks do not establish full-workflow or biological validity. No public binary or package release is available.
