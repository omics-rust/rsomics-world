use std::io;
use std::path::{Path, PathBuf};

use clap::{Args, Parser, Subcommand};
use rsomics_common::{
    OutputArgs, Result, RsomicsError, ThreadArgs, ToolMeta, reject_output_alias, write_output,
};
use rsomics_sc::cnv::{
    self, CellGroup, CnvState, CreatedInput, CreationConfig, InputPaths, PreprocessConfig,
    ReferenceMode, Samples, SamplesConfig,
};
use serde::Serialize;

pub const META: ToolMeta = ToolMeta {
    name: env!("CARGO_PKG_NAME"),
    version: env!("CARGO_PKG_VERSION"),
};

#[derive(Debug, Parser)]
#[command(
    name = "rsomics-sc",
    version,
    about = "Native single-cell workflows (unreleased)",
    subcommand_required = true,
    arg_required_else_help = true
)]
pub struct Cli {
    #[command(subcommand)]
    command: Command,

    #[command(flatten)]
    pub output: OutputArgs,

    #[command(flatten)]
    threads: ThreadArgs,
}

#[derive(Debug, Subcommand)]
enum Command {
    /// Expression-based copy-number preprocessing and sample clustering.
    #[command(subcommand)]
    Cnv(CnvCommand),
}

#[derive(Debug, Subcommand)]
enum CnvCommand {
    /// Join raw TSV inputs, preprocess through step 14, and cluster samples with Ward.D2.
    #[command(
        after_help = "This unreleased workflow does not run HMM inference or generate plots."
    )]
    Samples(SamplesArgs),
}

#[derive(Debug, Args)]
struct SamplesArgs {
    /// Counts TSV: explicit gene-column header followed by cell IDs; plain or gzip.
    #[arg(long)]
    counts: PathBuf,

    /// Headerless gene/chromosome/start/end TSV; plain or gzip.
    #[arg(long)]
    positions: PathBuf,

    /// Headerless cell/group TSV; plain or gzip. IDs are literal, including V1.
    #[arg(long)]
    annotations: PathBuf,

    /// Self-contained JSON report; '-' writes stdout and cannot be used with --json.
    #[arg(short, long)]
    output: PathBuf,

    /// Reference group name; repeat for multiple groups. Omit to use all cells as reference.
    #[arg(long = "reference")]
    references: Vec<String>,

    /// Center by the equally weighted reference-group mean instead of group bounds.
    #[arg(long, requires = "references")]
    reference_mean: bool,

    /// Cluster observation groups separately instead of pooling all observations.
    #[arg(long)]
    cluster_by_groups: bool,

    /// Enable reference filtering when positive (fixed upstream cutoff 0.8); zero disables.
    #[arg(long, default_value_t = 0.8)]
    z_score_filter: f64,

    /// Minimum mean raw count across cells for retaining a gene.
    #[arg(long, default_value_t = 0.1)]
    cutoff: f64,

    /// Minimum number of positive-count cells for retaining a gene.
    #[arg(long, default_value_t = 3)]
    min_cells_per_gene: usize,

    /// Positive odd triangular smoothing window, truncated at chromosome ends.
    #[arg(long, default_value_t = 101)]
    window_length: usize,

    /// Positive symmetric clamp threshold for centered log2 expression.
    #[arg(long, default_value_t = 3.0)]
    max_centered_threshold: f64,

    /// Inclusive cell-depth lower bound; values below one are clamped to one.
    #[arg(long, default_value_t = 1.0)]
    min_counts_per_cell: f64,

    /// Inclusive cell-depth upper bound; inf disables the upper bound.
    #[arg(long, default_value = "inf")]
    max_counts_per_cell: f64,

    /// Excluded chromosome labels; replaces defaults. Pass no labels to retain all.
    #[arg(long = "exclude-chromosome", value_delimiter = ',', num_args = 0.., default_values = ["chrX", "chrY", "chrM"])]
    excluded_chromosomes: Vec<String>,

    /// Per-stage numerical/workspace byte ceiling; excludes metadata, retained prior stages, and RSS.
    #[arg(long, default_value_t = 1_073_741_824)]
    max_numeric_bytes: usize,

    /// Maximum decoded TSV record bytes, including CR/LF; not a whole-input memory ceiling.
    #[arg(long, default_value_t = 16_777_216)]
    max_record_bytes: usize,

    /// Include the step-14 expression matrix as column-major values in the JSON report.
    #[arg(long)]
    include_expression: bool,
}

#[derive(Debug, Serialize)]
pub struct CommandSummary {
    operation: &'static str,
    report: PathBuf,
    genes: usize,
    cells: usize,
    selected_genes: usize,
    groups: usize,
    threads: usize,
}

impl Cli {
    pub fn execute(self) -> Result<CommandSummary> {
        let threads = match self.threads.requested() {
            Some(threads) => threads,
            None => std::thread::available_parallelism()?,
        }
        .get();
        match self.command {
            Command::Cnv(CnvCommand::Samples(args)) => args.execute(self.output.json, threads),
        }
    }
}

impl SamplesArgs {
    fn execute(self, json: bool, threads: usize) -> Result<CommandSummary> {
        if json && self.output == Path::new("-") {
            return Err(RsomicsError::ConfigError(
                "--json requires a named --output report; stdout is reserved for the result envelope"
                    .into(),
            ));
        }
        reject_output_alias(
            &self.output,
            [
                self.counts.as_path(),
                self.positions.as_path(),
                self.annotations.as_path(),
            ],
        )?;
        let input = cnv::create_input(
            InputPaths {
                counts: &self.counts,
                positions: &self.positions,
                annotations: &self.annotations,
            },
            &CreationConfig {
                reference_groups: self.references.clone(),
                excluded_chromosomes: self.excluded_chromosomes.clone(),
                min_counts_per_cell: self.min_counts_per_cell,
                max_counts_per_cell: self.max_counts_per_cell,
                max_numeric_bytes: self.max_numeric_bytes,
                max_record_bytes: self.max_record_bytes,
            },
        )?;
        let references = if self.references.is_empty() {
            ReferenceMode::AllCells
        } else if self.reference_mean {
            ReferenceMode::GroupMean(self.references.clone())
        } else {
            ReferenceMode::GroupBounds(self.references.clone())
        };
        let state = cnv::run(
            input.prepared_counts(),
            &PreprocessConfig {
                cutoff: self.cutoff,
                min_cells_per_gene: self.min_cells_per_gene,
                window_length: self.window_length,
                max_centered_threshold: self.max_centered_threshold,
                references,
                threads,
                max_numeric_bytes: self.max_numeric_bytes,
            },
        )?;
        let samples = cnv::samples(
            &state,
            &input,
            &SamplesConfig {
                cluster_by_groups: self.cluster_by_groups,
                z_score_filter: self.z_score_filter,
                max_workspace_bytes: self.max_numeric_bytes,
                threads,
            },
        )?;
        let report = SamplesReport::new(&self, &input, &state, &samples, threads);
        write_output(Some(&self.output), |output| {
            serde_json::to_writer_pretty(&mut *output, &report).map_err(|error| {
                RsomicsError::Io(io::Error::other(format!(
                    "serializing samples report: {error}"
                )))
            })?;
            output.write_all(b"\n").map_err(RsomicsError::Io)
        })?;
        Ok(CommandSummary {
            operation: "cnv.samples",
            report: self.output,
            genes: state.gene_count(),
            cells: state.cell_count(),
            selected_genes: samples.selected_gene_indices.len(),
            groups: samples.groups.len(),
            threads,
        })
    }
}

#[derive(Serialize)]
struct SamplesReport<'a> {
    schema: &'static str,
    tool: &'static str,
    tool_version: &'static str,
    index_basis: IndexBasis,
    inputs: ReportInputs<'a>,
    settings: ReportSettings<'a>,
    genes: Vec<GeneView<'a>>,
    cells: Vec<CellView<'a>>,
    input_groups: InputGroups<'a>,
    selected_gene_indices: &'a [usize],
    outlier_gene_indices: Option<&'a [usize]>,
    groups: Vec<GroupView<'a>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    expression: Option<ExpressionView<'a>>,
}

#[derive(Serialize)]
struct IndexBasis {
    genes: usize,
    cells: usize,
    tree_order: &'static str,
    tree_merge: &'static str,
    member_indices: &'static str,
}

#[derive(Serialize)]
struct ReportInputs<'a> {
    counts: &'a Path,
    positions: &'a Path,
    annotations: &'a Path,
}

#[derive(Serialize)]
struct ReportSettings<'a> {
    reference_groups: &'a [String],
    reference_centering: &'static str,
    excluded_chromosomes: &'a [String],
    min_counts_per_cell: f64,
    max_counts_per_cell: Option<f64>,
    cutoff: f64,
    min_cells_per_gene: usize,
    window_length: usize,
    max_centered_threshold: f64,
    cluster_by_groups: bool,
    z_score_filter: f64,
    max_numeric_bytes_per_stage: usize,
    max_record_bytes: usize,
    threads: usize,
}

#[derive(Serialize)]
struct GeneView<'a> {
    id: &'a str,
    chromosome: &'a str,
    start: u64,
    end: u64,
}

#[derive(Serialize)]
struct CellView<'a> {
    id: &'a str,
    group: &'a str,
}

#[derive(Serialize)]
struct InputGroups<'a> {
    observations: Vec<InputGroupView<'a>>,
    references: Vec<InputGroupView<'a>>,
}

#[derive(Serialize)]
struct InputGroupView<'a> {
    name: &'a str,
    cell_indices: &'a [usize],
}

#[derive(Serialize)]
struct GroupView<'a> {
    name: &'a str,
    subcluster_name: &'a str,
    member_indices: &'a [usize],
    tree: Option<TreeView<'a>>,
}

#[derive(Serialize)]
struct TreeView<'a> {
    merge: &'a [[i32; 2]],
    height: &'a [f64],
    order: &'a [usize],
}

#[derive(Serialize)]
struct ExpressionView<'a> {
    step: u8,
    layout: &'static str,
    shape: [usize; 2],
    values: &'a [f64],
}

impl<'a> SamplesReport<'a> {
    fn new(
        args: &'a SamplesArgs,
        input: &'a CreatedInput,
        state: &'a CnvState,
        samples: &'a Samples,
        threads: usize,
    ) -> Self {
        Self {
            schema: "rsomics-sc.cnv.samples.v1",
            tool: META.name,
            tool_version: META.version,
            index_basis: IndexBasis {
                genes: 0,
                cells: 0,
                tree_order: "zero-based local leaves; zip order with member_indices to map leaves to report cells",
                tree_merge: "signed R hclust: -k denotes one-based local leaf k; +k denotes one-based merge row k",
                member_indices: "zero-based report cells in tree traversal order; unclustered groups retain input order",
            },
            inputs: ReportInputs {
                counts: &args.counts,
                positions: &args.positions,
                annotations: &args.annotations,
            },
            settings: ReportSettings {
                reference_groups: &args.references,
                reference_centering: if args.references.is_empty() {
                    "all-cells"
                } else if args.reference_mean {
                    "group-mean"
                } else {
                    "group-bounds"
                },
                excluded_chromosomes: &args.excluded_chromosomes,
                min_counts_per_cell: args.min_counts_per_cell.max(1.0),
                max_counts_per_cell: args
                    .max_counts_per_cell
                    .is_finite()
                    .then_some(args.max_counts_per_cell),
                cutoff: args.cutoff,
                min_cells_per_gene: args.min_cells_per_gene,
                window_length: args.window_length,
                max_centered_threshold: args.max_centered_threshold,
                cluster_by_groups: args.cluster_by_groups,
                z_score_filter: args.z_score_filter,
                max_numeric_bytes_per_stage: args.max_numeric_bytes,
                max_record_bytes: args.max_record_bytes,
                threads,
            },
            genes: state
                .genes()
                .iter()
                .map(|gene| GeneView {
                    id: &gene.id,
                    chromosome: &gene.chromosome,
                    start: gene.start,
                    end: gene.end,
                })
                .collect(),
            cells: state
                .cells()
                .iter()
                .map(|cell| CellView {
                    id: &cell.id,
                    group: &cell.group,
                })
                .collect(),
            input_groups: InputGroups {
                observations: input_group_views(input.observation_groups()),
                references: input_group_views(input.reference_groups()),
            },
            selected_gene_indices: &samples.selected_gene_indices,
            outlier_gene_indices: samples.outlier_gene_indices.as_deref(),
            groups: samples
                .groups
                .iter()
                .map(|group| GroupView {
                    name: &group.name,
                    subcluster_name: &group.subcluster_name,
                    member_indices: &group.member_indices,
                    tree: group.tree.as_ref().map(|tree| TreeView {
                        merge: &tree.merge,
                        height: &tree.height,
                        order: &tree.order,
                    }),
                })
                .collect(),
            expression: args.include_expression.then_some(ExpressionView {
                step: 14,
                layout: "column-major",
                shape: [state.gene_count(), state.cell_count()],
                values: state.values(),
            }),
        }
    }
}

fn input_group_views(groups: &[CellGroup]) -> Vec<InputGroupView<'_>> {
    groups
        .iter()
        .map(|group| InputGroupView {
            name: group.name(),
            cell_indices: group.cell_indices(),
        })
        .collect()
}
