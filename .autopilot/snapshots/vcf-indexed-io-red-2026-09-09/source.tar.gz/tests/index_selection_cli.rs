use std::fs::{self, File, FileTimes};
use std::path::PathBuf;
use std::process::{Command, Output};
use std::time::Duration;

struct Fixture {
    directory: tempfile::TempDir,
    input: PathBuf,
}

impl Fixture {
    fn new(encoding: &str) -> Self {
        let directory = tempfile::tempdir().unwrap();
        let source = directory.path().join("source.vcf");
        fs::write(
            &source,
            b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t10\tselected\tA\tC\t.\tPASS\t.\tGT\t0|1\n",
        )
        .unwrap();
        let input = directory.path().join("input.data");
        success(
            command()
                .args(["view", "-O", encoding, "-o"])
                .arg(&input)
                .arg(&source)
                .output()
                .unwrap(),
        );
        Self { directory, input }
    }

    fn index(&self, kind: &str) -> PathBuf {
        self.input.with_extension(format!("data.{kind}"))
    }

    fn build(&self, kind: &str) {
        success(
            command()
                .args(["index", "--force", &format!("--{kind}")])
                .arg(&self.input)
                .output()
                .unwrap(),
        );
    }

    fn make_stale(&self, kind: &str) {
        let modified = fs::metadata(&self.input).unwrap().modified().unwrap();
        File::options()
            .write(true)
            .open(self.index(kind))
            .unwrap()
            .set_times(FileTimes::new().set_modified(modified - Duration::from_secs(60)))
            .unwrap();
    }

    fn write_empty_tbi(&self) {
        let index = noodles_tabix::Index::builder()
            .set_header(noodles_csi::binning_index::index::Header::default())
            .build();
        noodles_tabix::fs::write(self.index("tbi"), &index).unwrap();
    }

    fn run(&self, arguments: &[&str]) -> Output {
        command().args(arguments).arg(&self.input).output().unwrap()
    }

    fn reject_atomically(&self, arguments: &[&str], error: &str) {
        let destination = self.directory.path().join("output.vcf");
        fs::write(&destination, b"previous output").unwrap();
        let output = command()
            .args(arguments)
            .arg("-o")
            .arg(&destination)
            .arg(&self.input)
            .output()
            .unwrap();
        assert!(
            !output.status.success(),
            "unexpected success: {arguments:?}"
        );
        let stderr = String::from_utf8_lossy(&output.stderr);
        assert!(stderr.contains(error), "{stderr}");
        assert_eq!(fs::read(destination).unwrap(), b"previous output");
    }
}

fn command() -> Command {
    Command::new(env!("CARGO_BIN_EXE_rsomics-vcf"))
}

fn success(output: Output) -> Output {
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    output
}

const REGION_COMMANDS: &[&[&str]] = &[
    &["view", "-r", "chr1:10-10"],
    &["concat", "-a", "-r", "chr1:10-10"],
];
const INDEX_COMMANDS: &[&[&str]] = &[
    REGION_COMMANDS[0],
    REGION_COMMANDS[1],
    &["concat", "--ligate"],
];

#[test]
fn vcf_prefers_valid_tbi_over_stale_or_corrupt_csi() {
    for corrupt in [false, true] {
        let fixture = Fixture::new("z");
        fixture.build("csi");
        fixture.build("tbi");
        if corrupt {
            fs::write(fixture.index("csi"), b"corrupt CSI").unwrap();
        } else {
            fixture.make_stale("csi");
        }
        for arguments in INDEX_COMMANDS {
            let output = success(fixture.run(arguments));
            assert!(String::from_utf8_lossy(&output.stdout).contains("chr1\t10\tselected\t"));
        }
    }
}

#[test]
fn vcf_does_not_fall_back_from_stale_or_corrupt_tbi() {
    for corrupt in [false, true] {
        let fixture = Fixture::new("z");
        fixture.build("csi");
        fixture.build("tbi");
        if corrupt {
            fs::write(fixture.index("tbi"), b"corrupt TBI").unwrap();
        } else {
            fixture.make_stale("tbi");
        }
        for arguments in INDEX_COMMANDS {
            fixture.reject_atomically(arguments, "input.data.tbi");
        }
    }
}

#[test]
fn indexed_query_uses_tbi_contents_when_both_indexes_exist() {
    let fixture = Fixture::new("z");
    fixture.build("tbi");
    noodles_csi::fs::write(fixture.index("csi"), &noodles_csi::Index::default()).unwrap();
    for arguments in REGION_COMMANDS {
        let output = success(fixture.run(arguments));
        assert!(String::from_utf8_lossy(&output.stdout).contains("chr1\t10\tselected\t"));
    }
}

#[test]
fn csi_is_used_when_tbi_is_absent() {
    for encoding in ["z", "b"] {
        let fixture = Fixture::new(encoding);
        fixture.build("csi");
        for arguments in INDEX_COMMANDS {
            let output = success(fixture.run(arguments));
            assert!(String::from_utf8_lossy(&output.stdout).contains("chr1\t10\tselected\t"));
        }
    }
}

#[test]
fn bcf_ignores_tbi_but_requires_a_valid_csi() {
    let fixture = Fixture::new("b");
    fixture.build("csi");
    fs::write(fixture.index("tbi"), b"not a TBI index").unwrap();
    for arguments in INDEX_COMMANDS {
        success(fixture.run(arguments));
    }
    fs::write(fixture.index("csi"), b"corrupt CSI").unwrap();
    fixture.write_empty_tbi();
    for arguments in INDEX_COMMANDS {
        fixture.reject_atomically(arguments, "input.data.csi");
    }
}

#[test]
fn bcf_rejects_tbi_only_even_for_ligation() {
    let fixture = Fixture::new("b");
    fixture.write_empty_tbi();
    for arguments in INDEX_COMMANDS {
        fixture.reject_atomically(arguments, "no CSI index found");
    }
}

#[test]
fn indexed_operations_reject_missing_indexes() {
    for encoding in ["z", "b"] {
        let fixture = Fixture::new(encoding);
        for arguments in INDEX_COMMANDS {
            fixture.reject_atomically(arguments, "index found");
        }
    }
}

#[cfg(target_os = "linux")]
#[test]
fn indexed_operations_preserve_non_utf8_paths() {
    use std::ffi::OsString;
    use std::os::unix::ffi::OsStringExt;

    for (encoding, kind) in [("z", "tbi"), ("z", "csi"), ("b", "csi")] {
        for collision in [false, true] {
            let mut fixture = Fixture::new(encoding);
            fixture.build(kind);
            let previous_index = fixture.index(kind);
            let input = fixture
                .directory
                .path()
                .join(OsString::from_vec(b"input-\xff.data".to_vec()));
            fs::rename(&fixture.input, &input).unwrap();
            fixture.input = input;
            fs::rename(previous_index, fixture.index(kind)).unwrap();
            if collision {
                let unrelated = PathBuf::from(format!("{}.{}", fixture.input.display(), kind));
                assert_ne!(unrelated, fixture.index(kind));
                fs::write(unrelated, b"unrelated index").unwrap();
            }
            for arguments in INDEX_COMMANDS {
                let output = success(fixture.run(arguments));
                assert!(String::from_utf8_lossy(&output.stdout).contains("chr1\t10\tselected\t"));
            }
        }
    }
}

#[cfg(target_os = "linux")]
#[test]
fn index_creation_preserves_non_utf8_paths() {
    use std::ffi::OsString;
    use std::os::unix::ffi::OsStringExt;

    for (encoding, kind) in [("z", "tbi"), ("z", "csi"), ("b", "csi")] {
        let mut fixture = Fixture::new(encoding);
        let input = fixture
            .directory
            .path()
            .join(OsString::from_vec(b"input-\xff.data".to_vec()));
        fs::rename(&fixture.input, &input).unwrap();
        fixture.input = input;
        fixture.build(kind);
        assert!(fixture.index(kind).is_file());
        let lossy = PathBuf::from(format!("{}.{}", fixture.input.display(), kind));
        assert!(!lossy.exists());
    }
}

#[cfg(unix)]
#[test]
fn default_index_paths_preserve_non_utf8_bytes() {
    use std::ffi::OsString;
    use std::os::unix::ffi::OsStringExt;

    use rsomics_vcf::index::{IndexKind, default_output_path};

    let input = PathBuf::from(OsString::from_vec(b"input-\xff.data".to_vec()));
    for (kind, expected) in [
        (IndexKind::Tbi, b"input-\xff.data.tbi"),
        (IndexKind::Csi, b"input-\xff.data.csi"),
    ] {
        assert_eq!(
            default_output_path(&input, kind)
                .into_os_string()
                .into_vec(),
            expected
        );
    }
}

#[cfg(unix)]
#[test]
fn dangling_preferred_tbi_does_not_fall_back_to_valid_csi() {
    let fixture = Fixture::new("z");
    fixture.build("csi");
    std::os::unix::fs::symlink("missing-index", fixture.index("tbi")).unwrap();
    for arguments in INDEX_COMMANDS {
        fixture.reject_atomically(arguments, "input.data.tbi");
    }
}
