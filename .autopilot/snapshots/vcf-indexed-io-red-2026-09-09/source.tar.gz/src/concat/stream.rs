use std::cmp::{Ordering, Reverse};
use std::collections::{BinaryHeap, HashMap, HashSet};
use std::sync::mpsc::{Receiver, SyncSender, sync_channel};
use std::thread;

use noodles_vcf::{
    Header,
    variant::{RecordBuf, record_buf::Samples},
};
use rsomics_common::{Result, RsomicsError};

use super::{DuplicatePolicy, Options, PlannedInput, Summary, invalid_record, reopen};
use crate::format::{Reader, RecordScratch, VariantWriter};
use crate::regions::{IndexedRecords, RegionSet};
use crate::variant_type;

struct Input {
    reader: Reader,
    header: Header,
    path: std::path::PathBuf,
    scratch: RecordScratch,
    number: u64,
    previous: Option<(usize, usize)>,
    seen: HashSet<usize>,
}

struct Pending {
    reference: usize,
    position: usize,
    input: usize,
    number: u64,
    record: RecordBuf,
}

impl PartialEq for Pending {
    fn eq(&self, other: &Self) -> bool {
        self.cmp(other) == Ordering::Equal
    }
}

impl Eq for Pending {}

impl PartialOrd for Pending {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for Pending {
    fn cmp(&self, other: &Self) -> Ordering {
        self.coordinate()
            .cmp(&other.coordinate())
            .then_with(|| self.input.cmp(&other.input))
            .then_with(|| self.number.cmp(&other.number))
    }
}

impl Pending {
    fn coordinate(&self) -> (usize, usize) {
        (self.reference, self.position)
    }
}

pub(super) fn write_overlap(
    planned: &[PlannedInput],
    output_header: &Header,
    options: &Options,
    duplicate_policy: Option<DuplicatePolicy>,
    writer: &mut impl VariantWriter,
    summary: &mut Summary,
) -> Result<()> {
    if let Some(regions) = &options.regions {
        return write_indexed(
            planned,
            output_header,
            options,
            duplicate_policy,
            regions,
            writer,
            summary,
        );
    }
    let references: HashMap<_, _> = output_header
        .contigs()
        .keys()
        .enumerate()
        .map(|(index, name)| (name.clone(), index))
        .collect();
    let mut inputs: Vec<_> = planned
        .iter()
        .map(|input| {
            Ok(Input {
                reader: reopen(input)?,
                header: input.header.clone(),
                path: input.path.clone(),
                scratch: RecordScratch::default(),
                number: 0,
                previous: None,
                seen: HashSet::new(),
            })
        })
        .collect::<Result<_>>()?;
    let mut pending = BinaryHeap::new();
    for index in 0..inputs.len() {
        push_next(index, &references, &mut inputs, &mut pending, summary)?;
    }

    while let Some(Reverse(first)) = pending.pop() {
        let coordinate = first.coordinate();
        let mut records = vec![first];
        let input = records[0].input;
        push_next(input, &references, &mut inputs, &mut pending, summary)?;
        while pending
            .peek()
            .is_some_and(|Reverse(record)| record.coordinate() == coordinate)
        {
            let Reverse(record) = pending.pop().unwrap();
            let input = record.input;
            records.push(record);
            push_next(input, &references, &mut inputs, &mut pending, summary)?;
        }
        write_coordinate(
            records,
            output_header,
            options,
            duplicate_policy,
            writer,
            summary,
        )?;
    }
    Ok(())
}

enum RegionMessage {
    Record { record: Box<RecordBuf>, number: u64 },
    Done { read: u64 },
    Error(RsomicsError),
}

struct RegionInput {
    receiver: Receiver<RegionMessage>,
    path: std::path::PathBuf,
    previous: Option<(usize, usize)>,
    seen: HashSet<usize>,
}

fn write_indexed(
    planned: &[PlannedInput],
    output_header: &Header,
    options: &Options,
    duplicate_policy: Option<DuplicatePolicy>,
    regions: &RegionSet,
    writer: &mut impl VariantWriter,
    summary: &mut Summary,
) -> Result<()> {
    let references: HashMap<_, _> = output_header
        .contigs()
        .keys()
        .enumerate()
        .map(|(index, name)| (name.clone(), index))
        .collect();
    thread::scope(|scope| {
        let mut handles = Vec::with_capacity(planned.len());
        let mut inputs = Vec::with_capacity(planned.len());
        for input in planned {
            let (sender, receiver) = sync_channel(1);
            let path = input.path.clone();
            let worker_path = path.clone();
            let regions = regions.clone();
            handles.push(scope.spawn(move || indexed_worker(&worker_path, &regions, sender)));
            inputs.push(RegionInput {
                receiver,
                path,
                previous: None,
                seen: HashSet::new(),
            });
        }

        let result = merge_indexed(
            &references,
            &mut inputs,
            output_header,
            options,
            duplicate_policy,
            writer,
            summary,
        );
        drop(inputs);
        for handle in handles {
            if handle.join().is_err() && result.is_ok() {
                return Err(RsomicsError::InvalidInput(
                    "indexed concat worker panicked".to_owned(),
                ));
            }
        }
        result
    })
}

fn indexed_worker(path: &std::path::Path, regions: &RegionSet, sender: SyncSender<RegionMessage>) {
    let result = (|| {
        let mut records = IndexedRecords::open(path, regions)?;
        let read = records.visit(|_, record, number| {
            sender
                .send(RegionMessage::Record {
                    record: Box::new(record),
                    number,
                })
                .map_err(|_| receiver_closed())
        })?;
        sender
            .send(RegionMessage::Done { read })
            .map_err(|_| receiver_closed())
    })();
    if let Err(error) = result {
        let _ = sender.send(RegionMessage::Error(error));
    }
}

fn merge_indexed(
    references: &HashMap<String, usize>,
    inputs: &mut [RegionInput],
    output_header: &Header,
    options: &Options,
    duplicate_policy: Option<DuplicatePolicy>,
    writer: &mut impl VariantWriter,
    summary: &mut Summary,
) -> Result<()> {
    let mut pending = BinaryHeap::new();
    for index in 0..inputs.len() {
        push_next_indexed(index, references, inputs, &mut pending, summary)?;
    }
    while let Some(Reverse(first)) = pending.pop() {
        let coordinate = first.coordinate();
        let mut records = vec![first];
        let input = records[0].input;
        push_next_indexed(input, references, inputs, &mut pending, summary)?;
        while pending
            .peek()
            .is_some_and(|Reverse(record)| record.coordinate() == coordinate)
        {
            let Reverse(record) = pending.pop().unwrap();
            let input = record.input;
            records.push(record);
            push_next_indexed(input, references, inputs, &mut pending, summary)?;
        }
        write_coordinate(
            records,
            output_header,
            options,
            duplicate_policy,
            writer,
            summary,
        )?;
    }
    Ok(())
}

fn push_next_indexed(
    index: usize,
    references: &HashMap<String, usize>,
    inputs: &mut [RegionInput],
    pending: &mut BinaryHeap<Reverse<Pending>>,
    summary: &mut Summary,
) -> Result<()> {
    let input = &mut inputs[index];
    match input.receiver.recv() {
        Ok(RegionMessage::Record { record, number }) => {
            let record = *record;
            let reference = references
                .get(record.reference_sequence_name())
                .copied()
                .ok_or_else(|| {
                    invalid_record(
                        &input.path,
                        number,
                        "reference sequence is absent from the merged header",
                    )
                })?;
            let position = record.variant_start().map(usize::from).ok_or_else(|| {
                invalid_record(&input.path, number, "variant position is missing")
            })?;
            if let Some((previous_reference, previous_position)) = input.previous {
                if reference < previous_reference
                    || (reference == previous_reference && position < previous_position)
                {
                    return Err(invalid_record(
                        &input.path,
                        number,
                        "indexed records are not coordinate sorted",
                    ));
                }
                if reference != previous_reference && !input.seen.insert(previous_reference) {
                    return Err(invalid_record(
                        &input.path,
                        number,
                        "indexed reference sequence blocks are not contiguous",
                    ));
                }
            }
            input.previous = Some((reference, position));
            pending.push(Reverse(Pending {
                reference,
                position,
                input: index,
                number,
                record,
            }));
            Ok(())
        }
        Ok(RegionMessage::Done { read }) => {
            summary.records_read = summary.records_read.checked_add(read).ok_or_else(|| {
                RsomicsError::InvalidInput("variant record count exceeds u64".to_owned())
            })?;
            Ok(())
        }
        Ok(RegionMessage::Error(error)) => Err(error),
        Err(_) => Err(RsomicsError::InvalidInput(format!(
            "indexed concat worker ended without completing {}",
            input.path.display()
        ))),
    }
}

fn receiver_closed() -> RsomicsError {
    RsomicsError::InvalidInput("indexed concat receiver closed".to_owned())
}

fn push_next(
    index: usize,
    references: &HashMap<String, usize>,
    inputs: &mut [Input],
    pending: &mut BinaryHeap<Reverse<Pending>>,
    summary: &mut Summary,
) -> Result<()> {
    let input = &mut inputs[index];
    input.number = input
        .number
        .checked_add(1)
        .ok_or_else(|| RsomicsError::InvalidInput("variant record count exceeds u64".to_owned()))?;
    let Some(record) = input
        .reader
        .read_record(&input.header, &mut input.scratch, input.number)?
    else {
        return Ok(());
    };
    summary.records_read = summary
        .records_read
        .checked_add(1)
        .ok_or_else(|| RsomicsError::InvalidInput("variant record count exceeds u64".to_owned()))?;
    let reference = references
        .get(record.reference_sequence_name())
        .copied()
        .ok_or_else(|| {
            invalid_record(
                &input.path,
                input.number,
                "reference sequence is absent from the merged header",
            )
        })?;
    let position = record
        .variant_start()
        .map(usize::from)
        .ok_or_else(|| invalid_record(&input.path, input.number, "variant position is missing"))?;
    if let Some((previous_reference, previous_position)) = input.previous {
        if reference < previous_reference
            || (reference == previous_reference && position < previous_position)
        {
            return Err(invalid_record(
                &input.path,
                input.number,
                "input records are not coordinate sorted",
            ));
        }
        if reference != previous_reference && !input.seen.insert(previous_reference) {
            return Err(invalid_record(
                &input.path,
                input.number,
                "reference sequence blocks are not contiguous",
            ));
        }
    }
    input.previous = Some((reference, position));
    pending.push(Reverse(Pending {
        reference,
        position,
        input: index,
        number: input.number,
        record,
    }));
    Ok(())
}

fn write_coordinate(
    records: Vec<Pending>,
    header: &Header,
    options: &Options,
    duplicate_policy: Option<DuplicatePolicy>,
    writer: &mut impl VariantWriter,
    summary: &mut Summary,
) -> Result<()> {
    let mut accepted: Vec<(usize, RecordBuf)> = Vec::with_capacity(records.len());
    let mut input = None;
    let mut matched = HashSet::new();
    for mut pending in records {
        if input != Some(pending.input) {
            input = Some(pending.input);
            matched.clear();
        }
        let duplicate = duplicate_policy.and_then(|policy| {
            accepted
                .iter()
                .enumerate()
                .find(|(index, (input, previous))| {
                    *input < pending.input
                        && !matched.contains(index)
                        && exact_alleles(previous, &pending.record)
                })
                .or_else(|| {
                    accepted
                        .iter()
                        .enumerate()
                        .find(|(index, (input, previous))| {
                            *input < pending.input
                                && !matched.contains(index)
                                && relaxed_match(policy, previous, &pending.record)
                        })
                })
                .map(|(index, _)| index)
        });
        if let Some(index) = duplicate {
            matched.insert(index);
            summary.duplicates_removed =
                summary.duplicates_removed.checked_add(1).ok_or_else(|| {
                    RsomicsError::InvalidInput("duplicate count exceeds u64".to_owned())
                })?;
            continue;
        }
        if options.drop_genotypes {
            *pending.record.samples_mut() = Samples::default();
        }
        summary.records_written = summary.records_written.checked_add(1).ok_or_else(|| {
            RsomicsError::InvalidInput("output record count exceeds u64".to_owned())
        })?;
        writer.write_record(header, &pending.record, summary.records_written)?;
        accepted.push((pending.input, pending.record));
    }
    Ok(())
}

fn relaxed_match(policy: DuplicatePolicy, left: &RecordBuf, right: &RecordBuf) -> bool {
    let left_type = variant_type::record_mask(left);
    let right_type = variant_type::record_mask(right);
    match policy {
        DuplicatePolicy::Exact => false,
        DuplicatePolicy::All => true,
        DuplicatePolicy::Snps => {
            same_class(left_type, right_type, variant_type::SNP | variant_type::MNP)
        }
        DuplicatePolicy::Indels => same_class(left_type, right_type, variant_type::INDEL),
        DuplicatePolicy::Both => {
            same_class(left_type, right_type, variant_type::SNP | variant_type::MNP)
                || same_class(left_type, right_type, variant_type::INDEL)
        }
    }
}

fn exact_alleles(left: &RecordBuf, right: &RecordBuf) -> bool {
    if !left
        .reference_bases()
        .eq_ignore_ascii_case(right.reference_bases())
    {
        return false;
    }
    let left = left.alternate_bases().as_ref();
    let right = right.alternate_bases().as_ref();
    if left.len() != right.len() {
        return false;
    }
    let mut matched = vec![false; right.len()];
    left.iter().all(|allele| {
        right
            .iter()
            .enumerate()
            .find(|(index, candidate)| !matched[*index] && allele.eq_ignore_ascii_case(candidate))
            .is_some_and(|(index, _)| {
                matched[index] = true;
                true
            })
    })
}

fn same_class(left: u32, right: u32, mask: u32) -> bool {
    left & mask != 0 && right & mask != 0
}

#[cfg(test)]
mod tests {
    use noodles_vcf::{Header, Record, variant::RecordBuf};

    use super::exact_alleles;

    fn record(alleles: &str) -> RecordBuf {
        let header = Header::default();
        let source =
            Record::try_from(format!("chr1\t1\t.\tA\t{alleles}\t.\tPASS\t.").as_bytes()).unwrap();
        RecordBuf::try_from_variant_record(&header, &source).unwrap()
    }

    #[test]
    fn exact_alleles_are_case_insensitive_unordered_multisets() {
        assert!(exact_alleles(&record("C,G"), &record("g,c")));
        assert!(!exact_alleles(&record("C,C"), &record("C,G")));
    }
}
