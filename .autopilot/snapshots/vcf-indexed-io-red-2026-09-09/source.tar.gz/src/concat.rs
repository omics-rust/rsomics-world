mod header;
mod ligate;
mod naive;
mod stream;

use std::collections::{HashMap, HashSet};
use std::io::Write;
use std::path::{Path, PathBuf};

use noodles_vcf::{Header, header::StringMaps, variant::RecordBuf, variant::record_buf::Samples};
use rsomics_common::{Result, RsomicsError};
use serde::Serialize;

use crate::format::{
    HeaderMode, OutputFormat, ParallelWriter, Reader, RecordScratch, VariantWriter, Writer,
};
use crate::regions::RegionSet;

#[derive(Clone, Debug)]
pub(crate) struct Options {
    pub(crate) drop_genotypes: bool,
    pub(crate) output_format: OutputFormat,
    pub(crate) mode: Mode,
    pub(crate) regions: Option<RegionSet>,
}

#[derive(Clone, Copy, Debug)]
pub(crate) enum Mode {
    Ordered,
    Overlap {
        duplicate_policy: Option<DuplicatePolicy>,
    },
    Ligate(LigateOptions),
}

#[derive(Clone, Copy, Debug)]
pub(crate) struct LigateOptions {
    pub(crate) compact_ps: bool,
    pub(crate) force: bool,
    pub(crate) warn: bool,
    pub(crate) min_pq: u32,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum DuplicatePolicy {
    Snps,
    Indels,
    Both,
    All,
    Exact,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize)]
pub(crate) struct Summary {
    inputs: u64,
    records_read: u64,
    records_written: u64,
    duplicates_removed: u64,
    overlap_records_dropped: u64,
    samples_dropped: u64,
    phase_orientations_changed: u64,
    output_format: OutputFormat,
    raw_bgzf: bool,
}

impl Summary {
    pub(crate) fn overlap_records_dropped(&self) -> u64 {
        self.overlap_records_dropped
    }
}

pub(super) struct PlannedInput {
    pub(super) path: PathBuf,
    pub(super) header: Header,
}

struct Preflight {
    inputs: Vec<PlannedInput>,
    stdin: Option<(usize, Reader)>,
    header: Header,
}

struct OrderState {
    references: HashMap<String, usize>,
    previous: Option<(usize, usize)>,
    seen: HashSet<usize>,
}

pub(crate) fn write(inputs: &[PathBuf], options: &Options, output: impl Write) -> Result<Summary> {
    write_with_writer(inputs, options, Writer::new(output, options.output_format))
}

pub(crate) fn write_naive(inputs: &[PathBuf], output: impl Write) -> Result<Summary> {
    naive::write(inputs, output)
}

pub(crate) fn write_parallel<W>(
    inputs: &[PathBuf],
    options: &Options,
    output: W,
    workers: usize,
) -> Result<Summary>
where
    W: Write + Send + 'static,
{
    write_with_writer(
        inputs,
        options,
        ParallelWriter::new(output, options.output_format, workers)?,
    )
}

fn write_with_writer(
    inputs: &[PathBuf],
    options: &Options,
    mut writer: impl VariantWriter,
) -> Result<Summary> {
    let mut preflight = preflight(inputs, options.drop_genotypes)?;
    if matches!(options.mode, Mode::Ligate(_)) {
        ligate::prepare_header(&mut preflight.header)?;
    }
    writer.write_header(&preflight.header, HeaderMode::Full)?;
    let mut summary = Summary {
        inputs: inputs.len() as u64,
        records_read: 0,
        records_written: 0,
        duplicates_removed: 0,
        overlap_records_dropped: 0,
        samples_dropped: if options.drop_genotypes {
            preflight
                .inputs
                .first()
                .map_or(0, |input| input.header.sample_names().len() as u64)
        } else {
            0
        },
        phase_orientations_changed: 0,
        output_format: options.output_format,
        raw_bgzf: false,
    };

    match options.mode {
        Mode::Ordered => write_ordered(&mut preflight, options, &mut writer, &mut summary)?,
        Mode::Overlap { duplicate_policy } => stream::write_overlap(
            &preflight.inputs,
            &preflight.header,
            options,
            duplicate_policy,
            &mut writer,
            &mut summary,
        )?,
        Mode::Ligate(ligate_options) => ligate::write(
            &preflight.inputs,
            &preflight.header,
            ligate_options,
            &mut writer,
            &mut summary,
        )?,
    }
    writer.finish()?;
    Ok(summary)
}

fn write_ordered(
    preflight: &mut Preflight,
    options: &Options,
    writer: &mut impl VariantWriter,
    summary: &mut Summary,
) -> Result<()> {
    let mut order = OrderState::new(&preflight.header);
    for index in 0..preflight.inputs.len() {
        let planned = &preflight.inputs[index];
        let mut reader = if preflight
            .stdin
            .as_ref()
            .is_some_and(|(position, _)| *position == index)
        {
            preflight.stdin.take().unwrap().1
        } else {
            reopen(planned)?
        };
        stream_input(
            &mut reader,
            planned,
            &preflight.header,
            options,
            &mut order,
            writer,
            summary,
        )?;
    }
    Ok(())
}

pub(super) fn reopen(planned: &PlannedInput) -> Result<Reader> {
    let mut reader = Reader::open(&planned.path)?;
    let (header, _, _) = reader.read_header()?;
    if header != planned.header {
        return Err(RsomicsError::InvalidInput(format!(
            "variant header changed after preflight: {}",
            planned.path.display()
        )));
    }
    Ok(reader)
}

fn preflight(inputs: &[PathBuf], drop_genotypes: bool) -> Result<Preflight> {
    if inputs.is_empty() {
        return Err(RsomicsError::ConfigError(
            "concat requires at least one input".to_owned(),
        ));
    }
    let mut planned = Vec::with_capacity(inputs.len());
    let mut stdin = None;
    let mut merged = None;
    for (index, path) in inputs.iter().enumerate() {
        let mut reader = Reader::open(path)?;
        let (header, _, _) = reader.read_header()?;
        if let Some(target) = &mut merged {
            header::merge(target, &header, path, drop_genotypes)?;
        } else {
            merged = Some(header.clone());
        }
        planned.push(PlannedInput {
            path: path.clone(),
            header,
        });
        if path == Path::new("-") {
            stdin = Some((index, reader));
        }
    }
    let mut header = merged.unwrap();
    if drop_genotypes {
        header.formats_mut().clear();
        header.sample_names_mut().clear();
    }
    normalize_dictionary(&mut header)?;
    Ok(Preflight {
        inputs: planned,
        stdin,
        header,
    })
}

fn normalize_dictionary(header: &mut Header) -> Result<()> {
    for value in header.contigs_mut().values_mut() {
        *value.idx_mut() = None;
    }
    for value in header.infos_mut().values_mut() {
        *value.idx_mut() = None;
    }
    for value in header.filters_mut().values_mut() {
        *value.idx_mut() = None;
    }
    for value in header.formats_mut().values_mut() {
        *value.idx_mut() = None;
    }
    let maps = StringMaps::try_from(&*header).map_err(|error| {
        RsomicsError::InvalidInput(format!("building merged BCF dictionary: {error}"))
    })?;
    *header.string_maps_mut() = maps;
    Ok(())
}

fn stream_input(
    reader: &mut Reader,
    input: &PlannedInput,
    output_header: &Header,
    options: &Options,
    order: &mut OrderState,
    writer: &mut impl VariantWriter,
    summary: &mut Summary,
) -> Result<()> {
    let mut scratch = RecordScratch::default();
    let mut input_record = 0u64;
    loop {
        input_record = input_record.checked_add(1).ok_or_else(|| {
            RsomicsError::InvalidInput("variant record count exceeds u64".to_owned())
        })?;
        let Some(mut record) = reader.read_record(&input.header, &mut scratch, input_record)?
        else {
            break;
        };
        summary.records_read = summary.records_read.checked_add(1).ok_or_else(|| {
            RsomicsError::InvalidInput("variant record count exceeds u64".to_owned())
        })?;
        order.validate(&record, &input.path, input_record)?;
        if options.drop_genotypes {
            *record.samples_mut() = Samples::default();
        }
        summary.records_written = summary.records_written.checked_add(1).ok_or_else(|| {
            RsomicsError::InvalidInput("output record count exceeds u64".to_owned())
        })?;
        writer.write_record(output_header, &record, summary.records_written)?;
    }
    Ok(())
}

impl OrderState {
    fn new(header: &Header) -> Self {
        let references = header
            .contigs()
            .keys()
            .enumerate()
            .map(|(index, name)| (name.clone(), index))
            .collect();
        Self {
            references,
            previous: None,
            seen: HashSet::new(),
        }
    }

    fn validate(&mut self, record: &RecordBuf, path: &Path, number: u64) -> Result<()> {
        let reference = self
            .references
            .get(record.reference_sequence_name())
            .copied()
            .ok_or_else(|| {
                invalid_record(
                    path,
                    number,
                    "reference sequence is absent from the merged header",
                )
            })?;
        let position = record
            .variant_start()
            .map(usize::from)
            .ok_or_else(|| invalid_record(path, number, "variant position is missing"))?;
        if let Some((previous_reference, previous_position)) = self.previous {
            if reference < previous_reference
                || (reference == previous_reference && position < previous_position)
            {
                return Err(invalid_record(
                    path,
                    number,
                    "input records are not coordinate sorted",
                ));
            }
            if reference != previous_reference && !self.seen.insert(previous_reference) {
                return Err(invalid_record(
                    path,
                    number,
                    "reference sequence blocks are not contiguous",
                ));
            }
        }
        self.previous = Some((reference, position));
        Ok(())
    }
}

pub(super) fn invalid_record(path: &Path, number: u64, message: &str) -> RsomicsError {
    RsomicsError::InvalidInput(format!(
        "{} record {number}: {message}",
        if path == Path::new("-") {
            "standard input".to_owned()
        } else {
            path.display().to_string()
        }
    ))
}
