use std::fs::File;
use std::path::{Path, PathBuf};

use noodles_bgzf as bgzf;
use noodles_core::{Position, Region, region::Interval};
use noodles_util::variant::io::indexed_reader;
use noodles_vcf::variant::{RecordBuf, record::info::field::key, record_buf::info::field::Value};
use rsomics_common::{Context, Result, RsomicsError};

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub enum OverlapMode {
    Position,
    #[default]
    Record,
    Variant,
}

#[derive(Clone, Debug)]
pub struct RegionSet {
    regions: Vec<Region>,
    overlap: OverlapMode,
}

#[derive(Clone, Debug)]
pub struct RegionSelection {
    regions: RegionSet,
    exclude: bool,
}

pub(crate) struct IndexedRecords {
    reader: indexed_reader::IndexedReader<bgzf::io::Reader<File>>,
    header: noodles_vcf::Header,
    regions: Vec<Region>,
    overlap: OverlapMode,
    input: PathBuf,
}

type ChunkReader<'a> = noodles_csi::io::Query<'a, bgzf::io::Reader<File>>;

enum QueryReader<'a> {
    Vcf(
        noodles_vcf::io::Reader<ChunkReader<'a>>,
        noodles_vcf::Record,
    ),
    Bcf(
        noodles_bcf::io::Reader<ChunkReader<'a>>,
        noodles_bcf::Record,
    ),
}

pub(crate) struct IndexedQuery<'a> {
    reader: QueryReader<'a>,
    header: &'a noodles_vcf::Header,
    input: &'a Path,
    regions: &'a [Region],
    overlap: OverlapMode,
    read: &'a mut u64,
}

impl IndexedRecords {
    pub(crate) fn open(input: &Path, regions: &RegionSet) -> Result<Self> {
        let index = crate::index::read_fresh(input)?;
        let mut reader = indexed_reader::Builder::default()
            .set_index(index)
            .build_from_path(input)
            .rs_with_context(|| format!("opening indexed variant input {}", input.display()))?;
        let header = reader
            .read_header()
            .rs_with_context(|| format!("reading variant header {}", input.display()))?;
        let query_regions = regions.merged(&header)?;
        Ok(Self {
            reader,
            header,
            regions: query_regions,
            overlap: regions.overlap(),
            input: input.to_path_buf(),
        })
    }

    pub(crate) fn header(&self) -> &noodles_vcf::Header {
        &self.header
    }

    pub(crate) fn query_contig<'a>(
        &'a mut self,
        regions: &'a [Region],
        read: &'a mut u64,
    ) -> Result<IndexedQuery<'a>> {
        let name = regions[0].name();
        let index = self.reader.index();
        let reference = match &self.reader {
            indexed_reader::IndexedReader::Vcf(_) => index
                .header()
                .and_then(|header| header.reference_sequence_names().get_index_of(name)),
            indexed_reader::IndexedReader::Bcf(_) => {
                let name = std::str::from_utf8(name).map_err(|_| {
                    RsomicsError::InvalidInput(format!(
                        "region reference name is not UTF-8: {name}"
                    ))
                })?;
                self.header.string_maps().contigs().get_index_of(name)
            }
        }
        .ok_or_else(|| {
            RsomicsError::InvalidInput(format!(
                "indexed input {} has no reference for region {name}",
                self.input.display()
            ))
        })?;
        let mut chunks = Vec::new();
        for region in regions {
            chunks.extend(
                index
                    .query(reference, region.interval())
                    .rs_with_context(|| {
                        format!("querying region {region} in {}", self.input.display())
                    })?,
            );
        }
        let chunks = noodles_csi::binning_index::merge_chunks(&chunks);
        let reader = match &mut self.reader {
            indexed_reader::IndexedReader::Vcf(reader) => QueryReader::Vcf(
                noodles_vcf::io::Reader::new(noodles_csi::io::Query::new(reader.get_mut(), chunks)),
                noodles_vcf::Record::default(),
            ),
            indexed_reader::IndexedReader::Bcf(reader) => QueryReader::Bcf(
                noodles_bcf::io::Reader::from(noodles_csi::io::Query::new(
                    reader.get_mut(),
                    chunks,
                )),
                noodles_bcf::Record::default(),
            ),
        };
        Ok(IndexedQuery {
            reader,
            header: &self.header,
            input: &self.input,
            regions,
            overlap: self.overlap,
            read,
        })
    }

    pub(crate) fn visit(
        &mut self,
        mut visit: impl FnMut(&noodles_vcf::Header, RecordBuf, u64) -> Result<()>,
    ) -> Result<u64> {
        let Self {
            reader,
            header,
            regions,
            overlap,
            input,
        } = self;
        let mut read = 0;
        for (region_index, region) in regions.iter().enumerate() {
            let records = query_records(
                reader,
                header,
                input,
                *overlap,
                region,
                &regions[..region_index],
                &mut read,
            )?;
            for result in records {
                let (record, number) = result?;
                visit(header, record, number)?;
            }
        }
        Ok(read)
    }
}

impl QueryReader<'_> {
    fn read_record(&mut self) -> std::io::Result<Option<&dyn noodles_vcf::variant::Record>> {
        match self {
            Self::Vcf(reader, record) => match reader.read_record(record)? {
                0 => Ok(None),
                _ => Ok(Some(record)),
            },
            Self::Bcf(reader, record) => match reader.read_record(record)? {
                0 => Ok(None),
                _ => Ok(Some(record)),
            },
        }
    }
}

impl IndexedQuery<'_> {
    fn read_record(&mut self) -> Result<Option<(RecordBuf, u64)>> {
        loop {
            let number = self.read.checked_add(1).ok_or_else(|| {
                RsomicsError::InvalidInput("variant record count exceeds u64".to_owned())
            })?;
            let Some(record) = self.reader.read_record().rs_with_context(|| {
                format!(
                    "reading indexed variant record {number} in {}",
                    self.input.display()
                )
            })?
            else {
                return Ok(None);
            };
            if !intersects_query(self.header, record, self.regions).rs_with_context(|| {
                format!(
                    "locating indexed variant record {number} in {}",
                    self.input.display()
                )
            })? {
                continue;
            }
            let record =
                RecordBuf::try_from_variant_record(self.header, record).map_err(|error| {
                    RsomicsError::InvalidInput(format!(
                        "{}: decoding indexed variant record {number}: {error}",
                        self.input.display()
                    ))
                })?;
            *self.read = number;
            if self
                .regions
                .iter()
                .any(|region| overlaps(&record, region.interval(), self.overlap))
            {
                return Ok(Some((record, number)));
            }
        }
    }
}

impl Iterator for IndexedQuery<'_> {
    type Item = Result<(RecordBuf, u64)>;

    fn next(&mut self) -> Option<Self::Item> {
        self.read_record().transpose()
    }
}

fn intersects_query(
    header: &noodles_vcf::Header,
    record: &dyn noodles_vcf::variant::Record,
    regions: &[Region],
) -> std::io::Result<bool> {
    let name = record.reference_sequence_name(header)?;
    let region_name: &[u8] = regions[0].name().as_ref();
    if name.as_bytes() != region_name {
        return Ok(false);
    }
    let Some(start) = record.variant_start().transpose()? else {
        return Ok(false);
    };
    let interval = Interval::from(start..=record.variant_end(header)?);
    Ok(regions
        .iter()
        .any(|region| region.interval().intersects(interval)))
}

fn query_records<'a>(
    reader: &'a mut indexed_reader::IndexedReader<bgzf::io::Reader<File>>,
    header: &'a noodles_vcf::Header,
    input: &'a Path,
    overlap: OverlapMode,
    region: &'a Region,
    previous: &'a [Region],
    read: &'a mut u64,
) -> Result<impl Iterator<Item = Result<(RecordBuf, u64)>> + 'a> {
    let records = reader
        .query(header, region)
        .rs_with_context(|| format!("querying region {region} in {}", input.display()))?;
    Ok(records.filter_map(move |result| {
        let result = (|| {
            let number = read.checked_add(1).ok_or_else(|| {
                RsomicsError::InvalidInput("variant record count exceeds u64".to_owned())
            })?;
            let record = result.rs_with_context(|| {
                format!(
                    "reading indexed variant record {number} in {}",
                    input.display()
                )
            })?;
            let record =
                RecordBuf::try_from_variant_record(header, record.as_ref()).map_err(|error| {
                    RsomicsError::InvalidInput(format!(
                        "{}: decoding indexed variant record {number}: {error}",
                        input.display()
                    ))
                })?;
            *read = number;
            let keep = overlaps(&record, region.interval(), overlap)
                && !previous.iter().any(|previous| {
                    previous.name() == region.name()
                        && overlaps(&record, previous.interval(), overlap)
                });
            Ok(keep.then_some((record, number)))
        })();
        result.transpose()
    }))
}

impl RegionSelection {
    pub fn new(regions: RegionSet, exclude: bool) -> Self {
        Self { regions, exclude }
    }

    pub fn parse(
        values: impl IntoIterator<Item = String>,
        overlap: OverlapMode,
        exclude: bool,
    ) -> Result<Self> {
        RegionSet::parse(values, overlap).map(|regions| Self::new(regions, exclude))
    }

    pub(crate) fn keeps(&self, record: &RecordBuf) -> bool {
        self.regions.matches(record) != self.exclude
    }
}

impl RegionSet {
    pub fn new(regions: Vec<Region>, overlap: OverlapMode) -> Result<Self> {
        if regions.is_empty() {
            return Err(RsomicsError::InvalidInput(
                "region list is empty".to_owned(),
            ));
        }
        Ok(Self { regions, overlap })
    }

    pub fn parse(values: impl IntoIterator<Item = String>, overlap: OverlapMode) -> Result<Self> {
        let regions = values
            .into_iter()
            .map(|value| parse_region(&value))
            .collect::<Result<Vec<_>>>()?;
        Self::new(regions, overlap)
    }

    pub(crate) fn matches(&self, record: &RecordBuf) -> bool {
        self.regions.iter().any(|region| {
            let name: &[u8] = region.name().as_ref();
            name == record.reference_sequence_name().as_bytes()
                && overlaps(record, region.interval(), self.overlap)
        })
    }

    pub(crate) fn merged(&self, header: &noodles_vcf::Header) -> Result<Vec<Region>> {
        let mut values = Vec::with_capacity(self.regions.len());
        for region in &self.regions {
            let name = std::str::from_utf8(region.name().as_ref()).map_err(|_| {
                RsomicsError::InvalidInput(format!(
                    "region reference name is not UTF-8: {}",
                    region.name()
                ))
            })?;
            let reference = header.contigs().get_index_of(name).ok_or_else(|| {
                RsomicsError::InvalidInput(format!(
                    "region reference is absent from the VCF header: {name}"
                ))
            })?;
            values.push((
                reference,
                name.to_owned(),
                region.interval().start().unwrap_or(Position::MIN),
                region.interval().end().unwrap_or(Position::MAX),
            ));
        }
        values.sort_by_key(|(reference, _, start, end)| (*reference, *start, *end));

        let mut merged: Vec<(usize, String, Position, Position)> = Vec::new();
        for (reference, name, start, end) in values {
            if let Some((last_reference, _, _, last_end)) = merged.last_mut()
                && *last_reference == reference
                && start <= last_end.checked_add(1).unwrap_or(Position::MAX)
            {
                *last_end = (*last_end).max(end);
                continue;
            }
            merged.push((reference, name, start, end));
        }
        Ok(merged
            .into_iter()
            .map(|(_, name, start, end)| Region::new(name, start..=end))
            .collect())
    }

    pub(crate) fn overlap(&self) -> OverlapMode {
        self.overlap
    }
}

fn parse_region(value: &str) -> Result<Region> {
    let interval = value.rsplit_once(':').map(|(_, interval)| interval);
    let open_end = interval
        .and_then(|interval| interval.strip_suffix('-'))
        .is_some_and(is_coordinate);
    let normalized = if open_end {
        value.strip_suffix('-').unwrap()
    } else {
        value
    };
    let region: Region = normalized.parse().map_err(|error| {
        RsomicsError::InvalidInput(format!("invalid region {value:?}: {error}"))
    })?;
    if interval.is_some_and(is_coordinate) {
        let start = region.interval().start().ok_or_else(|| {
            RsomicsError::InvalidInput(format!("invalid region {value:?}: missing position"))
        })?;
        Ok(Region::new(region.name().to_owned(), start..=start))
    } else {
        Ok(region)
    }
}

fn is_coordinate(value: &str) -> bool {
    !value.is_empty()
        && value
            .bytes()
            .all(|byte| byte.is_ascii_digit() || byte == b',')
}

pub(crate) fn overlaps(record: &RecordBuf, interval: Interval, mode: OverlapMode) -> bool {
    let Some(start) = record.variant_start() else {
        return false;
    };
    match mode {
        OverlapMode::Position => interval.contains(start),
        OverlapMode::Record => interval.intersects(record_interval(record, start)),
        OverlapMode::Variant => {
            variant_interval(record, start).is_some_and(|variant| interval.intersects(variant))
        }
    }
}

fn record_interval(record: &RecordBuf, start: Position) -> Interval {
    let end = record
        .info()
        .get(key::END_POSITION)
        .flatten()
        .and_then(|value| match value {
            Value::Integer(value) => usize::try_from(*value).ok(),
            _ => None,
        })
        .and_then(|value| Position::try_from(value).ok())
        .filter(|end| *end >= start)
        .unwrap_or_else(|| {
            start
                .checked_add(record.reference_bases().len().max(1) - 1)
                .unwrap_or(Position::MAX)
        });
    Interval::from(start..=end)
}

fn variant_interval(record: &RecordBuf, start: Position) -> Option<Interval> {
    let alternates = record.alternate_bases();
    if alternates.as_ref().is_empty() {
        return None;
    }
    let reference = record.reference_bases().as_bytes();
    let end = record_interval(record, start).end().unwrap();
    let mut offset = usize::from(end) - usize::from(start) + 1;
    for alternate in alternates.as_ref() {
        let prefix = reference
            .iter()
            .zip(alternate.as_bytes())
            .take_while(|(reference, alternate)| reference == alternate)
            .count();
        offset = offset.min(prefix);
        if offset == 0 {
            break;
        }
    }
    let variant_start = start.checked_add(offset)?;
    (variant_start <= end).then(|| Interval::from(variant_start..=end))
}

#[cfg(test)]
mod tests {
    use noodles_vcf::{self as vcf, variant::RecordBuf};

    use super::*;

    fn record(value: &[u8]) -> RecordBuf {
        let header: vcf::Header = "##fileformat=VCFv4.3\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\n"
            .parse()
            .unwrap();
        let record = vcf::Record::try_from(value).unwrap();
        RecordBuf::try_from_variant_record(&header, &record).unwrap()
    }

    #[test]
    fn literal_variant_overlap_keeps_the_reference_suffix() {
        let record = record(b"chr1\t10\t.\tAACGT\tAATGT\t10\tPASS\t.");
        assert!(!overlaps(
            &record,
            "12-14".parse().unwrap(),
            OverlapMode::Position
        ));
        assert!(overlaps(
            &record,
            "14".parse().unwrap(),
            OverlapMode::Variant
        ));
    }

    #[test]
    fn literal_insertions_and_absent_alternates_have_no_reference_span() {
        for record in [
            record(b"chr1\t25\t.\tA\tAT\t10\tPASS\t."),
            record(b"chr1\t25\t.\tA\t.\t10\tPASS\t."),
        ] {
            assert!(!overlaps(
                &record,
                "25-26".parse().unwrap(),
                OverlapMode::Variant
            ));
        }
    }

    #[test]
    fn region_selection_can_include_or_exclude_matches() {
        let record = record(b"chr1\t10\t.\tA\tC\t10\tPASS\t.");
        let regions = RegionSet::parse(["chr1:10".to_owned()], OverlapMode::Position).unwrap();

        assert!(RegionSelection::new(regions.clone(), false).keeps(&record));
        assert!(!RegionSelection::new(regions, true).keeps(&record));
    }

    #[test]
    fn single_coordinate_regions_are_not_open_ended() {
        let exact = RegionSet::parse(["chr1:10".to_owned()], OverlapMode::Position).unwrap();
        let open = RegionSet::parse(["chr1:10-".to_owned()], OverlapMode::Position).unwrap();
        let later = record(b"chr1\t12\t.\tA\tC\t10\tPASS\t.");

        assert!(!exact.matches(&later));
        assert!(open.matches(&later));
    }
}
