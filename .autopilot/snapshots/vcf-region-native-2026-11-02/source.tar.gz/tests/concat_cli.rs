use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::{Command, Output, Stdio};

const BGZF_EOF: [u8; 28] = [
    0x1f, 0x8b, 0x08, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0xff, 0x06, 0x00, 0x42, 0x43, 0x02, 0x00,
    0x1b, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
];

struct Fixture {
    _directory: tempfile::TempDir,
    first: PathBuf,
    second: PathBuf,
    conflicting_samples: PathBuf,
    regressing: PathBuf,
    overlapping: PathBuf,
    ligate_first: PathBuf,
    ligate_second: PathBuf,
}

impl Fixture {
    fn new() -> Self {
        let directory = tempfile::tempdir().unwrap();
        let first = directory.path().join("first.vcf");
        let second = directory.path().join("second.vcf");
        let conflicting_samples = directory.path().join("samples.vcf");
        let regressing = directory.path().join("regressing.vcf");
        let overlapping = directory.path().join("overlapping.vcf");
        let ligate_first = directory.path().join("ligate-first.vcf");
        let ligate_second = directory.path().join("ligate-second.vcf");
        fs::write(
            &first,
            b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Depth\">\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t10\ta\tA\tC\t.\tPASS\tDP=4\tGT\t0/1\n",
        )
        .unwrap();
        fs::write(
            &second,
            b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##contig=<ID=chr2,length=50>\n\
##FILTER=<ID=q10,Description=\"Low quality\">\n\
##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Later depth text\">\n\
##INFO=<ID=AF,Number=A,Type=Float,Description=\"Frequency\">\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t20\tb\tG\tT\t.\tq10\tDP=8;AF=0.5\tGT\t1/1\n\
chr2\t1\tc\tC\tA\t.\tPASS\tAF=0.25\tGT\t0/1\n",
        )
        .unwrap();
        fs::write(
            &conflicting_samples,
            b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS2\n\
chr1\t20\tb\tG\tT\t.\tPASS\t.\tGT\t0/1\n",
        )
        .unwrap();
        fs::write(
            &regressing,
            b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t20\tb\tG\tT\t.\tPASS\t.\tGT\t0/1\n\
chr1\t15\tc\tC\tA\t.\tPASS\t.\tGT\t0/1\n",
        )
        .unwrap();
        fs::write(
            &overlapping,
            b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Depth\">\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t5\tearly\tA\tG\t.\tPASS\tDP=2\tGT\t0/1\n\
chr1\t10\tduplicate-1\tA\tC\t.\tPASS\tDP=9\tGT\t1/1\n\
chr1\t10\twithin-1\tA\tG\t.\tPASS\tDP=10\tGT\t0/1\n\
chr1\t10\twithin-2\tA\tG\t.\tPASS\tDP=11\tGT\t1/1\n\
chr1\t15\tlater\tC\tT\t.\tPASS\tDP=3\tGT\t0/1\n",
        )
        .unwrap();
        fs::write(
            &ligate_first,
            b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\tS2\n\
chr1\t10\tl1\tA\tC\t.\tPASS\t.\tGT\t0|1\t0|0\n\
chr1\t20\tl2\tG\tT\t.\tPASS\t.\tGT\t0|1\t1|0\n\
chr1\t30\tl3\tC\tG\t.\tPASS\t.\tGT\t1|0\t0|1\n",
        )
        .unwrap();
        fs::write(
            &ligate_second,
            b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\tS2\n\
chr1\t20\tl2\tG\tT\t.\tPASS\t.\tGT\t1|0\t1|0\n\
chr1\t30\tl3\tC\tG\t.\tPASS\t.\tGT\t0|1\t0|1\n\
chr1\t40\tl4\tT\tA\t.\tPASS\t.\tGT\t1|0\t0|1\n",
        )
        .unwrap();
        Self {
            _directory: directory,
            first,
            second,
            conflicting_samples,
            regressing,
            overlapping,
            ligate_first,
            ligate_second,
        }
    }
}

fn command() -> Command {
    Command::new(env!("CARGO_BIN_EXE_rsomics-vcf"))
}

fn success(output: Output) -> Output {
    assert!(
        output.status.success(),
        "stdout={}\nstderr={}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    output
}

fn record_lines(output: &[u8]) -> Vec<&[u8]> {
    output
        .split(|byte| *byte == b'\n')
        .filter(|line| !line.is_empty() && !line.starts_with(b"#"))
        .collect()
}

fn path(path: &Path) -> &str {
    path.to_str().unwrap()
}

fn index_vcf(input: &Path, output: &Path) {
    success(
        command()
            .args(["view", "-O", "z", "-o", path(output), path(input)])
            .output()
            .unwrap(),
    );
    success(command().args(["index", path(output)]).output().unwrap());
}

fn convert(input: &Path, output: &Path, encoding: &str) {
    success(
        command()
            .args(["view", "-O", encoding, "-o", path(output), path(input)])
            .output()
            .unwrap(),
    );
}

#[test]
fn help_exposes_the_complete_family_surface() {
    let output = success(command().args(["concat", "--help"]).output().unwrap());
    let help = String::from_utf8(output.stdout).unwrap();
    for option in [
        "-f, --file-list <FILE>",
        "-a, --allow-overlaps",
        "-d, --rm-dups <MODE>",
        "-G, --drop-genotypes",
        "-l, --ligate",
        "-c, --compact-PS",
        "--ligate-force",
        "--ligate-warn",
        "-q, --min-PQ <INT>",
        "-r, --regions <REGIONS>",
        "--regions-overlap <MODE>",
        "-n, --naive",
        "-O, --output-type <TYPE>",
        "--threads <INT>",
    ] {
        assert!(help.contains(option), "missing {option} in {help}");
    }
}

#[test]
fn invalid_argument_combinations_and_output_aliases_fail_loud() {
    let fixture = Fixture::new();
    let list = fixture._directory.path().join("empty.list");
    fs::write(&list, b"\n# no inputs\n").unwrap();
    let first = path(&fixture.first);
    for arguments in [
        vec!["concat", "--file-list", path(&list), first],
        vec!["concat", "--rm-dups", "exact", first],
        vec!["concat", "--allow-overlaps", "--ligate", first],
        vec!["concat", "--ligate", "--drop-genotypes", first],
        vec!["concat", "--compact-PS", first],
        vec![
            "concat",
            "--ligate",
            "--ligate-force",
            "--ligate-warn",
            first,
        ],
        vec!["concat", "--naive", "-O", "z", first],
        vec!["concat", "--threads", "1", first],
        vec!["concat", "-", "-"],
    ] {
        let output = command().args(arguments).output().unwrap();
        assert!(!output.status.success());
    }

    let empty = command()
        .args(["concat", "--file-list", path(&list)])
        .output()
        .unwrap();
    assert!(!empty.status.success());
    assert!(String::from_utf8_lossy(&empty.stderr).contains("file list is empty"));

    let before = fs::read(&fixture.first).unwrap();
    let alias = command()
        .args([
            "concat",
            "--output",
            path(&fixture.first),
            path(&fixture.first),
        ])
        .output()
        .unwrap();
    assert!(!alias.status.success());
    assert_eq!(fs::read(&fixture.first).unwrap(), before);

    let regions = fixture._directory.path().join("regions.txt");
    fs::write(&regions, b"chr1:1-20\n").unwrap();
    let alias = command()
        .args([
            "concat",
            "--allow-overlaps",
            "--regions-file",
            path(&regions),
            "--output",
            path(&regions),
            path(&fixture.first),
        ])
        .output()
        .unwrap();
    assert!(!alias.status.success());
    assert_eq!(fs::read(&regions).unwrap(), b"chr1:1-20\n");
}

#[test]
fn ordinary_mode_merges_headers_and_streams_in_argument_order() {
    let fixture = Fixture::new();
    let output = success(
        command()
            .args(["concat", path(&fixture.first), path(&fixture.second)])
            .output()
            .unwrap(),
    );
    let text = String::from_utf8(output.stdout.clone()).unwrap();
    assert_eq!(text.matches("##INFO=<ID=DP,").count(), 1, "{text}");
    assert!(text.contains("##INFO=<ID=AF,Number=A,Type=Float"), "{text}");
    assert!(text.contains("##FILTER=<ID=q10,"), "{text}");
    assert!(text.contains("##contig=<ID=chr2,length=50>"), "{text}");
    let records = record_lines(&output.stdout);
    assert_eq!(records.len(), 3);
    assert!(records[0].starts_with(b"chr1\t10\ta\t"));
    assert!(records[1].starts_with(b"chr1\t20\tb\t"));
    assert!(records[2].starts_with(b"chr2\t1\tc\t"));
}

#[test]
fn ordinary_mode_translates_all_input_and_output_encodings() {
    let fixture = Fixture::new();
    for (case, first_encoding, second_encoding, output_encoding) in [
        ("vz-v", "v", "z", "v"),
        ("zb-z", "z", "b", "z"),
        ("bu-b", "b", "u", "b"),
        ("uv-u", "u", "v", "u"),
    ] {
        let first = fixture
            ._directory
            .path()
            .join(format!("{case}-first.variant"));
        let second = fixture
            ._directory
            .path()
            .join(format!("{case}-second.variant"));
        let output_path = fixture
            ._directory
            .path()
            .join(format!("{case}-output.variant"));
        convert(&fixture.first, &first, first_encoding);
        convert(&fixture.second, &second, second_encoding);
        let mut concat = command();
        concat.args(["concat", "-O", output_encoding, "-o", path(&output_path)]);
        if matches!(output_encoding, "z" | "b") {
            concat.args(["--threads", "2"]);
        }
        success(concat.args([path(&first), path(&second)]).output().unwrap());
        let decoded = success(
            command()
                .args(["view", "-O", "v", path(&output_path)])
                .output()
                .unwrap(),
        );
        let text = String::from_utf8(decoded.stdout).unwrap();
        assert_eq!(
            text.lines().filter(|line| !line.starts_with('#')).count(),
            3,
            "{case}: {text}"
        );
        assert!(text.contains("AF=0.5"), "{case}: {text}");
        assert!(
            text.contains("##INFO=<ID=AF,Number=A,Type=Float"),
            "{case}: {text}"
        );
    }
}

#[test]
fn ordinary_mode_retains_one_standard_input_after_header_preflight() {
    let fixture = Fixture::new();
    let mut child = command()
        .args(["concat", "-", path(&fixture.second)])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap();
    child
        .stdin
        .take()
        .unwrap()
        .write_all(&fs::read(&fixture.first).unwrap())
        .unwrap();
    let output = success(child.wait_with_output().unwrap());
    assert_eq!(record_lines(&output.stdout).len(), 3);
}

#[test]
fn file_list_ignores_blank_and_comment_lines() {
    let fixture = Fixture::new();
    let list = fixture._directory.path().join("inputs.list");
    fs::write(
        &list,
        format!(
            "  # chunks\n\n{}\n  {}  \n",
            fixture.first.display(),
            fixture.second.display()
        ),
    )
    .unwrap();
    let output = success(
        command()
            .args(["concat", "--file-list", path(&list)])
            .output()
            .unwrap(),
    );
    assert_eq!(record_lines(&output.stdout).len(), 3);
}

#[test]
fn incompatible_samples_fail_before_named_output_is_replaced() {
    let fixture = Fixture::new();
    let output_path = fixture._directory.path().join("output.vcf");
    fs::write(&output_path, b"existing").unwrap();
    let output = command()
        .args([
            "concat",
            "--output",
            path(&output_path),
            path(&fixture.first),
            path(&fixture.conflicting_samples),
        ])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert!(output.stdout.is_empty());
    assert_eq!(fs::read(output_path).unwrap(), b"existing");
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("sample"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn semantic_header_conflicts_fail_before_named_output_is_replaced() {
    let fixture = Fixture::new();
    let base = fixture._directory.path().join("header-base.vcf");
    let output_path = fixture._directory.path().join("header-output.vcf");
    let document = |contig: usize, info: &str, format_type: &str, filter: &str, sample: &str| {
        format!(
            "##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length={contig}>\n\
##INFO=<ID=X,Number=1,Type={info},Description=\"X\">\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
##FORMAT=<ID=X,Number=1,Type={format_type},Description=\"X\">\n\
##FILTER=<ID=q10,Description=\"{filter}\">\n\
##SAMPLE=<ID=S,Description=\"{sample}\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n"
        )
    };
    fs::write(&base, document(100, "Integer", "Integer", "low", "base")).unwrap();
    for (name, source) in [
        ("contig", document(101, "Integer", "Integer", "low", "base")),
        ("info", document(100, "Float", "Integer", "low", "base")),
        ("format", document(100, "Integer", "Float", "low", "base")),
        (
            "filter",
            document(100, "Integer", "Integer", "other", "base"),
        ),
        (
            "structured",
            document(100, "Integer", "Integer", "low", "other"),
        ),
    ] {
        let conflict = fixture._directory.path().join(format!("header-{name}.vcf"));
        fs::write(&conflict, source).unwrap();
        fs::write(&output_path, b"existing").unwrap();
        let output = command()
            .args([
                "concat",
                "--output",
                path(&output_path),
                path(&base),
                path(&conflict),
            ])
            .output()
            .unwrap();
        assert!(!output.status.success(), "{name}");
        assert_eq!(fs::read(&output_path).unwrap(), b"existing", "{name}");
        assert!(
            String::from_utf8_lossy(&output.stderr).contains("header conflict"),
            "{name}: {}",
            String::from_utf8_lossy(&output.stderr)
        );
    }
}

#[test]
fn coordinate_regression_fails_loud() {
    let fixture = Fixture::new();
    let output_path = fixture._directory.path().join("regression-output.vcf");
    fs::write(&output_path, b"existing").unwrap();
    let output = command()
        .args([
            "concat",
            "--output",
            path(&output_path),
            path(&fixture.first),
            path(&fixture.regressing),
        ])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert_eq!(fs::read(output_path).unwrap(), b"existing");
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("coordinate sorted"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn malformed_records_fail_without_replacing_named_output() {
    let fixture = Fixture::new();
    let malformed = fixture._directory.path().join("malformed.vcf");
    let output_path = fixture._directory.path().join("malformed-output.vcf");
    fs::write(
        &malformed,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\tbad\tbroken\tA\tC\t.\tPASS\t.\tGT\t0/1\n",
    )
    .unwrap();
    fs::write(&output_path, b"existing").unwrap();
    let output = command()
        .args([
            "concat",
            "--output",
            path(&output_path),
            path(&fixture.first),
            path(&malformed),
        ])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert_eq!(fs::read(&output_path).unwrap(), b"existing");
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("record 1"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn json_requires_named_variant_output() {
    let fixture = Fixture::new();
    let output = command()
        .args(["--json", "concat", path(&fixture.first)])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert!(output.stdout.is_empty());
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("--json requires --output"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn overlap_mode_performs_a_stable_coordinate_merge() {
    let fixture = Fixture::new();
    let output = success(
        command()
            .args([
                "concat",
                "--allow-overlaps",
                path(&fixture.first),
                path(&fixture.overlapping),
            ])
            .output()
            .unwrap(),
    );
    let records = record_lines(&output.stdout);
    let keys: Vec<_> = records
        .iter()
        .map(|record| {
            let fields: Vec<_> = record.split(|byte| *byte == b'\t').collect();
            (fields[1], fields[2])
        })
        .collect();
    assert_eq!(
        keys,
        [
            (b"5".as_slice(), b"early".as_slice()),
            (b"10".as_slice(), b"a".as_slice()),
            (b"10".as_slice(), b"duplicate-1".as_slice()),
            (b"10".as_slice(), b"within-1".as_slice()),
            (b"10".as_slice(), b"within-2".as_slice()),
            (b"15".as_slice(), b"later".as_slice()),
        ]
    );
}

#[test]
fn exact_duplicate_removal_is_cross_input_only_and_first_wins() {
    let fixture = Fixture::new();
    let output_path = fixture._directory.path().join("deduplicated.vcf");
    let output = success(
        command()
            .args([
                "--json",
                "concat",
                "--allow-overlaps",
                "--rm-dups",
                "exact",
                "--output",
                path(&output_path),
                path(&fixture.first),
                path(&fixture.overlapping),
            ])
            .output()
            .unwrap(),
    );
    let records = fs::read(output_path).unwrap();
    let records = record_lines(&records);
    assert_eq!(records.len(), 5);
    let text = records
        .iter()
        .map(|record| String::from_utf8_lossy(record))
        .collect::<Vec<_>>()
        .join("\n");
    assert!(text.contains("within-1"), "{text}");
    assert!(text.contains("within-2"), "{text}");
    assert!(!text.contains("duplicate-1"), "{text}");
    let envelope: serde_json::Value = serde_json::from_slice(&output.stdout).unwrap();
    assert_eq!(envelope["result"]["summary"]["records_read"], 6);
    assert_eq!(envelope["result"]["summary"]["records_written"], 5);
    assert_eq!(envelope["result"]["summary"]["duplicates_removed"], 1);
}

#[test]
fn relaxed_duplicate_matching_is_one_to_one_and_prefers_exact_alleles() {
    let fixture = Fixture::new();
    for mode in ["snps", "both", "all"] {
        let output = success(
            command()
                .args([
                    "concat",
                    "--allow-overlaps",
                    "--rm-dups",
                    mode,
                    path(&fixture.first),
                    path(&fixture.overlapping),
                ])
                .output()
                .unwrap(),
        );
        let text = String::from_utf8(output.stdout).unwrap();
        assert_eq!(
            text.lines().filter(|line| !line.starts_with('#')).count(),
            5
        );
        assert!(!text.contains("duplicate-1"), "{mode}: {text}");
        assert!(text.contains("within-1"), "{mode}: {text}");
        assert!(text.contains("within-2"), "{mode}: {text}");
    }
}

#[test]
fn every_duplicate_mode_has_a_distinct_cross_input_contract() {
    let fixture = Fixture::new();
    let first = fixture._directory.path().join("dups-first.vcf");
    let second = fixture._directory.path().join("dups-second.vcf");
    let header = "##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\n";
    fs::write(
        &first,
        format!(
            "{header}chr1\t10\ta-exact\tA\tC\t.\tPASS\t.\n\
chr1\t10\ta-snp\tA\tG\t.\tPASS\t.\n\
chr1\t10\ta-indel\tA\tAT\t.\tPASS\t.\n"
        ),
    )
    .unwrap();
    fs::write(
        &second,
        format!(
            "{header}chr1\t10\tb-exact\tA\tC\t.\tPASS\t.\n\
chr1\t10\tb-snp\tA\tT\t.\tPASS\t.\n\
chr1\t10\tb-indel\tA\tAG\t.\tPASS\t.\n"
        ),
    )
    .unwrap();

    for (mode, expected) in [
        ("exact", 5),
        ("snps", 4),
        ("indels", 4),
        ("both", 3),
        ("all", 3),
    ] {
        let output = success(
            command()
                .args([
                    "concat",
                    "--allow-overlaps",
                    "--rm-dups",
                    mode,
                    path(&first),
                    path(&second),
                ])
                .output()
                .unwrap(),
        );
        assert_eq!(record_lines(&output.stdout).len(), expected, "{mode}");
    }
}

#[test]
fn overlap_mode_rejects_standard_input_and_unsorted_sources() {
    let fixture = Fixture::new();
    let stdin = command()
        .args(["concat", "--allow-overlaps", "-", path(&fixture.first)])
        .output()
        .unwrap();
    assert!(!stdin.status.success());
    assert!(
        String::from_utf8_lossy(&stdin.stderr).contains("named inputs"),
        "{}",
        String::from_utf8_lossy(&stdin.stderr)
    );

    let unsorted = command()
        .args([
            "concat",
            "--allow-overlaps",
            path(&fixture.first),
            path(&fixture.regressing),
        ])
        .output()
        .unwrap();
    assert!(!unsorted.status.success());
    assert!(
        String::from_utf8_lossy(&unsorted.stderr).contains("coordinate sorted"),
        "{}",
        String::from_utf8_lossy(&unsorted.stderr)
    );
}

#[test]
fn drop_genotypes_removes_format_schema_and_sample_values() {
    let fixture = Fixture::new();
    let first = fixture._directory.path().join("drop-first.vcf");
    let incompatible = fixture
        ._directory
        .path()
        .join("drop-incompatible-format.vcf");
    fs::write(
        &first,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
##FORMAT=<ID=X,Number=1,Type=Integer,Description=\"Integer field\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t10\ta\tA\tC\t.\tPASS\tDP=4\tGT:X\t0/1:1\n",
    )
    .unwrap();
    fs::write(
        &incompatible,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
##FORMAT=<ID=X,Number=1,Type=Float,Description=\"Float field\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS2\n\
chr1\t20\tb\tG\tT\t.\tPASS\t.\tGT:X\t1/1:0.5\n",
    )
    .unwrap();
    let output = success(
        command()
            .args([
                "concat",
                "--drop-genotypes",
                path(&first),
                path(&incompatible),
            ])
            .output()
            .unwrap(),
    );
    let text = String::from_utf8(output.stdout).unwrap();
    assert!(!text.contains("##FORMAT="), "{text}");
    let chrom = text
        .lines()
        .find(|line| line.starts_with("#CHROM"))
        .unwrap();
    assert_eq!(chrom.split('\t').count(), 8);
    assert!(
        text.lines()
            .filter(|line| !line.starts_with('#'))
            .all(|line| line.split('\t').count() == 8)
    );
}

#[test]
fn indexed_regions_are_merged_across_every_input() {
    let fixture = Fixture::new();
    let first = fixture._directory.path().join("first.vcf.gz");
    let second = fixture._directory.path().join("overlap.vcf.gz");
    index_vcf(&fixture.first, &first);
    index_vcf(&fixture.overlapping, &second);
    let output = success(
        command()
            .args([
                "concat",
                "--allow-overlaps",
                "--regions",
                "chr1:10-10",
                path(&first),
                path(&second),
            ])
            .output()
            .unwrap(),
    );
    let records = record_lines(&output.stdout);
    assert_eq!(records.len(), 4);
    assert!(records.iter().all(|record| {
        record
            .split(|byte| *byte == b'\t')
            .nth(1)
            .is_some_and(|position| position == b"10")
    }));
}

#[test]
fn indexed_regions_reject_an_index_older_than_replaced_input() {
    let fixture = Fixture::new();
    let source = fixture._directory.path().join("stale-source.vcf");
    let indexed = fixture._directory.path().join("stale.vcf.gz");
    index_vcf(&fixture.first, &indexed);
    fs::write(
        &source,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Depth\">\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t10\ta\tA\tC\t.\tPASS\tDP=4\tGT\t0/1\n\
chr1\t11\tnew\tG\tT\t.\tPASS\tDP=5\tGT\t0/1\n",
    )
    .unwrap();
    std::thread::sleep(std::time::Duration::from_millis(10));
    convert(&source, &indexed, "z");
    let output = command()
        .args([
            "concat",
            "--allow-overlaps",
            "--regions",
            "chr1:10-11",
            path(&indexed),
        ])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("index is older than its input"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn indexed_input_failures_do_not_emit_stdout() {
    for encoding in ["v", "z", "b", "u"] {
        for invalid_input in 0..2 {
            let fixture = Fixture::new();
            let first = fixture._directory.path().join("first.vcf.gz");
            let second = fixture._directory.path().join("overlap.vcf.gz");
            index_vcf(&fixture.first, &first);
            index_vcf(&fixture.overlapping, &second);
            let inputs = [&first, &second];
            let index = inputs[invalid_input].with_extension("gz.csi");
            assert!(index.is_file());
            fs::write(&index, b"corrupt CSI").unwrap();
            let output = command()
                .args([
                    "concat",
                    "--allow-overlaps",
                    "--regions",
                    "chr1:1-100",
                    "-O",
                    encoding,
                ])
                .args(inputs)
                .output()
                .unwrap();
            assert!(!output.status.success());
            assert!(
                String::from_utf8_lossy(&output.stderr).contains(path(&index)),
                "{}",
                String::from_utf8_lossy(&output.stderr)
            );
            assert!(
                output.stdout.is_empty(),
                "index failure emitted {} bytes for {encoding} output and input {invalid_input}",
                output.stdout.len()
            );
        }
    }
}

#[test]
fn indexed_preflight_finishes_before_serial_or_parallel_writer_creation() {
    for (encoding, threads) in [("v", 0), ("z", 0), ("b", 0), ("u", 0), ("z", 2), ("b", 2)] {
        for failure in ["index", "header", "region"] {
            let fixture = Fixture::new();
            let first = fixture._directory.path().join("first.vcf.gz");
            let second = fixture._directory.path().join("second.vcf.gz");
            index_vcf(&fixture.second, &first);
            index_vcf(
                if failure == "header" {
                    &fixture.conflicting_samples
                } else {
                    &fixture.first
                },
                &second,
            );
            let index = second.with_extension("gz.csi");
            if failure == "index" {
                assert!(index.is_file());
                fs::write(&index, b"corrupt CSI").unwrap();
            }
            let mut concat = command();
            concat.args([
                "concat",
                "-a",
                "-r",
                if failure == "region" {
                    "chr2:1"
                } else {
                    "chr1:1-100"
                },
                "-O",
                encoding,
            ]);
            if threads > 0 {
                concat.args(["--threads", "2"]);
            }
            let output = concat.args([&first, &second]).output().unwrap();
            assert!(!output.status.success());
            let stderr = String::from_utf8_lossy(&output.stderr);
            let expected = match failure {
                "index" => path(&index),
                "header" => "sample names or order differ",
                "region" => "region reference is absent from the VCF header: chr2",
                _ => unreachable!(),
            };
            assert!(stderr.contains(expected), "{stderr}");
            assert!(
                output.stdout.is_empty(),
                "{failure}, {encoding}, {threads} workers: {} stdout bytes",
                output.stdout.len()
            );
        }
    }
}

#[test]
fn indexed_disjoint_queries_preserve_three_input_ties_and_counts() {
    let directory = tempfile::tempdir().unwrap();
    let header = "##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##contig=<ID=chr2,length=100>\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\n";
    let reference = "A".repeat(31);
    for input_encoding in ["z", "b"] {
        let mut inputs = Vec::new();
        let mut bodies = Vec::new();
        for input in 0..3 {
            let source = directory.path().join(format!("source-{input}.vcf"));
            let indexed = directory
                .path()
                .join(format!("input-{input}.{input_encoding}"));
            let body = vec![
                format!("chr1\t10\t{input}-long\t{reference}\tA\t.\tPASS\t."),
                format!("chr1\t20\t{input}-first\tA\tC\t.\tPASS\t."),
                format!("chr1\t20\t{input}-repeat\tA\tC\t.\tPASS\t."),
                format!("chr1\t30\t{input}-second\tA\tG\t.\tPASS\t."),
                format!("chr1\t90\t{input}-outside\tA\tT\t.\tPASS\t."),
                format!("chr2\t5\t{input}-tail\tT\tA\t.\tPASS\t."),
            ];
            fs::write(&source, format!("{header}{}\n", body.join("\n"))).unwrap();
            convert(&source, &indexed, input_encoding);
            success(command().arg("index").arg(&indexed).output().unwrap());
            inputs.push(indexed);
            bodies.push(body);
        }
        for output_encoding in ["v", "z", "b", "u"] {
            for deduplicate in [false, true] {
                let destination = directory.path().join("merged.data");
                let mut concat = command();
                concat
                    .args([
                        "--json",
                        "concat",
                        "-a",
                        "-r",
                        "chr2:5,chr1:30-31,chr1:20-20,chr1:19-21,chr1:60",
                        "-O",
                        output_encoding,
                        "-o",
                    ])
                    .arg(&destination);
                if deduplicate {
                    concat.args(["-d", "exact"]);
                }
                let output = success(concat.args(&inputs).output().unwrap());
                let json: serde_json::Value = serde_json::from_slice(&output.stdout).unwrap();
                let summary = &json["result"]["summary"];
                let mut expected = Vec::new();
                for slots in [&[0][..], &[1, 2][..], &[3][..], &[5][..]] {
                    for body in bodies.iter().take(if deduplicate { 1 } else { 3 }) {
                        expected.extend(slots.iter().map(|&slot| body[slot].clone()));
                    }
                }
                let decoded = success(command().arg("view").arg(&destination).output().unwrap());
                let actual: Vec<_> = record_lines(&decoded.stdout)
                    .into_iter()
                    .map(|line| String::from_utf8(line.to_vec()).unwrap())
                    .collect();
                assert_eq!(
                    actual, expected,
                    "{input_encoding} -> {output_encoding}, dedup={deduplicate}"
                );
                assert_eq!(summary["inputs"], 3);
                assert_eq!(summary["records_read"], 15);
                assert_eq!(summary["records_written"], expected.len());
                assert_eq!(
                    summary["duplicates_removed"],
                    if deduplicate { 10 } else { 0 }
                );
            }
        }
    }
}

#[test]
fn variant_overlap_queries_keep_global_coordinate_order() {
    let directory = tempfile::tempdir().unwrap();
    let mut mismatches = Vec::new();
    for encoding in ["z", "b"] {
        let inputs = variant_overlap_inputs(
            directory.path(),
            "chr1\t20\tshort\tA\tC\t.\tPASS\t.",
            encoding,
        );
        let output = success(
            command()
                .args([
                    "concat",
                    "-a",
                    "--regions-overlap",
                    "variant",
                    "-r",
                    "chr1:20,chr1:100",
                ])
                .args(&inputs)
                .output()
                .unwrap(),
        );
        let ids: Vec<_> = record_lines(&output.stdout)
            .into_iter()
            .map(|line| line.split(|byte| *byte == b'\t').nth(2).unwrap())
            .collect();
        if ids != [b"long".as_slice(), b"short".as_slice()] {
            let names: Vec<_> = ids.iter().map(|id| String::from_utf8_lossy(id)).collect();
            mismatches.push(format!("{encoding}: {names:?}"));
        }
    }
    assert!(mismatches.is_empty(), "{mismatches:#?}");
}

#[test]
fn variant_overlap_queries_keep_ties_in_one_duplicate_group() {
    let directory = tempfile::tempdir().unwrap();
    let mut mismatches = Vec::new();
    let second = format!(
        "chr1\t10\tearly\t{}\t{}C\t.\tPASS\t.",
        "A".repeat(11),
        "A".repeat(10)
    );
    for encoding in ["z", "b"] {
        let inputs = variant_overlap_inputs(directory.path(), &second, encoding);
        for deduplicate in [false, true] {
            let mut concat = command();
            concat.args([
                "concat",
                "-a",
                "--regions-overlap",
                "variant",
                "-r",
                "chr1:20,chr1:100",
            ]);
            if deduplicate {
                concat.args(["-d", "all"]);
            }
            let output = success(concat.args(&inputs).output().unwrap());
            let ids: Vec<_> = record_lines(&output.stdout)
                .into_iter()
                .map(|line| line.split(|byte| *byte == b'\t').nth(2).unwrap())
                .collect();
            let expected: &[&[u8]] = if deduplicate {
                &[b"long"]
            } else {
                &[b"long", b"early"]
            };
            if ids != expected {
                let names: Vec<_> = ids.iter().map(|id| String::from_utf8_lossy(id)).collect();
                mismatches.push(format!("{encoding}, dedup={deduplicate}: {names:?}"));
            }
        }
    }
    assert!(mismatches.is_empty(), "{mismatches:#?}");
}

#[test]
fn indexed_overlap_modes_count_candidates_once_in_one_input() {
    let directory = tempfile::tempdir().unwrap();
    let body = format!(
        "chr1\t10\tlong\t{}\t{}C\t.\tPASS\t.\n\
chr1\t20\tshort\tA\tC\t.\tPASS\t.",
        "A".repeat(91),
        "A".repeat(90)
    );
    for encoding in ["z", "b"] {
        let inputs = variant_overlap_inputs(directory.path(), &body, encoding);
        for mode in ["pos", "record", "variant"] {
            let destination = directory.path().join("selected.vcf");
            let output = success(
                command()
                    .args([
                        "--json",
                        "concat",
                        "-a",
                        "--regions-overlap",
                        mode,
                        "-r",
                        "chr1:20,chr1:100",
                        "-o",
                    ])
                    .arg(&destination)
                    .arg(&inputs[1])
                    .output()
                    .unwrap(),
            );
            let json: serde_json::Value = serde_json::from_slice(&output.stdout).unwrap();
            let bytes = fs::read(&destination).unwrap();
            let ids: Vec<_> = record_lines(&bytes)
                .into_iter()
                .map(|line| line.split(|byte| *byte == b'\t').nth(2).unwrap())
                .collect();
            let expected: &[&[u8]] = if mode == "pos" {
                &[b"short"]
            } else {
                &[b"long", b"short"]
            };
            assert_eq!(ids, expected, "{encoding}, {mode}");
            assert_eq!(json["result"]["summary"]["records_read"], 2);
            assert_eq!(json["result"]["summary"]["records_written"], expected.len());
        }
    }
}

#[test]
fn indexed_queries_resolve_each_inputs_original_contig_dictionary() {
    let directory = tempfile::tempdir().unwrap();
    for encoding in ["z", "b"] {
        let mut inputs = Vec::new();
        for (input, contigs) in [["chr1", "chr2"], ["chr2", "chr1"]].into_iter().enumerate() {
            let source = directory.path().join(format!("dictionary-{input}.vcf"));
            let indexed = directory
                .path()
                .join(format!("dictionary-{input}.{encoding}"));
            let header = format!(
                "##fileformat=VCFv4.3\n\
##contig=<ID={},length=100,IDX=2>\n\
##contig=<ID={},length=100,IDX=5>\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\n",
                contigs[0], contigs[1]
            );
            let body =
                contigs.map(|contig| format!("{contig}\t10\t{input}-{contig}\tA\tC\t.\tPASS\t.\n"));
            fs::write(&source, format!("{header}{}", body.concat())).unwrap();
            convert(&source, &indexed, encoding);
            if encoding == "b" {
                let mut reader = noodles_bcf::io::Reader::new(fs::File::open(&indexed).unwrap());
                let header = reader.read_header().unwrap();
                assert_eq!(
                    header.string_maps().contigs().get_index(2),
                    Some(contigs[0])
                );
                assert_eq!(
                    header.string_maps().contigs().get_index(5),
                    Some(contigs[1])
                );
                let mut indexer = noodles_csi::binning_index::Indexer::<
                    noodles_csi::binning_index::index::reference_sequence::index::BinnedIndex,
                >::new(14, 5);
                let position = noodles_core::Position::try_from(10).unwrap();
                let mut record = noodles_bcf::Record::default();
                for reference in [2, 5] {
                    let start = reader.get_ref().virtual_position();
                    assert!(reader.read_record(&mut record).unwrap() > 0);
                    assert_eq!(record.reference_sequence_id().unwrap(), reference);
                    let end = reader.get_ref().virtual_position();
                    let chunk =
                        noodles_csi::binning_index::index::reference_sequence::bin::Chunk::new(
                            start, end,
                        );
                    indexer
                        .add_record(Some((reference, position, position, true)), chunk)
                        .unwrap();
                }
                assert_eq!(reader.read_record(&mut record).unwrap(), 0);
                noodles_csi::fs::write(indexed.with_extension("b.csi"), &indexer.build(6)).unwrap();
            } else {
                success(command().arg("index").arg(&indexed).output().unwrap());
            }
            inputs.push(indexed);
        }
        let output = success(
            command()
                .args(["concat", "-a", "-r", "chr2:10,chr1:10"])
                .args(&inputs)
                .output()
                .unwrap(),
        );
        let ids: Vec<_> = record_lines(&output.stdout)
            .into_iter()
            .map(|line| line.split(|byte| *byte == b'\t').nth(2).unwrap())
            .collect();
        assert_eq!(
            ids,
            [
                b"0-chr1".as_slice(),
                b"1-chr1".as_slice(),
                b"0-chr2".as_slice(),
                b"1-chr2".as_slice(),
            ],
            "{encoding}"
        );
    }
}

fn variant_overlap_inputs(directory: &Path, second: &str, encoding: &str) -> [PathBuf; 2] {
    let header = "##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=200>\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\n";
    let first = format!(
        "chr1\t10\tlong\t{}\t{}C\t.\tPASS\t.",
        "A".repeat(91),
        "A".repeat(90)
    );
    std::array::from_fn(|input| {
        let source = directory.join(format!("variant-{input}.vcf"));
        let indexed = directory.join(format!("variant-{input}.{encoding}"));
        fs::write(
            &source,
            format!("{header}{}\n", if input == 0 { &first } else { second }),
        )
        .unwrap();
        convert(&source, &indexed, encoding);
        success(command().arg("index").arg(&indexed).output().unwrap());
        indexed
    })
}

#[test]
fn ligation_reconciles_phase_and_emits_pq_ps() {
    let fixture = Fixture::new();
    let first = fixture._directory.path().join("ligate-first.vcf.gz");
    let second = fixture._directory.path().join("ligate-second.vcf.gz");
    index_vcf(&fixture.ligate_first, &first);
    index_vcf(&fixture.ligate_second, &second);
    let output = success(
        command()
            .args(["concat", "--ligate", path(&first), path(&second)])
            .output()
            .unwrap(),
    );
    let text = String::from_utf8(output.stdout).unwrap();
    assert!(
        text.contains("##FORMAT=<ID=PQ,Number=1,Type=Integer"),
        "{text}"
    );
    assert!(
        text.contains("##FORMAT=<ID=PS,Number=1,Type=Integer"),
        "{text}"
    );
    assert!(
        text.contains("chr1\t30\tl3\tC\tG\t.\tPASS\t.\tGT:PQ:PS\t1|0:99:10\t0|1:99:10"),
        "{text}"
    );
    assert!(
        text.contains("chr1\t40\tl4\tT\tA\t.\tPASS\t.\tGT:PS\t0|1:10\t0|1:10"),
        "{text}"
    );

    let compact = success(
        command()
            .args([
                "concat",
                "--ligate",
                "--compact-PS",
                path(&first),
                path(&second),
            ])
            .output()
            .unwrap(),
    );
    let compact = String::from_utf8(compact.stdout).unwrap();
    assert!(
        compact.contains("chr1\t10\tl1\tA\tC\t.\tPASS\t.\tGT:PS"),
        "{compact}"
    );
    assert!(
        compact.contains("chr1\t30\tl3\tC\tG\t.\tPASS\t.\tGT:PQ"),
        "{compact}"
    );
    assert!(
        compact.contains("chr1\t40\tl4\tT\tA\t.\tPASS\t.\tGT\t"),
        "{compact}"
    );
}

#[test]
fn ligation_rejects_incompatible_phase_format_definitions_atomically() {
    let fixture = Fixture::new();
    let first_source = fixture._directory.path().join("invalid-pq.vcf");
    let output_path = fixture._directory.path().join("phase-output.vcf");
    fs::write(
        &first_source,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
##FORMAT=<ID=PQ,Number=1,Type=Float,Description=\"Wrong type\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\tS2\n\
chr1\t10\tl1\tA\tC\t.\tPASS\t.\tGT:PQ\t0|1:.\t0|0:.\n\
chr1\t20\tl2\tG\tT\t.\tPASS\t.\tGT:PQ\t0|1:.\t1|0:.\n",
    )
    .unwrap();
    fs::write(&output_path, b"existing").unwrap();
    let output = command()
        .args([
            "concat",
            "--ligate",
            "--output",
            path(&output_path),
            path(&first_source),
            path(&fixture.ligate_second),
        ])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert_eq!(fs::read(&output_path).unwrap(), b"existing");
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("parsing VCF header"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn ligate_force_keeps_disjoint_chunks_in_order() {
    let fixture = Fixture::new();
    let left_source = fixture._directory.path().join("disjoint-left.vcf");
    let right_source = fixture._directory.path().join("disjoint-right.vcf");
    let left = fixture._directory.path().join("disjoint-left.vcf.gz");
    let right = fixture._directory.path().join("disjoint-right.vcf.gz");
    let header = "##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n";
    fs::write(
        &left_source,
        format!(
            "{header}chr1\t10\tleft-a\tA\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t20\tleft-b\tG\tT\t.\tPASS\t.\tGT\t1|0\n"
        ),
    )
    .unwrap();
    fs::write(
        &right_source,
        format!(
            "{header}chr1\t30\tright-a\tC\tG\t.\tPASS\t.\tGT\t0|1\n\
chr1\t40\tright-b\tT\tA\t.\tPASS\t.\tGT\t1|0\n"
        ),
    )
    .unwrap();
    index_vcf(&left_source, &left);
    index_vcf(&right_source, &right);

    let rejected = command()
        .args(["concat", "--ligate", path(&left), path(&right)])
        .output()
        .unwrap();
    assert!(!rejected.status.success());

    let forced = success(
        command()
            .args([
                "concat",
                "--ligate",
                "--ligate-force",
                path(&left),
                path(&right),
            ])
            .output()
            .unwrap(),
    );
    let ids: Vec<_> = record_lines(&forced.stdout)
        .into_iter()
        .map(|record| record.split(|byte| *byte == b'\t').nth(2).unwrap())
        .collect();
    assert_eq!(
        ids,
        [
            b"left-a".as_slice(),
            b"left-b".as_slice(),
            b"right-a".as_slice(),
            b"right-b".as_slice(),
        ]
    );
}

#[test]
fn imperfect_ligation_has_distinct_error_warn_and_force_policies() {
    let fixture = Fixture::new();
    let first = fixture._directory.path().join("imperfect-first.vcf.gz");
    let second_source = fixture._directory.path().join("imperfect-second.vcf");
    let second = fixture._directory.path().join("imperfect-second.vcf.gz");
    index_vcf(&fixture.ligate_first, &first);
    fs::write(
        &second_source,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\tS2\n\
chr1\t20\tl2\tG\tT\t.\tPASS\t.\tGT\t1|0\t1|0\n\
chr1\t25\textra\tA\tG\t.\tPASS\t.\tGT\t1|0\t0|1\n\
chr1\t30\tl3\tC\tG\t.\tPASS\t.\tGT\t0|1\t0|1\n\
chr1\t40\tl4\tT\tA\t.\tPASS\t.\tGT\t1|0\t0|1\n",
    )
    .unwrap();
    index_vcf(&second_source, &second);

    let rejected = command()
        .args(["concat", "--ligate", path(&first), path(&second)])
        .output()
        .unwrap();
    assert!(!rejected.status.success());
    assert!(
        String::from_utf8_lossy(&rejected.stderr).contains("perfect overlap"),
        "{}",
        String::from_utf8_lossy(&rejected.stderr)
    );

    let warned = success(
        command()
            .args([
                "concat",
                "--ligate",
                "--ligate-warn",
                path(&first),
                path(&second),
            ])
            .output()
            .unwrap(),
    );
    assert!(!String::from_utf8_lossy(&warned.stdout).contains("\textra\t"));
    assert!(
        String::from_utf8_lossy(&warned.stderr)
            .contains("warning: dropped 1 unpaired overlap record during ligation")
    );

    let warned_path = fixture._directory.path().join("warned.vcf");
    let warned_json = success(
        command()
            .args([
                "--json",
                "concat",
                "--ligate",
                "--ligate-warn",
                "--output",
                path(&warned_path),
                path(&first),
                path(&second),
            ])
            .output()
            .unwrap(),
    );
    assert!(warned_json.stderr.is_empty());
    let envelope: serde_json::Value = serde_json::from_slice(&warned_json.stdout).unwrap();
    assert_eq!(envelope["result"]["summary"]["overlap_records_dropped"], 1);

    let forced = success(
        command()
            .args([
                "concat",
                "--ligate",
                "--ligate-force",
                path(&first),
                path(&second),
            ])
            .output()
            .unwrap(),
    );
    assert!(String::from_utf8_lossy(&forced.stdout).contains("\textra\t"));
}

#[test]
fn ligation_matches_same_coordinate_variants_by_alleles() {
    let fixture = Fixture::new();
    let left_source = fixture._directory.path().join("ligate-multi-left.vcf");
    let right_source = fixture._directory.path().join("ligate-multi-right.vcf");
    let left = fixture._directory.path().join("ligate-multi-left.vcf.gz");
    let right = fixture._directory.path().join("ligate-multi-right.vcf.gz");
    fs::write(
        &left_source,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t10\tleft-start\tT\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t20\tleft-c\tA\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t20\tleft-g\tA\tG\t.\tPASS\t.\tGT\t1|0\n\
chr1\t30\tleft-end\tG\tT\t.\tPASS\t.\tGT\t0|1\n",
    )
    .unwrap();
    fs::write(
        &right_source,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t20\tright-g\tA\tG\t.\tPASS\t.\tGT\t1|0\n\
chr1\t20\tright-c\tA\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t30\tright-end\tG\tT\t.\tPASS\t.\tGT\t0|1\n\
chr1\t40\tright-tail\tC\tA\t.\tPASS\t.\tGT\t0|1\n",
    )
    .unwrap();
    index_vcf(&left_source, &left);
    index_vcf(&right_source, &right);

    let output = success(
        command()
            .args(["concat", "--ligate", path(&left), path(&right)])
            .output()
            .unwrap(),
    );
    let ids: Vec<_> = record_lines(&output.stdout)
        .iter()
        .map(|line| line.split(|byte| *byte == b'\t').nth(2).unwrap())
        .collect();
    assert_eq!(
        ids,
        [
            b"left-start".as_slice(),
            b"left-c".as_slice(),
            b"left-g".as_slice(),
            b"right-end".as_slice(),
            b"right-tail".as_slice(),
        ]
    );
}

#[test]
fn ligation_rejects_corrupt_indexes_and_regressing_chunk_starts() {
    let fixture = Fixture::new();
    let first = fixture._directory.path().join("ligate-index-first.vcf.gz");
    let second = fixture._directory.path().join("ligate-index-second.vcf.gz");
    let output_path = fixture._directory.path().join("ligate-output.vcf");
    index_vcf(&fixture.ligate_first, &first);
    index_vcf(&fixture.ligate_second, &second);
    fs::write(format!("{}.csi", second.display()), b"not an index").unwrap();
    fs::write(&output_path, b"existing").unwrap();
    let corrupt = command()
        .args([
            "concat",
            "--ligate",
            "--output",
            path(&output_path),
            path(&first),
            path(&second),
        ])
        .output()
        .unwrap();
    assert!(!corrupt.status.success());
    assert_eq!(fs::read(&output_path).unwrap(), b"existing");
    assert!(
        String::from_utf8_lossy(&corrupt.stderr).contains("valid CSI or TBI index"),
        "{}",
        String::from_utf8_lossy(&corrupt.stderr)
    );

    let late_source = fixture._directory.path().join("ligate-late.vcf");
    let early_source = fixture._directory.path().join("ligate-early.vcf");
    let late = fixture._directory.path().join("ligate-late.vcf.gz");
    let early = fixture._directory.path().join("ligate-early.vcf.gz");
    let header = "##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n";
    fs::write(
        &late_source,
        format!(
            "{header}chr1\t20\tshared\tA\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t30\ttail\tG\tT\t.\tPASS\t.\tGT\t0|1\n"
        ),
    )
    .unwrap();
    fs::write(
        &early_source,
        format!(
            "{header}chr1\t10\tearly\tC\tG\t.\tPASS\t.\tGT\t0|1\n\
chr1\t20\tshared\tA\tC\t.\tPASS\t.\tGT\t0|1\n"
        ),
    )
    .unwrap();
    index_vcf(&late_source, &late);
    index_vcf(&early_source, &early);
    let regressing = command()
        .args([
            "concat",
            "--ligate",
            "--ligate-force",
            path(&late),
            path(&early),
        ])
        .output()
        .unwrap();
    assert!(!regressing.status.success());
    assert!(
        String::from_utf8_lossy(&regressing.stderr).contains("chunk order regresses"),
        "{}",
        String::from_utf8_lossy(&regressing.stderr)
    );
}

#[test]
fn ligation_ties_preserve_orientation_and_min_pq_controls_phase_sets() {
    let fixture = Fixture::new();
    let left_source = fixture._directory.path().join("ligate-tie-left.vcf");
    let right_source = fixture._directory.path().join("ligate-tie-right.vcf");
    let left = fixture._directory.path().join("ligate-tie-left.vcf.gz");
    let right = fixture._directory.path().join("ligate-tie-right.vcf.gz");
    let header = "##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n";
    fs::write(
        &left_source,
        format!(
            "{header}chr1\t10\tl1\tT\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t20\tl2\tA\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t30\tl3\tG\tT\t.\tPASS\t.\tGT\t0|1\n"
        ),
    )
    .unwrap();
    fs::write(
        &right_source,
        format!(
            "{header}chr1\t20\tr2\tA\tC\t.\tPASS\t.\tGT\t0|1\n\
chr1\t30\tr3\tG\tT\t.\tPASS\t.\tGT\t1|0\n\
chr1\t40\tr4\tC\tA\t.\tPASS\t.\tGT\t0|1\n"
        ),
    )
    .unwrap();
    index_vcf(&left_source, &left);
    index_vcf(&right_source, &right);

    let default = success(
        command()
            .args(["concat", "--ligate", path(&left), path(&right)])
            .output()
            .unwrap(),
    );
    let default = String::from_utf8(default.stdout).unwrap();
    assert!(default.contains("chr1\t30\tr3\tG\tT\t.\tPASS\t.\tGT:PQ:PS\t1|0:0:30"));
    assert!(default.contains("chr1\t40\tr4\tC\tA\t.\tPASS\t.\tGT:PS\t0|1:30"));

    for threshold in ["0", "4294967295"] {
        let output = success(
            command()
                .args([
                    "concat",
                    "--ligate",
                    "--min-PQ",
                    threshold,
                    path(&left),
                    path(&right),
                ])
                .output()
                .unwrap(),
        );
        let output = String::from_utf8(output.stdout).unwrap();
        let expected = if threshold == "0" { ":0:10" } else { ":0:30" };
        assert!(output.contains(expected), "threshold={threshold}: {output}");
    }
}

#[test]
fn naive_mode_splices_compatible_bgzf_vcf_and_bcf() {
    let fixture = Fixture::new();
    let compatible = fixture._directory.path().join("naive-compatible.vcf");
    fs::write(
        &compatible,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Depth\">\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t20\tb\tG\tT\t.\tPASS\tDP=8\tGT\t1/1\n",
    )
    .unwrap();
    for (encoding, suffix) in [("z", "vcf.gz"), ("b", "bcf")] {
        let first = fixture
            ._directory
            .path()
            .join(format!("naive-first.{suffix}"));
        let second = fixture
            ._directory
            .path()
            .join(format!("naive-second.{suffix}"));
        let output_path = fixture
            ._directory
            .path()
            .join(format!("naive-output.{suffix}"));
        convert(&fixture.first, &first, encoding);
        convert(&compatible, &second, encoding);
        let output = success(
            command()
                .args(["concat", "--naive", path(&first), path(&second)])
                .output()
                .unwrap(),
        );
        assert!(output.stdout.ends_with(&BGZF_EOF));
        assert_eq!(
            output
                .stdout
                .windows(BGZF_EOF.len())
                .filter(|window| *window == BGZF_EOF)
                .count(),
            1
        );
        fs::write(&output_path, &output.stdout).unwrap();
        let decoded = success(
            command()
                .args(["view", "-O", "v", path(&output_path)])
                .output()
                .unwrap(),
        );
        assert_eq!(record_lines(&decoded.stdout).len(), 2, "{suffix}");
    }
}

#[test]
fn naive_corrupt_frame_fails_before_replacing_output() {
    let fixture = Fixture::new();
    let first = fixture._directory.path().join("naive-first.vcf.gz");
    let output_path = fixture._directory.path().join("naive-output.vcf.gz");
    convert(&fixture.first, &first, "z");
    let valid = fs::read(&first).unwrap();
    let mut corruptions = Vec::new();
    let mut crc = valid.clone();
    let frame_len = usize::from(u16::from_le_bytes([crc[16], crc[17]])) + 1;
    crc[frame_len - 8] ^= 0xff;
    corruptions.push(("crc", crc));
    corruptions.push((
        "missing-eof",
        valid[..valid.len() - BGZF_EOF.len()].to_vec(),
    ));
    let mut repeated_eof = valid.clone();
    repeated_eof.extend_from_slice(&BGZF_EOF);
    corruptions.push(("repeated-eof", repeated_eof));
    let mut trailing = valid.clone();
    trailing.push(0);
    corruptions.push(("trailing", trailing));
    corruptions.push((
        "partial-frame",
        valid[..valid.len() - BGZF_EOF.len() - 1].to_vec(),
    ));
    let mut invalid_size = valid;
    invalid_size[16..18].copy_from_slice(&0u16.to_le_bytes());
    corruptions.push(("invalid-size", invalid_size));

    for (name, bytes) in corruptions {
        let corrupt = fixture
            ._directory
            .path()
            .join(format!("naive-corrupt-{name}.vcf.gz"));
        fs::write(&corrupt, bytes).unwrap();
        fs::write(&output_path, b"existing").unwrap();
        let output = command()
            .args([
                "concat",
                "--naive",
                "--output",
                path(&output_path),
                path(&first),
                path(&corrupt),
            ])
            .output()
            .unwrap();
        assert!(!output.status.success(), "{name}");
        assert_eq!(fs::read(&output_path).unwrap(), b"existing", "{name}");
        assert!(
            String::from_utf8_lossy(&output.stderr).contains("BGZF"),
            "{name}: {}",
            String::from_utf8_lossy(&output.stderr)
        );
    }
}

#[test]
fn naive_rejects_mixed_vcf_and_bcf_before_stdout() {
    let fixture = Fixture::new();
    let vcf = fixture._directory.path().join("naive.vcf.gz");
    let bcf = fixture._directory.path().join("naive.bcf");
    convert(&fixture.first, &vcf, "z");
    convert(&fixture.second, &bcf, "b");
    let output = command()
        .args(["concat", "--naive", path(&vcf), path(&bcf)])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert!(output.stdout.is_empty());
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("cannot mix BGZF VCF and BCF"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn naive_header_conflict_fails_before_replacing_output() {
    let fixture = Fixture::new();
    let conflict_source = fixture._directory.path().join("naive-conflict.vcf");
    let first = fixture._directory.path().join("naive-first.vcf.gz");
    let conflict = fixture._directory.path().join("naive-conflict.vcf.gz");
    let output_path = fixture._directory.path().join("naive-output.vcf.gz");
    fs::write(
        &conflict_source,
        b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=101>\n\
##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Depth\">\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n\
chr1\t20\tb\tG\tT\t.\tPASS\tDP=8\tGT\t1/1\n",
    )
    .unwrap();
    convert(&fixture.first, &first, "z");
    convert(&conflict_source, &conflict, "z");
    fs::write(&output_path, b"existing").unwrap();
    let output = command()
        .args([
            "concat",
            "--naive",
            "--output",
            path(&output_path),
            path(&first),
            path(&conflict),
        ])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert_eq!(fs::read(output_path).unwrap(), b"existing");
    assert!(
        String::from_utf8_lossy(&output.stderr).contains("header"),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

#[test]
fn zero_length_bcf_records_are_not_logical_eof_in_concat() {
    use std::io::{self, Read};

    use noodles_vcf::variant::io::Write as _;

    fn encode(source: &[u8], compressed: bool) -> Vec<u8> {
        if !compressed {
            return source.to_vec();
        }
        let mut writer = noodles_bgzf::io::Writer::new(Vec::new());
        writer.write_all(source).unwrap();
        let encoded = writer.finish().unwrap();
        assert!(encoded.ends_with(&BGZF_EOF));
        let mut decoded = Vec::new();
        flate2::read::MultiGzDecoder::new(encoded.as_slice())
            .read_to_end(&mut decoded)
            .unwrap();
        assert_eq!(decoded, source);
        encoded
    }

    fn decoded_records(source: &[u8]) -> io::Result<Vec<u8>> {
        let mut reader = noodles_util::variant::io::Reader::new(source)?;
        let header = reader.read_header()?;
        let mut writer = noodles_vcf::io::Writer::new(Vec::new());
        for record in reader.records(&header) {
            writer.write_variant_record(&header, record?.as_ref())?;
        }
        Ok(writer.into_inner())
    }

    let fixture = Fixture::new();
    let directory = fixture._directory.path();
    let first_path = directory.join("zero-length-first.u");
    convert(&fixture.first, &first_path, "u");
    let first = fs::read(&first_path).unwrap();
    let later_source = directory.join("zero-length-later.vcf");
    let later_path = directory.join("zero-length-later.u");
    let text = fs::read_to_string(&fixture.first)
        .unwrap()
        .replace("chr1\t10\ta\t", "chr1\t20\tb\t");
    fs::write(
        &later_source,
        format!("{text}chr1\t30\tc\tG\tT\t.\tPASS\tDP=8\tGT\t1/1\n"),
    )
    .unwrap();
    convert(&later_source, &later_path, "u");
    let later = fs::read(&later_path).unwrap();
    assert!(later.starts_with(b"BCF\x02\x02"));
    let mut reader = noodles_bcf::io::Reader::from(later.as_slice());
    let header = reader.read_header().unwrap();
    let header_end = later.len() - reader.get_ref().len();
    let mut record = noodles_bcf::Record::default();
    assert!(reader.read_record(&mut record).unwrap() > 0);
    assert_eq!(usize::from(record.variant_start().unwrap().unwrap()), 20);
    noodles_vcf::variant::RecordBuf::try_from_variant_record(&header, &record).unwrap();
    let first_record_end = later.len() - reader.get_ref().len();
    assert!(reader.read_record(&mut record).unwrap() > 0);
    assert_eq!(usize::from(record.variant_start().unwrap().unwrap()), 30);
    noodles_vcf::variant::RecordBuf::try_from_variant_record(&header, &record).unwrap();
    assert!(reader.get_ref().is_empty());
    assert_eq!(reader.read_record(&mut record).unwrap(), 0);
    let first_header = noodles_bcf::io::Reader::from(first.as_slice())
        .read_header()
        .unwrap();
    assert_eq!(first_header, header);
    assert_eq!(first_header.string_maps(), header.string_maps());

    let mut failures = Vec::new();
    let mut malformed_runs = 0;
    let mut control_runs = 0;
    for (mode, compressed, naive) in [
        ("ordered-raw", false, false),
        ("ordered-bgzf", true, false),
        ("naive-bgzf", true, true),
    ] {
        let first_path = directory.join(format!("zero-length-{mode}-first"));
        let second_path = directory.join(format!("zero-length-{mode}-second"));
        let output_path = directory.join(format!("zero-length-{mode}-output"));
        fs::write(&first_path, encode(&first, compressed)).unwrap();
        for after_record in [false, true] {
            for remaining_record in [false, true] {
                let mut malformed = later[..header_end].to_vec();
                if after_record {
                    malformed.extend_from_slice(&later[header_end..first_record_end]);
                }
                malformed.extend_from_slice(&0u32.to_le_bytes());
                if remaining_record {
                    malformed.extend_from_slice(&later[first_record_end..]);
                }
                fs::write(&second_path, encode(&malformed, compressed)).unwrap();
                for named in [false, true] {
                    let case = format!(
                        "{mode}, after_record={after_record}, remaining_record={remaining_record}, named={named}"
                    );
                    let mut child = command();
                    child.arg("concat");
                    if naive {
                        child.arg("--naive");
                    } else {
                        child.args(["-O", "v"]);
                    }
                    if named {
                        fs::write(&output_path, b"existing output").unwrap();
                        child.args(["--output", path(&output_path)]);
                    }
                    let output = child
                        .args([path(&first_path), path(&second_path)])
                        .output()
                        .unwrap();
                    malformed_runs += 1;
                    eprintln!(
                        "zero-length BCF: {case}: status={}, stdout_bytes={}, stderr={}",
                        output.status,
                        output.stdout.len(),
                        String::from_utf8_lossy(&output.stderr)
                    );
                    if output.status.success() {
                        failures.push(format!("{case}: malformed BCF was accepted"));
                    }
                    if named && fs::read(&output_path).unwrap() != b"existing output" {
                        failures.push(format!("{case}: existing output was replaced"));
                    }
                    if naive && !output.stdout.is_empty() {
                        failures.push(format!("{case}: naive preflight emitted stdout"));
                    }
                }
            }
        }

        fs::write(&second_path, encode(&later[..header_end], compressed)).unwrap();
        for named in [false, true] {
            let case = format!("{mode}, header-only control, named={named}");
            let mut child = command();
            child.arg("concat");
            if naive {
                child.arg("--naive");
            } else {
                child.args(["-O", "v"]);
            }
            if named {
                fs::write(&output_path, b"existing output").unwrap();
                child.args(["--output", path(&output_path)]);
            }
            let output = child
                .args([path(&first_path), path(&second_path)])
                .output()
                .unwrap();
            control_runs += 1;
            eprintln!(
                "zero-length BCF: {case}: status={}, stderr={}",
                output.status,
                String::from_utf8_lossy(&output.stderr)
            );
            if !output.status.success() {
                failures.push(format!("{case}: valid header-only input was rejected"));
                continue;
            }
            let bytes = if named {
                fs::read(&output_path).unwrap()
            } else {
                output.stdout
            };
            match decoded_records(&bytes) {
                Ok(records) if records == b"chr1\t10\ta\tA\tC\t.\tPASS\tDP=4\tGT\t0/1\n" => {}
                other => failures.push(format!("{case}: unexpected records {other:?}")),
            }
        }
    }
    eprintln!(
        "zero-length BCF completed: {malformed_runs} malformed runs, {control_runs} controls"
    );
    assert!(failures.is_empty(), "{failures:#?}");
}

#[test]
fn naive_extra_subfields_preserve_split_headers_and_raw_body_frames() {
    use std::io::{self, Read};

    use noodles_vcf::variant::io::Write as _;

    const HEADER: &[u8] = b"##fileformat=VCFv4.3\n\
##contig=<ID=chr1,length=100>\n\
##INFO=<ID=DP,Number=1,Type=Integer,Description=\"Depth\">\n\
##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n\
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tS1\n";
    const BODIES: [&[u8]; 2] = [
        b"chr1\t10\ta\tA\tC\t.\tPASS\tDP=4\tGT\t0/1\n\
chr1\t20\tb\tG\tT\t.\tPASS\tDP=8\tGT\t1/1\n",
        b"chr1\t30\tc\tC\tG\t.\tPASS\tDP=3\tGT\t1/0\n\
chr1\t40\td\tT\tA\t.\tPASS\tDP=9\tGT\t0/0\n",
    ];

    fn to_bcf(text: &[u8]) -> Vec<u8> {
        let mut reader = noodles_vcf::io::Reader::new(text);
        let header = reader.read_header().unwrap();
        let mut writer = noodles_bcf::io::Writer::from(Vec::new());
        writer.write_header(&header).unwrap();
        for record in reader.records() {
            writer
                .write_variant_record(&header, &record.unwrap())
                .unwrap();
        }
        writer.into_inner()
    }

    fn typed_body(raw: &[u8]) -> io::Result<(noodles_vcf::Header, Vec<u8>)> {
        let mut reader = noodles_util::variant::io::Reader::new(raw)?;
        let header = reader.read_header()?;
        let mut writer = noodles_vcf::io::Writer::new(Vec::new());
        for record in reader.records(&header) {
            writer.write_variant_record(&header, record?.as_ref())?;
        }
        Ok((header, writer.into_inner()))
    }

    fn inflate(source: &[u8]) -> io::Result<Vec<u8>> {
        let mut decoded = Vec::new();
        flate2::read::MultiGzDecoder::new(source).read_to_end(&mut decoded)?;
        Ok(decoded)
    }

    fn frame(payload: &[u8]) -> Vec<u8> {
        let mut writer = noodles_bgzf::io::Writer::new(Vec::new());
        writer.write_all(payload).unwrap();
        let encoded = writer.finish().unwrap();
        assert!(encoded.ends_with(&BGZF_EOF));
        let data = encoded[..encoded.len() - BGZF_EOF.len()].to_vec();
        assert_eq!(
            data.len(),
            usize::from(u16::from_le_bytes([data[16], data[17]])) + 1
        );
        assert_eq!(&data[10..18], &[6, 0, b'B', b'C', 2, 0, data[16], data[17]]);
        data
    }

    fn extend_extra(original: &[u8], before: &[u8], after: &[u8]) -> Vec<u8> {
        let mut extended = original[..12].to_vec();
        extended.extend_from_slice(before);
        extended.extend_from_slice(&original[12..18]);
        extended.extend_from_slice(after);
        extended.extend_from_slice(&original[18..]);
        let extra_len = u16::try_from(6 + before.len() + after.len()).unwrap();
        extended[10..12].copy_from_slice(&extra_len.to_le_bytes());
        let size = u16::try_from(extended.len() - 1).unwrap();
        let size_offset = 16 + before.len();
        extended[size_offset..size_offset + 2].copy_from_slice(&size.to_le_bytes());
        extended
    }

    fn check_frame(frame: &[u8], payload: &[u8]) {
        assert_eq!(&frame[..4], &[0x1f, 0x8b, 8, 4]);
        let extra_end = 12 + usize::from(u16::from_le_bytes([frame[10], frame[11]]));
        let mut offset = 12;
        let mut bc_count = 0;
        while offset < extra_end {
            let length = usize::from(u16::from_le_bytes([frame[offset + 2], frame[offset + 3]]));
            let end = offset + 4 + length;
            assert!(end <= extra_end);
            if &frame[offset..offset + 2] == b"BC" {
                assert_eq!(length, 2);
                assert_eq!(
                    usize::from(u16::from_le_bytes([frame[offset + 4], frame[offset + 5]])) + 1,
                    frame.len()
                );
                bc_count += 1;
            }
            offset = end;
        }
        assert_eq!(offset, extra_end);
        assert_eq!(bc_count, 1);
        let mut decoder = flate2::bufread::GzDecoder::new(frame);
        let mut decoded = Vec::new();
        decoder.read_to_end(&mut decoded).unwrap();
        assert_eq!(decoded, payload);
        assert!(decoder.into_inner().is_empty());
    }

    let directory = tempfile::tempdir().unwrap();
    let mut large_extra = b"LX".to_vec();
    large_extra.extend_from_slice(&9000u16.to_le_bytes());
    large_extra.extend(std::iter::repeat_n(0x5a, 9000));
    let before = b"XY\x01\x00\x07".as_slice();
    let after = b"UV\x02\x00\x08\x09".as_slice();
    let cases = [
        ("canonical", 0, 0, &[][..], &[][..]),
        ("before-first", 0, 0, before, &[][..]),
        ("after-first", 0, 0, &[][..], after),
        ("before-second-boundary", 1, 2, before, &[][..]),
        ("after-second-boundary", 1, 2, &[][..], after),
        ("before-second-tail", 1, 3, before, &[][..]),
        ("after-second-tail", 1, 3, &[][..], after),
        ("large-before-first", 0, 0, large_extra.as_slice(), &[][..]),
        ("large-before-second", 1, 0, large_extra.as_slice(), &[][..]),
    ];
    let expected_body = BODIES.concat();
    let mut failures = Vec::new();
    let mut extra_runs = 0;
    let mut control_runs = 0;
    check_frame(&BGZF_EOF, &[]);
    for encoding in ["vcf", "bcf"] {
        let raw = BODIES.map(|body| {
            let text = [HEADER, body].concat();
            if encoding == "bcf" {
                to_bcf(&text)
            } else {
                text
            }
        });
        let header_ends = raw.each_ref().map(|source| {
            if encoding == "bcf" {
                assert!(source.starts_with(b"BCF\x02\x02"));
                let end = 9 + usize::try_from(u32::from_le_bytes(source[5..9].try_into().unwrap()))
                    .unwrap();
                let mut reader = noodles_bcf::io::Reader::from(source.as_slice());
                reader.read_header().unwrap();
                assert_eq!(source.len() - reader.get_ref().len(), end);
                end
            } else {
                assert!(source.starts_with(HEADER));
                HEADER.len()
            }
        });
        let (first_header, first_body) = typed_body(&raw[0]).unwrap();
        let (second_header, second_body) = typed_body(&raw[1]).unwrap();
        assert_eq!(first_header, second_header);
        assert_eq!(first_header.string_maps(), second_header.string_maps());
        assert_eq!(first_body, BODIES[0]);
        assert_eq!(second_body, BODIES[1]);
        let payloads = [0, 1].map(|input| {
            let source = raw[input].as_slice();
            let boundary_end = header_ends[input] + 5;
            assert!(boundary_end < source.len());
            [
                &source[..1],
                &source[1..3],
                &source[3..boundary_end],
                &source[boundary_end..],
            ]
        });
        let canonical = payloads.map(|chunks| chunks.map(frame));
        let expected_raw = [raw[0].as_slice(), &raw[1][header_ends[1]..]].concat();
        eprintln!(
            "naive extras fixture: {encoding}, header_ends={header_ends:?}, payload_lengths={:?}",
            payloads.map(|chunks| chunks.map(<[u8]>::len))
        );
        for (name, input, frame_index, before, after) in cases {
            let mut frames = canonical.clone();
            frames[input][frame_index] = extend_extra(&frames[input][frame_index], before, after);
            if name.starts_with("large-") {
                let extended = &frames[input][frame_index];
                assert!(usize::from(u16::from_le_bytes([extended[10], extended[11]])) > 8192);
                assert!(extended.len() <= 65536);
            }
            let sources = [0, 1].map(|input| {
                for (member, payload) in frames[input].iter().zip(payloads[input]) {
                    check_frame(member, payload);
                }
                let mut source = frames[input].concat();
                source.extend_from_slice(&BGZF_EOF);
                assert_eq!(inflate(&source).unwrap(), raw[input]);
                source
            });
            let first_path = directory
                .path()
                .join(format!("extra-{encoding}-{name}-first"));
            let second_path = directory
                .path()
                .join(format!("extra-{encoding}-{name}-second"));
            let output_path = directory
                .path()
                .join(format!("extra-{encoding}-{name}-output"));
            fs::write(&first_path, &sources[0]).unwrap();
            fs::write(&second_path, &sources[1]).unwrap();
            let first_prefix = frames[0].concat();
            let expected_tail = [frames[1][3].as_slice(), &BGZF_EOF].concat();
            for named in [false, true] {
                let case = format!("{encoding}, {name}, named={named}");
                let mut child = command();
                child.args(["concat", "--naive"]);
                if named {
                    fs::write(&output_path, b"existing output").unwrap();
                    child.args(["--output", path(&output_path)]);
                }
                let output = child
                    .args([path(&first_path), path(&second_path)])
                    .output()
                    .unwrap();
                if name == "canonical" {
                    control_runs += 1;
                } else {
                    extra_runs += 1;
                }
                eprintln!(
                    "naive extras: {case}: status={}, stdout_bytes={}, stderr={}",
                    output.status,
                    output.stdout.len(),
                    String::from_utf8_lossy(&output.stderr)
                );
                if !output.status.success() {
                    failures.push(format!("{case}: valid BGZF was rejected"));
                    if named && fs::read(&output_path).unwrap() != b"existing output" {
                        failures.push(format!("{case}: failed preflight replaced existing output"));
                    }
                    if !output.stdout.is_empty() {
                        failures.push(format!("{case}: failed preflight emitted stdout"));
                    }
                    continue;
                }
                let bytes = if named {
                    fs::read(&output_path).unwrap()
                } else {
                    output.stdout
                };
                if !bytes.starts_with(&first_prefix) {
                    failures.push(format!(
                        "{case}: first input data frames were not copied exactly"
                    ));
                }
                if !bytes.ends_with(&expected_tail) {
                    failures.push(format!(
                        "{case}: second input post-boundary frame or EOF was changed"
                    ));
                }
                match inflate(&bytes) {
                    Ok(decoded) => {
                        if decoded != expected_raw {
                            failures.push(format!("{case}: decoded concatenation differs"));
                        }
                        match typed_body(&decoded) {
                            Ok((header, body))
                                if header == first_header
                                    && header.string_maps() == first_header.string_maps()
                                    && body == expected_body => {}
                            other => {
                                failures.push(format!("{case}: unexpected typed output {other:?}"))
                            }
                        }
                    }
                    Err(error) => failures.push(format!("{case}: invalid gzip output: {error}")),
                }
            }
        }
    }
    eprintln!(
        "naive extras completed: {extra_runs} legal extra-field runs, {control_runs} controls"
    );
    assert_eq!((extra_runs, control_runs), (32, 4));
    assert!(failures.is_empty(), "{failures:#?}");
}

#[test]
fn naive_accepts_long_empty_frame_prefixes_in_either_input() {
    use std::io::Read;

    use noodles_vcf::variant::io::Write as _;

    let fixture = Fixture::new();
    let directory = fixture._directory.path();
    let source = directory.join("prefix-second.vcf");
    fs::write(
        &source,
        fs::read_to_string(&fixture.first)
            .unwrap()
            .replace("chr1\t10\ta\t", "chr1\t20\tb\t"),
    )
    .unwrap();
    let mut empty = BGZF_EOF;
    empty[4] = 1;
    let prefix = empty.repeat(400);
    assert!(prefix.len() > 8192);
    let mut failures = Vec::new();
    for encoding in ["z", "b"] {
        let first = directory.join(format!("prefix-first-{encoding}"));
        let second = directory.join(format!("prefix-second-{encoding}"));
        let output_path = directory.join(format!("prefix-output-{encoding}"));
        convert(&fixture.first, &first, encoding);
        convert(&source, &second, encoding);
        let originals = [fs::read(&first).unwrap(), fs::read(&second).unwrap()];
        for prefixed in [0, 1] {
            let inputs = [&first, &second];
            for input in 0..2 {
                let bytes = if input == prefixed {
                    [prefix.as_slice(), originals[input].as_slice()].concat()
                } else {
                    originals[input].clone()
                };
                fs::write(inputs[input], bytes).unwrap();
            }
            for named in [false, true] {
                let mut child = command();
                child.args(["concat", "--naive", path(&first), path(&second)]);
                if named {
                    child.args(["--output", path(&output_path)]);
                }
                let output = child.output().unwrap();
                let case = format!("{encoding}, prefixed={prefixed}, named={named}");
                if !output.status.success() {
                    failures.push(format!(
                        "{case}: {}",
                        String::from_utf8_lossy(&output.stderr)
                    ));
                    continue;
                }
                let bytes = if named {
                    fs::read(&output_path).unwrap()
                } else {
                    output.stdout
                };
                let mut decoded = Vec::new();
                flate2::read::MultiGzDecoder::new(bytes.as_slice())
                    .read_to_end(&mut decoded)
                    .unwrap();
                let mut reader =
                    noodles_util::variant::io::Reader::new(decoded.as_slice()).unwrap();
                let header = reader.read_header().unwrap();
                let mut writer = noodles_vcf::io::Writer::new(Vec::new());
                for record in reader.records(&header) {
                    writer
                        .write_variant_record(&header, record.unwrap().as_ref())
                        .unwrap();
                }
                assert_eq!(
                    writer.into_inner(),
                    b"chr1\t10\ta\tA\tC\t.\tPASS\tDP=4\tGT\t0/1\n\
chr1\t20\tb\tA\tC\t.\tPASS\tDP=4\tGT\t0/1\n",
                    "{case}"
                );
            }
        }
    }
    assert!(failures.is_empty(), "{failures:#?}");
}

#[test]
fn naive_rejects_late_second_input_failures_before_any_output() {
    fn frame(payload: &[u8]) -> Vec<u8> {
        let mut writer = noodles_bgzf::io::Writer::new(Vec::new());
        writer.write_all(payload).unwrap();
        let mut bytes = writer.finish().unwrap();
        bytes.truncate(bytes.len() - BGZF_EOF.len());
        bytes
    }

    let fixture = Fixture::new();
    let directory = fixture._directory.path();
    let first = directory.join("late-first.vcf.gz");
    let second = directory.join("late-second.vcf.gz");
    let output_path = directory.join("late-output.vcf.gz");
    convert(&fixture.first, &first, "z");
    let text = fs::read(&fixture.first).unwrap();
    let header: Vec<_> = text
        .split_inclusive(|byte| *byte == b'\n')
        .take_while(|line| line.starts_with(b"#"))
        .flatten()
        .copied()
        .collect();
    for case in ["crc", "isize", "typed"] {
        let body = if case == "typed" {
            b"chr1\t30\tc\tG\tT\tbad\tPASS\tDP=8\tGT\t1/1\n".as_slice()
        } else {
            b"chr1\t30\tc\tG\tT\t.\tPASS\tDP=8\tGT\t1/1\n".as_slice()
        };
        let mut late = frame(body);
        let length = late.len();
        if case == "crc" {
            late[length - 8] ^= 1;
        } else if case == "isize" {
            late[length - 4] ^= 1;
        }
        let bytes = [
            frame(&header),
            frame(b"chr1\t20\tb\tA\tC\t.\tPASS\tDP=4\tGT\t0/1\n"),
            late,
            BGZF_EOF.to_vec(),
        ]
        .concat();
        fs::write(&second, bytes).unwrap();
        for named in [false, true] {
            fs::write(&output_path, b"existing output").unwrap();
            let mut child = command();
            child.args(["concat", "--naive", path(&first), path(&second)]);
            if named {
                child.args(["--output", path(&output_path)]);
            }
            let output = child.output().unwrap();
            assert!(!output.status.success(), "{case}, named={named}");
            assert!(output.stdout.is_empty(), "{case}, named={named}");
            assert_eq!(
                fs::read(&output_path).unwrap(),
                b"existing output",
                "{case}"
            );
            assert!(!output.stderr.is_empty(), "{case}, named={named}");
        }
    }
}
