use crate::dataset::{Dataset, DosageField, ImportProfile, InputSpec, VariantId};
use crate::execution::Execution;
use crate::make::{self, MakeConfig, Selection};
use serde_json::{Value, json};
use std::{fs, path::PathBuf};

struct WorkflowAllocator;
thread_local! {
    static CALL_ALLOCATION_SIZE: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
    static CALL_ALLOCATIONS: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
}
#[global_allocator]
static WORKFLOW_ALLOCATOR: WorkflowAllocator = WorkflowAllocator;
unsafe impl std::alloc::GlobalAlloc for WorkflowAllocator {
    unsafe fn alloc(&self, layout: std::alloc::Layout) -> *mut u8 {
        if layout.align() == std::mem::align_of::<crate::dataset::genotypes::Call>() {
            CALL_ALLOCATION_SIZE.with(|size| {
                if size.get() != 0 && size.get() == layout.size() {
                    CALL_ALLOCATIONS.with(|count| count.set(count.get() + 1));
                }
            });
        }
        unsafe { std::alloc::System.alloc(layout) }
    }
    unsafe fn dealloc(&self, pointer: *mut u8, layout: std::alloc::Layout) {
        unsafe { std::alloc::System.dealloc(pointer, layout) }
    }
}

fn fixtures() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures")
}
fn raw(dataset: &Dataset) -> Vec<Value> {
    let mut reader = dataset.reader().unwrap();
    let rows = (0..dataset.metadata.variants.len())
        .map(|v| {
            let value = reader.read(VariantId(v)).unwrap();
            let calls = value
                .calls()
                .map(|call| {
                    let mut alleles = call
                        .alleles
                        .map(|[a, b]| [a as i32, b as i32])
                        .unwrap_or([-9, -9]);
                    if call.phase && call.reversed {
                        alleles.swap(0, 1);
                    }
                    json!([
                        alleles[0],
                        alleles[1],
                        u8::from(call.phase),
                        u8::from(call.reversed),
                        call.dosage,
                        call.dphase
                    ])
                })
                .collect::<Vec<_>>();
            json!({"variant":v,"provisional_ref":value.provisional_ref,"calls":calls})
        })
        .collect();
    reader.close().unwrap();
    rows
}
fn assert_raw(actual: &[Value], expected: &[Value], context: &str) {
    assert_eq!(actual.len(), expected.len(), "{context} variant count");
    for (variant, (actual, expected)) in actual.iter().zip(expected).enumerate() {
        assert_eq!(actual["variant"], expected["variant"], "{context} ordinal");
        assert_eq!(
            actual["provisional_ref"], expected["provisional_ref"],
            "{context} variant{variant} REF"
        );
        let a = actual["calls"].as_array().unwrap();
        let e = expected["calls"].as_array().unwrap();
        assert_eq!(a.len(), e.len(), "{context} sample count");
        for (sample, (actual, expected)) in a.iter().zip(e).enumerate() {
            assert_eq!(
                actual, expected,
                "{context} variant{variant} sample{sample}"
            );
        }
    }
}

#[test]
fn six_lane_make_preserves_accepted_raw_state_through_fresh_reopen_and_selection() {
    let inputs = fixtures().join("inputs");
    let directory = tempfile::Builder::new()
        .prefix("plink-native-six-")
        .tempdir_in(std::env::temp_dir())
        .unwrap();
    let execution = Execution::new(std::num::NonZeroUsize::new(2), 512).unwrap();
    for lane in ["gt", "bed", "pgen", "ds", "hds", "rich"] {
        let input = match lane {
            "bed" => InputSpec::Bed(inputs.join("baseline")),
            "pgen" => InputSpec::Pgen(directory.path().join("gt.I")),
            _ => InputSpec::Vcf(inputs.join(if lane == "gt" {
                "baseline.vcf".into()
            } else {
                format!("{lane}.vcf")
            })),
        };
        let profile = ImportProfile {
            psam: matches!(input, InputSpec::Vcf(_)).then(|| inputs.join("baseline.psam")),
            dosage: match lane {
                "ds" => DosageField::Ds,
                "hds" => DosageField::Hds,
                _ => DosageField::None,
            },
            split_par_b37: lane == "rich",
            ..ImportProfile::default()
        };
        let out = directory.path().join(format!("{lane}.I"));
        make::run(
            &MakeConfig {
                input,
                profile,
                selection: Selection::default(),
                filters: Default::default(),
                out: out.clone(),
            },
            &execution,
        )
        .unwrap_or_else(|e| panic!("{lane}: {e}"));
        let dataset =
            Dataset::open(InputSpec::Pgen(out.clone()), ImportProfile::default()).unwrap();
        let expected = fs::read_to_string(fixtures().join(format!("oracle/{lane}/raw.jsonl")))
            .unwrap()
            .lines()
            .skip(1)
            .map(|line| serde_json::from_str::<Value>(line).unwrap())
            .collect::<Vec<_>>();
        assert_raw(&raw(&dataset), &expected, &format!("{lane} native I"));
        let identity = directory.path().join(format!("{lane}.identity"));
        let all_samples = (0..dataset.metadata.samples.len()).collect::<Vec<_>>();
        let variants = (0..dataset.metadata.variants.len()).collect::<Vec<_>>();
        CALL_ALLOCATIONS.with(|count| count.set(0));
        CALL_ALLOCATION_SIZE.with(|size| {
            size.set(all_samples.len() * std::mem::size_of::<crate::dataset::genotypes::Call>());
        });
        let identity_result =
            make::materialize(&dataset, &all_samples, &variants, &identity, &execution);
        CALL_ALLOCATION_SIZE.with(|size| size.set(0));
        identity_result.unwrap();
        assert_eq!(
            CALL_ALLOCATIONS.with(|count| count.get()),
            0,
            "{lane}: identity make must retain packed tracks without allocating a Call projection"
        );
        let identity = Dataset::open(InputSpec::Pgen(identity), ImportProfile::default()).unwrap();
        assert_raw(
            &raw(&identity),
            &expected,
            &format!("{lane} packed identity"),
        );
        let filtered = directory.path().join(format!("{lane}.no-drop"));
        make::run(
            &MakeConfig {
                input: InputSpec::Pgen(out.clone()),
                profile: ImportProfile::default(),
                selection: Selection::default(),
                filters: make::filter::FilterThresholds {
                    mind: Some(1.0),
                    geno: Some(1.0),
                    maf: Some(0.0),
                    hwe_midp: None,
                },
                out: filtered.clone(),
            },
            &execution,
        )
        .unwrap();
        let filtered = Dataset::open(InputSpec::Pgen(filtered), ImportProfile::default()).unwrap();
        assert_raw(
            &raw(&filtered),
            &expected,
            &format!("{lane} no-drop filter"),
        );
        let selected = directory.path().join(format!("{lane}.selected"));
        let indices = (0..65).collect::<Vec<_>>();
        make::materialize(&dataset, &indices, &variants, &selected, &execution).unwrap();
        let reread = Dataset::open(InputSpec::Pgen(selected), ImportProfile::default()).unwrap();
        let mut selected_expected = expected;
        for row in &mut selected_expected {
            row["calls"].as_array_mut().unwrap().truncate(65);
        }
        assert_raw(
            &raw(&reread),
            &selected_expected,
            &format!("{lane} selected65"),
        );
        let selected_filtered = directory.path().join(format!("{lane}.selected-no-drop"));
        make::run(
            &MakeConfig {
                input: InputSpec::Pgen(out),
                profile: ImportProfile::default(),
                selection: Selection {
                    keep: Some(inputs.join("keep65.id")),
                    ..Selection::default()
                },
                filters: make::filter::FilterThresholds {
                    mind: Some(1.0),
                    geno: Some(1.0),
                    maf: Some(0.0),
                    hwe_midp: None,
                },
                out: selected_filtered.clone(),
            },
            &execution,
        )
        .unwrap();
        let selected_filtered =
            Dataset::open(InputSpec::Pgen(selected_filtered), ImportProfile::default()).unwrap();
        assert_raw(
            &raw(&selected_filtered),
            &selected_expected,
            &format!("{lane} subset no-drop filter"),
        );
        if lane == "gt" {
            for (case, keep, mind) in [
                ("identity-filter", None, 1.0),
                ("subset-filter", Some(inputs.join("keep65.id")), 1.0),
                ("mind-removal", None, 0.125),
            ] {
                let mut results = Vec::new();
                for hwe_midp in [None, Some(0.0)] {
                    let out = directory.path().join(format!("{case}-{}", results.len()));
                    make::run(
                        &MakeConfig {
                            input: dataset.source.clone(),
                            profile: ImportProfile::default(),
                            selection: Selection {
                                keep: keep.clone(),
                                autosome: true,
                                max_alleles: Some(2),
                                ..Selection::default()
                            },
                            filters: make::filter::FilterThresholds {
                                mind: Some(mind),
                                geno: Some(0.125),
                                maf: Some(0.05),
                                hwe_midp,
                            },
                            out: out.clone(),
                        },
                        &execution,
                    )
                    .unwrap();
                    let result =
                        Dataset::open(InputSpec::Pgen(out), ImportProfile::default()).unwrap();
                    results.push((
                        result
                            .metadata
                            .samples
                            .iter()
                            .map(|s| s.iid.clone())
                            .collect::<Vec<_>>(),
                        result
                            .metadata
                            .variants
                            .iter()
                            .map(|v| v.id.clone())
                            .collect::<Vec<_>>(),
                        raw(&result),
                    ));
                }
                assert_eq!(
                    results[0], results[1],
                    "{case}: packed counts must match general tally; zero HWE threshold rejects no variants"
                );
                if case == "mind-removal" {
                    assert!(results[0].0.len() < 72);
                }
                assert!(
                    results[0].1.len() < 64,
                    "{case}: thresholds must reject variants"
                );
            }
            let mut budget_dataset = Dataset::open(
                InputSpec::Bed(inputs.join("baseline")),
                ImportProfile::default(),
            )
            .unwrap();
            let bed = fs::read(inputs.join("baseline.bed")).unwrap();
            let mut repeated_bed = bed[..3].to_vec();
            for _ in 0..16 {
                repeated_bed.extend_from_slice(&bed[3..]);
            }
            assert_eq!(repeated_bed.len(), 18_435);
            let budget_source = directory.path().join("cached-budget");
            fs::write(crate::dataset::sibling(&budget_source, "bed"), repeated_bed).unwrap();
            budget_dataset.source = InputSpec::Bed(budget_source);
            let original_variants = std::mem::take(&mut budget_dataset.metadata.variants);
            budget_dataset.metadata.variants = (0..16)
                .flat_map(|repeat| {
                    original_variants.iter().map(move |variant| {
                        let mut variant = variant.clone();
                        variant.id = format!("{repeat}_{}", variant.id);
                        variant.fields[2] = variant.id.clone();
                        variant
                    })
                })
                .collect();
            budget_dataset.metadata.validate().unwrap();
            let sample_count = budget_dataset.metadata.samples.len();
            let variant_count = budget_dataset.metadata.variants.len();
            let persistent = (2 * sample_count + variant_count) * std::mem::size_of::<usize>()
                + sample_count * std::mem::size_of::<u64>()
                + sample_count.div_ceil(32) * 4 * std::mem::size_of::<u64>()
                + variant_count * std::mem::size_of::<Option<[u64; 4]>>()
                + 65536;
            let decision_bytes = crate::stats::metadata_bytes(&budget_dataset.metadata)
                + persistent
                + 2 * variant_count * std::mem::size_of::<usize>();
            let mut limited = Execution::new(std::num::NonZeroUsize::new(1), 1).unwrap();
            let thresholds = make::filter::FilterThresholds {
                mind: Some(1.0),
                geno: Some(1.0),
                maf: Some(0.0),
                hwe_midp: None,
            };
            for budget in [decision_bytes - 1, decision_bytes] {
                limited.memory_bytes = budget;
                let (samples, variants) =
                    make::select(&budget_dataset, &Selection::default()).unwrap();
                let result =
                    make::filter::apply(&budget_dataset, samples, variants, &thresholds, &limited);
                if budget < decision_bytes {
                    assert!(
                        result
                            .as_ref()
                            .is_err_and(|error| error.to_string().contains("decision state")),
                        "cached filter must admit both indexes before allocation even with no pending decode; got {result:?}"
                    );
                } else {
                    let (samples, variants) = result.unwrap();
                    assert_eq!((samples.len(), variants.len()), (72, 1024));
                }
            }
        }
    }
    crate::stats::hwe::LOG_ADDITIONS.with(|count| count.set(0));
    let source_normal = crate::stats::hwe::midp_log(760, 147, 22);
    assert_eq!(
        crate::numeric::six_significant(source_normal.exp()),
        "7.06926e-05"
    );
    assert_eq!(
        crate::stats::hwe::LOG_ADDITIONS.with(|count| count.get()),
        0,
        "ordinary source-bound HWE must not execute a per-state log-add recurrence"
    );
    for counts in [[3, 2, 1], [2, 4, 0]] {
        assert_eq!(
            crate::numeric::six_significant(
                crate::stats::hwe::midp_log(counts[0], counts[1], counts[2]).exp()
            ),
            "0.515152",
            "equal-likelihood mid-P must retain both half weights (17/33)"
        );
    }
    crate::stats::hwe::LOG_ADDITIONS.with(|count| count.set(0));
    let extreme = crate::stats::hwe::midp_log(0, 3000, 0);
    assert!(extreme.is_finite() && extreme.exp() == 0.0);
    assert!(crate::stats::hwe::LOG_ADDITIONS.with(|count| count.get()) > 0);
}

#[test]
fn failed_import_preserves_existing_generation_and_manifest_rejects_mixed_state() {
    let inputs = fixtures().join("inputs");
    let dir = tempfile::tempdir_in(std::env::temp_dir()).unwrap();
    let out = dir.path().join("data");
    let execution = Execution::new(std::num::NonZeroUsize::new(1), 512).unwrap();
    let mut config = MakeConfig {
        input: InputSpec::Vcf(inputs.join("baseline.vcf")),
        profile: ImportProfile::default(),
        selection: Selection::default(),
        filters: Default::default(),
        out: out.clone(),
    };
    make::run(&config, &execution).unwrap();
    let external = Dataset::open(
        InputSpec::Pgen(fixtures().join("external/data")),
        ImportProfile::default(),
    )
    .unwrap();
    let expected_external = fs::read_to_string(fixtures().join("external/raw.jsonl"))
        .unwrap()
        .lines()
        .skip(1)
        .map(|line| serde_json::from_str::<Value>(line).unwrap())
        .collect::<Vec<_>>();
    assert_raw(
        &raw(&external),
        &expected_external,
        "accepted external-index input",
    );
    let header_ref_resolved = external
        .metadata
        .variants
        .iter()
        .zip(&expected_external)
        .all(|(variant, raw)| variant.provisional_ref == raw["provisional_ref"].as_bool().unwrap());
    let large = dir.path().join("large-input");
    for extension in ["pgen", "pgen.pgi", "psam"] {
        fs::copy(
            crate::dataset::sibling(&fixtures().join("external/data"), extension),
            crate::dataset::sibling(&large, extension),
        )
        .unwrap();
    }
    let mut lines = fs::read_to_string(fixtures().join("external/data.pvar"))
        .unwrap()
        .lines()
        .map(str::to_owned)
        .collect::<Vec<_>>();
    let header = lines
        .iter()
        .position(|line| line.starts_with("#CHROM"))
        .unwrap();
    lines.insert(
        header,
        "##INFO=<ID=NOTE,Number=1,Type=String,Description=\"Memory accounting review\">".into(),
    );
    let header = header + 1;
    lines[header].push_str("\tINFO");
    for (index, line) in lines.iter_mut().enumerate().skip(header + 1) {
        line.push('\t');
        if index == header + 1 {
            line.push_str("NOTE=");
            line.push_str(&"A".repeat(4 * 1024 * 1024));
        } else {
            line.push('.');
        }
    }
    let large_pvar = crate::dataset::sibling(&large, "pvar");
    fs::write(&large_pvar, lines.join("\n") + "\n").unwrap();
    assert_eq!(fs::metadata(&large_pvar).unwrap().len(), 4_195_985);
    let limited_out = dir.path().join("limited-output");
    let limited = MakeConfig {
        input: InputSpec::Pgen(large),
        profile: ImportProfile::default(),
        selection: Selection::default(),
        filters: Default::default(),
        out: limited_out.clone(),
    };
    let result = make::run(
        &limited,
        &Execution::new(std::num::NonZeroUsize::new(1), 1).unwrap(),
    );
    let memory_rejected = result
        .as_ref()
        .is_err_and(|error| error.to_string().contains("memory"));
    let unpublished = ["pgen", "pvar", "psam", "rsomics.json"]
        .iter()
        .all(|extension| !crate::dataset::sibling(&limited_out, extension).exists());
    assert!(
        header_ref_resolved && memory_rejected && unpublished,
        "external REF metadata resolved={header_ref_resolved}; 1MiB rejected={memory_rejected}; no published generation={unpublished}"
    );
    let before = ["pgen", "pvar", "psam", "rsomics.json"]
        .map(|ext| fs::read(crate::dataset::sibling(&out, ext)).unwrap());
    for invalid in [
        "halfcall.vcf",
        "invalid-allele.vcf",
        "invalid-cardinality.vcf",
        "unsupported-multiallelic-dosage.vcf",
    ] {
        config.input = InputSpec::Vcf(inputs.join(invalid));
        config.profile.dosage = DosageField::Ds;
        assert!(make::run(&config, &execution).is_err(), "{invalid}");
        let after = ["pgen", "pvar", "psam", "rsomics.json"]
            .map(|ext| fs::read(crate::dataset::sibling(&out, ext)).unwrap());
        assert_eq!(before, after);
    }
    let missing_index = dir.path().join("missing-index");
    for extension in ["pgen", "pvar", "psam"] {
        fs::copy(
            crate::dataset::sibling(&fixtures().join("external/data"), extension),
            crate::dataset::sibling(&missing_index, extension),
        )
        .unwrap();
    }
    config.input = InputSpec::Pgen(missing_index);
    config.profile = ImportProfile::default();
    assert!(
        make::run(&config, &execution).is_err(),
        "missing external PGEN index"
    );
    let after = ["pgen", "pvar", "psam", "rsomics.json"]
        .map(|ext| fs::read(crate::dataset::sibling(&out, ext)).unwrap());
    assert_eq!(before, after);
    fs::write(crate::dataset::sibling(&out, "psam"), b"#IID\nwrong\n").unwrap();
    assert!(Dataset::open(InputSpec::Pgen(out), ImportProfile::default()).is_err());
}
