use crate::dataset::sibling;
use crate::{Result, invalid};
use rsomics_common::AtomicFile;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{
    collections::BTreeMap,
    fmt::Write as _,
    fs::File,
    io::{Read, Write},
    path::Path,
};

#[derive(Serialize, Deserialize)]
pub(crate) struct Manifest {
    pub schema: u32,
    pub source_profile: String,
    pub samples: usize,
    pub variants: usize,
    pub requested_workers: usize,
    pub writer_workers: usize,
    pub files: BTreeMap<String, String>,
    pub projected_vcf_fields: Vec<String>,
}
pub(crate) fn sha(path: &Path) -> Result<String> {
    let mut input = File::open(path)?;
    let mut hash = Sha256::new();
    let mut buffer = [0u8; 65536];
    loop {
        let n = input.read(&mut buffer)?;
        if n == 0 {
            break;
        }
        hash.update(&buffer[..n]);
    }
    let mut output = String::with_capacity(64);
    for byte in hash.finalize() {
        write!(&mut output, "{byte:02x}").expect("writing to a String cannot fail");
    }
    Ok(output)
}
pub(crate) fn verify(prefix: &Path) -> Result<()> {
    let path = sibling(prefix, "rsomics.json");
    if !path.try_exists()? {
        return Ok(());
    }
    let manifest: Manifest = serde_json::from_reader(File::open(path)?)
        .map_err(|e| invalid(format!("invalid generation manifest: {e}")))?;
    if manifest.schema != 1
        || manifest.files.len() != 3
        || ["pgen", "pvar", "psam"]
            .iter()
            .any(|key| !manifest.files.contains_key(*key))
    {
        return Err(invalid("unsupported/incomplete generation manifest"));
    }
    for (extension, expected) in &manifest.files {
        if sha(&sibling(prefix, extension))? != *expected {
            return Err(invalid(format!(
                "generation identity mismatch for {extension}"
            )));
        }
    }
    Ok(())
}
pub(crate) fn commit(
    prefix: &Path,
    outputs: Vec<AtomicFile>,
    mut manifest: Manifest,
) -> Result<()> {
    for (extension, output) in ["pgen", "pvar", "psam"].iter().zip(&outputs) {
        manifest
            .files
            .insert((*extension).into(), sha(output.temporary_path())?);
    }
    let mut metadata = AtomicFile::new(sibling(prefix, "rsomics.json"))?;
    serde_json::to_writer_pretty(metadata.file_mut(), &manifest)
        .map_err(|e| invalid(format!("writing generation manifest: {e}")))?;
    writeln!(metadata.file_mut())?;
    let mut all = outputs;
    all.push(metadata);
    AtomicFile::commit_all(all)
}
