use super::{chrom::Chromosome, sibling};
use crate::{Result, invalid};
use std::{collections::HashSet, fs, io::Write, path::Path};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum Sex {
    Unknown,
    Male,
    Female,
}
#[derive(Clone, Debug)]
pub(crate) struct Sample {
    pub fid: String,
    pub iid: String,
    pub sid: String,
    pub paternal: String,
    pub maternal: String,
    pub sex: Sex,
    pub fields: Vec<String>,
}
impl Sample {
    pub fn founder(&self) -> bool {
        self.paternal == "0" && self.maternal == "0"
    }
}
#[derive(Clone, Debug)]
pub(crate) struct Variant {
    pub chromosome: Chromosome,
    pub position: u64,
    pub id: String,
    pub alleles: Vec<String>,
    pub provisional_ref: bool,
    pub fields: Vec<String>,
}
#[derive(Clone, Debug)]
pub(crate) struct Metadata {
    pub sample_header: Vec<String>,
    pub variant_header: Vec<String>,
    pub sample_preamble: Vec<String>,
    pub variant_preamble: Vec<String>,
    pub samples: Vec<Sample>,
    pub variants: Vec<Variant>,
}
struct TextTable {
    preamble: Vec<String>,
    header: Vec<String>,
    rows: Vec<Vec<String>>,
}
fn table(path: &Path) -> Result<TextTable> {
    let text = fs::read_to_string(path)?;
    let mut preamble = Vec::new();
    let mut header = None;
    let mut rows = Vec::new();
    for line in text.lines().filter(|line| !line.is_empty()) {
        if line.starts_with("##") {
            preamble.push(line.into());
        } else if let Some(line) = line.strip_prefix('#') {
            if header.is_some() {
                return Err(invalid("duplicate metadata header"));
            }
            header = Some(
                line.split_whitespace()
                    .map(str::to_owned)
                    .collect::<Vec<_>>(),
            );
        } else {
            rows.push(
                line.split_whitespace()
                    .map(str::to_owned)
                    .collect::<Vec<_>>(),
            );
        }
    }
    let header =
        header.ok_or_else(|| invalid(format!("{} has no column header", path.display())))?;
    if rows.iter().any(|row| row.len() != header.len()) {
        return Err(invalid("metadata row/header width mismatch"));
    }
    Ok(TextTable {
        preamble,
        header,
        rows,
    })
}
fn field<'a>(header: &[String], row: &'a [String], key: &str, default: &'a str) -> &'a str {
    header
        .iter()
        .position(|name| name == key)
        .map(|i| row[i].as_str())
        .unwrap_or(default)
}
pub(crate) fn samples(header: &[String], rows: Vec<Vec<String>>) -> Result<Vec<Sample>> {
    if !header.iter().any(|name| name == "IID") {
        return Err(invalid("PSAM requires IID"));
    }
    rows.into_iter()
        .map(|row| {
            Ok(Sample {
                fid: field(header, &row, "FID", "0").into(),
                iid: field(header, &row, "IID", "").into(),
                sid: field(header, &row, "SID", "0").into(),
                paternal: field(header, &row, "PAT", "0").into(),
                maternal: field(header, &row, "MAT", "0").into(),
                sex: match field(header, &row, "SEX", "0") {
                    "0" | "NA" => Sex::Unknown,
                    "1" => Sex::Male,
                    "2" => Sex::Female,
                    _ => return Err(invalid("SEX must be 0, 1, 2 or NA")),
                },
                fields: row,
            })
        })
        .collect()
}
pub(crate) fn read_samples(path: &Path) -> Result<(Vec<String>, Vec<String>, Vec<Sample>)> {
    let TextTable {
        preamble,
        header,
        rows,
    } = table(path)?;
    let data = samples(&header, rows)?;
    Ok((preamble, header, data))
}
impl Metadata {
    pub fn read_pgen(prefix: &Path) -> Result<Self> {
        let (sample_preamble, sample_header, samples) = read_samples(&sibling(prefix, "psam"))?;
        let TextTable {
            preamble: variant_preamble,
            header: variant_header,
            rows,
        } = table(&sibling(prefix, "pvar"))?;
        for key in ["CHROM", "POS", "ID", "REF", "ALT"] {
            if !variant_header.iter().any(|name| name == key) {
                return Err(invalid(format!("PVAR requires {key}")));
            }
        }
        let variants = rows
            .into_iter()
            .map(|row| {
                let mut alleles = vec![field(&variant_header, &row, "REF", "").to_owned()];
                alleles.extend(
                    field(&variant_header, &row, "ALT", "")
                        .split(',')
                        .map(str::to_owned),
                );
                let position = field(&variant_header, &row, "POS", "")
                    .parse()
                    .map_err(|_| invalid("invalid PVAR position"))?;
                Ok(Variant {
                    chromosome: Chromosome::parse(field(&variant_header, &row, "CHROM", "")),
                    position,
                    id: field(&variant_header, &row, "ID", "").into(),
                    alleles,
                    provisional_ref: field(&variant_header, &row, "INFO", ".")
                        .split(';')
                        .any(|x| x == "PR"),
                    fields: row,
                })
            })
            .collect::<Result<Vec<_>>>()?;
        Ok(Self {
            sample_header,
            variant_header,
            sample_preamble,
            variant_preamble,
            samples,
            variants,
        })
    }
    pub fn validate(&self) -> Result<()> {
        let mut identities = HashSet::new();
        for sample in &self.samples {
            if sample.iid.is_empty() || !identities.insert((&sample.fid, &sample.iid, &sample.sid))
            {
                return Err(invalid("duplicate/empty sample identity"));
            }
        }
        if self.samples.len() > (i32::MAX as usize) - 1
            || self.variants.len() > (i32::MAX as usize) - 2
        {
            return Err(invalid("dataset exceeds codec dimensions"));
        }
        for variant in &self.variants {
            if !(2..=255).contains(&variant.alleles.len())
                || variant.alleles.iter().any(String::is_empty)
            {
                return Err(invalid("invalid allele metadata"));
            }
        }
        Ok(())
    }
    pub fn offsets(&self) -> Vec<u64> {
        let mut result = Vec::with_capacity(self.variants.len() + 1);
        result.push(0);
        for v in &self.variants {
            result.push(result.last().copied().unwrap_or(0) + v.alleles.len() as u64);
        }
        result
    }
    pub fn write_samples(&self, output: &mut dyn Write, selected: &[usize]) -> Result<()> {
        for line in &self.sample_preamble {
            writeln!(output, "{line}")?;
        }
        writeln!(output, "#{}", self.sample_header.join("\t"))?;
        for &i in selected {
            writeln!(output, "{}", self.samples[i].fields.join("\t"))?;
        }
        Ok(())
    }
    pub fn write_variants(
        &self,
        output: &mut dyn Write,
        selected: &[usize],
        provisional: &[bool],
    ) -> Result<()> {
        let mut header = self.variant_header.clone();
        let info = header.iter().position(|s| s == "INFO").unwrap_or_else(|| {
            header.push("INFO".into());
            header.len() - 1
        });
        for line in &self.variant_preamble {
            writeln!(output, "{line}")?;
        }
        if !self
            .variant_preamble
            .iter()
            .any(|line| line.starts_with("##INFO=<ID=PR,"))
        {
            writeln!(
                output,
                "##INFO=<ID=PR,Number=0,Type=Flag,Description=\"Provisional reference allele\">"
            )?;
        }
        writeln!(output, "#{}", header.join("\t"))?;
        for (&i, &pr) in selected.iter().zip(provisional) {
            let mut row = self.variants[i].fields.clone();
            row.resize(header.len(), ".".into());
            let mut infos = row[info]
                .split(';')
                .filter(|x| *x != "PR" && *x != ".")
                .map(str::to_owned)
                .collect::<Vec<_>>();
            if pr {
                infos.push("PR".into());
            }
            row[info] = if infos.is_empty() {
                ".".into()
            } else {
                infos.join(";")
            };
            writeln!(output, "{}", row.join("\t"))?;
        }
        Ok(())
    }
}
