use crate::dataset::{Dataset, DosageField, ImportProfile, InputSpec, VariantId};
use crate::execution::Execution;
use crate::make::{self, MakeConfig, Selection};
use serde_json::{Value, json};
use std::{fs, path::PathBuf};

fn fixtures() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures")
}
fn raw(dataset: &Dataset) -> Vec<Value> {
    let mut reader = dataset.reader().unwrap();
    let rows = (0..dataset.metadata.variants.len())
        .map(|v| {
            let value = reader.read(VariantId(v)).unwrap();
            let calls = value
                .calls()
                .map(|call| {
                    let mut alleles = call
                        .alleles
                        .map(|[a, b]| [a as i32, b as i32])
                        .unwrap_or([-9, -9]);
                    if call.phase && call.reversed {
                        alleles.swap(0, 1);
                    }
                    json!([
                        alleles[0],
                        alleles[1],
                        u8::from(call.phase),
                        u8::from(call.reversed),
                        call.dosage,
                        call.dphase
                    ])
                })
                .collect::<Vec<_>>();
            json!({"variant":v,"provisional_ref":value.provisional_ref,"calls":calls})
        })
        .collect();
    reader.close().unwrap();
    rows
}
fn assert_raw(actual: &[Value], expected: &[Value], context: &str) {
    assert_eq!(actual.len(), expected.len(), "{context} variant count");
    for (variant, (actual, expected)) in actual.iter().zip(expected).enumerate() {
        assert_eq!(actual["variant"], expected["variant"], "{context} ordinal");
        assert_eq!(
            actual["provisional_ref"], expected["provisional_ref"],
            "{context} variant{variant} REF"
        );
        let a = actual["calls"].as_array().unwrap();
        let e = expected["calls"].as_array().unwrap();
        assert_eq!(a.len(), e.len(), "{context} sample count");
        for (sample, (actual, expected)) in a.iter().zip(e).enumerate() {
            assert_eq!(
                actual, expected,
                "{context} variant{variant} sample{sample}"
            );
        }
    }
}

#[test]
fn six_lane_make_preserves_accepted_raw_state_through_fresh_reopen_and_selection() {
    let inputs = fixtures().join("inputs");
    let directory = tempfile::Builder::new()
        .prefix("plink-native-six-")
        .tempdir_in(std::env::temp_dir())
        .unwrap();
    let execution = Execution::new(std::num::NonZeroUsize::new(2), 512).unwrap();
    for lane in ["gt", "bed", "pgen", "ds", "hds", "rich"] {
        let input = match lane {
            "bed" => InputSpec::Bed(inputs.join("baseline")),
            "pgen" => InputSpec::Pgen(directory.path().join("gt.I")),
            _ => InputSpec::Vcf(inputs.join(if lane == "gt" {
                "baseline.vcf".into()
            } else {
                format!("{lane}.vcf")
            })),
        };
        let profile = ImportProfile {
            psam: matches!(input, InputSpec::Vcf(_)).then(|| inputs.join("baseline.psam")),
            dosage: match lane {
                "ds" => DosageField::Ds,
                "hds" => DosageField::Hds,
                _ => DosageField::None,
            },
            split_par_b37: lane == "rich",
            ..ImportProfile::default()
        };
        let out = directory.path().join(format!("{lane}.I"));
        make::run(
            &MakeConfig {
                input,
                profile,
                selection: Selection::default(),
                filters: Default::default(),
                out: out.clone(),
            },
            &execution,
        )
        .unwrap_or_else(|e| panic!("{lane}: {e}"));
        let dataset =
            Dataset::open(InputSpec::Pgen(out.clone()), ImportProfile::default()).unwrap();
        let expected = fs::read_to_string(fixtures().join(format!("oracle/{lane}/raw.jsonl")))
            .unwrap()
            .lines()
            .skip(1)
            .map(|line| serde_json::from_str::<Value>(line).unwrap())
            .collect::<Vec<_>>();
        assert_raw(&raw(&dataset), &expected, &format!("{lane} native I"));
        let selected = directory.path().join(format!("{lane}.selected"));
        let indices = (0..65).collect::<Vec<_>>();
        let variants = (0..dataset.metadata.variants.len()).collect::<Vec<_>>();
        make::materialize(&dataset, &indices, &variants, &selected, &execution).unwrap();
        let reread = Dataset::open(InputSpec::Pgen(selected), ImportProfile::default()).unwrap();
        let mut selected_expected = expected;
        for row in &mut selected_expected {
            row["calls"].as_array_mut().unwrap().truncate(65);
        }
        assert_raw(
            &raw(&reread),
            &selected_expected,
            &format!("{lane} selected65"),
        );
    }
}

#[test]
fn failed_import_preserves_existing_generation_and_manifest_rejects_mixed_state() {
    let inputs = fixtures().join("inputs");
    let dir = tempfile::tempdir_in(std::env::temp_dir()).unwrap();
    let out = dir.path().join("data");
    let execution = Execution::new(std::num::NonZeroUsize::new(1), 512).unwrap();
    let mut config = MakeConfig {
        input: InputSpec::Vcf(inputs.join("baseline.vcf")),
        profile: ImportProfile::default(),
        selection: Selection::default(),
        filters: Default::default(),
        out: out.clone(),
    };
    make::run(&config, &execution).unwrap();
    let external = Dataset::open(
        InputSpec::Pgen(fixtures().join("external/data")),
        ImportProfile::default(),
    )
    .unwrap();
    let expected_external = fs::read_to_string(fixtures().join("external/raw.jsonl"))
        .unwrap()
        .lines()
        .skip(1)
        .map(|line| serde_json::from_str::<Value>(line).unwrap())
        .collect::<Vec<_>>();
    assert_raw(
        &raw(&external),
        &expected_external,
        "accepted external-index input",
    );
    let header_ref_resolved = external
        .metadata
        .variants
        .iter()
        .zip(&expected_external)
        .all(|(variant, raw)| variant.provisional_ref == raw["provisional_ref"].as_bool().unwrap());
    let large = dir.path().join("large-input");
    for extension in ["pgen", "pgen.pgi", "psam"] {
        fs::copy(
            crate::dataset::sibling(&fixtures().join("external/data"), extension),
            crate::dataset::sibling(&large, extension),
        )
        .unwrap();
    }
    let mut lines = fs::read_to_string(fixtures().join("external/data.pvar"))
        .unwrap()
        .lines()
        .map(str::to_owned)
        .collect::<Vec<_>>();
    let header = lines
        .iter()
        .position(|line| line.starts_with("#CHROM"))
        .unwrap();
    lines.insert(
        header,
        "##INFO=<ID=NOTE,Number=1,Type=String,Description=\"Memory accounting review\">".into(),
    );
    let header = header + 1;
    lines[header].push_str("\tINFO");
    for (index, line) in lines.iter_mut().enumerate().skip(header + 1) {
        line.push('\t');
        if index == header + 1 {
            line.push_str("NOTE=");
            line.push_str(&"A".repeat(4 * 1024 * 1024));
        } else {
            line.push('.');
        }
    }
    let large_pvar = crate::dataset::sibling(&large, "pvar");
    fs::write(&large_pvar, lines.join("\n") + "\n").unwrap();
    assert_eq!(fs::metadata(&large_pvar).unwrap().len(), 4_195_985);
    let limited_out = dir.path().join("limited-output");
    let limited = MakeConfig {
        input: InputSpec::Pgen(large),
        profile: ImportProfile::default(),
        selection: Selection::default(),
        filters: Default::default(),
        out: limited_out.clone(),
    };
    let result = make::run(
        &limited,
        &Execution::new(std::num::NonZeroUsize::new(1), 1).unwrap(),
    );
    let memory_rejected = result
        .as_ref()
        .is_err_and(|error| error.to_string().contains("memory"));
    let unpublished = ["pgen", "pvar", "psam", "rsomics.json"]
        .iter()
        .all(|extension| !crate::dataset::sibling(&limited_out, extension).exists());
    assert!(
        header_ref_resolved && memory_rejected && unpublished,
        "external REF metadata resolved={header_ref_resolved}; 1MiB rejected={memory_rejected}; no published generation={unpublished}"
    );
    let before = ["pgen", "pvar", "psam", "rsomics.json"]
        .map(|ext| fs::read(crate::dataset::sibling(&out, ext)).unwrap());
    for invalid in [
        "halfcall.vcf",
        "invalid-allele.vcf",
        "invalid-cardinality.vcf",
        "unsupported-multiallelic-dosage.vcf",
    ] {
        config.input = InputSpec::Vcf(inputs.join(invalid));
        config.profile.dosage = DosageField::Ds;
        assert!(make::run(&config, &execution).is_err(), "{invalid}");
        let after = ["pgen", "pvar", "psam", "rsomics.json"]
            .map(|ext| fs::read(crate::dataset::sibling(&out, ext)).unwrap());
        assert_eq!(before, after);
    }
    let missing_index = dir.path().join("missing-index");
    for extension in ["pgen", "pvar", "psam"] {
        fs::copy(
            crate::dataset::sibling(&fixtures().join("external/data"), extension),
            crate::dataset::sibling(&missing_index, extension),
        )
        .unwrap();
    }
    config.input = InputSpec::Pgen(missing_index);
    config.profile = ImportProfile::default();
    assert!(
        make::run(&config, &execution).is_err(),
        "missing external PGEN index"
    );
    let after = ["pgen", "pvar", "psam", "rsomics.json"]
        .map(|ext| fs::read(crate::dataset::sibling(&out, ext)).unwrap());
    assert_eq!(before, after);
    fs::write(crate::dataset::sibling(&out, "psam"), b"#IID\nwrong\n").unwrap();
    assert!(Dataset::open(InputSpec::Pgen(out), ImportProfile::default()).is_err());
}
