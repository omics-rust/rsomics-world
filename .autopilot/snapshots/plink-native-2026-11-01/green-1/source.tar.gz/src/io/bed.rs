use crate::dataset::{
    GenotypeReader, VariantId,
    chrom::Chromosome,
    genotypes::{Call, Genotypes},
    metadata::{Metadata, Sample, Sex, Variant},
    sibling,
};
use crate::{Result, invalid};
use std::{
    fs::{self, File},
    io::{Read, Seek, SeekFrom},
    path::Path,
};

pub(crate) fn metadata(prefix: &Path) -> Result<Metadata> {
    let fam = fs::read_to_string(sibling(prefix, "fam"))?;
    let bim = fs::read_to_string(sibling(prefix, "bim"))?;
    let mut samples = Vec::new();
    let mut variants = Vec::new();
    for line in fam.lines().filter(|l| !l.trim().is_empty()) {
        let f = line
            .split_whitespace()
            .map(str::to_owned)
            .collect::<Vec<_>>();
        if f.len() != 6 {
            return Err(invalid("FAM requires six fields"));
        }
        samples.push(Sample {
            fid: f[0].clone(),
            iid: f[1].clone(),
            sid: "0".into(),
            paternal: f[2].clone(),
            maternal: f[3].clone(),
            sex: match f[4].as_str() {
                "1" => Sex::Male,
                "2" => Sex::Female,
                "0" => Sex::Unknown,
                _ => return Err(invalid("invalid FAM sex")),
            },
            fields: f,
        });
    }
    for line in bim.lines().filter(|l| !l.trim().is_empty()) {
        let f = line.split_whitespace().collect::<Vec<_>>();
        if f.len() != 6 {
            return Err(invalid("BIM requires six fields"));
        }
        variants.push(Variant {
            chromosome: Chromosome::parse(f[0]),
            position: f[3].parse().map_err(|_| invalid("invalid BIM position"))?,
            id: f[1].into(),
            alleles: vec![f[5].into(), f[4].into()],
            provisional_ref: true,
            fields: vec![
                f[0].into(),
                f[3].into(),
                f[1].into(),
                f[5].into(),
                f[4].into(),
                f[2].into(),
                "PR".into(),
            ],
        });
    }
    Ok(Metadata {
        sample_header: ["FID", "IID", "PAT", "MAT", "SEX", "PHENO1"]
            .map(str::to_owned)
            .to_vec(),
        variant_header: ["CHROM", "POS", "ID", "REF", "ALT", "CM", "INFO"]
            .map(str::to_owned)
            .to_vec(),
        sample_preamble: Vec::new(),
        variant_preamble: Vec::new(),
        samples,
        variants,
    })
}
pub(crate) struct Reader {
    file: File,
    samples: usize,
    variants: usize,
    stride: usize,
    buffer: Vec<u8>,
}
impl Reader {
    pub fn open(prefix: &Path, metadata: &Metadata) -> Result<Self> {
        let mut file = File::open(sibling(prefix, "bed"))?;
        let mut magic = [0; 3];
        file.read_exact(&mut magic)?;
        if magic != [0x6c, 0x1b, 1] {
            return Err(invalid("BED must use SNP-major encoding"));
        }
        let samples = metadata.samples.len();
        let variants = metadata.variants.len();
        let stride = samples.div_ceil(4);
        if file.metadata()?.len() != 3 + (stride as u64) * (variants as u64) {
            return Err(invalid("BED length does not match BIM/FAM"));
        }
        Ok(Self {
            file,
            samples,
            variants,
            stride,
            buffer: vec![0; stride],
        })
    }
}
impl GenotypeReader for Reader {
    fn read(&mut self, variant: VariantId) -> Result<Genotypes> {
        if variant.0 >= self.variants {
            return Err(invalid("BED variant index out of range"));
        }
        self.file
            .seek(SeekFrom::Start(3 + (variant.0 * self.stride) as u64))?;
        self.file.read_exact(&mut self.buffer)?;
        let calls = (0..self.samples)
            .map(|i| Call {
                alleles: match (self.buffer[i / 4] >> (2 * (i % 4))) & 3 {
                    0 => Some([1, 1]),
                    2 => Some([0, 1]),
                    3 => Some([0, 0]),
                    _ => None,
                },
                ..Call::default()
            })
            .collect::<Vec<_>>();
        Genotypes::from_calls(&calls, 2, true)
    }
    fn workspace_bytes(&self) -> usize {
        self.buffer.len()
    }
    fn close(self: Box<Self>) -> Result<()> {
        Ok(())
    }
}
