use crate::dataset::{
    chrom::Chromosome,
    genotypes::{Call, Genotypes},
    metadata::{Metadata, Sample, Sex, Variant},
};

#[derive(Default, Clone, Copy)]
pub(crate) struct Missing {
    pub hardcall: u64,
    pub dosage: u64,
    pub hethap: u64,
    pub observations: u64,
}

impl Missing {
    pub fn add(&mut self, call: Call, haploid: bool) {
        self.observations += 1;
        self.hardcall += u64::from(call.alleles.is_none());
        self.dosage += u64::from(call.alleles.is_none() && call.dosage.is_none());
        self.hethap += u64::from(haploid && call.alleles.is_some_and(|[a, b]| a != b));
    }
}

#[derive(Default, Clone)]
pub(crate) struct SampleTotals {
    pub hom_ref: u64,
    pub hom_alt: u64,
    pub het_ref_alt: u64,
    pub het_two_alt: u64,
    pub hap_ref: u64,
    pub hap_alt: u64,
    pub missing_calls: u64,
    pub missing: Missing,
    pub observed_het: u64,
    pub expected_het: f64,
    pub het_observations: u64,
}

pub(crate) fn missing_eligible(chrom: &Chromosome, sample: &Sample) -> bool {
    !matches!(chrom, Chromosome::Y) || sample.sex == Sex::Male
}

pub(crate) fn haploid(chrom: &Chromosome, sample: &Sample) -> bool {
    matches!(chrom, Chromosome::Y | Chromosome::Mt)
        || matches!(chrom, Chromosome::X) && sample.sex == Sex::Male
}

pub(crate) fn heterozygosity_chromosome(chrom: &Chromosome) -> bool {
    !matches!(chrom, Chromosome::X | Chromosome::Y | Chromosome::Mt)
}

pub(crate) fn pair_index(a: usize, b: usize) -> usize {
    b * (b + 1) / 2 + a
}

pub(crate) struct VariantTotals {
    pub allele_units: Vec<u64>,
    pub diploid: Vec<u64>,
    pub haploid: Vec<u64>,
    pub genotype_missing: u64,
    pub genotype_observations: u64,
    pub missing: Missing,
    pub hwe_counts: [u64; 3],
    pub expected_het: f64,
}

impl VariantTotals {
    pub fn nonmajor_frequency(&self) -> f64 {
        let total = self.allele_units.iter().sum::<u64>();
        if total == 0 {
            return 1.0 - 1.0 / self.allele_units.len() as f64;
        }
        (total - self.allele_units.iter().copied().max().unwrap_or(0)) as f64 / total as f64
    }
}

pub(crate) fn variant(
    genotypes: &Genotypes,
    variant: &Variant,
    metadata: &Metadata,
    sample_positions: &[usize],
) -> VariantTotals {
    let k = variant.alleles.len();
    let mut result = VariantTotals {
        allele_units: vec![0; k],
        diploid: vec![0; k * (k + 1) / 2],
        haploid: vec![0; k],
        genotype_missing: 0,
        genotype_observations: 0,
        missing: Missing::default(),
        hwe_counts: [0; 3],
        expected_het: 0.0,
    };
    for (index, call) in genotypes.calls().enumerate() {
        if sample_positions[index] == usize::MAX {
            continue;
        }
        let sample = &metadata.samples[index];
        let is_haploid = haploid(&variant.chromosome, sample);
        if missing_eligible(&variant.chromosome, sample) {
            result.missing.add(call, is_haploid);
        }
        if !matches!(variant.chromosome, Chromosome::Y) || sample.sex != Sex::Female {
            match call.alleles {
                Some([a, b]) if !is_haploid => {
                    result.diploid[pair_index(a as usize, b as usize)] += 1;
                    result.genotype_observations += 1;
                }
                Some([a, b]) if a == b => {
                    result.haploid[a as usize] += 1;
                    result.genotype_observations += 1;
                }
                Some([a, b]) if matches!(variant.chromosome, Chromosome::Mt) => {
                    result.diploid[pair_index(a as usize, b as usize)] += 1;
                    result.genotype_observations += 1;
                }
                _ => result.genotype_missing += 1,
            }
        }
        if !sample.founder() {
            continue;
        }
        if variant.chromosome.is_autosome()
            && k == 2
            && let Some([a, b]) = call.alleles
        {
            result.hwe_counts[(a + b) as usize] += 1;
        }
        if matches!(variant.chromosome, Chromosome::Y) && sample.sex == Sex::Female {
            continue;
        }
        let multiplier = if is_haploid { 1 } else { 2 };
        if let Some(dosage) = call.dosage {
            result.allele_units[0] += u64::from(32768 - dosage) * multiplier;
            result.allele_units[1] += u64::from(dosage) * multiplier;
        } else if let Some([a, b]) = call.alleles {
            result.allele_units[a as usize] += 16384 * multiplier;
            result.allele_units[b as usize] += 16384 * multiplier;
        }
    }
    let units = result.allele_units.iter().sum::<u64>();
    let mut frequency_sum = 0.0;
    let mut squares = 0.0;
    for &value in result.allele_units.iter().take(k - 1) {
        let frequency = if units == 0 {
            1.0 / k as f64
        } else {
            value as f64 / units as f64
        };
        frequency_sum += frequency;
        squares += frequency * frequency;
    }
    let last = 1.0 - frequency_sum;
    result.expected_het = 1.0 - squares - last * last;
    result
}

pub(crate) fn add_samples(
    genotypes: &Genotypes,
    variant: &Variant,
    metadata: &Metadata,
    sample_positions: &[usize],
    counts: &VariantTotals,
    samples: &mut [SampleTotals],
) {
    let het_eligible =
        heterozygosity_chromosome(&variant.chromosome) && counts.expected_het >= 2f64.powi(-35);
    for (index, call) in genotypes.calls().enumerate() {
        let position = sample_positions[index];
        if position == usize::MAX {
            continue;
        }
        let sample = &metadata.samples[index];
        let total = &mut samples[position];
        if missing_eligible(&variant.chromosome, sample) {
            let is_haploid = haploid(&variant.chromosome, sample);
            total.missing.add(call, is_haploid);
            match call.alleles {
                Some([a, b]) if is_haploid && a == b => {
                    if a == 0 {
                        total.hap_ref += 1;
                    } else {
                        total.hap_alt += 1;
                    }
                }
                Some(_) if is_haploid => total.missing_calls += 1,
                Some([0, 0]) => total.hom_ref += 1,
                Some([a, b]) if a == b => total.hom_alt += 1,
                Some([0, _]) => total.het_ref_alt += 1,
                Some(_) => total.het_two_alt += 1,
                None => total.missing_calls += 1,
            }
        }
        if het_eligible && let Some([a, b]) = call.alleles {
            total.observed_het += u64::from(a != b);
            total.expected_het += counts.expected_het;
            total.het_observations += 1;
        }
    }
}
