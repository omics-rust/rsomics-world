pub(crate) mod hwe;
pub(crate) mod tally;

use crate::dataset::{
    Dataset, ImportProfile, InputSpec, VariantId,
    chrom::Chromosome,
    genotypes::Genotypes,
    metadata::{Metadata, Sex, Variant},
    sibling,
};
use crate::execution::Execution;
use crate::make::{self, Selection};
use crate::{Result, invalid};
use rayon::prelude::*;
use rsomics_common::{AtomicFile, reject_output_alias};
use serde::Serialize;
use std::{io::Write, mem::size_of, path::PathBuf};
use tally::{Missing, SampleTotals, VariantTotals};

pub(crate) struct StatsConfig {
    pub pgen: PathBuf,
    pub out: PathBuf,
    pub selection: Selection,
}

#[derive(Serialize)]
pub(crate) struct QcReport {
    pub samples: usize,
    pub variants: usize,
    pub founders: usize,
    pub hwe_variants: usize,
    pub hwe_scope: &'static str,
    pub requested_workers: usize,
    pub effective_worker_limit: usize,
    pub writer_workers: usize,
    pub batch_variants: usize,
    pub memory_budget_bytes: usize,
    pub output_prefix: PathBuf,
    pub files: Vec<PathBuf>,
}

fn string_vector_bytes(values: &Vec<String>) -> usize {
    values.capacity() * size_of::<String>() + values.iter().map(String::capacity).sum::<usize>()
}

pub(crate) fn metadata_bytes(metadata: &Metadata) -> usize {
    let mut bytes = size_of::<Metadata>()
        + metadata.samples.capacity() * size_of::<crate::dataset::metadata::Sample>()
        + metadata.variants.capacity() * size_of::<Variant>();
    for values in [
        &metadata.sample_header,
        &metadata.variant_header,
        &metadata.sample_preamble,
        &metadata.variant_preamble,
    ] {
        bytes += string_vector_bytes(values);
    }
    for sample in &metadata.samples {
        bytes += [
            &sample.fid,
            &sample.iid,
            &sample.sid,
            &sample.paternal,
            &sample.maternal,
        ]
        .iter()
        .map(|value| value.capacity())
        .sum::<usize>();
        bytes += string_vector_bytes(&sample.fields);
    }
    for variant in &metadata.variants {
        bytes += variant.id.capacity()
            + string_vector_bytes(&variant.alleles)
            + string_vector_bytes(&variant.fields);
        if let Chromosome::Other(value) = &variant.chromosome {
            bytes += value.capacity();
        }
    }
    bytes
}

pub(crate) fn sample_positions(count: usize, samples: &[usize]) -> Vec<usize> {
    let mut positions = vec![usize::MAX; count];
    for (position, &index) in samples.iter().enumerate() {
        positions[index] = position;
    }
    positions
}

pub(crate) fn visit_batches(
    dataset: &Dataset,
    variants: &[usize],
    persistent_bytes: usize,
    execution: &Execution,
    mut visit: impl FnMut(&[(usize, Genotypes)]) -> Result<()>,
) -> Result<usize> {
    let raw_samples = dataset.metadata.samples.len();
    let max_alleles = variants
        .iter()
        .map(|&i| dataset.metadata.variants[i].alleles.len())
        .max()
        .unwrap_or(2);
    let max_identity_bytes = variants
        .iter()
        .map(|&i| {
            let variant = &dataset.metadata.variants[i];
            variant.id.len() + variant.alleles.iter().map(String::len).sum::<usize>() + 128
        })
        .max()
        .unwrap_or(128);
    let packed_bound = raw_samples
        .checked_mul(32)
        .and_then(|n| n.checked_add(4096))
        .ok_or_else(|| invalid("genotype workspace size overflow"))?;
    let per_variant = raw_samples
        .checked_mul(64)
        .and_then(|n| n.checked_add(packed_bound))
        .and_then(|n| {
            n.checked_add(
                64 * max_alleles * (max_alleles + 1)
                    + 32 * max_alleles
                    + 8 * max_identity_bytes
                    + 512,
            )
        })
        .ok_or_else(|| invalid("QC workspace size overflow"))?;
    let mut reader = dataset.reader()?;
    let workspace = reader.workspace_bytes();
    let fixed = metadata_bytes(&dataset.metadata)
        .checked_add(persistent_bytes)
        .and_then(|n| n.checked_add(workspace))
        .ok_or_else(|| invalid("QC memory accounting overflow"))?;
    let width = execution
        .batch_width(fixed, per_variant)?
        .min(variants.len().max(1));
    let mut batch = Vec::with_capacity(width);
    for chunk in variants.chunks(width) {
        batch.clear();
        for &index in chunk {
            let value = reader.read(VariantId(index))?;
            if value.bytes() > packed_bound || reader.workspace_bytes() > workspace {
                return Err(invalid("genotype reader exceeded preflighted QC workspace"));
            }
            batch.push((index, value));
        }
        visit(&batch)?;
    }
    reader.close()?;
    Ok(width)
}

fn float(value: f64) -> String {
    if value.is_nan() {
        return "nan".into();
    }
    if value.is_infinite() {
        return if value.is_sign_negative() {
            "-inf"
        } else {
            "inf"
        }
        .into();
    }
    if value == 0.0 {
        return "0".into();
    }
    let scientific = format!("{value:.5e}");
    let (mantissa, exponent_text) = scientific
        .split_once('e')
        .expect("scientific float has exponent");
    let exponent = exponent_text
        .parse::<i32>()
        .expect("formatter supplies integral exponent");
    if !(-4..6).contains(&exponent) {
        format!(
            "{}e{exponent:+}",
            mantissa.trim_end_matches('0').trim_end_matches('.')
        )
    } else {
        let decimals = (5 - exponent).max(0) as usize;
        let fixed = format!("{value:.decimals$}");
        if decimals == 0 {
            fixed
        } else {
            fixed.trim_end_matches('0').trim_end_matches('.').into()
        }
    }
}

fn dosage_count(units: u64) -> String {
    let value = format!("{:.5}", units as f64 / 32768.0);
    value.trim_end_matches('0').trim_end_matches('.').into()
}

fn probability(logp: f64) -> String {
    if logp >= -4.0 * std::f64::consts::LN_10 {
        return float(logp.exp());
    }
    let mut exponent = (logp / std::f64::consts::LN_10).floor() as i64;
    let mut mantissa = format!(
        "{:.5}",
        (logp - exponent as f64 * std::f64::consts::LN_10).exp()
    );
    if mantissa == "10.00000" {
        exponent += 1;
        mantissa = "1".into();
    }
    format!(
        "{}e{exponent:+}",
        mantissa.trim_end_matches('0').trim_end_matches('.')
    )
}

fn chromosome(chrom: &Chromosome) -> String {
    match chrom {
        Chromosome::Autosome(n) => n.to_string(),
        Chromosome::X => "X".into(),
        Chromosome::Y => "Y".into(),
        Chromosome::Par1 => "PAR1".into(),
        Chromosome::Par2 => "PAR2".into(),
        Chromosome::Mt => "MT".into(),
        Chromosome::Other(value) => value.clone(),
    }
}

fn variant_identity(variant: &Variant) -> String {
    format!(
        "{}\t{}\t{}\t{}\t{}\t{}",
        chromosome(&variant.chromosome),
        variant.position,
        variant.id,
        variant.alleles[0],
        variant.alleles[1..].join(","),
        if variant.provisional_ref { 'Y' } else { 'N' }
    )
}

fn list(values: impl Iterator<Item = u64>) -> String {
    values
        .map(|value| value.to_string())
        .collect::<Vec<_>>()
        .join(",")
}

fn missing_fields(value: Missing) -> String {
    let denominator = value.observations as f64;
    format!(
        "{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}",
        value.dosage,
        value.hardcall,
        value.hardcall + value.hethap,
        value.hethap,
        value.observations,
        float(value.dosage as f64 / denominator),
        float(value.hardcall as f64 / denominator),
        float((value.hardcall + value.hethap) as f64 / denominator)
    )
}

const VARIANT_COLUMNS: &str = "#CHROM\tPOS\tID\tREF\tALT\tPROVISIONAL_REF?";
const MISSING_COLUMNS: &str = "MISSING_DOSAGE_CT\tMISSING_CT\tMISSING_AND_HETHAP_CT\tHETHAP_CT\tOBS_CT\tF_MISS_DOSAGE\tF_MISS\tF_MISS_AND_HETHAP";
const HARDY_COLUMNS: &str = "A1\tAX\tHOM_A1_CT\tHET_A1_CT\tTWO_AX_CT\tO(HET_A1)\tE(HET_A1)";
const EXTENSIONS: [&str; 8] = [
    "acount",
    "gcount",
    "scount",
    "smiss",
    "vmiss",
    "het",
    "hardy",
    "hwe-log.hardy",
];

struct Tables {
    outputs: Vec<AtomicFile>,
}

impl Tables {
    fn open(config: &StatsConfig) -> Result<Self> {
        let inputs =
            ["pgen", "pvar", "psam", "rsomics.json"].map(|suffix| sibling(&config.pgen, suffix));
        let mut outputs = Vec::new();
        for extension in EXTENSIONS {
            let path = sibling(&config.out, extension);
            reject_output_alias(&path, inputs.iter().map(PathBuf::as_path))?;
            outputs.push(AtomicFile::new(path)?);
        }
        let mut tables = Self { outputs };
        tables.line(0, &format!("{VARIANT_COLUMNS}\tREF_CT\tALT_CTS\tOBS_CT"))?;
        tables.line(1, &format!("{VARIANT_COLUMNS}\tHOM_REF_CT\tHET_REF_ALT_CTS\tTWO_ALT_GENO_CTS\tHAP_REF_CT\tHAP_ALT_CTS\tMISSING_CT\tOBS_CT"))?;
        tables.line(2, "#FID\tIID\tSID\tSEX\tHOM_REF_CT\tHOM_ALT_CT\tHET_CT\tHET_REF_ALT_CT\tHET_2ALT_CT\tHAP_REF_CT\tHAP_ALT_CT\tMISSING_CT")?;
        tables.line(3, &format!("#FID\tIID\tSID\t{MISSING_COLUMNS}"))?;
        tables.line(4, &format!("{VARIANT_COLUMNS}\t{MISSING_COLUMNS}"))?;
        tables.line(
            5,
            "#FID\tIID\tSID\tO(HOM)\tE(HOM)\tO(HET)\tE(HET)\tOBS_CT\tF",
        )?;
        tables.line(6, &format!("{VARIANT_COLUMNS}\t{HARDY_COLUMNS}\tMIDP"))?;
        tables.line(
            7,
            &format!("{VARIANT_COLUMNS}\t{HARDY_COLUMNS}\tNEG_LOG10_MIDP"),
        )?;
        Ok(tables)
    }

    fn line(&mut self, table: usize, line: &str) -> Result<()> {
        writeln!(self.outputs[table].file_mut(), "{line}")?;
        Ok(())
    }

    fn variant(&mut self, variant: &Variant, counts: &VariantTotals) -> Result<bool> {
        let identity = variant_identity(variant);
        self.line(
            0,
            &format!(
                "{identity}\t{}\t{}\t{}",
                dosage_count(counts.allele_units[0]),
                counts.allele_units[1..]
                    .iter()
                    .map(|&value| dosage_count(value))
                    .collect::<Vec<_>>()
                    .join(","),
                counts.allele_units.iter().sum::<u64>() / 32768
            ),
        )?;
        let k = variant.alleles.len();
        let two_alt =
            (1..k).flat_map(|hi| (1..=hi).map(move |lo| counts.diploid[tally::pair_index(lo, hi)]));
        self.line(
            1,
            &format!(
                "{identity}\t{}\t{}\t{}\t{}\t{}\t{}\t{}",
                counts.diploid[0],
                list((1..k).map(|alt| counts.diploid[tally::pair_index(0, alt)])),
                list(two_alt),
                counts.haploid[0],
                list(counts.haploid[1..].iter().copied()),
                counts.genotype_missing,
                counts.genotype_observations
            ),
        )?;
        self.line(
            4,
            &format!("{identity}\t{}", missing_fields(counts.missing)),
        )?;
        if variant.chromosome.is_autosome() && k == 2 {
            let [hom_ref, het, hom_alt] = counts.hwe_counts;
            let n = hom_ref + het + hom_alt;
            let observed = het as f64 / n as f64;
            let expected = if hom_ref == n {
                0.0
            } else {
                let twice_ref = (2 * hom_ref + het) as f64 / n as f64;
                twice_ref * (1.0 - twice_ref * 0.5)
            };
            let fields = format!(
                "{identity}\t{}\t{}\t{hom_ref}\t{het}\t{hom_alt}\t{}\t{}",
                variant.alleles[0],
                variant.alleles[1],
                float(observed),
                float(expected)
            );
            let logp = hwe::midp_log(hom_ref, het, hom_alt);
            self.line(6, &format!("{fields}\t{}", probability(logp)))?;
            self.line(
                7,
                &format!("{fields}\t{}", float(-logp / std::f64::consts::LN_10)),
            )?;
            Ok(true)
        } else {
            Ok(false)
        }
    }

    fn sample(
        &mut self,
        sample: &crate::dataset::metadata::Sample,
        total: &SampleTotals,
    ) -> Result<()> {
        let identity = format!("{}\t{}\t{}", sample.fid, sample.iid, sample.sid);
        let sex = match sample.sex {
            Sex::Male => "1",
            Sex::Female => "2",
            Sex::Unknown => "NA",
        };
        self.line(
            2,
            &format!(
                "{identity}\t{sex}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}",
                total.hom_ref,
                total.hom_alt,
                total.het_ref_alt + total.het_two_alt,
                total.het_ref_alt,
                total.het_two_alt,
                total.hap_ref,
                total.hap_alt,
                total.missing_calls
            ),
        )?;
        self.line(3, &format!("{identity}\t{}", missing_fields(total.missing)))?;
        self.line(
            5,
            &format!(
                "{identity}\t{}\t{}\t{}\t{}\t{}\t{}",
                total.het_observations - total.observed_het,
                float(total.het_observations as f64 - total.expected_het),
                total.observed_het,
                float(total.expected_het),
                total.het_observations,
                float(1.0 - total.observed_het as f64 / total.expected_het)
            ),
        )?;
        Ok(())
    }
}

pub(crate) fn run(config: &StatsConfig, execution: &Execution) -> Result<QcReport> {
    let dataset = Dataset::open(
        InputSpec::Pgen(config.pgen.clone()),
        ImportProfile::default(),
    )?;
    let (samples, variants) = make::select(&dataset, &config.selection)?;
    let persistent = dataset.metadata.samples.len() * size_of::<usize>()
        + samples.len() * (size_of::<usize>() + size_of::<SampleTotals>())
        + variants.len() * size_of::<usize>()
        + 65536;
    if metadata_bytes(&dataset.metadata).saturating_add(persistent) >= execution.memory_bytes {
        return Err(invalid(
            "QC metadata and sample state exceed invocation memory budget",
        ));
    }
    let positions = sample_positions(dataset.metadata.samples.len(), &samples);
    let mut totals = vec![SampleTotals::default(); samples.len()];
    let mut tables = Tables::open(config)?;
    let mut hwe_variants = 0;
    let mut effective_worker_limit = 1;
    let width = visit_batches(&dataset, &variants, persistent, execution, |batch| {
        effective_worker_limit =
            effective_worker_limit.max(batch.len().min(execution.requested_workers));
        let counts = execution.pool.install(|| {
            batch
                .par_iter()
                .map(|(index, value)| {
                    tally::variant(
                        value,
                        &dataset.metadata.variants[*index],
                        &dataset.metadata,
                        &positions,
                    )
                })
                .collect::<Vec<_>>()
        });
        for ((index, value), count) in batch.iter().zip(&counts) {
            let variant = &dataset.metadata.variants[*index];
            tally::add_samples(
                value,
                variant,
                &dataset.metadata,
                &positions,
                count,
                &mut totals,
            );
            hwe_variants += usize::from(tables.variant(variant, count)?);
        }
        Ok(())
    })?;
    for (&index, total) in samples.iter().zip(&totals) {
        tables.sample(&dataset.metadata.samples[index], total)?;
    }
    AtomicFile::commit_all(tables.outputs)?;
    Ok(QcReport {
        samples: samples.len(),
        variants: variants.len(),
        founders: samples
            .iter()
            .filter(|&&i| dataset.metadata.samples[i].founder())
            .count(),
        hwe_variants,
        hwe_scope: "autosome-biallelic-founders-midp",
        requested_workers: execution.requested_workers,
        effective_worker_limit,
        writer_workers: 1,
        batch_variants: width,
        memory_budget_bytes: execution.memory_bytes,
        output_prefix: config.out.clone(),
        files: EXTENSIONS
            .iter()
            .map(|suffix| sibling(&config.out, suffix))
            .collect(),
    })
}
