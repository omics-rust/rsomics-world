use crate::dataset::{Dataset, metadata::Sex, policy::SMALL_EPSILON};
use crate::execution::Execution;
use crate::stats::{self, tally};
use crate::{Result, invalid};
use rayon::prelude::*;
use std::mem::size_of;

#[derive(Default, Clone, Debug)]
pub(crate) struct FilterThresholds {
    pub mind: Option<f64>,
    pub geno: Option<f64>,
    pub hwe_midp: Option<f64>,
    pub maf: Option<f64>,
}

impl FilterThresholds {
    fn validate(&self) -> Result<()> {
        for (name, value) in [
            ("mind", self.mind),
            ("geno", self.geno),
            ("hwe-midp", self.hwe_midp),
            ("maf", self.maf),
        ] {
            if value.is_some_and(|threshold| {
                !threshold.is_finite() || !(0.0..=1.0).contains(&threshold)
            }) {
                return Err(invalid(format!(
                    "{name} threshold must be finite and in [0,1]"
                )));
            }
        }
        Ok(())
    }
}

fn missing_allowed(denominator: u64, threshold: f64) -> u64 {
    (denominator as f64 * (threshold * (1.0 + SMALL_EPSILON))) as u64
}

pub(crate) fn apply(
    dataset: &Dataset,
    mut samples: Vec<usize>,
    mut variants: Vec<usize>,
    thresholds: &FilterThresholds,
    execution: &Execution,
) -> Result<(Vec<usize>, Vec<usize>)> {
    thresholds.validate()?;
    if thresholds.mind.is_none()
        && thresholds.geno.is_none()
        && thresholds.hwe_midp.is_none()
        && thresholds.maf.is_none()
    {
        return Ok((samples, variants));
    }
    if thresholds.hwe_midp.is_some()
        && variants.iter().any(|&i| {
            let variant = &dataset.metadata.variants[i];
            !variant.chromosome.is_autosome() || variant.alleles.len() != 2
        })
    {
        return Err(invalid(
            "HWE filtering currently requires an explicit autosome/biallelic selection",
        ));
    }
    let persistent = (dataset.metadata.samples.len() + samples.len() + variants.len())
        * size_of::<usize>()
        + samples.len() * size_of::<u64>()
        + 65536;
    if stats::metadata_bytes(&dataset.metadata).saturating_add(persistent) >= execution.memory_bytes
    {
        return Err(invalid(
            "filter metadata and sample state exceed invocation memory budget",
        ));
    }
    let mut positions = stats::sample_positions(dataset.metadata.samples.len(), &samples);
    if let Some(threshold) = thresholds.mind {
        let mut missing = vec![0u64; samples.len()];
        stats::visit_batches(dataset, &variants, persistent, execution, |batch| {
            for (index, values) in batch {
                let variant = &dataset.metadata.variants[*index];
                for (index, call) in values.calls().enumerate() {
                    let position = positions[index];
                    if position != usize::MAX
                        && tally::missing_eligible(
                            &variant.chromosome,
                            &dataset.metadata.samples[index],
                        )
                    {
                        missing[position] += u64::from(call.alleles.is_none());
                    }
                }
            }
            Ok(())
        })?;
        let nony = variants
            .iter()
            .filter(|&&i| {
                !matches!(
                    dataset.metadata.variants[i].chromosome,
                    crate::dataset::chrom::Chromosome::Y
                )
            })
            .count();
        samples.retain(|&index| {
            let denominator = if dataset.metadata.samples[index].sex == Sex::Male {
                variants.len()
            } else {
                nony
            };
            missing[positions[index]] <= missing_allowed(denominator as u64, threshold)
        });
        if samples.is_empty() {
            return Err(invalid("mind filtering left no samples"));
        }
        positions.fill(usize::MAX);
        for (position, &index) in samples.iter().enumerate() {
            positions[index] = position;
        }
    }
    if thresholds.geno.is_some() || thresholds.hwe_midp.is_some() || thresholds.maf.is_some() {
        let mut retained = Vec::with_capacity(variants.len());
        stats::visit_batches(
            dataset,
            &variants,
            persistent + variants.len() * size_of::<usize>(),
            execution,
            |batch| {
                let decisions = execution.pool.install(|| {
                    batch
                        .par_iter()
                        .map(|(index, value)| {
                            let variant = &dataset.metadata.variants[*index];
                            let count =
                                tally::variant(value, variant, &dataset.metadata, &positions);
                            let geno_ok = thresholds.geno.is_none_or(|threshold| {
                                count.missing.hardcall
                                    <= missing_allowed(count.missing.observations, threshold)
                            });
                            let maf_ok = thresholds.maf.is_none_or(|threshold| {
                                count.nonmajor_frequency() >= threshold * (1.0 - SMALL_EPSILON)
                            });
                            let hwe_ok = thresholds.hwe_midp.is_none_or(|threshold| {
                                let [hom_ref, het, hom_alt] = count.hwe_counts;
                                hom_ref + het + hom_alt == 0
                                    || crate::stats::hwe::midp_log(hom_ref, het, hom_alt)
                                        >= threshold.ln() * (1.0 + SMALL_EPSILON)
                            });
                            (*index, geno_ok && maf_ok && hwe_ok)
                        })
                        .collect::<Vec<_>>()
                });
                retained.extend(
                    decisions
                        .into_iter()
                        .filter_map(|(index, keep)| keep.then_some(index)),
                );
                Ok(())
            },
        )?;
        variants = retained;
        if variants.is_empty() {
            return Err(invalid("variant filtering left no variants"));
        }
    }
    Ok((samples, variants))
}
