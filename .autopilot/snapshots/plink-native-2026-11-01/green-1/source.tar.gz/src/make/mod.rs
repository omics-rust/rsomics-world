use crate::dataset::{Dataset, ImportProfile, InputSpec, VariantId, metadata::Sample, sibling};
use crate::execution::Execution;
use crate::io::{
    pgen,
    transaction::{self, Manifest},
};
use crate::{Result, invalid};
use rsomics_common::{AtomicFile, reject_output_alias};
use serde::Serialize;
use std::{
    collections::{BTreeMap, HashSet},
    fs,
    mem::{size_of, size_of_val},
    path::{Path, PathBuf},
};

#[derive(Default, Clone, Debug)]
pub(crate) struct Selection {
    pub keep: Option<PathBuf>,
    pub remove: Option<PathBuf>,
    pub extract: Option<PathBuf>,
    pub exclude: Option<PathBuf>,
    pub autosome: bool,
    pub max_alleles: Option<usize>,
}
pub(crate) struct MakeConfig {
    pub input: InputSpec,
    pub profile: ImportProfile,
    pub selection: Selection,
    pub filters: filter::FilterThresholds,
    pub out: PathBuf,
}
#[derive(Serialize)]
pub(crate) struct GenerationReport {
    pub samples: usize,
    pub variants: usize,
    pub requested_workers: usize,
    pub writer_workers: usize,
    pub output_prefix: PathBuf,
}
fn selector_rows(path: &Path) -> Result<Vec<Vec<String>>> {
    Ok(fs::read_to_string(path)?
        .lines()
        .map(str::trim)
        .filter(|line| !line.is_empty() && !line.starts_with('#'))
        .map(|line| line.split_whitespace().map(str::to_owned).collect())
        .collect())
}
pub(crate) fn id_set(path: &Option<PathBuf>) -> Result<Option<HashSet<String>>> {
    path.as_ref()
        .map(|path| {
            selector_rows(path)?
                .into_iter()
                .map(|fields| {
                    if let [id] = fields.as_slice() {
                        Ok(id.clone())
                    } else {
                        Err(invalid("variant selector requires one ID per line"))
                    }
                })
                .collect()
        })
        .transpose()
}
struct SampleSelector {
    iid: HashSet<String>,
    pair: HashSet<(String, String)>,
    triple: HashSet<(String, String, String)>,
}
impl SampleSelector {
    fn read(path: &Option<PathBuf>) -> Result<Option<Self>> {
        path.as_ref()
            .map(|path| {
                let mut result = Self {
                    iid: HashSet::new(),
                    pair: HashSet::new(),
                    triple: HashSet::new(),
                };
                for fields in selector_rows(path)? {
                    match fields.as_slice() {
                        [iid] => {
                            result.iid.insert(iid.clone());
                        }
                        [fid, iid] => {
                            result.pair.insert((fid.clone(), iid.clone()));
                        }
                        [fid, iid, sid] => {
                            result
                                .triple
                                .insert((fid.clone(), iid.clone(), sid.clone()));
                        }
                        _ => {
                            return Err(invalid(
                                "sample selector requires IID, FID/IID or FID/IID/SID",
                            ));
                        }
                    }
                }
                Ok(result)
            })
            .transpose()
    }
    fn matches(&self, sample: &Sample) -> bool {
        self.iid.contains(&sample.iid)
            || self
                .pair
                .contains(&(sample.fid.clone(), sample.iid.clone()))
            || self
                .triple
                .contains(&(sample.fid.clone(), sample.iid.clone(), sample.sid.clone()))
    }
}
pub(crate) fn select(dataset: &Dataset, selection: &Selection) -> Result<(Vec<usize>, Vec<usize>)> {
    let keep = SampleSelector::read(&selection.keep)?;
    let remove = SampleSelector::read(&selection.remove)?;
    let extract = id_set(&selection.extract)?;
    let exclude = id_set(&selection.exclude)?;
    let samples = dataset
        .metadata
        .samples
        .iter()
        .enumerate()
        .filter(|(_, s)| {
            keep.as_ref().is_none_or(|set| set.matches(s))
                && !remove.as_ref().is_some_and(|set| set.matches(s))
        })
        .map(|(i, _)| i)
        .collect::<Vec<_>>();
    let variants = dataset
        .metadata
        .variants
        .iter()
        .enumerate()
        .filter(|(_, v)| {
            (!selection.autosome || v.chromosome.is_autosome())
                && selection
                    .max_alleles
                    .is_none_or(|max| v.alleles.len() <= max)
                && extract.as_ref().is_none_or(|set| set.contains(&v.id))
                && !exclude.as_ref().is_some_and(|set| set.contains(&v.id))
        })
        .map(|(i, _)| i)
        .collect::<Vec<_>>();
    if samples.is_empty() || variants.is_empty() {
        return Err(invalid("selection left no samples or variants"));
    }
    Ok((samples, variants))
}
fn input_paths(input: &InputSpec) -> Vec<PathBuf> {
    match input {
        InputSpec::Pgen(p) => ["pgen", "pgen.pgi", "pvar", "psam", "rsomics.json"]
            .map(|e| sibling(p, e))
            .to_vec(),
        InputSpec::Bed(p) => ["bed", "bim", "fam"].map(|e| sibling(p, e)).to_vec(),
        InputSpec::Vcf(p) => vec![p.clone()],
    }
}
pub(crate) fn run(config: &MakeConfig, execution: &Execution) -> Result<GenerationReport> {
    let dataset = Dataset::open(config.input.clone(), config.profile.clone())?;
    admit_memory(execution, crate::stats::metadata_bytes(&dataset.metadata))?;
    let (samples, variants) = select(&dataset, &config.selection)?;
    let (samples, variants) =
        filter::apply(&dataset, samples, variants, &config.filters, execution)?;
    materialize(&dataset, &samples, &variants, &config.out, execution)
}
fn admit_memory(execution: &Execution, bytes: usize) -> Result<()> {
    if bytes > execution.memory_bytes {
        return Err(invalid(format!(
            "make live workspace {bytes} exceeds invocation memory budget {}",
            execution.memory_bytes
        )));
    }
    Ok(())
}
struct MakeMemory {
    persistent: usize,
    transient: usize,
}
impl MakeMemory {
    fn new(dataset: &Dataset, samples: &[usize], variants: &[usize]) -> Self {
        let metadata = &dataset.metadata;
        let metadata_bytes = crate::stats::metadata_bytes(metadata);
        let largest_row = metadata
            .samples
            .iter()
            .map(|s| &s.fields)
            .chain(metadata.variants.iter().map(|v| &v.fields))
            .map(|fields| {
                size_of_val(fields.as_slice()) + fields.iter().map(String::capacity).sum::<usize>()
            })
            .max()
            .unwrap_or(0);
        let selectors = (metadata.samples.len() + metadata.variants.len()) * size_of::<usize>() * 2;
        let output_index = (variants.len() + 1) * size_of::<u64>() + variants.len();
        let codec_init = (metadata.variants.len() + 1) * size_of::<u64>()
            + metadata.variants.len().div_ceil(64) * size_of::<u64>()
            + variants.len().div_ceil(64) * size_of::<u64>();
        let reader_metadata = if matches!(dataset.source, InputSpec::Vcf(_)) {
            metadata_bytes
        } else {
            0
        };
        let persistent = metadata_bytes
            .saturating_add(selectors)
            .saturating_add(output_index)
            .saturating_add(codec_init)
            .saturating_add(reader_metadata)
            .saturating_add(256 * 1024);
        let packed = metadata.samples.len() * 128
            + samples.len() * (32 + size_of::<crate::dataset::genotypes::Call>())
            + 8192;
        Self {
            persistent,
            transient: packed.max(largest_row.saturating_mul(6)),
        }
    }
    fn with_codecs(&self, reader: usize, writer: usize) -> usize {
        self.persistent
            .saturating_add(self.transient)
            .saturating_add(reader)
            .saturating_add(writer)
    }
}
pub(crate) fn materialize(
    dataset: &Dataset,
    samples: &[usize],
    variants: &[usize],
    out: &Path,
    execution: &Execution,
) -> Result<GenerationReport> {
    if samples.is_empty() || variants.is_empty() {
        return Err(invalid("PGEN generation requires positive dimensions"));
    }
    let mut inputs = input_paths(&dataset.source);
    if let Some(psam) = &dataset.profile.psam {
        inputs.push(psam.clone());
    }
    for extension in ["pgen", "pvar", "psam", "rsomics.json"] {
        reject_output_alias(
            &sibling(out, extension),
            inputs.iter().map(PathBuf::as_path),
        )?;
    }
    let memory = MakeMemory::new(dataset, samples, variants);
    admit_memory(execution, memory.with_codecs(0, 0))?;
    let mut reader = dataset.reader()?;
    admit_memory(execution, memory.with_codecs(reader.workspace_bytes(), 0))?;
    let mut offsets = Vec::with_capacity(variants.len() + 1);
    offsets.push(0);
    let mut provisional = Vec::with_capacity(variants.len());
    let mut flags = 0;
    for &index in variants {
        let value = reader.read(VariantId(index))?;
        offsets.push(offsets.last().copied().unwrap_or(0) + value.allele_count as u64);
        provisional.push(value.provisional_ref);
        if value.phase_count() != 0 {
            flags |= 8;
        }
        if !value.dosages.is_empty() {
            flags |= 16;
        }
        if !value.dphase.is_empty() {
            flags |= 32;
        }
    }
    reader.close()?;
    let pgen_out = AtomicFile::new(sibling(out, "pgen"))?;
    let mut pvar_out = AtomicFile::new(sibling(out, "pvar"))?;
    let mut psam_out = AtomicFile::new(sibling(out, "psam"))?;
    let mut writer = pgen::Writer::open(
        pgen_out.temporary_path(),
        samples.len(),
        &offsets,
        &provisional,
        flags,
    )?;
    let mut reader = dataset.reader()?;
    admit_memory(
        execution,
        memory.with_codecs(reader.workspace_bytes(), writer.workspace_bytes()),
    )?;
    for (&index, &pr) in variants.iter().zip(&provisional) {
        let value = reader.read(VariantId(index))?.select(samples)?;
        if value.provisional_ref != pr {
            return Err(invalid("input reference state changed during make"));
        }
        writer.append(&value)?;
    }
    reader.close()?;
    writer.finish()?;
    dataset
        .metadata
        .write_variants(pvar_out.file_mut(), variants, &provisional)?;
    dataset
        .metadata
        .write_samples(psam_out.file_mut(), samples)?;
    let report = GenerationReport {
        samples: samples.len(),
        variants: variants.len(),
        requested_workers: execution.requested_workers,
        writer_workers: 1,
        output_prefix: out.into(),
    };
    transaction::commit(
        out,
        vec![pgen_out, pvar_out, psam_out],
        Manifest {
            schema: 1,
            source_profile: "PLINK2-v2.0.0-b.1.2-cc2c95e61c509d49aaf884d2ec0956a921770745".into(),
            samples: samples.len(),
            variants: variants.len(),
            requested_workers: execution.requested_workers,
            writer_workers: 1,
            files: BTreeMap::new(),
            projected_vcf_fields: if matches!(dataset.source, InputSpec::Vcf(_)) {
                vec!["Only GT and explicitly selected DS/HDS are projected; other FORMAT fields are discarded".into()]
            } else {
                Vec::new()
            },
        },
    )?;
    Ok(report)
}
pub(crate) mod filter;
