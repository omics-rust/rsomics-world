use crate::dataset::genotypes::Genotypes;
use std::mem::size_of;

pub(super) struct Founders {
    pub indices: Vec<usize>,
    pub mask: Vec<u64>,
}

pub(super) struct HardCalls {
    valid: Vec<u64>,
    one: Vec<u64>,
    two: Vec<u64>,
    moments: Moments,
}

impl HardCalls {
    pub fn new(raw: &Genotypes, founders: &Founders) -> Self {
        let words = founders.indices.len().div_ceil(64);
        let mut value = Self {
            valid: vec![0; words],
            one: vec![0; words],
            two: vec![0; words],
            moments: Moments::default(),
        };
        for (ordinal, &sample) in founders.indices.iter().enumerate() {
            let code = (raw.genotypes[sample / 32] >> (2 * (sample % 32))) & 3;
            if code == 3 {
                continue;
            }
            let bit = 1 << (ordinal % 64);
            let word = ordinal / 64;
            value.valid[word] |= bit;
            if code == 1 {
                value.one[word] |= bit;
            } else if code == 2 {
                value.two[word] |= bit;
            }
            value.moments.add(code, code);
        }
        value
    }

    pub fn bytes(&self) -> usize {
        (self.valid.len() + self.one.len() + self.two.len()) * size_of::<u64>()
    }

    pub fn constant(&self) -> bool {
        self.moments.variance_x() == 0
    }

    pub fn moments(&self, other: &Self) -> Moments {
        let mut result = Moments::default();
        for word in 0..self.valid.len() {
            let valid = self.valid[word] & other.valid[word];
            let x1 = self.one[word] & valid;
            let x2 = self.two[word] & valid;
            let y1 = other.one[word] & valid;
            let y2 = other.two[word] & valid;
            let nx1 = u64::from(x1.count_ones());
            let nx2 = u64::from(x2.count_ones());
            let ny1 = u64::from(y1.count_ones());
            let ny2 = u64::from(y2.count_ones());
            result.n += u64::from(valid.count_ones());
            result.x += nx1 + 2 * nx2;
            result.y += ny1 + 2 * ny2;
            result.xx += nx1 + 4 * nx2;
            result.yy += ny1 + 4 * ny2;
            result.xy += u64::from((x1 & y1).count_ones())
                + 2 * u64::from(((x1 & y2) | (x2 & y1)).count_ones())
                + 4 * u64::from((x2 & y2).count_ones());
        }
        result
    }
}

#[derive(Clone, Copy, Default, Debug)]
pub(super) struct Moments {
    pub n: u64,
    x: u64,
    y: u64,
    xx: u64,
    yy: u64,
    xy: u64,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub(super) enum Correlation {
    Defined(f64),
    NoOverlap,
    ZeroVariance,
}

impl Moments {
    fn add(&mut self, x: u64, y: u64) {
        self.n += 1;
        self.x += x;
        self.y += y;
        self.xx += x * x;
        self.yy += y * y;
        self.xy += x * y;
    }

    fn variance_x(self) -> u128 {
        u128::from(self.xx) * u128::from(self.n) - u128::from(self.x).pow(2)
    }

    fn components(self) -> (f64, f64, f64) {
        let vx = self.variance_x() as f64;
        let vy = (u128::from(self.yy) * u128::from(self.n) - u128::from(self.y).pow(2)) as f64;
        let covariance = (i128::from(self.xy) * i128::from(self.n)
            - i128::from(self.x) * i128::from(self.y)) as f64;
        (covariance, vx, vy)
    }

    pub fn correlation(self) -> Correlation {
        if self.n == 0 {
            return Correlation::NoOverlap;
        }
        let (covariance, vx, vy) = self.components();
        if vx == 0.0 || vy == 0.0 {
            Correlation::ZeroVariance
        } else {
            Correlation::Defined(covariance * covariance / (vx * vy))
        }
    }

    pub fn exceeds(self, threshold: f64) -> bool {
        let (covariance, vx, vy) = self.components();
        covariance * covariance > threshold * vx * vy
    }
}

pub(super) fn dosage_moments(a: &Genotypes, b: &Genotypes, founders: &Founders) -> Moments {
    let mut moments = Moments::default();
    for (sample, (a, b)) in a.calls().zip(b.calls()).enumerate() {
        if founders.mask[sample / 64] & (1 << (sample % 64)) == 0 {
            continue;
        }
        let dosage = |call: crate::dataset::genotypes::Call| {
            call.dosage.map(u64::from).or_else(|| {
                call.alleles
                    .map(|[a, b]| (u64::from(a) + u64::from(b)) * 16_384)
            })
        };
        if let (Some(x), Some(y)) = (dosage(a), dosage(b)) {
            moments.add(x, y);
        }
    }
    moments
}

pub(super) fn major_frequency(raw: &Genotypes, founders: &Founders) -> (usize, f64) {
    let mut count = 0u64;
    let mut sum = 0u64;
    for (sample, call) in raw.calls().enumerate() {
        if founders.mask[sample / 64] & (1 << (sample % 64)) == 0 {
            continue;
        }
        if let Some(value) = call.dosage.map(u64::from).or_else(|| {
            call.alleles
                .map(|[a, b]| (u64::from(a) + u64::from(b)) * 16_384)
        }) {
            count += 1;
            sum += value;
        }
    }
    if count == 0 {
        return (0, 0.5);
    }
    let alt = sum as f64 / (count as f64 * 32_768.0);
    if alt > 0.5 { (1, alt) } else { (0, 1.0 - alt) }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::dataset::genotypes::Call;

    #[test]
    fn packed_pairwise_complete_and_dosage_override() {
        let calls = |values: &[Option<[u8; 2]>]| {
            Genotypes::from_calls(
                &values
                    .iter()
                    .map(|&alleles| Call {
                        alleles,
                        ..Call::default()
                    })
                    .collect::<Vec<_>>(),
                2,
                false,
            )
            .unwrap()
        };
        let founders = Founders {
            indices: vec![0, 1, 2],
            mask: vec![7],
        };
        let a = calls(&[Some([0, 0]), Some([0, 1]), Some([1, 1]), None]);
        let b = calls(&[Some([1, 1]), None, Some([0, 0]), Some([0, 1])]);
        let moments = HardCalls::new(&a, &founders).moments(&HardCalls::new(&b, &founders));
        assert_eq!(moments.n, 2);
        assert_eq!(moments.correlation(), Correlation::Defined(1.0));
        assert_eq!(
            dosage_moments(&a, &b, &founders).correlation(),
            moments.correlation()
        );
        let mut values = a.calls().collect::<Vec<_>>();
        values[0].dosage = Some(16_384);
        values[2].dosage = Some(16_384);
        let a = Genotypes::from_calls(&values, 2, false).unwrap();
        assert_eq!(
            dosage_moments(&a, &b, &founders).correlation(),
            Correlation::ZeroVariance
        );
    }
}
