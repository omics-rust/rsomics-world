use std::{env, fs, path::PathBuf, process::Command};

fn main() {
    let output = PathBuf::from(env::var_os("OUT_DIR").expect("Cargo OUT_DIR"));
    let canonical = output.canonicalize().expect("existing Cargo output");
    if let Some(root) = env::var_os("RSOMICS_GUARDED_TARGET_DIR") {
        let root = PathBuf::from(root)
            .canonicalize()
            .expect("guarded Cargo target");
        assert!(
            canonical.starts_with(root),
            "native output escaped guarded target"
        );
    } else if env::var("HOST").is_ok_and(|host| host.ends_with("apple-darwin"))
        && env::var_os("GITHUB_ACTIONS").is_none()
    {
        panic!("local macOS native compilation requires the external-disk guard");
    }
    let mut build = cc::Build::new();
    build
        .cpp(true)
        .std("c++17")
        .flag("-ffp-contract=off")
        .define("PGENLIB_NOPRINT", None)
        .define("NDEBUG", None)
        .include("native")
        .include("vendor/pgenlib/include")
        .file("native/pgen_shim.cc");
    for unit in [
        "plink2_base",
        "plink2_bits",
        "plink2_simd",
        "pgenlib_misc",
        "pgenlib_read",
        "pgenlib_write",
    ] {
        build.file(format!("vendor/pgenlib/include/{unit}.cc"));
    }
    let compiler = build.get_compiler();
    let version = Command::new(compiler.path())
        .arg("--version")
        .output()
        .expect("C++ compiler version");
    assert!(version.status.success());
    fs::write(
        output.join("compiler.txt"),
        format!(
            "{}\ncompiler={:?}\nargs={:?}\ntarget={}\n",
            String::from_utf8_lossy(&version.stdout),
            compiler.path(),
            compiler.args(),
            env::var("TARGET").expect("Cargo target")
        ),
    )
    .expect("compiler provenance");
    build.compile("rsomics_pgen_codec");
    println!("cargo:rerun-if-changed=native");
    println!("cargo:rerun-if-changed=vendor");
    println!("cargo:rerun-if-env-changed=RSOMICS_GUARDED_TARGET_DIR");
}
