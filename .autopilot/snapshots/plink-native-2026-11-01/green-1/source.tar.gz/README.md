# rsomics-plink

Private genotype preparation: one durable PGEN dataset, QC, dosage-aware
unphased LD and hardcall pruning. Rust owns metadata, import/filter policy,
statistics and execution. A pinned, private LGPL pgenlib C++ codec reads/writes
compressed PGEN; this is not an all-Rust codec.

```sh
rsomics-plink make --vcf cohort.vcf.gz --psam cohort.psam --out imported
rsomics-plink make --pfile imported --autosome --max-alleles 2 \
  --mind 0.125 --geno 0.125 --hwe 1e-6 --maf 0.05 --out filtered
rsomics-plink stats --pfile filtered --out filtered.qc
rsomics-plink ld pairs --pfile filtered --out filtered.ld
rsomics-plink ld prune --pfile filtered --window-bp 500000 --r2 0.2 --out filtered
rsomics-plink make --pfile filtered --extract filtered.prune.in --out pruned
rsomics-plink stats --pfile pruned --out pruned.qc
```

`--out` is a fileset prefix. `make` accepts one of `--vcf`, `--bfile`,
`--pfile`. Select DS/HDS explicitly with `--dosage ds`/`hds`; half-calls fail
unless `--half-call missing` is explicit. `--split-par b37` uses the pinned
inclusive GRCh37 endpoints. Sample identity is FID/IID/SID, with preserved
ordered metadata and distinct raw hardcall phase/dosage/dphase tracks.

Filtering applies selectors, then mind, then recomputed geno/founder HWE and
founder nonmajor MAF. Stats always reopens the durable dataset. Its counts,
missingness and heterozygosity have explicit report-specific populations;
Hardy is named autosome/biallelic/founder mid-p scope, not multiallelic/X HWE.
Pair LD uses dosages where present and at least50 founders unless explicitly
overridden; pruning uses hardcalls and emits lists only. Neither secretly
materializes a different dataset. Pruned output is a separate make operation.

`--threads`, `--memory-mib` and `--json` use the family CLI layer. Outputs use
ordinary-error-recoverable grouped transactions; multi-file crash-atomic
visibility is not claimed. Native generation manifests reject mixed files.
Make's memory admission includes live metadata and concurrent codec/processing
workspace; it is not an operating-system RSS cap.

The compatibility profile is PLINK2 v2.0.0-b.1.2 source
cc2c95e61c509d49aaf884d2ec0956a921770745. Malformed biallelic scalar DS values
with multiple elements fail explicitly, unlike the captured permissive source
diagnostic. Unsupported PGEN extensions, multiallelic dosage and polyploid GT
fail rather than silently discard state. BCF, association, PCA, scoring,
relatedness and phased LD are outside this private slice.

Compact six-lane native workflow evidence is not release, real-cohort speed or
four-platform acceptance. See IMPLEMENTATION.md, tests/COMPARISON.md and
LICENSES.md for the actual gates and component terms.
