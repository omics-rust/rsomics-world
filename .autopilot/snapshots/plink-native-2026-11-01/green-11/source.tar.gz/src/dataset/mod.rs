pub(crate) mod chrom;
pub(crate) mod genotypes;
pub(crate) mod metadata;
pub(crate) mod policy;

use crate::io::{bed, pgen, vcf};
use crate::{Result, invalid};
use metadata::Metadata;
use std::path::{Path, PathBuf};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct VariantId(pub usize);
#[derive(Clone, Debug)]
pub(crate) enum InputSpec {
    Pgen(PathBuf),
    Bed(PathBuf),
    Vcf(PathBuf),
}
#[derive(Clone, Copy, Debug, Default)]
pub(crate) enum DosageField {
    #[default]
    None,
    Ds,
    Hds,
}
#[derive(Clone, Debug, Default)]
pub(crate) struct ImportProfile {
    pub dosage: DosageField,
    pub half_call_missing: bool,
    pub split_par_b37: bool,
    pub psam: Option<PathBuf>,
}

pub(crate) struct Dataset {
    pub metadata: Metadata,
    source: Source,
    pub profile: ImportProfile,
}
enum Source {
    Pgen(PathBuf, Option<pgen::Prepared>),
    Bed(PathBuf),
    Vcf(PathBuf),
}

pub(crate) trait GenotypeReader {
    fn read(&mut self, variant: VariantId) -> Result<genotypes::Genotypes>;
    fn read_into(&mut self, variant: VariantId, value: &mut genotypes::Genotypes) -> Result<()> {
        *value = self.read(variant)?;
        Ok(())
    }
    fn track_flags(&self) -> Option<u32> {
        None
    }
    fn workspace_bytes(&self) -> usize;
    fn close(self: Box<Self>) -> Result<()>;
}

impl Dataset {
    #[cfg(test)]
    pub fn open(source: InputSpec, profile: ImportProfile) -> Result<Self> {
        Self::open_budgeted(source, profile, usize::MAX)
    }
    pub fn open_budgeted(source: InputSpec, profile: ImportProfile, budget: usize) -> Result<Self> {
        let mut metadata = match &source {
            InputSpec::Pgen(prefix) => {
                crate::io::transaction::verify(prefix)?;
                Metadata::read_pgen(prefix)?
            }
            InputSpec::Bed(prefix) => bed::metadata(prefix)?,
            InputSpec::Vcf(path) => vcf::metadata(path, &profile)?,
        };
        if metadata.samples.is_empty() || metadata.variants.is_empty() {
            return Err(invalid(
                "dataset requires positive sample and variant counts",
            ));
        }
        metadata.validate()?;
        let remaining = budget
            .checked_sub(metadata_bytes(&metadata))
            .ok_or_else(|| invalid("dataset metadata exceeds invocation memory budget"))?;
        let source = match source {
            InputSpec::Pgen(prefix) => {
                let prepared = pgen::Prepared::open(&prefix, &metadata, remaining)?;
                for (variant, &provisional) in metadata
                    .variants
                    .iter_mut()
                    .zip(prepared.resolved_reference())
                {
                    variant.provisional_ref = provisional;
                }
                Source::Pgen(prefix, Some(prepared))
            }
            InputSpec::Bed(prefix) => Source::Bed(prefix),
            InputSpec::Vcf(path) => Source::Vcf(path),
        };
        Ok(Self {
            metadata,
            source,
            profile,
        })
    }
    pub fn input_spec(&self) -> InputSpec {
        match &self.source {
            Source::Pgen(prefix, _) => InputSpec::Pgen(prefix.clone()),
            Source::Bed(prefix) => InputSpec::Bed(prefix.clone()),
            Source::Vcf(path) => InputSpec::Vcf(path.clone()),
        }
    }
    pub fn shared_bytes(&self) -> usize {
        match &self.source {
            Source::Pgen(_, Some(prepared)) => prepared.shared_bytes(),
            _ => 0,
        }
    }
    pub fn prepared_reader_bytes(&self) -> Option<usize> {
        match &self.source {
            Source::Pgen(_, Some(prepared)) => Some(prepared.reader_bytes()),
            _ => None,
        }
    }
    pub fn close(&mut self) -> Result<()> {
        if let Source::Pgen(_, prepared) = &mut self.source
            && let Some(mut prepared) = prepared.take()
        {
            prepared.close()?;
        }
        Ok(())
    }
    pub fn reader(&self) -> Result<Box<dyn GenotypeReader + '_>> {
        match &self.source {
            Source::Pgen(_, prepared) => Ok(Box::new(
                prepared
                    .as_ref()
                    .ok_or_else(|| invalid("PGEN source closed"))?
                    .reader()?,
            )),
            Source::Bed(prefix) => Ok(Box::new(bed::Reader::open(prefix, &self.metadata)?)),
            Source::Vcf(path) => Ok(Box::new(vcf::Reader::open(
                path,
                &self.profile,
                &self.metadata,
            )?)),
        }
    }
}

pub(crate) fn metadata_bytes(metadata: &Metadata) -> usize {
    use std::mem::size_of;
    fn strings(values: &Vec<String>) -> usize {
        values.capacity() * size_of::<String>() + values.iter().map(String::capacity).sum::<usize>()
    }
    let mut bytes = size_of::<Metadata>()
        + metadata.samples.capacity() * size_of::<metadata::Sample>()
        + metadata.variants.capacity() * size_of::<metadata::Variant>();
    for values in [
        &metadata.sample_header,
        &metadata.variant_header,
        &metadata.sample_preamble,
        &metadata.variant_preamble,
    ] {
        bytes += strings(values);
    }
    let mut arenas = metadata::text::Arenas::default();
    for sample in &metadata.samples {
        bytes += sample.fields.account(&mut arenas);
        bytes += [
            &sample.fid,
            &sample.iid,
            &sample.sid,
            &sample.paternal,
            &sample.maternal,
        ]
        .iter()
        .map(|value| value.account(&mut arenas))
        .sum::<usize>();
    }
    for variant in &metadata.variants {
        bytes += variant.fields.account(&mut arenas) + variant.id.account(&mut arenas);
        bytes += variant.alleles.capacity() * size_of::<metadata::text::Text>();
        bytes += variant
            .alleles
            .iter()
            .map(|value| value.account(&mut arenas))
            .sum::<usize>();
        if let chrom::Chromosome::Other(value) = &variant.chromosome {
            bytes += value.capacity();
        }
    }
    bytes
}

pub(crate) fn variant_owned_bytes(variants: &Vec<metadata::Variant>) -> usize {
    // Reader clones share arenas already charged to the dataset, but own these containers.
    variants.capacity() * std::mem::size_of::<metadata::Variant>()
        + variants
            .iter()
            .map(|variant| {
                variant.alleles.capacity() * std::mem::size_of::<metadata::text::Text>()
                    + match &variant.chromosome {
                        chrom::Chromosome::Other(value) => value.capacity(),
                        _ => 0,
                    }
            })
            .sum::<usize>()
}

pub(crate) fn sibling(prefix: &Path, extension: &str) -> PathBuf {
    let mut path = prefix.as_os_str().to_os_string();
    path.push(".");
    path.push(extension);
    PathBuf::from(path)
}
