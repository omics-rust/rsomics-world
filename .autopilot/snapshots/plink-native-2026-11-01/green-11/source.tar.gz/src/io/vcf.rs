use crate::dataset::{
    DosageField, GenotypeReader, ImportProfile, VariantId,
    chrom::Chromosome,
    genotypes::{Call, Genotypes},
    metadata::{
        self, Metadata, Variant,
        text::{Fields, RowsBuilder},
    },
};
use crate::{Result, invalid};
use noodles_vcf as vcf;
use std::{
    io::BufRead,
    path::{Path, PathBuf},
};
use vcf::variant::io::Write as _;

type VcfReader = vcf::io::Reader<Box<dyn BufRead>>;
fn open(path: &Path) -> Result<(VcfReader, vcf::Header)> {
    let mut reader = vcf::io::reader::Builder::default().build_from_path(path)?;
    let header = reader.read_header()?;
    Ok((reader, header))
}
fn variant_fields(
    record: &vcf::Record,
    header: &vcf::Header,
    profile: &ImportProfile,
    rows: &mut RowsBuilder,
) -> Result<()> {
    let mut writer = vcf::io::Writer::new(Vec::new());
    writer.write_variant_record(header, record)?;
    let line =
        String::from_utf8(writer.into_inner()).map_err(|_| invalid("non UTF-8 VCF metadata"))?;
    let mut fields = line.trim_end().split('\t').take(8).collect::<Vec<_>>();
    if fields.len() != 8 {
        return Err(invalid("VCF requires eight site fields"));
    }
    let position = record
        .variant_start()
        .transpose()?
        .map(usize::from)
        .ok_or_else(|| invalid("missing VCF position"))? as u64;
    let chromosome = Chromosome::parse(record.reference_sequence_name());
    if profile.split_par_b37 {
        if matches!(chromosome, Chromosome::Par1 | Chromosome::Par2) {
            return Err(invalid("split-PAR input is already split"));
        }
        if let Some(name) = chromosome.split_b37(position) {
            fields[0] = name;
        }
    }
    rows.push_row(fields);
    Ok(())
}
fn variant(fields: Fields) -> Result<Variant> {
    let mut alleles = vec![fields.text(3).expect("VCF site width validated")];
    alleles.extend(fields.text(4).expect("VCF site width validated").split(','));
    let provisional_ref = fields[7].split(';').any(|s| s == "PR");
    Ok(Variant {
        chromosome: Chromosome::parse(&fields[0]),
        position: fields[1]
            .parse()
            .map_err(|_| invalid("invalid VCF position"))?,
        id: fields.text(2).expect("VCF site width validated"),
        alleles,
        provisional_ref,
        fields,
    })
}
pub(crate) fn metadata(path: &Path, profile: &ImportProfile) -> Result<Metadata> {
    let (mut reader, header) = open(path)?;
    let names = header
        .sample_names()
        .iter()
        .map(String::as_str)
        .collect::<Vec<_>>();
    let (sample_preamble, sample_header, samples) = if let Some(psam) = &profile.psam {
        let data = metadata::read_samples(psam)?;
        if data.2.iter().map(|s| s.iid.as_str()).collect::<Vec<_>>() != names {
            return Err(invalid("VCF/PSAM sample order or identity mismatch"));
        }
        data
    } else {
        let sample_header = ["IID", "SEX"].map(str::to_owned).to_vec();
        let mut rows = RowsBuilder::default();
        for name in &names {
            rows.push_row([*name, "NA"]);
        }
        let samples = metadata::samples(&sample_header, rows.finish())?;
        (Vec::new(), sample_header, samples)
    };
    let mut writer = vcf::io::Writer::new(Vec::new());
    writer.write_header(&header)?;
    let preamble = String::from_utf8(writer.into_inner())
        .map_err(|_| invalid("non UTF-8 VCF header"))?
        .lines()
        .filter(|line| line.starts_with("##") && !line.starts_with("##FORMAT="))
        .map(str::to_owned)
        .collect();
    let mut record = vcf::Record::default();
    let mut rows = RowsBuilder::default();
    while reader.read_record(&mut record)? != 0 {
        variant_fields(&record, &header, profile, &mut rows)?;
    }
    let variants = rows
        .finish()
        .into_iter()
        .map(variant)
        .collect::<Result<Vec<_>>>()?;
    Ok(Metadata {
        sample_preamble,
        sample_header,
        samples,
        variant_preamble: preamble,
        variant_header: ["CHROM", "POS", "ID", "REF", "ALT", "QUAL", "FILTER", "INFO"]
            .map(str::to_owned)
            .to_vec(),
        variants,
    })
}
pub(crate) struct Reader {
    path: PathBuf,
    reader: VcfReader,
    header: vcf::Header,
    profile: ImportProfile,
    next: usize,
    samples: usize,
    variants: Vec<Variant>,
}
impl Reader {
    pub fn open(path: &Path, profile: &ImportProfile, metadata: &Metadata) -> Result<Self> {
        let (reader, header) = open(path)?;
        Ok(Self {
            path: path.into(),
            reader,
            header,
            profile: profile.clone(),
            next: 0,
            samples: metadata.samples.len(),
            variants: metadata.variants.clone(),
        })
    }
}
impl GenotypeReader for Reader {
    fn read(&mut self, id: VariantId) -> Result<Genotypes> {
        if id.0 >= self.variants.len() {
            return Err(invalid("VCF variant index out of range"));
        }
        if id.0 < self.next {
            let (reader, header) = open(&self.path)?;
            self.reader = reader;
            self.header = header;
            self.next = 0;
        }
        let mut record = vcf::Record::default();
        while self.next <= id.0 {
            if self.reader.read_record(&mut record)? == 0 {
                return Err(invalid("VCF changed/truncated after metadata scan"));
            }
            self.next += 1;
        }
        let metadata = &self.variants[id.0];
        let mut rows = RowsBuilder::default();
        variant_fields(&record, &self.header, &self.profile, &mut rows)?;
        let current = variant(rows.finish().pop().expect("one VCF row supplied"))?;
        if current.fields != metadata.fields {
            return Err(invalid("VCF metadata changed between passes"));
        }
        let data = record.samples();
        let text = data.as_ref();
        let mut columns = text.split('\t');
        let keys = columns
            .next()
            .ok_or_else(|| invalid("missing VCF FORMAT"))?
            .split(':')
            .collect::<Vec<_>>();
        let mut unique = std::collections::HashSet::new();
        if keys.iter().any(|key| !unique.insert(*key)) {
            return Err(invalid("duplicate VCF FORMAT field"));
        }
        let gt = keys.iter().position(|k| *k == "GT");
        let ds = keys.iter().position(|k| *k == "DS");
        let hds = keys.iter().position(|k| *k == "HDS");
        let mut calls = Vec::with_capacity(self.samples);
        for text in columns {
            let fields = text.split(':').collect::<Vec<_>>();
            if fields.len() > keys.len() {
                return Err(invalid("VCF sample has extra FORMAT values"));
            }
            let value = |index: Option<usize>| {
                index
                    .and_then(|i| fields.get(i).copied())
                    .filter(|v| *v != ".")
            };
            let mut call = Call::default();
            let mut haploid = false;
            if let Some(text) = value(gt) {
                use vcf::variant::record::samples::series::value::genotype::Phasing;
                use vcf::variant::record_buf::samples::sample::value::Genotype;
                let genotype = text
                    .parse::<Genotype>()
                    .map_err(|e| invalid(format!("invalid GT: {e}")))?;
                let alleles = genotype.as_ref();
                if !(1..=2).contains(&alleles.len()) {
                    return Err(invalid("polyploid GT is outside this profile"));
                }
                haploid = alleles.len() == 1;
                let mut positions = alleles.iter().map(|a| a.position()).collect::<Vec<_>>();
                if positions
                    .iter()
                    .flatten()
                    .any(|&a| a >= metadata.alleles.len())
                {
                    return Err(invalid("GT allele exceeds ALT cardinality"));
                }
                if positions.iter().any(Option::is_none)
                    && positions.iter().any(Option::is_some)
                    && !self.profile.half_call_missing
                {
                    return Err(invalid("VCF half-call requires --half-call missing"));
                }
                if haploid {
                    positions.push(positions[0]);
                }
                if let [Some(a), Some(b)] = positions.as_slice() {
                    call.alleles = Some([(*a).min(*b) as u8, (*a).max(*b) as u8]);
                    call.phase =
                        a != b && alleles.len() == 2 && alleles[1].phasing() == Phasing::Phased;
                    call.reversed = call.phase && a > b;
                }
            }
            let selected_ds = if matches!(self.profile.dosage, DosageField::None) {
                None
            } else {
                value(ds)
            };
            let selected_hds = if matches!(self.profile.dosage, DosageField::Hds) {
                value(hds).filter(|text| *text != ".,.")
            } else {
                None
            };
            if metadata.alleles.len() > 2 && (selected_ds.is_some() || selected_hds.is_some()) {
                return Err(invalid("multiallelic dosage is outside this profile"));
            }
            let parsed = if let Some(text) = selected_hds {
                let values = text
                    .split(',')
                    .map(|token| finite(token, 1.0))
                    .collect::<Result<Vec<_>>>()?;
                match values.as_slice() {
                    [a] => Some((((a * 32768.0) + 0.5) as i32, Some(0))),
                    [a, b] => Some((
                        ((a + b) * 16384.0 + 0.5) as i32,
                        Some(((1.0 + a - b) * 16384.0 + 0.5) as i32 - 16384),
                    )),
                    _ => return Err(invalid("HDS must have one or two complete values")),
                }
            } else if let Some(text) = selected_ds {
                if text.contains(',') {
                    return Err(invalid("biallelic DS requires one scalar value"));
                }
                let dosage = finite(text, if haploid { 1.0 } else { 2.0 })?;
                Some((
                    (dosage * if haploid { 32768.0 } else { 16384.0 } + 0.5) as i32,
                    None,
                ))
            } else {
                None
            };
            if let Some((dose, phase)) = parsed {
                call = dosage_call(call, dose, phase);
            }
            calls.push(call);
        }
        if calls.len() != self.samples {
            return Err(invalid("VCF sample count does not match header"));
        }
        Genotypes::from_calls(&calls, metadata.alleles.len(), metadata.provisional_ref)
    }
    fn workspace_bytes(&self) -> usize {
        crate::dataset::variant_owned_bytes(&self.variants) + 64 * 1024
    }
    fn close(self: Box<Self>) -> Result<()> {
        Ok(())
    }
}
fn finite(text: &str, max: f64) -> Result<f64> {
    let value = text
        .parse::<f64>()
        .map_err(|_| invalid("invalid dosage number"))?;
    if !value.is_finite() || value < 0.0 || value > max {
        return Err(invalid("dosage outside its finite range"));
    }
    Ok(value)
}
fn dosage_call(mut call: Call, dose: i32, phase: Option<i32>) -> Call {
    let nearest = (dose + 8192) / 16384;
    let hard = if ((dose % 16384) - 8192).abs() >= 6554 {
        Some(match nearest {
            0 => [0, 0],
            1 => [0, 1],
            _ => [1, 1],
        })
    } else {
        None
    };
    if let Some(delta) = phase {
        let retain = (dose + delta - 16384).abs() < 16384 || (dose - delta - 16384).abs() < 16384;
        call = Call {
            alleles: hard,
            ..Call::default()
        };
        if retain {
            call.dosage = Some(dose as u16);
            call.dphase = (delta != 0).then_some(delta as i16);
        }
        if hard == Some([0, 1]) && delta.abs() > 8192 {
            call.phase = true;
            call.reversed = delta > 0;
            if delta.abs() == dose || delta.abs() + dose == 32768 {
                call.dphase = None;
            }
        }
    } else {
        let previous = call.alleles;
        call.alleles = hard;
        if dose % 16384 != 0 {
            call.dosage = Some(dose as u16);
        }
        if call.phase && hard != Some([0, 1]) {
            if call.dosage.is_some() && previous != hard {
                let delta = dose.min(32768 - dose);
                call.dphase = Some(if call.reversed { delta } else { -delta } as i16);
            }
            call.phase = false;
            call.reversed = false;
        }
    }
    call
}
