mod moments;
mod pairs;
mod prepared;
mod prune;

pub(crate) use pairs::{PairConfig, PairReport, pairs};
pub(crate) use prune::{PruneConfig, PruneReport, PruneWindow, prune};

use crate::dataset::genotypes::Genotypes;
use crate::dataset::{Dataset, GenotypeReader, ImportProfile, InputSpec, VariantId, sibling};
use crate::execution::Execution;
use crate::make::{self, Selection};
use crate::{Result, invalid};
use moments::{Founders, HardCallKernel, HardCalls};
use rsomics_common::reject_output_alias;
use std::collections::{HashMap, VecDeque};
use std::mem::size_of;
use std::ops::Range;
use std::path::{Path, PathBuf};

const IO_BYTES: usize = 196_608;
#[cfg(test)]
thread_local! {
    pub(crate) static CACHE_EVICTIONS: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
    pub(crate) static DECODE_COUNTER: std::cell::RefCell<Option<std::sync::Arc<std::sync::atomic::AtomicUsize>>> = const { std::cell::RefCell::new(None) };
}

struct Prepared {
    dataset: Dataset,
    variants: Vec<usize>,
    founders: Founders,
    selected_samples: usize,
    chromosomes: Vec<Range<usize>>,
    #[cfg(test)]
    decodes: Option<std::sync::Arc<std::sync::atomic::AtomicUsize>>,
}

impl Prepared {
    fn open(
        prefix: &Path,
        selection: &Selection,
        minimum_founders: usize,
        execution: &Execution,
    ) -> Result<Self> {
        let dataset = Dataset::open_budgeted(
            InputSpec::Pgen(prefix.to_owned()),
            ImportProfile::default(),
            execution.memory_bytes,
        )?;
        let (samples, variants) = make::select(&dataset, selection)?;
        let indices: Vec<_> = samples
            .iter()
            .copied()
            .filter(|&i| dataset.metadata.samples[i].founder())
            .collect();
        if indices.len() < minimum_founders {
            return Err(invalid(format!(
                "LD requires at least {minimum_founders} selected founders; found {}",
                indices.len()
            )));
        }
        let mut mask = vec![0; dataset.metadata.samples.len().div_ceil(64)];
        for &index in &indices {
            mask[index / 64] |= 1 << (index % 64);
        }
        let mut chromosomes = Vec::new();
        let mut start = 0;
        for (ordinal, &index) in variants.iter().enumerate() {
            let variant = &dataset.metadata.variants[index];
            if !variant.chromosome.is_autosome() || variant.alleles.len() != 2 {
                return Err(invalid(format!(
                    "initial LD workflow requires autosomal biallelic variants; {} is not eligible (select --autosome --max-alleles 2)",
                    variant.id
                )));
            }
            if ordinal != 0 {
                let previous = &dataset.metadata.variants[variants[ordinal - 1]];
                if previous.chromosome == variant.chromosome {
                    if previous.position > variant.position {
                        return Err(invalid(
                            "LD requires variants in nondecreasing position order within each chromosome",
                        ));
                    }
                } else {
                    if chromosomes.iter().any(|range: &Range<usize>| {
                        dataset.metadata.variants[variants[range.start]].chromosome
                            == variant.chromosome
                    }) {
                        return Err(invalid(
                            "LD requires each chromosome to occupy one contiguous block",
                        ));
                    }
                    chromosomes.push(start..ordinal);
                    start = ordinal;
                }
            }
        }
        chromosomes.push(start..variants.len());
        Ok(Self {
            selected_samples: samples.len(),
            dataset,
            variants,
            founders: Founders { indices, mask },
            chromosomes,
            #[cfg(test)]
            decodes: DECODE_COUNTER.with(|value| value.borrow().clone()),
        })
    }

    fn indexed_bytes(&self) -> usize {
        crate::dataset::metadata_bytes(&self.dataset.metadata)
            + self.dataset.shared_bytes()
            + (self.variants.capacity() + self.founders.indices.capacity()) * size_of::<usize>()
            + self.founders.mask.capacity() * size_of::<u64>()
            + self.chromosomes.capacity() * size_of::<Range<usize>>()
    }
}

struct Resources {
    workers: usize,
    workspace: usize,
    variant_reserve: usize,
    cache_bytes: usize,
    resident_span: Option<usize>,
    kernel: HardCallKernel,
}

impl Resources {
    fn new_pairs(
        input: &Prepared,
        execution: &Execution,
        tasks: usize,
        additional_bytes: usize,
        live_span: usize,
        line_bytes: usize,
    ) -> Result<Self> {
        Self::build(
            input,
            execution,
            tasks,
            additional_bytes,
            live_span,
            Some(line_bytes),
        )
    }

    fn new(
        input: &Prepared,
        execution: &Execution,
        tasks: usize,
        additional_bytes: usize,
        live_span: usize,
    ) -> Result<Self> {
        Self::build(input, execution, tasks, additional_bytes, live_span, None)
    }

    fn build(
        input: &Prepared,
        execution: &Execution,
        tasks: usize,
        additional_bytes: usize,
        live_span: usize,
        output_line_bytes: Option<usize>,
    ) -> Result<Self> {
        let pair_output = output_line_bytes.is_some();
        let workspace = input
            .dataset
            .prepared_reader_bytes()
            .ok_or_else(|| invalid("LD requires a prepared PGEN source"))?;
        let variant_reserve = input
            .dataset
            .metadata
            .samples
            .len()
            .checked_mul(32)
            .and_then(|value| value.checked_add(8192))
            .and_then(|value| {
                let prefix = input
                    .variants
                    .iter()
                    .map(|&index| {
                        let variant = &input.dataset.metadata.variants[index];
                        variant.id.len()
                            + 2 * variant
                                .alleles
                                .iter()
                                .map(|value| value.len())
                                .sum::<usize>()
                            + 256
                    })
                    .max()
                    .unwrap_or(0);
                value.checked_add(prefix)
            })
            .ok_or_else(|| invalid("LD variant memory estimate overflow"))?;
        let indexed = input
            .indexed_bytes()
            .checked_add(additional_bytes)
            .and_then(|value| value.checked_add(IO_BYTES))
            .ok_or_else(|| invalid("LD index memory estimate overflow"))?;
        let available = execution
            .memory_bytes
            .checked_sub(indexed)
            .ok_or_else(|| invalid("LD metadata and indexes exceed the memory budget"))?;
        let worker_io = |workers| {
            if pair_output && workers > 1 {
                IO_BYTES + pairs::BLOCK_BYTES
            } else {
                IO_BYTES
            }
        };
        let minimum = workspace
            .checked_add(IO_BYTES)
            .and_then(|value| value.checked_add(3 * variant_reserve))
            .ok_or_else(|| invalid("LD worker memory estimate overflow"))?;
        let mut workers = execution
            .requested_workers
            .min(execution.pool.current_num_threads())
            .min(tasks.max(1))
            .min(available / minimum);
        if output_line_bytes.is_some_and(|bytes| bytes > pairs::BLOCK_BYTES) {
            workers = workers.min(1);
        }
        if workers == 0 {
            return Err(invalid(
                "LD memory budget cannot hold one reader and two packed variants",
            ));
        }
        let coordination = |workers| {
            if pair_output && workers > 1 {
                crate::ordered::memory_bytes::<pairs::Block, pairs::Counts>(workers)
            } else {
                0
            }
        };
        while workers > 1
            && (minimum + worker_io(workers) - IO_BYTES)
                .saturating_mul(workers)
                .saturating_add(coordination(workers))
                > available
        {
            workers -= 1;
        }
        let cache_bytes = (available - coordination(workers)) / workers
            - workspace
            - worker_io(workers)
            - variant_reserve;
        let resident_span = live_span
            .checked_mul(variant_reserve + size_of::<VariantData>())
            .filter(|&bytes| bytes <= cache_bytes)
            .map(|_| live_span);
        Ok(Self {
            workers,
            workspace,
            variant_reserve,
            cache_bytes,
            resident_span,
            kernel: HardCallKernel::detect(),
        })
    }
}

struct VariantData {
    raw: Genotypes,
    hard: HardCalls,
    major_frequency: f64,
    bytes: usize,
    pair_prefix: String,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct SelectedOrdinal(usize);

struct VariantCache<'a> {
    reader: Box<dyn GenotypeReader + 'a>,
    founders: &'a Founders,
    resources: &'a Resources,
    values: HashMap<usize, Box<VariantData>>,
    order: VecDeque<usize>,
    used: usize,
    metadata: &'a crate::dataset::metadata::Metadata,
    pair_output: bool,
    resident: VecDeque<VariantData>,
    start: SelectedOrdinal,
    variants: &'a [usize],
    #[cfg(test)]
    decodes: Option<std::sync::Arc<std::sync::atomic::AtomicUsize>>,
}

impl<'a> VariantCache<'a> {
    fn open(input: &'a Prepared, resources: &'a Resources, pair_output: bool) -> Result<Self> {
        let reader = input.dataset.reader()?;
        if reader.workspace_bytes() > resources.workspace {
            return Err(invalid("LD reader workspace exceeds preflight reservation"));
        }
        Ok(Self {
            reader,
            founders: &input.founders,
            resources,
            values: HashMap::new(),
            order: VecDeque::new(),
            used: 0,
            metadata: &input.dataset.metadata,
            pair_output,
            resident: VecDeque::with_capacity(resources.resident_span.unwrap_or(0)),
            start: SelectedOrdinal(0),
            variants: &input.variants,
            #[cfg(test)]
            decodes: input.decodes.clone(),
        })
    }

    fn ensure(&mut self, variant: usize, pinned: Option<usize>) -> Result<()> {
        if self.values.contains_key(&variant) {
            return Ok(());
        }
        while self.used + self.resources.variant_reserve > self.resources.cache_bytes {
            let old = self
                .order
                .pop_front()
                .ok_or_else(|| invalid("LD packed cache reservation exhausted"))?;
            if Some(old) == pinned {
                self.order.push_back(old);
                continue;
            }
            if let Some(value) = self.values.remove(&old) {
                #[cfg(test)]
                CACHE_EVICTIONS.with(|count| count.set(count.get() + 1));
                self.used -= value.bytes;
            }
        }
        let data = self.load(variant)?;
        self.used += data.bytes;
        self.values.insert(variant, Box::new(data));
        self.order.push_back(variant);
        Ok(())
    }

    fn load(&mut self, variant: usize) -> Result<VariantData> {
        let raw = self.reader.read(VariantId(variant))?;
        #[cfg(test)]
        if let Some(counter) = &self.decodes {
            counter.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        }
        let hard = HardCalls::new(&raw, self.founders);
        let (major, major_frequency) = moments::major_frequency(&raw, self.founders);
        let pair_prefix = if self.pair_output {
            pairs::variant_prefix(&self.metadata.variants[variant], major, major_frequency)?
        } else {
            String::new()
        };
        let bytes =
            raw.bytes() + hard.bytes() + size_of::<VariantData>() + pair_prefix.capacity() + 256;
        if bytes > self.resources.variant_reserve {
            return Err(invalid("LD packed variant exceeds reserved memory"));
        }
        Ok(VariantData {
            raw,
            hard,
            major_frequency,
            bytes,
            pair_prefix,
        })
    }

    fn get(&self, variant: usize) -> &VariantData {
        &self.values[&variant]
    }

    fn refill(&mut self, start: SelectedOrdinal, end: SelectedOrdinal) -> Result<()> {
        let capacity = self
            .resources
            .resident_span
            .ok_or_else(|| invalid("resident LD window not admitted"))?;
        if end.0 - start.0 > capacity {
            return Err(invalid("LD live span exceeds preflight reservation"));
        }
        if start.0 < self.start.0 || start.0 > self.start.0 + self.resident.len() {
            self.resident.clear();
            self.start = start;
        }
        while self.start.0 < start.0 {
            self.resident.pop_front();
            self.start.0 += 1;
        }
        while self.start.0 + self.resident.len() < end.0 {
            let index = self.variants[self.start.0 + self.resident.len()];
            let data = self.load(index)?;
            self.resident.push_back(data);
        }
        Ok(())
    }

    fn resident(&self, ordinal: SelectedOrdinal) -> &VariantData {
        &self.resident[ordinal.0 - self.start.0]
    }

    fn close(self) -> Result<()> {
        self.reader.close()
    }
}

fn output_parent(prefix: &Path) -> &Path {
    prefix
        .parent()
        .filter(|path| !path.as_os_str().is_empty())
        .unwrap_or_else(|| Path::new("."))
}

fn check_outputs(
    prefix: &Path,
    selection: &Selection,
    output: &Path,
    extensions: &[&str],
) -> Result<()> {
    let mut inputs: Vec<PathBuf> = ["pgen", "pvar", "psam", "rsomics.json"]
        .iter()
        .map(|extension| sibling(prefix, extension))
        .collect();
    inputs.extend(
        [
            &selection.keep,
            &selection.remove,
            &selection.extract,
            &selection.exclude,
        ]
        .into_iter()
        .filter_map(|path| path.clone()),
    );
    for extension in extensions {
        reject_output_alias(
            &sibling(output, extension),
            inputs.iter().map(PathBuf::as_path),
        )?;
    }
    Ok(())
}
