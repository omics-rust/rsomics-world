use super::moments::{self, Correlation};
use super::{Prepared, Resources, SelectedOrdinal, VariantCache, VariantData, check_outputs};
use crate::dataset::chrom::Chromosome;
use crate::dataset::metadata::Variant;
use crate::dataset::sibling;
use crate::execution::Execution;
use crate::make::Selection;
use crate::numeric::six_significant;
use crate::{Result, invalid};
use rsomics_common::AtomicFile;
use serde::Serialize;
use std::collections::BTreeSet;
use std::fmt::Write as _;
use std::io::{self, BufWriter, Write};
use std::mem::size_of;
use std::ops::Range;
use std::path::PathBuf;

#[derive(Clone, Debug)]
pub(crate) struct PairConfig {
    pub pfile: PathBuf,
    pub out: PathBuf,
    pub selection: Selection,
    pub window_variants: usize,
    pub window_bp: u64,
    pub min_r2: f64,
    pub allow_small_founders: bool,
}

impl Default for PairConfig {
    fn default() -> Self {
        Self {
            pfile: PathBuf::new(),
            out: PathBuf::new(),
            selection: Selection::default(),
            window_variants: 1_000_000,
            window_bp: 500_000,
            min_r2: -1.0,
            allow_small_founders: false,
        }
    }
}

#[derive(Default, Serialize)]
pub(crate) struct PairReport {
    pub selected_samples: usize,
    pub founders: usize,
    pub variants: usize,
    pub evaluated_pairs: u64,
    pub emitted_pairs: u64,
    pub no_overlap_pairs: u64,
    pub zero_variance_pairs: u64,
    pub requested_workers: usize,
    pub effective_workers: usize,
    pub writer_workers: usize,
}

struct Task {
    rows: Range<usize>,
    chromosome_end: usize,
    pairs: u64,
    first_pair: u64,
}

pub(super) struct PairRow {
    pub row: usize,
    pub end: usize,
    first_pair: u64,
}

struct Segment {
    first_pair: u64,
    end_pair: u64,
    first_job: usize,
}

struct Jobs {
    segments: Vec<Segment>,
    width: u64,
    count: usize,
}

impl Jobs {
    fn new(tasks: &[Task], partitions: &[Range<usize>], workers: usize, line_bytes: usize) -> Self {
        let total = tasks.iter().map(|task| task.pairs).sum::<u64>();
        let width = total
            .div_ceil(workers.saturating_mul(16).max(1) as u64)
            .clamp(16_384, 262_144)
            .min((BLOCK_BYTES / line_bytes.max(1)).max(1) as u64);
        let mut segments = Vec::with_capacity(partitions.len());
        let mut count = 0;
        for partition in partitions {
            let first_pair = tasks[partition.start].first_pair;
            let last = &tasks[partition.end - 1];
            let end_pair = last.first_pair + last.pairs;
            if end_pair != first_pair {
                segments.push(Segment {
                    first_pair,
                    end_pair,
                    first_job: count,
                });
                count += (end_pair - first_pair).div_ceil(width) as usize;
            }
        }
        Self {
            segments,
            width,
            count,
        }
    }

    fn pairs(&self, job: usize) -> Range<u64> {
        let index = self
            .segments
            .partition_point(|segment| segment.first_job <= job)
            - 1;
        let segment = &self.segments[index];
        let start = segment.first_pair + (job - segment.first_job) as u64 * self.width;
        start..(start + self.width).min(segment.end_pair)
    }
}

fn partitions(tasks: &[Task], workers: usize) -> Vec<Range<usize>> {
    let count = workers.saturating_mul(2).min(tasks.len());
    if count == 0 {
        return Vec::new();
    }
    let cost = tasks
        .iter()
        .map(|task| u128::from(task.pairs))
        .sum::<u128>();
    let weighted = cost != 0;
    let total = if weighted { cost } else { tasks.len() as u128 };
    let mut output = Vec::with_capacity(count);
    let mut cumulative = 0;
    let mut start = 0;
    for (index, task) in tasks.iter().enumerate() {
        cumulative += if weighted { u128::from(task.pairs) } else { 1 };
        let remaining = count - output.len() - 1;
        if remaining != 0
            && (cumulative >= total * (output.len() + 1) as u128 / count as u128
                || tasks.len() - index - 1 == remaining)
        {
            output.push(start..index + 1);
            start = index + 1;
        }
    }
    output.push(start..tasks.len());
    output
}

pub(super) const BLOCK_BYTES: usize = 4 * 1_048_576;

fn line_bytes(input: &Prepared) -> usize {
    // Six-significant text needs at most a sign, six digits, dot and e±DDD.
    const NUMBER_BYTES: usize = 13;
    let prefix = input
        .variants
        .iter()
        .map(|&index| {
            let variant = &input.dataset.metadata.variants[index];
            variant
                .id
                .len()
                .saturating_add(
                    variant
                        .alleles
                        .iter()
                        .map(|allele| allele.len())
                        .sum::<usize>()
                        .saturating_mul(2),
                )
                .saturating_add(2 + 20 + 8 + 1 + NUMBER_BYTES)
        })
        .max()
        .unwrap_or(0);
    prefix.saturating_mul(2).saturating_add(3 + NUMBER_BYTES)
}

#[derive(Default)]
pub(super) struct Counts {
    evaluated: u64,
    emitted: u64,
    no_overlap: u64,
    zero_variance: u64,
    worker: usize,
}

impl PairReport {
    fn add(&mut self, counts: &Counts) {
        self.evaluated_pairs += counts.evaluated;
        self.emitted_pairs += counts.emitted;
        self.no_overlap_pairs += counts.no_overlap;
        self.zero_variance_pairs += counts.zero_variance;
    }
}

pub(crate) fn pairs(config: &PairConfig, execution: &Execution) -> Result<PairReport> {
    if config.window_variants < 2 || !config.min_r2.is_finite() || config.min_r2 > 1.0 {
        return Err(invalid(
            "LD pair window must be at least 2 and minimum r2 must be finite and no greater than 1",
        ));
    }
    check_outputs(&config.pfile, &config.selection, &config.out, &["vcor"])?;
    let mut input = Prepared::open(
        &config.pfile,
        &config.selection,
        if config.allow_small_founders { 2 } else { 50 },
        execution,
    )?;
    let mut tasks = Vec::new();
    let mut rows = Vec::new();
    let mut total_pairs = 0;
    let mut live_span = 1;
    for chromosome in &input.chromosomes {
        let mut endpoint = chromosome.start;
        for start in (chromosome.start..chromosome.end.saturating_sub(1)).step_by(16) {
            let stop = (start + 16).min(chromosome.end - 1);
            let mut pairs = 0;
            let first_pair = total_pairs;
            for row in start..stop {
                endpoint = endpoint.max(row + 1);
                let end = row
                    .saturating_add(config.window_variants)
                    .min(chromosome.end);
                let a = &input.dataset.metadata.variants[input.variants[row]];
                while endpoint < end {
                    let b = &input.dataset.metadata.variants[input.variants[endpoint]];
                    if b.position - a.position > config.window_bp {
                        break;
                    }
                    endpoint += 1;
                }
                let count = (endpoint - row - 1) as u64;
                if count != 0 {
                    rows.push(PairRow {
                        row,
                        end: endpoint,
                        first_pair: total_pairs,
                    });
                }
                pairs += count;
                total_pairs += count;
                live_span = live_span.max(endpoint - row);
            }
            tasks.push(Task {
                rows: start..stop,
                chromosome_end: chromosome.end,
                pairs,
                first_pair,
            });
        }
    }
    let maximum_partitions = execution
        .requested_workers
        .min(execution.pool.current_num_threads())
        .saturating_mul(2)
        .min(tasks.len());
    let line_bytes = line_bytes(&input);
    let planner_bytes = tasks.capacity() * size_of::<Task>()
        + rows.capacity() * size_of::<PairRow>()
        + maximum_partitions * (size_of::<Range<usize>>() + size_of::<Segment>());
    let resources = Resources::new_pairs(
        &input,
        execution,
        tasks.len(),
        planner_bytes,
        live_span,
        line_bytes,
    )?;
    let shared =
        super::prepared::SharedPairs::prepare(&input, &resources, execution, &rows, planner_bytes)?;
    let partitions = partitions(&tasks, resources.workers);
    let jobs = Jobs::new(&tasks, &partitions, resources.workers, line_bytes);
    let mut output = AtomicFile::new(sibling(&config.out, "vcor"))?;
    let mut report = PairReport {
        selected_samples: input.selected_samples,
        founders: input.founders.indices.len(),
        variants: input.variants.len(),
        requested_workers: execution.requested_workers,
        writer_workers: 1,
        ..PairReport::default()
    };
    let mut workers = BTreeSet::new();
    {
        let mut writer = BufWriter::with_capacity(65_536, output.file_mut());
        writeln!(
            writer,
            "#CHROM_A\tPOS_A\tID_A\tREF_A\tALT_A\tPROVISIONAL_REF_A?\tMAJ_A\tNONMAJ_A\tNONMAJ_FREQ_A\tCHROM_B\tPOS_B\tID_B\tREF_B\tALT_B\tPROVISIONAL_REF_B?\tMAJ_B\tNONMAJ_B\tNONMAJ_FREQ_B\tUNPHASED_R2"
        )?;
        if let Some(shared) = &shared {
            if resources.workers == 1 {
                let count = calculate_shared(
                    shared,
                    resources.kernel,
                    config,
                    &rows,
                    0..total_pairs,
                    &mut writer,
                )?;
                report.add(&count);
                workers.insert(count.worker);
            } else {
                crate::ordered::run(
                    &execution.pool,
                    resources.workers,
                    jobs.count,
                    |_| Ok(()),
                    |_, job, recycled: Option<Block>| {
                        let mut block = recycled.unwrap_or_else(Block::new);
                        block.used = 0;
                        let counts = calculate_shared(
                            shared,
                            resources.kernel,
                            config,
                            &rows,
                            jobs.pairs(job),
                            &mut block,
                        )?;
                        Ok((block, counts))
                    },
                    |_| Ok(()),
                    crate::ordered::Consumer {
                        write: |_, block: &mut Block| {
                            writer.write_all(&block.bytes[..block.used])?;
                            Ok(())
                        },
                        complete: |count: Counts| {
                            report.add(&count);
                            workers.insert(count.worker);
                        },
                    },
                )?;
            }
        } else if resources.workers == 1 && total_pairs != 0 {
            let mut cache = VariantCache::open(&input, &resources, true)?;
            let counts = calculate(&input, &resources, config, &tasks, &mut cache, &mut writer);
            let closed = cache.close();
            let counts = counts?;
            closed?;
            report.add(&counts);
            workers.insert(counts.worker);
        } else if jobs.count != 0 {
            crate::ordered::run(
                &execution.pool,
                resources.workers,
                jobs.count,
                |_| VariantCache::open(&input, &resources, true),
                |cache, partition, recycled: Option<Block>| {
                    let mut block = recycled.unwrap_or_else(Block::new);
                    block.used = 0;
                    let counts = calculate_job(
                        &input,
                        &resources,
                        config,
                        &rows,
                        jobs.pairs(partition),
                        cache,
                        &mut block,
                    )?;
                    Ok((block, counts))
                },
                VariantCache::close,
                crate::ordered::Consumer {
                    write: |_, block: &mut Block| {
                        writer.write_all(&block.bytes[..block.used])?;
                        Ok(())
                    },
                    complete: |count: Counts| {
                        report.add(&count);
                        workers.insert(count.worker);
                    },
                },
            )?;
        }
        writer.flush()?;
    }
    report.effective_workers = workers.len();
    input.dataset.close()?;
    AtomicFile::commit_all(vec![output])?;
    Ok(report)
}

fn calculate(
    input: &Prepared,
    resources: &Resources,
    config: &PairConfig,
    tasks: &[Task],
    cache: &mut VariantCache<'_>,
    writer: &mut impl Write,
) -> Result<Counts> {
    let mut part = Counts {
        worker: rayon::current_thread_index().unwrap_or(0),
        ..Counts::default()
    };
    for task in tasks {
        let mut endpoint = task.rows.start;
        for row in task.rows.clone() {
            let a_index = input.variants[row];
            let a = &input.dataset.metadata.variants[a_index];
            let end = row
                .saturating_add(config.window_variants)
                .min(task.chromosome_end);
            endpoint = endpoint.max(row + 1);
            while endpoint < end {
                let b = &input.dataset.metadata.variants[input.variants[endpoint]];
                if b.position - a.position > config.window_bp {
                    break;
                }
                endpoint += 1;
            }
            if resources.resident_span.is_some() {
                cache.refill(SelectedOrdinal(row), SelectedOrdinal(endpoint))?;
                let (first, second) = cache.resident.as_slices();
                let (a_data, rest) = first
                    .split_first()
                    .ok_or_else(|| invalid("empty LD resident row"))?;
                for b_data in rest.iter().chain(second) {
                    emit(a_data, b_data, input, resources, config, writer, &mut part)?;
                }
            } else {
                cache.ensure(a_index, None)?;
                for &b_index in &input.variants[row + 1..endpoint] {
                    cache.ensure(b_index, Some(a_index))?;
                    let a_data = cache.get(a_index);
                    let b_data = cache.get(b_index);
                    emit(a_data, b_data, input, resources, config, writer, &mut part)?;
                }
            }
        }
    }
    Ok(part)
}

fn calculate_job(
    input: &Prepared,
    resources: &Resources,
    config: &PairConfig,
    rows: &[PairRow],
    pairs: Range<u64>,
    cache: &mut VariantCache<'_>,
    writer: &mut impl Write,
) -> Result<Counts> {
    let mut row_index = rows.partition_point(|row| row.first_pair <= pairs.start) - 1;
    let mut position = pairs.start;
    let mut part = Counts {
        worker: rayon::current_thread_index().unwrap_or(0),
        ..Counts::default()
    };
    while position < pairs.end {
        let row = &rows[row_index];
        let first = row.row + 1 + (position - row.first_pair) as usize;
        let end = row.end.min(first + (pairs.end - position) as usize);
        let a_index = input.variants[row.row];
        if resources.resident_span.is_some() {
            cache.refill(SelectedOrdinal(row.row), SelectedOrdinal(row.end))?;
            let a = cache.resident(SelectedOrdinal(row.row));
            for ordinal in first..end {
                let b = cache.resident(SelectedOrdinal(ordinal));
                emit(a, b, input, resources, config, writer, &mut part)?;
            }
        } else {
            cache.ensure(a_index, None)?;
            for &b_index in &input.variants[first..end] {
                cache.ensure(b_index, Some(a_index))?;
                emit(
                    cache.get(a_index),
                    cache.get(b_index),
                    input,
                    resources,
                    config,
                    writer,
                    &mut part,
                )?;
            }
        }
        position += (end - first) as u64;
        row_index += 1;
    }
    Ok(part)
}

fn calculate_shared(
    shared: &super::prepared::SharedPairs,
    kernel: moments::HardCallKernel,
    config: &PairConfig,
    rows: &[PairRow],
    pairs: Range<u64>,
    writer: &mut impl Write,
) -> Result<Counts> {
    let mut row_index = rows.partition_point(|row| row.first_pair <= pairs.start) - 1;
    let mut position = pairs.start;
    let mut counts = Counts {
        worker: rayon::current_thread_index().unwrap_or(0),
        ..Counts::default()
    };
    while position < pairs.end {
        let row = &rows[row_index];
        let first = row.row + 1 + (position - row.first_pair) as usize;
        let end = row.end.min(first + (pairs.end - position) as usize);
        for ordinal in first..end {
            let (moments, a, b) =
                shared.pair(SelectedOrdinal(row.row), SelectedOrdinal(ordinal), kernel);
            emit_values(moments, a, b, config, writer, &mut counts)?;
        }
        position += (end - first) as u64;
        row_index += 1;
    }
    Ok(counts)
}

pub(super) struct Block {
    bytes: Box<[u8]>,
    used: usize,
}

impl Block {
    fn new() -> Self {
        Self {
            bytes: vec![0; BLOCK_BYTES].into_boxed_slice(),
            used: 0,
        }
    }
}

impl Write for Block {
    fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
        if bytes.len() > self.bytes.len() - self.used {
            return Err(io::Error::other(
                "LD complete result exceeds admitted output bytes",
            ));
        }
        self.bytes[self.used..self.used + bytes.len()].copy_from_slice(bytes);
        self.used += bytes.len();
        Ok(bytes.len())
    }

    fn flush(&mut self) -> io::Result<()> {
        Ok(())
    }
}

fn emit(
    a_data: &VariantData,
    b_data: &VariantData,
    input: &Prepared,
    resources: &Resources,
    config: &PairConfig,
    writer: &mut impl Write,
    part: &mut Counts,
) -> Result<()> {
    let moments = if a_data.raw.dosages.is_empty() && b_data.raw.dosages.is_empty() {
        resources.kernel.moments(&a_data.hard, &b_data.hard)
    } else {
        moments::dosage_moments(&a_data.raw, &b_data.raw, &input.founders)
    };
    emit_values(
        moments,
        a_data.pair_prefix.as_bytes(),
        b_data.pair_prefix.as_bytes(),
        config,
        writer,
        part,
    )
}

fn emit_values(
    moments: moments::Moments,
    a: &[u8],
    b: &[u8],
    config: &PairConfig,
    writer: &mut impl Write,
    part: &mut Counts,
) -> Result<()> {
    part.evaluated += 1;
    let value = match moments.correlation() {
        Correlation::Defined(value) => Some(value),
        Correlation::NoOverlap => {
            part.no_overlap += 1;
            None
        }
        Correlation::ZeroVariance => {
            part.zero_variance += 1;
            None
        }
    };
    if config.min_r2 >= 0.0 && value.is_none_or(|value| value < config.min_r2) {
        return Ok(());
    }
    writer.write_all(a)?;
    write!(writer, "\t")?;
    writer.write_all(b)?;
    writeln!(
        writer,
        "\t{}",
        value
            .map(six_significant)
            .unwrap_or_else(|| "nan".to_owned())
    )?;
    part.emitted += 1;
    Ok(())
}

pub(super) fn variant_prefix(
    variant: &Variant,
    major: usize,
    major_frequency: f64,
) -> Result<String> {
    let Chromosome::Autosome(chromosome) = variant.chromosome else {
        return Err(invalid("ineligible chromosome reached LD writer"));
    };
    let mut prefix = String::with_capacity(
        variant.id.len()
            + 2 * variant
                .alleles
                .iter()
                .map(|value| value.len())
                .sum::<usize>()
            + 256,
    );
    write!(
        prefix,
        "{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}",
        chromosome,
        variant.position,
        variant.id,
        variant.alleles[0],
        variant.alleles[1],
        if variant.provisional_ref { "Y" } else { "N" },
        variant.alleles[major],
        variant.alleles[1 - major],
        six_significant(1.0 - major_frequency)
    )
    .map_err(|_| invalid("LD prefix formatting failed"))?;
    Ok(prefix)
}

#[cfg(test)]
mod tests {
    use super::{Jobs, Task, partitions, six_significant};

    #[test]
    fn overlapping_pair_windows_decode_each_required_variant_once() {
        use super::{PairConfig, pairs};
        use crate::dataset::{ImportProfile, InputSpec, sibling};
        use crate::execution::Execution;
        use crate::make::{self, MakeConfig};
        use crate::native_workflow::fixtures;
        use std::fs;
        use std::num::NonZeroUsize;
        use std::sync::{
            Arc,
            atomic::{AtomicUsize, Ordering},
        };

        let directory = tempfile::tempdir_in(std::env::temp_dir()).unwrap().keep();
        let input = fixtures().join("inputs");
        let original = fs::read_to_string(input.join("baseline.vcf")).unwrap();
        let mut lines = original
            .lines()
            .filter(|line| line.starts_with('#'))
            .map(str::to_owned)
            .collect::<Vec<_>>();
        let variants = original
            .lines()
            .filter(|line| !line.starts_with('#'))
            .take(16)
            .collect::<Vec<_>>();
        for ordinal in 0..128 {
            let mut fields = variants[ordinal % variants.len()]
                .split('\t')
                .map(str::to_owned)
                .collect::<Vec<_>>();
            fields[0] = "1".into();
            fields[1] = (ordinal + 1).to_string();
            fields[2] = format!("window{ordinal}");
            lines.push(fields.join("\t"));
        }
        let vcf = directory.join("windows.vcf");
        fs::write(&vcf, lines.join("\n") + "\n").unwrap();
        let serial = Execution::new(NonZeroUsize::new(1), 512).unwrap();
        let parallel = Execution::new(NonZeroUsize::new(4), 512).unwrap();
        let pfile = directory.join("input");
        make::run(
            &MakeConfig {
                input: InputSpec::Vcf(vcf),
                profile: ImportProfile {
                    psam: Some(input.join("baseline.psam")),
                    ..Default::default()
                },
                out: pfile.clone(),
                selection: Default::default(),
                filters: Default::default(),
            },
            &serial,
        )
        .unwrap();
        let config = PairConfig {
            pfile,
            out: directory.join("serial"),
            allow_small_founders: true,
            ..Default::default()
        };
        let baseline = pairs(&config, &serial).unwrap();
        assert_eq!(baseline.evaluated_pairs, 8128);
        let counter = Arc::new(AtomicUsize::new(0));
        crate::ld::DECODE_COUNTER.with(|value| *value.borrow_mut() = Some(counter.clone()));
        let target = directory.join("parallel");
        let result = pairs(
            &PairConfig {
                out: target.clone(),
                ..config.clone()
            },
            &parallel,
        );
        crate::ld::DECODE_COUNTER.with(|value| *value.borrow_mut() = None);
        let report = result.unwrap();
        assert_eq!(report.effective_workers, 4);
        assert_eq!(
            (
                report.evaluated_pairs,
                report.emitted_pairs,
                report.no_overlap_pairs,
                report.zero_variance_pairs
            ),
            (
                baseline.evaluated_pairs,
                baseline.emitted_pairs,
                baseline.no_overlap_pairs,
                baseline.zero_variance_pairs
            )
        );
        assert_eq!(
            fs::read(sibling(&target, "vcor")).unwrap(),
            fs::read(sibling(&config.out, "vcor")).unwrap()
        );
        assert_eq!(
            counter.load(Ordering::Relaxed),
            128,
            "overlapping lanes must share each prepared variant"
        );
    }

    #[test]
    fn shared_mixed_dosage_pairs_match_budget_fallback_and_skip_empty_windows() {
        use super::{PairConfig, PairRow, Prepared, Resources, Selection, line_bytes, pairs};
        use crate::dataset::genotypes::{Call, Genotypes};
        use crate::dataset::sibling;
        use crate::execution::Execution;
        use std::{
            fs,
            num::NonZeroUsize,
            sync::{
                Arc,
                atomic::{AtomicUsize, Ordering},
            },
        };

        let directory = tempfile::tempdir_in(std::env::temp_dir()).unwrap().keep();
        let pfile = directory.join("mixed");
        let count = 4096;
        let mut psam = "#FID\tIID\tPAT\tMAT\tSEX\n".to_owned();
        let mut keep = String::new();
        for sample in 0..72 {
            psam.push_str(&format!(
                "0\tS{sample}\t{}\t0\t1\n",
                if sample < 65 { "0" } else { "S0" }
            ));
            if sample < 65 || sample == 71 {
                keep.push_str(&format!("S{sample}\n"));
            }
        }
        fs::write(sibling(&pfile, "psam"), psam).unwrap();
        let keep_path = directory.join("keep");
        fs::write(&keep_path, keep).unwrap();
        let mut pvar = "#CHROM\tPOS\tID\tREF\tALT\n".to_owned();
        for row in 0..count {
            let position = if row < count - 5 {
                row + 1
            } else {
                (row - (count - 6)) * 1_000_000
            };
            pvar.push_str(&format!("1\t{position}\tmixed{row}\tA\tG\n"));
        }
        fs::write(sibling(&pfile, "pvar"), pvar).unwrap();
        let offsets = (0..=count).map(|row| (row * 2) as u64).collect::<Vec<_>>();
        let mut writer = crate::io::pgen::Writer::open(
            &sibling(&pfile, "pgen"),
            72,
            &offsets,
            &vec![false; count],
            48,
        )
        .unwrap();
        for row in 0..count {
            let calls = (0..72)
                .map(|sample| {
                    let alleles = if row % 6 == 3 || sample % 13 == 0 {
                        None
                    } else {
                        Some(match if row % 6 == 4 { 0 } else { (sample + row) % 3 } {
                            0 => [0, 0],
                            1 => [0, 1],
                            _ => [1, 1],
                        })
                    };
                    let dosage = match row % 6 {
                        1 if sample == 71 => Some(12_345),
                        2 if sample % 5 != 0 => Some(((sample * 419 + row) % 32_769) as u16),
                        5 if sample % 7 != 0 => Some(((sample * 811 + row) % 32_769) as u16),
                        _ => None,
                    };
                    Call {
                        alleles,
                        dosage,
                        dphase: if row % 6 == 5 {
                            dosage.map(|value| {
                                if (101..32_668).contains(&value) {
                                    100
                                } else {
                                    0
                                }
                            })
                        } else {
                            None
                        },
                        ..Default::default()
                    }
                })
                .collect::<Vec<_>>();
            writer
                .append(&Genotypes::from_calls(&calls, 2, false).unwrap())
                .unwrap();
        }
        writer.finish().unwrap();
        let high = Execution::new(NonZeroUsize::new(4), 512).unwrap();
        let config = PairConfig {
            pfile,
            out: directory.join("shared"),
            window_variants: 8,
            selection: Selection {
                keep: Some(keep_path),
                ..Default::default()
            },
            ..Default::default()
        };
        let mut input = Prepared::open(&config.pfile, &config.selection, 50, &high).unwrap();
        let mut reader = input.dataset.reader().unwrap();
        let excluded_dosage = reader.read(crate::dataset::VariantId(1)).unwrap();
        assert!(!excluded_dosage.dosages.is_empty());
        assert!(
            excluded_dosage
                .calls()
                .take(65)
                .all(|call| call.dosage.is_none())
        );
        let hds = reader.read(crate::dataset::VariantId(5)).unwrap();
        assert!(hds.dphase.iter().any(|&value| value != 0));
        reader.close().unwrap();
        let resources =
            Resources::new_pairs(&input, &high, count / 16, 0, 8, line_bytes(&input)).unwrap();
        let mut low = Execution::new(NonZeroUsize::new(4), 512).unwrap();
        let planner_bytes = (count / 16) * std::mem::size_of::<super::Task>()
            + count * std::mem::size_of::<PairRow>()
            + 8 * (std::mem::size_of::<std::ops::Range<usize>>()
                + std::mem::size_of::<super::Segment>());
        low.memory_bytes = input.indexed_bytes()
            + planner_bytes
            + 2 * super::super::IO_BYTES
            + resources.workspace
            + 3 * resources.variant_reserve;
        let low_resources = Resources::new_pairs(
            &input,
            &low,
            count / 16,
            planner_bytes,
            8,
            line_bytes(&input),
        )
        .unwrap();
        assert_eq!(low_resources.workers, 1);
        assert!(low_resources.resident_span.is_none());
        let rows = (0..count - 1)
            .map(|row| PairRow {
                row,
                end: (row + 8).min(count),
                first_pair: row as u64,
            })
            .collect::<Vec<_>>();
        assert!(
            super::super::prepared::SharedPairs::prepare(&input, &low_resources, &low, &rows, 0)
                .unwrap()
                .is_none()
        );
        input.dataset.close().unwrap();
        crate::ld::CACHE_EVICTIONS.with(|count| count.set(0));
        let expected = pairs(
            &PairConfig {
                out: directory.join("fallback"),
                ..config.clone()
            },
            &low,
        )
        .unwrap();
        assert!(
            crate::ld::CACHE_EVICTIONS.with(|count| count.get()) > 0,
            "low-budget LD must retain the bounded evicting fallback"
        );
        let counter = Arc::new(AtomicUsize::new(0));
        crate::ld::DECODE_COUNTER.with(|value| *value.borrow_mut() = Some(counter.clone()));
        let actual = pairs(&config, &high);
        crate::ld::DECODE_COUNTER.with(|value| *value.borrow_mut() = None);
        let actual = actual.unwrap();
        assert_eq!(counter.load(Ordering::Relaxed), count - 5);
        assert_eq!(actual.founders, 65);
        assert_eq!(actual.selected_samples, 66);
        assert_eq!(actual.effective_workers, 4);
        assert_eq!(expected.effective_workers, 1);
        assert_eq!(
            (
                actual.evaluated_pairs,
                actual.emitted_pairs,
                actual.no_overlap_pairs,
                actual.zero_variance_pairs
            ),
            (
                expected.evaluated_pairs,
                expected.emitted_pairs,
                expected.no_overlap_pairs,
                expected.zero_variance_pairs
            )
        );
        assert!(actual.no_overlap_pairs > 0);
        assert!(actual.zero_variance_pairs > 0);
        assert_eq!(
            fs::read(sibling(&config.out, "vcor")).unwrap(),
            fs::read(directory.join("fallback.vcor")).unwrap()
        );
        counter.store(0, Ordering::Relaxed);
        crate::ld::DECODE_COUNTER.with(|value| *value.borrow_mut() = Some(counter.clone()));
        let empty = pairs(
            &PairConfig {
                out: directory.join("empty"),
                window_bp: 0,
                ..config
            },
            &low,
        );
        crate::ld::DECODE_COUNTER.with(|value| *value.borrow_mut() = None);
        assert_eq!(empty.unwrap().evaluated_pairs, 0);
        assert_eq!(counter.load(Ordering::Relaxed), 0);
    }

    #[test]
    fn pair_jobs_preserve_order_and_respect_compute_and_output_bounds() {
        let tasks = (0..1000)
            .map(|i| Task {
                rows: i * 16..(i + 1) * 16,
                chromosome_end: 16_001,
                pairs: 4000,
                first_pair: i as u64 * 4000,
            })
            .collect::<Vec<_>>();
        let parts = partitions(&tasks, 4);
        let jobs = Jobs::new(&tasks, &parts, 4, 64);
        assert!(
            jobs.count <= 128,
            "streaming must not hand off every few candidate pairs"
        );
        let mut next = 0;
        for job in 0..jobs.count {
            let range = jobs.pairs(job);
            assert_eq!(range.start, next);
            assert!(range.end - range.start <= 262_144);
            next = range.end;
        }
        assert_eq!(next, 4_000_000);
        let jobs = Jobs::new(&tasks, &parts, 4, 8192);
        let mut next = 0;
        for job in 0..jobs.count {
            let range = jobs.pairs(job);
            assert_eq!(range.start, next);
            assert!((range.end - range.start) * 8192 <= 4_194_304);
            next = range.end;
        }
        assert_eq!(next, 4_000_000);
    }

    #[test]
    fn source_table_numeric_precision_keeps_tiny_values() {
        assert_eq!(six_significant(0.0), "0");
        assert_eq!(six_significant(0.2581967213114754), "0.258197");
        assert_eq!(six_significant(2.762004e-7), "2.762e-07");
        assert_eq!(six_significant(0.00009999999), "0.0001");
        assert_eq!(six_significant(0.99999999), "1");
        assert_eq!(six_significant(0.9096875), "0.909688");
    }
}
