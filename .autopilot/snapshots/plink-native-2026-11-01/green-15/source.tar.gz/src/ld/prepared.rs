use super::moments::{self, HardCallView, Moments};
use super::pairs::{self, PairRow};
use super::{IO_BYTES, Prepared, Resources, SelectedOrdinal};
use crate::dataset::VariantId;
use crate::dataset::genotypes::Genotypes;
use crate::execution::Execution;
use crate::{Result, invalid};
use std::mem::size_of;
use std::ops::Range;

#[derive(Clone, Default)]
struct Row {
    prefix: Range<usize>,
    dosage: bool,
}

pub(super) struct SharedPairs {
    mapping: Box<[usize]>,
    rows: Box<[Row]>,
    planes: Box<[u64]>,
    dosages: Box<[u16]>,
    prefixes: Box<[u8]>,
    words: usize,
    founders: usize,
}

fn required(rows: &[PairRow]) -> impl Iterator<Item = Range<usize>> + '_ {
    let mut end = 0;
    rows.iter().filter_map(move |row| {
        let start = row.row.max(end);
        end = end.max(row.end);
        (start < end).then_some(start..end)
    })
}

impl SharedPairs {
    pub fn prepare(
        input: &Prepared,
        resources: &Resources,
        execution: &Execution,
        rows: &[PairRow],
        planner_bytes: usize,
    ) -> Result<Option<Self>> {
        if rows.is_empty() {
            return Ok(None);
        }
        let count = required(rows).map(|range| range.len()).sum::<usize>();
        let founders = input.founders.indices.len();
        let words = founders.div_ceil(64);
        let overflow = || invalid("LD shared preparation memory estimate overflow");
        let mut prefix_bytes = 0usize;
        for ordinal in required(rows).flatten() {
            let variant = &input.dataset.metadata.variants[input.variants[ordinal]];
            let prefix = variant
                .alleles
                .iter()
                .try_fold(variant.id.len(), |n, allele| {
                    n.checked_add(allele.len().checked_mul(2)?)
                })
                .and_then(|n| n.checked_add(256))
                .ok_or_else(overflow)?;
            prefix_bytes = prefix_bytes.checked_add(prefix).ok_or_else(overflow)?;
        }
        let plane_count = count
            .checked_mul(words)
            .and_then(|n| n.checked_mul(3))
            .ok_or_else(overflow)?;
        let base = input
            .indexed_bytes()
            .checked_add(planner_bytes)
            .and_then(|n| n.checked_add(IO_BYTES))
            .and_then(|n| n.checked_add(resources.workspace))
            .and_then(|n| n.checked_add(resources.variant_reserve))
            .and_then(|n| n.checked_add(size_of::<Self>() + 6 * 64))
            .ok_or_else(overflow)?;
        if base > execution.memory_bytes {
            return Ok(None);
        }
        let mut reader = input.dataset.reader()?;
        let result = (|| {
            if reader.workspace_bytes() > resources.workspace {
                return Err(invalid("LD reader workspace exceeds preflight reservation"));
            }
            let dosage = reader.track_flags().is_none_or(|flags| flags & 48 != 0);
            let dosage_count = if dosage {
                count.checked_mul(founders).ok_or_else(overflow)?
            } else {
                0
            };
            let arrays = [
                input.variants.len().checked_mul(size_of::<usize>()),
                count.checked_mul(size_of::<Row>()),
                plane_count.checked_mul(size_of::<u64>()),
                dosage_count.checked_mul(size_of::<u16>()),
                Some(prefix_bytes),
            ]
            .into_iter()
            .try_fold(0usize, |sum, bytes| sum.checked_add(bytes?));
            let output = if resources.workers > 1 {
                pairs::BLOCK_BYTES
                    .checked_mul(resources.workers)
                    .and_then(|n| {
                        n.checked_add(crate::ordered::memory_bytes::<pairs::Block, pairs::Counts>(
                            resources.workers,
                        ))
                    })
            } else {
                Some(0)
            };
            let total = arrays
                .and_then(|n| base.checked_add(n))
                .and_then(|n| n.checked_add(output?))
                .ok_or_else(overflow)?;
            if total > execution.memory_bytes {
                return Ok(None);
            }
            let mut value = Self {
                mapping: vec![usize::MAX; input.variants.len()].into_boxed_slice(),
                rows: vec![Row::default(); count].into_boxed_slice(),
                planes: vec![0; plane_count].into_boxed_slice(),
                dosages: vec![u16::MAX; dosage_count].into_boxed_slice(),
                prefixes: vec![0; prefix_bytes].into_boxed_slice(),
                words,
                founders,
            };
            let mut raw = Genotypes::empty(0, 2, false);
            let mut offset = 0;
            for (dense, ordinal) in required(rows).flatten().enumerate() {
                reader.read_into(VariantId(input.variants[ordinal]), &mut raw)?;
                #[cfg(test)]
                if let Some(counter) = &input.decodes {
                    counter.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
                }
                value.mapping[ordinal] = dense;
                let start = dense * words * 3;
                for (founder, &sample) in input.founders.indices.iter().enumerate() {
                    let code = (raw.genotypes[sample / 32] >> (2 * (sample % 32))) & 3;
                    if code != 3 {
                        let bit = 1 << (founder % 64);
                        value.planes[start + founder / 64] |= bit;
                        if code != 0 {
                            value.planes[start + code as usize * words + founder / 64] |= bit;
                        }
                    }
                }
                if dosage {
                    let mut founder = 0;
                    for (sample, call) in raw.calls().enumerate() {
                        if founder == founders {
                            break;
                        }
                        if sample != input.founders.indices[founder] {
                            continue;
                        }
                        value.dosages[dense * founders + founder] = call
                            .dosage
                            .or_else(|| {
                                call.alleles
                                    .map(|[a, b]| (u16::from(a) + u16::from(b)) * 16_384)
                            })
                            .unwrap_or(u16::MAX);
                        founder += 1;
                    }
                } else if !raw.dosages.is_empty() {
                    return Err(invalid("LD dosage track contradicts prepared source flags"));
                }
                let (major, frequency) = moments::major_frequency(&raw, &input.founders);
                let prefix = pairs::variant_prefix(
                    &input.dataset.metadata.variants[input.variants[ordinal]],
                    major,
                    frequency,
                )?;
                let end = offset + prefix.len();
                if end > value.prefixes.len() {
                    return Err(invalid("LD prefix exceeds shared reservation"));
                }
                value.prefixes[offset..end].copy_from_slice(prefix.as_bytes());
                value.rows[dense] = Row {
                    prefix: offset..end,
                    dosage: !raw.dosages.is_empty(),
                };
                offset = end;
            }
            Ok(Some(value))
        })();
        let closed = reader.close();
        let result = result?;
        closed?;
        Ok(result)
    }

    fn hard(&self, row: usize) -> HardCallView<'_> {
        let start = row * self.words * 3;
        HardCallView {
            valid: &self.planes[start..start + self.words],
            one: &self.planes[start + self.words..start + 2 * self.words],
            two: &self.planes[start + 2 * self.words..start + 3 * self.words],
        }
    }

    pub fn pair(
        &self,
        a: SelectedOrdinal,
        b: SelectedOrdinal,
        kernel: moments::HardCallKernel,
    ) -> (Moments, &[u8], &[u8]) {
        let a = self.mapping[a.0];
        let b = self.mapping[b.0];
        let moments = if !self.rows[a].dosage && !self.rows[b].dosage {
            kernel.borrowed(self.hard(a), self.hard(b))
        } else {
            let mut result = Moments::default();
            for (&x, &y) in self.dosages[a * self.founders..(a + 1) * self.founders]
                .iter()
                .zip(&self.dosages[b * self.founders..(b + 1) * self.founders])
            {
                if x != u16::MAX && y != u16::MAX {
                    result.add(u64::from(x), u64::from(y));
                }
            }
            result
        };
        (
            moments,
            &self.prefixes[self.rows[a].prefix.clone()],
            &self.prefixes[self.rows[b].prefix.clone()],
        )
    }
}
