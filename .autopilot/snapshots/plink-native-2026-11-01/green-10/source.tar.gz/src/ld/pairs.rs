use super::moments::{self, Correlation};
use super::{Prepared, Resources, SelectedOrdinal, VariantCache, VariantData, check_outputs};
use crate::dataset::chrom::Chromosome;
use crate::dataset::metadata::Variant;
use crate::dataset::sibling;
use crate::execution::Execution;
use crate::make::Selection;
use crate::numeric::six_significant;
use crate::{Result, invalid};
use rsomics_common::AtomicFile;
use serde::Serialize;
use std::collections::BTreeSet;
use std::fmt::Write as _;
use std::io::{self, BufWriter, Write};
use std::mem::size_of;
use std::ops::Range;
use std::path::PathBuf;

#[derive(Clone, Debug)]
pub(crate) struct PairConfig {
    pub pfile: PathBuf,
    pub out: PathBuf,
    pub selection: Selection,
    pub window_variants: usize,
    pub window_bp: u64,
    pub min_r2: f64,
    pub allow_small_founders: bool,
}

impl Default for PairConfig {
    fn default() -> Self {
        Self {
            pfile: PathBuf::new(),
            out: PathBuf::new(),
            selection: Selection::default(),
            window_variants: 1_000_000,
            window_bp: 500_000,
            min_r2: -1.0,
            allow_small_founders: false,
        }
    }
}

#[derive(Default, Serialize)]
pub(crate) struct PairReport {
    pub selected_samples: usize,
    pub founders: usize,
    pub variants: usize,
    pub evaluated_pairs: u64,
    pub emitted_pairs: u64,
    pub no_overlap_pairs: u64,
    pub zero_variance_pairs: u64,
    pub requested_workers: usize,
    pub effective_workers: usize,
    pub writer_workers: usize,
}

struct Task {
    rows: Range<usize>,
    chromosome_end: usize,
    pairs: u64,
    first_pair: u64,
}

struct PairRow {
    row: usize,
    end: usize,
    first_pair: u64,
}

struct Segment {
    first_pair: u64,
    end_pair: u64,
    first_job: usize,
}

struct Jobs {
    segments: Vec<Segment>,
    width: u64,
    count: usize,
}

impl Jobs {
    fn new(tasks: &[Task], partitions: &[Range<usize>], workers: usize) -> Self {
        let total = tasks.iter().map(|task| task.pairs).sum::<u64>();
        let width = total
            .div_ceil(workers.saturating_mul(16).max(1) as u64)
            .clamp(16_384, 262_144);
        let mut segments = Vec::with_capacity(partitions.len());
        let mut count = 0;
        for partition in partitions {
            let first_pair = tasks[partition.start].first_pair;
            let last = &tasks[partition.end - 1];
            let end_pair = last.first_pair + last.pairs;
            if end_pair != first_pair {
                segments.push(Segment {
                    first_pair,
                    end_pair,
                    first_job: count,
                });
                count += (end_pair - first_pair).div_ceil(width) as usize;
            }
        }
        Self {
            segments,
            width,
            count,
        }
    }

    fn pairs(&self, job: usize) -> Range<u64> {
        let index = self
            .segments
            .partition_point(|segment| segment.first_job <= job)
            - 1;
        let segment = &self.segments[index];
        let start = segment.first_pair + (job - segment.first_job) as u64 * self.width;
        start..(start + self.width).min(segment.end_pair)
    }
}

fn partitions(tasks: &[Task], workers: usize) -> Vec<Range<usize>> {
    let count = workers.saturating_mul(2).min(tasks.len());
    if count == 0 {
        return Vec::new();
    }
    let cost = tasks
        .iter()
        .map(|task| u128::from(task.pairs))
        .sum::<u128>();
    let weighted = cost != 0;
    let total = if weighted { cost } else { tasks.len() as u128 };
    let mut output = Vec::with_capacity(count);
    let mut cumulative = 0;
    let mut start = 0;
    for (index, task) in tasks.iter().enumerate() {
        cumulative += if weighted { u128::from(task.pairs) } else { 1 };
        let remaining = count - output.len() - 1;
        if remaining != 0
            && (cumulative >= total * (output.len() + 1) as u128 / count as u128
                || tasks.len() - index - 1 == remaining)
        {
            output.push(start..index + 1);
            start = index + 1;
        }
    }
    output.push(start..tasks.len());
    output
}

pub(super) const BLOCK_BYTES: usize = 65_536;

#[derive(Default)]
pub(super) struct Counts {
    evaluated: u64,
    emitted: u64,
    no_overlap: u64,
    zero_variance: u64,
    worker: usize,
}

impl PairReport {
    fn add(&mut self, counts: &Counts) {
        self.evaluated_pairs += counts.evaluated;
        self.emitted_pairs += counts.emitted;
        self.no_overlap_pairs += counts.no_overlap;
        self.zero_variance_pairs += counts.zero_variance;
    }
}

pub(crate) fn pairs(config: &PairConfig, execution: &Execution) -> Result<PairReport> {
    if config.window_variants < 2 || !config.min_r2.is_finite() || config.min_r2 > 1.0 {
        return Err(invalid(
            "LD pair window must be at least 2 and minimum r2 must be finite and no greater than 1",
        ));
    }
    check_outputs(&config.pfile, &config.selection, &config.out, &["vcor"])?;
    let mut input = Prepared::open(
        &config.pfile,
        &config.selection,
        if config.allow_small_founders { 2 } else { 50 },
        execution,
    )?;
    let mut tasks = Vec::new();
    let mut rows = Vec::new();
    let mut total_pairs = 0;
    let mut live_span = 1;
    for chromosome in &input.chromosomes {
        let mut endpoint = chromosome.start;
        for start in (chromosome.start..chromosome.end.saturating_sub(1)).step_by(16) {
            let stop = (start + 16).min(chromosome.end - 1);
            let mut pairs = 0;
            let first_pair = total_pairs;
            for row in start..stop {
                endpoint = endpoint.max(row + 1);
                let end = row
                    .saturating_add(config.window_variants)
                    .min(chromosome.end);
                let a = &input.dataset.metadata.variants[input.variants[row]];
                while endpoint < end {
                    let b = &input.dataset.metadata.variants[input.variants[endpoint]];
                    if b.position - a.position > config.window_bp {
                        break;
                    }
                    endpoint += 1;
                }
                let count = (endpoint - row - 1) as u64;
                if count != 0 {
                    rows.push(PairRow {
                        row,
                        end: endpoint,
                        first_pair: total_pairs,
                    });
                }
                pairs += count;
                total_pairs += count;
                live_span = live_span.max(endpoint - row);
            }
            tasks.push(Task {
                rows: start..stop,
                chromosome_end: chromosome.end,
                pairs,
                first_pair,
            });
        }
    }
    let maximum_partitions = execution
        .requested_workers
        .min(execution.pool.current_num_threads())
        .saturating_mul(2)
        .min(tasks.len());
    let resources = Resources::new_pairs(
        &input,
        execution,
        tasks.len(),
        tasks.capacity() * size_of::<Task>()
            + rows.capacity() * size_of::<PairRow>()
            + maximum_partitions * (size_of::<Range<usize>>() + size_of::<Segment>()),
        live_span,
    )?;
    let partitions = partitions(&tasks, resources.workers);
    let jobs = Jobs::new(&tasks, &partitions, resources.workers);
    let mut output = AtomicFile::new(sibling(&config.out, "vcor"))?;
    let mut report = PairReport {
        selected_samples: input.selected_samples,
        founders: input.founders.indices.len(),
        variants: input.variants.len(),
        requested_workers: execution.requested_workers,
        writer_workers: 1,
        ..PairReport::default()
    };
    let mut workers = BTreeSet::new();
    {
        let mut writer = BufWriter::with_capacity(65_536, output.file_mut());
        writeln!(
            writer,
            "#CHROM_A\tPOS_A\tID_A\tREF_A\tALT_A\tPROVISIONAL_REF_A?\tMAJ_A\tNONMAJ_A\tNONMAJ_FREQ_A\tCHROM_B\tPOS_B\tID_B\tREF_B\tALT_B\tPROVISIONAL_REF_B?\tMAJ_B\tNONMAJ_B\tNONMAJ_FREQ_B\tUNPHASED_R2"
        )?;
        if resources.workers == 1 && !tasks.is_empty() {
            let mut cache = VariantCache::open(&input, &resources, true)?;
            let counts = calculate(&input, &resources, config, &tasks, &mut cache, &mut writer);
            let closed = cache.close();
            let counts = counts?;
            closed?;
            report.add(&counts);
            workers.insert(counts.worker);
        } else if jobs.count != 0 {
            crate::ordered::run(
                &execution.pool,
                resources.workers,
                jobs.count,
                |_| VariantCache::open(&input, &resources, true),
                |cache, partition, sink| {
                    let mut writer = Blocks::new(sink);
                    let counts = calculate_job(
                        &input,
                        &resources,
                        config,
                        &rows,
                        jobs.pairs(partition),
                        cache,
                        &mut writer,
                    )?;
                    writer.flush()?;
                    Ok(counts)
                },
                VariantCache::close,
                crate::ordered::Consumer {
                    write: |_, block: &mut Vec<u8>| {
                        writer.write_all(block)?;
                        Ok(())
                    },
                    complete: |count: Counts| {
                        report.add(&count);
                        workers.insert(count.worker);
                    },
                },
            )?;
        }
        writer.flush()?;
    }
    report.effective_workers = workers.len();
    input.dataset.close()?;
    AtomicFile::commit_all(vec![output])?;
    Ok(report)
}

fn calculate(
    input: &Prepared,
    resources: &Resources,
    config: &PairConfig,
    tasks: &[Task],
    cache: &mut VariantCache<'_>,
    writer: &mut impl Write,
) -> Result<Counts> {
    let mut part = Counts {
        worker: rayon::current_thread_index().unwrap_or(0),
        ..Counts::default()
    };
    for task in tasks {
        let mut endpoint = task.rows.start;
        for row in task.rows.clone() {
            let a_index = input.variants[row];
            let a = &input.dataset.metadata.variants[a_index];
            let end = row
                .saturating_add(config.window_variants)
                .min(task.chromosome_end);
            endpoint = endpoint.max(row + 1);
            while endpoint < end {
                let b = &input.dataset.metadata.variants[input.variants[endpoint]];
                if b.position - a.position > config.window_bp {
                    break;
                }
                endpoint += 1;
            }
            if resources.resident_span.is_some() {
                cache.refill(SelectedOrdinal(row), SelectedOrdinal(endpoint))?;
                let (first, second) = cache.resident.as_slices();
                let (a_data, rest) = first
                    .split_first()
                    .ok_or_else(|| invalid("empty LD resident row"))?;
                for b_data in rest.iter().chain(second) {
                    emit(a_data, b_data, input, resources, config, writer, &mut part)?;
                }
            } else {
                cache.ensure(a_index, None)?;
                for &b_index in &input.variants[row + 1..endpoint] {
                    cache.ensure(b_index, Some(a_index))?;
                    let a_data = cache.get(a_index);
                    let b_data = cache.get(b_index);
                    emit(a_data, b_data, input, resources, config, writer, &mut part)?;
                }
            }
        }
    }
    Ok(part)
}

fn calculate_job(
    input: &Prepared,
    resources: &Resources,
    config: &PairConfig,
    rows: &[PairRow],
    pairs: Range<u64>,
    cache: &mut VariantCache<'_>,
    writer: &mut impl Write,
) -> Result<Counts> {
    let mut row_index = rows.partition_point(|row| row.first_pair <= pairs.start) - 1;
    let mut position = pairs.start;
    let mut part = Counts {
        worker: rayon::current_thread_index().unwrap_or(0),
        ..Counts::default()
    };
    while position < pairs.end {
        let row = &rows[row_index];
        let first = row.row + 1 + (position - row.first_pair) as usize;
        let end = row.end.min(first + (pairs.end - position) as usize);
        let a_index = input.variants[row.row];
        if resources.resident_span.is_some() {
            cache.refill(SelectedOrdinal(row.row), SelectedOrdinal(row.end))?;
            let a = cache.resident(SelectedOrdinal(row.row));
            for ordinal in first..end {
                let b = cache.resident(SelectedOrdinal(ordinal));
                emit(a, b, input, resources, config, writer, &mut part)?;
            }
        } else {
            cache.ensure(a_index, None)?;
            for &b_index in &input.variants[first..end] {
                cache.ensure(b_index, Some(a_index))?;
                emit(
                    cache.get(a_index),
                    cache.get(b_index),
                    input,
                    resources,
                    config,
                    writer,
                    &mut part,
                )?;
            }
        }
        position += (end - first) as u64;
        row_index += 1;
    }
    Ok(part)
}

struct Blocks<'a> {
    sink: &'a crate::ordered::Sink<Vec<u8>, Counts>,
    bytes: Vec<u8>,
}

impl<'a> Blocks<'a> {
    fn new(sink: &'a crate::ordered::Sink<Vec<u8>, Counts>) -> Self {
        Self {
            sink,
            bytes: Vec::new(),
        }
    }
}

impl Write for Blocks<'_> {
    fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
        let mut remaining = bytes;
        while !remaining.is_empty() {
            if self.bytes.capacity() == 0 {
                self.bytes = self
                    .sink
                    .recycled()
                    .unwrap_or_else(|| Vec::with_capacity(BLOCK_BYTES));
                self.bytes.clear();
            }
            let count = remaining.len().min(BLOCK_BYTES - self.bytes.len());
            self.bytes.extend_from_slice(&remaining[..count]);
            remaining = &remaining[count..];
            if self.bytes.len() == BLOCK_BYTES {
                self.flush()?;
            }
        }
        Ok(bytes.len())
    }

    fn flush(&mut self) -> io::Result<()> {
        if !self.bytes.is_empty() {
            self.sink
                .send(std::mem::take(&mut self.bytes))
                .map_err(|error| io::Error::new(io::ErrorKind::BrokenPipe, error.to_string()))?;
        }
        Ok(())
    }
}

fn emit(
    a_data: &VariantData,
    b_data: &VariantData,
    input: &Prepared,
    resources: &Resources,
    config: &PairConfig,
    writer: &mut impl Write,
    part: &mut Counts,
) -> Result<()> {
    let moments = if a_data.raw.dosages.is_empty() && b_data.raw.dosages.is_empty() {
        resources.kernel.moments(&a_data.hard, &b_data.hard)
    } else {
        moments::dosage_moments(&a_data.raw, &b_data.raw, &input.founders)
    };
    part.evaluated += 1;
    let value = match moments.correlation() {
        Correlation::Defined(value) => Some(value),
        Correlation::NoOverlap => {
            part.no_overlap += 1;
            None
        }
        Correlation::ZeroVariance => {
            part.zero_variance += 1;
            None
        }
    };
    if config.min_r2 >= 0.0 && value.is_none_or(|value| value < config.min_r2) {
        return Ok(());
    }
    writer.write_all(a_data.pair_prefix.as_bytes())?;
    write!(writer, "\t")?;
    writer.write_all(b_data.pair_prefix.as_bytes())?;
    writeln!(
        writer,
        "\t{}",
        value
            .map(six_significant)
            .unwrap_or_else(|| "nan".to_owned())
    )?;
    part.emitted += 1;
    Ok(())
}

pub(super) fn variant_prefix(
    variant: &Variant,
    major: usize,
    major_frequency: f64,
) -> Result<String> {
    let Chromosome::Autosome(chromosome) = variant.chromosome else {
        return Err(invalid("ineligible chromosome reached LD writer"));
    };
    let mut prefix = String::with_capacity(
        variant.id.len() + 2 * variant.alleles.iter().map(String::len).sum::<usize>() + 256,
    );
    write!(
        prefix,
        "{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}",
        chromosome,
        variant.position,
        variant.id,
        variant.alleles[0],
        variant.alleles[1],
        if variant.provisional_ref { "Y" } else { "N" },
        variant.alleles[major],
        variant.alleles[1 - major],
        six_significant(1.0 - major_frequency)
    )
    .map_err(|_| invalid("LD prefix formatting failed"))?;
    Ok(prefix)
}

#[cfg(test)]
mod tests {
    use super::{Jobs, Task, partitions, six_significant};

    #[test]
    fn streamed_pair_jobs_keep_contiguous_work_coarse_and_bounded() {
        let tasks = (0..1000)
            .map(|i| Task {
                rows: i * 16..(i + 1) * 16,
                chromosome_end: 16_001,
                pairs: 4000,
                first_pair: i as u64 * 4000,
            })
            .collect::<Vec<_>>();
        let parts = partitions(&tasks, 4);
        let jobs = Jobs::new(&tasks, &parts, 4);
        assert!(
            jobs.count <= 128,
            "streaming must not hand off every few candidate pairs"
        );
        let mut next = 0;
        for job in 0..jobs.count {
            let range = jobs.pairs(job);
            assert_eq!(range.start, next);
            assert!(range.end - range.start <= 262_144);
            next = range.end;
        }
        assert_eq!(next, 4_000_000);
    }

    #[test]
    fn source_table_numeric_precision_keeps_tiny_values() {
        assert_eq!(six_significant(0.0), "0");
        assert_eq!(six_significant(0.2581967213114754), "0.258197");
        assert_eq!(six_significant(2.762004e-7), "2.762e-07");
        assert_eq!(six_significant(0.00009999999), "0.0001");
        assert_eq!(six_significant(0.99999999), "1");
        assert_eq!(six_significant(0.9096875), "0.909688");
    }
}
