/* SPDX-License-Identifier: LGPL-3.0-or-later */
#ifndef RSOMICS_PGEN_SHIM_H
#define RSOMICS_PGEN_SHIM_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct RsPgReader RsPgReader;
typedef struct RsPgIndex RsPgIndex;
typedef struct RsPgWriter RsPgWriter;
typedef struct {
  uint32_t samples, alleles, provisional_ref, reference_mode;
  uint32_t genotype_words, mask_words, patch01_count, patch10_count;
  uint32_t phase_count, dosage_count, dphase_count;
  const uint64_t *genotypes, *patch01, *patch10;
  const uint8_t *patch01_values, *patch10_values;
  const uint64_t *phase_present, *phase_info, *dosage_present, *dphase_present;
  const uint16_t *dosages;
  const int16_t *dphase;
} RsPgVariantView;
uint32_t rs_pg_abi_version(void);
int rs_pg_index_open(const char *, uint32_t, uint32_t, const uint64_t *, uint64_t,
                     RsPgIndex **, uint64_t *, uint64_t *, char *, size_t);
int rs_pg_index_close(RsPgIndex *, char *, size_t);
int rs_pg_reader_open(RsPgIndex *, RsPgReader **, char *, size_t);
int rs_pg_read(RsPgReader *, uint32_t, RsPgVariantView *, char *, size_t);
int rs_pg_reference_flags(RsPgIndex *, uint64_t *, uint32_t, uint32_t *, char *, size_t);
int rs_pg_track_flags(RsPgIndex *, uint32_t *, char *, size_t);
int rs_pg_reader_close(RsPgReader *, char *, size_t);
int rs_pg_writer_open(const char *, uint32_t, uint32_t, const uint64_t *,
                     const uint64_t *, uint32_t, RsPgWriter **, uint64_t *, char *, size_t);
int rs_pg_append(RsPgWriter *, const RsPgVariantView *, char *, size_t);
int rs_pg_writer_finish(RsPgWriter *, char *, size_t);
void rs_pg_writer_abort(RsPgWriter *);
#ifdef __cplusplus
}
#endif
#endif
