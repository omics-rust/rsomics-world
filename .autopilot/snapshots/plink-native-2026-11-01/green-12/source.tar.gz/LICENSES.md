# Component licenses

The original Rust application code is available under MIT OR Apache-2.0.
The vendored pgenlib codec and native/pgen_shim.h and native/pgen_shim.cc
are LGPL-3.0-or-later. The bundled SIMDe headers retain their individual
MIT or CC0-1.0 license headers. See vendor/SOURCE.json and the unmodified
full license texts in vendor/pgenlib/COPYING, COPYING.LESSER and simde/COPYING.

This private source tree is not distribution qualification. A combined binary
release requires exact corresponding source/application code, all notices,
marked changes and verified replace-codec/rebuild/relink instructions under
the applicable LGPL terms. It is not an all-Rust PGEN codec.
