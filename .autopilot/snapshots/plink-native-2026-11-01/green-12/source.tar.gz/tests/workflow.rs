#[path = "../src/dataset/mod.rs"]
#[allow(dead_code)]
mod dataset;
#[path = "../src/io/mod.rs"]
#[allow(dead_code)]
mod io;

pub(crate) use rsomics_common::Result;
use serde_json::{Value, json};
use std::{
    fs,
    path::{Path, PathBuf},
    process::Command,
};
pub(crate) fn invalid(message: impl Into<String>) -> rsomics_common::RsomicsError {
    rsomics_common::RsomicsError::InvalidInput(message.into())
}

fn raw(dataset: &dataset::Dataset) -> Vec<Value> {
    let mut reader = dataset.reader().unwrap();
    let rows = (0..dataset.metadata.variants.len())
        .map(|index| {
            let values = reader.read(dataset::VariantId(index)).unwrap();
            let calls = values
                .calls()
                .map(|call| {
                    let mut alleles = call
                        .alleles
                        .map(|[a, b]| [a as i32, b as i32])
                        .unwrap_or([-9, -9]);
                    if call.phase && call.reversed {
                        alleles.swap(0, 1);
                    }
                    json!([
                        alleles[0],
                        alleles[1],
                        u8::from(call.phase),
                        u8::from(call.reversed),
                        call.dosage,
                        call.dphase
                    ])
                })
                .collect::<Vec<_>>();
            json!({"variant":index,"provisional_ref":values.provisional_ref,"calls":calls})
        })
        .collect();
    reader.close().unwrap();
    rows
}

fn load(prefix: &Path) -> dataset::Dataset {
    dataset::Dataset::open(
        dataset::InputSpec::Pgen(prefix.into()),
        dataset::ImportProfile::default(),
    )
    .unwrap()
}

#[test]
fn complete_six_lane_native_cli_graph_matches_source_and_preserves_raw_generations() {
    std::hint::black_box(rsomics_plink::run_cli as fn() -> std::process::ExitCode);
    let root = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let output = tempfile::Builder::new()
        .prefix("plink-whole-native-")
        .tempdir_in(std::env::temp_dir())
        .unwrap()
        .keep();
    let python = std::env::var_os("RSOMICS_PYTHON").unwrap_or_else(|| "python3".into());
    let result = Command::new(python)
        .arg("-B")
        .arg(root.join("tests/workflow.py"))
        .env("RSOMICS_PLINK_BIN", env!("CARGO_BIN_EXE_rsomics-plink"))
        .env("RSOMICS_PLINK_WORKFLOW_DIR", &output)
        .env("PYTHONDONTWRITEBYTECODE", "1")
        .output()
        .unwrap();
    fs::write(output.join("driver.stdout.txt"), &result.stdout).unwrap();
    fs::write(output.join("driver.stderr.txt"), &result.stderr).unwrap();
    assert!(
        result.status.success(),
        "whole graph failed; retained {}\n{}\n{}",
        output.display(),
        String::from_utf8_lossy(&result.stdout),
        String::from_utf8_lossy(&result.stderr)
    );
    let mut graph: Value =
        serde_json::from_slice(&fs::read(output.join("native-graph.json")).unwrap()).unwrap();
    let mut cells = 0usize;
    for entry in graph["generations"].as_array().unwrap() {
        let prefix = Path::new(entry["prefix"].as_str().unwrap());
        let expected = fs::read_to_string(entry["expected"].as_str().unwrap())
            .unwrap()
            .lines()
            .skip(1)
            .map(|line| serde_json::from_str::<Value>(line).unwrap())
            .collect::<Vec<_>>();
        let actual = raw(&load(prefix));
        assert_eq!(
            actual.len(),
            expected.len(),
            "{} variant count",
            prefix.display()
        );
        for (index, (a, e)) in actual.iter().zip(&expected).enumerate() {
            assert_eq!(a["variant"], e["variant"], "{} ordinal", prefix.display());
            assert_eq!(
                a["provisional_ref"],
                e["provisional_ref"],
                "{} variant{index} REF",
                prefix.display()
            );
            for (sample, (a, e)) in a["calls"]
                .as_array()
                .unwrap()
                .iter()
                .zip(e["calls"].as_array().unwrap())
                .enumerate()
            {
                assert_eq!(a, e, "{} variant{index} sample{sample}", prefix.display());
                cells += 1;
            }
            assert_eq!(
                a["calls"].as_array().unwrap().len(),
                e["calls"].as_array().unwrap().len()
            );
        }
        fs::write(
            prefix.with_extension(format!(
                "{}.raw.json",
                prefix.extension().unwrap().to_string_lossy()
            )),
            serde_json::to_vec_pretty(&actual).unwrap(),
        )
        .unwrap();
    }
    for workers in [1, 4] {
        for lane in ["gt", "bed", "pgen", "ds", "hds", "rich"] {
            let f = load(&output.join(format!("{workers}/{lane}.F")));
            let p = load(&output.join(format!("{workers}/{lane}.P")));
            let fraw = raw(&f);
            let praw = raw(&p);
            for (variant, row) in p.metadata.variants.iter().zip(&praw) {
                let index = f
                    .metadata
                    .variants
                    .iter()
                    .position(|v| v.id == variant.id)
                    .unwrap();
                assert_eq!(
                    row["calls"], fraw[index]["calls"],
                    "{lane} P raw projection"
                );
                assert_eq!(row["provisional_ref"], fraw[index]["provisional_ref"]);
            }
        }
    }
    graph["status"] = json!("complete_compact_native_graph_passed");
    graph["raw_cells_checked"] = json!(cells);
    fs::write(
        output.join("native-graph.json"),
        serde_json::to_vec_pretty(&graph).unwrap(),
    )
    .unwrap();
    println!(
        "complete native graph retained at {}; {cells} raw cells checked",
        output.display()
    );
}
