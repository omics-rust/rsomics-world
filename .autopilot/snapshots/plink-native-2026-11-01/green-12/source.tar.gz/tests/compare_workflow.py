import csv
from decimal import Decimal, InvalidOperation, ROUND_HALF_EVEN, ROUND_HALF_UP
import hashlib
import json
from pathlib import Path

FLOAT_COLUMNS = {
    'F_MISS_DOSAGE', 'F_MISS', 'F_MISS_AND_HETHAP', 'E(HOM)', 'E(HET)', 'F',
    'O(HET_A1)', 'E(HET_A1)', 'MIDP', 'NEG_LOG10_MIDP',
    'NONMAJ_FREQ_A', 'NONMAJ_FREQ_B', 'UNPHASED_R2',
}
CATEGORY_COLUMNS = {
    'CHROM', 'ID', 'REF', 'ALT', 'PROVISIONAL_REF?', 'FID', 'IID', 'SID', 'SEX',
    'A1', 'AX', 'CHROM_A', 'ID_A', 'REF_A', 'ALT_A', 'PROVISIONAL_REF_A?',
    'MAJ_A', 'NONMAJ_A', 'CHROM_B', 'ID_B', 'REF_B', 'ALT_B',
    'PROVISIONAL_REF_B?', 'MAJ_B', 'NONMAJ_B',
}
INTEGER_COLUMNS = {
    'POS', 'POS_A', 'POS_B', 'OBS_CT', 'HOM_REF_CT', 'HOM_ALT_CT', 'HET_CT',
    'HET_REF_ALT_CT', 'HET_2ALT_CT', 'HET_REF_ALT_CTS', 'TWO_ALT_GENO_CTS',
    'HAP_REF_CT', 'HAP_ALT_CT', 'HAP_ALT_CTS', 'MISSING_CT', 'MISSING_DOSAGE_CT',
    'MISSING_AND_HETHAP_CT', 'HETHAP_CT', 'HOM_A1_CT', 'HET_A1_CT', 'TWO_AX_CT',
    'O(HOM)', 'O(HET)',
}


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(65536), b''):
            digest.update(block)
    return digest.hexdigest()


def table(path):
    with Path(path).open() as stream:
        reader = csv.DictReader((line.lstrip('#') for line in stream if not line.startswith('##')), delimiter='\t')
        rows = list(reader)
    assert reader.fieldnames and all(None not in row and None not in row.values() for row in rows), f'malformed table: {path}'
    return reader.fieldnames, rows


def numeric(token):
    lower = token.lower()
    if lower == 'na':
        return 'missing', None
    if lower in ('nan', '+nan', '-nan'):
        return 'nan', None
    if lower in ('inf', '+inf', 'infinity', '+infinity'):
        return 'positive infinity', None
    if lower in ('-inf', '-infinity'):
        return 'negative infinity', None
    try:
        value = Decimal(token)
    except InvalidOperation as error:
        raise AssertionError(f'invalid numeric token: {token}') from error
    assert value.is_finite(), f'unclassified numeric token: {token}'
    return 'finite', value


def six_significant(value):
    if value.is_zero():
        return Decimal(0)
    return value.quantize(Decimal(1).scaleb(value.adjusted() - 5), rounding=ROUND_HALF_EVEN)


def same_float(actual, expected, context):
    aclass, a = numeric(actual)
    eclass, e = numeric(expected)
    assert aclass == eclass, f'{context}: class {actual} != {expected}'
    if eclass != 'finite':
        return
    if e.is_zero():
        assert a.is_zero(), f'{context}: nonzero {actual} replaced source zero'
    else:
        assert not a.is_zero() and a.is_signed() == e.is_signed(), f'{context}: sign/nonzero {actual} != {expected}'
        assert six_significant(a) == e, f'{context}: source printed stage {actual} != {expected}'


def dosage_units(token):
    kind, value = numeric(token)
    assert kind == 'finite' and value >= 0, f'invalid allele count: {token}'
    units = (value * 32768).to_integral_value(rounding=ROUND_HALF_UP)
    assert abs(value - units / 32768) <= Decimal('0.000005'), f'dosage token does not resolve source grid: {token}'
    return int(units)


def compare_report(actual, expected, *, projection=False):
    aheader, arows = table(actual)
    eheader, erows = table(expected)
    assert set(eheader).issubset(aheader) if projection else aheader == eheader, f'{actual}: header mismatch\n{aheader}\n{eheader}'
    assert len(arows) == len(erows), f'{actual}: rows {len(arows)} != {len(erows)}'
    for index, (a, e) in enumerate(zip(arows, erows)):
        for key in eheader:
            context = f'{actual} row{index + 1} {key}'
            if key in FLOAT_COLUMNS:
                same_float(a[key], e[key], context)
            elif key in ('REF_CT', 'ALT_CTS'):
                av, ev = a[key].split(','), e[key].split(',')
                assert len(av) == len(ev), f'{context}: allele count width'
                assert list(map(dosage_units, av)) == list(map(dosage_units, ev)), f'{context}: exact dosage units {av} != {ev}'
            elif key in INTEGER_COLUMNS:
                av, ev = a[key].split(','), e[key].split(',')
                assert len(av) == len(ev) and [int(x) for x in av] == [int(x) for x in ev], f'{context}: exact counts {av} != {ev}'
            elif key in CATEGORY_COLUMNS:
                assert a[key] == e[key], f'{context}: identity {a[key]} != {e[key]}'
            else:
                raise AssertionError(f'{context}: schema column has no frozen comparison policy')
    return len(arows)


def compare_metadata(actual_prefix, expected_prefix):
    identities = {}
    for extension in ('psam', 'pvar'):
        aheader, arows = table(f'{actual_prefix}.{extension}')
        eheader, erows = table(f'{expected_prefix}.{extension}')
        assert set(eheader).issubset(aheader), f'{actual_prefix}.{extension}: missing source metadata columns'
        assert len(arows) == len(erows), f'{actual_prefix}.{extension}: shape mismatch'
        for index, (a, e) in enumerate(zip(arows, erows)):
            if extension == 'psam':
                for key in ('FID', 'IID', 'SID', 'PAT', 'MAT', 'SEX'):
                    av, ev = a.get(key, '0'), e.get(key, '0')
                    if key == 'SEX':
                        av, ev = ('0' if av == 'NA' else av), ('0' if ev == 'NA' else ev)
                    assert av == ev, f'{actual_prefix}.psam row{index + 1} {key}: identity/default mismatch'
            for key in eheader:
                av, ev = a[key], e[key]
                if key == 'SEX':
                    av, ev = ('0' if av == 'NA' else av), ('0' if ev == 'NA' else ev)
                assert av == ev, f'{actual_prefix}.{extension} row{index + 1} {key}: {av} != {ev}'
        if extension == 'psam':
            keys = [tuple(row.get(key, '0') for key in ('FID', 'IID', 'SID')) for row in arows]
            assert len(set(keys)) == len(keys), f'{actual_prefix}: duplicate sample identity'
            identities['samples'] = keys
        else:
            identities['variants'] = [tuple(row[key] for key in ('CHROM', 'POS', 'ID', 'REF', 'ALT')) for row in arows]
    return identities


def snapshot(prefix):
    return {extension: sha256(f'{prefix}.{extension}') for extension in ('pgen', 'pvar', 'psam', 'rsomics.json')}


def verify_expected(root):
    root = Path(root)
    binding = json.loads((root / 'SOURCE.json').read_text())
    for item in binding['files']:
        path = root / item['path']
        assert path.stat().st_size == item['bytes'] and sha256(path) == item['sha256'], f'golden identity drift: {path}'
    for path in root.glob('*/[FP]/qc.acount'):
        _, rows = table(path)
        for row in rows:
            for key in ('REF_CT', 'ALT_CTS'):
                for token in row[key].split(','):
                    dosage_units(token)
    return binding
