# Frozen compact whole-workflow comparison policy

Frozen before the first native QC/LD result on 2026-11-01. The accepted source
authority is run41221033473/attempt1, source commit
cc2c95e61c509d49aaf884d2ec0956a921770745 and source engine
ec93f5a85e2d788acc40e808566e054eca89daae8f83af561ffcf557db75edba.
Expected files are original-body/CAPTURE-bound derivatives; see
fixtures/expected/SOURCE.json. The generator, source flags, golden files and
this policy are not tuned after seeing native outcomes.

## Connected state, identity and exact values

The driver imports native I, makes native F, runs QC and LD/prune on native F,
extracts the native emitted prune.in to native P, and freshly reopens/re-QCs
native P. The PGEN lane imports the native GT lane's I, not an expected fileset.
Expected F/P datasets are comparison data only and never input to native work.
Snapshot native generation hashes before/after downstream operations.

All six I/F/P shapes, sample tuples and their order, parental/sex values,
variant CHROM/POS/ID/REF/ordered ALT values and their order, provisional REF,
every hardcall/raw phase/phase orientation/dosage/dphase presence and integer
payload are exact. P raw state is also the exact ordered projection of native F
by native prune.in. Missing FID/SID/PAT/MAT have format defaults0; SEX0/NA denote
the same unknown-sex value. Native extra preserved metadata columns are checked
against the input and unchanged native ancestors; they are not discarded merely
because source make omits all-default optional columns. PVAR INFO/PR is combined
with the codec's reference status, not treated as contradictory redundant text.
No binary-PGEN byte-identity requirement is imposed on different compressors.

Principal reports require the exact captured header, row count, row order and
every column. Categorical identities/alleles/REF flags and integer scalar/list
counts are exact. Ordered prune.in and prune.out lists are exact (not sets).

For the dedicated unfiltered gt.I founder64 Hardy probe, source uses fewer
explicit columns than the main QC profile. Compare EVERY source probe row and
column against the matching native Hardy projection; native extra main-profile
columns are separately checked by native metadata and the other whole reports.
Do not substitute F/P populations for this probe. Its v12 raw MIDP must be
positive and is4.61606e-19 at source precision; log MIDP is18.3357. Zero is a
failure. The compact panel does not reach HWE underflow.

## Float classes and actual source printing

Classify finite, NaN, missing NA, positive infinity and negative infinity
separately. NaN sign/spelling are normalized; NA is not NaN. A source finite
zero requires an exact native numeric zero. Nonzero signs must agree.

Pinned plink2_string.h:1461-1476 and plink2_string.cc:dtoa_g/lntoa_g establish
SIX significant decimal digits, not fixed six decimal places. Main missingness,
heterozygosity expectations/F, Hardy observed/expected heterozygosity/MIDP/log,
LD nonmajor frequencies and unphased R2 use this contract. A full-precision
native finite number must round to the same six-significant-digit Decimal
value as the source token, using decimal nearest/even rounding. This is the
actual printed-stage comparison, including decade transitions; there is NO
absolute or relative epsilon. A native report already printed at source
precision compares numerically equal. This cannot accept zero for tiny P.

Allele count REF_CT/ALT_CTS use pinned plink2_common.h:471 ddosagetoa_full:
FIVE decimal places reconstruct the exact32768th-unit sums. Reconstruct the
unique nearest integer unit from each source/native token, require the token
to lie within half a source decimal unit of that exact grid value, then compare
the reconstructed integer units exactly. Integers remain exact integer units.
This handles genuine dosage counts without a broad float tolerance or loss of
the underlying quantized sum. Comma-list shape/order is exact.

Every other report column is exact. Unknown report columns or schemas fail
rather than silently entering a generic numeric tolerance.

## Expected principal coverage

For every F/P: complete acount/gcount/scount/smiss/vmiss/het, complete raw Hardy
for non-rich lanes, and complete explicit-autosomal-biallelic log-Hardy for all
six lanes. Rich main QC retains all variants; its extra native raw Hardy uses
the same named restricted scope and is not passed off as multiallelic/X HWE.
For every F: all pair rows and both ordered prune lists. Every I/F/P raw cell
and ordered metadata row is compared with the captured source generation.

Native requested1/4 workers must produce the same principal values, lists and
raw states; command results separately report requested/effective compute and
single writer workers. Four native hosts, source cross-read of these same new
native files, representative real-cohort performance and package/relink gates
remain later root-owned acceptance, not claims made by this compact driver.
