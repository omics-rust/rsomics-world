# Third-party codec source

PLINK2 pgenlib, source commit cc2c95e61c509d49aaf884d2ec0956a921770745,
copyright Shaun Purcell, Christopher Chang and Benjamin Demaille, is used as
an external compressed PGEN codec. Its 12 source/header files retain their
LGPL-3.0-or-later notices without modification. Full GPLv3 and LGPLv3 texts
are in vendor/pgenlib/COPYING and vendor/pgenlib/COPYING.LESSER.

The 15 bundled SIMDe closure headers retain their exact original notices:
nine MIT headers and six CC0-1.0 headers (check.h, debug-trap.h, hedley.h,
simde-align.h, simde-arch.h, simde-detect-clang.h). The MIT text is retained
at vendor/pgenlib/simde/COPYING; each CC0 header retains its authors' waiver
and the Creative Commons Zero 1.0 Universal reference.

vendor/SOURCE.json binds every original body to its exact accepted source
capture. scripts/vendor_from_capture.py reproduces the narrowly selected
source/license closure, not the PLINK command implementation. Rust code uses
the upstream format, documented policies and source behavior as reference;
the original GPL PLINK CLI/policy implementation is not transplanted.

native/pgen_shim.h and native/pgen_shim.cc are new LGPL-3.0-or-later adapter
files; no vendored original was patched. Future modifications must be marked
and retained with the exact source. A distribution still requires the root's
full corresponding-source/application-code and replace-library/relink gate;
these notices alone do not qualify a release.
