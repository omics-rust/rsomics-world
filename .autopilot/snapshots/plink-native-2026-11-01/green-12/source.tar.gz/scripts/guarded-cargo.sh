#!/bin/bash
set -euo pipefail
export CARGO_HOME=/Volumes/KIOXIA/Developments/cargo-home
export CARGO_TARGET_DIR=/Volumes/KIOXIA/Developments/cargo-target/rsomics-plink
export RSOMICS_GUARDED_TARGET_DIR="$CARGO_TARGET_DIR"
export RUSTUP_HOME=/Volumes/KIOXIA/Developments/rustup-home
export TMPDIR=/Volumes/KIOXIA/Developments/tmp
export XDG_CACHE_HOME=/Volumes/KIOXIA/Developments/tmp/cache
export CLANG_MODULE_CACHE_PATH=/Volumes/KIOXIA/Developments/tmp/clang-modules-plink
export CCACHE_DIR=/Volumes/KIOXIA/Developments/tmp/ccache-plink
export SCCACHE_DIR=/Volumes/KIOXIA/Developments/tmp/sccache-plink
export PYTHONDONTWRITEBYTECODE=1
toolchain=/Volumes/KIOXIA/Developments/rustup-home/toolchains/1.91.0-aarch64-apple-darwin/bin
export CARGO="$toolchain/cargo" RUSTC="$toolchain/rustc" RUSTDOC="$toolchain/rustdoc" RUSTFMT="$toolchain/rustfmt"
export PATH="$toolchain:$PATH"
export CARGO_BUILD_JOBS=2
for name in CARGO_BUILD_TARGET RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS CXX CXXFLAGS CPPFLAGS CC CFLAGS CXXSTDLIB HOST_CXX HOST_CC HOST_CXXFLAGS HOST_CFLAGS TARGET_CXX TARGET_CC TARGET_CXXFLAGS TARGET_CFLAGS CC_KNOWN_WRAPPER_CUSTOM CC_FORCE_DISABLE CC_SHELL_ESCAPED_FLAGS; do
  if [[ -n "${!name:-}" ]]; then echo "Unsupported compiler/target override: $name" >&2; exit 1; fi
done
while IFS='=' read -r name value; do
  case "$name" in CXX_*|CC_*|CXXFLAGS_*|CPPFLAGS_*|CFLAGS_*) echo "Unsupported native override: $name" >&2; exit 1;; esac
done < <(env)
/usr/sbin/diskutil info -plist /Volumes/KIOXIA | /usr/bin/python3 -c '
import plistlib,sys
v=plistlib.loads(sys.stdin.buffer.read())
if v.get("MountPoint")!="/Volumes/KIOXIA" or v.get("Internal") is not False:
    sys.exit("KIOXIA is not externally mounted")
print("verified external device:",v["DeviceNode"])
'
device=$(stat -f %d /Volumes/KIOXIA)
for path in "$CARGO_HOME" "$RUSTUP_HOME" "$TMPDIR" "$toolchain"; do
  test -d "$path"
  test "$(stat -f %d "$path")" = "$device"
done
mkdir -p "$CARGO_TARGET_DIR" "$XDG_CACHE_HOME" "$CLANG_MODULE_CACHE_PATH" "$CCACHE_DIR" "$SCCACHE_DIR"
for path in "$CARGO_HOME" "$CARGO_TARGET_DIR" "$RUSTUP_HOME" "$TMPDIR" "$toolchain" "$XDG_CACHE_HOME" "$CLANG_MODULE_CACHE_PATH" "$CCACHE_DIR" "$SCCACHE_DIR"; do
  resolved=$(cd "$path" && pwd -P)
  case "$resolved" in /Volumes/KIOXIA/Developments/*) ;; *) echo "Forbidden path: $resolved" >&2; exit 1;; esac
  test "$(stat -f %d "$resolved")" = "$device"
  echo "verified external path: $resolved"
done
for argument in "$@"; do
  case "$argument" in --target-dir|--target-dir=*|--config|--config=*) echo "Storage overrides forbidden" >&2; exit 1;; esac
done
df -h /Volumes/KIOXIA
target=$("$CARGO" metadata --no-deps --format-version 1 | /usr/bin/python3 -c 'import json,sys;print(json.load(sys.stdin)["target_directory"])')
test "$target" = "$CARGO_TARGET_DIR"
echo "Cargo resolved target: $target"
case "${1:-}" in
  --exec) shift; exec "$@";;
  clippy) shift; exec "$toolchain/cargo-clippy" clippy "$@";;
  fmt) shift; exec "$toolchain/cargo-fmt" fmt "$@";;
  *) exec "$CARGO" "$@";;
esac
