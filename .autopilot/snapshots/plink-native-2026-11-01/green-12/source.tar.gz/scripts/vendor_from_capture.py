import hashlib
import json
from pathlib import Path
import tarfile

owner = Path(__file__).resolve().parents[1]
packet = Path('/Volumes/KIOXIA/Developments/tmp/plink-native-codec-plan-20261101.mp78r1')
archive_path = Path("/Volumes/Zane's HDD/rsomics-fixtures/evidence/plink-first-workflow-oracle-2026-11-01/run-41221033473/plink-first-workflow-oracle.tar")
closure = json.loads((packet / 'codec-include-closure-final.json').read_text())
source_prefix = 'plink-first-workflow-oracle/runtime/source/'
scratch = Path('/Volumes/KIOXIA/Developments/tmp/plink-native-primary-20261101')

def materialize(target, body):
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == body, target
    else:
        target.write_bytes(body)

with tarfile.open(archive_path) as archive:
    capture = json.load(archive.extractfile('plink-first-workflow-oracle/CAPTURE.json'))['files']
    names = sorted(closure['license_headers'])
    names += ['2.0/COPYING', '2.0/COPYING.LESSER', '2.0/simde/COPYING']
    bindings = []
    for name in names:
        body = archive.extractfile(source_prefix + name).read()
        expected = capture['runtime/source/' + name]
        sha = hashlib.sha256(body).hexdigest()
        assert len(body) == expected['bytes'] and sha == expected['sha256']
        relative = name.removeprefix('2.0/')
        materialize(owner / 'vendor/pgenlib' / relative, body)
        bindings.append(dict(path='vendor/pgenlib/' + relative, bytes=len(body), sha256=sha,
                             license=closure['license_headers'].get(name, 'license text')))
    for name in ['2.0/plink2_import.cc', '2.0/include/pgenlib_ffi_support.cc']:
        materialize(scratch / Path(name).name, archive.extractfile(source_prefix + name).read())
    for item in archive.getmembers():
        if item.isfile() and item.name.startswith('plink-first-workflow-oracle/inputs/'):
            materialize(owner / 'tests/fixtures/inputs' / Path(item.name).name, archive.extractfile(item).read())
    fixture_bindings = []
    for lane in ['gt', 'bed', 'pgen', 'ds', 'hds', 'rich']:
        entries = [(f'oracle/source/1/{lane}/I/data.{ext}', f'{lane}/data.{ext}') for ext in ['pgen', 'pvar', 'psam']]
        entries.append((f'oracle/source/1/calls/{lane}.I.decode/stdout.txt', f'{lane}/raw.jsonl'))
        for source, target in entries:
            body = archive.extractfile('plink-first-workflow-oracle/' + source).read()
            sha = hashlib.sha256(body).hexdigest()
            assert capture[source]['bytes'] == len(body) and capture[source]['sha256'] == sha
            materialize(owner / 'tests/fixtures/oracle' / target, body)
            fixture_bindings.append(dict(source=source, path=target, bytes=len(body), sha256=sha))
    expected_bindings = []
    for lane in ['gt', 'bed', 'pgen', 'ds', 'hds', 'rich']:
        for generation in ['I', 'F', 'P']:
            entries = [(f'oracle/source/1/{lane}/{generation}/data.{ext}', f'{lane}/{generation}/data.{ext}') for ext in ['pvar', 'psam']]
            entries.append((f'oracle/source/1/calls/{lane}.{generation}.decode/stdout.txt', f'{lane}/{generation}/raw.jsonl'))
            if generation != 'I':
                for ext in ['acount', 'gcount', 'scount', 'smiss', 'vmiss', 'het'] + ([] if lane == 'rich' else ['hardy']):
                    entries.append((f'oracle/source/1/{lane}/{generation}/reports/qc.{ext}', f'{lane}/{generation}/qc.{ext}'))
                entries.append((f'oracle/source/1/{lane}/{generation}/reports/hwe-log.hardy', f'{lane}/{generation}/hwe-log.hardy'))
            if generation == 'F':
                entries.extend((f'oracle/source/1/{lane}/F/ld/{name}', f'{lane}/F/{name}') for name in ['pairs.vcor', 'prune.prune.in', 'prune.prune.out'])
            for source, target in entries:
                body = archive.extractfile('plink-first-workflow-oracle/' + source).read()
                sha = hashlib.sha256(body).hexdigest()
                assert capture[source]['bytes'] == len(body) and capture[source]['sha256'] == sha
                materialize(owner / 'tests/fixtures/expected' / target, body)
                expected_bindings.append(dict(source=source, path=target, bytes=len(body), sha256=sha))
    for name in ['raw.hardy', 'log.hardy']:
        source = 'oracle/source/1/probes/tail/' + name
        body = archive.extractfile('plink-first-workflow-oracle/' + source).read()
        sha = hashlib.sha256(body).hexdigest()
        assert capture[source]['bytes'] == len(body) and capture[source]['sha256'] == sha
        materialize(owner / 'tests/fixtures/expected/tail' / name, body)
        expected_bindings.append(dict(source=source, path='tail/' + name, bytes=len(body), sha256=sha))
    materialize(owner / 'tests/fixtures/expected/SOURCE.json', (json.dumps(dict(
        capture='run-41221033473', source_engine='ec93f5a85e2d788acc40e808566e054eca89daae8f83af561ffcf557db75edba',
        role='comparison only; native I/F/P feed all native descendants', files=expected_bindings), indent=2, sort_keys=True) + '\n').encode())
    external_bindings = []
    for name in ['pgen', 'pgen.pgi', 'pvar', 'psam']:
        source = 'oracle/source/1/mutations/external/data.' + name
        body = archive.extractfile('plink-first-workflow-oracle/' + source).read()
        sha = hashlib.sha256(body).hexdigest()
        assert capture[source]['bytes'] == len(body) and capture[source]['sha256'] == sha
        materialize(owner / 'tests/fixtures/external' / ('data.' + name), body)
        external_bindings.append(dict(source=source, path='data.' + name, bytes=len(body), sha256=sha))
    source = 'oracle/source/1/mutation-calls/mutation.external-index/stdout.txt'
    body = archive.extractfile('plink-first-workflow-oracle/' + source).read()
    sha = hashlib.sha256(body).hexdigest()
    assert capture[source]['bytes'] == len(body) and capture[source]['sha256'] == sha
    materialize(owner / 'tests/fixtures/external/raw.jsonl', body)
    materialize(owner / 'tests/fixtures/external/raw-SOURCE.json', (json.dumps(dict(
        capture='run-41221033473', source=source, path='raw.jsonl', bytes=len(body), sha256=sha),
        indent=2, sort_keys=True) + '\n').encode())
    materialize(owner / 'tests/fixtures/external/SOURCE.json', (json.dumps(dict(
        capture='run-41221033473', role='existing accepted external-index PGEN input probe',
        files=external_bindings), indent=2, sort_keys=True) + '\n').encode())
    materialize(owner / 'tests/fixtures/oracle/SOURCE.json', (json.dumps(dict(
        capture='run-41221033473', source_engine='ec93f5a85e2d788acc40e808566e054eca89daae8f83af561ffcf557db75edba',
        files=fixture_bindings), indent=2, sort_keys=True) + '\n').encode())
    materialize(owner / 'vendor/SOURCE.json', (json.dumps(dict(
        source='https://github.com/chrchang/plink-ng',
        commit='cc2c95e61c509d49aaf884d2ec0956a921770745',
        capture='run-41221033473', files=bindings), indent=2, sort_keys=True) + '\n').encode())
print('materialized exact 27-file codec closure, license texts, engineering inputs and primary importer')
