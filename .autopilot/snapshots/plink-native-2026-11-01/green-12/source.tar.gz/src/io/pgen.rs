use crate::dataset::{
    GenotypeReader, VariantId, genotypes::Genotypes, metadata::Metadata, sibling,
};
use crate::{Result, invalid};
use std::os::unix::ffi::OsStrExt;
use std::{
    ffi::{CStr, CString, c_char, c_void},
    path::Path,
    ptr,
    sync::Mutex,
};

// pgenlib's allocation-failure diagnostic is process-global and non-atomic.
static READER_INIT: Mutex<()> = Mutex::new(());

#[repr(C)]
#[derive(Default)]
struct RawView {
    samples: u32,
    alleles: u32,
    provisional_ref: u32,
    reference_mode: u32,
    genotype_words: u32,
    mask_words: u32,
    patch01_count: u32,
    patch10_count: u32,
    phase_count: u32,
    dosage_count: u32,
    dphase_count: u32,
    genotypes: *const u64,
    patch01: *const u64,
    patch10: *const u64,
    patch01_values: *const u8,
    patch10_values: *const u8,
    phase_present: *const u64,
    phase_info: *const u64,
    dosage_present: *const u64,
    dphase_present: *const u64,
    dosages: *const u16,
    dphase: *const i16,
}
unsafe extern "C" {
    fn rs_pg_abi_version() -> u32;
    fn rs_pg_index_open(
        path: *const c_char,
        samples: u32,
        variants: u32,
        offsets: *const u64,
        budget: u64,
        out: *mut *mut c_void,
        workspace: *mut u64,
        reader_workspace: *mut u64,
        error: *mut c_char,
        cap: usize,
    ) -> i32;
    fn rs_pg_index_close(index: *mut c_void, error: *mut c_char, cap: usize) -> i32;
    fn rs_pg_reader_open(
        index: *mut c_void,
        out: *mut *mut c_void,
        error: *mut c_char,
        cap: usize,
    ) -> i32;
    fn rs_pg_read(
        reader: *mut c_void,
        variant: u32,
        out: *mut RawView,
        error: *mut c_char,
        cap: usize,
    ) -> i32;
    fn rs_pg_reader_close(reader: *mut c_void, error: *mut c_char, cap: usize) -> i32;
    fn rs_pg_reference_flags(
        reader: *mut c_void,
        flags: *mut u64,
        words: u32,
        mode: *mut u32,
        error: *mut c_char,
        cap: usize,
    ) -> i32;
    fn rs_pg_track_flags(
        reader: *mut c_void,
        flags: *mut u32,
        error: *mut c_char,
        cap: usize,
    ) -> i32;
    fn rs_pg_writer_open(
        path: *const c_char,
        samples: u32,
        variants: u32,
        offsets: *const u64,
        provisional: *const u64,
        flags: u32,
        out: *mut *mut c_void,
        workspace: *mut u64,
        error: *mut c_char,
        cap: usize,
    ) -> i32;
    fn rs_pg_append(
        writer: *mut c_void,
        view: *const RawView,
        error: *mut c_char,
        cap: usize,
    ) -> i32;
    fn rs_pg_writer_finish(writer: *mut c_void, error: *mut c_char, cap: usize) -> i32;
    fn rs_pg_writer_abort(writer: *mut c_void);
}
fn path_string(path: &Path) -> Result<CString> {
    CString::new(path.as_os_str().as_bytes()).map_err(|_| invalid("path contains a zero byte"))
}
fn checked(status: i32, error: &[c_char]) -> Result<()> {
    if status == 0 {
        Ok(())
    } else {
        Err(invalid(
            unsafe { CStr::from_ptr(error.as_ptr()) }
                .to_string_lossy()
                .into_owned(),
        ))
    }
}

struct IndexHandle(Option<*mut c_void>);
// Only the locked factory mutates the header FILE; readers borrow immutable arrays.
unsafe impl Send for IndexHandle {}

pub(crate) struct Prepared {
    handle: Mutex<IndexHandle>,
    shared_bytes: usize,
    reader_bytes: usize,
    provisional: Vec<bool>,
    track_flags: u32,
}
impl Prepared {
    pub fn open(prefix: &Path, metadata: &Metadata, budget: usize) -> Result<Self> {
        let count = metadata.variants.len();
        let rust_bytes = count
            .checked_add((count + 1).saturating_mul(8))
            .and_then(|n| n.checked_add(count.div_ceil(64) * 8))
            .and_then(|n| {
                n.checked_add(std::mem::size_of::<Self>() + prefix.as_os_str().len() + 16)
            })
            .ok_or_else(|| invalid("PGEN index memory estimate overflow"))?;
        let native_budget = budget
            .checked_sub(rust_bytes)
            .ok_or_else(|| invalid("PGEN index exceeds memory budget"))?;
        let path = path_string(&sibling(prefix, "pgen"))?;
        let offsets = metadata.offsets();
        let mut handle = ptr::null_mut();
        let mut workspace = 0;
        let mut reader_workspace = 0;
        let mut error = [0; 2048];
        if unsafe { rs_pg_abi_version() } != 4 {
            return Err(invalid("PGEN codec ABI mismatch"));
        }
        let initialization = READER_INIT
            .lock()
            .map_err(|_| invalid("codec initialization lock poisoned"))?;
        let status = unsafe {
            rs_pg_index_open(
                path.as_ptr(),
                metadata.samples.len() as u32,
                metadata.variants.len() as u32,
                offsets.as_ptr(),
                native_budget as u64,
                &mut handle,
                &mut workspace,
                &mut reader_workspace,
                error.as_mut_ptr(),
                error.len(),
            )
        };
        drop(initialization);
        checked(status, &error)?;
        let mut prepared = Self {
            handle: Mutex::new(IndexHandle(Some(handle))),
            shared_bytes: workspace as usize + std::mem::size_of::<Self>() + count,
            reader_bytes: reader_workspace as usize + std::mem::size_of::<Reader<'_>>(),
            provisional: Vec::with_capacity(metadata.variants.len()),
            track_flags: 0,
        };
        let mut flags = vec![0u64; metadata.variants.len().div_ceil(64)];
        let mut mode = 0;
        checked(
            unsafe {
                rs_pg_reference_flags(
                    handle,
                    flags.as_mut_ptr(),
                    flags.len() as u32,
                    &mut mode,
                    error.as_mut_ptr(),
                    error.len(),
                )
            },
            &error,
        )?;
        checked(
            unsafe {
                rs_pg_track_flags(
                    handle,
                    &mut prepared.track_flags,
                    error.as_mut_ptr(),
                    error.len(),
                )
            },
            &error,
        )?;
        for (index, variant) in metadata.variants.iter().enumerate() {
            let binary = crate::dataset::genotypes::bit(&flags, index);
            if mode != 0 && variant.provisional_ref && !binary {
                return Err(invalid("PVAR provisional REF contradicts PGEN header"));
            }
            prepared
                .provisional
                .push(binary || (mode == 0 && variant.provisional_ref));
        }
        Ok(prepared)
    }
    pub fn resolved_reference(&self) -> &[bool] {
        &self.provisional
    }
    pub fn shared_bytes(&self) -> usize {
        self.shared_bytes
    }
    pub fn reader_bytes(&self) -> usize {
        self.reader_bytes
    }
    pub fn reader(&self) -> Result<Reader<'_>> {
        let factory = self
            .handle
            .lock()
            .map_err(|_| invalid("PGEN factory lock poisoned"))?;
        let index = factory.0.ok_or_else(|| invalid("PGEN source closed"))?;
        let initialization = READER_INIT
            .lock()
            .map_err(|_| invalid("codec initialization lock poisoned"))?;
        let mut handle = ptr::null_mut();
        let mut error = [0; 2048];
        checked(
            unsafe { rs_pg_reader_open(index, &mut handle, error.as_mut_ptr(), error.len()) },
            &error,
        )?;
        drop(initialization);
        Ok(Reader {
            handle: Some(handle),
            prepared: self,
        })
    }
    pub fn close(&mut self) -> Result<()> {
        let factory = self.handle.get_mut().unwrap_or_else(|e| e.into_inner());
        if let Some(handle) = factory.0.take() {
            let mut error = [0; 2048];
            checked(
                unsafe { rs_pg_index_close(handle, error.as_mut_ptr(), error.len()) },
                &error,
            )
        } else {
            Ok(())
        }
    }
}
impl Drop for Prepared {
    fn drop(&mut self) {
        let _ = self.close();
    }
}

pub(crate) struct Reader<'a> {
    handle: Option<*mut c_void>,
    prepared: &'a Prepared,
}
impl Reader<'_> {
    fn close_handle(&mut self) -> Result<()> {
        if let Some(handle) = self.handle.take() {
            let mut error = [0; 2048];
            checked(
                unsafe { rs_pg_reader_close(handle, error.as_mut_ptr(), error.len()) },
                &error,
            )
        } else {
            Ok(())
        }
    }
}
impl GenotypeReader for Reader<'_> {
    fn read(&mut self, variant: VariantId) -> Result<Genotypes> {
        let mut value = Genotypes::empty(0, 2, false);
        self.read_into(variant, &mut value)?;
        Ok(value)
    }
    fn track_flags(&self) -> Option<u32> {
        Some(self.prepared.track_flags)
    }
    fn read_into(&mut self, variant: VariantId, value: &mut Genotypes) -> Result<()> {
        let handle = self.handle.ok_or_else(|| invalid("reader closed"))?;
        let mut raw = RawView::default();
        let mut error = [0; 2048];
        checked(
            unsafe {
                rs_pg_read(
                    handle,
                    variant.0 as u32,
                    &mut raw,
                    error.as_mut_ptr(),
                    error.len(),
                )
            },
            &error,
        )?;
        unsafe fn reuse<T: Copy>(value: &mut Vec<T>, pointer: *const T, length: usize) {
            value.clear();
            if length != 0 {
                value.extend_from_slice(unsafe { std::slice::from_raw_parts(pointer, length) });
            }
        }
        value.samples = raw.samples as usize;
        value.allele_count = raw.alleles as usize;
        value.provisional_ref = self.prepared.provisional[variant.0];
        // Codec views expire on the next read; only owned buffers escape this call.
        unsafe {
            reuse(
                &mut value.genotypes,
                raw.genotypes,
                raw.genotype_words as usize,
            );
            reuse(&mut value.patch01, raw.patch01, raw.mask_words as usize);
            reuse(&mut value.patch10, raw.patch10, raw.mask_words as usize);
            reuse(
                &mut value.patch01_values,
                raw.patch01_values,
                raw.patch01_count as usize,
            );
            reuse(
                &mut value.patch10_values,
                raw.patch10_values,
                raw.patch10_count as usize * 2,
            );
            reuse(
                &mut value.phase_present,
                raw.phase_present,
                raw.mask_words as usize,
            );
            reuse(
                &mut value.phase_info,
                raw.phase_info,
                raw.mask_words as usize,
            );
            reuse(
                &mut value.dosage_present,
                raw.dosage_present,
                raw.mask_words as usize,
            );
            reuse(&mut value.dosages, raw.dosages, raw.dosage_count as usize);
            reuse(
                &mut value.dphase_present,
                raw.dphase_present,
                raw.mask_words as usize,
            );
            reuse(&mut value.dphase, raw.dphase, raw.dphase_count as usize);
        }
        if !value.samples.is_multiple_of(32) {
            let n = value.genotypes.len() - 1;
            value.genotypes[n] &= (1u64 << (2 * (value.samples % 32))) - 1;
        }
        if !value.samples.is_multiple_of(64) {
            let mask = (1u64 << (value.samples % 64)) - 1;
            for words in [
                &mut value.patch01,
                &mut value.patch10,
                &mut value.phase_present,
                &mut value.phase_info,
                &mut value.dosage_present,
                &mut value.dphase_present,
            ] {
                let n = words.len() - 1;
                words[n] &= mask;
            }
        }
        Ok(())
    }
    fn workspace_bytes(&self) -> usize {
        self.prepared.reader_bytes
    }
    fn close(mut self: Box<Self>) -> Result<()> {
        self.close_handle()
    }
}
impl Drop for Reader<'_> {
    fn drop(&mut self) {
        let _ = self.close_handle();
    }
}

pub(crate) struct Writer {
    handle: Option<*mut c_void>,
    workspace: usize,
}
impl Writer {
    pub fn open(
        path: &Path,
        samples: usize,
        offsets: &[u64],
        provisional: &[bool],
        flags: u32,
    ) -> Result<Self> {
        let path = path_string(path)?;
        let mut mask = vec![0u64; provisional.len().div_ceil(64)];
        for (i, &value) in provisional.iter().enumerate() {
            if value {
                crate::dataset::genotypes::set(&mut mask, i);
            }
        }
        let mut handle = ptr::null_mut();
        let mut workspace = 0;
        let mut error = [0; 2048];
        checked(
            unsafe {
                rs_pg_writer_open(
                    path.as_ptr(),
                    samples as u32,
                    provisional.len() as u32,
                    offsets.as_ptr(),
                    mask.as_ptr(),
                    flags,
                    &mut handle,
                    &mut workspace,
                    error.as_mut_ptr(),
                    error.len(),
                )
            },
            &error,
        )?;
        Ok(Self {
            handle: Some(handle),
            workspace: workspace as usize + std::mem::size_of::<Self>(),
        })
    }
    pub fn workspace_bytes(&self) -> usize {
        self.workspace
    }
    pub fn append(&mut self, v: &Genotypes) -> Result<()> {
        let raw = RawView {
            samples: v.samples as u32,
            alleles: v.allele_count as u32,
            provisional_ref: u32::from(v.provisional_ref),
            reference_mode: 3,
            genotype_words: v.genotypes.len() as u32,
            mask_words: v.phase_present.len() as u32,
            patch01_count: v.patch01_values.len() as u32,
            patch10_count: (v.patch10_values.len() / 2) as u32,
            phase_count: v.phase_count() as u32,
            dosage_count: v.dosages.len() as u32,
            dphase_count: v.dphase.len() as u32,
            genotypes: v.genotypes.as_ptr(),
            patch01: v.patch01.as_ptr(),
            patch10: v.patch10.as_ptr(),
            patch01_values: v.patch01_values.as_ptr(),
            patch10_values: v.patch10_values.as_ptr(),
            phase_present: v.phase_present.as_ptr(),
            phase_info: v.phase_info.as_ptr(),
            dosage_present: v.dosage_present.as_ptr(),
            dphase_present: v.dphase_present.as_ptr(),
            dosages: v.dosages.as_ptr(),
            dphase: v.dphase.as_ptr(),
        };
        let mut error = [0; 2048];
        checked(
            unsafe {
                rs_pg_append(
                    self.handle.ok_or_else(|| invalid("writer closed"))?,
                    &raw,
                    error.as_mut_ptr(),
                    error.len(),
                )
            },
            &error,
        )
    }
    pub fn finish(mut self) -> Result<()> {
        let handle = self.handle.take().ok_or_else(|| invalid("writer closed"))?;
        let mut error = [0; 2048];
        checked(
            unsafe { rs_pg_writer_finish(handle, error.as_mut_ptr(), error.len()) },
            &error,
        )
    }
}
impl Drop for Writer {
    fn drop(&mut self) {
        if let Some(handle) = self.handle.take() {
            unsafe { rs_pg_writer_abort(handle) }
        }
    }
}
