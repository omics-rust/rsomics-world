use crate::{Result, invalid};
use std::num::NonZeroUsize;

pub(crate) struct Execution {
    pub requested_workers: usize,
    pub memory_bytes: usize,
    pub pool: rayon::ThreadPool,
}
impl Execution {
    pub fn new(workers: Option<NonZeroUsize>, memory_mib: usize) -> Result<Self> {
        let requested_workers = workers
            .unwrap_or_else(|| std::thread::available_parallelism().unwrap_or(NonZeroUsize::MIN))
            .get();
        let memory_bytes = memory_mib
            .checked_mul(1024 * 1024)
            .ok_or_else(|| invalid("memory budget overflow"))?;
        if memory_bytes < 1024 * 1024 {
            return Err(invalid("memory budget must be at least one MiB"));
        }
        let pool = rayon::ThreadPoolBuilder::new()
            .num_threads(requested_workers)
            .build()
            .map_err(|e| invalid(format!("worker pool: {e}")))?;
        Ok(Self {
            requested_workers,
            memory_bytes,
            pool,
        })
    }
    pub fn batch_width(&self, workspace: usize, per_variant: usize) -> Result<usize> {
        let available = self
            .memory_bytes
            .checked_sub(workspace)
            .ok_or_else(|| invalid("reader workspace exceeds invocation memory budget"))?;
        let width = (available / per_variant.max(1)).min(1024);
        if width == 0 {
            Err(invalid("one variant exceeds remaining memory budget"))
        } else {
            Ok(width)
        }
    }
}
