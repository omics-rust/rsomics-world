mod cli;
mod dataset;
mod execution;
mod io;
mod ld;
mod make;
#[cfg(test)]
mod native_workflow;
mod numeric;
mod ordered;
mod stats;

pub(crate) use rsomics_common::Result;
pub(crate) fn invalid(message: impl Into<String>) -> rsomics_common::RsomicsError {
    rsomics_common::RsomicsError::InvalidInput(message.into())
}

pub fn run_cli() -> std::process::ExitCode {
    let cli = rsomics_help::parse::<cli::Cli>();
    rsomics_common::run(
        &cli.output,
        rsomics_common::ToolMeta {
            name: "rsomics-plink",
            version: env!("CARGO_PKG_VERSION"),
        },
        || {
            let execution = execution::Execution::new(cli.threads.requested(), cli.memory_mib)?;
            match cli.command {
                cli::Command::Make(args) => {
                    make::run(&args.config()?, &execution).map(CommandReport::Make)
                }
                cli::Command::Stats(args) => {
                    stats::run(&args.config(), &execution).map(CommandReport::Stats)
                }
                cli::Command::Ld(args) => match args.command {
                    cli::LdCommand::Pairs(args) => {
                        ld::pairs(&args.config(), &execution).map(CommandReport::Pairs)
                    }
                    cli::LdCommand::Prune(args) => {
                        ld::prune(&args.config(), &execution).map(CommandReport::Prune)
                    }
                },
            }
        },
    )
}

#[derive(serde::Serialize)]
#[serde(untagged)]
enum CommandReport {
    Make(make::GenerationReport),
    Stats(stats::QcReport),
    Pairs(ld::PairReport),
    Prune(ld::PruneReport),
}
