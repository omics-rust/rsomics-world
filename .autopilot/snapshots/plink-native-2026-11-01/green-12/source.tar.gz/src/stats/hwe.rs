use std::cmp::Ordering;

#[cfg(test)]
thread_local! {
    pub(crate) static LOG_ADDITIONS: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
}

fn log_add(a: f64, b: f64) -> f64 {
    #[cfg(test)]
    LOG_ADDITIONS.with(|count| count.set(count.get() + 1));
    if a == f64::NEG_INFINITY {
        return b;
    }
    if b == f64::NEG_INFINITY {
        return a;
    }
    let upper = a.max(b);
    upper + (a.min(b) - upper).exp().ln_1p()
}

#[derive(Default)]
struct Integer(Vec<u32>);

impl Integer {
    fn one() -> Self {
        Self(vec![1])
    }

    fn multiply(&mut self, factor: usize) {
        let mut carry = 0u128;
        for digit in &mut self.0 {
            let value = u128::from(*digit) * factor as u128 + carry;
            *digit = value as u32;
            carry = value >> 32;
        }
        while carry != 0 {
            self.0.push(carry as u32);
            carry >>= 32;
        }
    }

    fn power_two(&mut self, power: usize) {
        if power >= 32 {
            self.0.splice(0..0, std::iter::repeat_n(0, power / 32));
        }
        let shift = power % 32;
        if shift != 0 {
            self.multiply(1usize << shift);
        }
    }

    fn compare(&self, other: &Self) -> Ordering {
        self.0
            .len()
            .cmp(&other.0.len())
            .then_with(|| self.0.iter().rev().cmp(other.0.iter().rev()))
    }
}

fn exact_likelihood_order(observed: [usize; 3], candidate: [usize; 3]) -> Ordering {
    let mut numerator_args = observed;
    let mut denominator_args = candidate;
    numerator_args.sort_unstable();
    denominator_args.sort_unstable();
    let mut numerator = Integer::one();
    let mut denominator = Integer::one();
    for (a, b) in numerator_args.into_iter().zip(denominator_args) {
        if a > b {
            for factor in b + 1..=a {
                numerator.multiply(factor);
            }
        } else {
            for factor in a + 1..=b {
                denominator.multiply(factor);
            }
        }
    }
    if candidate[1] > observed[1] {
        numerator.power_two(candidate[1] - observed[1]);
    } else {
        denominator.power_two(observed[1] - candidate[1]);
    }
    numerator.compare(&denominator)
}

fn normal_weight(value: f64) -> Option<f64> {
    (value.is_normal() && value > 0.0).then_some(value)
}

fn mode_scaled_midp(observed: [usize; 3]) -> Option<f64> {
    let n = observed.iter().sum::<usize>();
    let rare = 2 * observed[0].min(observed[2]) + observed[1];
    if rare < 2 {
        return Some(-std::f64::consts::LN_2);
    }
    let mut mode = ((rare as u128 * (2 * n - rare) as u128) / (2 * n) as u128) as usize;
    if (mode ^ rare) & 1 != 0 {
        mode += 1;
    }
    let step_down = |h: usize| {
        let r = (rare - h) / 2;
        let c = n - h - r;
        (h as u128 * (h - 1) as u128) as f64 / (4 * (r + 1) as u128 * (c + 1) as u128) as f64
    };
    let step_up = |h: usize| {
        let r = (rare - h) / 2;
        let c = n - h - r;
        (4 * r as u128 * c as u128) as f64 / ((h + 2) as u128 * (h + 1) as u128) as f64
    };
    let mut observed_weight = 1.0;
    let mut h = mode;
    while h > observed[1] {
        observed_weight = normal_weight(observed_weight * step_down(h))?;
        h -= 2;
    }
    while h < observed[1] {
        observed_weight = normal_weight(observed_weight * step_up(h))?;
        h += 2;
    }
    let tie_window = 32.0 * f64::EPSILON * n.max(1) as f64;
    let lower = normal_weight(observed_weight * (-tie_window).exp())?;
    let upper = normal_weight(observed_weight * tie_window.exp())?;
    let observed_sorted = [
        observed[0].min(observed[2]),
        observed[1],
        observed[0].max(observed[2]),
    ];
    let mut total = 0.0;
    let mut tail = 0.0;
    let mut include = |h: usize, weight: f64| -> Option<()> {
        total = normal_weight(total + weight)?;
        let comparison = if h == observed[1] {
            Ordering::Equal
        } else if (lower..=upper).contains(&weight) {
            let r = (rare - h) / 2;
            exact_likelihood_order(observed_sorted, [r, h, n - h - r])
        } else if weight < observed_weight {
            Ordering::Less
        } else {
            Ordering::Greater
        };
        match comparison {
            Ordering::Less => tail = normal_weight(tail + weight)?,
            Ordering::Equal => tail = normal_weight(tail + normal_weight(weight * 0.5)?)?,
            Ordering::Greater => {}
        }
        Some(())
    };
    include(mode, 1.0)?;
    let mut weight = 1.0;
    let mut h = mode;
    while h >= 2 {
        weight = normal_weight(weight * step_down(h))?;
        h -= 2;
        include(h, weight)?;
    }
    weight = 1.0;
    h = mode;
    while h + 2 <= rare {
        weight = normal_weight(weight * step_up(h))?;
        h += 2;
        include(h, weight)?;
    }
    let logp = normal_weight(tail)?.ln() - total.ln();
    (logp.is_finite() && logp <= 0.0).then_some(logp)
}

pub(crate) fn midp_log(hom_ref: u64, het: u64, hom_alt: u64) -> f64 {
    mode_scaled_midp([hom_ref as usize, het as usize, hom_alt as usize])
        .unwrap_or_else(|| log_midp(hom_ref, het, hom_alt))
}

fn log_midp(hom_ref: u64, het: u64, hom_alt: u64) -> f64 {
    let observed = [hom_ref as usize, het as usize, hom_alt as usize];
    let n = observed.iter().sum::<usize>();
    let rare = 2 * observed[0].min(observed[2]) + observed[1];
    if rare < 2 {
        return -std::f64::consts::LN_2;
    }
    let mut mode = ((rare as u128 * (2 * n - rare) as u128) / (2 * n) as u128) as usize;
    if (mode ^ rare) & 1 != 0 {
        mode += 1;
    }
    let log_step_down = |h: usize| {
        let r = (rare - h) / 2;
        let c = n - h - r;
        (h as f64).ln() + ((h - 1) as f64).ln()
            - std::f64::consts::LN_2 * 2.0
            - ((r + 1) as f64).ln()
            - ((c + 1) as f64).ln()
    };
    let log_step_up = |h: usize| {
        let r = (rare - h) / 2;
        let c = n - h - r;
        std::f64::consts::LN_2 * 2.0 + (r as f64).ln() + (c as f64).ln()
            - ((h + 2) as f64).ln()
            - ((h + 1) as f64).ln()
    };
    let mut log_observed = 0.0;
    if observed[1] < mode {
        let mut h = mode;
        while h > observed[1] {
            log_observed += log_step_down(h);
            h -= 2;
        }
    } else {
        let mut h = mode;
        while h < observed[1] {
            log_observed += log_step_up(h);
            h += 2;
        }
    }
    let observed_sorted = [
        observed[0].min(observed[2]),
        observed[1],
        observed[0].max(observed[2]),
    ];
    let tie_window = 32.0 * f64::EPSILON * n.max(1) as f64;
    let mut total = f64::NEG_INFINITY;
    let mut tail = f64::NEG_INFINITY;
    let mut include = |h: usize, weight: f64| {
        total = log_add(total, weight);
        let comparison = if h == observed[1] {
            Ordering::Equal
        } else if (weight - log_observed).abs() <= tie_window {
            let r = (rare - h) / 2;
            exact_likelihood_order(observed_sorted, [r, h, n - h - r])
        } else if weight < log_observed {
            Ordering::Less
        } else {
            Ordering::Greater
        };
        match comparison {
            Ordering::Less => tail = log_add(tail, weight),
            Ordering::Equal => tail = log_add(tail, weight - std::f64::consts::LN_2),
            Ordering::Greater => {}
        }
    };
    include(mode, 0.0);
    let mut weight = 0.0;
    let mut h = mode;
    while h >= 2 {
        weight += log_step_down(h);
        h -= 2;
        include(h, weight);
    }
    weight = 0.0;
    h = mode;
    while h + 2 <= rare {
        weight += log_step_up(h);
        h += 2;
        include(h, weight);
    }
    (tail - total).min(0.0)
}
