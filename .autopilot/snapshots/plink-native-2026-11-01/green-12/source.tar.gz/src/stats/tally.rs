use crate::dataset::{
    chrom::Chromosome,
    genotypes::{Call, Genotypes},
    metadata::{Metadata, Sample, Sex, Variant},
};

#[derive(Default, Clone, Copy)]
pub(crate) struct Missing {
    pub hardcall: u64,
    pub dosage: u64,
    pub hethap: u64,
    pub observations: u64,
}

impl Missing {
    pub fn add(&mut self, call: Call, haploid: bool) {
        self.observations += 1;
        self.hardcall += u64::from(call.alleles.is_none());
        self.dosage += u64::from(call.alleles.is_none() && call.dosage.is_none());
        self.hethap += u64::from(haploid && call.alleles.is_some_and(|[a, b]| a != b));
    }
}

#[derive(Default, Clone)]
pub(crate) struct SampleTotals {
    pub hom_ref: u64,
    pub hom_alt: u64,
    pub het_ref_alt: u64,
    pub het_two_alt: u64,
    pub hap_ref: u64,
    pub hap_alt: u64,
    pub missing_calls: u64,
    pub missing: Missing,
    pub observed_het: u64,
    pub expected_het: f64,
    pub het_observations: u64,
}

pub(crate) fn missing_eligible(chrom: &Chromosome, sample: &Sample) -> bool {
    !matches!(chrom, Chromosome::Y) || sample.sex == Sex::Male
}

pub(crate) fn haploid(chrom: &Chromosome, sample: &Sample) -> bool {
    matches!(chrom, Chromosome::Y | Chromosome::Mt)
        || matches!(chrom, Chromosome::X) && sample.sex == Sex::Male
}

pub(crate) fn heterozygosity_chromosome(chrom: &Chromosome) -> bool {
    !matches!(chrom, Chromosome::X | Chromosome::Y | Chromosome::Mt)
}

pub(crate) fn pair_index(a: usize, b: usize) -> usize {
    b * (b + 1) / 2 + a
}

#[derive(Default)]
pub(crate) struct VariantTotals {
    pub allele_units: Vec<u64>,
    pub diploid: Vec<u64>,
    pub haploid: Vec<u64>,
    pub genotype_missing: u64,
    pub genotype_observations: u64,
    pub missing: Missing,
    pub hwe_counts: [u64; 3],
    pub expected_het: f64,
}

impl VariantTotals {
    fn reset(&mut self, alleles: usize) {
        self.allele_units.resize(alleles, 0);
        self.allele_units.fill(0);
        self.diploid.resize(alleles * (alleles + 1) / 2, 0);
        self.diploid.fill(0);
        self.haploid.resize(alleles, 0);
        self.haploid.fill(0);
        self.genotype_missing = 0;
        self.genotype_observations = 0;
        self.missing = Missing::default();
        self.hwe_counts = [0; 3];
        self.expected_het = 0.0;
    }

    fn finish(&mut self) {
        let k = self.allele_units.len();
        let units = self.allele_units.iter().sum::<u64>();
        let mut frequency_sum = 0.0;
        let mut squares = 0.0;
        for &value in self.allele_units.iter().take(k - 1) {
            let frequency = if units == 0 {
                1.0 / k as f64
            } else {
                value as f64 / units as f64
            };
            frequency_sum += frequency;
            squares += frequency * frequency;
        }
        let last = 1.0 - frequency_sum;
        self.expected_het = 1.0 - squares - last * last;
    }

    pub fn nonmajor_frequency(&self) -> f64 {
        let total = self.allele_units.iter().sum::<u64>();
        if total == 0 {
            return 1.0 - 1.0 / self.allele_units.len() as f64;
        }
        (total - self.allele_units.iter().copied().max().unwrap_or(0)) as f64 / total as f64
    }
}

pub(crate) fn variant(
    genotypes: &Genotypes,
    variant: &Variant,
    metadata: &Metadata,
    sample_positions: &[usize],
) -> VariantTotals {
    let mut result = VariantTotals::default();
    variant_into(genotypes, variant, metadata, sample_positions, &mut result);
    result
}

fn variant_into(
    genotypes: &Genotypes,
    variant: &Variant,
    metadata: &Metadata,
    sample_positions: &[usize],
    result: &mut VariantTotals,
) {
    let k = variant.alleles.len();
    result.reset(k);
    for (index, call) in genotypes.calls().enumerate() {
        if sample_positions[index] == usize::MAX {
            continue;
        }
        let sample = &metadata.samples[index];
        let is_haploid = haploid(&variant.chromosome, sample);
        if missing_eligible(&variant.chromosome, sample) {
            result.missing.add(call, is_haploid);
        }
        if !matches!(variant.chromosome, Chromosome::Y) || sample.sex != Sex::Female {
            match call.alleles {
                Some([a, b]) if !is_haploid => {
                    result.diploid[pair_index(a as usize, b as usize)] += 1;
                    result.genotype_observations += 1;
                }
                Some([a, b]) if a == b => {
                    result.haploid[a as usize] += 1;
                    result.genotype_observations += 1;
                }
                Some([a, b]) if matches!(variant.chromosome, Chromosome::Mt) => {
                    result.diploid[pair_index(a as usize, b as usize)] += 1;
                    result.genotype_observations += 1;
                }
                _ => result.genotype_missing += 1,
            }
        }
        if !sample.founder() {
            continue;
        }
        if variant.chromosome.is_autosome()
            && k == 2
            && let Some([a, b]) = call.alleles
        {
            result.hwe_counts[(a + b) as usize] += 1;
        }
        if matches!(variant.chromosome, Chromosome::Y) && sample.sex == Sex::Female {
            continue;
        }
        let multiplier = if is_haploid { 1 } else { 2 };
        if let Some(dosage) = call.dosage {
            result.allele_units[0] += u64::from(32768 - dosage) * multiplier;
            result.allele_units[1] += u64::from(dosage) * multiplier;
        } else if let Some([a, b]) = call.alleles {
            result.allele_units[a as usize] += 16384 * multiplier;
            result.allele_units[b as usize] += 16384 * multiplier;
        }
    }
    result.finish();
}

fn packed_eligible(genotypes: &Genotypes, variant: &Variant) -> bool {
    variant.chromosome.is_autosome() && variant.alleles.len() == 2 && genotypes.dosages.is_empty()
}

pub(crate) struct SelectionMasks {
    selected: Vec<u64>,
    founders: Vec<u64>,
    observations: u64,
}

impl SelectionMasks {
    pub fn new(metadata: &Metadata, sample_positions: &[usize]) -> Self {
        let mut selected = vec![0; metadata.samples.len().div_ceil(32)];
        let mut founders = selected.clone();
        let mut observations = 0;
        for (index, sample) in metadata.samples.iter().enumerate() {
            if sample_positions[index] == usize::MAX {
                continue;
            }
            let bit = 1 << (2 * (index % 32));
            selected[index / 32] |= bit;
            if sample.founder() {
                founders[index / 32] |= bit;
            }
            observations += 1;
        }
        Self {
            selected,
            founders,
            observations,
        }
    }

    pub fn variant_into(
        &self,
        genotypes: &Genotypes,
        variant: &Variant,
        metadata: &Metadata,
        sample_positions: &[usize],
        result: &mut VariantTotals,
    ) {
        if !packed_eligible(genotypes, variant) {
            variant_into(genotypes, variant, metadata, sample_positions, result);
            return;
        }
        result.reset(2);
        for ((&word, &selected), &founders) in genotypes
            .genotypes
            .iter()
            .zip(&self.selected)
            .zip(&self.founders)
        {
            let low = word & 0x5555_5555_5555_5555;
            let high = (word >> 1) & 0x5555_5555_5555_5555;
            let hom_ref = !low & !high;
            let het = low & !high;
            let hom_alt = !low & high;
            result.diploid[0] += (hom_ref & selected).count_ones() as u64;
            result.diploid[1] += (het & selected).count_ones() as u64;
            result.diploid[2] += (hom_alt & selected).count_ones() as u64;
            result.genotype_missing += (low & high & selected).count_ones() as u64;
            result.hwe_counts[0] += (hom_ref & founders).count_ones() as u64;
            result.hwe_counts[1] += (het & founders).count_ones() as u64;
            result.hwe_counts[2] += (hom_alt & founders).count_ones() as u64;
        }
        result.genotype_observations = self.observations - result.genotype_missing;
        result.missing = Missing {
            hardcall: result.genotype_missing,
            dosage: result.genotype_missing,
            hethap: 0,
            observations: self.observations,
        };
        let [hom_ref, het, hom_alt] = result.hwe_counts;
        result.allele_units[0] = 32768 * (2 * hom_ref + het);
        result.allele_units[1] = 32768 * (2 * hom_alt + het);
        result.finish();
    }

    pub fn add_samples(
        &self,
        genotypes: &Genotypes,
        variant: &Variant,
        metadata: &Metadata,
        sample_positions: &[usize],
        counts: &VariantTotals,
        samples: &mut [SampleTotals],
    ) {
        if !packed_eligible(genotypes, variant) {
            add_samples(
                genotypes,
                variant,
                metadata,
                sample_positions,
                counts,
                samples,
            );
            return;
        }
        let het_eligible = counts.expected_het >= 2f64.powi(-35);
        for (word_index, (&word, &selected)) in
            genotypes.genotypes.iter().zip(&self.selected).enumerate()
        {
            let mut bits = selected;
            while bits != 0 {
                let shift = bits.trailing_zeros() as usize;
                let index = word_index * 32 + shift / 2;
                let code = (word >> shift) & 3;
                let total = &mut samples[sample_positions[index]];
                total.missing.observations += 1;
                match code {
                    0 => total.hom_ref += 1,
                    1 => total.het_ref_alt += 1,
                    2 => total.hom_alt += 1,
                    _ => {
                        total.missing_calls += 1;
                        total.missing.hardcall += 1;
                        total.missing.dosage += 1;
                    }
                }
                if het_eligible && code != 3 {
                    total.observed_het += u64::from(code == 1);
                    total.expected_het += counts.expected_het;
                    total.het_observations += 1;
                }
                bits &= bits - 1;
            }
        }
    }
}

pub(crate) fn add_samples(
    genotypes: &Genotypes,
    variant: &Variant,
    metadata: &Metadata,
    sample_positions: &[usize],
    counts: &VariantTotals,
    samples: &mut [SampleTotals],
) {
    let het_eligible =
        heterozygosity_chromosome(&variant.chromosome) && counts.expected_het >= 2f64.powi(-35);
    for (index, call) in genotypes.calls().enumerate() {
        let position = sample_positions[index];
        if position == usize::MAX {
            continue;
        }
        let sample = &metadata.samples[index];
        let total = &mut samples[position];
        if missing_eligible(&variant.chromosome, sample) {
            let is_haploid = haploid(&variant.chromosome, sample);
            total.missing.add(call, is_haploid);
            match call.alleles {
                Some([a, b]) if is_haploid && a == b => {
                    if a == 0 {
                        total.hap_ref += 1;
                    } else {
                        total.hap_alt += 1;
                    }
                }
                Some(_) if is_haploid => total.missing_calls += 1,
                Some([0, 0]) => total.hom_ref += 1,
                Some([a, b]) if a == b => total.hom_alt += 1,
                Some([0, _]) => total.het_ref_alt += 1,
                Some(_) => total.het_two_alt += 1,
                None => total.missing_calls += 1,
            }
        }
        if het_eligible && let Some([a, b]) = call.alleles {
            total.observed_het += u64::from(a != b);
            total.expected_het += counts.expected_het;
            total.het_observations += 1;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{
        make::Selection,
        stats::{EXTENSIONS, StatsConfig, Tables, hwe},
    };
    use rsomics_common::AtomicFile;

    fn assert_missing(actual: Missing, expected: Missing) {
        assert_eq!(actual.hardcall, expected.hardcall);
        assert_eq!(actual.dosage, expected.dosage);
        assert_eq!(actual.hethap, expected.hethap);
        assert_eq!(actual.observations, expected.observations);
    }

    fn assert_variant(actual: &VariantTotals, expected: &VariantTotals) {
        assert_eq!(actual.allele_units, expected.allele_units);
        assert_eq!(actual.diploid, expected.diploid);
        assert_eq!(actual.haploid, expected.haploid);
        assert_eq!(actual.genotype_missing, expected.genotype_missing);
        assert_eq!(actual.genotype_observations, expected.genotype_observations);
        assert_missing(actual.missing, expected.missing);
        assert_eq!(actual.hwe_counts, expected.hwe_counts);
        assert_eq!(
            actual.expected_het.to_bits(),
            expected.expected_het.to_bits()
        );
        assert_eq!(
            actual.nonmajor_frequency().to_bits(),
            expected.nonmajor_frequency().to_bits()
        );
    }

    fn assert_sample(actual: &SampleTotals, expected: &SampleTotals) {
        assert_eq!(actual.hom_ref, expected.hom_ref);
        assert_eq!(actual.hom_alt, expected.hom_alt);
        assert_eq!(actual.het_ref_alt, expected.het_ref_alt);
        assert_eq!(actual.het_two_alt, expected.het_two_alt);
        assert_eq!(actual.hap_ref, expected.hap_ref);
        assert_eq!(actual.hap_alt, expected.hap_alt);
        assert_eq!(actual.missing_calls, expected.missing_calls);
        assert_missing(actual.missing, expected.missing);
        assert_eq!(actual.observed_het, expected.observed_het);
        assert_eq!(
            actual.expected_het.to_bits(),
            expected.expected_het.to_bits()
        );
        assert_eq!(actual.het_observations, expected.het_observations);
    }

    #[test]
    fn packed_qc_matches_general_tallies_and_ordered_tables_across_reused_rows() {
        let metadata = Metadata {
            sample_header: vec![],
            variant_header: vec![],
            sample_preamble: vec![],
            variant_preamble: vec![],
            variants: vec![],
            samples: (0..65)
                .map(|index| Sample {
                    fid: "0".into(),
                    iid: format!("sample{index}").into(),
                    sid: "0".into(),
                    paternal: if [1, 32].contains(&index) {
                        "parent"
                    } else {
                        "0"
                    }
                    .into(),
                    maternal: "0".into(),
                    sex: [Sex::Male, Sex::Female, Sex::Unknown][index % 3],
                    fields: vec![].into(),
                })
                .collect(),
        };
        let selected = [0, 1, 2, 31, 32, 33, 63, 64];
        let positions = crate::stats::sample_positions(65, &selected);
        let masks = SelectionMasks::new(&metadata, &positions);
        let calls = (0..65)
            .map(|index| Call {
                alleles: [Some([0, 0]), Some([0, 1]), Some([1, 1]), None][index % 4],
                phase: index % 4 == 1,
                reversed: index == 33,
                ..Call::default()
            })
            .collect::<Vec<_>>();
        let mut hardcalls = Genotypes::from_calls(&calls, 2, false).unwrap();
        hardcalls.genotypes[2] |= u64::MAX << 2;
        let mut dosed = calls.clone();
        dosed[0].dosage = Some(9000);
        dosed[31].dosage = Some(12000);
        let mut multi = calls.clone();
        multi[0].alleles = Some([0, 2]);
        multi[2].alleles = Some([2, 3]);
        multi[32].alleles = Some([2, 2]);
        let multiallelic = Genotypes::from_calls(&multi, 4, false).unwrap();
        let mut rows = vec![
            (Chromosome::Autosome(1), hardcalls.clone(), true),
            (
                Chromosome::Autosome(1),
                Genotypes::from_calls(&dosed, 2, false).unwrap(),
                false,
            ),
            (Chromosome::Autosome(1), multiallelic, false),
            (Chromosome::Autosome(1), hardcalls.clone(), true),
        ];
        for chromosome in [
            Chromosome::X,
            Chromosome::Y,
            Chromosome::Mt,
            Chromosome::Other("scaffold".into()),
            Chromosome::Par1,
        ] {
            rows.push((chromosome, hardcalls.clone(), false));
        }
        rows.push((
            Chromosome::Autosome(1),
            Genotypes::from_calls(&vec![Call::default(); 65], 2, false).unwrap(),
            true,
        ));
        rows.push((Chromosome::Autosome(1), hardcalls, true));
        let dir = tempfile::tempdir_in(std::env::temp_dir()).unwrap();
        let config = |name| StatsConfig {
            pgen: dir.path().join("input"),
            out: dir.path().join(name),
            selection: Selection::default(),
        };
        let mut actual_tables = Tables::open(&config("packed")).unwrap();
        let mut expected_tables = Tables::open(&config("general")).unwrap();
        let mut actual_samples = vec![SampleTotals::default(); selected.len()];
        let mut expected_samples = actual_samples.clone();
        let mut reused = VariantTotals::default();
        let mut enlarged_storage = None;
        for (index, (chromosome, genotypes, packed)) in rows.into_iter().enumerate() {
            let row = Variant {
                chromosome,
                position: index as u64 + 1,
                id: format!("row{index}").into(),
                alleles: ["A", "C", "G", "T"][..genotypes.allele_count]
                    .iter()
                    .map(|s| (*s).into())
                    .collect(),
                provisional_ref: false,
                fields: vec![].into(),
            };
            assert_eq!(packed_eligible(&genotypes, &row), packed);
            let expected = variant(&genotypes, &row, &metadata, &positions);
            masks.variant_into(&genotypes, &row, &metadata, &positions, &mut reused);
            assert_variant(&reused, &expected);
            if index == 0 {
                assert_eq!(reused.diploid, [3, 2, 1]);
                assert_eq!(reused.hwe_counts, [2, 1, 1]);
                assert_eq!(reused.allele_units, [163840, 98304]);
                assert_eq!(reused.genotype_missing, 2);
                assert_eq!(reused.genotype_observations, 6);
                assert_eq!(reused.expected_het, 0.46875);
            }
            let storage = (&reused.allele_units, &reused.diploid, &reused.haploid);
            let identity = (
                storage.0.as_ptr(),
                storage.1.as_ptr(),
                storage.2.as_ptr(),
                storage.0.capacity(),
                storage.1.capacity(),
                storage.2.capacity(),
            );
            if index == 2 {
                enlarged_storage = Some(identity);
            }
            if index > 2 {
                assert_eq!(Some(identity), enlarged_storage);
            }
            masks.add_samples(
                &genotypes,
                &row,
                &metadata,
                &positions,
                &reused,
                &mut actual_samples,
            );
            add_samples(
                &genotypes,
                &row,
                &metadata,
                &positions,
                &expected,
                &mut expected_samples,
            );
            for (actual, expected) in actual_samples.iter().zip(&expected_samples) {
                assert_sample(actual, expected);
            }
            let logp = (row.chromosome.is_autosome() && row.alleles.len() == 2).then(|| {
                let [hom_ref, het, hom_alt] = expected.hwe_counts;
                hwe::midp_log(hom_ref, het, hom_alt)
            });
            actual_tables.variant(&row, &reused, logp).unwrap();
            expected_tables.variant(&row, &expected, logp).unwrap();
        }
        for ((&index, actual), expected) in
            selected.iter().zip(&actual_samples).zip(&expected_samples)
        {
            actual_tables
                .sample(&metadata.samples[index], actual)
                .unwrap();
            expected_tables
                .sample(&metadata.samples[index], expected)
                .unwrap();
        }
        AtomicFile::commit_all(actual_tables.finish().unwrap()).unwrap();
        AtomicFile::commit_all(expected_tables.finish().unwrap()).unwrap();
        for extension in EXTENSIONS {
            let body = |name| {
                std::fs::read(crate::dataset::sibling(&dir.path().join(name), extension)).unwrap()
            };
            assert_eq!(body("packed"), body("general"), "{extension}");
        }
    }
}
