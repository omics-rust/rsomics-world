use std::{
    borrow::Borrow,
    collections::HashSet,
    fmt,
    hash::{Hash, Hasher},
    ops::{Deref, Index, Range},
    sync::Arc,
};

#[derive(Debug)]
struct Arena {
    text: String,
    fields: Vec<Range<usize>>,
}

#[derive(Clone, Debug)]
pub(crate) struct Text {
    arena: Arc<Arena>,
    range: Range<usize>,
}
impl Text {
    pub fn as_str(&self) -> &str {
        &self.arena.text[self.range.clone()]
    }
    pub fn split(&self, separator: char) -> impl Iterator<Item = Self> + '_ {
        let mut start = self.range.start;
        self.as_str().split(separator).map(move |value| {
            let range = start..start + value.len();
            start = range.end + separator.len_utf8();
            Self {
                arena: self.arena.clone(),
                range,
            }
        })
    }
    pub fn account(&self, arenas: &mut Arenas) -> usize {
        arenas.add(&self.arena)
    }
}
impl Deref for Text {
    type Target = str;
    fn deref(&self) -> &str {
        self.as_str()
    }
}
impl Borrow<str> for Text {
    fn borrow(&self) -> &str {
        self.as_str()
    }
}
impl fmt::Display for Text {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.as_str().fmt(f)
    }
}
impl PartialEq for Text {
    fn eq(&self, other: &Self) -> bool {
        self.as_str() == other.as_str()
    }
}
impl Eq for Text {}
impl PartialEq<&str> for Text {
    fn eq(&self, other: &&str) -> bool {
        self.as_str() == *other
    }
}
impl PartialOrd for Text {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}
impl Ord for Text {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        self.as_str().cmp(other.as_str())
    }
}
impl Hash for Text {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.as_str().hash(state);
    }
}
impl From<&str> for Text {
    fn from(value: &str) -> Self {
        let mut rows = RowsBuilder::default();
        rows.push_row([value]);
        rows.finish()[0].text(0).expect("one field was supplied")
    }
}
impl From<String> for Text {
    fn from(value: String) -> Self {
        value.as_str().into()
    }
}

#[derive(Clone, Debug)]
pub(crate) struct Fields {
    arena: Arc<Arena>,
    range: Range<usize>,
}
impl Fields {
    pub fn len(&self) -> usize {
        self.range.len()
    }
    pub fn get(&self, index: usize) -> Option<&str> {
        (index < self.len())
            .then(|| &self.arena.text[self.arena.fields[self.range.start + index].clone()])
    }
    pub fn iter(&self) -> impl Iterator<Item = &str> {
        self.arena.fields[self.range.clone()]
            .iter()
            .map(|range| &self.arena.text[range.clone()])
    }
    pub fn text(&self, index: usize) -> Option<Text> {
        (index < self.len()).then(|| Text {
            arena: self.arena.clone(),
            range: self.arena.fields[self.range.start + index].clone(),
        })
    }
    pub fn zero(&self) -> Text {
        Text {
            arena: self.arena.clone(),
            range: 0..1,
        }
    }
    pub fn account(&self, arenas: &mut Arenas) -> usize {
        arenas.add(&self.arena)
    }
}
impl PartialEq for Fields {
    fn eq(&self, other: &Self) -> bool {
        self.iter().eq(other.iter())
    }
}
impl Eq for Fields {}
impl Index<usize> for Fields {
    type Output = str;
    fn index(&self, index: usize) -> &str {
        self.get(index).expect("field index in bounds")
    }
}
impl From<Vec<String>> for Fields {
    fn from(values: Vec<String>) -> Self {
        let mut rows = RowsBuilder::default();
        rows.push_row(values.iter().map(String::as_str));
        rows.finish().pop().expect("one row was supplied")
    }
}

pub(crate) struct RowsBuilder {
    text: String,
    fields: Vec<Range<usize>>,
    rows: Vec<Range<usize>>,
}
impl Default for RowsBuilder {
    fn default() -> Self {
        Self {
            text: "0".into(),
            fields: Vec::new(),
            rows: Vec::new(),
        }
    }
}
impl RowsBuilder {
    pub fn push_row<'a>(&mut self, fields: impl IntoIterator<Item = &'a str>) {
        let start = self.fields.len();
        for value in fields {
            let start = self.text.len();
            self.text.push_str(value);
            self.fields.push(start..self.text.len());
        }
        self.rows.push(start..self.fields.len());
    }
    pub fn finish(self) -> Vec<Fields> {
        let arena = Arc::new(Arena {
            text: self.text,
            fields: self.fields,
        });
        self.rows
            .into_iter()
            .map(|range| Fields {
                arena: arena.clone(),
                range,
            })
            .collect()
    }
}

#[derive(Default)]
pub(crate) struct Arenas(HashSet<*const Arena>);
impl Arenas {
    fn add(&mut self, arena: &Arc<Arena>) -> usize {
        if self.0.insert(Arc::as_ptr(arena)) {
            std::mem::size_of::<Arena>()
                + 2 * std::mem::size_of::<usize>()
                + arena.text.capacity()
                + arena.fields.capacity() * std::mem::size_of::<Range<usize>>()
        } else {
            0
        }
    }
}
