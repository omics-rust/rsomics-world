use crate::{Result, invalid};

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub(crate) struct Call {
    pub alleles: Option<[u8; 2]>,
    pub phase: bool,
    pub reversed: bool,
    pub dosage: Option<u16>,
    pub dphase: Option<i16>,
}
#[derive(Clone, Debug)]
pub(crate) struct Genotypes {
    pub samples: usize,
    pub allele_count: usize,
    pub provisional_ref: bool,
    pub genotypes: Vec<u64>,
    pub patch01: Vec<u64>,
    pub patch10: Vec<u64>,
    pub patch01_values: Vec<u8>,
    pub patch10_values: Vec<u8>,
    pub phase_present: Vec<u64>,
    pub phase_info: Vec<u64>,
    pub dosage_present: Vec<u64>,
    pub dosages: Vec<u16>,
    pub dphase_present: Vec<u64>,
    pub dphase: Vec<i16>,
}
pub(crate) fn bit(mask: &[u64], index: usize) -> bool {
    mask[index / 64] & (1 << (index % 64)) != 0
}
pub(crate) fn set(mask: &mut [u64], index: usize) {
    mask[index / 64] |= 1 << (index % 64);
}
impl Genotypes {
    pub fn empty(samples: usize, allele_count: usize, provisional_ref: bool) -> Self {
        let words = samples.div_ceil(64);
        Self {
            samples,
            allele_count,
            provisional_ref,
            genotypes: vec![0; samples.div_ceil(32)],
            patch01: vec![0; words],
            patch10: vec![0; words],
            patch01_values: Vec::new(),
            patch10_values: Vec::new(),
            phase_present: vec![0; words],
            phase_info: vec![0; words],
            dosage_present: vec![0; words],
            dosages: Vec::new(),
            dphase_present: vec![0; words],
            dphase: Vec::new(),
        }
    }
    pub fn from_calls(calls: &[Call], allele_count: usize, provisional_ref: bool) -> Result<Self> {
        let mut data = Self::empty(calls.len(), allele_count, provisional_ref);
        for (i, call) in calls.iter().enumerate() {
            let code = match call.alleles {
                None => 3,
                Some([a, b]) if a <= b && (b as usize) < allele_count => match (a, b) {
                    (0, 0) => 0,
                    (0, 1) => 1,
                    (1, 1) => 2,
                    (0, b) => {
                        set(&mut data.patch01, i);
                        data.patch01_values.push(b);
                        1
                    }
                    (a, b) => {
                        set(&mut data.patch10, i);
                        data.patch10_values.extend([a, b]);
                        2
                    }
                },
                _ => return Err(invalid("invalid sorted hardcall alleles")),
            };
            data.genotypes[i / 32] |= code << (2 * (i % 32));
            if call.phase {
                if !matches!(call.alleles,Some([a,b]) if a!=b) {
                    return Err(invalid("phase presence requires a heterozygous hardcall"));
                }
                set(&mut data.phase_present, i);
                if call.reversed {
                    set(&mut data.phase_info, i);
                }
            }
            if let Some(d) = call.dosage {
                if d > 32768 || allele_count != 2 {
                    return Err(invalid("invalid/unsupported dosage"));
                }
                set(&mut data.dosage_present, i);
                data.dosages.push(d);
            }
            if let Some(d) = call.dphase {
                if call.dosage.is_none() {
                    return Err(invalid("dphase requires explicit dosage"));
                }
                set(&mut data.dphase_present, i);
                data.dphase.push(d);
            }
        }
        Ok(data)
    }
    fn decode(&self, index: usize, offsets: [usize; 4]) -> Call {
        let code = (self.genotypes[index / 32] >> (2 * (index % 32))) & 3;
        let alleles = match code {
            0 => Some([0, 0]),
            1 if bit(&self.patch01, index) => Some([0, self.patch01_values[offsets[0]]]),
            1 => Some([0, 1]),
            2 if bit(&self.patch10, index) => {
                let i = offsets[1] * 2;
                Some([self.patch10_values[i], self.patch10_values[i + 1]])
            }
            2 => Some([1, 1]),
            _ => None,
        };
        let phase = bit(&self.phase_present, index);
        Call {
            alleles,
            phase,
            reversed: phase && bit(&self.phase_info, index),
            dosage: bit(&self.dosage_present, index).then(|| self.dosages[offsets[2]]),
            dphase: bit(&self.dphase_present, index).then(|| self.dphase[offsets[3]]),
        }
    }
    pub fn calls(&self) -> impl Iterator<Item = Call> + '_ {
        let mut offsets = [0usize; 4];
        (0..self.samples).map(move |index| {
            let result = self.decode(index, offsets);
            for (offset, mask) in offsets.iter_mut().zip([
                &self.patch01,
                &self.patch10,
                &self.dosage_present,
                &self.dphase_present,
            ]) {
                *offset += usize::from(bit(mask, index));
            }
            result
        })
    }
    pub fn select(&self, samples: &[usize]) -> Result<Self> {
        if samples.last().is_some_and(|&index| index >= self.samples)
            || samples.windows(2).any(|pair| pair[0] >= pair[1])
        {
            return Err(invalid(
                "sample projection must follow unique source ordinals",
            ));
        }
        let mut selected = Vec::with_capacity(samples.len());
        for (index, call) in self.calls().enumerate() {
            if samples.get(selected.len()) == Some(&index) {
                selected.push(call);
            }
            if selected.len() == samples.len() {
                break;
            }
        }
        Self::from_calls(&selected, self.allele_count, self.provisional_ref)
    }
    pub fn phase_count(&self) -> usize {
        self.phase_present
            .iter()
            .map(|x| x.count_ones() as usize)
            .sum()
    }
    pub fn bytes(&self) -> usize {
        self.genotypes.len() * 8
            + (self.patch01.len()
                + self.patch10.len()
                + self.phase_present.len()
                + self.phase_info.len()
                + self.dosage_present.len()
                + self.dphase_present.len())
                * 8
            + self.patch01_values.len()
            + self.patch10_values.len()
            + (self.dosages.len() + self.dphase.len()) * 2
    }
}
