#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) enum Chromosome {
    Autosome(u8),
    X,
    Y,
    Par1,
    Par2,
    Mt,
    Other(String),
}
impl Chromosome {
    pub fn parse(value: &str) -> Self {
        let value = value.strip_prefix("chr").unwrap_or(value);
        match value {
            "X" | "23" => Self::X,
            "Y" | "24" => Self::Y,
            "PAR1" => Self::Par1,
            "PAR2" => Self::Par2,
            "M" | "MT" | "26" => Self::Mt,
            _ => match value.parse::<u8>() {
                Ok(n @ 1..=22) => Self::Autosome(n),
                _ => Self::Other(value.to_owned()),
            },
        }
    }
    pub fn is_autosome(&self) -> bool {
        matches!(self, Self::Autosome(_))
    }
    pub fn split_b37(&self, position: u64) -> Option<&'static str> {
        match self {
            Self::X if position <= 2_699_520 => Some("PAR1"),
            Self::X if position >= 154_931_044 => Some("PAR2"),
            _ => None,
        }
    }
}
