pub(crate) const SMALL_EPSILON: f64 = 1.0 / ((1u64 << 44) as f64);
