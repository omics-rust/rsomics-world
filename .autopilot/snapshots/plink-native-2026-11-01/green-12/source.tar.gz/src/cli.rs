use crate::dataset::{DosageField, ImportProfile, InputSpec};
use crate::make::{MakeConfig, Selection};
use crate::{Result, invalid};
use clap::{ArgGroup, Args, Parser, Subcommand, ValueEnum};
use std::path::PathBuf;

#[derive(Debug, Parser)]
#[command(
    name = "rsomics-plink",
    version,
    about = "Durable genotype preparation with a pinned pgenlib codec"
)]
pub(crate) struct Cli {
    #[command(flatten)]
    pub output: rsomics_common::OutputArgs,
    #[command(flatten)]
    pub threads: rsomics_common::ThreadArgs,
    #[arg(long, global = true, default_value_t = 512)]
    pub memory_mib: usize,
    #[command(subcommand)]
    pub command: Command,
}
#[derive(Debug, Subcommand)]
pub(crate) enum Command {
    /// Import or select a durable PGEN dataset.
    Make(MakeArgs),
    /// Report counts, missingness, heterozygosity and explicitly scoped founder HWE.
    Stats(StatsArgs),
    /// Compute unphased LD or hardcall pruning from a durable dataset.
    Ld(LdArgs),
}
#[derive(Clone, Copy, Debug, ValueEnum)]
pub(crate) enum Dosage {
    Ds,
    Hds,
}
#[derive(Clone, Copy, Debug, ValueEnum)]
pub(crate) enum HalfCall {
    Error,
    Missing,
}
#[derive(Debug, Args)]
#[command(group(ArgGroup::new("input").required(true).multiple(false).args(["pfile","bfile","vcf"])))]
pub(crate) struct MakeArgs {
    #[arg(long)]
    pfile: Option<PathBuf>,
    #[arg(long)]
    bfile: Option<PathBuf>,
    #[arg(long)]
    vcf: Option<PathBuf>,
    #[arg(long, requires = "vcf")]
    psam: Option<PathBuf>,
    #[arg(long, value_enum, ignore_case = true, requires = "vcf")]
    dosage: Option<Dosage>,
    #[arg(long, value_enum, requires = "vcf")]
    half_call: Option<HalfCall>,
    #[arg(long,value_parser=["b37"],requires="vcf")]
    split_par: Option<String>,
    #[arg(long)]
    out: PathBuf,
    #[command(flatten)]
    selection: SelectionArgs,
    #[arg(
        long,
        help = "Maximum sample hardcall missingness before variant filters"
    )]
    mind: Option<f64>,
    #[arg(
        long,
        help = "Maximum variant hardcall missingness after sample filtering"
    )]
    geno: Option<f64>,
    #[arg(long, help = "Minimum autosomal biallelic founder HWE mid-p value")]
    hwe: Option<f64>,
    #[arg(long, help = "Minimum founder nonmajor allele frequency")]
    maf: Option<f64>,
}
impl MakeArgs {
    pub fn config(self) -> Result<MakeConfig> {
        let input = if let Some(p) = self.pfile {
            InputSpec::Pgen(p)
        } else if let Some(p) = self.bfile {
            InputSpec::Bed(p)
        } else {
            InputSpec::Vcf(self.vcf.ok_or_else(|| invalid("one input is required"))?)
        };
        Ok(MakeConfig {
            input,
            profile: ImportProfile {
                dosage: match self.dosage {
                    Some(Dosage::Ds) => DosageField::Ds,
                    Some(Dosage::Hds) => DosageField::Hds,
                    None => DosageField::None,
                },
                half_call_missing: matches!(self.half_call, Some(HalfCall::Missing)),
                split_par_b37: self.split_par.is_some(),
                psam: self.psam,
            },
            selection: self.selection.config(),
            filters: crate::make::filter::FilterThresholds {
                mind: self.mind,
                geno: self.geno,
                hwe_midp: self.hwe,
                maf: self.maf,
            },
            out: self.out,
        })
    }
}

#[derive(Clone, Debug, Args)]
pub(crate) struct SelectionArgs {
    #[arg(long)]
    keep: Option<PathBuf>,
    #[arg(long)]
    remove: Option<PathBuf>,
    #[arg(long)]
    extract: Option<PathBuf>,
    #[arg(long)]
    exclude: Option<PathBuf>,
    #[arg(long)]
    autosome: bool,
    #[arg(long)]
    max_alleles: Option<usize>,
}
impl SelectionArgs {
    fn config(self) -> Selection {
        Selection {
            keep: self.keep,
            remove: self.remove,
            extract: self.extract,
            exclude: self.exclude,
            autosome: self.autosome,
            max_alleles: self.max_alleles,
        }
    }
}

#[derive(Debug, Args)]
pub(crate) struct StatsArgs {
    #[arg(long)]
    pfile: PathBuf,
    #[arg(long)]
    out: PathBuf,
    #[command(flatten)]
    selection: SelectionArgs,
}
impl StatsArgs {
    pub fn config(self) -> crate::stats::StatsConfig {
        crate::stats::StatsConfig {
            pgen: self.pfile,
            out: self.out,
            selection: self.selection.config(),
        }
    }
}

#[derive(Debug, Args)]
pub(crate) struct LdArgs {
    #[command(subcommand)]
    pub command: LdCommand,
}
#[derive(Debug, Subcommand)]
pub(crate) enum LdCommand {
    /// Compute dosage-aware pairwise-complete founder LD.
    Pairs(PairArgs),
    /// Emit ordered retain/remove lists with hardcall-only backward pruning.
    Prune(PruneArgs),
}

#[derive(Debug, Args)]
pub(crate) struct PairArgs {
    #[arg(long)]
    pfile: PathBuf,
    #[arg(long)]
    out: PathBuf,
    #[command(flatten)]
    selection: SelectionArgs,
    #[arg(long, default_value_t = 1_000_000)]
    window_variants: usize,
    #[arg(long, default_value_t = 500_000)]
    window_bp: u64,
    #[arg(long,default_value_t=-1.0,allow_negative_numbers=true)]
    min_r2: f64,
    #[arg(long)]
    allow_small_founders: bool,
}
impl PairArgs {
    pub fn config(self) -> crate::ld::PairConfig {
        crate::ld::PairConfig {
            pfile: self.pfile,
            out: self.out,
            selection: self.selection.config(),
            window_variants: self.window_variants,
            window_bp: self.window_bp,
            min_r2: self.min_r2,
            allow_small_founders: self.allow_small_founders,
        }
    }
}

#[derive(Debug, Args)]
pub(crate) struct PruneArgs {
    #[arg(long)]
    pfile: PathBuf,
    #[arg(long)]
    out: PathBuf,
    #[command(flatten)]
    selection: SelectionArgs,
    #[arg(long, conflicts_with = "window_variants")]
    window_bp: Option<u64>,
    #[arg(long, conflicts_with = "window_bp")]
    window_variants: Option<usize>,
    #[arg(long, default_value_t = 1)]
    step: usize,
    #[arg(long, default_value_t = 0.2)]
    r2: f64,
}
impl PruneArgs {
    pub fn config(self) -> crate::ld::PruneConfig {
        crate::ld::PruneConfig {
            pfile: self.pfile,
            out: self.out,
            selection: self.selection.config(),
            window: match self.window_variants {
                Some(n) => crate::ld::PruneWindow::Variants(n),
                None => crate::ld::PruneWindow::BasePairs(self.window_bp.unwrap_or(500_000)),
            },
            step: self.step,
            r2: self.r2,
        }
    }
}
