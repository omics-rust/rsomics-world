use crate::{Result, invalid};
use std::mem::size_of;
use std::sync::mpsc::{Receiver, SyncSender, sync_channel};

enum Message<T, S> {
    Data(T, S),
    Closed(Result<()>),
}

pub(crate) fn memory_bytes<T, S>(lanes: usize) -> usize {
    // Two opaque channels get 8 KiB per lane, separately from their owned payloads.
    lanes.saturating_mul(
        8192 + 2 * size_of::<Message<T, S>>()
            + size_of::<Receiver<Message<T, S>>>()
            + size_of::<SyncSender<Message<T, S>>>()
            + size_of::<Receiver<T>>()
            + size_of::<SyncSender<T>>(),
    )
}

pub(crate) struct Consumer<C, A> {
    pub(crate) write: C,
    pub(crate) complete: A,
}

pub(crate) fn run<T, S, W, I, P, F, C, A>(
    pool: &rayon::ThreadPool,
    lanes: usize,
    partitions: usize,
    initialize: I,
    produce: P,
    finish: F,
    mut consume: Consumer<C, A>,
) -> Result<()>
where
    T: Send,
    S: Send,
    I: Fn(usize) -> Result<W> + Sync,
    P: Fn(&mut W, usize, Option<T>) -> Result<(T, S)> + Sync,
    F: Fn(W) -> Result<()> + Sync,
    C: FnMut(usize, &mut T) -> Result<()>,
    A: FnMut(S),
{
    pool.in_place_scope(|scope| {
        let mut receivers = Vec::with_capacity(lanes);
        for lane in 0..lanes {
            let (sender, receiver) = sync_channel(1);
            let (returned, recycled) = sync_channel(1);
            receivers.push((receiver, returned));
            let initialize = &initialize;
            let produce = &produce;
            let finish = &finish;
            scope.spawn(move |_| {
                let result = initialize(lane).and_then(|mut worker| {
                    let mut result = Ok(());
                    let mut payload = None;
                    for partition in (lane..partitions).step_by(lanes) {
                        match produce(&mut worker, partition, payload.take()) {
                            Ok((value, summary)) => {
                                if sender.send(Message::Data(value, summary)).is_err() {
                                    result = Err(invalid("ordered output consumer stopped"));
                                    break;
                                }
                                match recycled.recv() {
                                    Ok(value) => payload = Some(value),
                                    Err(_) => {
                                        result = Err(invalid("ordered output consumer stopped"));
                                        break;
                                    }
                                }
                            }
                            Err(error) => {
                                result = Err(error);
                                break;
                            }
                        }
                    }
                    let closed = finish(worker);
                    result.and(closed)
                });
                let _ = sender.send(Message::Closed(result));
            });
        }
        let result = (|| {
            for partition in 0..partitions {
                let (receiver, returned) = &receivers[partition % lanes];
                match receiver.recv() {
                    Ok(Message::Data(mut value, summary)) => {
                        (consume.write)(partition, &mut value)?;
                        (consume.complete)(summary);
                        returned.send(value).map_err(|_| {
                            invalid("ordered producer stopped before buffer return")
                        })?;
                    }
                    Ok(Message::Closed(result)) => {
                        result?;
                        return Err(invalid("ordered producer closed before its partition"));
                    }
                    Err(_) => return Err(invalid("ordered producer disconnected")),
                }
            }
            for (receiver, _) in &receivers {
                match receiver.recv() {
                    Ok(Message::Closed(result)) => result?,
                    _ => return Err(invalid("ordered producer did not report its close result")),
                }
            }
            Ok(())
        })();
        drop(receivers);
        result
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::{self, Write};

    #[test]
    fn every_lane_completes_its_job_before_the_first_output_is_drained() {
        let pool = rayon::ThreadPoolBuilder::new()
            .num_threads(4)
            .build()
            .unwrap();
        let (completed, completions) = std::sync::mpsc::channel();
        let mut output = Vec::new();
        run(
            &pool,
            4,
            4,
            |_| Ok(()),
            |_: &mut (), partition, recycled: Option<Vec<u8>>| {
                let mut bytes = recycled.unwrap_or_default();
                bytes.clear();
                for block in 0..5 {
                    bytes.extend_from_slice(&[partition as u8, block]);
                }
                completed.send(partition).unwrap();
                Ok((bytes, ()))
            },
            |_| Ok(()),
            Consumer {
                write: |_, block: &mut Vec<u8>| {
                    if output.is_empty() {
                        for _ in 0..4 {
                            completions
                                .recv_timeout(std::time::Duration::from_secs(30))
                                .map_err(|_| {
                                    invalid("a calculation job blocked before completion")
                                })?;
                        }
                    }
                    output.extend_from_slice(block);
                    Ok(())
                },
                complete: |_| {},
            },
        )
        .unwrap();
        assert_eq!(
            output,
            (0..4u8)
                .flat_map(|part| (0..5).flat_map(move |block| [part, block]))
                .collect::<Vec<_>>()
        );
    }

    #[test]
    fn bounded_lanes_preserve_partition_order_and_cancel_a_failed_consumer() {
        let pool = rayon::ThreadPoolBuilder::new()
            .num_threads(4)
            .build()
            .unwrap();
        let produce = |_: &mut (), partition: usize, recycled: Option<Vec<u8>>| {
            let mut bytes = recycled.unwrap_or_default();
            bytes.clear();
            for block in 0..5 {
                bytes.extend_from_slice(&[partition as u8, block]);
            }
            Ok((bytes, partition))
        };
        let mut bytes = Vec::new();
        let mut counts = Vec::new();
        run(
            &pool,
            4,
            12,
            |_| Ok(()),
            produce,
            |_| Ok(()),
            Consumer {
                write: |_, block: &mut Vec<u8>| {
                    bytes.extend_from_slice(block);
                    Ok(())
                },
                complete: |part| counts.push(part),
            },
        )
        .unwrap();
        assert_eq!(counts, (0..12).collect::<Vec<_>>());
        assert_eq!(
            bytes,
            (0..12u8)
                .flat_map(|part| (0..5).flat_map(move |block| [part, block]))
                .collect::<Vec<_>>()
        );
        struct Failing;
        impl Write for Failing {
            fn write(&mut self, _: &[u8]) -> io::Result<usize> {
                Err(io::Error::other("controlled output failure"))
            }
            fn flush(&mut self) -> io::Result<()> {
                Ok(())
            }
        }
        let error = run(
            &pool,
            4,
            12,
            |_| Ok(()),
            produce,
            |_| Ok(()),
            Consumer {
                write: |_, block: &mut Vec<u8>| {
                    Failing.write_all(block)?;
                    Ok(())
                },
                complete: |_| {},
            },
        )
        .unwrap_err();
        assert!(error.to_string().contains("controlled output failure"));

        let closed = std::sync::atomic::AtomicUsize::new(0);
        let error = run(
            &pool,
            4,
            12,
            |_| Ok(()),
            |worker, partition, recycled| {
                if partition == 2 {
                    return Err(invalid("controlled producer failure"));
                }
                produce(worker, partition, recycled)
            },
            |_| {
                closed.fetch_add(1, std::sync::atomic::Ordering::SeqCst);
                Ok(())
            },
            Consumer {
                write: |_, _: &mut Vec<u8>| Ok(()),
                complete: |_| {},
            },
        )
        .unwrap_err();
        assert!(error.to_string().contains("controlled producer failure"));
        assert_eq!(closed.load(std::sync::atomic::Ordering::SeqCst), 4);
    }
}
