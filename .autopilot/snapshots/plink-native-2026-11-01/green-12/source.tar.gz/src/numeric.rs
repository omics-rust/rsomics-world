fn round_even(value: f64) -> u32 {
    let whole = value as u32;
    // Source reports use an even-rounding window at decimal half boundaries.
    let half = if whole & 1 == 0 {
        0.499999995
    } else {
        0.500000005
    };
    whole + ((value - f64::from(whole)) + half) as u32
}

fn fixed(value: u32, places: u32) -> String {
    let mut digits = value.to_string();
    if places == 0 {
        return digits;
    }
    let places = places as usize;
    if digits.len() <= places {
        digits.insert_str(0, &"0".repeat(places + 1 - digits.len()));
    }
    digits.insert(digits.len() - places, '.');
    digits.truncate(digits.trim_end_matches('0').trim_end_matches('.').len());
    digits
}

pub(crate) fn six_significant(value: f64) -> String {
    if value.is_nan() {
        return "nan".into();
    }
    if value.is_infinite() {
        return if value.is_sign_negative() {
            "-inf"
        } else {
            "inf"
        }
        .into();
    }
    if value == 0.0 {
        return "0".into();
    }
    let mut scaled = value.abs();
    let mut result = if scaled < 9.9999949999999e-5 {
        let mut exponent = 0;
        for (threshold, factor, power) in [
            (9.9999949999999e-256, 1e256, 256),
            (9.9999949999999e-128, 1e128, 128),
            (9.9999949999999e-64, 1e64, 64),
            (9.9999949999999e-32, 1e32, 32),
            (9.9999949999999e-16, 1e16, 16),
            (9.9999949999999e-8, 1e8, 8),
            (9.9999949999999e-4, 1e4, 4),
            (9.9999949999999e-2, 1e2, 2),
            (9.9999949999999e-1, 1e1, 1),
        ] {
            if scaled < threshold {
                scaled *= factor;
                exponent += power;
            }
        }
        format!("{}e-{exponent:02}", fixed(round_even(scaled * 100000.0), 5))
    } else if scaled >= 999999.49999999 {
        let mut exponent = 0;
        for (threshold, factor, power) in [
            (9.9999949999999e255, 1e-256, 256),
            (9.9999949999999e127, 1e-128, 128),
            (9.9999949999999e63, 1e-64, 64),
            (9.9999949999999e31, 1e-32, 32),
            (9.9999949999999e15, 1e-16, 16),
            (9.9999949999999e7, 1e-8, 8),
            (9.9999949999999e3, 1e-4, 4),
            (9.9999949999999e1, 1e-2, 2),
            (9.9999949999999e0, 1e-1, 1),
        ] {
            if scaled >= threshold {
                scaled *= factor;
                exponent += power;
            }
        }
        format!("{}e+{exponent:02}", fixed(round_even(scaled * 100000.0), 5))
    } else if scaled < 0.99999949999999 {
        let mut places = 6;
        if scaled < 9.9999949999999e-3 {
            scaled *= 100.0;
            places += 2;
        }
        if scaled < 9.9999949999999e-2 {
            scaled *= 10.0;
            places += 1;
        }
        fixed(round_even(scaled * 1000000.0), places)
    } else {
        let places = [
            (9.9999949999999, 5),
            (99.999949999999, 4),
            (999.99949999999, 3),
            (9999.9949999999, 2),
            (99999.949999999, 1),
        ]
        .into_iter()
        .find_map(|(threshold, places)| (scaled < threshold).then_some(places))
        .unwrap_or(0);
        fixed(round_even(scaled * f64::from(10u32.pow(places))), places)
    };
    if value.is_sign_negative() {
        result.insert(0, '-');
    }
    result
}
