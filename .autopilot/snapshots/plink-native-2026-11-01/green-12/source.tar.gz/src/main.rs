fn main() -> std::process::ExitCode {
    rsomics_plink::run_cli()
}
