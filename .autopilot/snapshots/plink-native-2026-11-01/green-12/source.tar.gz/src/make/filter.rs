use crate::dataset::{
    Dataset,
    genotypes::Genotypes,
    metadata::{Sex, Variant},
    policy::SMALL_EPSILON,
};
use crate::execution::Execution;
use crate::stats::{self, tally};
use crate::{Result, invalid};
use rayon::prelude::*;
use std::mem::size_of;

#[derive(Default, Clone, Debug)]
pub(crate) struct FilterThresholds {
    pub mind: Option<f64>,
    pub geno: Option<f64>,
    pub hwe_midp: Option<f64>,
    pub maf: Option<f64>,
}

impl FilterThresholds {
    fn validate(&self) -> Result<()> {
        for (name, value) in [
            ("mind", self.mind),
            ("geno", self.geno),
            ("hwe-midp", self.hwe_midp),
            ("maf", self.maf),
        ] {
            if value.is_some_and(|threshold| {
                !threshold.is_finite() || !(0.0..=1.0).contains(&threshold)
            }) {
                return Err(invalid(format!(
                    "{name} threshold must be finite and in [0,1]"
                )));
            }
        }
        Ok(())
    }
}

fn missing_allowed(denominator: u64, threshold: f64) -> u64 {
    (denominator as f64 * (threshold * (1.0 + SMALL_EPSILON))) as u64
}

struct PackedSelection {
    selected: Vec<u64>,
    founders: Vec<u64>,
    observations: u64,
}

#[derive(Clone, Copy)]
struct PackedCounts {
    missing: u64,
    observations: u64,
    reference: u64,
    alternate: u64,
}

impl PackedSelection {
    fn new(dataset: &Dataset, samples: &[usize]) -> Self {
        let mut selected = vec![0; dataset.metadata.samples.len().div_ceil(32)];
        let mut founders = selected.clone();
        for &index in samples {
            let bit = 1 << (2 * (index % 32));
            selected[index / 32] |= bit;
            if dataset.metadata.samples[index].founder() {
                founders[index / 32] |= bit;
            }
        }
        Self {
            selected,
            founders,
            observations: samples.len() as u64,
        }
    }

    fn counts(&self, values: &Genotypes, variant: &Variant) -> Option<PackedCounts> {
        if !variant.chromosome.is_autosome()
            || values.allele_count != 2
            || !values.dosages.is_empty()
        {
            return None;
        }
        let mut result = PackedCounts {
            missing: 0,
            observations: self.observations,
            reference: 0,
            alternate: 0,
        };
        for ((&word, &selected), &founders) in values
            .genotypes
            .iter()
            .zip(&self.selected)
            .zip(&self.founders)
        {
            let low = word & 0x5555_5555_5555_5555;
            let high = (word >> 1) & 0x5555_5555_5555_5555;
            let missing = low & high;
            let het = (low & !high & founders).count_ones() as u64;
            result.missing += (missing & selected).count_ones() as u64;
            result.reference += 2 * (!low & !high & founders).count_ones() as u64 + het;
            result.alternate += 2 * (!low & high & founders).count_ones() as u64 + het;
        }
        Some(result)
    }

    fn add_missing(&self, values: &Genotypes, positions: &[usize], missing: &mut [u64]) {
        for (word_index, (&word, &selected)) in
            values.genotypes.iter().zip(&self.selected).enumerate()
        {
            let mut bits = word & (word >> 1) & selected;
            while bits != 0 {
                let index = word_index * 32 + bits.trailing_zeros() as usize / 2;
                missing[positions[index]] += 1;
                bits &= bits - 1;
            }
        }
    }
}

impl PackedCounts {
    fn keep(self, thresholds: &FilterThresholds) -> bool {
        let total = self.reference + self.alternate;
        let frequency = if total == 0 {
            0.5
        } else {
            self.reference.min(self.alternate) as f64 / total as f64
        };
        thresholds
            .geno
            .is_none_or(|threshold| self.missing <= missing_allowed(self.observations, threshold))
            && thresholds
                .maf
                .is_none_or(|threshold| frequency >= threshold * (1.0 - SMALL_EPSILON))
    }
}

pub(crate) fn apply(
    dataset: &Dataset,
    mut samples: Vec<usize>,
    mut variants: Vec<usize>,
    thresholds: &FilterThresholds,
    execution: &Execution,
) -> Result<(Vec<usize>, Vec<usize>)> {
    thresholds.validate()?;
    if thresholds.mind.is_none()
        && thresholds.geno.is_none()
        && thresholds.hwe_midp.is_none()
        && thresholds.maf.is_none()
    {
        return Ok((samples, variants));
    }
    if thresholds.hwe_midp.is_some()
        && variants.iter().any(|&i| {
            let variant = &dataset.metadata.variants[i];
            !variant.chromosome.is_autosome() || variant.alleles.len() != 2
        })
    {
        return Err(invalid(
            "HWE filtering currently requires an explicit autosome/biallelic selection",
        ));
    }
    let reuse = thresholds.mind.is_some()
        && thresholds.hwe_midp.is_none()
        && (thresholds.geno.is_some() || thresholds.maf.is_some());
    let persistent = (dataset.metadata.samples.len() + samples.len() + variants.len())
        * size_of::<usize>()
        + samples.len() * size_of::<u64>()
        + dataset.metadata.samples.len().div_ceil(32) * 4 * size_of::<u64>()
        + if reuse {
            variants.len() * size_of::<Option<PackedCounts>>()
        } else {
            0
        }
        + 65536;
    if stats::metadata_bytes(&dataset.metadata)
        .saturating_add(dataset.shared_bytes())
        .saturating_add(persistent)
        >= execution.memory_bytes
    {
        return Err(invalid(
            "filter metadata and sample state exceed invocation memory budget",
        ));
    }
    let mut positions = stats::sample_positions(dataset.metadata.samples.len(), &samples);
    let mut packed = PackedSelection::new(dataset, &samples);
    let mut cached = reuse.then(|| Vec::with_capacity(variants.len()));
    if let Some(threshold) = thresholds.mind {
        let original_sample_count = samples.len();
        let mut missing = vec![0u64; samples.len()];
        stats::visit_batches(dataset, &variants, persistent, execution, |batch| {
            for (index, values) in batch {
                let variant = &dataset.metadata.variants[*index];
                let count = packed.counts(values, variant);
                if count.is_some() {
                    packed.add_missing(values, &positions, &mut missing);
                } else {
                    for (index, call) in values.calls().enumerate() {
                        let position = positions[index];
                        if position != usize::MAX
                            && tally::missing_eligible(
                                &variant.chromosome,
                                &dataset.metadata.samples[index],
                            )
                        {
                            missing[position] += u64::from(call.alleles.is_none());
                        }
                    }
                }
                if let Some(cached) = &mut cached {
                    cached.push(count);
                }
            }
            Ok(())
        })?;
        let nony = variants
            .iter()
            .filter(|&&i| {
                !matches!(
                    dataset.metadata.variants[i].chromosome,
                    crate::dataset::chrom::Chromosome::Y
                )
            })
            .count();
        samples.retain(|&index| {
            let denominator = if dataset.metadata.samples[index].sex == Sex::Male {
                variants.len()
            } else {
                nony
            };
            missing[positions[index]] <= missing_allowed(denominator as u64, threshold)
        });
        if samples.is_empty() {
            return Err(invalid("mind filtering left no samples"));
        }
        positions.fill(usize::MAX);
        for (position, &index) in samples.iter().enumerate() {
            positions[index] = position;
        }
        if samples.len() != original_sample_count {
            // Allele frequencies are defined after mind removes samples.
            cached = None;
            packed = PackedSelection::new(dataset, &samples);
        }
    }
    if thresholds.geno.is_some() || thresholds.hwe_midp.is_some() || thresholds.maf.is_some() {
        let decision_state = persistent.saturating_add(variants.len() * size_of::<usize>() * 2);
        if stats::metadata_bytes(&dataset.metadata)
            .saturating_add(dataset.shared_bytes())
            .saturating_add(decision_state)
            > execution.memory_bytes
        {
            return Err(invalid(
                "filter metadata and decision state exceed invocation memory budget",
            ));
        }
        let mut retained = Vec::with_capacity(variants.len());
        let mut pending = Vec::with_capacity(variants.len());
        for (ordinal, &index) in variants.iter().enumerate() {
            if let Some(count) = cached.as_ref().and_then(|counts| counts[ordinal]) {
                if count.keep(thresholds) {
                    retained.push(index);
                }
            } else {
                pending.push(index);
            }
        }
        stats::visit_batches(dataset, &pending, decision_state, execution, |batch| {
            let decisions = execution.pool.install(|| {
                batch
                    .par_iter()
                    .map(|(index, value)| {
                        let variant = &dataset.metadata.variants[*index];
                        if thresholds.hwe_midp.is_none()
                            && let Some(count) = packed.counts(value, variant)
                        {
                            return (*index, count.keep(thresholds));
                        }
                        let count = tally::variant(value, variant, &dataset.metadata, &positions);
                        let geno_ok = thresholds.geno.is_none_or(|threshold| {
                            count.missing.hardcall
                                <= missing_allowed(count.missing.observations, threshold)
                        });
                        let maf_ok = thresholds.maf.is_none_or(|threshold| {
                            count.nonmajor_frequency() >= threshold * (1.0 - SMALL_EPSILON)
                        });
                        let hwe_ok = thresholds.hwe_midp.is_none_or(|threshold| {
                            let [hom_ref, het, hom_alt] = count.hwe_counts;
                            hom_ref + het + hom_alt == 0
                                || crate::stats::hwe::midp_log(hom_ref, het, hom_alt)
                                    >= threshold.ln() * (1.0 + SMALL_EPSILON)
                        });
                        (*index, geno_ok && maf_ok && hwe_ok)
                    })
                    .collect::<Vec<_>>()
            });
            retained.extend(
                decisions
                    .into_iter()
                    .filter_map(|(index, keep)| keep.then_some(index)),
            );
            Ok(())
        })?;
        retained.sort_unstable();
        variants = retained;
        if variants.is_empty() {
            return Err(invalid("variant filtering left no variants"));
        }
    }
    Ok((samples, variants))
}
