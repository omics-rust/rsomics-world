# Adopted private first workflow

Plan: docs/plans/2026-11-01-plink-native-first-workflow.md in rsomics-world;
full proposal SHA256 57b4499c786af3c115968967e7940848c29c25ba9ae6724eda8d5791312f8c56.

Root owns Git, public actions and the final native-four/source/performance gates.
Coordinator owns Cargo, native codec, metadata, make, execution, CLI and shared
contracts. No operation worker starts until concrete interfaces are frozen.

The single connected workflow test is tests/workflow.py. Its initial observed
failure is native product absent. This is not compatibility or make acceptance.
QC/LD and prune extraction consume durable generations, not transient import
state. One whole-feature review/fix wave follows working implementations.

Initial source-derived codec closure is 27 files/2108660 bytes; vendor/SOURCE.json
binds exact captured originals. The private static codec route is adopted for
implementation only, not public distribution or legal qualification.

Task1 active: native Mac arm64 production codec compiled with the exact six
library units. Initial compile error was uintptr_t/uint64_t pointer aliasing
on macOS; fixed explicitly in the private ABI view, without changing vendor.
Six-lane raw-state make/reopen/selected65 and ordinary-error preservation passed
2/2 tests in plink-native-make-test-20261101-2.log under external tmp. Initial
HDS missing-pair `.,.` handling was corrected to fall back to DS/GT, following
the inspected source. No upstream binary/runtime executed locally.

Shared contracts frozen in INTERFACES.md. Raw DS/HDS parsing deliberately uses
f64 lexical tokens (noodles Record/typed GT) instead of f32 RecordBuf dosage,
to retain the captured quantized rounding thresholds. Number=1 scalar DS
cardinality is strict per adopted invalid-input incompatibility ruling.

The implemented CLI now exposes make with shared QC filters, complete stats,
unphased ld pairs and hardcall ld prune. There are no placeholder commands.
The initial whole-feature RED after actual gt.I import is preserved at
/Volumes/KIOXIA/Developments/tmp/plink-native-whole-workflow-20261101-red.log;
the completed graph now exercises those formerly missing operations.

The complete native1/4-worker six-lane graph passed at
/Volumes/KIOXIA/Developments/tmp/plink-native-whole-graph-20261101-3.log;
retained actual new-native outputs are
/Volumes/KIOXIA/Developments/tmp/plink-whole-native-ZkrRYt/native-graph.json.
This checks36 new I/F/P generations,114 principal report/list files per worker
profile and74878 raw sample cells. Expected source F/P files are comparisons
only. Every native descendant consumes its own native ancestor, including
native prune.in extraction, fresh P reload and re-QC. Full captured rows,
headers, lists/order, metadata/shapes, exact raw masks/units/reference state
and the unfiltered founder64 HWE probe are checked. The latter retains raw
v12 MIDP4.61606e-19/log18.3357; zero cannot pass the frozen comparison policy.

The whole graph exposed the coordinator's inclusive-PAR endpoint bug, corrected
in native import without changing source flags, fixtures or comparator. The
comparison policy SHA remains4b99373876681ecc7379e0653d26eff696a6c2f7dbc97482c57a31b7c3caf806;
expected168-body manifest SHA remainsd04404749b8b28ba53fbfab3805c47101c2fc7b0e7fff35d69f76b3f532132bc.

Strict Clippy passed on the integrated tree in
/Volumes/KIOXIA/Developments/tmp/plink-native-integrated-clippy-20261101-2.log.
The initial3 mechanical diagnostics were fixed, not suppressed. The unused
universal ploidy helpers were removed in favor of concrete report populations.
QC reports effective_worker_limit (bounded batch parallel capacity); LD reports
observed distinct effective_workers. Both distinguish one ordered writer.

Pre-review debug/release full suites PASS (4 library tests plus1 connected workflow,
binary/doc0; no ignores). Receipts:
/Volumes/KIOXIA/Developments/tmp/plink-native-final-debug-20261101.log and
/Volumes/KIOXIA/Developments/tmp/plink-native-final-release-20261101.log.
Actual final debug/release new-native corpora are respectively
/Volumes/KIOXIA/Developments/tmp/plink-whole-native-9i3BjE and
/Volumes/KIOXIA/Developments/tmp/plink-whole-native-G2UyiZ. Each independently
checks the full1/4-worker graph and74878 raw cells. Frozen owner file identities,
compiler/argv receipts and final lint/format status belong in the external packet.

Compiler identity/full base argv is in the dedicated Cargo OUT_DIR compiler.txt;
full first build/first ABI error, corrected build and latest build are retained
as plink-native-build-20261101.log, -2.log and -3.log under external tmp.
Local cc selected macOS deployment target27.0; no older-host portability claim
is made. Build metadata supports native-four hosted builds without embedding
Mac fixture locations; local macOS compilation still requires the physical
external-target guard.

The single fresh whole-product review is
/Volumes/KIOXIA/Developments/tmp/plink-whole-feature-review-20261101.NoJLl8/REPORT.md,
SHAda4884f18c119758a49eca399fdc1c7833f607dcde8fadbd19a58acce62d06ca.
Root adopted one concentrated material correction wave, implemented together:

- Dataset reconciles PGEN header/index REF with delegated PVAR PR before
  stats/LD metadata is exposed. Explicit contradiction rejection is retained;
  no full genotype decode scan was added.
- Make admits persistent metadata/selection/index/reference state, formatting,
  packed raw/selected data and simultaneous reader/writer workspaces. Private
  ABI2 reports actual owned codec allocations; no public memory API was added.
- Shim writer offsets are vector<uintptr_t>, converted from the fixed-u64 ABI,
  and passed without the aliasing reinterpret cast. Vendor bodies are unchanged.
- Source-ordered projection now advances linear sparse calls cursors; the
  unused quadratic random-rank accessor was removed. Existing HDS/all-cell/
  selected65 checks retain exact phase/dosage/dphase/REF semantics.
- Only reader codec open/init is process-locked, protecting the library's
  non-atomic allocation-failure diagnostic. Readers remain task-local/non-Send;
  reads and compute stay parallel/unlocked. No OOM was deliberately induced.

The existing connected test observed both material runtime failures before
the fix: external REF metadata unresolved, 1MiB admission accepted and an
output generation published (plink-review-wave-red-20261101.log). Its exact
4,195,985-byte PVAR matches the review's original probe construction.

Post-wave debug whole suite passes in plink-review-wave-debug-20261101.log,
with new-native corpus /Volumes/KIOXIA/Developments/tmp/plink-whole-native-4N48gZ.
Post-wave strict Clippy passes in plink-review-wave-clippy-20261101.log.
Post-wave release whole suite also passes in plink-review-wave-release-20261101.log,
with new-native corpus /Volumes/KIOXIA/Developments/tmp/plink-whole-native-W4gsaS.
Both retain4 library tests and1 fullgraph test, with no ignored/failing tests.
Final fmt receipts and owner freeze identities are recorded in the
closure packet /Volumes/KIOXIA/Developments/tmp/plink-material-wave-close-20261101.pPcIh0.

Actual direct production stats/LD now matches the external input's OWN captured
REF state on320 report rows and1016 pair rows. The original reviewer PGEN/PGI/
PVAR/PSAM bodies are unchanged; its4.2MB PVAR with1MiB budget now exits1 with
memory4249708>1048576 and publishes no generation files. Receipts are bound in
the closure packet's FIXED-ENTRYPOINTS.json. This is admission evidence, not an
RSS/allocator-failure campaign or representative performance result.

The accepted external-index input/missing-PGI failure probe retains its original
CAPTURE receipts under tests/fixtures/external. Its expected raw data uses the
probe's own capture, not an incorrectly associated gt.I capture (different REF
status). Canonical wholegraph goldens were never changed by this correction.

No Git/index, public remote, publication or unrelated repository edits were
performed. Native-four, source cross-read of these same new native outputs,
representative real-cohort performance and exact license/source/relink
distribution gates remain root-owned and unqualified. No second review ladder
was started; the adopted review's material fixes close in this one wave.
