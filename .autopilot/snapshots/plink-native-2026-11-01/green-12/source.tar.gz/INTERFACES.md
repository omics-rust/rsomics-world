# Private first-workflow shared contracts

Freeze 2026-11-01 after actual six-lane native codec/make/reopen/subset tests.
These are product-private contracts, not a public foundation or advertised API.
Coordinator owns Cargo, build/native/vendor, CLI, dataset, io, execution and
make/mod.rs. Operation workers own only their assigned stats/ld/filter paths.
Only the coordinator runs Cargo to avoid simultaneous competing builds.

## Existing callable interfaces

- `Dataset::open(InputSpec, ImportProfile) -> Result<Dataset>` validates metadata
  and a native generation hash manifest when present. PGEN/VCF/BED metadata is
  immutable in a dataset. PGEN header/index reference flags are reconciled with
  delegated PVAR PR before returning; no genotype decode scan is used. Dataset
  is not a dense genotype matrix.
- `dataset.metadata.samples: Vec<Sample>` preserves full ordinal row order.
  Sample has `fid`, `iid`, `sid`, `paternal`, `maternal`, `sex`, `fields` and
  `founder()` (both parent IDs zero). Sex is Unknown/Male/Female.
- `dataset.metadata.variants: Vec<Variant>` preserves ordinal order. Variant has
  `chromosome`, `position: u64`, `id`, `alleles` (REF first, unused ALT retained),
  `provisional_ref`, `fields`. `Chromosome` is Autosome(u8), X, Y, Par1, Par2,
  Mt, Other(String), with `is_autosome()`.
- `dataset.reader() -> Result<Box<dyn GenotypeReader>>`. Every worker opens its
  own reader inside its task; no reader is shared/Sync. `read(VariantId(usize))
  -> Result<Genotypes>` returns an OWNED packed variant. `workspace_bytes()`
  reports owned codec/Rust workspace. A private process mutex serializes only
  C++ reader open/init because its allocation-failure diagnostic is non-atomic;
  readers are not sent between threads and reads/compute remain unlocked.
  `close(self: Box<Self>)` propagates successful-path
  cleanup errors. Shared dataset metadata may be borrowed by worker closures.
- `Genotypes` has `samples`, `allele_count`, `provisional_ref`, packed two-bit
  `genotypes`, patch masks/payloads, phase/dosage/dphase masks/payloads. Main codes
  are 0 homREF, 1 REF/ALT1, 2 ALT1/ALT1, 3 missing; multiallelic patches refine
  codes 1/2. `calls()` yields `Call { alleles: Option<[u8;2]>,
  phase: bool, reversed: bool, dosage: Option<u16>, dphase: Option<i16> }`.
  Alleles are sorted. Reversed is meaningful only with phase and means the
  original first allele is the larger one. No homozygous/implicit phase is
  synthesized. Dosage is 0..32768 in 16384ths; dphase is signed raw delta.
  Sparse payload cursors run in O(samples); sample projection also uses this
  linear stream, with unique increasing source ordinals. The unused random
  rank-scanning call accessor was removed. `bytes()` is
  the owned packed payload size. Do not allocate per-pair sample vectors.
- The unused initial universal ploidy helpers were removed when concrete QC
  policy landed. Reports have different source-backed chromosome/sex/founder
  populations and Y missingness denominators in stats/tally. No generic ploidy
  helper is passed off as all report policy. Raw codec values remain unchanged.
  `dataset::policy::SMALL_EPSILON` is the one shared exact2^-44 source constant.
- `make::Selection` contains optional keep/remove/extract/exclude PathBufs,
  `autosome: bool`, `max_alleles: Option<usize>`. `make::select(&Dataset,
  &Selection) -> Result<(Vec<usize>,Vec<usize>)>` returns input-order sample and
  variant ordinals. `make::materialize(&Dataset, &[sample_ordinal],
  &[variant_ordinal], &out_prefix, &Execution)` writes a fresh complete PGEN
  generation without hidden report filtering. Reject empty final dimensions.
  Make admission includes persistent metadata/selection/index/reference state,
  formatting and packed raw/selected buffers plus simultaneous reader/writer
  workspaces. Private ABI2 reports the writer's actual owned allocations and
  stores its codec offsets as uintptr_t, converting fixed-u64 ABI inputs.
- `Execution` exposes requested_workers, memory_bytes, rayon pool and
  `batch_width(reader_workspace,per_variant_bytes)`, capped at1024. Budget all
  concurrently alive reader workspaces/buffers/caches; codec open/init is
  process-serialized while handles stay task-local. Do not materialize a cohort
  matrix. Requested and actual
  compute workers are reported separately from one writer worker.
- `dataset::sibling(prefix,extension)` appends a suffix, never replaces an
  existing dotted prefix extension. `crate::{Result,invalid}` is the shared
  fail-loud error route. `rsomics_common::AtomicFile` and output-alias checks
  are available to operation writers; outputs commit as a recoverable group.

## Operation connection

Implemented private configs are `StatsConfig {pgen,out,selection}`,
`PairConfig {pfile,out,selection,window_variants,window_bp,min_r2,
allow_small_founders}` and `PruneConfig {pfile,out,selection,window,step,r2}`.
`stats::run`, `ld::pairs`, `ld::prune` receive `&Execution` and return typed
serializable reports. QC reports bounded effective_worker_limit; LD counts
actual effective_workers. Stats reopens durable F/P. Prune only emits ordered
keep/drop lists; explicit make extraction produces P.

`FilterThresholds` has optional mind/geno/hwe_midp/maf. `apply(&Dataset,
Vec<usize>,Vec<usize>,&FilterThresholds,&Execution)` returns ordered sample/
variant lists. Mind precedes recomputed variant decisions under concrete
report-specific founder/ploidy/dosage policy. Make calls it between select and
materialize; F/P report statistics are freshly recomputed, not reused filter
decision state. No duplicate codec/readers or speculative public crate exists.

## Current connected evidence, not final acceptance

`src/native_workflow.rs` passes six actual make/reopen paths and
selected65 re-materializations against every accepted source-I raw cell. It
also checks malformed import keeps an old generation byte-identical and that
mixed metadata fails native manifest verification. Its existing connected case
also checks external-index/header REF and4.2MB metadata rejection at1MiB before
publication. `tests/workflow.rs` executes the complete real CLI graph through
`tests/workflow.py` and then privately inspects every native I/F/P raw cell.
Full source rows/lists/order/metadata, raw identities and the tiny positive
founder64 HWE pass in debug/release at requested1/4 workers. The frozen
comparison policy and source answers are unchanged. Native-four, source-on-
native and representative performance/distribution remain separate gates.
