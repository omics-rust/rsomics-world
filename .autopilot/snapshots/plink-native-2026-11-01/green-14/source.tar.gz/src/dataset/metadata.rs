use super::{chrom::Chromosome, sibling};
use crate::{Result, invalid};
use std::{collections::HashSet, fs, io::Write, path::Path};
pub(crate) mod text;
use text::{Fields, RowsBuilder, Text};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum Sex {
    Unknown,
    Male,
    Female,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ten_thousand_variants_fit_metadata_budget() {
        let dir = tempfile::Builder::new()
            .prefix("compact-budget-")
            .tempdir_in(std::env::temp_dir())
            .unwrap()
            .keep();
        let prefix = dir.join("input");
        fs::write(sibling(&prefix, "psam"), "#IID\nsubject\n").unwrap();
        let mut pvar = String::from("#CHROM POS ID REF ALT\n");
        for i in 1..=10_000 {
            use std::fmt::Write;
            writeln!(pvar, "1 {i} variant{i} A C").unwrap();
        }
        fs::write(sibling(&prefix, "pvar"), pvar).unwrap();
        let metadata = Metadata::read_pgen(&prefix).unwrap();
        let bytes = crate::dataset::metadata_bytes(&metadata);
        eprintln!("retained fixture {}, owned metadata {bytes}", dir.display());
        assert!(bytes <= 3_706_987, "owned metadata {bytes} exceeds budget");
    }

    #[test]
    fn owned_clone_roundtrips_unknown_utf8_columns_and_reference_flags() {
        let dir = tempfile::Builder::new()
            .prefix("compact-roundtrip-")
            .tempdir_in(std::env::temp_dir())
            .unwrap()
            .keep();
        let prefix = dir.join("input");
        fs::write(
            sibling(&prefix, "psam"),
            "##sample-note\n#FID IID SID PAT MAT SEX EXTRA\nf α s 0 0 2 café\n",
        )
        .unwrap();
        fs::write(
            sibling(&prefix, "pvar"),
            "##site-note\n#CHROM POS ID REF ALT INFO EXTRA\n1 7 β A C,é PR;X=1 λ\nX 8 γ G T . μ\n",
        )
        .unwrap();
        let metadata = {
            let source = Metadata::read_pgen(&prefix).unwrap();
            source.clone()
        };
        metadata.validate().unwrap();
        let mut psam = Vec::new();
        let mut pvar = Vec::new();
        metadata.write_samples(&mut psam, &[0]).unwrap();
        metadata
            .write_variants(&mut pvar, &[0, 1], &[false, true])
            .unwrap();
        fs::write(dir.join("before.psam"), &psam).unwrap();
        fs::write(dir.join("before.pvar"), &pvar).unwrap();
        assert_eq!(
            psam,
            "##sample-note\n#FID\tIID\tSID\tPAT\tMAT\tSEX\tEXTRA\nf\tα\ts\t0\t0\t2\tcafé\n"
                .as_bytes()
        );
        assert_eq!(pvar, "##site-note\n##INFO=<ID=PR,Number=0,Type=Flag,Description=\"Provisional reference allele\">\n#CHROM\tPOS\tID\tREF\tALT\tINFO\tEXTRA\n1\t7\tβ\tA\tC,é\tX=1\tλ\nX\t8\tγ\tG\tT\tPR\tμ\n".as_bytes());
        assert_eq!(metadata.variants[0].alleles[2], "é");
    }

    #[test]
    fn reordered_duplicate_columns_keep_first_values_and_validate_all_widths() {
        let dir = tempfile::Builder::new()
            .prefix("compiled-columns-")
            .tempdir_in(std::env::temp_dir())
            .unwrap()
            .keep();
        let prefix = dir.join("input");
        fs::write(
            sibling(&prefix, "psam"),
            "##sample-note\r\n#SEX IID IID EXTRA\r\n2\u{2003}α ignored café\r\n",
        )
        .unwrap();
        fs::write(
            sibling(&prefix, "pvar"),
            "##site-note\r\n#ALT ID CHROM REF POS INFO POS ALT\r\nC,é β X A 7 PR;X=1 invalid ignored\r\n",
        )
        .unwrap();
        let metadata = Metadata::read_pgen(&prefix).unwrap();
        metadata.validate().unwrap();
        let sample = &metadata.samples[0];
        assert_eq!(sample.iid, "α");
        assert_eq!(sample.sex, Sex::Female);
        assert_eq!(sample.fid, "0");
        assert_eq!(sample.sid, "0");
        assert!(sample.founder());
        let variant = &metadata.variants[0];
        assert_eq!(variant.chromosome, Chromosome::X);
        assert_eq!(variant.position, 7);
        assert_eq!(variant.id, "β");
        assert_eq!(
            variant.alleles.iter().map(Text::as_str).collect::<Vec<_>>(),
            ["A", "C", "é"]
        );
        assert!(variant.provisional_ref);
        let mut output = Vec::new();
        metadata
            .write_variants(&mut output, &[0], &[false])
            .unwrap();
        assert_eq!(output, "##site-note\n##INFO=<ID=PR,Number=0,Type=Flag,Description=\"Provisional reference allele\">\n#ALT\tID\tCHROM\tREF\tPOS\tINFO\tPOS\tALT\nC,é\tβ\tX\tA\t7\tX=1\tinvalid\tignored\n".as_bytes());
        fs::write(
            sibling(&prefix, "pvar"),
            "#CHROM POS ID REF ALT\n1 invalid v A C\n1 8 short A\n",
        )
        .unwrap();
        assert_eq!(
            Metadata::read_pgen(&prefix).unwrap_err().to_string(),
            "invalid input: metadata row/header width mismatch"
        );
        fs::write(sibling(&prefix, "psam"), "#IID SEX\nα invalid\nshort\n").unwrap();
        assert_eq!(
            Metadata::read_pgen(&prefix).unwrap_err().to_string(),
            "invalid input: metadata row/header width mismatch"
        );
    }
}
#[derive(Clone, Debug)]
pub(crate) struct Sample {
    pub fid: Text,
    pub iid: Text,
    pub sid: Text,
    pub paternal: Text,
    pub maternal: Text,
    pub sex: Sex,
    pub fields: Fields,
}
impl Sample {
    pub fn founder(&self) -> bool {
        self.paternal == "0" && self.maternal == "0"
    }
}
#[derive(Clone, Debug)]
pub(crate) struct Variant {
    pub chromosome: Chromosome,
    pub position: u64,
    pub id: Text,
    pub alleles: Vec<Text>,
    pub provisional_ref: bool,
    pub fields: Fields,
}
#[derive(Clone, Debug)]
pub(crate) struct Metadata {
    pub sample_header: Vec<String>,
    pub variant_header: Vec<String>,
    pub sample_preamble: Vec<String>,
    pub variant_preamble: Vec<String>,
    pub samples: Vec<Sample>,
    pub variants: Vec<Variant>,
}
struct TextTable {
    preamble: Vec<String>,
    header: Vec<String>,
    rows: RowsBuilder,
}
fn table(path: &Path) -> Result<TextTable> {
    let text = fs::read_to_string(path)?;
    let mut preamble = Vec::new();
    let mut header = None;
    let mut rows = RowsBuilder::default();
    for line in text.lines().filter(|line| !line.is_empty()) {
        if line.starts_with("##") {
            preamble.push(line.into());
        } else if let Some(line) = line.strip_prefix('#') {
            if header.is_some() {
                return Err(invalid("duplicate metadata header"));
            }
            header = Some(
                line.split_whitespace()
                    .map(str::to_owned)
                    .collect::<Vec<_>>(),
            );
        } else {
            rows.push_row(line.split_whitespace());
        }
    }
    let header =
        header.ok_or_else(|| invalid(format!("{} has no column header", path.display())))?;
    if !rows.has_width(header.len()) {
        return Err(invalid("metadata row/header width mismatch"));
    }
    Ok(TextTable {
        preamble,
        header,
        rows,
    })
}
struct Column(Option<usize>);
impl Column {
    fn bind(header: &[String], key: &str) -> Self {
        Self(header.iter().position(|name| name == key))
    }
    fn field<'a>(&self, row: &'a Fields, default: &'a str) -> &'a str {
        self.0.map(|i| &row[i]).unwrap_or(default)
    }
    fn text(&self, row: &Fields) -> Text {
        self.0
            .and_then(|i| row.text(i))
            .unwrap_or_else(|| row.zero())
    }
}
struct SampleColumns {
    fid: Column,
    iid: Column,
    sid: Column,
    paternal: Column,
    maternal: Column,
    sex: Column,
}
impl SampleColumns {
    fn bind(header: &[String]) -> Result<Self> {
        let iid = Column::bind(header, "IID");
        if iid.0.is_none() {
            return Err(invalid("PSAM requires IID"));
        }
        Ok(Self {
            fid: Column::bind(header, "FID"),
            iid,
            sid: Column::bind(header, "SID"),
            paternal: Column::bind(header, "PAT"),
            maternal: Column::bind(header, "MAT"),
            sex: Column::bind(header, "SEX"),
        })
    }
    fn samples(&self, rows: impl ExactSizeIterator<Item = Fields>) -> Result<Vec<Sample>> {
        let mut samples = Vec::with_capacity(rows.len());
        for row in rows {
            samples.push(Sample {
                fid: self.fid.text(&row),
                iid: self.iid.text(&row),
                sid: self.sid.text(&row),
                paternal: self.paternal.text(&row),
                maternal: self.maternal.text(&row),
                sex: match self.sex.field(&row, "0") {
                    "0" | "NA" => Sex::Unknown,
                    "1" => Sex::Male,
                    "2" => Sex::Female,
                    _ => return Err(invalid("SEX must be 0, 1, 2 or NA")),
                },
                fields: row,
            });
        }
        Ok(samples)
    }
}
struct VariantColumns {
    chromosome: Column,
    position: Column,
    id: Column,
    reference: Column,
    alternate: Column,
    info: Column,
}
impl VariantColumns {
    fn bind(header: &[String]) -> Result<Self> {
        let required = |key| {
            let column = Column::bind(header, key);
            if column.0.is_none() {
                return Err(invalid(format!("PVAR requires {key}")));
            }
            Ok(column)
        };
        Ok(Self {
            chromosome: required("CHROM")?,
            position: required("POS")?,
            id: required("ID")?,
            reference: required("REF")?,
            alternate: required("ALT")?,
            info: Column::bind(header, "INFO"),
        })
    }
    fn variants(&self, rows: impl ExactSizeIterator<Item = Fields>) -> Result<Vec<Variant>> {
        let mut variants = Vec::with_capacity(rows.len());
        for row in rows {
            let mut alleles = Vec::with_capacity(2);
            alleles.push(self.reference.text(&row));
            alleles.extend(self.alternate.text(&row).split(','));
            let position = self
                .position
                .field(&row, "")
                .parse()
                .map_err(|_| invalid("invalid PVAR position"))?;
            variants.push(Variant {
                chromosome: Chromosome::parse(self.chromosome.field(&row, "")),
                position,
                id: self.id.text(&row),
                alleles,
                provisional_ref: self.info.field(&row, ".").split(';').any(|x| x == "PR"),
                fields: row,
            });
        }
        Ok(variants)
    }
}
pub(crate) fn samples(header: &[String], rows: Vec<Fields>) -> Result<Vec<Sample>> {
    SampleColumns::bind(header)?.samples(rows.into_iter())
}
pub(crate) fn read_samples(path: &Path) -> Result<(Vec<String>, Vec<String>, Vec<Sample>)> {
    let TextTable {
        preamble,
        header,
        rows,
    } = table(path)?;
    let data = SampleColumns::bind(&header)?.samples(rows.into_rows())?;
    Ok((preamble, header, data))
}
impl Metadata {
    pub fn read_pgen(prefix: &Path) -> Result<Self> {
        let (sample_preamble, sample_header, samples) = read_samples(&sibling(prefix, "psam"))?;
        let TextTable {
            preamble: variant_preamble,
            header: variant_header,
            rows,
        } = table(&sibling(prefix, "pvar"))?;
        let variants = VariantColumns::bind(&variant_header)?.variants(rows.into_rows())?;
        Ok(Self {
            sample_header,
            variant_header,
            sample_preamble,
            variant_preamble,
            samples,
            variants,
        })
    }
    pub fn validate(&self) -> Result<()> {
        let mut identities = HashSet::new();
        for sample in &self.samples {
            if sample.iid.is_empty() || !identities.insert((&sample.fid, &sample.iid, &sample.sid))
            {
                return Err(invalid("duplicate/empty sample identity"));
            }
        }
        if self.samples.len() > (i32::MAX as usize) - 1
            || self.variants.len() > (i32::MAX as usize) - 2
        {
            return Err(invalid("dataset exceeds codec dimensions"));
        }
        for variant in &self.variants {
            if !(2..=255).contains(&variant.alleles.len())
                || variant.alleles.iter().any(|value| value.is_empty())
            {
                return Err(invalid("invalid allele metadata"));
            }
        }
        Ok(())
    }
    pub fn offsets(&self) -> Vec<u64> {
        let mut result = Vec::with_capacity(self.variants.len() + 1);
        result.push(0);
        for v in &self.variants {
            result.push(result.last().copied().unwrap_or(0) + v.alleles.len() as u64);
        }
        result
    }
    pub fn write_samples(&self, output: &mut dyn Write, selected: &[usize]) -> Result<()> {
        for line in &self.sample_preamble {
            writeln!(output, "{line}")?;
        }
        writeln!(output, "#{}", self.sample_header.join("\t"))?;
        for &i in selected {
            for (column, value) in self.samples[i].fields.iter().enumerate() {
                if column != 0 {
                    output.write_all(b"\t")?;
                }
                output.write_all(value.as_bytes())?;
            }
            output.write_all(b"\n")?;
        }
        Ok(())
    }
    pub fn write_variants(
        &self,
        output: &mut dyn Write,
        selected: &[usize],
        provisional: &[bool],
    ) -> Result<()> {
        let mut header = self.variant_header.clone();
        let info = header.iter().position(|s| s == "INFO").unwrap_or_else(|| {
            header.push("INFO".into());
            header.len() - 1
        });
        for line in &self.variant_preamble {
            writeln!(output, "{line}")?;
        }
        if !self
            .variant_preamble
            .iter()
            .any(|line| line.starts_with("##INFO=<ID=PR,"))
        {
            writeln!(
                output,
                "##INFO=<ID=PR,Number=0,Type=Flag,Description=\"Provisional reference allele\">"
            )?;
        }
        writeln!(output, "#{}", header.join("\t"))?;
        for (&i, &pr) in selected.iter().zip(provisional) {
            let row = &self.variants[i].fields;
            for column in 0..header.len() {
                if column != 0 {
                    output.write_all(b"\t")?;
                }
                let value = row.get(column).unwrap_or(".");
                if column == info {
                    let mut present = false;
                    for field in value.split(';').filter(|x| *x != "PR" && *x != ".") {
                        if present {
                            output.write_all(b";")?;
                        }
                        output.write_all(field.as_bytes())?;
                        present = true;
                    }
                    if pr {
                        if present {
                            output.write_all(b";")?;
                        }
                        output.write_all(b"PR")?;
                    } else if !present {
                        output.write_all(b".")?;
                    }
                } else {
                    output.write_all(value.as_bytes())?;
                }
            }
            output.write_all(b"\n")?;
        }
        Ok(())
    }
}
