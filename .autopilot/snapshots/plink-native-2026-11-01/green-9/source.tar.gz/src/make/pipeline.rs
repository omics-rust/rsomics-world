use super::MakeMemory;
use crate::dataset::{Dataset, VariantId, genotypes::Genotypes};
use crate::execution::Execution;
use crate::io::pgen;
use crate::{Result, invalid, ordered};
use std::mem::size_of;

pub(super) struct Plan {
    lanes: usize,
    rows: usize,
    partitions: usize,
}

struct Block {
    rows: Vec<Genotypes>,
    used: usize,
}

impl Plan {
    pub(super) fn new(
        dataset: &Dataset,
        variants: usize,
        execution: &Execution,
        memory: &MakeMemory,
        writer_bytes: usize,
    ) -> Option<Self> {
        let reader_bytes = dataset.prepared_reader_bytes()?;
        let limit = execution
            .requested_workers
            .saturating_sub(1)
            .min(execution.pool.current_num_threads())
            .min(variants);
        let row_bytes = dataset
            .metadata
            .samples
            .len()
            .saturating_mul(128)
            .saturating_add(8192 + size_of::<Genotypes>());
        let target_rows = (262_144 / row_bytes).clamp(1, 64);
        let base = memory.with_codecs(0, writer_bytes);
        for lanes in (1..=limit).rev() {
            let fixed = base
                .saturating_add(lanes.saturating_mul(reader_bytes))
                .saturating_add(ordered::memory_bytes::<Block, ()>(lanes));
            let available = execution.memory_bytes.saturating_sub(fixed);
            let rows = (available / (4 * lanes + 1).saturating_mul(row_bytes)).min(target_rows);
            if rows == 0 {
                continue;
            }
            let partitions = variants.div_ceil(rows);
            if partitions < 2 {
                continue;
            }
            return Some(Self {
                lanes: lanes.min(partitions),
                rows,
                partitions,
            });
        }
        None
    }
}

pub(super) fn materialize(
    dataset: &Dataset,
    samples: &[usize],
    variants: &[usize],
    provisional: &[bool],
    writer: &mut pgen::Writer,
    execution: &Execution,
    plan: Plan,
) -> Result<()> {
    let identity = samples.len() == dataset.metadata.samples.len();
    ordered::run(
        &execution.pool,
        plan.lanes,
        plan.partitions,
        |_| dataset.reader(),
        |reader, partition, sink: &ordered::Sink<Block, ()>| {
            let start = partition * plan.rows;
            let end = (start + plan.rows).min(variants.len());
            let mut block = sink.recycled().unwrap_or_else(|| Block {
                rows: (0..plan.rows)
                    .map(|_| Genotypes::empty(0, 2, false))
                    .collect(),
                used: 0,
            });
            block.used = end - start;
            for (ordinal, value) in (start..end).zip(&mut block.rows) {
                let index = variants[ordinal];
                reader.read_into(VariantId(index), value)?;
                if value.provisional_ref != provisional[ordinal]
                    || value.allele_count != dataset.metadata.variants[index].alleles.len()
                {
                    return Err(invalid("input variant metadata changed during make"));
                }
            }
            sink.send(block)
        },
        |reader| reader.close(),
        ordered::Consumer {
            write: |_, block: &mut Block| {
                for value in &block.rows[..block.used] {
                    if identity {
                        writer.append(value)?;
                    } else {
                        writer.append(&value.select(samples)?)?;
                    }
                }
                Ok(())
            },
            complete: |_| {},
        },
    )?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::dataset::{DosageField, ImportProfile, InputSpec, sibling};
    use crate::make::{self, MakeConfig, Selection};
    use crate::native_workflow::{assert_raw, fixtures, raw};
    use rsomics_common::AtomicFile;
    use serde_json::Value;
    use std::{fs, num::NonZeroUsize};

    #[test]
    fn ordered_make_and_ld_preserve_full_state_across_workers_and_serial_budget() {
        let directory = tempfile::tempdir_in(std::env::temp_dir()).unwrap();
        let inputs = fixtures().join("inputs");
        let original = fs::read_to_string(inputs.join("baseline.vcf")).unwrap();
        let mut large = original
            .lines()
            .filter(|line| line.starts_with('#'))
            .map(str::to_owned)
            .collect::<Vec<_>>();
        let rows = original
            .lines()
            .filter(|line| !line.starts_with('#'))
            .take(16)
            .map(|line| line.split('\t').map(str::to_owned).collect::<Vec<_>>())
            .collect::<Vec<_>>();
        for ordinal in 0..96 {
            let mut row = rows[ordinal % 16].clone();
            row[0] = "1".into();
            row[1] = (ordinal + 1).to_string();
            row[2] = format!("row{ordinal:03}_{}", "A".repeat(256));
            large.push(row.join("\t"));
        }
        let large_path = directory.path().join("large.vcf");
        fs::write(&large_path, large.join("\n") + "\n").unwrap();
        let serial = Execution::new(NonZeroUsize::new(1), 512).unwrap();
        let parallel = Execution::new(NonZeroUsize::new(4), 512).unwrap();
        for lane in ["gt", "ds", "hds"] {
            let out = directory.path().join(format!("{lane}.input"));
            make::run(
                &MakeConfig {
                    input: InputSpec::Vcf(if lane == "gt" {
                        large_path.clone()
                    } else {
                        inputs.join(format!("{lane}.vcf"))
                    }),
                    profile: ImportProfile {
                        psam: Some(inputs.join("baseline.psam")),
                        dosage: match lane {
                            "ds" => DosageField::Ds,
                            "hds" => DosageField::Hds,
                            _ => DosageField::None,
                        },
                        ..ImportProfile::default()
                    },
                    selection: Selection::default(),
                    filters: Default::default(),
                    out: out.clone(),
                },
                &serial,
            )
            .unwrap();
            let oracle = fs::read_to_string(fixtures().join(format!("oracle/{lane}/raw.jsonl")))
                .unwrap()
                .lines()
                .skip(1)
                .map(|line| serde_json::from_str::<Value>(line).unwrap())
                .collect::<Vec<_>>();
            let expected = if lane == "gt" {
                (0..96)
                    .map(|ordinal| {
                        let mut value = oracle[ordinal % 16].clone();
                        value["variant"] = ordinal.into();
                        value
                    })
                    .collect::<Vec<_>>()
            } else {
                oracle
            };
            for selected in [72, 65] {
                let mut bodies = Vec::new();
                for execution in [&serial, &parallel] {
                    let mut dataset =
                        Dataset::open(InputSpec::Pgen(out.clone()), ImportProfile::default())
                            .unwrap();
                    let variants = (0..dataset.metadata.variants.len()).collect::<Vec<_>>();
                    let samples = (0..selected).collect::<Vec<_>>();
                    let target = directory
                        .path()
                        .join(format!("{lane}.{selected}.{}", execution.requested_workers));
                    make::materialize(&mut dataset, &samples, &variants, &target, execution)
                        .unwrap();
                    let reopened =
                        Dataset::open(InputSpec::Pgen(target.clone()), ImportProfile::default())
                            .unwrap();
                    let mut selected_expected = expected.clone();
                    for row in &mut selected_expected {
                        row["calls"].as_array_mut().unwrap().truncate(selected);
                    }
                    assert_raw(&raw(&reopened), &selected_expected, lane);
                    bodies.push(
                        ["pgen", "pvar", "psam"]
                            .map(|extension| fs::read(sibling(&target, extension)).unwrap()),
                    );
                }
                assert_eq!(
                    bodies[0], bodies[1],
                    "{lane} selected{selected} worker order"
                );
            }
            if lane == "gt" {
                let mut dataset =
                    Dataset::open(InputSpec::Pgen(out.clone()), ImportProfile::default()).unwrap();
                let samples = (0..dataset.metadata.samples.len()).collect::<Vec<_>>();
                let variants = (0..dataset.metadata.variants.len()).collect::<Vec<_>>();
                let reader = dataset.reader().unwrap();
                let flags = reader.track_flags().unwrap();
                let temporary =
                    AtomicFile::new(directory.path().join("budget-probe.pgen")).unwrap();
                let writer = pgen::Writer::open(
                    temporary.temporary_path(),
                    samples.len(),
                    &dataset.metadata.offsets(),
                    &dataset
                        .metadata
                        .variants
                        .iter()
                        .map(|variant| variant.provisional_ref)
                        .collect::<Vec<_>>(),
                    flags,
                )
                .unwrap();
                let memory = MakeMemory::new(&dataset, &samples, &variants);
                let mut limited = Execution::new(NonZeroUsize::new(4), 512).unwrap();
                limited.memory_bytes =
                    memory.with_codecs(reader.workspace_bytes(), writer.workspace_bytes());
                assert!(
                    Plan::new(
                        &dataset,
                        variants.len(),
                        &parallel,
                        &memory,
                        writer.workspace_bytes()
                    )
                    .is_some()
                );
                assert!(
                    Plan::new(
                        &dataset,
                        variants.len(),
                        &limited,
                        &memory,
                        writer.workspace_bytes()
                    )
                    .is_none()
                );
                reader.close().unwrap();
                drop(writer);
                dataset.close().unwrap();
                let target = directory.path().join("limited");
                let mut dataset =
                    Dataset::open(InputSpec::Pgen(out.clone()), ImportProfile::default()).unwrap();
                make::materialize(&mut dataset, &samples, &variants, &target, &limited).unwrap();
                let reopened =
                    Dataset::open(InputSpec::Pgen(target), ImportProfile::default()).unwrap();
                assert_raw(&raw(&reopened), &expected, "serial budget fallback");
                let mut tables = Vec::new();
                for execution in [&serial, &parallel] {
                    let target = directory
                        .path()
                        .join(format!("pairs{}", execution.requested_workers));
                    let report = crate::ld::pairs(
                        &crate::ld::PairConfig {
                            pfile: out.clone(),
                            out: target.clone(),
                            ..Default::default()
                        },
                        execution,
                    )
                    .unwrap();
                    assert_eq!(report.evaluated_pairs, 4560);
                    let bytes = fs::read(sibling(&target, "vcor")).unwrap();
                    assert!(bytes.len() > 2 * 65_536);
                    tables.push(bytes);
                }
                assert_eq!(tables[0], tables[1]);
            }
        }
    }
}
