use super::{Prepared, Resources, VariantCache, check_outputs, output_parent};
use crate::dataset::policy::SMALL_EPSILON;
use crate::dataset::sibling;
use crate::execution::Execution;
use crate::make::Selection;
use crate::{Result, invalid};
use rayon::prelude::*;
use rsomics_common::AtomicFile;
use serde::Serialize;
use std::collections::BTreeSet;
use std::fs::File;
use std::io::{BufWriter, Seek, SeekFrom, Write};
use std::mem::size_of;
use std::ops::Range;
use std::path::{Path, PathBuf};

#[derive(Clone, Copy, Debug)]
pub(crate) enum PruneWindow {
    BasePairs(u64),
    Variants(usize),
}

#[derive(Clone, Debug)]
pub(crate) struct PruneConfig {
    pub pfile: PathBuf,
    pub out: PathBuf,
    pub selection: Selection,
    pub window: PruneWindow,
    pub step: usize,
    pub r2: f64,
}

impl Default for PruneConfig {
    fn default() -> Self {
        Self {
            pfile: PathBuf::new(),
            out: PathBuf::new(),
            selection: Selection::default(),
            window: PruneWindow::BasePairs(500_000),
            step: 1,
            r2: 0.2,
        }
    }
}

#[derive(Default, Serialize)]
pub(crate) struct PruneReport {
    pub selected_samples: usize,
    pub founders: usize,
    pub variants: usize,
    pub retained_variants: usize,
    pub removed_variants: usize,
    pub monomorphic_variants: usize,
    pub evaluated_pairs: u64,
    pub requested_workers: usize,
    pub effective_workers: usize,
    pub writer_workers: usize,
    pub order: u8,
}

struct Part {
    kept_file: File,
    removed_file: File,
    kept: usize,
    removed: usize,
    monomorphic: usize,
    evaluated: u64,
    worker: usize,
}

pub(crate) fn prune(config: &PruneConfig, execution: &Execution) -> Result<PruneReport> {
    if !config.r2.is_finite() || !(0.0..=1.0).contains(&config.r2) || config.step == 0 {
        return Err(invalid(
            "prune requires an r2 threshold in 0..1 and a positive step",
        ));
    }
    match config.window {
        PruneWindow::BasePairs(width) if width == 0 || config.step != 1 => {
            return Err(invalid(
                "base-pair pruning requires a positive window and step 1",
            ));
        }
        PruneWindow::Variants(width) if width < 2 || config.step > width => {
            return Err(invalid(
                "variant-count pruning requires a window of at least 2 and step no greater than the window",
            ));
        }
        _ => {}
    }
    check_outputs(
        &config.pfile,
        &config.selection,
        &config.out,
        &["prune.in", "prune.out"],
    )?;
    let input = Prepared::open(&config.pfile, &config.selection, 2)?;
    let mut tasks = Vec::new();
    for chromosome in &input.chromosomes {
        let mut start = chromosome.start;
        for ordinal in chromosome.start + 1..chromosome.end {
            let position = |i: usize| input.dataset.metadata.variants[input.variants[i]].position;
            if matches!(config.window, PruneWindow::BasePairs(width) if position(ordinal) - position(ordinal - 1) > width)
            {
                tasks.push(start..ordinal);
                start = ordinal;
            }
        }
        tasks.push(start..chromosome.end);
    }
    let extra = input
        .variants
        .len()
        .checked_mul(18)
        .and_then(|value| value.checked_add(tasks.capacity() * size_of::<Range<usize>>()))
        .ok_or_else(|| invalid("prune index memory estimate overflow"))?;
    let resources = Resources::new(&input, execution, tasks.len(), extra)?;
    {
        let mut ids: Vec<_> = input
            .variants
            .iter()
            .map(|&index| input.dataset.metadata.variants[index].id.as_str())
            .collect();
        ids.sort_unstable();
        if ids.windows(2).any(|pair| pair[0] == pair[1]) {
            return Err(invalid("LD pruning requires unique selected variant IDs"));
        }
    }
    let mut kept = AtomicFile::new(sibling(&config.out, "prune.in"))?;
    let mut removed = AtomicFile::new(sibling(&config.out, "prune.out"))?;
    let mut workers = BTreeSet::new();
    let mut report = PruneReport {
        selected_samples: input.selected_samples,
        founders: input.founders.indices.len(),
        variants: input.variants.len(),
        requested_workers: execution.requested_workers,
        writer_workers: 1,
        order: 2,
        ..PruneReport::default()
    };
    {
        let mut kept_writer = BufWriter::with_capacity(65_536, kept.file_mut());
        let mut removed_writer = BufWriter::with_capacity(65_536, removed.file_mut());
        for batch in tasks.chunks(resources.workers) {
            let parts: Vec<Result<Part>> = execution.pool.install(|| {
                batch
                    .par_iter()
                    .map(|range| {
                        calculate(
                            &input,
                            &resources,
                            config,
                            range.clone(),
                            output_parent(&config.out),
                        )
                    })
                    .collect()
            });
            for part in parts {
                let mut part = part?;
                part.kept_file.seek(SeekFrom::Start(0))?;
                part.removed_file.seek(SeekFrom::Start(0))?;
                std::io::copy(&mut part.kept_file, &mut kept_writer)?;
                std::io::copy(&mut part.removed_file, &mut removed_writer)?;
                report.retained_variants += part.kept;
                report.removed_variants += part.removed;
                report.monomorphic_variants += part.monomorphic;
                report.evaluated_pairs += part.evaluated;
                workers.insert(part.worker);
            }
        }
        kept_writer.flush()?;
        removed_writer.flush()?;
    }
    report.effective_workers = workers.len();
    AtomicFile::commit_all(vec![kept, removed])?;
    Ok(report)
}

fn calculate(
    input: &Prepared,
    resources: &Resources,
    config: &PruneConfig,
    range: Range<usize>,
    directory: &Path,
) -> Result<Part> {
    let ids = &input.variants[range];
    let position = |index: usize| input.dataset.metadata.variants[ids[index]].position;
    let mut removed = vec![false; ids.len()];
    let mut frequencies = vec![0.0; ids.len()];
    let mut active = Vec::with_capacity(ids.len());
    let mut cache = VariantCache::open(input, resources, false)?;
    let mut part = Part {
        kept_file: tempfile::tempfile_in(directory)?,
        removed_file: tempfile::tempfile_in(directory)?,
        kept: 0,
        removed: 0,
        monomorphic: 0,
        evaluated: 0,
        worker: rayon::current_thread_index().unwrap_or(0),
    };
    if ids.len() > 1 {
        let mut start = 0;
        let mut end = match config.window {
            PruneWindow::BasePairs(width) => ids.partition_point(|&id| {
                input.dataset.metadata.variants[id].position <= position(0).saturating_add(width)
            }),
            PruneWindow::Variants(width) => width.min(ids.len()),
        };
        let mut previous_end = 0;
        loop {
            let split = active.len();
            for ordinal in previous_end..end {
                cache.ensure(ids[ordinal], None)?;
                let data = cache.get(ids[ordinal]);
                frequencies[ordinal] = data.major_frequency;
                if data.hard.constant() {
                    removed[ordinal] = true;
                    part.monomorphic += 1;
                }
                active.push(ordinal);
            }
            // Newly loaded positions retain order-2 traversal even if an earlier
            // comparison in this window has already marked one for removal.
            for second in (split.max(1)..active.len()).rev() {
                let b = active[second];
                cache.ensure(ids[b], None)?;
                for &a in active[..second].iter().rev() {
                    if removed[a] {
                        continue;
                    }
                    cache.ensure(ids[a], Some(ids[b]))?;
                    let moments = resources
                        .kernel
                        .moments(&cache.get(ids[a]).hard, &cache.get(ids[b]).hard);
                    part.evaluated += 1;
                    if moments.exceeds(config.r2 * (1.0 + SMALL_EPSILON)) {
                        if frequencies[a] <= frequencies[b] * (1.0 + SMALL_EPSILON) {
                            removed[b] = true;
                            break;
                        }
                        removed[a] = true;
                    }
                }
            }
            if end == ids.len() {
                break;
            }
            previous_end = end;
            match config.window {
                PruneWindow::BasePairs(width) => {
                    let minimum = position(end).saturating_sub(width);
                    start += 1;
                    while position(start) < minimum {
                        start += 1;
                    }
                    let maximum = position(start).saturating_add(width);
                    end += 1;
                    while end < ids.len() && position(end) <= maximum {
                        end += 1;
                    }
                }
                PruneWindow::Variants(width) => {
                    start += config.step;
                    end = start.saturating_add(width).min(ids.len());
                }
            }
            active.retain(|&ordinal| ordinal >= start && !removed[ordinal]);
        }
    }
    {
        let mut kept_writer = BufWriter::with_capacity(65_536, &mut part.kept_file);
        let mut removed_writer = BufWriter::with_capacity(65_536, &mut part.removed_file);
        for (&id, &is_removed) in ids.iter().zip(&removed) {
            if is_removed {
                writeln!(removed_writer, "{}", input.dataset.metadata.variants[id].id)?;
                part.removed += 1;
            } else {
                writeln!(kept_writer, "{}", input.dataset.metadata.variants[id].id)?;
                part.kept += 1;
            }
        }
        kept_writer.flush()?;
        removed_writer.flush()?;
    }
    cache.close()?;
    Ok(part)
}
