pub(crate) mod chrom;
pub(crate) mod genotypes;
pub(crate) mod metadata;
pub(crate) mod policy;

use crate::io::{bed, pgen, vcf};
use crate::{Result, invalid};
use metadata::Metadata;
use std::path::{Path, PathBuf};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct VariantId(pub usize);
#[derive(Clone, Debug)]
pub(crate) enum InputSpec {
    Pgen(PathBuf),
    Bed(PathBuf),
    Vcf(PathBuf),
}
#[derive(Clone, Copy, Debug, Default)]
pub(crate) enum DosageField {
    #[default]
    None,
    Ds,
    Hds,
}
#[derive(Clone, Debug, Default)]
pub(crate) struct ImportProfile {
    pub dosage: DosageField,
    pub half_call_missing: bool,
    pub split_par_b37: bool,
    pub psam: Option<PathBuf>,
}

pub(crate) struct Dataset {
    pub metadata: Metadata,
    pub source: InputSpec,
    pub profile: ImportProfile,
}

pub(crate) trait GenotypeReader {
    fn read(&mut self, variant: VariantId) -> Result<genotypes::Genotypes>;
    fn read_into(&mut self, variant: VariantId, value: &mut genotypes::Genotypes) -> Result<()> {
        *value = self.read(variant)?;
        Ok(())
    }
    fn track_flags(&self) -> Option<u32> {
        None
    }
    fn workspace_bytes(&self) -> usize;
    fn close(self: Box<Self>) -> Result<()>;
}

impl Dataset {
    pub fn open(source: InputSpec, profile: ImportProfile) -> Result<Self> {
        let mut metadata = match &source {
            InputSpec::Pgen(prefix) => {
                crate::io::transaction::verify(prefix)?;
                Metadata::read_pgen(prefix)?
            }
            InputSpec::Bed(prefix) => bed::metadata(prefix)?,
            InputSpec::Vcf(path) => vcf::metadata(path, &profile)?,
        };
        if metadata.samples.is_empty() || metadata.variants.is_empty() {
            return Err(invalid(
                "dataset requires positive sample and variant counts",
            ));
        }
        metadata.validate()?;
        if let InputSpec::Pgen(prefix) = &source {
            let reader = pgen::Reader::open(prefix, &metadata)?;
            for (variant, &provisional) in metadata
                .variants
                .iter_mut()
                .zip(reader.resolved_reference())
            {
                variant.provisional_ref = provisional;
            }
            Box::new(reader).close()?;
        }
        Ok(Self {
            metadata,
            source,
            profile,
        })
    }
    pub fn reader(&self) -> Result<Box<dyn GenotypeReader>> {
        match &self.source {
            InputSpec::Pgen(prefix) => Ok(Box::new(pgen::Reader::open(prefix, &self.metadata)?)),
            InputSpec::Bed(prefix) => Ok(Box::new(bed::Reader::open(prefix, &self.metadata)?)),
            InputSpec::Vcf(path) => Ok(Box::new(vcf::Reader::open(
                path,
                &self.profile,
                &self.metadata,
            )?)),
        }
    }
}

pub(crate) fn sibling(prefix: &Path, extension: &str) -> PathBuf {
    let mut path = prefix.as_os_str().to_os_string();
    path.push(".");
    path.push(extension);
    PathBuf::from(path)
}
