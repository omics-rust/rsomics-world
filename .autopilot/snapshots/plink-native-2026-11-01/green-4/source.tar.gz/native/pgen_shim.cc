/* SPDX-License-Identifier: LGPL-3.0-or-later */
#include "pgen_shim.h"
#include "pgenlib_read.h"
#include "pgenlib_write.h"
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

using namespace plink2;
static_assert(sizeof(uintptr_t) == sizeof(uint64_t), "64-bit codec required");

namespace {
void check(PglErr e, const char *op) {
  if (e != kPglRetSuccess) throw std::runtime_error(std::string(op) + " codec status=" + std::to_string(static_cast<uint32_t>(e)));
}
template<class F> int boundary(char *error, size_t cap, F &&call) noexcept {
  try { call(); return 0; }
  catch (const std::exception &e) { if (cap) std::snprintf(error, cap, "%s", e.what()); return 1; }
  catch (...) { if (cap) std::snprintf(error, cap, "unexpected codec exception"); return 1; }
}
struct Storage {
  std::vector<void *> allocations;
  uint64_t bytes = 0;
  template<class T> T *alloc(size_t n) {
    const size_t size = std::max<size_t>(kCacheline, RoundUpPow2(n * sizeof(T), kCacheline));
    void *p = nullptr;
    if (cachealigned_malloc(size, &p)) throw std::bad_alloc();
    allocations.push_back(p); bytes += size;
    std::memset(p, 0, size);
    return static_cast<T *>(p);
  }
  ~Storage() { for (void *p : allocations) aligned_free(p); }
  uint64_t allocated_bytes() const { return bytes + allocations.capacity() * sizeof(void *); }
};
struct Tracks : Storage {
  PgenVariant value;
  uint32_t samples, words, genowords;
  explicit Tracks(uint32_t ns) : samples(ns), words(BitCtToWordCt(ns)), genowords(NypCtToWordCt(ns)) {
    PreinitPgv(&value);
    value.genovec = alloc<uintptr_t>(NypCtToVecCt(ns) * kWordsPerVec);
    value.patch_01_set = alloc<uintptr_t>(words);
    value.patch_10_set = alloc<uintptr_t>(words);
    value.patch_01_vals = alloc<AlleleCode>(ns);
    value.patch_10_vals = alloc<AlleleCode>(2 * ns);
    value.phasepresent = alloc<uintptr_t>(words);
    value.phaseinfo = alloc<uintptr_t>(words);
    value.dosage_present = alloc<uintptr_t>(words);
    value.dosage_main = alloc<uint16_t>(ns);
    value.dphase_present = alloc<uintptr_t>(words);
    value.dphase_delta = alloc<int16_t>(ns);
  }
  void reset() {
    value.patch_01_ct = value.patch_10_ct = value.phasepresent_ct = value.dosage_ct = value.dphase_ct = 0;
    for (auto p : {value.patch_01_set, value.patch_10_set, value.phasepresent, value.phaseinfo, value.dosage_present, value.dphase_present})
      std::memset(p, 0, words * sizeof(uintptr_t));
  }
  void copy(const RsPgVariantView &v) {
    if (v.samples != samples || v.mask_words != words || v.genotype_words != genowords ||
        v.patch01_count > samples || v.patch10_count > samples || v.dosage_count > samples || v.dphase_count > v.dosage_count)
      throw std::runtime_error("invalid variant track dimensions");
    reset();
    std::memcpy(value.genovec, v.genotypes, genowords * sizeof(uintptr_t));
    auto mask = [&](uintptr_t *dest, const uint64_t *source) { std::memcpy(dest, source, words * sizeof(uintptr_t)); };
    mask(value.patch_01_set, v.patch01); mask(value.patch_10_set, v.patch10);
    mask(value.phasepresent, v.phase_present); mask(value.phaseinfo, v.phase_info);
    mask(value.dosage_present, v.dosage_present); mask(value.dphase_present, v.dphase_present);
    if (v.patch01_count) std::memcpy(value.patch_01_vals, v.patch01_values, v.patch01_count);
    if (v.patch10_count) std::memcpy(value.patch_10_vals, v.patch10_values, v.patch10_count * 2);
    if (v.dosage_count) std::memcpy(value.dosage_main, v.dosages, v.dosage_count * sizeof(uint16_t));
    if (v.dphase_count) std::memcpy(value.dphase_delta, v.dphase, v.dphase_count * sizeof(int16_t));
    value.patch_01_ct = v.patch01_count; value.patch_10_ct = v.patch10_count;
    value.phasepresent_ct = v.phase_count; value.dosage_ct = v.dosage_count; value.dphase_ct = v.dphase_count;
  }
};
}

struct RsPgReader : Tracks {
  PgenFileInfo info;
  PgenReader reader;
  uint32_t variants, reference_mode = 0;
  RsPgReader(uint32_t ns, uint32_t nv) : Tracks(ns), variants(nv) { PreinitPgfi(&info); PreinitPgr(&reader); }
  PglErr close() {
    PglErr e = kPglRetSuccess;
    CleanupPgr(&reader, &e); CleanupPgfi(&info, &e); return e;
  }
  ~RsPgReader() { close(); }
};
struct RsPgWriter : Tracks {
  STPgenWriter writer;
  std::vector<uintptr_t> offsets;
  RsPgWriter(uint32_t ns) : Tracks(ns) { PreinitSpgw(&writer); }
  ~RsPgWriter() { PglErr e = kPglRetSuccess; CleanupSpgw(&writer, &e); }
};

extern "C" uint32_t rs_pg_abi_version() { return 3; }
extern "C" int rs_pg_reader_open(const char *path, const char *pgi, uint32_t ns, uint32_t nv,
 const uint64_t *offsets, RsPgReader **out, uint64_t *workspace, char *error, size_t cap) {
  *out = nullptr;
  return boundary(error, cap, [&] {
    auto s = std::make_unique<RsPgReader>(ns, nv);
    PgenHeaderCtrl ctrl; uintptr_t ncache = 0; char detail[kPglErrstrBufBlen] = {};
    auto e = PgfiInitPhase1(path, pgi, nv, ns, &ctrl, &s->info, &ncache, detail);
    if (e != kPglRetSuccess) throw std::runtime_error(detail);
    if (s->info.extensions_present) throw std::runtime_error("PGEN extension tracks are outside this profile");
    s->reference_mode = (ctrl >> 6) & 3;
    s->info.allele_idx_offsets = s->alloc<uintptr_t>(nv + 1);
    std::memcpy(s->info.allele_idx_offsets, offsets, (nv + 1) * sizeof(uint64_t));
    uint32_t max_alleles = 2;
    for (uint32_t i = 0; i < nv; ++i) max_alleles = std::max(max_alleles, static_cast<uint32_t>(offsets[i+1]-offsets[i]));
    s->info.max_allele_ct = max_alleles;
    if (s->reference_mode == 3) s->info.nonref_flags = s->alloc<uintptr_t>(BitCtToWordCt(nv));
    auto *phase1 = s->alloc<unsigned char>(ncache * kCacheline);
    uintptr_t reader_cache = 0; uint32_t max_width = 0;
    e = PgfiInitPhase2(ctrl, 1, 0, 0, 0, nv, &max_width, &s->info, phase1, &reader_cache, detail);
    if (e != kPglRetSuccess) throw std::runtime_error(detail);
    check(PgrInit(path, max_width, &s->info, &s->reader, s->alloc<unsigned char>(reader_cache*kCacheline)), "reader initialization");
    *workspace = s->allocated_bytes() + sizeof(RsPgReader); *out = s.release();
  });
}
extern "C" int rs_pg_reference_flags(RsPgReader *s, uint64_t *out, uint32_t words, uint32_t *mode, char *error, size_t cap) {
  return boundary(error, cap, [&] {
    if (words != BitCtToWordCt(s->variants)) throw std::runtime_error("reference mask dimension mismatch");
    if (s->info.nonref_flags) std::memcpy(out, s->info.nonref_flags, words * sizeof(uint64_t));
    else std::fill_n(out, words, (s->info.gflags & kfPgenGlobalAllNonref) ? UINT64_MAX : UINT64_C(0));
    if (s->variants % 64) out[words - 1] &= (UINT64_C(1) << (s->variants % 64)) - 1;
    *mode = s->reference_mode;
  });
}
extern "C" int rs_pg_track_flags(RsPgReader *s, uint32_t *out, char *error, size_t cap) {
  return boundary(error, cap, [&] {
    *out = static_cast<uint32_t>(PgrGetGflags(&s->reader) &
      (kfPgenGlobalHardcallPhasePresent | kfPgenGlobalDosagePresent | kfPgenGlobalDosagePhasePresent));
  });
}
extern "C" int rs_pg_read(RsPgReader *s, uint32_t variant, RsPgVariantView *out, char *error, size_t cap) {
  return boundary(error, cap, [&] {
    if (variant >= s->variants) throw std::runtime_error("PGEN variant index out of range");
    s->reset(); PgrSampleSubsetIndex subset; PgrClearSampleSubsetIndex(&s->reader, &subset);
    const uint32_t alleles = s->info.allele_idx_offsets[variant+1] - s->info.allele_idx_offsets[variant];
    if (alleles > 2 && (PgrGetVrtype(&s->reader, variant) & 0x60))
      throw std::runtime_error("multiallelic dosage is outside this profile");
    auto &v = s->value;
    check(alleles > 2 ? PgrGetMP(nullptr, subset, s->samples, variant, &s->reader, &v)
                     : PgrGetDp(nullptr, subset, s->samples, variant, &s->reader, &v), "variant read");
    const uint32_t provisional = s->info.nonref_flags ? IsSet(s->info.nonref_flags, variant) : ((s->info.gflags & kfPgenGlobalAllNonref) != 0);
    auto bits = [](const uintptr_t *p) { return reinterpret_cast<const uint64_t *>(p); };
    *out = RsPgVariantView{s->samples, alleles, provisional, s->reference_mode, s->genowords, s->words,
      v.patch_01_ct, v.patch_10_ct, v.phasepresent_ct, v.dosage_ct, v.dphase_ct,
      bits(v.genovec), bits(v.patch_01_set), bits(v.patch_10_set), v.patch_01_vals, v.patch_10_vals,
      bits(v.phasepresent), bits(v.phaseinfo), bits(v.dosage_present), bits(v.dphase_present), v.dosage_main, v.dphase_delta};
  });
}
extern "C" int rs_pg_reader_close(RsPgReader *s, char *error, size_t cap) {
  return boundary(error, cap, [&] { std::unique_ptr<RsPgReader> owned(s); check(s->close(), "reader close"); });
}
extern "C" int rs_pg_writer_open(const char *path, uint32_t ns, uint32_t nv, const uint64_t *offsets,
 const uint64_t *provisional, uint32_t flags, RsPgWriter **out, uint64_t *workspace, char *error, size_t cap) {
  *out = nullptr;
  return boundary(error, cap, [&] {
    auto s = std::make_unique<RsPgWriter>(ns);
    s->offsets.assign(offsets, offsets + nv + 1);
    auto *nonref = s->alloc<uintptr_t>(BitCtToWordCt(nv));
    std::memcpy(nonref, provisional, BitCtToWordCt(nv) * sizeof(uintptr_t));
    uintptr_t ncache = 0; uint32_t width = 0;
    check(SpgwInitPhase1(path, s->offsets.data(), nonref, nv, ns, 0,
      kPgenWriteBackwardSeek, static_cast<PgenGlobalFlags>(flags & 0x38), 3, &s->writer, &ncache, &width), "writer initialization");
    SpgwInitPhase2(width, &s->writer, s->alloc<unsigned char>(ncache*kCacheline));
    *workspace = s->allocated_bytes() + s->offsets.capacity() * sizeof(uintptr_t) + sizeof(RsPgWriter);
    *out = s.release();
  });
}
extern "C" int rs_pg_append(RsPgWriter *s, const RsPgVariantView *input, char *error, size_t cap) {
  return boundary(error, cap, [&] {
    const uint32_t index = SpgwGetVidx(&s->writer);
    if (index >= SpgwGetVariantCt(&s->writer) || input->alleles != s->offsets[index+1]-s->offsets[index])
      throw std::runtime_error("writer variant count/allele mismatch");
    s->copy(*input); auto &v = s->value; PglErr e;
    if (input->alleles > 2) {
      if (v.dosage_ct || v.dphase_ct) throw std::runtime_error("multiallelic dosage is outside this profile");
      e = v.phasepresent_ct ? SpgwAppendMultiallelicGenovecHphase(v.genovec,v.patch_01_set,v.patch_01_vals,v.patch_10_set,v.patch_10_vals,v.phasepresent,v.phaseinfo,input->alleles,v.patch_01_ct,v.patch_10_ct,&s->writer)
        : SpgwAppendMultiallelicSparse(v.genovec,v.patch_01_set,v.patch_01_vals,v.patch_10_set,v.patch_10_vals,input->alleles,v.patch_01_ct,v.patch_10_ct,&s->writer);
    } else if (v.dphase_ct) e=SpgwAppendBiallelicGenovecDphase16(v.genovec,v.phasepresent,v.phaseinfo,v.dosage_present,v.dphase_present,v.dosage_main,v.dphase_delta,v.dosage_ct,v.dphase_ct,&s->writer);
    else if (v.dosage_ct && v.phasepresent_ct) e=SpgwAppendBiallelicGenovecHphaseDosage16(v.genovec,v.phasepresent,v.phaseinfo,v.dosage_present,v.dosage_main,v.dosage_ct,&s->writer);
    else if (v.dosage_ct) e=SpgwAppendBiallelicGenovecDosage16(v.genovec,v.dosage_present,v.dosage_main,v.dosage_ct,&s->writer);
    else if (v.phasepresent_ct) e=SpgwAppendBiallelicGenovecHphase(v.genovec,v.phasepresent,v.phaseinfo,&s->writer);
    else e=SpgwAppendBiallelicGenovec(v.genovec,&s->writer);
    check(e, "variant append");
  });
}
extern "C" int rs_pg_writer_finish(RsPgWriter *s, char *error, size_t cap) {
  return boundary(error, cap, [&] {
    std::unique_ptr<RsPgWriter> owned(s);
    if (SpgwGetVidx(&s->writer) != SpgwGetVariantCt(&s->writer)) throw std::runtime_error("incomplete PGEN generation");
    check(SpgwFinish(&s->writer), "writer finish");
  });
}
extern "C" void rs_pg_writer_abort(RsPgWriter *s) { delete s; }
