//! Element assignment and atomic masses, matching biopython `Bio.PDB.Atom`.
//!
//! biopython keys the mass table by `element.capitalize()` (first character
//! upper, rest lower) into `Bio.Data.IUPACData.atom_weights`. The element is
//! taken from PDB columns 77-78 when present and recognised, otherwise guessed
//! from the atom name exactly as `Atom._assign_element` does.

/// Capitalise like Python `str.capitalize`: first char upper, rest lower.
fn capitalize(s: &str) -> String {
    let mut chars = s.chars();
    match chars.next() {
        None => String::new(),
        Some(first) => first.to_uppercase().collect::<String>() + &chars.as_str().to_lowercase(),
    }
}

/// Atomic weight for a capitalised element symbol, or `None` if the symbol is
/// not in biopython's `IUPACData.atom_weights`. Values are byte-for-byte the
/// f64 literals biopython stores.
pub fn atom_weight(capitalized: &str) -> Option<f64> {
    let w = match capitalized {
        "Ac" => 227.03,
        "Ag" => 107.8682,
        "Al" => 26.981538,
        "Am" => 243.06,
        "Ar" => 39.948,
        "As" => 74.9216,
        "At" => 209.99,
        "Au" => 196.96655,
        "B" => 10.811,
        "Ba" => 137.327,
        "Be" => 9.012182,
        "Bh" => 264.12,
        "Bi" => 208.98038,
        "Bk" => 247.07,
        "Br" => 79.904,
        "C" => 12.0107,
        "Ca" => 40.078,
        "Cd" => 112.411,
        "Ce" => 140.116,
        "Cf" => 251.08,
        "Cl" => 35.453,
        "Cm" => 247.07,
        "Co" => 58.9332,
        "Cr" => 51.9961,
        "Cs" => 132.90545,
        "Cu" => 63.546,
        "D" => 2.0141,
        "Db" => 262.11,
        "Dy" => 162.5,
        "Er" => 167.259,
        "Es" => 252.08,
        "Eu" => 151.964,
        "F" => 18.9984032,
        "Fe" => 55.845,
        "Fm" => 257.1,
        "Fr" => 223.02,
        "Ga" => 69.723,
        "Gd" => 157.25,
        "Ge" => 72.64,
        "H" => 1.00794,
        "He" => 4.002602,
        "Hf" => 178.49,
        "Hg" => 200.59,
        "Ho" => 164.93032,
        "Hs" => 269.13,
        "I" => 126.90447,
        "In" => 114.818,
        "Ir" => 192.217,
        "K" => 39.0983,
        "Kr" => 83.8,
        "La" => 138.9055,
        "Li" => 6.941,
        "Lr" => 262.11,
        "Lu" => 174.967,
        "Md" => 258.1,
        "Mg" => 24.305,
        "Mn" => 54.938049,
        "Mo" => 95.94,
        "Mt" => 268.14,
        "N" => 14.0067,
        "Na" => 22.98977,
        "Nb" => 92.90638,
        "Nd" => 144.24,
        "Ne" => 20.1797,
        "Ni" => 58.6934,
        "No" => 259.1,
        "Np" => 237.05,
        "O" => 15.9994,
        "Os" => 190.23,
        "P" => 30.973761,
        "Pa" => 231.03588,
        "Pb" => 207.2,
        "Pd" => 106.42,
        "Pm" => 145.0,
        "Po" => 208.98,
        "Pr" => 140.90765,
        "Pt" => 195.078,
        "Pu" => 244.06,
        "Ra" => 226.03,
        "Rb" => 85.4678,
        "Re" => 186.207,
        "Rf" => 261.11,
        "Rh" => 102.9055,
        "Rn" => 222.02,
        "Ru" => 101.07,
        "S" => 32.065,
        "Sb" => 121.76,
        "Sc" => 44.95591,
        "Se" => 78.96,
        "Sg" => 266.12,
        "Si" => 28.0855,
        "Sm" => 150.36,
        "Sn" => 118.71,
        "Sr" => 87.62,
        "Ta" => 180.9479,
        "Tb" => 158.92534,
        "Tc" => 98.0,
        "Te" => 127.6,
        "Th" => 232.0381,
        "Ti" => 47.867,
        "Tl" => 204.3833,
        "Tm" => 168.93421,
        "U" => 238.02891,
        "V" => 50.9415,
        "W" => 183.84,
        "Xe" => 131.293,
        "Y" => 88.90585,
        "Yb" => 173.04,
        "Zn" => 65.39,
        "Zr" => 91.224,
        _ => return None,
    };
    Some(w)
}

/// Resolve the element symbol for an atom the way biopython does.
///
/// `name` is the whitespace-stripped atom name (e.g. `"CA"`, `"HE21"`).
/// `fullname` is the raw 4-column atom field (e.g. `" CA "`, `"HE21"`).
/// `col_element` is the stripped, upper-cased PDB element column (77-78).
///
/// Returns the *capitalised* element symbol to key the mass table with. When
/// the element cannot be resolved, returns `"X"` (biopython's unknown marker),
/// which has no mass — the atom then contributes NaN to biopython and is
/// rejected here.
pub fn assign_element(name: &str, fullname: &str, col_element: &str) -> String {
    // Honour the explicit element column when it names a known element.
    if !col_element.is_empty() {
        let cap = capitalize(col_element);
        if atom_weight(&cap).is_some() {
            return cap;
        }
    }

    // Name-guessing, mirroring Atom._assign_element.
    let fb = fullname.as_bytes();
    let first_alpha = fb.first().is_some_and(|b| b.is_ascii_alphabetic());
    let tail_all_digits = fullname.len() > 2 && fullname[2..].bytes().all(|b| b.is_ascii_digit());

    let putative: String = if first_alpha && !tail_all_digits {
        name.trim().to_string()
    } else if name.as_bytes().first().is_some_and(|b| b.is_ascii_digit()) {
        name.chars().nth(1).map(String::from).unwrap_or_default()
    } else {
        name.chars().next().map(String::from).unwrap_or_default()
    };

    let cap = capitalize(&putative);
    if atom_weight(&cap).is_some() {
        cap
    } else {
        "X".to_string()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn capitalize_matches_python() {
        assert_eq!(capitalize("CA"), "Ca");
        assert_eq!(capitalize("c"), "C");
        assert_eq!(capitalize("HG"), "Hg");
        assert_eq!(capitalize(""), "");
    }

    #[test]
    fn explicit_column_element_wins() {
        // " CA " carbon-alpha with explicit element column "C".
        assert_eq!(assign_element("CA", " CA ", "C"), "C");
    }

    #[test]
    fn guess_carbon_from_short_name() {
        // No element column; fullname " CA " starts with a space, so the
        // first-character branch fires and the element is the name's first
        // character "C" — biopython returns carbon here, not calcium.
        assert_eq!(assign_element("CA", " CA ", ""), "C");
    }

    #[test]
    fn guess_hydrogen_with_trailing_digits() {
        // "HE21" fullname has no leading space and tail "21" is all digits,
        // so the name does not strip to an element; first char is alpha (H),
        // not a digit, so element is the first character.
        assert_eq!(assign_element("HE21", "HE21", ""), "H");
    }

    #[test]
    fn masses_are_exact() {
        assert_eq!(atom_weight("C"), Some(12.0107));
        assert_eq!(atom_weight("N"), Some(14.0067));
        assert_eq!(atom_weight("O"), Some(15.9994));
        assert_eq!(atom_weight("S"), Some(32.065));
        assert_eq!(atom_weight("H"), Some(1.00794));
        assert_eq!(atom_weight("X"), None);
    }
}
