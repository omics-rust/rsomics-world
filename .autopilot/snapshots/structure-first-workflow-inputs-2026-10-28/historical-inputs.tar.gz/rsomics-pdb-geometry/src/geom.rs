//! Global geometric descriptors over an atom set.
//!
//! COM, centroid and radius of gyration reproduce biopython's
//! `Entity.center_of_mass`, which casts coordinates and masses to float32
//! before `np.average`. We therefore round each coordinate and mass to f32
//! before accumulating (in f64) so the result tracks biopython to the float32
//! noise floor; numpy's strided axis-0 reduction order is the only remaining
//! difference (relative residual ~1e-6).
//!
//! Total mass uses the unrounded f64 masses — biopython's `atom.mass` is an
//! f64 table value. The bounding box is over the f32-rounded coordinates,
//! because biopython stores every `atom.coord` as float32; min/max is
//! order-independent so only the f32 rounding matters there.

use serde::Serialize;

use crate::pdb::{RawAtom, Vec3};

/// Which atoms enter the geometry. The default (`All`) matches biopython's
/// `Structure[0].center_of_mass`: every ATOM and HETATM, hydrogens included.
#[derive(Clone, Copy, PartialEq, Eq)]
pub struct Selection {
    pub ca_only: bool,
    pub include_hetatm: bool,
    pub include_hydrogens: bool,
}

impl Default for Selection {
    fn default() -> Self {
        Self {
            ca_only: false,
            include_hetatm: true,
            include_hydrogens: true,
        }
    }
}

impl Selection {
    fn keeps(&self, a: &RawAtom) -> bool {
        if self.ca_only {
            return a.is_ca;
        }
        if !self.include_hetatm && a.is_hetatm {
            return false;
        }
        if !self.include_hydrogens && a.is_hydrogen {
            return false;
        }
        true
    }
}

#[derive(Serialize)]
pub struct Geometry {
    pub atom_count: usize,
    pub residue_count: usize,
    pub total_mass: f64,
    pub center_of_mass: [f64; 3],
    pub centroid: [f64; 3],
    pub radius_of_gyration: f64,
    pub radius_of_gyration_geometric: f64,
    pub bbox_min: [f64; 3],
    pub bbox_max: [f64; 3],
    pub bbox_dim: [f64; 3],
}

#[inline]
fn f32round(x: f64) -> f64 {
    f64::from(x as f32)
}

#[inline]
fn sq_dist(a: &Vec3, b: &[f64; 3]) -> f64 {
    let dx = a[0] - b[0];
    let dy = a[1] - b[1];
    let dz = a[2] - b[2];
    dx * dx + dy * dy + dz * dz
}

/// Compute every descriptor over the atoms the selection keeps.
///
/// Returns `None` when the selection retains no atoms (e.g. `--ca-only` on a
/// ligand-only file) — the caller turns that into a loud error.
pub fn compute(atoms: &[RawAtom], sel: Selection) -> Option<Geometry> {
    let kept: Vec<&RawAtom> = atoms.iter().filter(|a| sel.keeps(a)).collect();
    if kept.is_empty() {
        return None;
    }
    let n = kept.len();

    let mut residue_count = 0usize;
    let mut cur: Option<&(char, String, i32, char)> = None;
    for a in &kept {
        if cur != Some(&a.res_key) {
            residue_count += 1;
            cur = Some(&a.res_key);
        }
    }

    // f32-rounded views, matching biopython's np.float32 cast.
    let coord32: Vec<Vec3> = kept
        .iter()
        .map(|a| {
            [
                f32round(a.coord[0]),
                f32round(a.coord[1]),
                f32round(a.coord[2]),
            ]
        })
        .collect();
    let mass32: Vec<f64> = kept.iter().map(|a| f32round(a.mass)).collect();

    let mass32_sum: f64 = mass32.iter().sum();
    let mut com_num = [0.0_f64; 3];
    let mut cen_num = [0.0_f64; 3];
    for (c, &m) in coord32.iter().zip(&mass32) {
        for k in 0..3 {
            com_num[k] += c[k] * m;
            cen_num[k] += c[k];
        }
    }
    let center_of_mass = [
        com_num[0] / mass32_sum,
        com_num[1] / mass32_sum,
        com_num[2] / mass32_sum,
    ];
    #[allow(clippy::cast_precision_loss)]
    let centroid = [
        cen_num[0] / n as f64,
        cen_num[1] / n as f64,
        cen_num[2] / n as f64,
    ];

    let mut rg_num = 0.0_f64;
    let mut rgg_num = 0.0_f64;
    for (c, &m) in coord32.iter().zip(&mass32) {
        rg_num += m * sq_dist(c, &center_of_mass);
        rgg_num += sq_dist(c, &centroid);
    }
    let radius_of_gyration = (rg_num / mass32_sum).sqrt();
    #[allow(clippy::cast_precision_loss)]
    let radius_of_gyration_geometric = (rgg_num / n as f64).sqrt();

    let total_mass: f64 = kept.iter().map(|a| a.mass).sum();
    let mut bbox_min = [f64::INFINITY; 3];
    let mut bbox_max = [f64::NEG_INFINITY; 3];
    for c in &coord32 {
        for k in 0..3 {
            bbox_min[k] = bbox_min[k].min(c[k]);
            bbox_max[k] = bbox_max[k].max(c[k]);
        }
    }
    let bbox_dim = [
        bbox_max[0] - bbox_min[0],
        bbox_max[1] - bbox_min[1],
        bbox_max[2] - bbox_min[2],
    ];

    Some(Geometry {
        atom_count: n,
        residue_count,
        total_mass,
        center_of_mass,
        centroid,
        radius_of_gyration,
        radius_of_gyration_geometric,
        bbox_min,
        bbox_max,
        bbox_dim,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn raw(x: f64, y: f64, z: f64, mass: f64, ca: bool, het: bool, h: bool) -> RawAtom {
        RawAtom {
            coord: [x, y, z],
            mass,
            is_hetatm: het,
            is_hydrogen: h,
            is_ca: ca,
            res_key: ('A', if het { "H_LIG".into() } else { " ".into() }, 1, ' '),
        }
    }

    #[test]
    fn two_equal_masses_com_is_midpoint() {
        let atoms = vec![
            raw(0.0, 0.0, 0.0, 12.0107, false, false, false),
            raw(2.0, 0.0, 0.0, 12.0107, false, false, false),
        ];
        let g = compute(&atoms, Selection::default()).unwrap();
        assert!((g.center_of_mass[0] - 1.0).abs() < 1e-6);
        assert!((g.centroid[0] - 1.0).abs() < 1e-6);
        assert!((g.total_mass - 24.0214).abs() < 1e-9);
    }

    #[test]
    fn bounding_box_spans_extremes() {
        let atoms = vec![
            raw(-1.0, 2.0, 0.0, 1.0, false, false, false),
            raw(3.0, -4.0, 5.0, 1.0, false, false, false),
        ];
        let g = compute(&atoms, Selection::default()).unwrap();
        assert_eq!(g.bbox_min, [-1.0, -4.0, 0.0]);
        assert_eq!(g.bbox_max, [3.0, 2.0, 5.0]);
        assert_eq!(g.bbox_dim, [4.0, 6.0, 5.0]);
    }

    #[test]
    fn rg_of_two_unit_masses_about_center() {
        let d = 3.0;
        let atoms = vec![
            raw(-d, 0.0, 0.0, 1.0, false, false, false),
            raw(d, 0.0, 0.0, 1.0, false, false, false),
        ];
        let g = compute(&atoms, Selection::default()).unwrap();
        assert!((g.radius_of_gyration - d).abs() < 1e-6);
        assert!((g.radius_of_gyration_geometric - d).abs() < 1e-6);
    }

    #[test]
    fn ca_only_keeps_only_calpha() {
        let atoms = vec![
            raw(0.0, 0.0, 0.0, 14.0067, false, false, false), // N
            raw(1.0, 0.0, 0.0, 12.0107, true, false, false),  // CA
        ];
        let g = compute(
            &atoms,
            Selection {
                ca_only: true,
                ..Selection::default()
            },
        )
        .unwrap();
        assert_eq!(g.atom_count, 1);
        assert!((g.center_of_mass[0] - 1.0).abs() < 1e-9);
    }

    #[test]
    fn exclude_hetatm_and_hydrogens() {
        let atoms = vec![
            raw(0.0, 0.0, 0.0, 12.0107, false, false, false),
            raw(5.0, 0.0, 0.0, 15.9994, false, true, false), // HETATM
            raw(9.0, 0.0, 0.0, 1.00794, false, false, true), // hydrogen
        ];
        let g = compute(
            &atoms,
            Selection {
                ca_only: false,
                include_hetatm: false,
                include_hydrogens: false,
            },
        )
        .unwrap();
        assert_eq!(g.atom_count, 1);
    }

    #[test]
    fn empty_selection_is_none() {
        let atoms = vec![raw(0.0, 0.0, 0.0, 12.0107, false, false, false)];
        assert!(
            compute(
                &atoms,
                Selection {
                    ca_only: true,
                    ..Selection::default()
                }
            )
            .is_none()
        );
    }
}
