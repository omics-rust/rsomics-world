use std::process::ExitCode;

use clap::Parser;
use rsomics_common::run;
use rsomics_help::{Example, FlagSpec, HelpSpec, Origin, Section};

use rsomics_pdb_geometry::cli::{Cli, META};

const HELP: HelpSpec = HelpSpec {
    name: env!("CARGO_PKG_NAME"),
    version: env!("CARGO_PKG_VERSION"),
    tagline: "Global geometric descriptors of a protein structure from a PDB",
    origin: Some(Origin {
        upstream: "Bio.PDB.Entity.center_of_mass (biopython)",
        upstream_license: "BSD-3-Clause",
        our_license: "MIT OR Apache-2.0",
        paper_doi: Some("10.1093/bioinformatics/btp163"),
    }),
    usage_lines: &["<PDB> [--ca-only] [--no-hetatm] [--no-hydrogens] [--json]"],
    sections: &[Section {
        title: "OPTIONS",
        flags: &[
            FlagSpec {
                short: None,
                long: "ca-only",
                aliases: &[],
                value: None,
                type_hint: None,
                required: false,
                default: None,
                description: "Use only Ca atoms",
                why_default: None,
            },
            FlagSpec {
                short: None,
                long: "no-hetatm",
                aliases: &[],
                value: None,
                type_hint: None,
                required: false,
                default: None,
                description: "Drop HETATM records (ligands, ions, water)",
                why_default: None,
            },
            FlagSpec {
                short: None,
                long: "no-hydrogens",
                aliases: &[],
                value: None,
                type_hint: None,
                required: false,
                default: None,
                description: "Drop hydrogen and deuterium atoms",
                why_default: None,
            },
        ],
    }],
    examples: &[
        Example {
            description: "All atoms (matches biopython center_of_mass)",
            command: "rsomics-pdb-geometry 1ubq.pdb",
        },
        Example {
            description: "Backbone Ca trace only, machine-readable",
            command: "rsomics-pdb-geometry 1ubq.pdb --ca-only --json",
        },
    ],
    json_result_schema_doc: None,
};

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().collect();
    if let Some(mode) = rsomics_help::intercept_help(&args) {
        rsomics_help::render(&HELP, mode);
        return ExitCode::SUCCESS;
    }
    let cli = Cli::parse();
    let common = cli.common.clone();
    run(&common, META, move || cli.run_to_result())
}
