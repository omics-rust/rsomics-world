use std::fs;
use std::io::{self, BufWriter, Read};
use std::path::PathBuf;

use clap::Parser;
use rsomics_common::{CommonFlags, Result, RsomicsError, ToolMeta};

use crate::geom::{Geometry, Selection};
use crate::{compute, parse, write_text};

pub const META: ToolMeta = ToolMeta {
    name: env!("CARGO_PKG_NAME"),
    version: env!("CARGO_PKG_VERSION"),
};

#[derive(Parser)]
#[command(name = "rsomics-pdb-geometry", disable_help_flag = true)]
pub struct Cli {
    /// Input PDB file, or - for stdin.
    pub pdb: PathBuf,

    /// Use only Cα atoms (excludes everything else, including HETATM).
    #[arg(long)]
    pub ca_only: bool,

    /// Drop HETATM records (ligands, ions, water) from the geometry.
    #[arg(long)]
    pub no_hetatm: bool,

    /// Drop hydrogen (and deuterium) atoms from the geometry.
    #[arg(long)]
    pub no_hydrogens: bool,

    #[command(flatten)]
    pub common: CommonFlags,
}

impl Cli {
    fn selection(&self) -> Selection {
        Selection {
            ca_only: self.ca_only,
            include_hetatm: !self.no_hetatm,
            include_hydrogens: !self.no_hydrogens,
        }
    }

    /// Run the computation and, unless `--json`, print the human-readable
    /// report. The returned `Geometry` is what the JSON envelope wraps.
    #[allow(clippy::missing_errors_doc)]
    pub fn run_to_result(&self) -> Result<Geometry> {
        let text = if self.pdb.as_os_str() == "-" {
            let mut s = String::new();
            io::stdin().read_to_string(&mut s)?;
            s
        } else {
            fs::read_to_string(&self.pdb)?
        };
        let atoms = parse(&text)?;
        let g = compute(&atoms, self.selection()).ok_or_else(|| {
            RsomicsError::InvalidInput("the atom selection retained no atoms".to_string())
        })?;
        if !self.common.json {
            let stdout = io::stdout();
            let mut w = BufWriter::new(stdout.lock());
            write_text(&mut w, &g)?;
        }
        Ok(g)
    }
}

#[cfg(test)]
mod tests {
    use clap::CommandFactory;

    #[test]
    fn cli_definition_is_valid() {
        super::Cli::command().debug_assert();
    }
}
