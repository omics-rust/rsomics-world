//! Atom set for global geometry, sourced from the shared `rsomics-pdb-core`
//! parser.
//!
//! Matches biopython's `PDBParser` + `Entity.center_of_mass` atom set: the
//! first model only, every ATOM and HETATM record (hydrogens and heteroatoms
//! included), and *every* altloc of a disordered atom counted separately —
//! `center_of_mass` walks `get_unpacked_list`, which expands a DisorderedAtom
//! into all of its alternate positions ([`AltLocPolicy::KeepAll`]).

use rsomics_common::Result;
use rsomics_common::error::RsomicsError;
use rsomics_pdb_core::{AltLocPolicy, ParseOptions, ResidueFilter, select_altloc};

use crate::mass::{assign_element, atom_weight};

pub type Vec3 = [f64; 3];

/// One parsed atom with the metadata atom-selection filters need.
pub struct RawAtom {
    pub coord: Vec3,
    pub mass: f64,
    pub is_hetatm: bool,
    pub is_hydrogen: bool,
    pub is_ca: bool,
    /// biopython's residue identity: (chain, field, resseq, icode), where
    /// `field` is `" "` for ATOM, `"W"` for water, and `"H_<resname>"` for
    /// other HETATM. Resname is part of identity only for hetero residues, so
    /// a point-mutation site (e.g. PRO/SER altlocs) counts as one residue.
    pub res_key: (char, String, i32, char),
}

/// Parse the first model's ATOM/HETATM records, keeping every altloc.
///
/// Atoms whose element resolves to `"X"` (unknown — biopython mass NaN) are
/// rejected loudly: a NaN mass would silently poison every aggregate.
pub fn parse(text: &str) -> Result<Vec<RawAtom>> {
    let opts = ParseOptions {
        include_hetatm: true,
        include_hydrogen: true,
        residue_filter: ResidueFilter::All,
    };
    let atoms = select_altloc(rsomics_pdb_core::parse(text, &opts)?, AltLocPolicy::KeepAll);

    atoms
        .into_iter()
        .map(|a| {
            let element = assign_element(&a.name, &a.fullname, &a.element);
            let mass = atom_weight(&element).ok_or_else(|| {
                RsomicsError::InvalidInput(format!(
                    "atom {:?} resolved to unknown element {element:?} (no mass)",
                    a.name
                ))
            })?;
            let field = if a.is_hetatm {
                if a.resname == "HOH" || a.resname == "WAT" {
                    "W".to_string()
                } else {
                    format!("H_{}", a.resname)
                }
            } else {
                " ".to_string()
            };
            Ok(RawAtom {
                coord: a.coord,
                mass,
                is_hetatm: a.is_hetatm,
                is_hydrogen: element == "H" || element == "D",
                is_ca: a.name == "CA" && !a.is_hetatm,
                res_key: (a.chain, field, a.resseq, a.icode),
            })
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    const MINI: &str = "\
ATOM      1  N   ALA A   1       0.000   0.000   0.000  1.00  0.00           N
ATOM      2  CA AALA A   1       1.000   0.000   0.000  0.50  0.00           C
ATOM      3  CA BALA A   1       2.000   0.000   0.000  0.50  0.00           C
ATOM      4  C   ALA A   1       3.000   0.000   0.000  1.00  0.00           C
HETATM    5  O   HOH B   2      10.000   0.000   0.000  1.00  0.00           O
";

    #[test]
    fn counts_all_altlocs() {
        let a = parse(MINI).unwrap();
        // Both CA altlocs are distinct atoms in center_of_mass.
        assert_eq!(a.len(), 5);
    }

    #[test]
    fn flags_classify_records() {
        let a = parse(MINI).unwrap();
        assert!(a[4].is_hetatm);
        assert!(!a[0].is_hetatm);
        assert!(a[1].is_ca && a[2].is_ca);
        assert!(!a[0].is_ca);
    }

    #[test]
    fn second_model_is_ignored() {
        let two = format!("MODEL        1\n{MINI}ENDMDL\nMODEL        2\n{MINI}ENDMDL\n");
        let a = parse(&two).unwrap();
        assert_eq!(a.len(), 5);
    }
}
