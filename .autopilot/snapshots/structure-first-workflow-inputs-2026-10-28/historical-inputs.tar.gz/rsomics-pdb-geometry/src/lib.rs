pub mod cli;
pub mod geom;
pub mod mass;
pub mod pdb;

pub use geom::{Geometry, Selection, compute};
pub use pdb::{RawAtom, parse};

use std::io::Write;

use rsomics_common::Result;

/// Human-readable report: one labelled value per line, x/y/z triples spaced.
pub fn write_text<W: Write>(w: &mut W, g: &Geometry) -> Result<()> {
    writeln!(w, "atoms\t{}", g.atom_count)?;
    writeln!(w, "residues\t{}", g.residue_count)?;
    writeln!(w, "total_mass\t{:.4}", g.total_mass)?;
    writeln!(
        w,
        "center_of_mass\t{:.4}\t{:.4}\t{:.4}",
        g.center_of_mass[0], g.center_of_mass[1], g.center_of_mass[2]
    )?;
    writeln!(
        w,
        "centroid\t{:.4}\t{:.4}\t{:.4}",
        g.centroid[0], g.centroid[1], g.centroid[2]
    )?;
    writeln!(w, "radius_of_gyration\t{:.4}", g.radius_of_gyration)?;
    writeln!(
        w,
        "radius_of_gyration_geometric\t{:.4}",
        g.radius_of_gyration_geometric
    )?;
    writeln!(
        w,
        "bbox_min\t{:.4}\t{:.4}\t{:.4}",
        g.bbox_min[0], g.bbox_min[1], g.bbox_min[2]
    )?;
    writeln!(
        w,
        "bbox_max\t{:.4}\t{:.4}\t{:.4}",
        g.bbox_max[0], g.bbox_max[1], g.bbox_max[2]
    )?;
    writeln!(
        w,
        "bbox_dim\t{:.4}\t{:.4}\t{:.4}",
        g.bbox_dim[0], g.bbox_dim[1], g.bbox_dim[2]
    )?;
    Ok(())
}
