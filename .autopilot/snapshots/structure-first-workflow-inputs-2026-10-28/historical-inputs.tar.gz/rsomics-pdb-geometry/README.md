# rsomics-pdb-geometry

Global geometric descriptors of a protein structure from a PDB: center of mass
(mass-weighted), geometric centroid, radius of gyration (mass-weighted and
geometric), axis-aligned bounding box, total mass, and atom/residue counts —
value-exact against biopython `Bio.PDB`.

```
rsomics-pdb-geometry prot.pdb                       # all atoms (biopython default)
rsomics-pdb-geometry prot.pdb --ca-only             # Ca trace only
rsomics-pdb-geometry prot.pdb --no-hetatm           # drop ligands/ions/water
rsomics-pdb-geometry prot.pdb --no-hydrogens        # drop H/D
rsomics-pdb-geometry prot.pdb --json                # machine-readable envelope
rsomics-pdb-geometry - < prot.pdb                   # stdin
```

Default output is a `key<TAB>value[...]` table:

```
atoms	58870
residues	8029
total_mass	780720.4456
center_of_mass	79.1763	-51.6149	-5.8642
centroid	79.1840	-51.6128	-5.8763
radius_of_gyration	68.4103
radius_of_gyration_geometric	68.4500
bbox_min	8.0480	-123.4790	-105.1380
bbox_max	150.3040	20.2520	93.2810
bbox_dim	142.2560	143.7310	198.4190
```

`--json` wraps the same fields in the rsomics result envelope.

## Atom selection

The default matches biopython's `Structure[0].center_of_mass`: the first model,
every `ATOM` and `HETATM` record, hydrogens included, and **every altloc** of a
disordered atom counted separately (biopython's `center_of_mass` walks
`get_unpacked_list`, which expands a disordered atom into all of its alternate
positions). A point-mutation site (e.g. PRO/SER altlocs at one residue id)
counts as a single residue, because biopython's residue identity is
`(hetero-flag, resseq, icode)` and excludes the residue name for standard
residues.

`--ca-only`, `--no-hetatm`, `--no-hydrogens` narrow the set; counts and every
descriptor are recomputed over exactly the retained atoms.

## Quantities

- **center of mass** `Σ mᵢ·rᵢ / Σ mᵢ` (mass-weighted).
- **centroid** `Σ rᵢ / N` (unweighted center of geometry).
- **radius of gyration** `Rg = sqrt( Σ mᵢ·‖rᵢ − COM‖² / Σ mᵢ )`, and the
  geometric variant about the centroid with unit weights.
- **bounding box** per-axis min/max and the dimensions `max − min`.
- **total mass** the f64 sum of per-atom masses.

Masses are biopython's `Bio.Data.IUPACData.atom_weights`, keyed by
`element.capitalize()`. The element is taken from PDB columns 77–78 when it
names a known element, otherwise guessed from the atom name exactly as
`Bio.PDB.Atom._assign_element` does. An atom whose element cannot be resolved
(biopython mass `NaN`) is rejected loudly rather than silently poisoning the
aggregates.

## Origin

This crate is an independent Rust reimplementation of the global geometry that
biopython's `Bio.PDB` computes, based on:

- biopython `Bio.PDB.Entity.center_of_mass`, `Bio.PDB.Atom` (element/mass
  assignment), `Bio.PDB.PDBParser`, and `Bio.Data.IUPACData.atom_weights`
  (BSD-3-Clause — read and cited for the exact atom-inclusion rule, the
  element-guessing logic, and the mass table).
- Cock et al., "Biopython: freely available Python tools for computational
  molecular biology and bioinformatics", Bioinformatics 25(11):1422–1423, 2009.
  doi:10.1093/bioinformatics/btp163

biopython stores every atom coordinate as `float32` and casts masses to
`float32` inside `center_of_mass`'s `np.average`. This crate rounds coordinates
and masses to f32 before accumulating (in f64) so COM, centroid, radius of
gyration and the bounding box track biopython at the float32 noise floor; total
mass, atom and residue counts are f64-exact. The only residual is numpy's
strided axis-0 float32 reduction order, which is not reproducible bit-for-bit —
the relative residual on COM/centroid/Rg is ≤ ~1e-5 (≤ ~1e-6 on the committed
fixtures). Validated against biopython 1.87 on 1UBQ, 1A2P (zinc + altlocs),
3NIR (hydrogens + PRO/SER and LEU/ILE microheterogeneity) and 1AON.

License: MIT OR Apache-2.0.
Upstream credit: biopython https://biopython.org (BSD-3-Clause).
