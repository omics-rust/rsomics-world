//! Differential compat against biopython `Bio.PDB`.
//!
//! The committed goldens (`tests/golden/*.geom.tsv`) were captured from
//! biopython 1.87: `center_of_mass(geometric=False/True)`, radius of gyration,
//! bounding box, total mass, and atom/residue counts over the float32 atom set
//! biopython's `center_of_mass` walks (every ATOM+HETATM, every altloc).
//!
//! The always-run tests reproduce those goldens from the binary's `--json`
//! output. COM/centroid/Rg carry numpy's strided-f32 reduction-order roundoff;
//! the residual is bounded by `REL_TOL` (relative) at the float32 noise floor.
//! Counts and total mass match to f64. A live-oracle test re-derives the
//! goldens when biopython is on PATH (loud-skip otherwise).

use std::collections::HashMap;
use std::env;
use std::path::{Path, PathBuf};
use std::process::Command;

/// Relative tolerance for COM/centroid/Rg. The only residual vs biopython is
/// numpy's strided axis-0 float32 reduction order, which we cannot reproduce
/// bit-for-bit; it grows with atom count (~1e-6 on the committed fixtures,
/// ~1e-5 on a 60k-atom structure). `2e-5` brackets it with headroom.
const REL_TOL: f64 = 2e-5;

fn bin() -> PathBuf {
    PathBuf::from(env!("CARGO_BIN_EXE_rsomics-pdb-geometry"))
}

fn manifest(rel: &str) -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR")).join(rel)
}

/// Parse a golden TSV (`key<TAB>v0[<TAB>v1<TAB>v2]`) into a name->values map.
fn parse_golden(text: &str) -> HashMap<String, Vec<f64>> {
    let mut m = HashMap::new();
    for line in text.lines() {
        let mut it = line.split('\t');
        let key = it.next().unwrap().to_string();
        let vals: Vec<f64> = it.map(|c| c.parse().unwrap()).collect();
        m.insert(key, vals);
    }
    m
}

/// Pull the same quantities out of the binary's `--json` envelope.
fn run_json(pdb: &Path, flags: &[&str]) -> HashMap<String, Vec<f64>> {
    let out = Command::new(bin())
        .arg(pdb)
        .args(flags)
        .arg("--json")
        .output()
        .unwrap();
    assert!(
        out.status.success(),
        "binary failed on {pdb:?}: {:?}",
        out.status
    );
    let text = String::from_utf8(out.stdout).unwrap();
    parse_envelope(&text)
}

/// Minimal extractor for the flat numeric fields of the result envelope —
/// avoids a serde_json dependency. Each field is `"name":value` or
/// `"name":[a,b,c]`.
fn parse_envelope(json: &str) -> HashMap<String, Vec<f64>> {
    let mut m = HashMap::new();
    let mut grab = |key: &str, name: &str| {
        let needle = format!("\"{key}\":");
        if let Some(p) = json.find(&needle) {
            let rest = &json[p + needle.len()..];
            let (slice, _) = if rest.starts_with('[') {
                let end = rest.find(']').unwrap();
                (&rest[1..end], end)
            } else {
                let end = rest.find([',', '}']).unwrap();
                (&rest[..end], end)
            };
            let vals: Vec<f64> = slice
                .split(',')
                .map(|s| s.trim().parse().unwrap())
                .collect();
            m.insert(name.to_string(), vals);
        }
    };
    grab("atom_count", "atoms");
    grab("residue_count", "residues");
    grab("total_mass", "total_mass");
    grab("center_of_mass", "center_of_mass");
    grab("centroid", "centroid");
    grab("radius_of_gyration", "radius_of_gyration");
    grab(
        "radius_of_gyration_geometric",
        "radius_of_gyration_geometric",
    );
    grab("bbox_min", "bbox_min");
    grab("bbox_max", "bbox_max");
    grab("bbox_dim", "bbox_dim");
    m
}

/// Assert ours matches the reference within tolerance. Counts and total mass
/// are checked tightly; geometry uses the relative tolerance.
fn compare(ours: &HashMap<String, Vec<f64>>, refr: &HashMap<String, Vec<f64>>) {
    for key in ["atoms", "residues"] {
        assert_eq!(ours[key], refr[key], "{key} mismatch");
    }
    // total mass: f64 sum, must match to ~1e-6 absolute.
    let dm = (ours["total_mass"][0] - refr["total_mass"][0]).abs();
    assert!(dm < 1e-6, "total_mass abs diff {dm} too large");

    for key in [
        "center_of_mass",
        "centroid",
        "radius_of_gyration",
        "radius_of_gyration_geometric",
        "bbox_min",
        "bbox_max",
        "bbox_dim",
    ] {
        let o = &ours[key];
        let r = &refr[key];
        assert_eq!(o.len(), r.len(), "{key} arity mismatch");
        for (a, b) in o.iter().zip(r) {
            let rel = (a - b).abs() / (b.abs() + 1e-30);
            assert!(
                rel < REL_TOL,
                "{key}: ours={a} ref={b} rel={rel} exceeds {REL_TOL}"
            );
        }
    }
}

struct Case {
    pdb: &'static str,
    golden: &'static str,
    flags: &'static [&'static str],
}

const CASES: &[Case] = &[
    Case {
        pdb: "1ubq.pdb",
        golden: "1ubq.geom.tsv",
        flags: &[],
    },
    Case {
        pdb: "1a2p.pdb",
        golden: "1a2p.geom.tsv",
        flags: &[],
    },
    Case {
        pdb: "3nir.pdb",
        golden: "3nir.geom.tsv",
        flags: &[],
    },
    Case {
        pdb: "3nir.pdb",
        golden: "3nir.ca.geom.tsv",
        flags: &["--ca-only"],
    },
    Case {
        pdb: "3nir.pdb",
        golden: "3nir.heavy.geom.tsv",
        flags: &["--no-hetatm", "--no-hydrogens"],
    },
];

#[test]
fn golden_matches() {
    for c in CASES {
        let pdb = manifest(&format!("tests/golden/{}", c.pdb));
        let golden = parse_golden(
            &std::fs::read_to_string(manifest(&format!("tests/golden/{}", c.golden))).unwrap(),
        );
        let ours = run_json(&pdb, c.flags);
        compare(&ours, &golden);
    }
}

#[test]
fn live_oracle_biopython() {
    let Some(py) = which_biopython() else {
        eprintln!("SKIP live_oracle_biopython: no biopython on PATH");
        return;
    };
    let scratch = env::temp_dir().join("rsomics-pdb-geometry-compat");
    std::fs::create_dir_all(&scratch).unwrap();
    let script = scratch.join("oracle.py");
    std::fs::write(&script, ORACLE_PY).unwrap();

    for c in CASES {
        let pdb = manifest(&format!("tests/golden/{}", c.pdb));
        let out = Command::new(&py)
            .arg(&script)
            .arg(&pdb)
            .args(c.flags)
            .output()
            .unwrap();
        assert!(
            out.status.success(),
            "oracle failed: {}",
            String::from_utf8_lossy(&out.stderr)
        );
        let refr = parse_golden(&String::from_utf8(out.stdout).unwrap());
        let ours = run_json(&pdb, c.flags);
        compare(&ours, &refr);
    }
}

fn which_biopython() -> Option<String> {
    for py in [
        "/opt/homebrew/Caskroom/miniforge/base/envs/rs-up/bin/python",
        "python3",
        "python",
    ] {
        let ok = Command::new(py)
            .args(["-c", "import Bio.PDB"])
            .output()
            .map(|o| o.status.success())
            .unwrap_or(false);
        if ok {
            return Some(py.to_string());
        }
    }
    None
}

const ORACLE_PY: &str = r#"
import sys, warnings
from collections import deque
import numpy as np
warnings.simplefilter("ignore")
from Bio.PDB import PDBParser

path = sys.argv[1]
flags = set(sys.argv[2:])
model = PDBParser(QUIET=True).get_structure("x", path)[0]

def walk(entity):
    ents = deque([entity])
    while True:
        e = ents.popleft()
        ents += e.get_unpacked_list() if e.level in {"R", "C"} else e.child_list
        if {x.level for x in ents} == {"A"}:
            break
    return list(ents)

def res_of(a): return a.get_parent()
def is_h(a): return a.element in ("H", "D")
def is_het(a): return res_of(a).id[0] != " "
def is_ca(a): return a.get_name() == "CA" and res_of(a).id[0] == " "

atoms = walk(model)
if "--ca-only" in flags:
    atoms = [a for a in atoms if is_ca(a)]
else:
    if "--no-hetatm" in flags: atoms = [a for a in atoms if not is_het(a)]
    if "--no-hydrogens" in flags: atoms = [a for a in atoms if not is_h(a)]
if not atoms: sys.exit("selection retained no atoms")

coords = np.asarray([a.coord for a in atoms], dtype=np.float32)
masses = np.asarray([a.mass for a in atoms], dtype=np.float32)
com = np.average(coords, axis=0, weights=masses)
cen = np.average(coords, axis=0)
rg = float(np.sqrt(np.average(np.sum((coords - com) ** 2, axis=1), weights=masses)))
rgg = float(np.sqrt(np.average(np.sum((coords - cen) ** 2, axis=1))))
total_mass = float(sum(a.mass for a in atoms))
bmin = coords.min(axis=0); bmax = coords.max(axis=0); bdim = bmax - bmin

seen, last = [], None
for a in atoms:
    r = res_of(a); key = (r.get_parent().id, r.id)
    if key != last: seen.append(key); last = key

def line(n, *vs): print(n + "\t" + "\t".join("%.10g" % v for v in vs))
print("atoms\t%d" % len(atoms)); print("residues\t%d" % len(seen))
line("total_mass", total_mass)
line("center_of_mass", *com.tolist()); line("centroid", *cen.tolist())
line("radius_of_gyration", rg); line("radius_of_gyration_geometric", rgg)
line("bbox_min", *bmin.tolist()); line("bbox_max", *bmax.tolist()); line("bbox_dim", *bdim.tolist())
"#;
