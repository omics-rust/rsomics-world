# rsomics-pdb-dihedrals

Per-residue protein torsion angles from a PDB: backbone phi/psi/omega and
side-chain chi1–chi5, as IUPAC signed degrees in (-180, 180].

```
rsomics-pdb-dihedrals prot.pdb              # all angles
rsomics-pdb-dihedrals prot.pdb --backbone   # phi/psi/omega only
rsomics-pdb-dihedrals prot.pdb --chi        # chi1..chi5 only
rsomics-pdb-dihedrals prot.pdb --ramachandran   # phi/psi only
rsomics-pdb-dihedrals - < prot.pdb          # stdin
```

Output is TSV: `chain  resseq  resname  phi  psi  omega  chi1 chi2 chi3 chi4 chi5`,
`NA` where an angle is undefined (phi/omega at a chain's first residue, psi at its
last, chi beyond a residue type's rotatable bonds). Only the 20 standard amino
acids are emitted; HETATM/water are skipped. First MODEL, first altloc.

phi = C(i-1)-N-CA-C, psi = N-CA-C-N(i+1), omega = CA(i-1)-C(i-1)-N-CA.
chi atom quads follow the IUPAC side-chain convention per residue type.

## Origin

Independent Rust reimplementation of the dihedral extraction performed by
biopython's `Bio.PDB`, based on:

- biopython `Bio.PDB.vectors.calc_dihedral` and `Bio.PDB.ic_data` (BSD-3-Clause —
  read and cited for the chi atom-quad tables and the dihedral sign/wrap
  convention).
- Cock et al., "Biopython: freely available Python tools for computational
  molecular biology and bioinformatics", Bioinformatics 25(11):1422–1423, 2009.
  doi:10.1093/bioinformatics/btp163

A dihedral is `atan2` over two cross products; given the coordinate parse, the
standard atom quads, and the (-180, 180] wrap, the value is exact. Validated
value-tolerance (< 5e-3 degrees) against biopython `calc_dihedral` on 1CRN,
4HHB, 1AON and 1UBQ; the residual is float-ordering roundoff at the 4th decimal.
biopython's `internal_coords.get_angle` assembles a di/hedron graph and returns
None for residues whose assembly is incomplete; the direct `calc_dihedral`
geometry is the faithful oracle and this crate matches it.

License: MIT OR Apache-2.0.
Upstream credit: biopython https://biopython.org (BSD-3-Clause).
