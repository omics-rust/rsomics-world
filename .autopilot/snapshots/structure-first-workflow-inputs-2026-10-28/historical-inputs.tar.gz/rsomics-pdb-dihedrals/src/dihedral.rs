//! IUPAC signed dihedral over four points, degrees in (-180, 180].

pub type Vec3 = [f64; 3];

fn sub(a: Vec3, b: Vec3) -> Vec3 {
    [a[0] - b[0], a[1] - b[1], a[2] - b[2]]
}

fn cross(a: Vec3, b: Vec3) -> Vec3 {
    [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]
}

fn dot(a: Vec3, b: Vec3) -> f64 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}

fn norm(a: Vec3) -> f64 {
    dot(a, a).sqrt()
}

/// Signed torsion p1-p2-p3-p4 in degrees, (-180, 180].
pub fn dihedral(p1: Vec3, p2: Vec3, p3: Vec3, p4: Vec3) -> f64 {
    let b1 = sub(p2, p1);
    let b2 = sub(p3, p2);
    let b3 = sub(p4, p3);
    let n1 = cross(b1, b2);
    let n2 = cross(b2, b3);
    let x = dot(n1, n2);
    let y = dot(cross(n1, n2), b2) / norm(b2);
    let deg = y.atan2(x).to_degrees();
    if deg == -180.0 { 180.0 } else { deg }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn matches_biopython_crambin_res2() {
        let ca_prev = [16.967, 12.784, 4.338];
        let c_prev = [15.685, 12.755, 5.133];
        let n = [15.115, 11.555, 5.265];
        let ca = [13.856, 11.469, 6.066];
        let c = [14.164, 10.785, 7.379];
        let n_next = [13.488, 11.241, 8.417];
        let phi = dihedral(c_prev, n, ca, c);
        let psi = dihedral(n, ca, c, n_next);
        let omega = dihedral(ca_prev, c_prev, n, ca);
        assert!((phi - -107.8325).abs() < 1e-3, "phi {phi}");
        assert!((psi - 144.3462).abs() < 1e-3, "psi {psi}");
        assert!((omega - 178.8760).abs() < 1e-3, "omega {omega}");
    }
}
