pub mod chi;
pub mod cli;
pub mod dihedral;
pub mod pdb;

use std::io::Write;

use rayon::prelude::*;
use rsomics_common::Result;

use crate::dihedral::{Vec3, dihedral};
use crate::pdb::{Chain, Residue};

#[derive(Clone, Copy)]
pub enum Mode {
    All,
    Backbone,
    Chi,
    Ramachandran,
}

pub struct Row {
    pub chain: char,
    pub resseq: i32,
    pub resname: String,
    pub phi: Option<f64>,
    pub psi: Option<f64>,
    pub omega: Option<f64>,
    pub chi: [Option<f64>; 5],
}

fn at(r: &Residue, name: &str) -> Option<Vec3> {
    r.pos(name)
}

fn quad(a: Option<Vec3>, b: Option<Vec3>, c: Option<Vec3>, d: Option<Vec3>) -> Option<f64> {
    Some(dihedral(a?, b?, c?, d?))
}

fn residue_row(chain: &Chain, i: usize) -> Row {
    let r = &chain.residues[i];
    let prev = if i > 0 {
        Some(&chain.residues[i - 1])
    } else {
        None
    };
    let next = chain.residues.get(i + 1);

    let phi = prev.and_then(|p| quad(at(p, "C"), at(r, "N"), at(r, "CA"), at(r, "C")));
    let psi = next.and_then(|n| quad(at(r, "N"), at(r, "CA"), at(r, "C"), at(n, "N")));
    let omega = prev.and_then(|p| quad(at(p, "CA"), at(p, "C"), at(r, "N"), at(r, "CA")));

    let mut chi = [None; 5];
    for (slot, atoms) in chi::chi_atoms(&r.resname).iter().enumerate() {
        chi[slot] = quad(
            at(r, atoms[0]),
            at(r, atoms[1]),
            at(r, atoms[2]),
            at(r, atoms[3]),
        );
    }

    Row {
        chain: chain.id,
        resseq: r.resseq,
        resname: r.resname.clone(),
        phi,
        psi,
        omega,
        chi,
    }
}

pub fn compute(chains: &[Chain]) -> Vec<Row> {
    chains
        .par_iter()
        .flat_map(|chain| {
            (0..chain.residues.len())
                .into_par_iter()
                .map(|i| residue_row(chain, i))
                .collect::<Vec<_>>()
        })
        .collect()
}

fn cell(v: Option<f64>) -> String {
    match v {
        Some(x) => format!("{x:.4}"),
        None => "NA".to_string(),
    }
}

pub fn write_tsv<W: Write>(w: &mut W, rows: &[Row], mode: Mode) -> Result<()> {
    let header: &[&str] = match mode {
        Mode::All => &[
            "chain", "resseq", "resname", "phi", "psi", "omega", "chi1", "chi2", "chi3", "chi4",
            "chi5",
        ],
        Mode::Backbone => &["chain", "resseq", "resname", "phi", "psi", "omega"],
        Mode::Chi => &[
            "chain", "resseq", "resname", "chi1", "chi2", "chi3", "chi4", "chi5",
        ],
        Mode::Ramachandran => &["chain", "resseq", "resname", "phi", "psi"],
    };
    writeln!(w, "{}", header.join("\t"))?;

    let mut buf = String::with_capacity(rows.len() * 80);
    for r in rows {
        buf.push(r.chain);
        buf.push('\t');
        buf.push_str(&r.resseq.to_string());
        buf.push('\t');
        buf.push_str(&r.resname);
        match mode {
            Mode::All => {
                for v in [r.phi, r.psi, r.omega] {
                    buf.push('\t');
                    buf.push_str(&cell(v));
                }
                for v in r.chi {
                    buf.push('\t');
                    buf.push_str(&cell(v));
                }
            }
            Mode::Backbone => {
                for v in [r.phi, r.psi, r.omega] {
                    buf.push('\t');
                    buf.push_str(&cell(v));
                }
            }
            Mode::Chi => {
                for v in r.chi {
                    buf.push('\t');
                    buf.push_str(&cell(v));
                }
            }
            Mode::Ramachandran => {
                for v in [r.phi, r.psi] {
                    buf.push('\t');
                    buf.push_str(&cell(v));
                }
            }
        }
        buf.push('\n');
    }
    w.write_all(buf.as_bytes())?;
    Ok(())
}
