//! Standard-amino-acid residues in chain/file order, sourced from the shared
//! `rsomics-pdb-core` parser. One model; per atom name the highest-occupancy
//! alternate location wins, matching biopython's DisorderedAtom.disordered_select
//! default. HETATM and non-standard residues drop out.

use std::collections::HashMap;

use rsomics_common::Result;
use rsomics_pdb_core::{AltLocPolicy, ParseOptions, ResidueFilter, select_altloc};

use crate::dihedral::Vec3;

pub struct Residue {
    pub chain: char,
    pub resseq: i32,
    pub icode: char,
    pub resname: String,
    atoms: HashMap<String, Vec3>,
}

impl Residue {
    pub fn pos(&self, name: &str) -> Option<Vec3> {
        self.atoms.get(name).copied()
    }
}

pub struct Chain {
    pub id: char,
    pub residues: Vec<Residue>,
}

const STANDARD_AA: &[&str] = &[
    "ALA", "ARG", "ASN", "ASP", "CYS", "GLN", "GLU", "GLY", "HIS", "ILE", "LEU", "LYS", "MET",
    "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL",
];

pub fn is_standard_aa(resname: &str) -> bool {
    STANDARD_AA.contains(&resname)
}

/// Parse the first MODEL of a PDB into chains of standard amino-acid residues,
/// preserving chain and residue order.
pub fn parse(text: &str) -> Result<Vec<Chain>> {
    let opts = ParseOptions {
        include_hetatm: false,
        include_hydrogen: true,
        residue_filter: ResidueFilter::Standard20,
    };
    let atoms = select_altloc(
        rsomics_pdb_core::parse(text, &opts)?,
        AltLocPolicy::HighestOccupancy,
    );

    let mut chains: Vec<Chain> = Vec::new();
    let mut chain_index: HashMap<char, usize> = HashMap::new();

    for a in atoms {
        let ci = *chain_index.entry(a.chain).or_insert_with(|| {
            chains.push(Chain {
                id: a.chain,
                residues: Vec::new(),
            });
            chains.len() - 1
        });
        let chain = &mut chains[ci];

        let need_new = match chain.residues.last() {
            Some(r) => r.resseq != a.resseq || r.icode != a.icode || r.resname != a.resname,
            None => true,
        };
        if need_new {
            chain.residues.push(Residue {
                chain: a.chain,
                resseq: a.resseq,
                icode: a.icode,
                resname: a.resname.clone(),
                atoms: HashMap::new(),
            });
        }
        chain
            .residues
            .last_mut()
            .unwrap()
            .atoms
            .insert(a.name, a.coord);
    }

    Ok(chains)
}
