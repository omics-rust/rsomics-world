use clap::Parser;
use rsomics_common::Tool;
use rsomics_pdb_dihedrals::cli::Cli;

fn main() -> std::process::ExitCode {
    Cli::parse().run()
}
