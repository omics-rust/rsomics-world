use std::fs;
use std::io::{self, BufWriter, Read};
use std::path::PathBuf;

use clap::Parser;
use rsomics_common::{CommonFlags, Result, Tool, ToolMeta};

use crate::{Mode, compute, pdb, write_tsv};

#[derive(Parser)]
#[command(
    name = "rsomics-pdb-dihedrals",
    version,
    about = "Per-residue protein torsion angles (phi/psi/omega, chi1-chi5) from a PDB"
)]
pub struct Cli {
    /// Input PDB file, or - for stdin.
    pub pdb: PathBuf,

    /// Emit only backbone angles (phi, psi, omega).
    #[arg(long)]
    pub backbone: bool,

    /// Emit only side-chain angles (chi1-chi5).
    #[arg(long)]
    pub chi: bool,

    /// Emit only phi/psi for Ramachandran plotting.
    #[arg(long)]
    pub ramachandran: bool,

    #[command(flatten)]
    pub common: CommonFlags,
}

impl Cli {
    fn mode(&self) -> Mode {
        match (self.backbone, self.chi, self.ramachandran) {
            (true, false, false) => Mode::Backbone,
            (false, true, false) => Mode::Chi,
            (false, false, true) => Mode::Ramachandran,
            _ => Mode::All,
        }
    }
}

impl Tool for Cli {
    fn meta() -> ToolMeta {
        ToolMeta {
            name: "rsomics-pdb-dihedrals",
            version: env!("CARGO_PKG_VERSION"),
        }
    }

    fn common(&self) -> &CommonFlags {
        &self.common
    }

    fn execute(self) -> Result<()> {
        let mode = self.mode();
        let text = if self.pdb.as_os_str() == "-" {
            let mut s = String::new();
            io::stdin().read_to_string(&mut s)?;
            s
        } else {
            fs::read_to_string(&self.pdb)?
        };
        let chains = pdb::parse(&text)?;
        let rows = compute(&chains);
        let stdout = io::stdout();
        let mut w = BufWriter::new(stdout.lock());
        write_tsv(&mut w, &rows, mode)?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use clap::CommandFactory;

    #[test]
    fn cli_definition_is_valid() {
        super::Cli::command().debug_assert();
    }
}
