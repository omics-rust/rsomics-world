//! Differential compat against biopython's Bio.PDB.vectors.calc_dihedral.
//!
//! The committed golden (tests/golden/1crn.dihedrals.tsv) was captured from
//! biopython 1.87. The live-oracle test reproduces it when biopython is on
//! PATH (loud-skip otherwise). Both compare numerically: biopython computes
//! the same dihedral in numpy float order, so the 4-decimal TSV jitters in
//! the last digit. Residual is bounded < 5e-3 degrees.

use std::env;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;

const TOL: f64 = 5e-3;

fn bin() -> PathBuf {
    PathBuf::from(env!("CARGO_BIN_EXE_rsomics-pdb-dihedrals"))
}

fn manifest(rel: &str) -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR")).join(rel)
}

fn parse(tsv: &str) -> Vec<(String, Vec<Option<f64>>)> {
    tsv.lines()
        .skip(1)
        .map(|line| {
            let cols: Vec<&str> = line.split('\t').collect();
            let key = format!("{}\t{}\t{}", cols[0], cols[1], cols[2]);
            let vals = cols[3..]
                .iter()
                .map(|c| {
                    if *c == "NA" {
                        None
                    } else {
                        Some(c.parse().unwrap())
                    }
                })
                .collect();
            (key, vals)
        })
        .collect()
}

fn diff(a: &str, b: &str) -> f64 {
    let pa = parse(a);
    let pb = parse(b);
    assert_eq!(pa.len(), pb.len(), "row count mismatch");
    let mut max = 0.0_f64;
    for ((ka, va), (kb, vb)) in pa.iter().zip(&pb) {
        assert_eq!(ka, kb, "key mismatch");
        assert_eq!(va.len(), vb.len(), "column count mismatch at {ka}");
        for (x, y) in va.iter().zip(vb) {
            match (x, y) {
                (Some(x), Some(y)) => max = max.max((x - y).abs()),
                (None, None) => {}
                _ => panic!("NA mismatch at {ka}"),
            }
        }
    }
    max
}

fn run_ours(pdb: &Path) -> String {
    let out = Command::new(bin()).arg(pdb).output().unwrap();
    assert!(out.status.success(), "binary failed: {:?}", out.status);
    String::from_utf8(out.stdout).unwrap()
}

#[test]
fn golden_1crn() {
    let ours = run_ours(&manifest("tests/golden/1crn.pdb"));
    let golden = fs::read_to_string(manifest("tests/golden/1crn.dihedrals.tsv")).unwrap();
    let d = diff(&golden, &ours);
    assert!(d < TOL, "max diff {d} exceeds {TOL}");
}

/// Alt-loc selection: per (residue, atom) the highest-occupancy alternate
/// wins, regardless of its label. Residue 1 has CB/OG in altloc A(occ 0.40)
/// and B(occ 0.60); biopython selects B, giving chi1 = 47.3217 (the A
/// conformer would give -60.0495). Residue 2's CB/OG carry only labels B/C
/// (no 'A', no blank); those atoms must not be dropped, so chi1 is computed,
/// not NA. Golden values captured from biopython 1.87 on the same fixture.
#[test]
fn golden_altloc() {
    let ours = run_ours(&manifest("tests/golden/altloc.pdb"));
    let golden = fs::read_to_string(manifest("tests/golden/altloc.dihedrals.tsv")).unwrap();
    let d = diff(&golden, &ours);
    assert!(d < TOL, "max diff {d} exceeds {TOL}");

    let rows = parse(&ours);
    let chi1 = |i: usize| rows[i].1[3].expect("chi1 must be computed, not NA");
    assert!(
        (chi1(0) - 47.3217).abs() < TOL,
        "res1 chi1 {} must use the higher-occupancy B alternate (47.3217), not A (-60.0495)",
        chi1(0)
    );
    assert!(
        (chi1(1) - 47.3217).abs() < TOL,
        "res2 chi1 {} must be computed from the B/C-only alternates",
        chi1(1)
    );
}

#[test]
fn live_oracle_biopython() {
    let py = which_biopython();
    let Some(py) = py else {
        eprintln!("SKIP live_oracle_biopython: no biopython on PATH");
        return;
    };
    let scratch = env::temp_dir().join("rsomics-pdb-dihedrals-compat");
    fs::create_dir_all(&scratch).unwrap();
    let script = scratch.join("oracle.py");
    fs::write(&script, ORACLE_PY).unwrap();

    let pdb = manifest("tests/golden/1crn.pdb");
    let out = Command::new(&py).arg(&script).arg(&pdb).output().unwrap();
    assert!(
        out.status.success(),
        "oracle failed: {}",
        String::from_utf8_lossy(&out.stderr)
    );
    let expected = String::from_utf8(out.stdout).unwrap();

    let ours = run_ours(&pdb);
    let d = diff(&expected, &ours);
    assert!(d < TOL, "live max diff {d} exceeds {TOL}");
}

fn which_biopython() -> Option<String> {
    for py in ["python3", "python"] {
        let ok = Command::new(py)
            .args(["-c", "import Bio.PDB.vectors"])
            .output()
            .map(|o| o.status.success())
            .unwrap_or(false);
        if ok {
            return Some(py.to_string());
        }
    }
    None
}

const ORACLE_PY: &str = r#"
import sys, math, warnings
warnings.simplefilter("ignore")
from Bio.PDB import PDBParser
from Bio.PDB.vectors import calc_dihedral

STD = set("ALA ARG ASN ASP CYS GLN GLU GLY HIS ILE LEU LYS MET PHE PRO SER THR TRP TYR VAL".split())
CHI = {
 "ARG":[("N","CA","CB","CG"),("CA","CB","CG","CD"),("CB","CG","CD","NE"),("CG","CD","NE","CZ"),("CD","NE","CZ","NH1")],
 "ASN":[("N","CA","CB","CG"),("CA","CB","CG","OD1")],"ASP":[("N","CA","CB","CG"),("CA","CB","CG","OD1")],
 "CYS":[("N","CA","CB","SG")],"GLN":[("N","CA","CB","CG"),("CA","CB","CG","CD"),("CB","CG","CD","OE1")],
 "GLU":[("N","CA","CB","CG"),("CA","CB","CG","CD"),("CB","CG","CD","OE1")],"HIS":[("N","CA","CB","CG"),("CA","CB","CG","ND1")],
 "ILE":[("N","CA","CB","CG1"),("CA","CB","CG1","CD1")],"LEU":[("N","CA","CB","CG"),("CA","CB","CG","CD1")],
 "LYS":[("N","CA","CB","CG"),("CA","CB","CG","CD"),("CB","CG","CD","CE"),("CG","CD","CE","NZ")],
 "MET":[("N","CA","CB","CG"),("CA","CB","CG","SD"),("CB","CG","SD","CE")],"PHE":[("N","CA","CB","CG"),("CA","CB","CG","CD1")],
 "PRO":[("N","CA","CB","CG"),("CA","CB","CG","CD")],"SER":[("N","CA","CB","OG")],"THR":[("N","CA","CB","OG1")],
 "TRP":[("N","CA","CB","CG"),("CA","CB","CG","CD1")],"TYR":[("N","CA","CB","CG"),("CA","CB","CG","CD1")],"VAL":[("N","CA","CB","CG1")],
}
def fmt(v): return "NA" if v is None else "%.4f" % math.degrees(v)
def dih(atoms):
    try: return calc_dihedral(*[a.get_vector() for a in atoms])
    except Exception: return None
p = PDBParser(QUIET=True)
m = p.get_structure("x", sys.argv[1])[0]
print("chain\tresseq\tresname\tphi\tpsi\tomega\tchi1\tchi2\tchi3\tchi4\tchi5")
for chain in m:
    res = [r for r in chain if r.resname in STD]
    for i, r in enumerate(res):
        prev = res[i-1] if i > 0 else None
        nxt = res[i+1] if i+1 < len(res) else None
        def at(rr, n):
            return rr[n] if (rr is not None and n in rr) else None
        def q(*aa):
            return dih(aa) if all(x is not None for x in aa) else None
        phi = q(at(prev,"C"), at(r,"N"), at(r,"CA"), at(r,"C")) if prev else None
        psi = q(at(r,"N"), at(r,"CA"), at(r,"C"), at(nxt,"N")) if nxt else None
        omega = q(at(prev,"CA"), at(prev,"C"), at(r,"N"), at(r,"CA")) if prev else None
        chis = []
        defs = CHI.get(r.resname, [])
        for k in range(5):
            chis.append(q(*[at(r,n) for n in defs[k]]) if k < len(defs) else None)
        cells = "\t".join(fmt(v) for v in [phi,psi,omega]+chis)
        print("%s\t%d\t%s\t%s" % (chain.id, r.id[1], r.resname, cells))
"#;
