//! Fixed-column PDB ATOM/HETATM parser shared by the rsomics structure tools.
//!
//! Column extraction matches biopython's `PDBParser`: the first model only,
//! fixed byte offsets for every field, and the same atom-name → element
//! guessing when the element column is blank. Altloc handling is left to the
//! caller via [`select_altloc`], because different upstreams disagree on it —
//! biopython counts every altloc, freesasa keeps a global-first label,
//! tm-align/dssp keep a fixed label, and occupancy-selection keeps the highest.

use std::collections::HashMap;

use rsomics_common::Result;
use rsomics_common::error::RsomicsError;

/// The 20 standard amino-acid residue names.
const STANDARD_20: &[&str] = &[
    "ALA", "ARG", "ASN", "ASP", "CYS", "GLN", "GLU", "GLY", "HIS", "ILE", "LEU", "LYS", "MET",
    "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL",
];

/// One parsed atom carrying every field the structure tools filter or report on.
#[derive(Debug, Clone)]
pub struct RawAtom {
    pub serial: i64,
    /// biopython atom name: the sole whitespace-stripped token of the raw 4-column
    /// field, or the raw field itself when it holds internal spaces (e.g. `" N B "`).
    pub name: String,
    /// The raw 4-column atom field, spaces preserved (e.g. `" CA "`).
    pub fullname: String,
    pub altloc: char,
    pub resname: String,
    pub chain: char,
    pub resseq: i32,
    pub icode: char,
    pub coord: [f64; 3],
    pub occupancy: f64,
    pub bfactor: f64,
    pub element: String,
    pub is_hetatm: bool,
    pub is_hydrogen: bool,
}

/// How to resolve alternate locations of a disordered atom.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AltLocPolicy {
    /// Every altloc is its own atom (biopython `get_unpacked_list`).
    KeepAll,
    /// Per `(chain, resseq, icode, name)`, keep the strictly-highest occupancy;
    /// ties and lower keep the first seen.
    HighestOccupancy,
    /// Keep atoms whose altloc is blank or equals the given label (tm-align/dssp).
    BlankOrLabel(char),
    /// freesasa's running-first-label rule.
    FreesasaGlobalFirst,
}

/// Which residues to admit.
#[derive(Debug, Clone)]
pub enum ResidueFilter {
    All,
    /// Only the 20 standard amino acids.
    Standard20,
    /// The 20 standard amino acids plus the listed modified residue names
    /// (e.g. `MSE`, `SEC`, `PYL`), which are admitted even as HETATM records.
    Standard20PlusModified(Vec<String>),
}

/// Record-level parse configuration.
#[derive(Debug, Clone)]
pub struct ParseOptions {
    pub include_hetatm: bool,
    pub include_hydrogen: bool,
    pub residue_filter: ResidueFilter,
}

impl Default for ParseOptions {
    fn default() -> Self {
        ParseOptions {
            include_hetatm: false,
            include_hydrogen: true,
            residue_filter: ResidueFilter::All,
        }
    }
}

/// Capitalise like Python `str.capitalize`: first char upper, rest lower.
fn capitalize(s: &str) -> String {
    let mut chars = s.chars();
    match chars.next() {
        None => String::new(),
        Some(first) => first.to_uppercase().collect::<String>() + &chars.as_str().to_lowercase(),
    }
}

/// Guess an element symbol from the atom name, mirroring biopython
/// `Atom._assign_element` when the element column is blank.
fn guess_element(name: &str, fullname: &str) -> String {
    let fb = fullname.as_bytes();
    let first_alpha = fb.first().is_some_and(|b| b.is_ascii_alphabetic());
    let tail_all_digits = fullname.len() > 2 && fullname[2..].bytes().all(|b| b.is_ascii_digit());

    let putative: String = if first_alpha && !tail_all_digits {
        name.trim().to_string()
    } else if name.as_bytes().first().is_some_and(|b| b.is_ascii_digit()) {
        name.chars().nth(1).map(String::from).unwrap_or_default()
    } else {
        name.chars().next().map(String::from).unwrap_or_default()
    };

    capitalize(&putative)
}

fn parse_coord(field: &str) -> Result<f64> {
    field
        .trim()
        .parse()
        .map_err(|_| RsomicsError::InvalidInput(format!("invalid coordinate {field:?}")))
}

/// Parse a fixed 6-wide numeric column, defaulting to `0.0` when the line is too
/// short to reach it or the field is blank; a present but garbled field is loud.
fn parse_optional_field(line: &str, start: usize, end: usize) -> Result<f64> {
    match line.get(start..end) {
        None => Ok(0.0),
        Some(field) => {
            let t = field.trim();
            if t.is_empty() {
                Ok(0.0)
            } else {
                t.parse().map_err(|_| {
                    RsomicsError::InvalidInput(format!("invalid numeric field {field:?}"))
                })
            }
        }
    }
}

fn is_modified(filter: &ResidueFilter, resname: &str) -> bool {
    matches!(filter, ResidueFilter::Standard20PlusModified(list) if list.iter().any(|s| s == resname))
}

/// Decide whether a record survives the residue and hetatm filters. The hydrogen
/// filter is applied separately once the element is known.
fn keep_record(is_hetatm: bool, resname: &str, opts: &ParseOptions) -> bool {
    let residue_ok = match &opts.residue_filter {
        ResidueFilter::All => true,
        ResidueFilter::Standard20 => STANDARD_20.contains(&resname),
        ResidueFilter::Standard20PlusModified(list) => {
            STANDARD_20.contains(&resname) || list.iter().any(|s| s == resname)
        }
    };
    if !residue_ok {
        return false;
    }

    // A HETATM survives include_hetatm=false only when it is an explicitly
    // allowed modified residue, so HETATM-stored residues like MSE reach dssp.
    if is_hetatm && !opts.include_hetatm && !is_modified(&opts.residue_filter, resname) {
        return false;
    }
    true
}

/// Parse the first model's ATOM/HETATM records under `opts`.
pub fn parse(text: &str, opts: &ParseOptions) -> Result<Vec<RawAtom>> {
    let mut atoms: Vec<RawAtom> = Vec::new();
    let mut seen_model = false;

    for line in text.lines() {
        let rec = line.get(0..6).unwrap_or("");
        if rec == "ENDMDL" {
            break;
        }
        if rec == "MODEL " {
            if seen_model {
                break;
            }
            seen_model = true;
            continue;
        }
        let is_hetatm = rec == "HETATM";
        if rec != "ATOM  " && !is_hetatm {
            continue;
        }
        if line.len() < 54 {
            return Err(RsomicsError::InvalidInput(format!(
                "truncated coordinate record: {line:?}"
            )));
        }

        let resname = line[17..20].trim().to_string();
        if !keep_record(is_hetatm, &resname, opts) {
            continue;
        }

        let fullname = line[12..16].to_string();
        let name = {
            let parts: Vec<&str> = fullname.split_whitespace().collect();
            if parts.len() == 1 {
                parts[0].to_string()
            } else {
                fullname.clone()
            }
        };
        let altloc = line.as_bytes()[16] as char;
        let chain = line.as_bytes()[21] as char;
        let serial: i64 = line[6..11]
            .trim()
            .parse()
            .map_err(|_| RsomicsError::InvalidInput(format!("invalid serial in {line:?}")))?;
        let resseq: i32 = line[22..26]
            .trim()
            .parse()
            .map_err(|_| RsomicsError::InvalidInput(format!("invalid resseq in {line:?}")))?;
        let icode = line.as_bytes()[26] as char;

        let x = parse_coord(&line[30..38])?;
        let y = parse_coord(&line[38..46])?;
        let z = parse_coord(&line[46..54])?;
        let occupancy = parse_optional_field(line, 54, 60)?;
        let bfactor = parse_optional_field(line, 60, 66)?;

        let col_element = line.get(76..78).unwrap_or("").trim().to_uppercase();
        let element = if col_element.is_empty() {
            guess_element(&name, &fullname)
        } else {
            col_element
        };
        let is_hydrogen = element == "H" || element == "D";
        if is_hydrogen && !opts.include_hydrogen {
            continue;
        }

        atoms.push(RawAtom {
            serial,
            name,
            fullname,
            altloc,
            resname,
            chain,
            resseq,
            icode,
            coord: [x, y, z],
            occupancy,
            bfactor,
            element,
            is_hetatm,
            is_hydrogen,
        });
    }

    if atoms.is_empty() {
        return Err(RsomicsError::InvalidInput(
            "no ATOM/HETATM records retained".to_string(),
        ));
    }

    Ok(atoms)
}

/// Resolve alternate locations under `policy`.
pub fn select_altloc(atoms: Vec<RawAtom>, policy: AltLocPolicy) -> Vec<RawAtom> {
    match policy {
        AltLocPolicy::KeepAll => atoms,

        AltLocPolicy::HighestOccupancy => {
            let mut out: Vec<RawAtom> = Vec::new();
            let mut selected: HashMap<(char, i32, char, String), usize> = HashMap::new();
            for atom in atoms {
                if atom.altloc == ' ' {
                    out.push(atom);
                    continue;
                }
                let key = (atom.chain, atom.resseq, atom.icode, atom.name.clone());
                match selected.get(&key) {
                    None => {
                        selected.insert(key, out.len());
                        out.push(atom);
                    }
                    // strict `>` keeps the first-seen atom on ties (biopython
                    // DisorderedAtom.disordered_add).
                    Some(&i) if atom.occupancy > out[i].occupancy => out[i] = atom,
                    Some(_) => {}
                }
            }
            out
        }

        AltLocPolicy::BlankOrLabel(label) => atoms
            .into_iter()
            .filter(|a| a.altloc == ' ' || a.altloc == label)
            .collect(),

        AltLocPolicy::FreesasaGlobalFirst => {
            let mut the_alt = ' ';
            let mut out: Vec<RawAtom> = Vec::new();
            for atom in atoms {
                let alt = atom.altloc;
                // A blank altloc resets the running label, so a following chain's
                // alternates are not stuck behind a stale first label. Otherwise
                // keep only atoms matching the running label; different ones drop.
                if alt == ' ' || the_alt == ' ' {
                    the_alt = alt;
                    out.push(atom);
                } else if alt == the_alt {
                    out.push(atom);
                }
            }
            out
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const BASIC: &str = "\
ATOM      1  N   ALA A   1       0.000   0.000   0.000  1.00  0.00           N
ATOM      2  CA  ALA A   1       1.500   0.000   0.000  0.80 11.00           C
ATOM      3  C   ALA A   1       3.000   0.000   0.000  1.00  0.00           C
HETATM    5  O   HOH B   2      10.000   0.000   0.000  1.00  0.00           O
";

    const ALT: &str = "\
ATOM      1  N   ALA A   1       0.000   0.000   0.000  1.00  0.00           N
ATOM      2  CA AALA A   1       1.000   0.000   0.000  0.60  0.00           C
ATOM      3  CA BALA A   1       2.000   0.000   0.000  0.40  0.00           C
ATOM      4  CB BALA A   1       3.000   0.000   0.000  0.50  0.00           C
";

    fn all_records() -> ParseOptions {
        ParseOptions {
            include_hetatm: true,
            ..Default::default()
        }
    }

    #[test]
    fn parses_fields() {
        let a = parse(BASIC, &all_records()).unwrap();
        assert_eq!(a.len(), 4);

        assert_eq!(a[0].serial, 1);
        assert_eq!(a[0].name, "N");
        assert_eq!(a[0].fullname.len(), 4);
        assert_eq!(a[0].fullname.trim(), "N");
        assert_eq!(a[0].altloc, ' ');
        assert_eq!(a[0].resname, "ALA");
        assert_eq!(a[0].chain, 'A');
        assert_eq!(a[0].resseq, 1);
        assert_eq!(a[0].icode, ' ');
        assert_eq!(a[0].coord, [0.0, 0.0, 0.0]);
        assert_eq!(a[0].occupancy, 1.0);
        assert_eq!(a[0].bfactor, 0.0);
        assert_eq!(a[0].element, "N");
        assert!(!a[0].is_hetatm);
        assert!(!a[0].is_hydrogen);

        assert_eq!(a[1].name, "CA");
        assert_eq!(a[1].occupancy, 0.80);
        assert_eq!(a[1].bfactor, 11.0);
        assert_eq!(a[1].element, "C");

        assert!(a[3].is_hetatm);
        assert_eq!(a[3].resname, "HOH");
        assert_eq!(a[3].chain, 'B');
        assert_eq!(a[3].resseq, 2);
        assert_eq!(a[3].coord[0], 10.0);
        assert_eq!(a[3].element, "O");
    }

    #[test]
    fn truncated_line_is_error() {
        let bad = "ATOM      1  N   ALA A   1       0.000\n";
        assert!(parse(bad, &all_records()).is_err());
    }

    #[test]
    fn first_model_only() {
        let two = "\
MODEL        1
ATOM      1  N   ALA A   1       0.000   0.000   0.000  1.00  0.00           N
ENDMDL
MODEL        2
ATOM      2  N   GLY B   2       9.000   9.000   9.000  1.00  0.00           N
ENDMDL
";
        let a = parse(two, &ParseOptions::default()).unwrap();
        assert_eq!(a.len(), 1);
        assert_eq!(a[0].resname, "ALA");
    }

    #[test]
    fn empty_input_is_error() {
        let none = "HEADER    TEST\nREMARK  none\n";
        assert!(parse(none, &ParseOptions::default()).is_err());
    }

    #[test]
    fn all_filtered_out_is_error() {
        let water =
            "HETATM    1  O   HOH B   2      10.000   0.000   0.000  1.00  0.00           O\n";
        // Default drops HETATM, so nothing remains.
        assert!(parse(water, &ParseOptions::default()).is_err());
    }

    #[test]
    fn default_drops_hetatm() {
        let a = parse(BASIC, &ParseOptions::default()).unwrap();
        assert_eq!(a.len(), 3);
        assert!(a.iter().all(|x| !x.is_hetatm));
    }

    #[test]
    fn include_hydrogen_toggle() {
        let h = "\
ATOM      1  N   ALA A   1       0.000   0.000   0.000  1.00  0.00           N
ATOM      2  H   ALA A   1       0.500   0.500   0.500  1.00  0.00           H
";
        let kept = parse(h, &ParseOptions::default()).unwrap();
        assert_eq!(kept.len(), 2);
        assert!(kept[1].is_hydrogen);

        let dropped = parse(
            h,
            &ParseOptions {
                include_hydrogen: false,
                ..Default::default()
            },
        )
        .unwrap();
        assert_eq!(dropped.len(), 1);
        assert!(dropped.iter().all(|x| !x.is_hydrogen));
    }

    const MSE: &str = "\
ATOM      1  N   ALA A   1       0.000   0.000   0.000  1.00  0.00           N
HETATM    2  SE  MSE A   2       1.000   0.000   0.000  1.00  0.00          SE
";

    #[test]
    fn standard20_drops_mse() {
        let a = parse(
            MSE,
            &ParseOptions {
                residue_filter: ResidueFilter::Standard20,
                ..Default::default()
            },
        )
        .unwrap();
        assert_eq!(a.len(), 1);
        assert_eq!(a[0].resname, "ALA");
    }

    #[test]
    fn standard20_plus_modified_keeps_mse_hetatm() {
        let a = parse(
            MSE,
            &ParseOptions {
                include_hetatm: false,
                residue_filter: ResidueFilter::Standard20PlusModified(vec!["MSE".to_string()]),
                ..Default::default()
            },
        )
        .unwrap();
        assert_eq!(a.len(), 2);
        assert!(a.iter().any(|x| x.resname == "MSE" && x.is_hetatm));
    }

    #[test]
    fn element_derived_from_name_when_col_blank() {
        // Line stops at the bfactor column: no element column present.
        let line = "ATOM      5  N   GLY A   3       5.000   0.000   0.000  1.00  0.00\n";
        assert!(line.trim_end().len() < 76);
        let a = parse(line, &ParseOptions::default()).unwrap();
        assert_eq!(a[0].element, "N");
    }

    #[test]
    fn element_from_column() {
        let a = parse(MSE, &all_records()).unwrap();
        assert_eq!(a[1].element, "SE");
    }

    #[test]
    fn keepall_keeps_all_altlocs() {
        let atoms = parse(ALT, &ParseOptions::default()).unwrap();
        assert_eq!(atoms.len(), 4);
        let out = select_altloc(atoms, AltLocPolicy::KeepAll);
        assert_eq!(out.len(), 4);
    }

    #[test]
    fn highest_occupancy_keeps_greater_and_b_only() {
        let atoms = parse(ALT, &ParseOptions::default()).unwrap();
        let out = select_altloc(atoms, AltLocPolicy::HighestOccupancy);
        // N (blank) + CA (0.60 winner) + CB (only B) = 3.
        assert_eq!(out.len(), 3);
        let ca = out.iter().find(|a| a.name == "CA").unwrap();
        assert_eq!(ca.altloc, 'A');
        assert_eq!(ca.occupancy, 0.60);
        assert!(out.iter().all(|a| a.occupancy != 0.40));
        let cb = out.iter().find(|a| a.name == "CB").unwrap();
        assert_eq!(cb.altloc, 'B');
    }

    #[test]
    fn blank_or_label_a_drops_b_only() {
        let atoms = parse(ALT, &ParseOptions::default()).unwrap();
        let out = select_altloc(atoms, AltLocPolicy::BlankOrLabel('A'));
        // N (blank) + CA altloc A. CA-B and the B-only CB are dropped.
        assert_eq!(out.len(), 2);
        assert!(out.iter().any(|a| a.name == "N"));
        assert!(out.iter().any(|a| a.name == "CA" && a.altloc == 'A'));
        assert!(!out.iter().any(|a| a.name == "CB"));
        assert!(!out.iter().any(|a| a.altloc == 'B'));
    }

    #[test]
    fn freesasa_on_main_fixture() {
        let atoms = parse(ALT, &ParseOptions::default()).unwrap();
        let out = select_altloc(atoms, AltLocPolicy::FreesasaGlobalFirst);
        // N sets the_alt=' ', CA-A becomes global first 'A', CA-B and CB-B drop.
        assert_eq!(out.len(), 2);
        assert!(out.iter().any(|a| a.name == "N"));
        assert!(out.iter().any(|a| a.name == "CA" && a.altloc == 'A'));
    }

    #[test]
    fn freesasa_blank_resets_running_label() {
        // altloc sequence A, blank, B: the blank must reset the running label so
        // the following B is kept as the new global first (the sticky-altloc fix).
        let reset = "\
ATOM      1  CA AALA A   1       0.000   0.000   0.000  0.60  0.00           C
ATOM      2  N   GLY A   2       1.000   0.000   0.000  1.00  0.00           N
ATOM      3  CA BGLY A   2       2.000   0.000   0.000  0.40  0.00           C
";
        let atoms = parse(reset, &ParseOptions::default()).unwrap();
        assert_eq!(atoms.len(), 3);
        let out = select_altloc(atoms, AltLocPolicy::FreesasaGlobalFirst);
        assert_eq!(out.len(), 3);
    }

    #[test]
    fn default_options_match_spec() {
        let d = ParseOptions::default();
        assert!(!d.include_hetatm);
        assert!(d.include_hydrogen);
        assert!(matches!(d.residue_filter, ResidueFilter::All));
    }
}
