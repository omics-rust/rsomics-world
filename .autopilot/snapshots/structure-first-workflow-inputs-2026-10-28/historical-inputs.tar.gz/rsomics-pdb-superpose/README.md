# rsomics-pdb-superpose

Kabsch least-squares superposition of two **index-paired** atom sets from PDB:
the optimal rotation, translation and RMSD putting the moving structure on top
of the reference. The correspondence is given — there is no alignment search
(that is TM-align's job) — which is what makes the result reproducible to
numerical precision.

```
rsomics-pdb-superpose --reference ref.pdb --mov mov.pdb            # Cα traces (equal length)
rsomics-pdb-superpose --reference ref.pdb --mov mov.pdb --json     # machine-readable
rsomics-pdb-superpose --reference ref.pdb --mov mov.pdb --pairs p.tsv   # explicit correspondence
```

- `--atoms ca` (default) pairs the Cα atoms of both structures position-for-position;
  the two Cα counts must match.
- `--pairs <tsv>` gives an explicit correspondence: two columns `ref_idx mov_idx`
  (0-based indices into the full ATOM list, `#` comments and blank lines ignored).
  This overrides `--atoms`.

First MODEL only, blank/`A` altloc, ATOM records in file order.

The reported rotation is biopython's **right-multiplying** matrix: a moving
coordinate maps to the reference frame as `transformed = mov · R + t`. RMSD is
`sqrt(mean(‖ref − (mov·R + t)‖²))`. `--json` emits
`{rotation:[[..],[..],[..]], translation:[..], rmsd, n_atoms}` inside the
standard envelope.

## Origin

Independent Rust reimplementation of biopython's `Bio.PDB.Superimposer`, based on:

- biopython `Bio/SVDSuperimposer/__init__.py` and `Bio/PDB/Superimposer.py`
  (BSD-3-Clause — read and cited for the exact matrix convention). With
  `coords = mov`, `reference_coords = ref`, biopython computes
  `a = dot(transpose(mov_centered), ref_centered)`, `u, d, vt = svd(a)`,
  `rot = transpose(dot(transpose(vt), transpose(u)))` (which simplifies to
  `u · vt`, i.e. `U · Vᵀ`), and the reflection fix `if det(rot) < 0: vt[2] = -vt[2]`,
  then `tran = ref_centroid − dot(mov_centroid, rot)`. This crate replicates that
  matrix order and reflection sign exactly.
- Kabsch, W. "A solution for the best rotation to relate two sets of vectors."
  Acta Cryst. A32:922–923, 1976. doi:10.1107/S0567739476001873
- Cock et al., "Biopython", Bioinformatics 25(11):1422–1423, 2009.
  doi:10.1093/bioinformatics/btp163

The 3×3 SVD is a one-sided Jacobi decomposition applied to the cross-covariance
matrix `a` directly (not the normal-equation matrix `aᵀa`, whose squared
condition number would halve the precision). Validated value-exact to machine
precision against biopython on identical float64 coordinate inputs — max
\|Δrot\| ≈ 2e-15, \|Δtran\| ≈ 2e-14, \|Δrms\| ≈ 4e-14 — including a
reflection-prone pair where the det-sign fix is required to recover a proper
rotation. (Against biopython's native float32 `Atom.get_coord()` the difference
is ~3e-7, a coordinate-ingestion truncation in biopython, not an algorithmic
divergence.)

License: MIT OR Apache-2.0.
Upstream credit: biopython https://biopython.org (BSD-3-Clause).
