use std::process::ExitCode;

use clap::Parser;
use rsomics_common::run;

use rsomics_pdb_superpose::cli::{Cli, META};

fn main() -> ExitCode {
    let cli = Cli::parse();
    let common = cli.common.clone();
    run(&common, META, move || cli.run_to_result())
}
