use std::fs;
use std::path::PathBuf;

use clap::Parser;
use rsomics_common::{CommonFlags, Result, RsomicsError, ToolMeta};

use crate::{Selection, SuperposeResult, parse_pairs, pdb, superpose_atoms};

pub const META: ToolMeta = ToolMeta {
    name: env!("CARGO_PKG_NAME"),
    version: env!("CARGO_PKG_VERSION"),
};

#[derive(Parser)]
#[command(
    name = "rsomics-pdb-superpose",
    version,
    about = "Kabsch superposition of two index-paired atom sets from PDB — rotation, translation, RMSD"
)]
pub struct Cli {
    /// Reference (fixed) structure, PDB.
    #[arg(long)]
    pub reference: PathBuf,

    /// Moving structure, PDB — superposed onto the reference.
    #[arg(long)]
    pub mov: PathBuf,

    /// Atom selection: `ca` pairs the Cα traces position-for-position
    /// (structures must have equal Cα counts).
    #[arg(long, value_enum, default_value_t = AtomSel::Ca)]
    pub atoms: AtomSel,

    /// Explicit correspondence: a TSV of `ref_idx<TAB>mov_idx` (0-based indices
    /// into the full ATOM lists). Overrides --atoms.
    #[arg(long)]
    pub pairs: Option<PathBuf>,

    #[command(flatten)]
    pub common: CommonFlags,
}

#[derive(Clone, Copy, clap::ValueEnum)]
pub enum AtomSel {
    Ca,
}

impl Cli {
    /// Run the superposition and, unless `--json`, print the human-readable
    /// report. The returned result is what the JSON envelope wraps.
    #[allow(clippy::missing_errors_doc)]
    pub fn run_to_result(&self) -> Result<SuperposeResult> {
        let ref_text = fs::read_to_string(&self.reference).map_err(RsomicsError::Io)?;
        let mov_text = fs::read_to_string(&self.mov).map_err(RsomicsError::Io)?;
        let ref_atoms = pdb::parse(&ref_text)?;
        let mov_atoms = pdb::parse(&mov_text)?;

        let selection = match &self.pairs {
            Some(p) => {
                let text = fs::read_to_string(p).map_err(RsomicsError::Io)?;
                Selection::Pairs(parse_pairs(&text)?)
            }
            None => match self.atoms {
                AtomSel::Ca => Selection::Ca,
            },
        };

        let r = superpose_atoms(&ref_atoms, &mov_atoms, &selection)?;
        if !self.common.json {
            print_human(&r);
        }
        Ok(r)
    }
}

fn print_human(r: &SuperposeResult) {
    println!("Superposed {} atom pairs", r.n_atoms);
    println!("RMSD = {:.6}", r.rmsd);
    println!("Rotation (right-multiplying: transformed = mov . R + t):");
    for row in &r.rotation {
        println!("  {:18.12}  {:18.12}  {:18.12}", row[0], row[1], row[2]);
    }
    println!(
        "Translation:\n  {:18.12}  {:18.12}  {:18.12}",
        r.translation[0], r.translation[1], r.translation[2]
    );
}

#[cfg(test)]
mod tests {
    use clap::CommandFactory;

    #[test]
    fn cli_definition_is_valid() {
        super::Cli::command().debug_assert();
    }
}
