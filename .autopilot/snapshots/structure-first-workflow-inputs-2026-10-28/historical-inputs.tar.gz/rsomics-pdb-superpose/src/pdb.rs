//! Ordered atom list from the shared `rsomics-pdb-core` parser.
//!
//! Mirrors `Bio.PDB.Superimposer`'s atom set: first MODEL only, ATOM records in
//! file order, and the highest-occupancy alternate representing each disordered
//! atom (biopython's DisorderedAtom default). Atom name, residue name, chain,
//! residue sequence number and coordinates are retained so the caller can pick
//! the paired sets (Cα selection or explicit index pairs).

use rsomics_common::Result;
use rsomics_pdb_core::{AltLocPolicy, ParseOptions, ResidueFilter, select_altloc};

use crate::superpose::Vec3;

pub struct Atom {
    pub name: String,
    pub resname: String,
    pub chain: char,
    pub resseq: i32,
    pub icode: char,
    pub coord: Vec3,
}

/// Parse the first model's ATOM records into an ordered atom list (file order).
#[allow(clippy::missing_errors_doc)]
pub fn parse(text: &str) -> Result<Vec<Atom>> {
    let opts = ParseOptions {
        include_hetatm: false,
        include_hydrogen: true,
        residue_filter: ResidueFilter::All,
    };
    let atoms = select_altloc(
        rsomics_pdb_core::parse(text, &opts)?,
        AltLocPolicy::HighestOccupancy,
    );

    Ok(atoms
        .into_iter()
        .map(|a| Atom {
            name: a.name,
            resname: a.resname,
            chain: a.chain,
            resseq: a.resseq,
            icode: a.icode,
            coord: a.coord,
        })
        .collect())
}

/// Coordinates of every Cα atom, in file order.
#[must_use]
pub fn ca_coords(atoms: &[Atom]) -> Vec<Vec3> {
    atoms
        .iter()
        .filter(|a| a.name == "CA")
        .map(|a| a.coord)
        .collect()
}
