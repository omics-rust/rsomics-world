//! Kabsch least-squares superposition matching `Bio.SVDSuperimposer`.
//!
//! Given paired point sets `ref` (fixed) and `mov` (moving), find the rotation
//! `rot` and translation `tran` putting `mov` onto `ref` so that
//! `mov·rot + tran ≈ ref` with minimum RMSD. The returned `rot` is biopython's
//! *right-multiplying* matrix — `transformed = dot(mov, rot) + tran`.
//!
//! Biopython (`Bio/SVDSuperimposer/__init__.py`, BSD) does, with
//! `coords = mov`, `reference_coords = ref`:
//!
//! ```text
//! a   = dot(transpose(mov_centered), ref_centered)   # 3×3, = movᵀ·ref
//! u, d, vt = svd(a)                                   # a = u·diag(d)·vt
//! rot = transpose(dot(transpose(vt), transpose(u)))  # = transpose(vᵀᵀ·uᵀ) = u·vt
//! if det(rot) < 0: vt[2] = -vt[2]; rot = …           # reflection fix
//! tran = av2 - dot(av1, rot)                          # av2=ref centroid, av1=mov centroid
//! ```
//!
//! `transpose(dot(transpose(vt), transpose(u)))` simplifies to `u·vt` where
//! `vt`'s rows are the right singular vectors. With `V = vtᵀ` (columns are right
//! singular vectors) this is `rot = U·Vᵀ`. The reflection fix negates the third
//! row of `vt` — i.e. the right singular vector paired with the smallest
//! singular value — exactly when `det(rot) < 0`.
//!
//! We obtain `u`/`vt` from the symmetric eigendecomposition of `aᵀa` (right
//! vectors → `vt` rows) and `aaᵀ` (left vectors → `u` columns), Jacobi-rotated;
//! a 3×3 problem needs no external SVD library.

pub type Mat3 = [[f64; 3]; 3];
pub type Vec3 = [f64; 3];

pub struct Superposition {
    /// Right-multiplying rotation: `transformed = dot(mov, rot) + tran`.
    pub rot: Mat3,
    pub tran: Vec3,
    pub rms: f64,
}

/// Superpose `mov` onto `reference` (paired by index). Both must be the same
/// non-empty length.
#[must_use]
pub fn superpose(reference: &[Vec3], mov: &[Vec3]) -> Superposition {
    let n = reference.len();
    let av2 = centroid(reference);
    let av1 = centroid(mov);

    // a = movᵀ · ref, centered. Row i (mov axis), column j (ref axis).
    let mut a = [[0.0f64; 3]; 3];
    for (m, r) in mov.iter().zip(reference) {
        let mc = [m[0] - av1[0], m[1] - av1[1], m[2] - av1[2]];
        let rc = [r[0] - av2[0], r[1] - av2[1], r[2] - av2[2]];
        for i in 0..3 {
            for j in 0..3 {
                a[i][j] += mc[i] * rc[j];
            }
        }
    }

    let rot = rotation_from_corr(a);
    let tran = [
        av2[0] - dot3(&av1, &col(&rot, 0)),
        av2[1] - dot3(&av1, &col(&rot, 1)),
        av2[2] - dot3(&av1, &col(&rot, 2)),
    ];

    let mut sum_sq = 0.0;
    for (m, r) in mov.iter().zip(reference) {
        let t = apply(&rot, &tran, m);
        for k in 0..3 {
            let d = t[k] - r[k];
            sum_sq += d * d;
        }
    }
    let rms = (sum_sq / n as f64).sqrt();

    Superposition { rot, tran, rms }
}

/// `transformed = dot(p, rot) + tran` (biopython right-multiply).
#[must_use]
pub fn apply(rot: &Mat3, tran: &Vec3, p: &Vec3) -> Vec3 {
    [
        dot3(p, &col(rot, 0)) + tran[0],
        dot3(p, &col(rot, 1)) + tran[1],
        dot3(p, &col(rot, 2)) + tran[2],
    ]
}

/// `rot = u · vt` with the biopython reflection fix on `vt[2]`. `a = movᵀ·ref`.
///
/// `svd_columns` returns `U`, `Σ` and `V` (columns = singular vectors, σ
/// descending) from a one-sided Jacobi SVD applied to `a` directly. Working on
/// `a` rather than the normal-equation matrix `aᵀa` avoids squaring the
/// condition number — that squaring is what halves the significant digits and
/// is the only reason a symmetric-eigen route diverges from LAPACK's `gesdd`.
/// We then form `rot = U Vᵀ` and apply biopython's reflection fix: when the
/// raw product reflects, negate the third right singular vector (`vt[2]`).
fn rotation_from_corr(a: Mat3) -> Mat3 {
    let (u, _sigma, v) = svd_columns(a);

    let rot = u_vt(&u, &v);
    if det(rot) < 0.0 {
        // biopython negates vt[2] = the third right singular vector = col 2 of v.
        let mut vflip = v;
        for row in &mut vflip {
            row[2] = -row[2];
        }
        return u_vt(&u, &vflip);
    }
    rot
}

/// One-sided Jacobi SVD of a 3×3 `a = U·diag(σ)·Vᵀ`. Columns of `U`/`V` are the
/// left/right singular vectors, ordered by descending σ. Givens rotations
/// orthogonalise the columns of a working copy of `a` (accumulated into `V`);
/// each final column's norm is a singular value and its unit vector a column of
/// `U`. A zero-norm column (rank deficiency) gets its left vector from the cross
/// product of the others so `U` stays a proper orthonormal frame.
#[allow(clippy::needless_range_loop)]
fn svd_columns(a: Mat3) -> (Mat3, Vec3, Mat3) {
    let mut w = a; // columns are orthogonalised in place
    let mut v = [[0.0; 3]; 3];
    for i in 0..3 {
        v[i][i] = 1.0;
    }

    for _ in 0..60 {
        let mut off = 0.0_f64;
        for p in 0..2 {
            for q in (p + 1)..3 {
                let cp = col(&w, p);
                let cq = col(&w, q);
                let alpha = dot3(&cp, &cp);
                let beta = dot3(&cq, &cq);
                let gamma = dot3(&cp, &cq);
                off = off.max(gamma.abs());
                if gamma.abs() <= 1e-300 * (alpha * beta).sqrt() {
                    continue;
                }
                let zeta = (beta - alpha) / (2.0 * gamma);
                let t = zeta.signum() / (zeta.abs() + (zeta * zeta + 1.0).sqrt());
                let c = 1.0 / (t * t + 1.0).sqrt();
                let s = c * t;
                for i in 0..3 {
                    let wip = w[i][p];
                    let wiq = w[i][q];
                    w[i][p] = c * wip - s * wiq;
                    w[i][q] = s * wip + c * wiq;
                    let vip = v[i][p];
                    let viq = v[i][q];
                    v[i][p] = c * vip - s * viq;
                    v[i][q] = s * vip + c * viq;
                }
            }
        }
        if off <= 1e-300 {
            break;
        }
    }

    let mut sigma = [0.0; 3];
    let mut u = [[0.0; 3]; 3];
    for k in 0..3 {
        let ck = col(&w, k);
        let norm = dot3(&ck, &ck).sqrt();
        sigma[k] = norm;
        if norm > 0.0 {
            for i in 0..3 {
                u[i][k] = ck[i] / norm;
            }
        }
    }
    for k in 0..3 {
        if sigma[k] == 0.0 {
            let (a1, a2) = ((k + 1) % 3, (k + 2) % 3);
            let cr = cross(col(&u, a1), col(&u, a2));
            for i in 0..3 {
                u[i][k] = cr[i];
            }
        }
    }

    // Sort columns of U, V and σ by descending singular value.
    let mut idx = [0, 1, 2];
    idx.sort_by(|&x, &y| sigma[y].partial_cmp(&sigma[x]).unwrap());
    let mut us = [[0.0; 3]; 3];
    let mut vs = [[0.0; 3]; 3];
    let mut ss = [0.0; 3];
    for (slot, &o) in idx.iter().enumerate() {
        ss[slot] = sigma[o];
        for i in 0..3 {
            us[i][slot] = u[i][o];
            vs[i][slot] = v[i][o];
        }
    }
    (us, ss, vs)
}

fn cross(a: Vec3, b: Vec3) -> Vec3 {
    [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]
}

/// `rot = u · vt` where `vt = vᵀ`. `u` columns = left vecs, `v` columns = right
/// vecs (so `vt` rows are right vecs). `rot[i][j] = Σₖ u[i][k]·v[j][k]`.
fn u_vt(u: &Mat3, v: &Mat3) -> Mat3 {
    let mut r = [[0.0; 3]; 3];
    for i in 0..3 {
        for j in 0..3 {
            for k in 0..3 {
                r[i][j] += u[i][k] * v[j][k];
            }
        }
    }
    r
}

fn centroid(pts: &[Vec3]) -> Vec3 {
    let mut c = [0.0; 3];
    for p in pts {
        c[0] += p[0];
        c[1] += p[1];
        c[2] += p[2];
    }
    let n = pts.len() as f64;
    [c[0] / n, c[1] / n, c[2] / n]
}

fn dot3(a: &Vec3, b: &Vec3) -> f64 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}

fn col(m: &Mat3, j: usize) -> Vec3 {
    [m[0][j], m[1][j], m[2][j]]
}

#[must_use]
pub fn det(m: Mat3) -> f64 {
    m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
        - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
        + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])
}

#[cfg(test)]
mod tests {
    use super::*;

    fn transpose(m: Mat3) -> Mat3 {
        let mut r = [[0.0; 3]; 3];
        for i in 0..3 {
            for j in 0..3 {
                r[i][j] = m[j][i];
            }
        }
        r
    }

    fn mat_mul(a: Mat3, b: Mat3) -> Mat3 {
        let mut r = [[0.0; 3]; 3];
        for i in 0..3 {
            for j in 0..3 {
                for k in 0..3 {
                    r[i][j] += a[i][k] * b[k][j];
                }
            }
        }
        r
    }

    fn rotate_z(p: Vec3, deg: f64) -> Vec3 {
        let r = deg.to_radians();
        [
            p[0] * r.cos() - p[1] * r.sin(),
            p[0] * r.sin() + p[1] * r.cos(),
            p[2],
        ]
    }

    #[test]
    fn identity_for_identical_clouds() {
        let pts = [
            [1.2, 3.4, 5.6],
            [2.0, -1.0, 0.5],
            [-3.3, 4.4, 1.1],
            [0.0, 0.0, 9.9],
        ];
        let s = superpose(&pts, &pts);
        assert!(s.rms < 1e-9, "rms {}", s.rms);
        assert!((det(s.rot) - 1.0).abs() < 1e-9);
        for p in &pts {
            let t = apply(&s.rot, &s.tran, p);
            for k in 0..3 {
                assert!((t[k] - p[k]).abs() < 1e-9);
            }
        }
    }

    #[test]
    fn recovers_known_rotation_and_translation() {
        // ref = mov rotated 37° about z, then shifted. `superpose` must recover a
        // rotation+translation mapping mov back onto ref (right-multiply).
        let mov = [
            [0.0, 0.0, 0.0],
            [1.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
            [0.0, 0.0, 1.0],
            [1.0, 2.0, 3.0],
        ];
        let shift = [5.0, -3.0, 1.0];
        let reference: Vec<Vec3> = mov
            .iter()
            .map(|&p| {
                let r = rotate_z(p, 37.0);
                [r[0] + shift[0], r[1] + shift[1], r[2] + shift[2]]
            })
            .collect();
        let s = superpose(&reference, &mov);
        assert!(s.rms < 1e-9, "rms {}", s.rms);
        assert!((det(s.rot) - 1.0).abs() < 1e-9, "det {}", det(s.rot));
        for (m, r) in mov.iter().zip(&reference) {
            let t = apply(&s.rot, &s.tran, m);
            for k in 0..3 {
                assert!((t[k] - r[k]).abs() < 1e-8, "axis {k}");
            }
        }
    }

    #[test]
    fn reflection_fix_yields_proper_rotation() {
        // A point set whose naive cross-covariance SVD would prefer an improper
        // (reflecting) "rotation"; the det check must force a proper rotation.
        // mov is planar-ish in z so the optimal map is genuinely degenerate-prone.
        let mov = [
            [1.0, 0.0, 0.0],
            [-1.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
            [0.0, -1.0, 0.0],
            [0.0, 0.0, 0.01],
        ];
        // reference is mov reflected through the xy-plane (z -> -z) — a pure
        // reflection, det = -1. The least-squares proper rotation must NOT be the
        // reflection; det(rot) must be +1.
        let reference: Vec<Vec3> = mov.iter().map(|&p| [p[0], p[1], -p[2]]).collect();
        let s = superpose(&reference, &mov);
        assert!((det(s.rot) - 1.0).abs() < 1e-9, "det {}", det(s.rot));
    }

    #[test]
    fn rot_is_orthonormal() {
        let mov = [
            [3.1, 0.2, -1.0],
            [0.0, 4.4, 2.2],
            [-2.0, 1.0, 5.0],
            [1.5, -3.0, 0.5],
            [0.7, 0.7, 0.7],
        ];
        let reference: Vec<Vec3> = mov.iter().map(|&p| rotate_z(p, 73.0)).collect();
        let s = superpose(&reference, &mov);
        // rotᵀ·rot = I
        let rt = transpose(s.rot);
        let prod = mat_mul(rt, s.rot);
        for (i, row) in prod.iter().enumerate() {
            for (j, &v) in row.iter().enumerate() {
                let want = if i == j { 1.0 } else { 0.0 };
                assert!((v - want).abs() < 1e-9, "({i},{j})");
            }
        }
    }
}
