//! Kabsch least-squares superposition of two index-paired atom sets from PDB.
//!
//! Value-exact reimplementation of `Bio.PDB.Superimposer` (BSD): the
//! correspondence between the two atom sets is *given* (no alignment search),
//! which is what makes the rotation/translation/RMSD reproducible to numerical
//! precision. See `superpose.rs` for the matched matrix convention.

pub mod cli;
pub mod pdb;
pub mod superpose;

use serde::Serialize;

use rsomics_common::{Result, RsomicsError};

pub use superpose::{Mat3, Vec3};

/// How the paired atom sets are selected from the two PDBs.
pub enum Selection {
    /// Cα atoms of each structure in file order; the two Cα traces must be equal
    /// length, paired position-for-position.
    Ca,
    /// Explicit `(ref_index, mov_index)` pairs into the full ordered ATOM lists.
    Pairs(Vec<(usize, usize)>),
}

/// Rotation (right-multiplying), translation and RMSD, matching biopython's
/// `Superimposer().rotran` + `.rms`.
#[derive(Serialize)]
pub struct SuperposeResult {
    /// Right-multiplying rotation: `transformed = dot(mov, rotation) + translation`.
    pub rotation: Mat3,
    pub translation: Vec3,
    pub rmsd: f64,
    pub n_atoms: usize,
}

/// Compute the superposition of `mov` onto `reference` under `selection`.
#[allow(clippy::missing_errors_doc)]
pub fn superpose_atoms(
    reference: &[pdb::Atom],
    mov: &[pdb::Atom],
    selection: &Selection,
) -> Result<SuperposeResult> {
    let (ref_pts, mov_pts) = match selection {
        Selection::Ca => {
            let r = pdb::ca_coords(reference);
            let m = pdb::ca_coords(mov);
            if r.len() != m.len() {
                return Err(RsomicsError::InvalidInput(format!(
                    "Cα count mismatch: ref has {}, mov has {} — the pairing must be 1:1 \
                     (use --pairs for an explicit correspondence)",
                    r.len(),
                    m.len()
                )));
            }
            (r, m)
        }
        Selection::Pairs(pairs) => {
            let mut r = Vec::with_capacity(pairs.len());
            let mut m = Vec::with_capacity(pairs.len());
            for &(ri, mi) in pairs {
                let ra = reference.get(ri).ok_or_else(|| {
                    RsomicsError::InvalidInput(format!(
                        "ref atom index {ri} out of range (0..{})",
                        reference.len()
                    ))
                })?;
                let ma = mov.get(mi).ok_or_else(|| {
                    RsomicsError::InvalidInput(format!(
                        "mov atom index {mi} out of range (0..{})",
                        mov.len()
                    ))
                })?;
                r.push(ra.coord);
                m.push(ma.coord);
            }
            (r, m)
        }
    };

    if ref_pts.len() < 3 {
        return Err(RsomicsError::InvalidInput(format!(
            "need at least 3 paired atoms for a well-defined superposition, got {}",
            ref_pts.len()
        )));
    }

    let s = superpose::superpose(&ref_pts, &mov_pts);
    Ok(SuperposeResult {
        rotation: s.rot,
        translation: s.tran,
        rmsd: s.rms,
        n_atoms: ref_pts.len(),
    })
}

/// Parse an index-pair TSV: two whitespace/tab-separated integer columns
/// `ref_idx<TAB>mov_idx` per line, `#`-comment and blank lines ignored.
#[allow(clippy::missing_errors_doc)]
pub fn parse_pairs(text: &str) -> Result<Vec<(usize, usize)>> {
    let mut pairs = Vec::new();
    for (lineno, line) in text.lines().enumerate() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let mut it = line.split_whitespace();
        let bad = || {
            RsomicsError::InvalidInput(format!(
                "line {}: expected two integer columns 'ref_idx mov_idx', got {line:?}",
                lineno + 1
            ))
        };
        let ri: usize = it.next().ok_or_else(bad)?.parse().map_err(|_| bad())?;
        let mi: usize = it.next().ok_or_else(bad)?.parse().map_err(|_| bad())?;
        if it.next().is_some() {
            return Err(bad());
        }
        pairs.push((ri, mi));
    }
    if pairs.is_empty() {
        return Err(RsomicsError::InvalidInput(
            "no pairs in --pairs file".into(),
        ));
    }
    Ok(pairs)
}
