//! Differential compat against biopython's `Bio.PDB.Superimposer` (SVDSuperimposer).
//!
//! The committed goldens (`tests/golden/{main,refl}.golden.tsv`) were captured
//! from biopython 1.87 — they hold the rotation (right-multiplying), translation
//! and RMSD biopython reports for the two committed PDB pairs. `golden_*` always
//! run (no biopython needed); `live_oracle_biopython` re-derives the goldens
//! from the live SVDSuperimposer when it is importable (loud-skip otherwise).
//!
//! The reflection-prone pair (`refl_*`) exercises the det-sign fix: its optimal
//! map would be improper without negating the third right singular vector, so a
//! correct det check is required to match biopython's proper-rotation answer.

use std::path::{Path, PathBuf};
use std::process::Command;

use rsomics_pdb_superpose::{Selection, SuperposeResult, pdb, superpose_atoms};

/// biopython runs SVD in numpy double precision; our 3×3 Jacobi eigen route
/// reaches the same minimiser to well within this. Recorded max abs diff is far
/// below it (see the eprintln summary).
const TOL: f64 = 1e-9;

fn golden(rel: &str) -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("tests/golden")
        .join(rel)
}

struct Golden {
    rot: [[f64; 3]; 3],
    tran: [f64; 3],
    rms: f64,
    n: usize,
}

fn parse_golden(text: &str) -> Golden {
    let mut rot = [[0.0; 3]; 3];
    let mut tran = [0.0; 3];
    let mut rms = f64::NAN;
    let mut n = 0;
    for line in text.lines() {
        if line.starts_with('#') || line.trim().is_empty() {
            continue;
        }
        let f: Vec<&str> = line.split('\t').collect();
        match f[0] {
            "n_atoms" => n = f[1].parse().unwrap(),
            "rms" => rms = f[1].parse().unwrap(),
            "rot" => {
                let i: usize = f[1].parse().unwrap();
                rot[i] = [
                    f[2].parse().unwrap(),
                    f[3].parse().unwrap(),
                    f[4].parse().unwrap(),
                ];
            }
            "tran" => {
                tran = [
                    f[1].parse().unwrap(),
                    f[2].parse().unwrap(),
                    f[3].parse().unwrap(),
                ];
            }
            other => panic!("unknown golden row {other:?}"),
        }
    }
    Golden { rot, tran, rms, n }
}

fn ours(ref_pdb: &Path, mov_pdb: &Path) -> SuperposeResult {
    let r = pdb::parse(&std::fs::read_to_string(ref_pdb).unwrap()).unwrap();
    let m = pdb::parse(&std::fs::read_to_string(mov_pdb).unwrap()).unwrap();
    superpose_atoms(&r, &m, &Selection::Ca).unwrap()
}

struct Diff {
    rot: f64,
    tran: f64,
    rms: f64,
}

fn compare(g: &Golden, r: &SuperposeResult) -> Diff {
    assert_eq!(g.n, r.n_atoms, "atom count mismatch");
    let mut drot = 0.0_f64;
    for i in 0..3 {
        for j in 0..3 {
            drot = drot.max((g.rot[i][j] - r.rotation[i][j]).abs());
        }
    }
    let mut dtran = 0.0_f64;
    for k in 0..3 {
        dtran = dtran.max((g.tran[k] - r.translation[k]).abs());
    }
    Diff {
        rot: drot,
        tran: dtran,
        rms: (g.rms - r.rmsd).abs(),
    }
}

fn check(name: &str, ref_pdb: &str, mov_pdb: &str, golden_tsv: &str) {
    let g = parse_golden(&std::fs::read_to_string(golden(golden_tsv)).unwrap());
    // The golden rotation must be a proper rotation (the reflection fix worked).
    let det = rsomics_pdb_superpose::superpose::det(g.rot);
    assert!((det - 1.0).abs() < 1e-6, "{name}: golden det {det} not +1");

    let r = ours(&golden(ref_pdb), &golden(mov_pdb));
    let det_ours = rsomics_pdb_superpose::superpose::det(r.rotation);
    assert!(
        (det_ours - 1.0).abs() < 1e-6,
        "{name}: ours det {det_ours} not +1"
    );

    let d = compare(&g, &r);
    eprintln!(
        "{name}: max|Δrot|={:.3e} max|Δtran|={:.3e} |Δrms|={:.3e}",
        d.rot, d.tran, d.rms
    );
    assert!(d.rot < TOL, "{name}: |Δrot| {} >= {TOL}", d.rot);
    assert!(d.tran < TOL, "{name}: |Δtran| {} >= {TOL}", d.tran);
    assert!(d.rms < TOL, "{name}: |Δrms| {} >= {TOL}", d.rms);
}

#[test]
fn golden_main() {
    check("main", "ref.pdb", "mov.pdb", "main.golden.tsv");
}

#[test]
fn golden_reflection_fix() {
    check("refl", "refl_ref.pdb", "refl_mov.pdb", "refl.golden.tsv");
}

const ORACLE_PY: &str = r#"
import sys
import numpy as np
from Bio.SVDSuperimposer import SVDSuperimposer

# Parse CA coordinates straight from the PDB columns as float64, matching our
# Rust parser exactly. Bio.PDB's Atom.get_coord() returns float32, which would
# inject a ~3e-7 coordinate-truncation difference unrelated to the algorithm;
# the Superimposer math itself runs in float64, so feeding float64 coordinates
# isolates the value-exactness of the superposition.
def ca(path):
    out = []
    for line in open(path):
        if line.startswith("ATOM") and line[12:16].strip() == "CA":
            out.append([float(line[30:38]), float(line[38:46]), float(line[46:54])])
    return np.array(out, dtype="d")

ra = ca(sys.argv[1])
ma = ca(sys.argv[2])
sup = SVDSuperimposer()
sup.set(ra, ma)
sup.run()
rot, tran = sup.get_rotran()
print("n_atoms\t%d" % len(ra))
print("rms\t%.12e" % sup.get_rms())
for i in range(3):
    print("rot\t%d\t%.15e\t%.15e\t%.15e" % (i, rot[i][0], rot[i][1], rot[i][2]))
print("tran\t%.15e\t%.15e\t%.15e" % (tran[0], tran[1], tran[2]))
"#;

fn which_biopython() -> Option<String> {
    for py in [
        "/opt/homebrew/Caskroom/miniforge/base/envs/rs-up/bin/python",
        "python3",
        "python",
    ] {
        let ok = Command::new(py)
            .args(["-c", "import Bio.SVDSuperimposer"])
            .output()
            .map(|o| o.status.success())
            .unwrap_or(false);
        if ok {
            return Some(py.to_string());
        }
    }
    None
}

#[test]
fn live_oracle_biopython() {
    let Some(py) = which_biopython() else {
        eprintln!("SKIP live_oracle_biopython: no biopython on PATH");
        return;
    };
    let scratch = std::env::temp_dir().join("rsomics-pdb-superpose-compat");
    std::fs::create_dir_all(&scratch).unwrap();
    let script = scratch.join("oracle.py");
    std::fs::write(&script, ORACLE_PY).unwrap();

    for (ref_pdb, mov_pdb) in [("ref.pdb", "mov.pdb"), ("refl_ref.pdb", "refl_mov.pdb")] {
        let out = Command::new(&py)
            .arg(&script)
            .arg(golden(ref_pdb))
            .arg(golden(mov_pdb))
            .output()
            .unwrap();
        assert!(
            out.status.success(),
            "oracle failed: {}",
            String::from_utf8_lossy(&out.stderr)
        );
        let g = parse_golden(&String::from_utf8(out.stdout).unwrap());
        let r = ours(&golden(ref_pdb), &golden(mov_pdb));
        let d = compare(&g, &r);
        eprintln!(
            "live {ref_pdb}->{mov_pdb}: max|Δrot|={:.3e} max|Δtran|={:.3e} |Δrms|={:.3e}",
            d.rot, d.tran, d.rms
        );
        assert!(d.rot < TOL && d.tran < TOL && d.rms < TOL, "live diverged");
    }
}
