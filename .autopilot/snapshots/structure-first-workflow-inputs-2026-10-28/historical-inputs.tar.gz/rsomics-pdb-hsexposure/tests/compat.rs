use std::path::{Path, PathBuf};
use std::process::Command;

fn golden(name: &str) -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("tests/golden")
        .join(name)
}

fn run_ours(pdb: &Path, radius: &str) -> String {
    let out = Command::new(env!("CARGO_BIN_EXE_rsomics-pdb-hsexposure"))
        .arg(pdb)
        .arg("--radius")
        .arg(radius)
        .output()
        .expect("run rsomics-pdb-hsexposure");
    assert!(out.status.success(), "binary failed: {:?}", out.status);
    String::from_utf8(out.stdout).expect("utf8 stdout")
}

fn check_against_golden(pdb: &str, radius: &str, expected: &str) {
    let got = run_ours(&golden(pdb), radius);
    let want = std::fs::read_to_string(golden(expected)).expect("read golden");
    assert_eq!(
        got, want,
        "{pdb} @ r{radius} diverged from committed biopython golden"
    );
}

#[test]
fn crn_r12_matches_golden() {
    check_against_golden("1crn.pdb", "12", "1crn.r12.expected.tsv");
}

#[test]
fn crn_r13_matches_golden() {
    check_against_golden("1crn.pdb", "13", "1crn.r13.expected.tsv");
}

#[test]
fn hhb_multichain_r13_matches_golden() {
    check_against_golden("4hhb.pdb", "13", "4hhb.r13.expected.tsv");
}

// altloc.pdb carries two multi-conformer atoms whose higher-occupancy
// alternate sits on a non-'A' label: res6 CA (A occ 0.30 / B occ 0.70) and
// res8 CB (A occ 0.40 / B occ 0.60). Selecting the B conformer (biopython's
// DisorderedAtom default) shifts CA neighbour geometry, so CN and HSE up/down
// change vs the discarded 'A' conformer. The goldens are HSExposure over
// biopython's selection; picking 'A' would give CN 11/6 on res6/res12 instead
// of 10/5 and flip several HSE splits.
#[test]
fn altloc_highest_occupancy_r10_matches_golden() {
    check_against_golden("altloc.pdb", "10", "altloc.r10.expected.tsv");
}

#[test]
fn altloc_highest_occupancy_r13_matches_golden() {
    check_against_golden("altloc.pdb", "13", "altloc.r13.expected.tsv");
}

const ORACLE: &str = r#"
import sys, warnings
warnings.simplefilter("ignore")
from Bio.PDB import PDBParser
from Bio.PDB.HSExposure import HSExposureCA, HSExposureCB, ExposureCN
pdb = sys.argv[1]; radius = float(sys.argv[2])
model = PDBParser(QUIET=True).get_structure("x", pdb)[0]
HSExposureCA(model, radius=radius); HSExposureCB(model, radius=radius); ExposureCN(model, radius=radius)
print("chain\tresseq\tresname\tHSEa_up\tHSEa_down\tHSEb_up\tHSEb_down\tCN")
def f(v): return "." if v is None else str(v)
for r in model.get_residues():
    x = r.xtra
    if x.get("EXP_HSE_A_U") is None and x.get("EXP_HSE_B_U") is None and x.get("EXP_CN") is None:
        continue
    print("\t".join([r.get_parent().get_id(), str(r.get_id()[1]), r.get_resname(),
        f(x.get("EXP_HSE_A_U")), f(x.get("EXP_HSE_A_D")),
        f(x.get("EXP_HSE_B_U")), f(x.get("EXP_HSE_B_D")), f(x.get("EXP_CN"))]))
"#;

fn oracle_python() -> Option<String> {
    if let Ok(p) = std::env::var("HSE_ORACLE_PY") {
        return Some(p);
    }
    for py in ["python3", "python"] {
        let ok = Command::new(py)
            .args(["-c", "import Bio.PDB.HSExposure"])
            .output()
            .map(|o| o.status.success())
            .unwrap_or(false);
        if ok {
            return Some(py.to_string());
        }
    }
    None
}

#[test]
fn live_oracle_differential() {
    let Some(py) = oracle_python() else {
        eprintln!(
            "SKIP live_oracle_differential: no python with Bio.PDB.HSExposure (set HSE_ORACLE_PY)"
        );
        return;
    };
    let script = std::env::temp_dir().join("rsomics_hse_oracle.py");
    std::fs::write(&script, ORACLE).expect("write oracle script");

    for (pdb, radius) in [
        ("1crn.pdb", "13"),
        ("4hhb.pdb", "13"),
        ("1crn.pdb", "10"),
        ("altloc.pdb", "10"),
        ("altloc.pdb", "13"),
    ] {
        let out = Command::new(&py)
            .arg(&script)
            .arg(golden(pdb))
            .arg(radius)
            .output()
            .expect("run oracle");
        assert!(
            out.status.success(),
            "oracle failed on {pdb}: {}",
            String::from_utf8_lossy(&out.stderr)
        );
        let upstream = String::from_utf8(out.stdout).expect("utf8");
        let ours = run_ours(&golden(pdb), radius);
        assert_eq!(
            ours, upstream,
            "{pdb} @ r{radius} diverged from live biopython"
        );
    }
}
