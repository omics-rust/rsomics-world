# rsomics-pdb-hsexposure

Per-residue **half-sphere exposure** (HSE-α and HSE-β) and **Cα contact
number** (CN) from a PDB file. A fast, single-binary Rust reimplementation of
biopython's `Bio.PDB.HSExposure`.

Half-sphere exposure (Hamelryck 2005) is a two-dimensional measure of residue
solvent exposure: instead of one neighbour count, the Cα neighbours within a
radius are split into an *upper* and a *lower* half-sphere relative to the
side-chain direction. HSE-β uses the real Cα→Cβ direction (glycine gets a
reconstructed pseudo-Cβ); HSE-α uses the bisector of the two flanking Cα→Cα
vectors. CN is the plain neighbour count (`ExposureCN`).

## Usage

```
rsomics-pdb-hsexposure <PDB> [--radius 13] [--measure ca|cb|cn|all]
```

Output is TSV on stdout:

```
chain	resseq	resname	HSEa_up	HSEa_down	HSEb_up	HSEb_down	CN
A	1	THR	.	.	11	12	23
A	2	THR	22	14	20	16	36
```

`.` marks an undefined value: HSE-α is undefined for the first and last
residue of every peptide (no flanking Cα), and a measure not selected by
`--measure` is left as `.`.

`--radius` is the sphere radius in Ångström (default 13). `--measure` selects
which columns are computed (`all` by default).

## Origin

This crate is an independent Rust reimplementation of the half-sphere
exposure measures in `Bio.PDB.HSExposure`, based on:

- Hamelryck, T. (2005). *An amino acid has two sides: A new 2D measure
  provides a different view of solvent exposure.* Proteins 59(1):38–48.
  DOI: [10.1002/prot.20379](https://doi.org/10.1002/prot.20379)
- The PDB coordinate file-format spec.
- The biopython `Bio.PDB.HSExposure` / `Bio.PDB.Polypeptide` source
  (BSD-3-Clause — readable and cited): peptide construction via Cα–Cα
  distance (`CaPPBuilder`, 4.3 Å), the glycine pseudo-Cβ rotation, and the
  exact half-sphere boundary (`angle < π/2`, distance `< radius`).
- Black-box differential testing against biopython 1.87
  (`HSExposureCA`/`HSExposureCB`/`ExposureCN`) — value-exact integer counts.

Test fixtures are public RCSB structures (1CRN, 4HHB, 1AON).

License: MIT OR Apache-2.0.
Upstream credit: biopython <https://biopython.org/> (BSD-3-Clause).
