use std::collections::HashMap;
use std::path::Path;

use rsomics_common::Result;
use rsomics_pdb_core::{AltLocPolicy, ParseOptions, ResidueFilter, select_altloc};

pub type Vec3 = [f64; 3];

/// One residue's backbone/Cb atoms, as needed for HSE.
#[derive(Debug, Clone)]
pub struct Residue {
    pub chain: char,
    pub resseq: i32,
    pub icode: char,
    pub resname: String,
    pub n: Option<Vec3>,
    pub ca: Option<Vec3>,
    pub c: Option<Vec3>,
    pub cb: Option<Vec3>,
}

/// Parse ATOM/HETATM records into per-residue atom positions, keeping the
/// first model only. For an atom with alternate locations, the highest-occupancy
/// alternate is selected (biopython's default DisorderedAtom selection), so the
/// same coordinate biopython feeds to HSExposure enters the neighbour geometry.
pub fn parse_pdb(path: &Path) -> Result<Vec<Residue>> {
    let text = std::fs::read_to_string(path)?;
    parse_pdb_str(&text)
}

pub fn parse_pdb_str(text: &str) -> Result<Vec<Residue>> {
    let opts = ParseOptions {
        include_hetatm: true,
        include_hydrogen: true,
        residue_filter: ResidueFilter::All,
    };
    let atoms = select_altloc(
        rsomics_pdb_core::parse(text, &opts)?,
        AltLocPolicy::HighestOccupancy,
    );

    let mut order: Vec<(char, i32, char)> = Vec::new();
    let mut by_key: HashMap<(char, i32, char), Residue> = HashMap::new();

    for a in atoms {
        let slot: Option<&'static str> = match a.name.as_str() {
            "N" => Some("N"),
            "CA" => Some("CA"),
            "C" => Some("C"),
            "CB" => Some("CB"),
            _ => None,
        };
        let Some(slot) = slot else { continue };

        let key = (a.chain, a.resseq, a.icode);
        let res = by_key.entry(key).or_insert_with(|| {
            order.push(key);
            Residue {
                chain: a.chain,
                resseq: a.resseq,
                icode: a.icode,
                resname: a.resname.clone(),
                n: None,
                ca: None,
                c: None,
                cb: None,
            }
        });

        match slot {
            "N" => res.n = Some(a.coord),
            "CA" => res.ca = Some(a.coord),
            "C" => res.c = Some(a.coord),
            "CB" => res.cb = Some(a.coord),
            _ => unreachable!(),
        }
    }

    Ok(order
        .into_iter()
        .map(|k| by_key.remove(&k).unwrap())
        .collect())
}

pub fn is_standard_aa(resname: &str) -> bool {
    matches!(
        resname,
        "ALA"
            | "ARG"
            | "ASN"
            | "ASP"
            | "CYS"
            | "GLN"
            | "GLU"
            | "GLY"
            | "HIS"
            | "ILE"
            | "LEU"
            | "LYS"
            | "MET"
            | "PHE"
            | "PRO"
            | "SER"
            | "THR"
            | "TRP"
            | "TYR"
            | "VAL"
    )
}

/// Split residues into peptides the way CaPPBuilder does: per chain, maximal
/// runs of consecutive standard amino acids whose Ca-Ca distance is below
/// 4.3 A. A residue starts a new peptide only when it bonds to the next.
pub fn build_peptides(residues: &[Residue]) -> Vec<Vec<usize>> {
    let connected = 4.3 * 4.3;
    let accept = |r: &Residue| is_standard_aa(&r.resname) && r.ca.is_some();
    let bonded =
        |a: usize, b: usize| dist2(&residues[a].ca.unwrap(), &residues[b].ca.unwrap()) < connected;

    let mut peptides: Vec<Vec<usize>> = Vec::new();
    let mut chains: HashMap<char, Vec<usize>> = HashMap::new();
    let mut chain_order: Vec<char> = Vec::new();
    for (i, r) in residues.iter().enumerate() {
        chains.entry(r.chain).or_insert_with(|| {
            chain_order.push(r.chain);
            Vec::new()
        });
        chains.get_mut(&r.chain).unwrap().push(i);
    }

    for ch in chain_order {
        let idx = &chains[&ch];
        let mut it = idx.iter().copied();
        let Some(mut prev) = it.by_ref().find(|&i| accept(&residues[i])) else {
            continue;
        };
        let mut current: Vec<usize> = Vec::new();
        for next in it {
            if accept(&residues[prev]) && accept(&residues[next]) && bonded(prev, next) {
                if current.is_empty() {
                    current.push(prev);
                }
                current.push(next);
            } else if !current.is_empty() {
                peptides.push(std::mem::take(&mut current));
            }
            prev = next;
        }
        if !current.is_empty() {
            peptides.push(current);
        }
    }
    peptides
}

#[inline]
pub fn sub(a: &Vec3, b: &Vec3) -> Vec3 {
    [a[0] - b[0], a[1] - b[1], a[2] - b[2]]
}

#[inline]
pub fn add(a: &Vec3, b: &Vec3) -> Vec3 {
    [a[0] + b[0], a[1] + b[1], a[2] + b[2]]
}

#[inline]
pub fn dot(a: &Vec3, b: &Vec3) -> f64 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}

#[inline]
pub fn norm(a: &Vec3) -> f64 {
    dot(a, a).sqrt()
}

#[inline]
pub fn dist2(a: &Vec3, b: &Vec3) -> f64 {
    let d = sub(a, b);
    dot(&d, &d)
}
