use std::f64::consts::PI;

use crate::pdb::{Residue, Vec3, add, build_peptides, dot, norm, sub};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Measure {
    Ca,
    Cb,
    Cn,
    All,
}

#[derive(Debug, Clone)]
pub struct Exposure {
    pub chain: char,
    pub resseq: i32,
    pub icode: char,
    pub resname: String,
    pub hse_a_up: Option<i64>,
    pub hse_a_down: Option<i64>,
    pub hse_b_up: Option<i64>,
    pub hse_b_down: Option<i64>,
    pub cn: Option<i64>,
}

/// Per-residue half-sphere exposure and Ca contact number.
///
/// Reimplements Bio.PDB.HSExposure (Hamelryck 2005). HSE-beta splits Ca
/// neighbours within `radius` by the Ca->Cb direction; HSE-alpha uses the
/// bisector of the two flanking Ca atoms; CN is the raw neighbour count.
pub fn hsexposure(residues: &[Residue], radius: f64, measure: Measure) -> Vec<Exposure> {
    let peptides = build_peptides(residues);
    let r2 = radius * radius;

    let want_a = matches!(measure, Measure::Ca | Measure::All);
    let want_b = matches!(measure, Measure::Cb | Measure::All);
    let want_cn = matches!(measure, Measure::Cn | Measure::All);

    let mut out: Vec<Exposure> = Vec::new();

    for (pi, pp) in peptides.iter().enumerate() {
        for (i, &ri) in pp.iter().enumerate() {
            let r = &residues[ri];
            let Some(ca) = r.ca else { continue };

            let mut row = Exposure {
                chain: r.chain,
                resseq: r.resseq,
                icode: r.icode,
                resname: r.resname.clone(),
                hse_a_up: None,
                hse_a_down: None,
                hse_b_up: None,
                hse_b_down: None,
                cn: None,
            };

            let pcb_b = if want_b { cb_vector(r) } else { None };
            let pcb_a = if want_a {
                ca_pseudo_cb(residues, pp, i)
            } else {
                None
            };

            if want_cn || pcb_b.is_some() || pcb_a.is_some() {
                let (mut bu, mut bd) = (0i64, 0i64);
                let (mut au, mut ad) = (0i64, 0i64);
                let mut cn = 0i64;

                for (pj, pp2) in peptides.iter().enumerate() {
                    for (j, &rj) in pp2.iter().enumerate() {
                        if pi == pj && i == j {
                            continue;
                        }
                        let Some(cao) = residues[rj].ca else { continue };
                        let d = sub(&cao, &ca);
                        if dot(&d, &d) < r2 {
                            cn += 1;
                            if let Some(p) = &pcb_b {
                                if angle_lt_90(&d, p) {
                                    bu += 1;
                                } else {
                                    bd += 1;
                                }
                            }
                            if let Some(p) = &pcb_a {
                                if angle_lt_90(&d, p) {
                                    au += 1;
                                } else {
                                    ad += 1;
                                }
                            }
                        }
                    }
                }

                if want_cn {
                    row.cn = Some(cn);
                }
                if pcb_b.is_some() {
                    row.hse_b_up = Some(bu);
                    row.hse_b_down = Some(bd);
                }
                if pcb_a.is_some() {
                    row.hse_a_up = Some(au);
                    row.hse_a_down = Some(ad);
                }
            }

            out.push(row);
        }
    }

    out
}

/// Ca->Cb direction. Glycine has no Cb, so reconstruct a pseudo-Cb from the
/// backbone (N rotated -120 deg about the Ca->C axis).
fn cb_vector(r: &Residue) -> Option<Vec3> {
    if r.resname == "GLY" {
        return gly_pseudo_cb(r);
    }
    let (cb, ca) = (r.cb?, r.ca?);
    Some(sub(&cb, &ca))
}

/// Bisector of the two flanking Ca->Ca directions, the HSE-alpha pseudo-Cb.
/// Undefined (None) for the first and last residue of a peptide.
fn ca_pseudo_cb(residues: &[Residue], pp: &[usize], i: usize) -> Option<Vec3> {
    if i == 0 || i == pp.len() - 1 {
        return None;
    }
    let ca1 = residues[pp[i - 1]].ca?;
    let ca2 = residues[pp[i]].ca?;
    let ca3 = residues[pp[i + 1]].ca?;
    let d1 = normalize(&sub(&ca2, &ca1))?;
    let d3 = normalize(&sub(&ca2, &ca3))?;
    normalize(&add(&d1, &d3))
}

/// Pseudo-Cb for glycine: N centred at Ca, rotated by -120 deg about the
/// Ca->C axis (Rodrigues). Returned centred at the origin.
fn gly_pseudo_cb(r: &Residue) -> Option<Vec3> {
    let (n, ca, c) = (r.n?, r.ca?, r.c?);
    let n0 = sub(&n, &ca);
    let axis = sub(&c, &ca);
    let rot = rotaxis(-PI * 120.0 / 180.0, &axis);
    Some(left_multiply(&rot, &n0))
}

#[inline]
fn angle_lt_90(d: &Vec3, pcb: &Vec3) -> bool {
    let dn = norm(d);
    let pn = norm(pcb);
    if dn == 0.0 || pn == 0.0 {
        return false;
    }
    let mut cos = dot(d, pcb) / (dn * pn);
    cos = cos.clamp(-1.0, 1.0);
    cos.acos() < PI / 2.0
}

#[inline]
fn normalize(v: &Vec3) -> Option<Vec3> {
    let n = norm(v);
    if n == 0.0 {
        return None;
    }
    Some([v[0] / n, v[1] / n, v[2] / n])
}

type Mat3 = [[f64; 3]; 3];

fn rotaxis(theta: f64, axis: &Vec3) -> Mat3 {
    let v = normalize(axis).unwrap_or([0.0, 0.0, 0.0]);
    let (c, s) = (theta.cos(), theta.sin());
    let t = 1.0 - c;
    let [x, y, z] = v;
    [
        [t * x * x + c, t * x * y - s * z, t * x * z + s * y],
        [t * x * y + s * z, t * y * y + c, t * y * z - s * x],
        [t * x * z - s * y, t * y * z + s * x, t * z * z + c],
    ]
}

#[inline]
fn left_multiply(m: &Mat3, v: &Vec3) -> Vec3 {
    [
        m[0][0] * v[0] + m[0][1] * v[1] + m[0][2] * v[2],
        m[1][0] * v[0] + m[1][1] * v[1] + m[1][2] * v[2],
        m[2][0] * v[0] + m[2][1] * v[1] + m[2][2] * v[2],
    ]
}
