use std::process::ExitCode;

use clap::Parser;
use rsomics_common::Tool;
use rsomics_help::{Example, FlagSpec, HelpSpec, Origin, Section};
use rsomics_pdb_hsexposure::cli::Cli;

const HELP: HelpSpec = HelpSpec {
    name: env!("CARGO_PKG_NAME"),
    version: env!("CARGO_PKG_VERSION"),
    tagline: "Half-sphere exposure (HSE-a, HSE-b) and Ca contact number per residue",
    origin: Some(Origin {
        upstream: "Bio.PDB.HSExposure (biopython)",
        upstream_license: "BSD-3-Clause",
        our_license: "MIT OR Apache-2.0",
        paper_doi: Some("10.1002/prot.20379"),
    }),
    usage_lines: &["<PDB> [--radius <A>] [--measure ca|cb|cn|all]"],
    sections: &[Section {
        title: "OPTIONS",
        flags: &[
            FlagSpec {
                short: None,
                long: "radius",
                aliases: &[],
                value: Some("ANGSTROM"),
                type_hint: Some("float"),
                required: false,
                default: Some("13"),
                description: "Sphere radius for the Ca neighbour count",
                why_default: None,
            },
            FlagSpec {
                short: None,
                long: "measure",
                aliases: &[],
                value: Some("ca|cb|cn|all"),
                type_hint: None,
                required: false,
                default: Some("all"),
                description: "Which exposure measures to compute",
                why_default: None,
            },
        ],
    }],
    examples: &[Example {
        description: "HSE-beta + HSE-alpha + CN for every residue",
        command: "rsomics-pdb-hsexposure 1crn.pdb",
    }],
    json_result_schema_doc: None,
};

fn main() -> ExitCode {
    let args: Vec<String> = std::env::args().collect();
    if let Some(mode) = rsomics_help::intercept_help(&args) {
        rsomics_help::render(&HELP, mode);
        return ExitCode::SUCCESS;
    }
    Cli::parse().run()
}
