use std::io::{BufWriter, Write};
use std::path::PathBuf;

use clap::{Parser, ValueEnum};
use rsomics_common::{CommonFlags, Result, RsomicsError, Tool, ToolMeta};

use crate::hse::{Measure, hsexposure};
use crate::pdb::parse_pdb;

#[derive(Debug, Clone, Copy, PartialEq, Eq, ValueEnum)]
pub enum MeasureArg {
    Ca,
    Cb,
    Cn,
    All,
}

impl From<MeasureArg> for Measure {
    fn from(m: MeasureArg) -> Self {
        match m {
            MeasureArg::Ca => Measure::Ca,
            MeasureArg::Cb => Measure::Cb,
            MeasureArg::Cn => Measure::Cn,
            MeasureArg::All => Measure::All,
        }
    }
}

#[derive(Parser, Debug)]
#[command(name = "rsomics-pdb-hsexposure", disable_help_flag = true)]
pub struct Cli {
    /// Input PDB file.
    pub pdb: PathBuf,

    #[arg(long, default_value_t = 13.0)]
    pub radius: f64,

    #[arg(long, value_enum, default_value_t = MeasureArg::All)]
    pub measure: MeasureArg,

    #[command(flatten)]
    pub common: CommonFlags,
}

impl Tool for Cli {
    fn meta() -> ToolMeta {
        ToolMeta {
            name: env!("CARGO_PKG_NAME"),
            version: env!("CARGO_PKG_VERSION"),
        }
    }

    fn common(&self) -> &CommonFlags {
        &self.common
    }

    fn execute(self) -> Result<()> {
        if !self.radius.is_finite() || self.radius <= 0.0 {
            return Err(RsomicsError::InvalidInput(format!(
                "radius must be positive, got {}",
                self.radius
            )));
        }
        let residues = parse_pdb(&self.pdb)?;
        let rows = hsexposure(&residues, self.radius, self.measure.into());

        let stdout = std::io::stdout();
        let mut w = BufWriter::new(stdout.lock());
        writeln!(
            w,
            "chain\tresseq\tresname\tHSEa_up\tHSEa_down\tHSEb_up\tHSEb_down\tCN"
        )?;
        for r in &rows {
            writeln!(
                w,
                "{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}",
                r.chain,
                r.resseq,
                r.resname,
                opt(r.hse_a_up),
                opt(r.hse_a_down),
                opt(r.hse_b_up),
                opt(r.hse_b_down),
                opt(r.cn),
            )?;
        }
        w.flush()?;
        Ok(())
    }
}

fn opt(v: Option<i64>) -> String {
    v.map_or_else(|| ".".to_string(), |n| n.to_string())
}

#[cfg(test)]
mod tests {
    use clap::CommandFactory;

    #[test]
    fn cli_definition_is_valid() {
        super::Cli::command().debug_assert();
    }
}
