use std::collections::{BTreeMap, BTreeSet};
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::atomic::{AtomicUsize, Ordering};

use serde_json::{Value, json};

const GEOMETRY_ABS: f64 = 5e-5;
const GEOMETRY_REL: f64 = 2e-6;
const FIT_ABS: f64 = 1e-10;
const FIT_REL: f64 = 1e-10;
const ANGLE_ABS: f64 = 1e-10;
const ANGLE_REL: f64 = 1e-10;

fn fixture(name: &str) -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("tests/fixtures")
        .join(name)
}

fn call(args: &[&str]) -> std::process::Output {
    let output = Command::new(env!("CARGO_BIN_EXE_rsomics-structure"))
        .args(args)
        .output()
        .unwrap();
    if let Some(root) = std::env::var_os("RSOMICS_STRUCTURE_EVIDENCE") {
        static NEXT: AtomicUsize = AtomicUsize::new(0);
        fs::write(Path::new(&root).join(format!("native-call-{}-{:04}.json", std::process::id(), NEXT.fetch_add(1, Ordering::Relaxed))),
            serde_json::to_vec_pretty(&json!({"args":args,"status":output.status.code(),"stdout":String::from_utf8_lossy(&output.stdout),"stderr":String::from_utf8_lossy(&output.stderr)})).unwrap()).unwrap();
    }
    output
}

fn run(args: &[&str]) -> Value {
    let output = call(args);
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    serde_json::from_slice::<Value>(&output.stdout).unwrap()["result"].clone()
}

fn close(actual: f64, expected: f64, absolute: f64, relative: f64) {
    assert!(
        (actual - expected).abs() <= absolute + relative * expected.abs(),
        "{actual} != {expected}"
    );
}

fn source(name: &str) -> Value {
    let record: Value =
        serde_json::from_slice(&fs::read(fixture(&format!("analysis/{name}.json"))).unwrap())
            .unwrap();
    assert_eq!(record["status"], "returned");
    record["result"].clone()
}

fn text(value: &Value) -> String {
    value
        .as_str()
        .map(str::to_owned)
        .unwrap_or_else(|| value.to_string())
}

fn residue_key(value: &Value) -> String {
    value.as_array().unwrap()[2..]
        .iter()
        .map(text)
        .collect::<Vec<_>>()
        .join("|")
}

fn atom_key(value: &Value) -> String {
    format!(
        "{}|{}|{}|{}",
        residue_key(&value["residue"]),
        text(&value["name"]),
        text(&value["serial"]),
        text(&value["altloc"])
    )
}

fn raw_keys(raw: &Value) -> (Vec<String>, Vec<String>) {
    let mut residues = Vec::new();
    let mut atoms = Vec::new();
    for atom in raw["atoms"].as_array().unwrap() {
        let fields = &atom["fields"];
        let value = |name: &str| fields[name]["value"].as_str().unwrap_or(" ");
        let comp = if fields["label_comp_id"]["state"] == "absent" {
            value("auth_comp_id")
        } else {
            value("label_comp_id")
        };
        let name = if fields["label_atom_id"]["state"] == "absent" {
            value("auth_atom_id")
        } else {
            value("label_atom_id")
        };
        let hetero = if value("group_PDB") == "ATOM" {
            " ".to_owned()
        } else if matches!(comp, "HOH" | "WAT") {
            "W".to_owned()
        } else {
            format!("H_{comp}")
        };
        let sequence = value("auth_seq_id")
            .parse::<i64>()
            .map(|n| n.to_string())
            .unwrap_or_else(|_| value("auth_seq_id").to_owned());
        let key = format!(
            "{}|{}|{}|{}|{}",
            value("auth_asym_id"),
            hetero,
            sequence,
            value("pdbx_PDB_ins_code"),
            comp
        );
        atoms.push(format!(
            "{}|{}|{}|{}",
            key,
            name,
            value("id"),
            value("label_alt_id")
        ));
        residues.push(key);
    }
    (residues, atoms)
}

fn compare_geometry(actual: &Value, reference: &Value) {
    let fields = &reference["filtered_reference_fields"];
    assert_eq!(
        actual["atom_count"].as_u64().unwrap() as usize,
        reference["atoms"].as_array().unwrap().len()
    );
    for (native, source) in [("center_of_mass", "com"), ("centroid", "cen")] {
        for axis in 0..3 {
            close(
                actual[native][axis].as_f64().unwrap(),
                fields[source][axis].as_f64().unwrap(),
                GEOMETRY_ABS,
                GEOMETRY_REL,
            );
        }
    }
    for (native, source) in [
        ("radius_of_gyration", "rg"),
        ("radius_of_gyration_geometric", "rgg"),
    ] {
        close(
            actual[native].as_f64().unwrap(),
            fields[source].as_f64().unwrap(),
            GEOMETRY_ABS,
            GEOMETRY_REL,
        );
    }
    close(
        actual["total_mass"].as_f64().unwrap(),
        fields["total_mass"].as_f64().unwrap(),
        1e-9,
        1e-12,
    );
    for (native, source) in [
        ("bbox_min", "bmin"),
        ("bbox_max", "bmax"),
        ("bbox_dim", "bdim"),
    ] {
        for axis in 0..3 {
            assert_eq!(
                actual[native][axis].as_f64().unwrap() as f32,
                fields[source][axis].as_f64().unwrap() as f32
            );
        }
    }
}

fn compare_contacts(actual: &Value, reference: &Value, keys: &[String]) {
    let selected = actual["source_rows"]
        .as_array()
        .unwrap()
        .iter()
        .map(|r| keys[r.as_u64().unwrap() as usize].clone())
        .collect::<Vec<_>>();
    let expected = reference["selected_atoms"]
        .as_array()
        .unwrap()
        .iter()
        .map(atom_key)
        .collect::<Vec<_>>();
    assert_eq!(selected, expected);
    let canonical = |a: String, b: String| if a < b { (a, b) } else { (b, a) };
    let pairs = actual["pairs"]
        .as_array()
        .unwrap()
        .iter()
        .map(|p| {
            canonical(
                keys[p[0].as_u64().unwrap() as usize].clone(),
                keys[p[1].as_u64().unwrap() as usize].clone(),
            )
        })
        .collect::<BTreeSet<_>>();
    let expected = reference["pairs"]
        .as_array()
        .unwrap()
        .iter()
        .map(|p| canonical(atom_key(&p[0]), atom_key(&p[1])))
        .collect::<BTreeSet<_>>();
    assert_eq!(actual["pairs"].as_array().unwrap().len(), pairs.len());
    assert_eq!(pairs, expected);
}

fn compare_exposure(actual: &Value, reference: &Value, residues: &[String], atoms: &[String]) {
    assert_eq!(
        actual["rows"]
            .as_array()
            .unwrap()
            .iter()
            .map(
                |r| residues[r["residue"]["representative_row"].as_u64().unwrap() as usize].clone()
            )
            .collect::<Vec<_>>(),
        reference["rows"]
            .as_array()
            .unwrap()
            .iter()
            .map(|r| residue_key(&r["residue"]))
            .collect::<Vec<_>>(),
        "source hierarchy order"
    );
    let expected = reference["rows"]
        .as_array()
        .unwrap()
        .iter()
        .map(|r| (residue_key(&r["residue"]), r))
        .collect::<BTreeMap<_, _>>();
    assert_eq!(actual["rows"].as_array().unwrap().len(), expected.len());
    for row in actual["rows"].as_array().unwrap() {
        let source =
            &expected[&residues[row["residue"]["representative_row"].as_u64().unwrap() as usize]];
        for (property, value) in source["properties"].as_object().unwrap() {
            if property == "EXP_CB_PCB_ANGLE" && !value.is_null() {
                close(
                    row["properties"][property].as_f64().unwrap(),
                    value.as_f64().unwrap(),
                    ANGLE_ABS,
                    ANGLE_REL,
                );
            } else {
                assert_eq!(
                    &row["properties"][property], value,
                    "{property} {}",
                    source["residue"]
                );
            }
        }
        let selected = row["selected_ca"]
            .as_u64()
            .map(|i| atoms[i as usize].clone());
        let expected = if source["selected_CA"].is_null() {
            None
        } else {
            Some(atom_key(&source["selected_CA"]))
        };
        assert_eq!(selected, expected);
        let all = row["ca_connectivity_rows"]
            .as_array()
            .unwrap()
            .iter()
            .map(|i| atoms[i.as_u64().unwrap() as usize].clone())
            .collect::<Vec<_>>();
        assert_eq!(
            all,
            source["all_CA_connectivity_candidates"]
                .as_array()
                .unwrap()
                .iter()
                .map(atom_key)
                .collect::<Vec<_>>()
        );
    }
    let peptides = actual["peptides"]
        .as_array()
        .unwrap()
        .iter()
        .map(|p| {
            p.as_array()
                .unwrap()
                .iter()
                .map(|r| residues[r.as_u64().unwrap() as usize].clone())
                .collect::<Vec<_>>()
        })
        .collect::<Vec<_>>();
    assert_eq!(
        peptides,
        reference["peptides"]
            .as_array()
            .unwrap()
            .iter()
            .map(|p| p
                .as_array()
                .unwrap()
                .iter()
                .map(residue_key)
                .collect::<Vec<_>>())
            .collect::<Vec<_>>()
    );
}

fn compare_fit(actual: &Value, reference: &Value) {
    close(
        actual["rmsd"].as_f64().unwrap(),
        reference["rmsd"].as_f64().unwrap(),
        FIT_ABS,
        FIT_REL,
    );
    close(actual["determinant"].as_f64().unwrap(), 1., FIT_ABS, 0.);
    for (i, row) in actual["transformed"].as_array().unwrap().iter().enumerate() {
        for axis in 0..3 {
            close(
                row[axis].as_f64().unwrap(),
                reference["transformed"][i][axis].as_f64().unwrap(),
                FIT_ABS,
                FIT_REL,
            );
        }
    }
    for i in 0..3 {
        for j in 0..3 {
            let dot = (0..3)
                .map(|k| {
                    actual["rotation"][k][i].as_f64().unwrap()
                        * actual["rotation"][k][j].as_f64().unwrap()
                })
                .sum::<f64>();
            close(dot, if i == j { 1. } else { 0. }, FIT_ABS, 0.);
            if reference["reference_centered_rank"] == 3 {
                close(
                    actual["rotation"][i][j].as_f64().unwrap(),
                    reference["rotation"][i][j].as_f64().unwrap(),
                    FIT_ABS,
                    FIT_REL,
                );
            }
        }
    }
    if reference["reference_centered_rank"] == 3 {
        for i in 0..3 {
            close(
                actual["translation"][i].as_f64().unwrap(),
                reference["translation"][i].as_f64().unwrap(),
                FIT_ABS,
                FIT_REL,
            );
        }
    }
}

fn legacy_contacts(native: &Value, raw: &Value, reference: &Value) {
    let atom_level = native["level"] == "atom";
    let label = |row: usize| {
        let fields = &raw["atoms"][row]["fields"];
        let get = |name: &str| fields[name]["value"].as_str().unwrap_or("");
        let mut values = vec![
            get("auth_asym_id").to_owned(),
            format!("{}{}", get("auth_seq_id"), get("pdbx_PDB_ins_code")),
            get("auth_comp_id").to_owned(),
        ];
        if atom_level {
            values.push(get("auth_atom_id").to_owned());
        }
        values
    };
    let canonical = |a: Vec<String>, b: Vec<String>| {
        if a < b {
            [a, b].concat()
        } else {
            [b, a].concat()
        }
    };
    let actual = native["pairs"]
        .as_array()
        .unwrap()
        .iter()
        .map(|p| {
            canonical(
                label(p[0].as_u64().unwrap() as usize),
                label(p[1].as_u64().unwrap() as usize),
            )
        })
        .collect::<BTreeSet<_>>();
    let expected = reference["stdout"]
        .as_str()
        .unwrap()
        .lines()
        .skip(1)
        .map(|line| {
            let fields = line.split('\t').map(str::to_owned).collect::<Vec<_>>();
            let half = fields.len() / 2;
            canonical(fields[..half].to_vec(), fields[half..].to_vec())
        })
        .collect::<BTreeSet<_>>();
    assert_eq!(actual, expected);
}

fn retained_legacy_profiles() {
    for (file, golden, flags) in [
        ("../1ubq.pdb", "1ubq.geom.tsv", vec![]),
        ("geometry-1a2p.pdb", "1a2p.geom.tsv", vec![]),
        ("geometry-3nir.pdb", "3nir.geom.tsv", vec![]),
        (
            "geometry-3nir.pdb",
            "3nir.heavy.geom.tsv",
            vec!["--no-hydrogens", "--atom-class", "atom"],
        ),
        ("geometry-3nir.pdb", "3nir.ca.geom.tsv", vec!["--ca-only"]),
    ] {
        let input = fixture(&format!("analysis/{file}"));
        let mut args = vec!["--json", "geometry", input.to_str().unwrap()];
        args.extend(flags);
        let actual = run(&args);
        let actual = &actual["models"][0];
        let expected = source(&format!("legacy-geometry-{golden}"));
        assert_eq!(expected["byte_equal_to_historical_golden"], true);
        for line in expected["stdout"].as_str().unwrap().lines() {
            let mut fields = line.split('\t');
            let name = fields.next().unwrap();
            let key = match name {
                "atoms" => "atom_count",
                "residues" => "residue_count",
                other => other,
            };
            for (i, value) in fields.enumerate() {
                let reference = value.parse::<f64>().unwrap();
                let result = if actual[key].is_array() {
                    actual[key][i].as_f64().unwrap()
                } else {
                    actual[key].as_f64().unwrap()
                };
                if matches!(name, "atoms" | "residues") {
                    assert_eq!(result, reference);
                } else if name.starts_with("bbox") {
                    assert_eq!(result as f32, reference as f32);
                } else {
                    let printed_half_quantum = if reference == 0. {
                        0.
                    } else {
                        0.5 * 10_f64.powf(reference.abs().log10().floor() - 9.)
                    };
                    if name == "total_mass" {
                        close(result, reference, 1e-9 + printed_half_quantum, 1e-12);
                    } else {
                        close(
                            result,
                            reference,
                            GEOMETRY_ABS + printed_half_quantum,
                            GEOMETRY_REL,
                        );
                    }
                }
            }
        }
    }
    for (file, golden, cutoff, level, extra) in [
        (
            "contacts-1crn.pdb",
            "1crn.atom_4.0.tsv",
            "4",
            "atom",
            vec![],
        ),
        (
            "contacts-1crn.pdb",
            "1crn.residue_8.0.tsv",
            "8",
            "residue",
            vec![],
        ),
        (
            "contacts-1crn.pdb",
            "1crn.residue_ca_8.0_sep2.tsv",
            "8",
            "residue",
            vec!["--ca-only", "--min-seq-sep", "2"],
        ),
        (
            "contacts-1crn.pdb",
            "1crn.atom_ca_boundary.tsv",
            "6.703862694776753",
            "atom",
            vec!["--ca-only"],
        ),
        (
            "contacts-altloc.pdb",
            "altloc.atom_ca_3.0.tsv",
            "3",
            "atom",
            vec!["--ca-only"],
        ),
    ] {
        let input = fixture(&format!("analysis/{file}"));
        let path = input.to_str().unwrap();
        let raw = run(&["--json", "inspect", path]);
        let mut args = vec![
            "--json", "contacts", path, "--cutoff", cutoff, "--level", level,
        ];
        args.extend(extra);
        let result = run(&args);
        legacy_contacts(
            &result["models"][0],
            &raw,
            &source(&format!("legacy-contacts-{golden}")),
        );
    }
    for (file, golden, radius) in [
        ("contacts-1crn.pdb", "1crn.r12.expected.tsv", "12"),
        ("contacts-1crn.pdb", "1crn.r13.expected.tsv", "13"),
        ("hsexposure-4hhb.pdb", "4hhb.r13.expected.tsv", "13"),
        ("hsexposure-altloc.pdb", "altloc.r10.expected.tsv", "10"),
        ("hsexposure-altloc.pdb", "altloc.r13.expected.tsv", "13"),
    ] {
        let input = fixture(&format!("analysis/{file}"));
        let actual = run(&[
            "--json",
            "exposure",
            input.to_str().unwrap(),
            "--radius",
            radius,
        ]);
        let rows = actual["models"][0]["rows"]
            .as_array()
            .unwrap()
            .iter()
            .map(|row| {
                let id = &row["residue"];
                (
                    (
                        text(&id["author_chain"]["value"]),
                        format!(
                            "{}{}",
                            id["author_sequence"]["value"].as_str().unwrap(),
                            id["insertion"]["value"].as_str().unwrap_or("")
                        ),
                        text(&id["component"]),
                    ),
                    &row["properties"],
                )
            })
            .collect::<BTreeMap<_, _>>();
        let reference = source(&format!("legacy-hsexposure-{golden}"));
        for line in reference["stdout"].as_str().unwrap().lines().skip(1) {
            let fields = line.split('\t').collect::<Vec<_>>();
            let row = &rows[&(
                fields[0].to_owned(),
                fields[1].to_owned(),
                fields[2].to_owned(),
            )];
            for (key, value) in [
                "EXP_HSE_A_U",
                "EXP_HSE_A_D",
                "EXP_HSE_B_U",
                "EXP_HSE_B_D",
                "EXP_CN",
            ]
            .iter()
            .zip(&fields[3..])
            {
                if *value == "." {
                    assert!(row[*key].is_null());
                } else {
                    assert_eq!(row[*key].as_u64().unwrap(), value.parse::<u64>().unwrap());
                }
            }
        }
    }
}

#[test]
fn complete_native_coordinate_analysis_workflow_matches_retained_source() {
    for (prefix, suffix) in [
        ("pdb-workflow", "pdb"),
        ("mmcif-workflow", "cif"),
        ("small-pdb-workflow", "pdb"),
        ("integrated-selected-workflow", "cif"),
    ] {
        let input = fixture(&format!("analysis/{prefix}.{suffix}"));
        let path = input.to_str().unwrap();
        let raw = run(&["--json", "inspect", path]);
        let (residues, atoms) = raw_keys(&raw);
        let geometry = run(&["--json", "--threads", "2", "geometry", path]);
        compare_geometry(
            &geometry["models"][0],
            &source(&format!("{prefix}-geometry")),
        );
        let actual = geometry["models"][0]["source_rows"]
            .as_array()
            .unwrap()
            .iter()
            .map(|r| atoms[r.as_u64().unwrap() as usize].clone())
            .collect::<Vec<_>>();
        assert_eq!(
            actual,
            source(&format!("{prefix}-geometry"))["atoms"]
                .as_array()
                .unwrap()
                .iter()
                .map(atom_key)
                .collect::<Vec<_>>()
        );
        let contacts = run(&[
            "--json",
            "--threads",
            "2",
            "contacts",
            path,
            "--cutoff",
            "4",
        ]);
        compare_contacts(
            &contacts["models"][0],
            &source(&format!("{prefix}-contacts")),
            &atoms,
        );
        let exposure = run(&[
            "--json",
            "--threads",
            "2",
            "exposure",
            path,
            "--radius",
            "13",
        ]);
        compare_exposure(
            &exposure["models"][0],
            &source(&format!("{prefix}-exposure")),
            &residues,
            &atoms,
        );
    }
    for name in [
        "fit-main",
        "fit-reflection",
        "fit-rank-deficient",
        "pdb-workflow-fit",
        "mmcif-workflow-fit",
        "small-pdb-workflow-fit",
        "integrated-selected-workflow-fit",
    ] {
        let points = fixture(&format!("analysis/{name}.json"));
        compare_fit(
            &run(&["--json", "superpose", "--points", points.to_str().unwrap()]),
            &source(&format!("{name}-source")),
        );
    }
    for (name, flags) in [
        ("all-conformers", vec![]),
        ("heavy", vec!["--no-hydrogens", "--atom-class", "atom"]),
        ("CA", vec!["--ca-only"]),
    ] {
        let input = fixture("analysis/geometry-3nir.pdb");
        let mut args = vec!["--json", "geometry", input.to_str().unwrap()];
        args.extend(flags);
        compare_geometry(
            &run(&args)["models"][0],
            &source(&format!("geometry-3nir-{name}")),
        );
    }
    let boundary = fixture("analysis/integrated-selected-workflow.cif");
    let path = boundary.to_str().unwrap();
    let raw = run(&["--json", "inspect", path]);
    let (residues, atoms) = raw_keys(&raw);
    let actual = run(&["--json", "contacts", path, "--cutoff", "3", "--ca-only"]);
    compare_contacts(
        &actual["models"][0],
        &source("integrated-cutoff-boundary")["contacts"],
        &atoms,
    );
    let actual = run(&["--json", "exposure", path, "--radius", "3"]);
    compare_exposure(
        &actual["models"][0],
        &source("integrated-cutoff-boundary")["exposure"],
        &residues,
        &atoms,
    );
    for (input, observation) in [
        ("hsexposure-altloc.pdb", "hsexposure-altloc.pdb"),
        ("hsexposure-4hhb.pdb", "hsexposure-4hhb.pdb"),
    ] {
        let path = fixture(&format!("analysis/{input}"));
        let raw = run(&["--json", "inspect", path.to_str().unwrap()]);
        let (residues, atoms) = raw_keys(&raw);
        let actual = run(&[
            "--json",
            "exposure",
            path.to_str().unwrap(),
            "--radius",
            "13",
        ]);
        compare_exposure(
            &actual["models"][0],
            &source(observation),
            &residues,
            &atoms,
        );
    }
    retained_legacy_profiles();
}

#[test]
fn namespace_selectors_read_write_capabilities_and_atomic_failures() {
    let (temporary, _cleanup) = if let Some(root) = std::env::var_os("RSOMICS_STRUCTURE_EVIDENCE") {
        let path = Path::new(&root).join("native-selector-lifecycle");
        fs::create_dir(&path).unwrap();
        (path, None)
    } else {
        let temp = tempfile::tempdir().unwrap();
        (temp.path().to_owned(), Some(temp))
    };
    let whole = fixture("1A8O.cif");
    let water_output = temporary.join("label-conformers.cif");
    let selected = run(&[
        "--json",
        "select",
        whole.to_str().unwrap(),
        "--residue-namespace",
        "label",
        "--conformers",
        "highest-occupancy",
        "--output",
        water_output.to_str().unwrap(),
    ]);
    assert_eq!(
        selected["outputs"][0]["source_rows"],
        json!((0..644).collect::<Vec<_>>())
    );
    let reread = run(&["--json", "inspect", water_output.to_str().unwrap()]);
    assert_eq!(reread["atoms"].as_array().unwrap().len(), 644);
    assert_eq!(
        reread["atoms"][557]["fields"]["label_seq_id"]["state"],
        "inapplicable"
    );
    assert_eq!(
        reread["atoms"][557]["fields"]["auth_seq_id"]["value"],
        "1001"
    );
    let label_geometry = run(&[
        "--json",
        "geometry",
        whole.to_str().unwrap(),
        "--analysis-namespace",
        "label",
    ]);
    assert_eq!(
        label_geometry["models"][0]["source_rows"],
        json!((0..556).collect::<Vec<_>>())
    );
    let output = temporary.join("selected.cif");
    let input = fixture("integrated-contract.cif");
    let selected = run(&[
        "--json",
        "select",
        input.to_str().unwrap(),
        "--model",
        "3",
        "--entity",
        "1",
        "--polymer-type",
        "polypeptide(L)",
        "--residue-namespace",
        "label",
        "--residue",
        "1",
        "--atom-namespace",
        "label",
        "--atom",
        "CA",
        "--conformers",
        "highest-occupancy",
        "--output",
        output.to_str().unwrap(),
    ]);
    assert_eq!(selected["outputs"][0]["source_rows"], json!([3]));
    let raw = run(&["--json", "inspect", input.to_str().unwrap()]);
    let reloaded = run(&["--json", "inspect", output.to_str().unwrap()]);
    assert_eq!(reloaded["atoms"][0]["fields"], raw["atoms"][3]["fields"]);
    let contacts = run(&[
        "--json",
        "contacts",
        input.to_str().unwrap(),
        "--model",
        "3",
        "--min-seq-sep",
        "2",
    ]);
    assert_eq!(
        contacts["models"][0]["source_rows"]
            .as_array()
            .unwrap()
            .len(),
        15
    );
    let mixed_hetero = fixture("analysis/hetero-kind.cif");
    let geometry = run(&["--json", "geometry", mixed_hetero.to_str().unwrap()]);
    assert_eq!(geometry["models"][0]["residue_count"], 2);
    let pdb = fixture("analysis/geometry-3nir.pdb");
    let inspection = run(&["--json", "inspect", pdb.to_str().unwrap()]);
    assert_eq!(
        inspection["unqualified_write_records"],
        json!(["ANISOU", "CONECT"])
    );
    let destination = temporary.join("existing.pdb");
    let ubq = fixture("1ubq.pdb");
    fs::write(&destination, b"preserve destination").unwrap();
    for args in [
        vec![
            "--json",
            "select",
            pdb.to_str().unwrap(),
            "--output",
            destination.to_str().unwrap(),
        ],
        vec![
            "--json",
            "geometry",
            ubq.to_str().unwrap(),
            "--polymer-only",
        ],
        vec![
            "--json",
            "superpose",
            "--reference",
            pdb.to_str().unwrap(),
            "--moving",
            pdb.to_str().unwrap(),
            "--reference-rows",
            "0,1",
            "--moving-rows",
            "0",
        ],
    ] {
        let failure = call(&args);
        assert!(!failure.status.success());
    }
    assert_eq!(fs::read(&destination).unwrap(), b"preserve destination");
    assert_eq!(fs::read_dir(&temporary).unwrap().count(), 3);
    let points = fixture("analysis/small-pdb-workflow.pdb");
    for rows in ["0", "0,1"] {
        let fit = run(&[
            "--json",
            "superpose",
            "--reference",
            points.to_str().unwrap(),
            "--moving",
            points.to_str().unwrap(),
            "--reference-rows",
            rows,
            "--moving-rows",
            rows,
        ]);
        assert_eq!(fit["profile"], "structure-f32-widened-to-f64");
        close(fit["rmsd"].as_f64().unwrap(), 0., FIT_ABS, 0.);
        close(fit["determinant"].as_f64().unwrap(), 1., FIT_ABS, 0.);
    }
}
