use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};
use std::sync::atomic::{AtomicUsize, Ordering};

use mmcif_cif::{Document, ValueKind};
use serde_json::{Value, json};

fn fixture(name: &str) -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("tests/fixtures")
        .join(name)
}

fn run(args: &[&str]) -> Output {
    let output = Command::new(env!("CARGO_BIN_EXE_rsomics-structure"))
        .args(args)
        .output()
        .unwrap();
    if let Some(root) = std::env::var_os("RSOMICS_STRUCTURE_EVIDENCE") {
        static NEXT: AtomicUsize = AtomicUsize::new(0);
        let path = Path::new(&root).join(format!(
            "call-{:04}.json",
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        fs::write(path,serde_json::to_vec_pretty(&json!({"binary":env!("CARGO_BIN_EXE_rsomics-structure"),"args":args,"status":output.status.code(),"stdout":String::from_utf8_lossy(&output.stdout),"stderr":String::from_utf8_lossy(&output.stderr)})).unwrap()).unwrap();
    }
    output
}

fn sandbox(name: &str) -> (PathBuf, Option<tempfile::TempDir>) {
    if let Some(root) = std::env::var_os("RSOMICS_STRUCTURE_EVIDENCE") {
        let path = Path::new(&root).join(name);
        fs::create_dir_all(&path).unwrap();
        (path, None)
    } else {
        let temp = tempfile::tempdir().unwrap();
        (temp.path().to_owned(), Some(temp))
    }
}

fn inspect(path: &Path) -> Value {
    let result = run(&["--json", "inspect", path.to_str().unwrap()]);
    assert!(
        result.status.success(),
        "{}",
        String::from_utf8_lossy(&result.stderr)
    );
    serde_json::from_slice::<Value>(&result.stdout).unwrap()["result"].clone()
}

fn source(name: &str) -> Value {
    let record: Value =
        serde_json::from_slice(&fs::read(fixture(&format!("source/{name}.json"))).unwrap())
            .unwrap();
    assert_eq!(record["status"], "returned");
    record["result"].clone()
}

fn field_expected(value: &Value) -> Value {
    match value["kind"].as_str().unwrap() {
        "unknown" => json!({"state":"unknown","value":null}),
        "inapplicable" => json!({"state":"inapplicable","value":null}),
        _ => json!({"state":"text","value":value["decoded"]}),
    }
}

fn compare_inspect(actual: &Value, expected: &Value) {
    let columns = expected["categories"]["_atom_site."].as_object().unwrap();
    assert_eq!(
        actual["atoms"].as_array().unwrap().len(),
        columns["id"].as_array().unwrap().len()
    );
    for (name, values) in columns {
        for (row, value) in values.as_array().unwrap().iter().enumerate() {
            let field = &actual["atoms"][row]["fields"][name];
            assert_eq!(
                json!({"state":field["state"],"value":field["value"]}),
                field_expected(value),
                "{name} row{row}"
            );
        }
    }
    for (row, atom) in actual["atoms"].as_array().unwrap().iter().enumerate() {
        assert_eq!(atom["source_row"], row);
        for (axis, name) in ["Cartn_x", "Cartn_y", "Cartn_z"].iter().enumerate() {
            assert_eq!(
                atom["coordinate"][axis].as_f64().unwrap(),
                columns[*name][row]["decoded"]
                    .as_str()
                    .unwrap()
                    .parse::<f64>()
                    .unwrap()
            );
        }
    }
}

fn compare_file(path: &Path, expected: &Value) {
    let document = Document::open(path).unwrap();
    let block = document.block(0).unwrap();
    let expected = expected["categories"].as_object().unwrap();
    assert_eq!(block.category_names().len(), expected.len());
    for (category, columns) in expected {
        let actual = block
            .category(category.trim_matches(&['_', '.'][..]))
            .unwrap();
        for (name, values) in columns.as_object().unwrap() {
            let column = actual.column(name).unwrap();
            assert_eq!(column.len(), values.as_array().unwrap().len());
            for (cell, reference) in column.iter().zip(values.as_array().unwrap()) {
                let field = match cell.kind() {
                    ValueKind::Unknown => json!({"state":"unknown","value":null}),
                    ValueKind::Inapplicable => json!({"state":"inapplicable","value":null}),
                    _ => json!({"state":"text","value":cell.raw()}),
                };
                assert_eq!(field, field_expected(reference), "{category}{name}");
            }
        }
    }
}

#[test]
fn inspect_select_split_reload_retains_actual_source_population() {
    let (temp, _temporary) = sandbox("workflow");
    for (name, file, model, chain) in [
        (
            "integrated",
            "integrated-contract.cif",
            "3",
            "LABEL_LONG_CHAIN",
        ),
        ("1a8o", "1A8O.cif", "1", "A"),
    ] {
        let input = fixture(file);
        let original = inspect(&input);
        compare_inspect(&original, &source(&format!("{name}-input")));
        let output = temp.join(format!("{name}.cif"));
        let result = run(&[
            "--json",
            "select",
            input.to_str().unwrap(),
            "--model",
            model,
            "--chain-namespace",
            "label",
            "--chain",
            chain,
            "--output",
            output.to_str().unwrap(),
        ]);
        assert!(
            result.status.success(),
            "{}",
            String::from_utf8_lossy(&result.stderr)
        );
        compare_file(&output, &source(&format!("{name}-selected")));
        compare_inspect(&inspect(&output), &source(&format!("{name}-selected")));
        for split in ["chain", "model"] {
            let directory = temp.join(format!("{name}-{split}"));
            fs::create_dir(&directory).unwrap();
            let result = run(&[
                "--json",
                "--threads",
                "2",
                "select",
                input.to_str().unwrap(),
                "--chain-namespace",
                "label",
                "--split-by",
                split,
                "--split-dir",
                directory.to_str().unwrap(),
            ]);
            assert!(
                result.status.success(),
                "{}",
                String::from_utf8_lossy(&result.stderr)
            );
            let report: Value = serde_json::from_slice(&result.stdout).unwrap();
            let mut rows = report["result"]["outputs"]
                .as_array()
                .unwrap()
                .iter()
                .flat_map(|file| {
                    file["source_rows"]
                        .as_array()
                        .unwrap()
                        .iter()
                        .map(|row| row.as_u64().unwrap())
                })
                .collect::<Vec<_>>();
            rows.sort_unstable();
            assert_eq!(
                rows,
                (0..original["atoms"].as_array().unwrap().len() as u64).collect::<Vec<_>>()
            );
            for output in report["result"]["outputs"].as_array().unwrap() {
                let actual = inspect(Path::new(output["path"].as_str().unwrap()));
                for (atom, row) in actual["atoms"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .zip(output["source_rows"].as_array().unwrap())
                {
                    assert_eq!(
                        atom["fields"],
                        original["atoms"][row.as_u64().unwrap() as usize]["fields"]
                    );
                }
            }
        }
    }
    let label_only = temp.join("label-only.cif");
    fs::write(
        &label_only,
        "data_labels\nloop_\n_atom_site.id\n_atom_site.group_PDB\n_atom_site.label_asym_id\n_atom_site.pdbx_PDB_model_num\n_atom_site.Cartn_x\n_atom_site.Cartn_y\n_atom_site.Cartn_z\n1 ATOM L 3 0 0 0\n2 ATOM L 7 1 2 3\n",
    )
    .unwrap();
    let original = inspect(&label_only);
    assert_eq!(original["namespaces"], json!(["label"]),);
    for (name, filter, expected_row) in [("all", None, 0), ("model", Some("7"), 1)] {
        let output = temp.join(format!("label-only-{name}.cif"));
        let mut args = vec![
            "select",
            label_only.to_str().unwrap(),
            "--output",
            output.to_str().unwrap(),
        ];
        if let Some(model) = filter {
            args.extend(["--model", model]);
        }
        let result = run(&args);
        assert!(
            result.status.success(),
            "{}",
            String::from_utf8_lossy(&result.stderr)
        );
        let selected = inspect(&output);
        assert_eq!(
            selected["atoms"][0]["fields"],
            original["atoms"][expected_row]["fields"]
        );
        assert_eq!(
            selected["atoms"].as_array().unwrap().len(),
            if filter.is_some() { 1 } else { 2 }
        );
    }
    let directory = temp.join("label-only-models");
    fs::create_dir(&directory).unwrap();
    let split = run(&[
        "--json",
        "select",
        label_only.to_str().unwrap(),
        "--split-by",
        "model",
        "--split-dir",
        directory.to_str().unwrap(),
    ]);
    assert!(
        split.status.success(),
        "{}",
        String::from_utf8_lossy(&split.stderr)
    );
    let split: Value = serde_json::from_slice(&split.stdout).unwrap();
    assert_eq!(split["result"]["outputs"].as_array().unwrap().len(), 2);
    for file in split["result"]["outputs"].as_array().unwrap() {
        let selected = inspect(Path::new(file["path"].as_str().unwrap()));
        let row = file["source_rows"][0].as_u64().unwrap() as usize;
        assert_eq!(
            selected["atoms"][0]["fields"],
            original["atoms"][row]["fields"]
        );
    }
    let pdb = inspect(&fixture("1ubq.pdb"));
    let expected = source("1ubq-inspect");
    let atoms = expected["models"][0]["unpacked_atoms"].as_array().unwrap();
    assert_eq!(pdb["atoms"].as_array().unwrap().len(), atoms.len());
    for (ours, theirs) in pdb["atoms"].as_array().unwrap().iter().zip(atoms) {
        for axis in 0..3 {
            assert_eq!(
                f64::from(ours["coordinate"][axis].as_f64().unwrap() as f32),
                theirs["coord"][axis].as_f64().unwrap()
            );
        }
        assert_eq!(
            ours["fields"]["auth_asym_id"]["value"],
            theirs["residue"][2]
        );
        assert_eq!(ours["fields"]["label_asym_id"]["state"], "absent");
    }
    let output = temp.join("ubq.pdb");
    let result = run(&[
        "select",
        fixture("1ubq.pdb").to_str().unwrap(),
        "--chain",
        "A",
        "--output",
        output.to_str().unwrap(),
    ]);
    assert!(
        result.status.success(),
        "{}",
        String::from_utf8_lossy(&result.stderr)
    );
    assert_eq!(inspect(&output)["atoms"], pdb["atoms"]);
    let multi = fixture("models-and-blanks.pdb");
    let original = inspect(&multi);
    assert_eq!(original["models"][0]["serial"]["value"], "3");
    assert_eq!(original["models"][1]["serial"]["value"], "7");
    assert_eq!(
        original["atoms"][0]["fields"]["occupancy"]["state"],
        "blank"
    );
    assert_eq!(
        original["atoms"][0]["fields"]["B_iso_or_equiv"]["state"],
        "blank"
    );
    assert_eq!(
        original["atoms"][3]["fields"]["auth_asym_id"]["state"],
        "blank"
    );
    for split in ["chain", "model"] {
        let directory = temp.join(format!("pdb-{split}"));
        fs::create_dir(&directory).unwrap();
        let result = run(&[
            "--json",
            "select",
            multi.to_str().unwrap(),
            "--split-by",
            split,
            "--split-dir",
            directory.to_str().unwrap(),
        ]);
        assert!(
            result.status.success(),
            "{}",
            String::from_utf8_lossy(&result.stderr)
        );
        let report: Value = serde_json::from_slice(&result.stdout).unwrap();
        for output in report["result"]["outputs"].as_array().unwrap() {
            let path = Path::new(output["path"].as_str().unwrap());
            let reloaded = inspect(path);
            for (atom, row) in reloaded["atoms"]
                .as_array()
                .unwrap()
                .iter()
                .zip(output["source_rows"].as_array().unwrap())
            {
                assert_eq!(
                    atom["fields"],
                    original["atoms"][row.as_u64().unwrap() as usize]["fields"]
                );
                assert_eq!(
                    atom["coordinate"],
                    original["atoms"][row.as_u64().unwrap() as usize]["coordinate"]
                );
            }
            assert!(fs::read_to_string(path).unwrap().ends_with("END\n"));
        }
    }
}

#[test]
fn failure_and_split_transaction_leave_existing_outputs_intact() {
    let (temp, _temporary) = sandbox("failure");
    let input = fixture("integrated-contract.cif");
    let alias = run(&[
        "select",
        input.to_str().unwrap(),
        "--output",
        input.to_str().unwrap(),
    ]);
    assert!(!alias.status.success());
    let protected = temp.join("protected.cif");
    fs::write(&protected, "existing-data").unwrap();
    let empty = run(&[
        "select",
        input.to_str().unwrap(),
        "--model",
        "missing",
        "--output",
        protected.to_str().unwrap(),
    ]);
    assert!(!empty.status.success());
    assert_eq!(fs::read_to_string(&protected).unwrap(), "existing-data");
    let wrong_namespace = run(&[
        "select",
        fixture("1ubq.pdb").to_str().unwrap(),
        "--chain-namespace",
        "label",
        "--chain",
        "A",
        "--output",
        temp.join("bad.pdb").to_str().unwrap(),
    ]);
    assert!(!wrong_namespace.status.success());
    let split = temp.join("split");
    fs::create_dir(&split).unwrap();
    fs::write(split.join("chain-000001.cif"), "previous-first").unwrap();
    fs::create_dir(split.join("chain-000002.cif")).unwrap();
    let failure = run(&[
        "--json",
        "select",
        input.to_str().unwrap(),
        "--split-by",
        "chain",
        "--split-dir",
        split.to_str().unwrap(),
    ]);
    assert!(!failure.status.success());
    assert_eq!(
        fs::read_to_string(split.join("chain-000001.cif")).unwrap(),
        "previous-first"
    );
    assert_eq!(fs::read_dir(&split).unwrap().count(), 2);
    let unsupported = temp.join("unsupported.cif");
    fs::write(
        &unsupported,
        format!(
            "{}\nloop_\n_atom_site_anisotrop.id\n_atom_site_anisotrop.U[1][1]\natom001 0.1\n",
            fs::read_to_string(&input).unwrap()
        ),
    )
    .unwrap();
    let failure = run(&["--json", "inspect", unsupported.to_str().unwrap()]);
    assert!(!failure.status.success());
    assert!(
        String::from_utf8_lossy(&failure.stderr).contains("unsupported linked coordinate category")
    );
}
