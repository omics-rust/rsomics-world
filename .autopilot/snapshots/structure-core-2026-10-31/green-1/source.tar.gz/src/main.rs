fn main() -> std::process::ExitCode {
    rsomics_structure::run_cli()
}
