#![forbid(unsafe_code)]

mod analysis;
mod cif;
mod cli;
mod field;
mod inspect;
mod model;
mod pdb;
mod select;

fn invalid(message: impl Into<String>) -> rsomics_common::RsomicsError {
    rsomics_common::RsomicsError::InvalidInput(message.into())
}

/// Runs the coordinate-file and structural-analysis command-line interface.
///
/// ```no_run
/// fn main() -> std::process::ExitCode {
///     rsomics_structure::run_cli()
/// }
/// ```
pub fn run_cli() -> std::process::ExitCode {
    cli::run()
}
