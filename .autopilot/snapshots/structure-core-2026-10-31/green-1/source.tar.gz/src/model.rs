use std::collections::HashMap;
use std::fs;
use std::io::Write;
use std::path::Path;

use clap::ValueEnum;
use rsomics_common::{Context, Result};
use serde::Serialize;

use crate::cif::Cif;
use crate::field::{Field, Identifier, State};
use crate::invalid;
use crate::pdb::Pdb;

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize)]
#[serde(rename_all = "lowercase")]
pub(crate) enum Format {
    Pdb,
    Mmcif,
}

impl Format {
    pub fn extension(self) -> &'static str {
        match self {
            Self::Pdb => "pdb",
            Self::Mmcif => "cif",
        }
    }
}

#[derive(Clone, Copy, Debug)]
pub(crate) enum Handle {
    Absent,
    Cif(usize),
    Pdb(usize, usize),
    PdbModel,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, ValueEnum, Serialize)]
#[serde(rename_all = "lowercase")]
pub(crate) enum Namespace {
    Author,
    Label,
}

#[derive(Clone, Copy)]
pub(crate) struct IdentityColumns {
    pub model: Handle,
    pub author_chain: Handle,
    pub label_chain: Handle,
}

#[derive(Debug)]
pub(crate) struct CoordinateRow {
    pub coordinate: [f64; 3],
    pub model: usize,
}

#[derive(Serialize)]
pub(crate) struct Model {
    pub index: usize,
    pub serial: Identifier,
    pub explicit: bool,
}

enum Raw {
    Cif(Cif),
    Pdb(Pdb),
}

pub(crate) struct Structure {
    raw: Raw,
    pub rows: Vec<CoordinateRow>,
    pub models: Vec<Model>,
    pub identity: IdentityColumns,
}

impl Structure {
    pub fn read(path: &Path) -> Result<Self> {
        let text =
            fs::read_to_string(path).rs_with_context(|| format!("reading {}", path.display()))?;
        let first = text
            .trim_start_matches('\u{feff}')
            .lines()
            .find(|line| !line.trim().is_empty() && !line.trim_start().starts_with('#'))
            .unwrap_or("")
            .trim_start();
        let cif = first
            .get(..5)
            .is_some_and(|head| head.eq_ignore_ascii_case("data_"));
        let raw = if cif {
            Raw::Cif(Cif::read(text)?)
        } else {
            Raw::Pdb(Pdb::read(text)?)
        };
        let mut structure = Self {
            raw,
            rows: Vec::new(),
            models: Vec::new(),
            identity: IdentityColumns {
                model: Handle::Absent,
                author_chain: Handle::Absent,
                label_chain: Handle::Absent,
            },
        };
        structure.identity = IdentityColumns {
            model: structure.resolve("pdbx_PDB_model_num"),
            author_chain: structure.resolve("auth_asym_id"),
            label_chain: structure.resolve("label_asym_id"),
        };
        if let Raw::Pdb(pdb) = &mut structure.raw {
            structure.rows = std::mem::take(&mut pdb.coordinates)
                .into_iter()
                .map(|(coordinate, model)| CoordinateRow { coordinate, model })
                .collect();
            structure.models = pdb
                .models
                .iter()
                .enumerate()
                .map(|(index, range)| Model {
                    index,
                    serial: range
                        .as_ref()
                        .map_or(Field::ABSENT, |range| Field::pdb(&pdb.text[range.clone()]))
                        .key()
                        .into(),
                    explicit: range.is_some(),
                })
                .collect();
        } else {
            let count = match &structure.raw {
                Raw::Cif(cif) => cif.rows,
                _ => unreachable!(),
            };
            let xyz = [
                structure.resolve("Cartn_x"),
                structure.resolve("Cartn_y"),
                structure.resolve("Cartn_z"),
            ];
            let mut models = HashMap::new();
            let mut rows = Vec::with_capacity(count);
            let mut model_reports = Vec::new();
            for row in 0..count {
                let key = structure.field(row, structure.identity.model).key();
                let next = models.len();
                let model = *models.entry(key).or_insert_with(|| {
                    model_reports.push(Model {
                        index: next,
                        serial: key.into(),
                        explicit: key.state != State::Absent,
                    });
                    next
                });
                let mut coordinate = [0.; 3];
                for axis in 0..3 {
                    coordinate[axis] = finite(structure.field(row, xyz[axis]), row, "coordinate")?;
                }
                rows.push(CoordinateRow { coordinate, model });
            }
            drop(models);
            structure.rows = rows;
            structure.models = model_reports;
        }
        if structure.rows.is_empty() {
            return Err(invalid("coordinate input contains no atoms"));
        }
        Ok(structure)
    }

    pub fn format(&self) -> Format {
        match self.raw {
            Raw::Cif(_) => Format::Mmcif,
            Raw::Pdb(_) => Format::Pdb,
        }
    }

    pub fn resolve(&self, name: &str) -> Handle {
        match &self.raw {
            Raw::Cif(cif) => cif
                .columns
                .get(&name.to_ascii_lowercase())
                .map_or(Handle::Absent, |&column| Handle::Cif(column)),
            Raw::Pdb(_) => match name {
                "group_PDB" => Handle::Pdb(0, 6),
                "id" => Handle::Pdb(6, 11),
                "auth_atom_id" => Handle::Pdb(12, 16),
                "label_alt_id" => Handle::Pdb(16, 17),
                "auth_comp_id" => Handle::Pdb(17, 20),
                "auth_asym_id" => Handle::Pdb(21, 22),
                "auth_seq_id" => Handle::Pdb(22, 26),
                "pdbx_PDB_ins_code" => Handle::Pdb(26, 27),
                "Cartn_x" => Handle::Pdb(30, 38),
                "Cartn_y" => Handle::Pdb(38, 46),
                "Cartn_z" => Handle::Pdb(46, 54),
                "occupancy" => Handle::Pdb(54, 60),
                "B_iso_or_equiv" => Handle::Pdb(60, 66),
                "type_symbol" => Handle::Pdb(76, 78),
                "pdbx_formal_charge" => Handle::Pdb(78, 80),
                "pdbx_PDB_model_num" => Handle::PdbModel,
                _ => Handle::Absent,
            },
        }
    }

    pub fn field(&self, row: usize, handle: Handle) -> Field<'_> {
        match (&self.raw, handle) {
            (_, Handle::Absent) => Field::ABSENT,
            (Raw::Cif(cif), Handle::Cif(column)) => cif.field(row, column),
            (Raw::Pdb(pdb), Handle::Pdb(start, end)) => pdb
                .line(row)
                .get(start..end)
                .map_or(Field::ABSENT, Field::pdb),
            (Raw::Pdb(pdb), Handle::PdbModel) => pdb.models[pdb.model(row)]
                .as_ref()
                .map_or(Field::ABSENT, |range| Field::pdb(&pdb.text[range.clone()])),
            _ => unreachable!("field handles belong to their structure"),
        }
    }

    pub fn names(&self) -> Vec<&str> {
        match &self.raw {
            Raw::Cif(cif) => cif.names.iter().map(String::as_str).collect(),
            Raw::Pdb(_) => vec![
                "group_PDB",
                "id",
                "auth_atom_id",
                "auth_comp_id",
                "auth_asym_id",
                "auth_seq_id",
                "label_atom_id",
                "label_comp_id",
                "label_asym_id",
                "label_seq_id",
                "label_entity_id",
                "label_alt_id",
                "pdbx_PDB_ins_code",
                "Cartn_x",
                "Cartn_y",
                "Cartn_z",
                "occupancy",
                "B_iso_or_equiv",
                "type_symbol",
                "pdbx_formal_charge",
                "pdbx_PDB_model_num",
            ],
        }
    }

    pub fn chain(&self, namespace: Namespace) -> Result<Handle> {
        let handle = match namespace {
            Namespace::Author => self.identity.author_chain,
            Namespace::Label => self.identity.label_chain,
        };
        if matches!(handle, Handle::Absent) {
            return Err(invalid(format!(
                "{namespace:?} chain namespace is absent from input"
            )));
        }
        Ok(handle)
    }

    pub fn polymers(&self) -> Result<Vec<(&str, &str)>> {
        match &self.raw {
            Raw::Cif(cif) => cif.polymers(),
            Raw::Pdb(_) => Err(invalid(
                "PDB has no qualified entity/polymer namespace; use mmCIF metadata",
            )),
        }
    }

    pub fn asym_entities(&self) -> Result<Vec<(&str, &str)>> {
        match &self.raw {
            Raw::Cif(cif) => cif.asym_entities(),
            Raw::Pdb(_) => Err(invalid("PDB has no entity namespace")),
        }
    }

    pub fn write(&self, rows: &[usize], output: &mut dyn Write) -> Result<()> {
        match &self.raw {
            Raw::Cif(cif) => cif.write(rows, output),
            Raw::Pdb(pdb) => pdb.write(rows, output),
        }
    }

    pub fn unqualified_write_records(&self) -> Vec<&'static str> {
        match &self.raw {
            Raw::Pdb(pdb) => pdb.unqualified_write_records(),
            Raw::Cif(_) => Vec::new(),
        }
    }
}

pub(crate) fn finite(field: Field<'_>, row: usize, name: &str) -> Result<f64> {
    let value = field
        .value
        .ok_or_else(|| invalid(format!("row {row}: {name} is missing")))?
        .parse::<f64>()?;
    if !value.is_finite() {
        return Err(invalid(format!("row {row}: {name} must be finite")));
    }
    Ok(value)
}
