use std::collections::HashMap;
use std::io::Write;
use std::path::PathBuf;

use rsomics_common::Result;
use serde::ser::{SerializeMap, SerializeSeq, SerializeStruct};
use serde::{Serialize, Serializer};

use crate::field::Identifier;
use crate::model::{Format, Handle, Namespace, Structure};

pub(crate) struct Inspection {
    pub input: PathBuf,
    pub workers: usize,
    pub structure: Structure,
}

#[derive(Serialize)]
struct Population {
    model_index: usize,
    namespace: Namespace,
    chain: Identifier,
    source_rows: Vec<usize>,
}

impl Inspection {
    fn populations(&self) -> Vec<Population> {
        let mut result: Vec<Population> = Vec::new();
        for namespace in [Namespace::Author, Namespace::Label] {
            let Ok(column) = self.structure.chain(namespace) else {
                continue;
            };
            let mut seen = HashMap::new();
            for (row, atom) in self.structure.rows.iter().enumerate() {
                let key = (atom.model, self.structure.field(row, column).key());
                let population = *seen.entry(key).or_insert_with(|| {
                    result.push(Population {
                        model_index: atom.model,
                        namespace,
                        chain: key.1.into(),
                        source_rows: Vec::new(),
                    });
                    result.len() - 1
                });
                result[population].source_rows.push(row);
            }
        }
        result
    }

    pub fn write_plain(&self, output: &mut dyn Write) -> Result<()> {
        writeln!(output, "format\tatoms\tmodels")?;
        writeln!(
            output,
            "{}\t{}\t{}",
            self.structure.format().extension(),
            self.structure.rows.len(),
            self.structure.models.len()
        )?;
        writeln!(output, "model_index\tnamespace\tchain_state\tchain\tatoms")?;
        for population in self.populations() {
            writeln!(
                output,
                "{}\t{:?}\t{:?}\t{}\t{}",
                population.model_index,
                population.namespace,
                population.chain.state,
                population.chain.value.as_deref().unwrap_or(""),
                population.source_rows.len()
            )?;
        }
        Ok(())
    }
}

impl Serialize for Inspection {
    fn serialize<S: Serializer>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error> {
        let structure = &self.structure;
        let mut result = serializer.serialize_struct("Inspection", 9)?;
        result.serialize_field("input", &self.input)?;
        result.serialize_field("workers", &self.workers)?;
        result.serialize_field("format", &structure.format())?;
        result.serialize_field(
            "unqualified_write_records",
            &structure.unqualified_write_records(),
        )?;
        let namespaces = if structure.format() == Format::Pdb {
            vec![Namespace::Author]
        } else {
            [Namespace::Author, Namespace::Label]
                .into_iter()
                .filter(|namespace| structure.chain(*namespace).is_ok())
                .collect()
        };
        result.serialize_field("namespaces", &namespaces)?;
        result.serialize_field("models", &structure.models)?;
        result.serialize_field("populations", &self.populations())?;
        result.serialize_field(
            "conformers",
            &"all source rows; no occupancy or residue-variant collapse",
        )?;
        result.serialize_field("atoms", &Atoms(structure))?;
        result.end()
    }
}

struct Atoms<'a>(&'a Structure);

impl Serialize for Atoms<'_> {
    fn serialize<S: Serializer>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error> {
        let columns = self
            .0
            .names()
            .into_iter()
            .map(|name| (name, self.0.resolve(name)))
            .collect::<Vec<_>>();
        let mut atoms = serializer.serialize_seq(Some(self.0.rows.len()))?;
        for row in 0..self.0.rows.len() {
            atoms.serialize_element(&AtomView {
                structure: self.0,
                row,
                columns: &columns,
            })?;
        }
        atoms.end()
    }
}

struct AtomView<'a> {
    structure: &'a Structure,
    row: usize,
    columns: &'a [(&'a str, Handle)],
}

impl Serialize for AtomView<'_> {
    fn serialize<S: Serializer>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error> {
        let atom = &self.structure.rows[self.row];
        let mut result = serializer.serialize_struct("Atom", 4)?;
        result.serialize_field("source_row", &self.row)?;
        result.serialize_field("model_index", &atom.model)?;
        result.serialize_field("coordinate", &atom.coordinate)?;
        result.serialize_field("fields", &Fields(self))?;
        result.end()
    }
}

struct Fields<'a>(&'a AtomView<'a>);

impl Serialize for Fields<'_> {
    fn serialize<S: Serializer>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error> {
        let mut fields = serializer.serialize_map(Some(self.0.columns.len()))?;
        for &(name, handle) in self.0.columns {
            fields.serialize_entry(name, &self.0.structure.field(self.0.row, handle))?;
        }
        fields.end()
    }
}
