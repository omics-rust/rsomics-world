use std::io::{self, Write};
use std::path::{Path, PathBuf};

use clap::{Args, Parser, Subcommand};
use rayon::prelude::*;
use rsomics_common::{
    AtomicFile, Context, OutputArgs, Result, RsomicsError, ThreadArgs, ToolMeta,
    reject_output_alias,
};
use serde::Serialize;

use crate::analysis::{contacts, exposure, geometry, superpose, view::View};
use crate::field::Identifier;
use crate::inspect::Inspection;
use crate::model::{Format, Namespace, Structure};
use crate::select::{Filters, Selection, SplitBy};
use serde_json::{Value, json};

#[derive(Parser)]
#[command(
    name = "rsomics-structure",
    version,
    about = "PDB and PDBx/mmCIF selection and coordinate analysis (private development)",
    arg_required_else_help = true
)]
struct Cli {
    #[command(flatten)]
    output: OutputArgs,
    #[command(flatten)]
    threads: ThreadArgs,
    #[command(subcommand)]
    command: Command,
}

#[derive(Subcommand)]
enum Command {
    /// Inspect ordered models, chain populations and all raw coordinate rows
    Inspect(Inspect),
    /// Select source rows, or transactionally split by chain or model
    Select(Select),
    /// Compute masses, centers, radii of gyration and bounding boxes
    Geometry(GeometryArgs),
    /// Find exact atom or residue contact pairs with an inclusive cutoff
    Contacts(ContactArgs),
    /// Compute HSE-alpha, HSE-beta and coordination numbers
    Exposure(ExposureArgs),
    /// Fit explicitly corresponding points with a proper right-multiplying rotation
    Superpose(SuperposeArgs),
}

#[derive(Args)]
struct InputArgs {
    input: PathBuf,
    #[arg(long)]
    model: Vec<String>,
    #[arg(long)]
    model_index: Vec<usize>,
    #[arg(long)]
    chain: Vec<String>,
    #[arg(long, value_enum, default_value = "author")]
    chain_namespace: Namespace,
    #[command(flatten)]
    filters: Filters,
}

impl InputArgs {
    fn selection(&self) -> Selection {
        Selection {
            namespace: self.chain_namespace,
            models: self.model.clone(),
            model_indices: self.model_index.clone(),
            chains: self.chain.clone(),
            filters: self.filters.clone(),
        }
    }
}

#[derive(Args)]
struct AnalysisArgs {
    #[command(flatten)]
    input: InputArgs,
    /// Residue/chain hierarchy used by the Biopython analysis profile
    #[arg(long, value_enum, default_value = "author")]
    analysis_namespace: Namespace,
    /// Named TSV (or --json result JSON) output, atomically replaced
    #[arg(short, long)]
    output: Option<PathBuf>,
}

#[derive(Args)]
struct GeometryArgs {
    #[command(flatten)]
    common: AnalysisArgs,
    /// All conformers of ATOM alpha carbons; no implicit occupancy collapse
    #[arg(long)]
    ca_only: bool,
}

#[derive(Args)]
struct ContactArgs {
    #[command(flatten)]
    common: AnalysisArgs,
    #[arg(long, default_value_t = 4.)]
    cutoff: f64,
    #[arg(long, value_enum, default_value = "atom")]
    level: contacts::Level,
    #[arg(long)]
    ca_only: bool,
    /// Exclude same-chain pairs with a smaller numeric author-sequence separation
    #[arg(long, default_value_t = 0)]
    min_seq_sep: u64,
}

#[derive(Args)]
struct ExposureArgs {
    #[command(flatten)]
    common: AnalysisArgs,
    #[arg(long, default_value_t = 13.)]
    radius: f64,
    /// Ignore this many adjacent peptide positions on either side, including self
    #[arg(long, default_value_t = 0)]
    offset: usize,
}

#[derive(Args)]
struct SuperposeArgs {
    /// JSON object with reference/moving Nx3 arrays and reference_ids/moving_ids
    #[arg(long,conflicts_with_all=["reference","moving","reference_rows","moving_rows"])]
    points: Option<PathBuf>,
    #[arg(long,required_unless_present="points",requires_all=["moving","reference_rows","moving_rows"])]
    reference: Option<PathBuf>,
    #[arg(long)]
    moving: Option<PathBuf>,
    /// Explicit corresponding input-local zero-based rows; comma-separated
    #[arg(long, value_delimiter = ',')]
    reference_rows: Vec<usize>,
    #[arg(long, value_delimiter = ',')]
    moving_rows: Vec<usize>,
    #[arg(short, long)]
    output: Option<PathBuf>,
}

#[derive(Args)]
struct Inspect {
    /// Named PDB or single-block mmCIF coordinate file; --json includes every raw field
    input: PathBuf,
}

#[derive(Args)]
struct Select {
    /// Named PDB or single-block mmCIF coordinate file
    input: PathBuf,
    /// Model serial/number exactly as stored; repeat to select several
    #[arg(long)]
    model: Vec<String>,
    /// Zero-based ordered model index; also addresses a PDB implicit model
    #[arg(long)]
    model_index: Vec<usize>,
    /// Exact chain text; repeat for several, or use an empty value for a blank PDB chain
    #[arg(long)]
    chain: Vec<String>,
    /// Which chain identity namespace --chain and chain splitting address
    #[arg(long, value_enum, default_value = "author")]
    chain_namespace: Namespace,
    #[command(flatten)]
    filters: Filters,
    /// Named destination in the input format, atomically replaced on success
    #[arg(
        short,
        long,
        required_unless_present = "split_dir",
        conflicts_with = "split_dir"
    )]
    output: Option<PathBuf>,
    /// Existing directory for the transactional output set
    #[arg(long, requires = "split_by")]
    split_dir: Option<PathBuf>,
    /// Split the selected population; filenames map to complete IDs in --json
    #[arg(long, value_enum, requires = "split_dir")]
    split_by: Option<SplitBy>,
}

#[derive(Serialize)]
#[serde(untagged)]
enum Report {
    Inspect(Inspection),
    Select(Selected),
    Analysis(Value),
}

#[derive(Serialize)]
struct OutputMapping {
    path: PathBuf,
    group: Option<Identifier>,
    source_rows: Vec<usize>,
}

#[derive(Serialize)]
struct Selected {
    input: PathBuf,
    format: Format,
    chain_namespace: Namespace,
    model_numbers: Vec<String>,
    model_indices: Vec<usize>,
    chains: Vec<String>,
    filters: Filters,
    conformers: &'static str,
    workers: usize,
    outputs: Vec<OutputMapping>,
}

pub(crate) fn run() -> std::process::ExitCode {
    let cli: Cli = rsomics_help::parse();
    rsomics_common::run(
        &cli.output,
        ToolMeta {
            name: "rsomics-structure",
            version: env!("CARGO_PKG_VERSION"),
        },
        || {
            let workers = match cli.threads.requested() {
                Some(value) => value.get(),
                None => std::thread::available_parallelism()?.get(),
            };
            match cli.command {
                Command::Inspect(args) => {
                    named(&args.input)?;
                    let report = Inspection {
                        structure: Structure::read(&args.input)?,
                        input: args.input,
                        workers,
                    };
                    if !cli.output.json {
                        let mut stdout = io::stdout().lock();
                        report.write_plain(&mut stdout)?;
                        stdout.flush()?;
                    }
                    Ok(Report::Inspect(report))
                }
                Command::Select(args) => {
                    let report = select(args, workers)?;
                    if !cli.output.json {
                        let mut stdout = io::stdout().lock();
                        writeln!(stdout, "output\tatoms")?;
                        for file in &report.outputs {
                            writeln!(
                                stdout,
                                "{}\t{}",
                                file.path.display(),
                                file.source_rows.len()
                            )?;
                        }
                        stdout.flush()?;
                    }
                    Ok(Report::Select(report))
                }
                Command::Geometry(args) => analysis(
                    &args.common,
                    workers,
                    &cli.output,
                    |view, model| {
                        serde_json::to_value(geometry::compute(view, model, args.ca_only)?)
                            .map_err(json_error)
                    },
                    "geometry",
                    "Bio1.87 unpacked conformers; f32 coordinates/weights/reductions; team NumPy Rg; Angstrom",
                ),
                Command::Contacts(args) => analysis(
                    &args.common,
                    workers,
                    &cli.output,
                    |view, model| {
                        serde_json::to_value(contacts::compute(
                            view,
                            model,
                            args.cutoff,
                            args.level,
                            args.ca_only,
                            args.min_seq_sep,
                        )?)
                        .map_err(json_error)
                    },
                    "contacts",
                    "Bio1.87 selected standard-AA heavy atoms; f32 inputs widened to f64; inclusive squared cutoff; pairs reference source rows",
                ),
                Command::Exposure(args) => analysis(
                    &args.common,
                    workers,
                    &cli.output,
                    |view, model| {
                        serde_json::to_value(exposure::compute(
                            view,
                            model,
                            args.radius,
                            args.offset,
                        )?)
                        .map_err(json_error)
                    },
                    "exposure",
                    "Bio1.87 any-CA conformer connectivity; selected CA calculations; HSE f64 strict radius; CN f32 strict radius; Angstrom/radians",
                ),
                Command::Superpose(args) => {
                    let (points, profile, inputs) = if let Some(path) = &args.points {
                        named(path)?;
                        (
                            serde_json::from_slice::<superpose::Points>(&std::fs::read(path)?)
                                .map_err(json_error)?,
                            "explicit-f64-points",
                            vec![path.as_path()],
                        )
                    } else {
                        let reference = args
                            .reference
                            .as_deref()
                            .ok_or_else(|| config("--reference is required"))?;
                        let moving = args
                            .moving
                            .as_deref()
                            .ok_or_else(|| config("--moving is required"))?;
                        named(reference)?;
                        named(moving)?;
                        let fixed = Structure::read(reference)?;
                        let moved = Structure::read(moving)?;
                        let (reference, reference_ids) = fit_rows(&fixed, &args.reference_rows)?;
                        let (moving, moving_ids) = fit_rows(&moved, &args.moving_rows)?;
                        (
                            superpose::Points {
                                reference,
                                moving,
                                reference_ids,
                                moving_ids,
                            },
                            "structure-f32-widened-to-f64",
                            vec![
                                args.reference.as_deref().expect("validated reference"),
                                args.moving.as_deref().expect("validated moving"),
                            ],
                        )
                    };
                    let report = serde_json::to_value(superpose::compute(points, profile)?)
                        .map_err(json_error)?;
                    emit_analysis(&report, args.output.as_deref(), &inputs, &cli.output)?;
                    Ok(Report::Analysis(report))
                }
            }
        },
    )
}

fn named(path: &Path) -> Result<()> {
    if path == Path::new("-") {
        return Err(config("input and output must be named files, not -"));
    }
    Ok(())
}

fn select(args: Select, workers: usize) -> Result<Selected> {
    named(&args.input)?;
    let structure = Structure::read(&args.input)?;
    let selection = Selection {
        namespace: args.chain_namespace,
        models: args.model,
        model_indices: args.model_index,
        chains: args.chain,
        filters: args.filters,
    };
    let rows = selection.resolve(&structure)?;
    let outputs = if let (Some(directory), Some(by)) = (args.split_dir, args.split_by) {
        if !std::fs::metadata(&directory)?.is_dir() {
            return Err(config("--split-dir must be an existing directory"));
        }
        selection
            .groups(&structure, &rows, by)?
            .into_iter()
            .enumerate()
            .map(|(index, group)| OutputMapping {
                path: directory.join(format!(
                    "{}-{:06}.{}",
                    match by {
                        SplitBy::Chain => "chain",
                        SplitBy::Model => "model",
                    },
                    index + 1,
                    structure.format().extension()
                )),
                group: Some(group.id),
                source_rows: group.rows,
            })
            .collect::<Vec<_>>()
    } else {
        vec![OutputMapping {
            path: args
                .output
                .ok_or_else(|| config("named output is required"))?,
            group: None,
            source_rows: rows,
        }]
    };
    for (index, file) in outputs.iter().enumerate() {
        named(&file.path)?;
        let suffix = file
            .path
            .extension()
            .and_then(|value| value.to_str())
            .map(str::to_ascii_lowercase);
        if matches!(
            (structure.format(), suffix.as_deref()),
            (Format::Pdb, Some("cif" | "mmcif")) | (Format::Mmcif, Some("pdb" | "ent"))
        ) {
            return Err(config("cross-format conversion is not supported"));
        }
        reject_output_alias(
            &file.path,
            std::iter::once(args.input.as_path())
                .chain(outputs[..index].iter().map(|other| other.path.as_path())),
        )?;
    }
    if outputs.len() == 1 {
        rsomics_common::write_output(Some(&outputs[0].path), |output| {
            structure.write(&outputs[0].source_rows, output)
        })?;
    } else {
        let pool = rayon::ThreadPoolBuilder::new()
            .num_threads(workers)
            .build()
            .map_err(|error| config(format!("creating split writer pool: {error}")))?;
        let staged: Result<Vec<_>> = pool.install(|| {
            outputs
                .par_iter()
                .map(|file| {
                    let mut staged = AtomicFile::new(&file.path)?;
                    structure
                        .write(&file.source_rows, staged.file_mut())
                        .rs_with_context(|| format!("writing {}", file.path.display()))?;
                    Ok(staged)
                })
                .collect()
        });
        AtomicFile::commit_all(staged?)?;
    }
    Ok(Selected {
        input: args.input,
        format: structure.format(),
        chain_namespace: selection.namespace,
        model_numbers: selection.models,
        model_indices: selection.model_indices,
        chains: selection.chains,
        filters: selection.filters,
        conformers: "resolved explicit row/conformer selection",
        workers,
        outputs,
    })
}

fn analysis(
    args: &AnalysisArgs,
    workers: usize,
    output: &OutputArgs,
    operation: impl Fn(&View<'_>, usize) -> Result<Value> + Sync,
    name: &str,
    profile: &str,
) -> Result<Report> {
    named(&args.input.input)?;
    let structure = Structure::read(&args.input.input)?;
    let selection = args.input.selection();
    let rows = selection.resolve(&structure)?;
    let view = View::new(&structure, &rows, args.analysis_namespace)?;
    view.validate_f32(&rows)?;
    let models = (0..structure.models.len())
        .filter(|&m| view.residues.iter().any(|r| r.model == m))
        .collect::<Vec<_>>();
    let pool = rayon::ThreadPoolBuilder::new()
        .num_threads(workers)
        .build()
        .map_err(|error| config(format!("creating analysis pool: {error}")))?;
    let results = pool.install(|| {
        models
            .into_iter()
            .map(|m| operation(&view, m))
            .collect::<Result<Vec<_>>>()
    })?;
    let report = json!({"operation":name,"input":args.input.input,"workers":workers,"profile":profile,
        "analysis_namespace":args.analysis_namespace,"selection":{"model":selection.models,"model_index":selection.model_indices,
        "chain_namespace":selection.namespace,"chain":selection.chains,"filters":selection.filters},"models":results});
    emit_analysis(
        &report,
        args.output.as_deref(),
        &[&args.input.input],
        output,
    )?;
    Ok(Report::Analysis(report))
}

fn emit_analysis(
    report: &Value,
    path: Option<&Path>,
    inputs: &[&Path],
    args: &OutputArgs,
) -> Result<()> {
    if let Some(path) = path {
        named(path)?;
        reject_output_alias(path, inputs.iter().copied())?;
        rsomics_common::write_output(Some(path), |out| {
            if args.json {
                serde_json::to_writer_pretty(&mut *out, report).map_err(json_error)?;
                writeln!(out)?;
            } else {
                write_analysis(report, out)?;
            }
            Ok(())
        })?;
    } else if !args.json {
        let mut stdout = io::stdout().lock();
        write_analysis(report, &mut stdout)?;
        stdout.flush()?;
    }
    Ok(())
}

fn write_analysis(report: &Value, out: &mut dyn Write) -> Result<()> {
    if report["operation"] == "contacts" {
        writeln!(out, "model\tlevel\tsource_row_a\tsource_row_b")?;
        for model in report["models"].as_array().expect("typed contact models") {
            for pair in model["pairs"].as_array().expect("typed contact pairs") {
                writeln!(
                    out,
                    "{}\t{}\t{}\t{}",
                    model["model_index"],
                    model["level"].as_str().expect("typed level"),
                    pair[0],
                    pair[1]
                )?;
            }
        }
        return Ok(());
    }
    if report["operation"] == "exposure" {
        let keys = [
            "EXP_HSE_A_U",
            "EXP_HSE_A_D",
            "EXP_HSE_B_U",
            "EXP_HSE_B_D",
            "EXP_CN",
            "EXP_CB_PCB_ANGLE",
        ];
        writeln!(out, "model\tresidue\t{}", keys.join("\t"))?;
        for model in report["models"].as_array().expect("typed exposure models") {
            for row in model["rows"].as_array().expect("typed exposure rows") {
                write!(out, "{}\t{}", model["model_index"], row["residue"])?;
                for key in keys {
                    let value = &row["properties"][key];
                    if value.is_null() {
                        write!(out, "\tNA")?;
                    } else {
                        write!(out, "\t{value}")?;
                    }
                }
                writeln!(out)?;
            }
        }
        return Ok(());
    }
    writeln!(out, "model\tmetric\tvalue")?;
    if let Some(models) = report["models"].as_array() {
        for model in models {
            let id = &model["model_index"];
            for (key, value) in model.as_object().expect("typed analysis report") {
                if key != "model_index" {
                    writeln!(out, "{id}\t{key}\t{value}")?;
                }
            }
        }
    } else {
        for (key, value) in report.as_object().expect("typed fit report") {
            writeln!(out, ".\t{key}\t{value}")?;
        }
    }
    Ok(())
}

fn fit_rows(structure: &Structure, rows: &[usize]) -> Result<(Vec<[f64; 3]>, Vec<Value>)> {
    let mut points = Vec::with_capacity(rows.len());
    let mut identities = Vec::with_capacity(rows.len());
    for &row in rows {
        let atom = structure
            .rows
            .get(row)
            .ok_or_else(|| config(format!("fit source row {row} is out of range")))?;
        let coordinate = atom.coordinate.map(|v| f64::from(v as f32));
        if coordinate.iter().any(|v| !v.is_finite()) {
            return Err(config("fit coordinate exceeds float32 source profile"));
        }
        points.push(coordinate);
        let fields = [
            "id",
            "auth_asym_id",
            "label_asym_id",
            "auth_seq_id",
            "label_seq_id",
            "pdbx_PDB_ins_code",
            "auth_atom_id",
            "label_atom_id",
            "label_alt_id",
        ]
        .into_iter()
        .map(|name| (name, structure.field(row, structure.resolve(name))))
        .collect::<std::collections::BTreeMap<_, _>>();
        identities.push(json!({"source_row":row,"model_index":atom.model,"fields":fields}));
    }
    Ok((points, identities))
}

fn json_error(error: serde_json::Error) -> RsomicsError {
    if error.is_io() {
        RsomicsError::Io(io::Error::other(error))
    } else {
        crate::invalid(format!("JSON: {error}"))
    }
}

fn config(message: impl Into<String>) -> RsomicsError {
    RsomicsError::ConfigError(message.into())
}
