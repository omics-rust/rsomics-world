use nalgebra::{Matrix3, linalg::SVD};
use rsomics_common::Result;
use serde::{Deserialize, Serialize};
use serde_json::Value;

use crate::invalid;

#[derive(Deserialize)]
pub(crate) struct Points {
    pub reference: Vec<[f64; 3]>,
    pub moving: Vec<[f64; 3]>,
    pub reference_ids: Vec<Value>,
    pub moving_ids: Vec<Value>,
}

#[derive(Serialize)]
pub(crate) struct Fit {
    pub profile: &'static str,
    pub convention: &'static str,
    pub reference_ids: Vec<Value>,
    pub moving_ids: Vec<Value>,
    pub rotation: [[f64; 3]; 3],
    pub translation: [f64; 3],
    pub rmsd: f64,
    pub transformed: Vec<[f64; 3]>,
    pub determinant: f64,
}

pub(crate) fn compute(points: Points, profile: &'static str) -> Result<Fit> {
    let n = points.reference.len();
    if n == 0
        || n != points.moving.len()
        || n != points.reference_ids.len()
        || n != points.moving_ids.len()
    {
        return Err(invalid(
            "explicit equal nonempty coordinate/identity correspondences are required",
        ));
    }
    if points
        .reference
        .iter()
        .chain(&points.moving)
        .flatten()
        .any(|v| !v.is_finite())
    {
        return Err(invalid("fit coordinates must be finite"));
    }
    let centroid = |rows: &[[f64; 3]]| -> [f64; 3] {
        let mut sum = [0.; 3];
        for row in rows {
            for axis in 0..3 {
                sum[axis] += row[axis];
            }
        }
        sum.map(|v| v / n as f64)
    };
    let fixed = centroid(&points.reference);
    let moving = centroid(&points.moving);
    let mut correlation = Matrix3::<f64>::zeros();
    for (m, r) in points.moving.iter().zip(&points.reference) {
        for i in 0..3 {
            for j in 0..3 {
                correlation[(i, j)] += (m[i] - moving[i]) * (r[j] - fixed[j]);
            }
        }
    }
    if correlation.iter().any(|v| !v.is_finite()) {
        return Err(invalid("fit covariance exceeds finite f64 range"));
    }
    let svd = SVD::try_new(correlation, true, true, f64::EPSILON, 1000)
        .ok_or_else(|| invalid("fit SVD failed to converge"))?;
    let u = svd.u.expect("SVD left vectors requested");
    let mut vt = svd.v_t.expect("SVD right vectors requested");
    let mut rotation = u * vt;
    if rotation.determinant() < 0. {
        for j in 0..3 {
            vt[(2, j)] = -vt[(2, j)];
        }
        rotation = u * vt;
    }
    let apply = |p: [f64; 3]| -> [f64; 3] {
        std::array::from_fn(|j| (0..3).map(|i| p[i] * rotation[(i, j)]).sum())
    };
    let rotated = apply(moving);
    let translation = std::array::from_fn(|i| fixed[i] - rotated[i]);
    let transformed = points
        .moving
        .iter()
        .map(|&p| {
            let r = apply(p);
            std::array::from_fn(|i| r[i] + translation[i])
        })
        .collect::<Vec<_>>();
    let sum: f64 = transformed
        .iter()
        .zip(&points.reference)
        .map(|(a, b)| (0..3).map(|i| (a[i] - b[i]).powi(2)).sum::<f64>())
        .sum();
    if !sum.is_finite() || translation.iter().any(|v| !v.is_finite()) {
        return Err(invalid("fit exceeds finite f64 result range"));
    }
    Ok(Fit {
        profile,
        convention: "moving @ rotation + translation; proper rotation; explicit fixed correspondence",
        reference_ids: points.reference_ids,
        moving_ids: points.moving_ids,
        rotation: std::array::from_fn(|i| std::array::from_fn(|j| rotation[(i, j)])),
        translation,
        rmsd: (sum / n as f64).sqrt(),
        transformed,
        determinant: rotation.determinant(),
    })
}
