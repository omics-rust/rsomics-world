use super::{
    dihedrals::{self, Angle},
    view::View,
};
use crate::model::{Namespace, Structure};
use serde_json::Value;
use std::{fs, path::Path};

const TORSION_ABS: f64 = 1e-8;
const TORSION_REL: f64 = 1e-10;

fn angle(actual: &Angle, reference: &Value, warnings: bool) {
    match actual {
        Angle::Defined(value) => {
            let expected = reference.as_f64().expect("defined source angle");
            assert!(
                (value - expected).abs() <= TORSION_ABS + TORSION_REL * expected.abs(),
                "{value} != {expected}"
            );
        }
        Angle::Missing(reason) => {
            assert!(!reason.is_empty());
            assert!(reference.is_null());
        }
        Angle::Degenerate => {
            assert!(
                reference.is_number() && warnings,
                "private degenerate class, no chosen public sentinel"
            );
        }
    }
}

#[test]
fn torsion_workflows_preserve_source_membership_defined_values_and_missing_classes() {
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/analysis");
    for (input, source) in [
        ("pdb-workflow.pdb", "pdb-workflow-dihedrals.json"),
        ("mmcif-workflow.cif", "mmcif-workflow-dihedrals.json"),
        (
            "small-pdb-workflow.pdb",
            "small-pdb-workflow-dihedrals.json",
        ),
        (
            "integrated-selected-workflow.cif",
            "integrated-selected-workflow-dihedrals.json",
        ),
        ("dihedrals-altloc.pdb", "dihedrals-altloc.pdb.json"),
    ] {
        let structure = Structure::read(&root.join(input)).unwrap();
        let view = View::new(
            &structure,
            &(0..structure.rows.len()).collect::<Vec<_>>(),
            Namespace::Author,
        )
        .unwrap();
        let reference: Value =
            serde_json::from_slice(&fs::read(root.join(source)).unwrap()).unwrap();
        let warnings = reference["warnings"]
            .as_array()
            .unwrap()
            .iter()
            .any(|w| w["type"] == "RuntimeWarning");
        let actual = dihedrals::compute(&view, 0);
        let source = &reference["result"];
        assert_eq!(
            actual.rows.len(),
            source["rows"].as_array().unwrap().len(),
            "{input}"
        );
        let source_key = |r: &Value| {
            r.as_array().unwrap()[2..]
                .iter()
                .map(|v| {
                    v.as_str()
                        .map(str::to_owned)
                        .unwrap_or_else(|| v.to_string())
                })
                .collect::<Vec<_>>()
        };
        let native_key = |index: usize| {
            let id = view.identity(index);
            vec![
                id.author_chain.value.unwrap_or(" ".into()),
                if id.hetero.is_empty() {
                    " ".into()
                } else {
                    id.hetero
                },
                id.author_sequence.value.unwrap(),
                id.insertion.value.unwrap_or(" ".into()),
                id.component,
            ]
        };
        let peptide_keys = actual
            .peptides
            .iter()
            .map(|p| p.iter().map(|&r| native_key(r)).collect::<Vec<_>>())
            .collect::<Vec<_>>();
        assert_eq!(
            peptide_keys,
            source["peptides"]
                .as_array()
                .unwrap()
                .iter()
                .map(|p| p
                    .as_array()
                    .unwrap()
                    .iter()
                    .map(source_key)
                    .collect::<Vec<_>>())
                .collect::<Vec<_>>(),
            "{input}"
        );
        for (row, source) in actual.rows.iter().zip(source["rows"].as_array().unwrap()) {
            assert_eq!(native_key(row.residue), source_key(&source["residue"]));
            angle(&row.phi, &source["backbone"]["phi_radians"], warnings);
            angle(&row.psi, &source["backbone"]["psi_radians"], warnings);
            angle(&row.omega, &source["backbone"]["omega_radians"], warnings);
            for (i, chi) in row.chi.iter().enumerate() {
                angle(
                    chi,
                    &source["sidechain"][format!("chi{}", i + 1)]["radians"],
                    warnings,
                );
            }
        }
    }
    for (input, golden) in [
        (
            "contacts-1crn.pdb",
            "legacy-dihedrals-1crn.dihedrals.tsv.json",
        ),
        (
            "dihedrals-altloc.pdb",
            "legacy-dihedrals-altloc.dihedrals.tsv.json",
        ),
    ] {
        let structure = Structure::read(&root.join(input)).unwrap();
        let view = View::new(
            &structure,
            &(0..structure.rows.len()).collect::<Vec<_>>(),
            Namespace::Author,
        )
        .unwrap();
        let actual = dihedrals::compute(&view, 0);
        let reference: Value =
            serde_json::from_slice(&fs::read(root.join(golden)).unwrap()).unwrap();
        let lines = reference["result"]["stdout"]
            .as_str()
            .unwrap()
            .lines()
            .skip(1)
            .collect::<Vec<_>>();
        assert_eq!(actual.rows.len(), lines.len());
        for (row, line) in actual.rows.iter().zip(lines) {
            let fields = line.split('\t').collect::<Vec<_>>();
            let values = std::iter::once(&row.phi)
                .chain(std::iter::once(&row.psi))
                .chain(std::iter::once(&row.omega))
                .chain(row.chi.iter());
            for (angle, expected) in values.zip(&fields[3..]) {
                match angle {
                    Angle::Defined(radians) => {
                        let expected = expected.parse::<f64>().unwrap();
                        let limit =
                            0.5e-4 + (TORSION_ABS + TORSION_REL * radians.abs()).to_degrees();
                        assert!((radians.to_degrees() - expected).abs() <= limit);
                    }
                    Angle::Missing(_) => assert_eq!(*expected, "NA"),
                    Angle::Degenerate => panic!("unqualified legacy degenerate angle"),
                }
            }
        }
    }
}
