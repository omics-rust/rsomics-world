use std::collections::HashMap;

use rayon::prelude::*;
use rsomics_common::{Result, RsomicsError};

/// Returns sorted unique i<j candidates; the caller applies its exact metric.
/// Index storage is O(n); candidate storage is O(k), possibly quadratic.
pub(crate) fn candidates(points: &[[f64; 3]], reach: f64) -> Result<Vec<(usize, usize)>> {
    if !reach.is_finite() || reach <= 0.0 {
        return Err(RsomicsError::InvalidInput(
            "spatial reach must be finite and positive".into(),
        ));
    }
    let mut cells: HashMap<[i64; 3], Vec<usize>> = HashMap::new();
    for (index, &point) in points.iter().enumerate() {
        cells.entry(cell(point, reach)?).or_default().push(index);
    }
    // Widen both the radius and endpoints before applying the same monotone map.
    let expanded = reach.next_up();
    let mut pairs = points
        .par_iter()
        .enumerate()
        .try_fold(Vec::new, |mut pairs, (index, point)| -> Result<_> {
            let lower = cell(point.map(|v| (v - expanded).next_down()), reach)?;
            let upper = cell(point.map(|v| (v + expanded).next_up()), reach)?;
            for x in lower[0]..=upper[0] {
                for y in lower[1]..=upper[1] {
                    for z in lower[2]..=upper[2] {
                        if let Some(nearby) = cells.get(&[x, y, z]) {
                            pairs.extend(
                                nearby
                                    .iter()
                                    .filter(|&&other| index < other)
                                    .map(|&other| (index, other)),
                            );
                        }
                    }
                }
            }
            Ok(pairs)
        })
        .try_reduce(Vec::new, |mut left, mut right| {
            left.append(&mut right);
            Ok(left)
        })?;
    pairs.sort_unstable();
    Ok(pairs)
}

fn cell(point: [f64; 3], reach: f64) -> Result<[i64; 3]> {
    const LIMIT: f64 = (1_u64 << 50) as f64;
    let mut key = [0; 3];
    for axis in 0..3 {
        let normalized = point[axis] / reach;
        if !normalized.is_finite() || normalized.abs() > LIMIT {
            return Err(RsomicsError::InvalidInput(
                "spatial coordinates and query endpoints must lie within the finite ±2^50 cell domain"
                    .into(),
            ));
        }
        key[axis] = normalized.floor() as i64;
    }
    Ok(key)
}

#[cfg(test)]
mod tests {
    use super::candidates;

    #[test]
    fn covers_nearby_pairs_in_source_order_across_worker_counts() {
        let mut points = (0..160)
            .map(|i| {
                [
                    ((i * 37) % 43) as f64 / 8.0 - 2.5,
                    ((i * 19) % 31) as f64 / 8.0 - 1.75,
                    ((i * 11) % 23) as f64 / 8.0 - 1.25,
                ]
            })
            .collect::<Vec<_>>();
        points.extend([
            [-1.0e-16, 0.0, 0.0],
            [1.0, 0.0, 0.0],
            [0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0],
            [-1.0e15, 0.0, 0.0],
            [-1.0e15 + 1.0, 0.0, 0.0],
        ]);
        let expected = (0..points.len())
            .flat_map(|i| {
                let points = &points;
                (i + 1..points.len()).filter_map(move |j| {
                    let delta = [
                        points[i][0] - points[j][0],
                        points[i][1] - points[j][1],
                        points[i][2] - points[j][2],
                    ];
                    let squared = delta.iter().map(|v| v * v).sum::<f64>();
                    (squared <= 1.0).then_some((i, j))
                })
            })
            .collect::<Vec<_>>();
        assert!(expected.contains(&(160, 161)));
        let mut first = None;
        for workers in [1, 4] {
            let pool = rayon::ThreadPoolBuilder::new()
                .num_threads(workers)
                .build()
                .unwrap();
            let pairs = pool.install(|| candidates(&points, 1.0)).unwrap();
            assert!(pairs.iter().all(|&(i, j)| i < j && j < points.len()));
            assert!(pairs.windows(2).all(|pair| pair[0] < pair[1]));
            assert!(
                expected
                    .iter()
                    .all(|pair| pairs.binary_search(pair).is_ok())
            );
            if let Some(first) = &first {
                assert_eq!(first, &pairs);
            } else {
                first = Some(pairs);
            }
        }
    }

    #[test]
    fn indexes_occupied_cells_without_a_bounding_box_and_rejects_invalid_domain() {
        let mut points = (0..4096)
            .map(|i| [i as f64 * 1.0e8, 0.0, 0.0])
            .collect::<Vec<_>>();
        points.push(points[0]);
        assert_eq!(candidates(&points, 0.01).unwrap(), vec![(0, 4096)]);
        assert!(candidates(&[], 1.0).unwrap().is_empty());
        assert!(candidates(&[[0.0; 3]], 1.0).unwrap().is_empty());
        for reach in [0.0, -1.0, f64::NAN, f64::INFINITY] {
            assert!(candidates(&[], reach).is_err());
        }
        for point in [[f64::NAN, 0.0, 0.0], [2.0_f64.powi(51), 0.0, 0.0]] {
            assert!(candidates(&[point], 1.0).is_err());
        }
    }
}
