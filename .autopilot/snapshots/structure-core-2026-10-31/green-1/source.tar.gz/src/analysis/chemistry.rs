fn capitalize(s: &str) -> String {
    let mut chars = s.chars();
    match chars.next() {
        None => String::new(),
        Some(first) => first.to_uppercase().collect::<String>() + &chars.as_str().to_lowercase(),
    }
}

pub fn atom_weight(capitalized: &str) -> Option<f64> {
    let w = match capitalized {
        "Ac" => 227.03,
        "Ag" => 107.8682,
        "Al" => 26.981538,
        "Am" => 243.06,
        "Ar" => 39.948,
        "As" => 74.9216,
        "At" => 209.99,
        "Au" => 196.96655,
        "B" => 10.811,
        "Ba" => 137.327,
        "Be" => 9.012182,
        "Bh" => 264.12,
        "Bi" => 208.98038,
        "Bk" => 247.07,
        "Br" => 79.904,
        "C" => 12.0107,
        "Ca" => 40.078,
        "Cd" => 112.411,
        "Ce" => 140.116,
        "Cf" => 251.08,
        "Cl" => 35.453,
        "Cm" => 247.07,
        "Co" => 58.9332,
        "Cr" => 51.9961,
        "Cs" => 132.90545,
        "Cu" => 63.546,
        "D" => 2.0141,
        "Db" => 262.11,
        "Dy" => 162.5,
        "Er" => 167.259,
        "Es" => 252.08,
        "Eu" => 151.964,
        "F" => 18.9984032,
        "Fe" => 55.845,
        "Fm" => 257.1,
        "Fr" => 223.02,
        "Ga" => 69.723,
        "Gd" => 157.25,
        "Ge" => 72.64,
        "H" => 1.00794,
        "He" => 4.002602,
        "Hf" => 178.49,
        "Hg" => 200.59,
        "Ho" => 164.93032,
        "Hs" => 269.13,
        "I" => 126.90447,
        "In" => 114.818,
        "Ir" => 192.217,
        "K" => 39.0983,
        "Kr" => 83.8,
        "La" => 138.9055,
        "Li" => 6.941,
        "Lr" => 262.11,
        "Lu" => 174.967,
        "Md" => 258.1,
        "Mg" => 24.305,
        "Mn" => 54.938049,
        "Mo" => 95.94,
        "Mt" => 268.14,
        "N" => 14.0067,
        "Na" => 22.98977,
        "Nb" => 92.90638,
        "Nd" => 144.24,
        "Ne" => 20.1797,
        "Ni" => 58.6934,
        "No" => 259.1,
        "Np" => 237.05,
        "O" => 15.9994,
        "Os" => 190.23,
        "P" => 30.973761,
        "Pa" => 231.03588,
        "Pb" => 207.2,
        "Pd" => 106.42,
        "Pm" => 145.0,
        "Po" => 208.98,
        "Pr" => 140.90765,
        "Pt" => 195.078,
        "Pu" => 244.06,
        "Ra" => 226.03,
        "Rb" => 85.4678,
        "Re" => 186.207,
        "Rf" => 261.11,
        "Rh" => 102.9055,
        "Rn" => 222.02,
        "Ru" => 101.07,
        "S" => 32.065,
        "Sb" => 121.76,
        "Sc" => 44.95591,
        "Se" => 78.96,
        "Sg" => 266.12,
        "Si" => 28.0855,
        "Sm" => 150.36,
        "Sn" => 118.71,
        "Sr" => 87.62,
        "Ta" => 180.9479,
        "Tb" => 158.92534,
        "Tc" => 98.0,
        "Te" => 127.6,
        "Th" => 232.0381,
        "Ti" => 47.867,
        "Tl" => 204.3833,
        "Tm" => 168.93421,
        "U" => 238.02891,
        "V" => 50.9415,
        "W" => 183.84,
        "Xe" => 131.293,
        "Y" => 88.90585,
        "Yb" => 173.04,
        "Zn" => 65.39,
        "Zr" => 91.224,
        _ => return None,
    };
    Some(w)
}

pub fn assign_element(name: &str, fullname: &str, col_element: &str) -> String {
    if !col_element.is_empty() {
        let cap = capitalize(col_element);
        if atom_weight(&cap).is_some() {
            return cap;
        }
    }

    let fb = fullname.as_bytes();
    let first_alpha = fb.first().is_some_and(|b| b.is_ascii_alphabetic());
    let tail_all_digits =
        fullname.chars().count() > 2 && fullname.chars().skip(2).all(|c| c.is_ascii_digit());

    let putative: String = if first_alpha && !tail_all_digits {
        name.trim().to_string()
    } else if name.as_bytes().first().is_some_and(|b| b.is_ascii_digit()) {
        name.chars().nth(1).map(String::from).unwrap_or_default()
    } else {
        name.chars().next().map(String::from).unwrap_or_default()
    };

    let cap = capitalize(&putative);
    if atom_weight(&cap).is_some() {
        cap
    } else {
        "X".to_string()
    }
}

pub fn chi_atoms(resname: &str) -> &'static [[&'static str; 4]] {
    match resname {
        "ARG" => &[
            ["N", "CA", "CB", "CG"],
            ["CA", "CB", "CG", "CD"],
            ["CB", "CG", "CD", "NE"],
            ["CG", "CD", "NE", "CZ"],
            ["CD", "NE", "CZ", "NH1"],
        ],
        "ASN" => &[["N", "CA", "CB", "CG"], ["CA", "CB", "CG", "OD1"]],
        "ASP" => &[["N", "CA", "CB", "CG"], ["CA", "CB", "CG", "OD1"]],
        "CYS" => &[["N", "CA", "CB", "SG"]],
        "GLN" => &[
            ["N", "CA", "CB", "CG"],
            ["CA", "CB", "CG", "CD"],
            ["CB", "CG", "CD", "OE1"],
        ],
        "GLU" => &[
            ["N", "CA", "CB", "CG"],
            ["CA", "CB", "CG", "CD"],
            ["CB", "CG", "CD", "OE1"],
        ],
        "HIS" => &[["N", "CA", "CB", "CG"], ["CA", "CB", "CG", "ND1"]],
        "ILE" => &[["N", "CA", "CB", "CG1"], ["CA", "CB", "CG1", "CD1"]],
        "LEU" => &[["N", "CA", "CB", "CG"], ["CA", "CB", "CG", "CD1"]],
        "LYS" => &[
            ["N", "CA", "CB", "CG"],
            ["CA", "CB", "CG", "CD"],
            ["CB", "CG", "CD", "CE"],
            ["CG", "CD", "CE", "NZ"],
        ],
        "MET" => &[
            ["N", "CA", "CB", "CG"],
            ["CA", "CB", "CG", "SD"],
            ["CB", "CG", "SD", "CE"],
        ],
        "PHE" => &[["N", "CA", "CB", "CG"], ["CA", "CB", "CG", "CD1"]],
        "PRO" => &[["N", "CA", "CB", "CG"], ["CA", "CB", "CG", "CD"]],
        "SER" => &[["N", "CA", "CB", "OG"]],
        "THR" => &[["N", "CA", "CB", "OG1"]],
        "TRP" => &[["N", "CA", "CB", "CG"], ["CA", "CB", "CG", "CD1"]],
        "TYR" => &[["N", "CA", "CB", "CG"], ["CA", "CB", "CG", "CD1"]],
        "VAL" => &[["N", "CA", "CB", "CG1"]],
        _ => &[],
    }
}

pub fn standard(name: &str) -> bool {
    matches!(
        name,
        "ALA"
            | "ARG"
            | "ASN"
            | "ASP"
            | "CYS"
            | "GLN"
            | "GLU"
            | "GLY"
            | "HIS"
            | "ILE"
            | "LEU"
            | "LYS"
            | "MET"
            | "PHE"
            | "PRO"
            | "SER"
            | "THR"
            | "TRP"
            | "TYR"
            | "VAL"
    )
}
