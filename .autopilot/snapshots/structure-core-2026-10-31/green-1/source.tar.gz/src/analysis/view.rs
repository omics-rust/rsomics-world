use std::collections::HashMap;

use rsomics_common::Result;
use serde::Serialize;

use super::chemistry;
use crate::field::{Identifier, Key, State};
use crate::invalid;
use crate::model::{Format, Handle, Namespace, Structure, finite};

#[derive(Clone, Copy)]
pub(crate) struct Columns {
    pub chain: Handle,
    pub seq: Handle,
    pub comp: Handle,
    pub atom: Handle,
    pub alt: Handle,
    pub ins: Handle,
    pub group: Handle,
    pub occupancy: Handle,
    pub element: Handle,
}

pub(crate) struct Slot<'a> {
    pub name: &'a str,
    pub first: usize,
    pub selected: usize,
    pub alternates: Vec<usize>,
}

impl Slot<'_> {
    pub fn rows(&self) -> impl Iterator<Item = usize> + '_ {
        std::iter::once(self.first).chain(self.alternates.iter().copied())
    }
}

pub(crate) struct Variant<'a> {
    pub name: &'a str,
    pub atoms: Vec<Slot<'a>>,
}

impl Variant<'_> {
    pub fn atom(&self, name: &str) -> Option<&Slot<'_>> {
        self.atoms.iter().find(|atom| atom.name == name)
    }
}

pub(crate) struct Residue<'a> {
    pub model: usize,
    pub chain: Key<'a>,
    pub hetero: &'a str,
    pub variants: Vec<Variant<'a>>,
    pub selected: usize,
}

impl<'a> Residue<'a> {
    pub fn variant(&self) -> &Variant<'a> {
        &self.variants[self.selected]
    }
    pub fn atom(&self, name: &str) -> Option<usize> {
        self.variant().atom(name).map(|a| a.selected)
    }
}

pub(crate) struct View<'a> {
    pub structure: &'a Structure,
    pub columns: Columns,
    pub residues: Vec<Residue<'a>>,
    pub row_residue: Vec<usize>,
}

#[derive(Clone, Copy)]
enum Grouping {
    Analysis(Namespace),
    Deposited,
}

#[derive(Eq, Hash, PartialEq)]
struct DepositedIdentity<'a> {
    author_chain: Key<'a>,
    label_chain: Key<'a>,
    author_sequence: Key<'a>,
    label_sequence: Key<'a>,
    unidentified_row: Option<usize>,
}

#[derive(Eq, Hash, PartialEq)]
struct ResidueKey<'a> {
    model: usize,
    chain: Key<'a>,
    sequence: Key<'a>,
    insertion: Key<'a>,
    hetero: &'a str,
    water: bool,
    deposited: Option<DepositedIdentity<'a>>,
}

#[derive(Serialize)]
pub(crate) struct ResidueIdentity {
    pub model_index: usize,
    pub representative_row: usize,
    pub author_chain: Identifier,
    pub label_chain: Identifier,
    pub author_sequence: Identifier,
    pub label_sequence: Identifier,
    pub insertion: Identifier,
    pub component: String,
    pub hetero: String,
}

impl<'a> View<'a> {
    pub fn new(structure: &'a Structure, rows: &[usize], namespace: Namespace) -> Result<Self> {
        Self::build(structure, rows, Grouping::Analysis(namespace))
    }

    pub fn highest_occupancy(structure: &'a Structure, rows: &[usize]) -> Result<Vec<usize>> {
        let view = Self::build(structure, rows, Grouping::Deposited)?;
        Ok(view
            .residues
            .iter()
            .flat_map(|r| &r.variant().atoms)
            .map(|a| a.selected)
            .collect())
    }

    fn build(structure: &'a Structure, rows: &[usize], grouping: Grouping) -> Result<Self> {
        let namespace = match grouping {
            Grouping::Analysis(namespace) => namespace,
            Grouping::Deposited => Namespace::Author,
        };
        let deposited = matches!(grouping, Grouping::Deposited);
        let prefix = match namespace {
            Namespace::Author => "auth",
            Namespace::Label => "label",
        };
        let names = match structure.format() {
            Format::Pdb => "auth",
            Format::Mmcif => "label",
        };
        let columns = Columns {
            chain: if deposited {
                structure.resolve("auth_asym_id")
            } else {
                structure.chain(namespace)?
            },
            seq: structure.resolve(&format!("{prefix}_seq_id")),
            comp: structure.resolve(&format!("{names}_comp_id")),
            atom: structure.resolve(&format!("{names}_atom_id")),
            alt: structure.resolve("label_alt_id"),
            ins: structure.resolve("pdbx_PDB_ins_code"),
            group: structure.resolve("group_PDB"),
            occupancy: structure.resolve("occupancy"),
            element: structure.resolve("type_symbol"),
        };
        if !deposited && matches!(columns.seq, Handle::Absent) {
            return Err(invalid("analysis residue identity is absent"));
        }
        for (name, column) in [("component", columns.comp), ("atom name", columns.atom)] {
            if matches!(column, Handle::Absent) {
                return Err(invalid(format!("analysis {name} is absent")));
            }
        }
        let mut view = Self {
            structure,
            columns,
            residues: Vec::new(),
            row_residue: vec![usize::MAX; structure.rows.len()],
        };
        let ordered = if deposited {
            Vec::new()
        } else {
            hierarchy_rows(structure, rows, columns.chain)
        };
        let rows = if deposited { rows } else { &ordered };
        let author_sequence = structure.resolve("auth_seq_id");
        let label_sequence = structure.resolve("label_seq_id");
        let mut groups = HashMap::new();
        for &row in rows {
            let field = |column| structure.field(row, column);
            if !deposited && namespace == Namespace::Label && structure.format() == Format::Mmcif {
                match field(columns.seq).state {
                    State::Inapplicable => continue,
                    State::Text => {}
                    _ => {
                        return Err(invalid(format!(
                            "row {row}: label residue identity is unavailable"
                        )));
                    }
                }
            }
            let name = field(columns.comp)
                .value
                .ok_or_else(|| invalid(format!("row {row}: component is missing")))?;
            let atom = field(columns.atom)
                .value
                .ok_or_else(|| invalid(format!("row {row}: atom name is missing")))?;
            let hetero = if field(columns.group).value == Some("ATOM") {
                ""
            } else if matches!(name, "HOH" | "WAT") {
                "W"
            } else {
                name
            };
            let insertion = field(columns.ins);
            let insertion = if deposited || insertion.state == State::Text {
                insertion.key()
            } else {
                Key {
                    state: State::Blank,
                    value: None,
                }
            };
            let model = structure.rows[row].model;
            let chain = field(columns.chain).key();
            let key = ResidueKey {
                model,
                chain,
                sequence: field(columns.seq).key(),
                insertion,
                hetero,
                water: !hetero.is_empty() && matches!(name, "HOH" | "WAT"),
                deposited: deposited.then(|| DepositedIdentity {
                    author_chain: field(structure.identity.author_chain).key(),
                    label_chain: field(structure.identity.label_chain).key(),
                    author_sequence: field(author_sequence).key(),
                    label_sequence: field(label_sequence).key(),
                    unidentified_row: (field(author_sequence).value.is_none()
                        && field(label_sequence).value.is_none())
                    .then_some(row),
                }),
            };
            let next = view.residues.len();
            let index = *groups.entry(key).or_insert_with(|| {
                view.residues.push(Residue {
                    model,
                    chain,
                    hetero,
                    variants: Vec::new(),
                    selected: 0,
                });
                next
            });
            view.row_residue[row] = index;
            let residue = &mut view.residues[index];
            let variant = match residue.variants.iter().position(|v| v.name == name) {
                Some(index) => index,
                None => {
                    residue.variants.push(Variant {
                        name,
                        atoms: Vec::new(),
                    });
                    residue.variants.len() - 1
                }
            };
            residue.selected = variant;
            let atoms = &mut residue.variants[variant].atoms;
            if let Some(slot) = atoms.iter_mut().find(|slot| slot.name == atom) {
                if slot.rows().any(|other| {
                    field(columns.alt).key() == structure.field(other, columns.alt).key()
                }) {
                    return Err(invalid(format!(
                        "row {row}: duplicate atom/conformer identity"
                    )));
                }
                let occupancy = finite(field(columns.occupancy), row, "alternate occupancy")?;
                let previous = finite(
                    structure.field(slot.selected, columns.occupancy),
                    slot.selected,
                    "alternate occupancy",
                )?;
                if occupancy > previous {
                    slot.selected = row;
                }
                slot.alternates.push(row);
            } else {
                atoms.push(Slot {
                    name: atom,
                    first: row,
                    selected: row,
                    alternates: Vec::new(),
                });
            }
        }
        if !deposited && view.residues.is_empty() {
            return Err(invalid(
                "analysis retained no residues in the requested namespace",
            ));
        }
        Ok(view)
    }

    pub fn coordinate(&self, row: usize) -> [f64; 3] {
        self.structure.rows[row]
            .coordinate
            .map(|v| f64::from(v as f32))
    }

    pub fn validate_f32(&self, rows: &[usize]) -> Result<()> {
        for &row in rows {
            if self.structure.rows[row]
                .coordinate
                .iter()
                .any(|&value| !(value as f32).is_finite())
            {
                return Err(invalid(format!(
                    "row {row}: coordinate exceeds float32 analysis profile"
                )));
            }
        }
        Ok(())
    }

    pub fn alt(&self, row: usize) -> &str {
        self.structure
            .field(row, self.columns.alt)
            .value
            .unwrap_or(" ")
    }

    pub fn conformers(&self, slot: &Slot<'_>) -> Vec<usize> {
        let mut rows = slot.rows().collect::<Vec<_>>();
        rows.sort_by_key(|&row| self.alt(row));
        rows
    }

    pub fn element(&self, row: usize) -> String {
        let atom = self.structure.field(row, self.columns.atom);
        let fullname = if self.structure.format() == Format::Pdb {
            atom.raw
        } else {
            atom.value
        };
        chemistry::assign_element(
            atom.value.unwrap_or(""),
            fullname.unwrap_or(""),
            self.structure
                .field(row, self.columns.element)
                .value
                .unwrap_or(""),
        )
    }

    pub fn selected_atoms(&self, model: usize, ca_only: bool) -> Vec<usize> {
        self.residues
            .iter()
            .filter(|r| r.model == model && chemistry::standard(r.variant().name))
            .flat_map(|r| r.variant().atoms.iter())
            .map(|a| a.selected)
            .filter(|&row| {
                !matches!(self.element(row).as_str(), "H" | "D")
                    && (!ca_only
                        || self.structure.field(row, self.columns.atom).value == Some("CA"))
            })
            .collect()
    }

    pub fn all_atoms(&self, model: usize) -> Vec<usize> {
        self.residues
            .iter()
            .filter(|r| r.model == model)
            .flat_map(|r| &r.variants)
            .flat_map(|v| &v.atoms)
            .flat_map(|a| self.conformers(a))
            .collect()
    }

    pub fn identity(&self, residue: usize) -> ResidueIdentity {
        let r = &self.residues[residue];
        let row = r.variant().atoms[0].selected;
        let id = |name| {
            self.structure
                .field(row, self.structure.resolve(name))
                .key()
                .into()
        };
        ResidueIdentity {
            model_index: r.model,
            representative_row: row,
            author_chain: id("auth_asym_id"),
            label_chain: id("label_asym_id"),
            author_sequence: id("auth_seq_id"),
            label_sequence: id("label_seq_id"),
            insertion: id("pdbx_PDB_ins_code"),
            component: r.variant().name.to_owned(),
            hetero: if r.hetero.is_empty() {
                String::new()
            } else if matches!(r.variant().name, "HOH" | "WAT") {
                "W".to_owned()
            } else {
                format!("H_{}", r.hetero)
            },
        }
    }

    pub fn peptide_ca(&self, model: usize) -> Vec<Vec<usize>> {
        self.peptides(model, |a, b| {
            let (Some(p), Some(n)) = (a.variant().atom("CA"), b.variant().atom("CA")) else {
                return false;
            };
            p.rows().any(|p| {
                n.rows()
                    .any(|n| atom_distance(self.coordinate(p), self.coordinate(n)) < 4.3_f32)
            })
        })
    }

    pub fn peptides(
        &self,
        model: usize,
        mut connected: impl FnMut(&Residue<'_>, &Residue<'_>) -> bool,
    ) -> Vec<Vec<usize>> {
        let mut chains: Vec<(Key<'_>, Vec<usize>)> = Vec::new();
        for (index, r) in self
            .residues
            .iter()
            .enumerate()
            .filter(|(_, r)| r.model == model)
        {
            if let Some((_, rows)) = chains.iter_mut().find(|(key, _)| *key == r.chain) {
                rows.push(index)
            } else {
                chains.push((r.chain, vec![index]));
            }
        }
        let mut peptides = Vec::new();
        for (_, chain) in chains {
            let mut current = Vec::new();
            for pair in chain.windows(2) {
                let (a, b) = (&self.residues[pair[0]], &self.residues[pair[1]]);
                if chemistry::standard(a.variant().name)
                    && chemistry::standard(b.variant().name)
                    && connected(a, b)
                {
                    if current.is_empty() {
                        current.push(pair[0]);
                    }
                    current.push(pair[1]);
                } else if !current.is_empty() {
                    peptides.push(std::mem::take(&mut current));
                }
            }
            if !current.is_empty() {
                peptides.push(current);
            }
        }
        peptides
    }
}

fn hierarchy_rows(structure: &Structure, rows: &[usize], chain: Handle) -> Vec<usize> {
    let mut models = vec![Vec::<Vec<usize>>::new(); structure.models.len()];
    let mut indices = HashMap::new();
    for &row in rows {
        let model = structure.rows[row].model;
        let chains = &mut models[model];
        let key = (model, structure.field(row, chain).key());
        let index = *indices.entry(key).or_insert_with(|| {
            chains.push(Vec::new());
            chains.len() - 1
        });
        chains[index].push(row);
    }
    models.into_iter().flatten().flatten().collect()
}

pub(crate) fn atom_distance(a: [f64; 3], b: [f64; 3]) -> f32 {
    let d = std::array::from_fn::<_, 3, _>(|i| a[i] as f32 - b[i] as f32);
    (d[0] * d[0] + d[1] * d[1] + d[2] * d[2]).sqrt()
}
