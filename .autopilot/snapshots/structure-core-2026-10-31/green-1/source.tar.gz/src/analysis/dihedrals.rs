use std::collections::HashMap;

use super::{
    chemistry,
    math::*,
    view::{View, atom_distance},
};

#[derive(Debug)]
pub(crate) enum Angle {
    Defined(f64),
    Missing(&'static str),
    Degenerate,
}

pub(crate) struct TorsionRow {
    pub residue: usize,
    pub phi: Angle,
    pub psi: Angle,
    pub omega: Angle,
    pub chi: Vec<Angle>,
}

pub(crate) struct Torsions {
    pub peptides: Vec<Vec<usize>>,
    pub rows: Vec<TorsionRow>,
}

fn torsion(points: [[f64; 3]; 4]) -> Angle {
    let ab = sub(points[0], points[1]);
    let cb = sub(points[2], points[1]);
    let db = sub(points[3], points[2]);
    let u = cross(ab, cb);
    let v = cross(db, cb);
    if norm(u) == 0. || norm(v) == 0. || norm(cb) == 0. {
        return Angle::Degenerate;
    }
    let w = cross(u, v);
    let mut value = angle(u, v);
    if angle(cb, w) > 0.001 {
        value = -value;
    }
    Angle::Defined(value)
}

pub(crate) fn compute(view: &View<'_>, model: usize) -> Torsions {
    let mut overrides = HashMap::new();
    let peptides = view.peptides(model, |a, b| {
        let (Some(c), Some(n)) = (a.variant().atom("C"), b.variant().atom("N")) else {
            return false;
        };
        for nn in view.conformers(n) {
            for cc in view.conformers(c) {
                let (na, ca) = (view.alt(nn), view.alt(cc));
                if (na == ca || na == " " || ca == " ")
                    && atom_distance(view.coordinate(nn), view.coordinate(cc)) < 1.8_f32
                {
                    overrides.insert(c.selected, cc);
                    overrides.insert(n.selected, nn);
                    return true;
                }
            }
        }
        false
    });
    let atom = |r: usize, name: &str| {
        view.residues[r]
            .atom(name)
            .map(|row| *overrides.get(&row).unwrap_or(&row))
    };
    let angle = |rows: [Option<usize>; 4]| match rows.into_iter().collect::<Option<Vec<_>>>() {
        Some(rows) => torsion(std::array::from_fn(|i| view.coordinate(rows[i]))),
        None => Angle::Missing("missing atom"),
    };
    let mut locations = HashMap::new();
    for (p, rows) in peptides.iter().enumerate() {
        for (i, &r) in rows.iter().enumerate() {
            locations.insert(r, (p, i));
        }
    }
    let rows = view
        .residues
        .iter()
        .enumerate()
        .filter(|(_, r)| r.model == model && chemistry::standard(r.variant().name))
        .map(|(r, residue)| {
            let (phi, psi, omega) = if let Some(&(p, i)) = locations.get(&r) {
                let peptide = &peptides[p];
                let previous = i.checked_sub(1).map(|i| peptide[i]);
                let next = peptide.get(i + 1).copied();
                let complete =
                    atom(r, "N").is_some() && atom(r, "CA").is_some() && atom(r, "C").is_some();
                let phi = if !complete {
                    Angle::Missing("missing backbone atom")
                } else if let Some(previous) = previous {
                    angle([
                        atom(previous, "C"),
                        atom(r, "N"),
                        atom(r, "CA"),
                        atom(r, "C"),
                    ])
                } else {
                    Angle::Missing("peptide terminus")
                };
                let psi = if !complete {
                    Angle::Missing("missing backbone atom")
                } else if let Some(next) = next {
                    angle([atom(r, "N"), atom(r, "CA"), atom(r, "C"), atom(next, "N")])
                } else {
                    Angle::Missing("peptide terminus")
                };
                let omega = if let Some(previous) = previous {
                    angle([
                        atom(previous, "CA"),
                        atom(previous, "C"),
                        atom(r, "N"),
                        atom(r, "CA"),
                    ])
                } else {
                    Angle::Missing("peptide terminus")
                };
                (phi, psi, omega)
            } else {
                (
                    Angle::Missing("not in PPBuilder peptide"),
                    Angle::Missing("not in PPBuilder peptide"),
                    Angle::Missing("not in PPBuilder peptide"),
                )
            };
            let chi = chemistry::chi_atoms(residue.variant().name)
                .iter()
                .map(|names| angle(names.map(|name| atom(r, name))))
                .collect();
            TorsionRow {
                residue: r,
                phi,
                psi,
                omega,
                chi,
            }
        })
        .collect();
    Torsions { peptides, rows }
}
