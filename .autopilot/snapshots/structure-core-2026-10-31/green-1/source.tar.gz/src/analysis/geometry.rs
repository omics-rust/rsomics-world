use rsomics_common::Result;
use serde::Serialize;

use super::{chemistry, view::View};
use crate::invalid;

#[derive(Serialize)]
pub(crate) struct Geometry {
    pub model_index: usize,
    pub source_rows: Vec<usize>,
    pub atom_count: usize,
    pub residue_count: usize,
    pub total_mass: f64,
    pub center_of_mass: [f32; 3],
    pub centroid: [f32; 3],
    pub radius_of_gyration: f32,
    pub radius_of_gyration_geometric: f32,
    pub bbox_min: [f32; 3],
    pub bbox_max: [f32; 3],
    pub bbox_dim: [f32; 3],
}

pub(crate) fn compute(view: &View<'_>, model: usize, ca_only: bool) -> Result<Geometry> {
    let source_rows = view
        .all_atoms(model)
        .into_iter()
        .filter(|&row| {
            !ca_only || {
                view.structure.field(row, view.columns.atom).value == Some("CA")
                    && view.residues[view.row_residue[row]].hetero.is_empty()
            }
        })
        .collect::<Vec<_>>();
    if source_rows.is_empty() {
        return Err(invalid("geometry selection retained no atoms"));
    }
    let mut coordinates = Vec::with_capacity(source_rows.len());
    let mut masses = Vec::with_capacity(source_rows.len());
    let mut total_mass = 0.;
    let mut residue_count = 0;
    let mut previous = None;
    for &row in &source_rows {
        let element = view.element(row);
        let mass = chemistry::atom_weight(&element)
            .ok_or_else(|| invalid(format!("row {row}: unknown atomic mass for {element}")))?;
        total_mass += mass;
        masses.push(mass as f32);
        let coordinate = view.structure.rows[row].coordinate.map(|v| v as f32);
        if coordinate.iter().any(|v| !v.is_finite()) {
            return Err(invalid("coordinate exceeds float32 analysis profile"));
        }
        coordinates.push(coordinate);
        let residue = view.row_residue[row];
        if previous != Some(residue) {
            residue_count += 1;
            previous = Some(residue);
        }
    }
    let weight = pairwise(0..masses.len(), &|i| masses[i]);
    let mut numerator = [0_f32; 3];
    let mut sum = [0_f32; 3];
    let mut bbox_min = [f32::INFINITY; 3];
    let mut bbox_max = [f32::NEG_INFINITY; 3];
    for (coordinate, &mass) in coordinates.iter().zip(&masses) {
        for axis in 0..3 {
            numerator[axis] += coordinate[axis] * mass;
            sum[axis] += coordinate[axis];
            bbox_min[axis] = bbox_min[axis].min(coordinate[axis]);
            bbox_max[axis] = bbox_max[axis].max(coordinate[axis]);
        }
    }
    let center_of_mass = numerator.map(|v| v / weight);
    let centroid = sum.map(|v| v / source_rows.len() as f32);
    let squared = |i: usize, center: [f32; 3]| {
        let coordinate = coordinates[i];
        let delta = std::array::from_fn::<_, 3, _>(|i| coordinate[i] - center[i]);
        delta[0] * delta[0] + delta[1] * delta[1] + delta[2] * delta[2]
    };
    let moment = pairwise(0..coordinates.len(), &|i| {
        squared(i, center_of_mass) * masses[i]
    });
    let geometric = pairwise(0..coordinates.len(), &|i| squared(i, centroid));
    if center_of_mass
        .iter()
        .chain(&centroid)
        .any(|v| !v.is_finite())
        || !moment.is_finite()
        || !geometric.is_finite()
    {
        return Err(invalid("geometry exceeds finite float32 result range"));
    }
    Ok(Geometry {
        model_index: model,
        atom_count: source_rows.len(),
        residue_count,
        total_mass,
        center_of_mass,
        centroid,
        radius_of_gyration: (moment / weight).sqrt(),
        radius_of_gyration_geometric: (geometric / source_rows.len() as f32).sqrt(),
        bbox_min,
        bbox_max,
        bbox_dim: std::array::from_fn(|i| bbox_max[i] - bbox_min[i]),
        source_rows,
    })
}

fn pairwise(range: std::ops::Range<usize>, value: &impl Fn(usize) -> f32) -> f32 {
    let n = range.len();
    if n < 8 {
        return range.fold(-0_f32, |sum, i| sum + value(i));
    }
    if n > 128 {
        let mut half = n / 2;
        half -= half % 8;
        let mid = range.start + half;
        return pairwise(range.start..mid, value) + pairwise(mid..range.end, value);
    }
    let mut lanes = std::array::from_fn::<_, 8, _>(|i| value(range.start + i));
    let end = range.start + n - n % 8;
    for offset in (range.start + 8..end).step_by(8) {
        for (lane, sum) in lanes.iter_mut().enumerate() {
            *sum += value(offset + lane);
        }
    }
    let sum = ((lanes[0] + lanes[1]) + (lanes[2] + lanes[3]))
        + ((lanes[4] + lanes[5]) + (lanes[6] + lanes[7]));
    (end..range.end).fold(sum, |sum, i| sum + value(i))
}
