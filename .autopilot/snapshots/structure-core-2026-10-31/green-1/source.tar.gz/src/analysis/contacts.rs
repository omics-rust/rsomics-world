use clap::ValueEnum;
use rayon::prelude::*;
use rsomics_common::Result;
use serde::Serialize;

use super::{
    math, spatial,
    view::{ResidueIdentity, View},
};
use crate::invalid;

#[derive(Clone, Copy, Debug, ValueEnum, Serialize)]
#[serde(rename_all = "lowercase")]
pub(crate) enum Level {
    Atom,
    Residue,
}

#[derive(Serialize)]
pub(crate) struct Contacts {
    pub model_index: usize,
    pub level: Level,
    pub cutoff: f64,
    pub source_rows: Vec<usize>,
    pub pairs: Vec<[usize; 2]>,
    pub residues: Vec<ResidueIdentity>,
}

pub(crate) fn compute(
    view: &View<'_>,
    model: usize,
    cutoff: f64,
    level: Level,
    ca_only: bool,
    min_separation: u64,
) -> Result<Contacts> {
    let source_rows = view.selected_atoms(model, ca_only);
    let points = source_rows
        .iter()
        .map(|&row| view.coordinate(row))
        .collect::<Vec<_>>();
    let numbers = if min_separation > 0 {
        let column = view.structure.resolve("auth_seq_id");
        let mut numbers = vec![None; view.residues.len()];
        for &row in &source_rows {
            let number = &mut numbers[view.row_residue[row]];
            if number.is_none() {
                *number = Some(
                    view.structure
                        .field(row, column)
                        .value
                        .ok_or_else(|| {
                            invalid("author sequence separation requires numeric author IDs")
                        })?
                        .parse::<i64>()?,
                );
            }
        }
        numbers
    } else {
        Vec::new()
    };
    let candidates = spatial::candidates(&points, cutoff)?;
    let mut pairs = candidates
        .into_par_iter()
        .filter_map(|(a, b)| {
            let delta = math::sub(points[a], points[b]);
            if math::dot(delta, delta) > cutoff * cutoff {
                return None;
            }
            let (ra, rb) = (
                view.row_residue[source_rows[a]],
                view.row_residue[source_rows[b]],
            );
            if min_separation > 0
                && view.residues[ra].chain == view.residues[rb].chain
                && numbers[ra]
                    .expect("selected residue number")
                    .abs_diff(numbers[rb].expect("selected residue number"))
                    < min_separation
            {
                return None;
            }
            let (a, b) = match level {
                Level::Atom => (source_rows[a], source_rows[b]),
                Level::Residue => {
                    if ra == rb {
                        return None;
                    }
                    (
                        view.residues[ra].variant().atoms[0].selected,
                        view.residues[rb].variant().atoms[0].selected,
                    )
                }
            };
            Some(if a < b { [a, b] } else { [b, a] })
        })
        .collect::<Vec<_>>();
    pairs.par_sort_unstable();
    pairs.dedup();
    Ok(Contacts {
        model_index: model,
        level,
        cutoff,
        source_rows,
        pairs,
        residues: view
            .residues
            .iter()
            .enumerate()
            .filter(|(_, r)| r.model == model)
            .map(|(i, _)| view.identity(i))
            .collect(),
    })
}
