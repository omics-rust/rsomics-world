pub(crate) fn sub(a: [f64; 3], b: [f64; 3]) -> [f64; 3] {
    std::array::from_fn(|i| a[i] - b[i])
}
pub(crate) fn add(a: [f64; 3], b: [f64; 3]) -> [f64; 3] {
    std::array::from_fn(|i| a[i] + b[i])
}
pub(crate) fn scale(a: [f64; 3], s: f64) -> [f64; 3] {
    a.map(|v| v * s)
}
pub(crate) fn dot(a: [f64; 3], b: [f64; 3]) -> f64 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}
pub(crate) fn cross(a: [f64; 3], b: [f64; 3]) -> [f64; 3] {
    [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]
}
pub(crate) fn norm(a: [f64; 3]) -> f64 {
    dot(a, a).sqrt()
}
pub(crate) fn normalized(a: [f64; 3]) -> [f64; 3] {
    let n = norm(a);
    if n == 0. { a } else { scale(a, 1. / n) }
}
pub(crate) fn angle(a: [f64; 3], b: [f64; 3]) -> f64 {
    let cosine = dot(a, b) / (norm(a) * norm(b));
    if cosine.is_nan() {
        std::f64::consts::PI
    } else {
        cosine.clamp(-1., 1.).acos()
    } // Bio Vector.angle's ordered min/max clamp maps NaN to -1.
}
