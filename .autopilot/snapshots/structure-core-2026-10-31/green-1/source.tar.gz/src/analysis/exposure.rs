use std::f64::consts::PI;

use rayon::prelude::*;
use rsomics_common::Result;
use serde::Serialize;

use super::{
    math::*,
    spatial,
    view::{ResidueIdentity, View, atom_distance},
};
use crate::invalid;

#[derive(Default, Serialize)]
pub(crate) struct Properties {
    #[serde(rename = "EXP_HSE_A_U")]
    pub alpha_up: Option<usize>,
    #[serde(rename = "EXP_HSE_A_D")]
    pub alpha_down: Option<usize>,
    #[serde(rename = "EXP_HSE_B_U")]
    pub beta_up: Option<usize>,
    #[serde(rename = "EXP_HSE_B_D")]
    pub beta_down: Option<usize>,
    #[serde(rename = "EXP_CN")]
    pub cn: Option<usize>,
    #[serde(rename = "EXP_CB_PCB_ANGLE")]
    pub cb_pcb_angle: Option<f64>,
}

#[derive(Serialize)]
pub(crate) struct ExposureRow {
    pub residue: ResidueIdentity,
    pub properties: Properties,
    pub selected_ca: Option<usize>,
    pub ca_connectivity_rows: Vec<usize>,
}

#[derive(Serialize)]
pub(crate) struct Exposure {
    pub model_index: usize,
    pub radius: f64,
    pub offset: usize,
    pub peptides: Vec<Vec<usize>>,
    pub rows: Vec<ExposureRow>,
}

fn beta(view: &View<'_>, residue: usize) -> Option<[f64; 3]> {
    let r = &view.residues[residue];
    let ca = view.coordinate(r.atom("CA")?);
    if r.variant().name != "GLY" {
        return Some(sub(view.coordinate(r.atom("CB")?), ca));
    }
    let n = sub(view.coordinate(r.atom("N")?), ca);
    let axis = normalized(sub(view.coordinate(r.atom("C")?), ca));
    let theta = -2. * PI / 3.;
    Some(add(
        add(scale(n, theta.cos()), scale(cross(axis, n), theta.sin())),
        scale(axis, dot(axis, n) * (1. - theta.cos())),
    ))
}

pub(crate) fn compute(
    view: &View<'_>,
    model: usize,
    radius: f64,
    offset: usize,
) -> Result<Exposure> {
    let r32 = radius as f32;
    if !radius.is_finite() || radius <= 0. || !r32.is_finite() || r32 <= 0. {
        return Err(invalid(
            "exposure radius must be positive finite in the float32 source profile",
        ));
    }
    let peptides = view.peptide_ca(model);
    let members = peptides
        .iter()
        .enumerate()
        .flat_map(|(p, rows)| rows.iter().enumerate().map(move |(i, &r)| (p, i, r)))
        .collect::<Vec<_>>();
    let points = members
        .iter()
        .map(|&(_, _, r)| {
            view.coordinate(view.residues[r].atom("CA").expect("CA peptide membership"))
        })
        .collect::<Vec<_>>();
    let reach = radius.max(f64::from(r32.next_up())) * (1. + 8. * f64::from(f32::EPSILON))
        + f64::from(f32::MIN_POSITIVE).sqrt();
    let pairs = spatial::candidates(&points, reach)?;
    let mut neighbors = vec![Vec::new(); members.len()];
    for (a, b) in pairs {
        neighbors[a].push(b);
        neighbors[b].push(a);
    }
    let properties = members
        .par_iter()
        .enumerate()
        .map(|(at, &(peptide, position, residue))| {
            let center = points[at];
            let alpha = if position == 0 || position + 1 == peptides[peptide].len() {
                None
            } else {
                let before = view.coordinate(
                    view.residues[peptides[peptide][position - 1]]
                        .atom("CA")
                        .expect("CA peptide"),
                );
                let after = view.coordinate(
                    view.residues[peptides[peptide][position + 1]]
                        .atom("CA")
                        .expect("CA peptide"),
                );
                Some(normalized(add(
                    normalized(sub(center, before)),
                    normalized(sub(center, after)),
                )))
            };
            let beta = beta(view, residue);
            let mut result = Properties {
                alpha_up: alpha.map(|_| 0),
                alpha_down: alpha.map(|_| 0),
                beta_up: beta.map(|_| 0),
                beta_down: beta.map(|_| 0),
                cn: Some(0),
                cb_pcb_angle: alpha.zip(beta).map(|(a, b)| angle(a, b)),
            };
            for &other in &neighbors[at] {
                let (p, i, _) = members[other];
                if p == peptide && position.abs_diff(i) <= offset {
                    continue;
                }
                let delta = sub(points[other], center);
                if atom_distance(points[other], center) < r32 {
                    *result.cn.as_mut().expect("CN available") += 1;
                }
                if norm(delta) < radius {
                    if let Some(direction) = alpha {
                        if angle(delta, direction) < PI / 2. {
                            *result.alpha_up.as_mut().expect("alpha available") += 1;
                        } else {
                            *result.alpha_down.as_mut().expect("alpha available") += 1;
                        }
                    }
                    if let Some(direction) = beta {
                        if angle(delta, direction) < PI / 2. {
                            *result.beta_up.as_mut().expect("beta available") += 1;
                        } else {
                            *result.beta_down.as_mut().expect("beta available") += 1;
                        }
                    }
                }
            }
            (residue, result)
        })
        .collect::<Vec<_>>();
    let mut computed = properties
        .into_iter()
        .collect::<std::collections::HashMap<_, _>>();
    let rows = view
        .residues
        .iter()
        .enumerate()
        .filter(|(_, r)| r.model == model)
        .map(|(i, r)| ExposureRow {
            residue: view.identity(i),
            properties: computed.remove(&i).unwrap_or_default(),
            selected_ca: r.atom("CA"),
            ca_connectivity_rows: r
                .variant()
                .atom("CA")
                .map(|a| view.conformers(a))
                .unwrap_or_default(),
        })
        .collect();
    let peptides = peptides
        .into_iter()
        .map(|rows| {
            rows.into_iter()
                .map(|r| view.residues[r].variant().atoms[0].selected)
                .collect()
        })
        .collect();
    Ok(Exposure {
        model_index: model,
        radius,
        offset,
        peptides,
        rows,
    })
}
