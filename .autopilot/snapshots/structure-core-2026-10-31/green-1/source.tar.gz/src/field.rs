use mmcif_cif::{Value, ValueKind};
use serde::Serialize;

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq, Serialize)]
#[serde(rename_all = "lowercase")]
pub(crate) enum State {
    Absent,
    Blank,
    Unknown,
    Inapplicable,
    Text,
}

#[derive(Clone, Copy, Debug, Serialize)]
pub(crate) struct Field<'a> {
    pub state: State,
    pub value: Option<&'a str>,
    pub raw: Option<&'a str>,
    pub token_form: Option<&'static str>,
}

impl<'a> Field<'a> {
    pub const ABSENT: Self = Self {
        state: State::Absent,
        value: None,
        raw: None,
        token_form: None,
    };

    pub fn cif(value: Value<'a>) -> Self {
        let state = match value.kind() {
            ValueKind::Unknown => State::Unknown,
            ValueKind::Inapplicable => State::Inapplicable,
            _ => State::Text,
        };
        let token_form = match value.kind() {
            ValueKind::Bare => "bare",
            ValueKind::SingleQuoted => "single-quoted",
            ValueKind::DoubleQuoted => "double-quoted",
            ValueKind::TextField => "text-field",
            ValueKind::Unknown => "unknown",
            ValueKind::Inapplicable => "inapplicable",
        };
        Self {
            state,
            value: value.as_str(),
            raw: Some(value.raw()),
            token_form: Some(token_form),
        }
    }

    pub fn pdb(raw: &'a str) -> Self {
        let value = raw.trim();
        Self {
            state: if value.is_empty() {
                State::Blank
            } else {
                State::Text
            },
            value: (!value.is_empty()).then_some(value),
            raw: Some(raw),
            token_form: Some("pdb-fixed"),
        }
    }

    pub fn key(self) -> Key<'a> {
        Key {
            state: self.state,
            value: self.value,
        }
    }

    pub fn matches(self, value: &str) -> bool {
        self.state == State::Text && self.value == Some(value)
            || self.state == State::Blank && value.is_empty()
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub(crate) struct Key<'a> {
    pub state: State,
    pub value: Option<&'a str>,
}

#[derive(Clone, Debug, Serialize)]
pub(crate) struct Identifier {
    pub state: State,
    pub value: Option<String>,
}

impl From<Key<'_>> for Identifier {
    fn from(key: Key<'_>) -> Self {
        Self {
            state: key.state,
            value: key.value.map(str::to_owned),
        }
    }
}
