use std::io::Write;
use std::ops::Range;

use rsomics_common::Result;

use crate::field::Field;
use crate::invalid;
use crate::model::finite;

struct Record {
    range: Range<usize>,
    model: usize,
    segment: usize,
}

pub(crate) struct Pdb {
    pub text: String,
    records: Vec<Record>,
    metadata: Vec<Range<usize>>,
    pub models: Vec<Option<Range<usize>>>,
    pub coordinates: Vec<([f64; 3], usize)>,
    master: bool,
    linked: Vec<(&'static str, Range<usize>)>,
}

impl Pdb {
    pub fn read(text: String) -> Result<Self> {
        if !text.is_ascii() {
            return Err(invalid("PDB fixed-column input must be ASCII"));
        }
        let mut result = Self {
            text,
            records: Vec::new(),
            metadata: Vec::new(),
            models: Vec::new(),
            coordinates: Vec::new(),
            master: false,
            linked: Vec::new(),
        };
        let mut active = None;
        let mut explicit = false;
        let mut segment = 0;
        let mut offset = 0;
        let mut ended = false;
        for raw in result.text.split_inclusive('\n') {
            let line = raw.trim_end_matches(['\n', '\r']);
            let range = offset..offset + line.len();
            offset += raw.len();
            if ended && !line.trim().is_empty() {
                return Err(invalid("records after PDB END are unsupported"));
            }
            let name = line.get(..6).unwrap_or(line).trim();
            match name {
                "MODEL" => {
                    if active.is_some() || (!explicit && !result.records.is_empty()) {
                        return Err(invalid("nested or mixed implicit/explicit PDB models"));
                    }
                    let serial = line
                        .get(10..14)
                        .ok_or_else(|| invalid("truncated PDB MODEL"))?;
                    serial.trim().parse::<i32>()?;
                    active = Some(result.models.len());
                    explicit = true;
                    result.models.push(Some(range.start + 10..range.start + 14));
                    segment += 1;
                }
                "ENDMDL" => {
                    if active.take().is_none() {
                        return Err(invalid("PDB ENDMDL without MODEL"));
                    }
                    segment += 1;
                }
                "ATOM" | "HETATM" => {
                    if line.len() < 54 {
                        return Err(invalid("truncated PDB coordinate record"));
                    }
                    let model = match active {
                        Some(index) => index,
                        None if explicit => return Err(invalid("PDB atom outside explicit MODEL")),
                        None => {
                            if result.models.is_empty() {
                                result.models.push(None);
                            }
                            0
                        }
                    };
                    line[6..11].trim().parse::<i32>()?;
                    line[22..26].trim().parse::<i32>()?;
                    let row = result.records.len();
                    let coordinate = [
                        finite(Field::pdb(&line[30..38]), row, "x")?,
                        finite(Field::pdb(&line[38..46]), row, "y")?,
                        finite(Field::pdb(&line[46..54]), row, "z")?,
                    ];
                    for (start, end, name) in [(54, 60, "occupancy"), (60, 66, "B factor")] {
                        if let Some(raw) = line.get(start..end)
                            && !raw.trim().is_empty()
                        {
                            finite(Field::pdb(raw), row, name)?;
                        }
                    }
                    result.records.push(Record {
                        range,
                        model,
                        segment,
                    });
                    result.coordinates.push((coordinate, model));
                }
                "TER" => segment += 1,
                "MASTER" => result.master = true,
                "END" => {
                    if active.is_some() {
                        return Err(invalid("PDB MODEL missing ENDMDL"));
                    }
                    ended = true;
                }
                "ANISOU" | "CONECT" => {
                    result
                        .linked
                        .push((if name == "ANISOU" { "ANISOU" } else { "CONECT" }, range));
                }
                "SIGATM" | "SIGUIJ" => {
                    return Err(invalid(format!(
                        "unsupported linked coordinate record {name}"
                    )));
                }
                _ => {
                    if !line.is_empty() {
                        result.metadata.push(range);
                    }
                }
            }
        }
        if active.is_some() {
            return Err(invalid("PDB MODEL missing ENDMDL"));
        }
        Ok(result)
    }

    pub fn line(&self, row: usize) -> &str {
        &self.text[self.records[row].range.clone()]
    }

    pub fn unqualified_write_records(&self) -> Vec<&'static str> {
        let mut kinds = Vec::new();
        for (kind, _) in &self.linked {
            if !kinds.contains(kind) {
                kinds.push(*kind);
            }
        }
        kinds
    }

    pub fn model(&self, row: usize) -> usize {
        self.records[row].model
    }

    fn water(&self, row: usize) -> bool {
        matches!(&self.line(row)[17..20], "HOH" | "WAT")
    }

    fn finish_segment(&self, last: usize, polymer: bool, output: &mut dyn Write) -> Result<usize> {
        if !polymer {
            return Ok(0);
        }
        let line = self.line(last);
        let serial = line[6..11]
            .trim()
            .parse::<i32>()?
            .checked_add(1)
            .ok_or_else(|| invalid("TER serial overflow"))?;
        if serial.to_string().len() > 5 {
            return Err(invalid("TER serial is not representable in PDB"));
        }
        writeln!(
            output,
            "TER   {serial:>5}      {} {}{}{}",
            &line[17..20],
            &line[21..22],
            &line[22..26],
            &line[26..27]
        )?;
        Ok(1)
    }

    pub fn write(&self, rows: &[usize], output: &mut dyn Write) -> Result<()> {
        if let Some((kind, _)) = self.linked.first() {
            return Err(invalid(format!(
                "unqualified linked coordinate record {kind}: read-only analysis is supported, selection/writing is not"
            )));
        }
        let mut model_order = Vec::new();
        for &row in rows {
            let model = self.records[row].model;
            if !model_order.contains(&model) {
                model_order.push(model);
            }
        }
        let first = *model_order
            .first()
            .ok_or_else(|| invalid("selection retained no PDB atoms"))?;
        let explicit = self.models.iter().any(Option::is_some);
        let mut counts = [0usize; 12];
        for range in &self.metadata {
            let line = &self.text[range.clone()];
            let record = line.get(..6).unwrap_or(line).trim();
            let index = match record {
                "REMARK" => Some(0),
                "HET" => Some(2),
                "HELIX" => Some(3),
                "SHEET" => Some(4),
                "TURN" => Some(5),
                "SITE" => Some(6),
                "SEQRES" => Some(11),
                _ if record.starts_with("ORIGX")
                    || record.starts_with("SCALE")
                    || record.starts_with("MTRIX") =>
                {
                    Some(7)
                }
                _ => None,
            };
            if let Some(index) = index {
                counts[index] += 1;
            }
            if record == "NUMMDL" {
                writeln!(output, "NUMMDL    {:>4}", model_order.len())?;
            } else {
                writeln!(output, "{line}")?;
            }
        }
        let mut previous: Option<usize> = None;
        let mut polymer = false;
        for &row in rows {
            let record = &self.records[row];
            if let Some(last) = previous {
                let prev = &self.records[last];
                let boundary = prev.model != record.model
                    || prev.segment != record.segment
                    || self.line(last)[21..22] != self.line(row)[21..22]
                    || self.water(last) != self.water(row);
                if boundary {
                    let ter = self.finish_segment(last, polymer, output)?;
                    if prev.model == first {
                        counts[9] += ter;
                    }
                    polymer = false;
                    if explicit && prev.model != record.model {
                        writeln!(output, "ENDMDL")?;
                    }
                }
                if explicit && prev.model != record.model {
                    self.write_model(record.model, output)?;
                }
            } else if explicit {
                self.write_model(record.model, output)?;
            }
            writeln!(output, "{}", self.line(row))?;
            if record.model == first {
                counts[8] += 1;
            }
            polymer |= self.line(row).starts_with("ATOM  ");
            previous = Some(row);
        }
        if let Some(last) = previous {
            let ter = self.finish_segment(last, polymer, output)?;
            if self.records[last].model == first {
                counts[9] += ter;
            }
            if explicit {
                writeln!(output, "ENDMDL")?;
            }
        }
        if self.master {
            if counts.iter().any(|&count| count > 99_999) {
                return Err(invalid("MASTER count is not representable in PDB"));
            }
            write!(output, "MASTER    ")?;
            for count in counts {
                write!(output, "{count:>5}")?;
            }
            writeln!(output)?;
        }
        writeln!(output, "END")?;
        Ok(())
    }

    fn write_model(&self, index: usize, output: &mut dyn Write) -> Result<()> {
        let range = self.models[index]
            .as_ref()
            .ok_or_else(|| invalid("mixed PDB model containers"))?;
        writeln!(output, "MODEL     {:>4}", self.text[range.clone()].trim())?;
        Ok(())
    }
}
