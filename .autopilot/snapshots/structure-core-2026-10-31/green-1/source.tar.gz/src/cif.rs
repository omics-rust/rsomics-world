use std::collections::HashMap;
use std::io::Write;

use mmcif_cif::{Document, DocumentBuilder, Entry, Loop};
use rsomics_common::Result;

use crate::field::Field;
use crate::invalid;

pub(crate) struct Cif {
    document: Document,
    table_index: usize,
    pub names: Vec<String>,
    pub columns: HashMap<String, usize>,
    pub rows: usize,
}

impl Cif {
    pub fn read(text: String) -> Result<Self> {
        let document = Document::parse(text).map_err(|error| invalid(error.to_string()))?;
        if document.len() != 1 {
            return Err(invalid("one coordinate data block is required"));
        }
        let block = document.block(0).expect("one validated block");
        for name in block.category_names() {
            let lower = name.to_ascii_lowercase();
            if lower.starts_with("atom_site_") || lower.starts_with("pdbx_atom_site_") {
                return Err(invalid(format!(
                    "unsupported linked coordinate category _{name}"
                )));
            }
        }
        let mut found = None;
        let mut names = Vec::new();
        let mut rows = 0;
        for (index, entry) in block.entries().enumerate() {
            match entry {
                Entry::Frame(_) => {
                    return Err(invalid("save frames are outside the coordinate profile"));
                }
                Entry::Pair(pair) if pair.tag().to_ascii_lowercase().starts_with("_atom_site.") => {
                    return Err(invalid("atom_site must be one complete loop, not pairs"));
                }
                Entry::Loop(table) => {
                    let tags = table.tags().collect::<Vec<_>>();
                    if table.row_count() == 0 {
                        return Err(invalid("empty metadata loops cannot be reconstructed"));
                    }
                    if tags
                        .iter()
                        .any(|tag| tag.to_ascii_lowercase().starts_with("_atom_site."))
                    {
                        if found.is_some()
                            || !tags
                                .iter()
                                .all(|tag| tag.to_ascii_lowercase().starts_with("_atom_site."))
                        {
                            return Err(invalid(
                                "mixed or duplicate atom_site coordinate tables are unsupported",
                            ));
                        }
                        found = Some(index);
                        rows = table.row_count();
                        names = tags
                            .iter()
                            .map(|tag| {
                                tag.split_once('.')
                                    .expect("qualified coordinate tag")
                                    .1
                                    .to_owned()
                            })
                            .collect();
                    }
                }
                _ => {}
            }
        }
        let table_index = found.ok_or_else(|| invalid("atom_site coordinate table is absent"))?;
        let columns: HashMap<_, _> = names
            .iter()
            .enumerate()
            .map(|(index, name)| (name.to_ascii_lowercase(), index))
            .collect();
        for name in ["id", "group_pdb", "cartn_x", "cartn_y", "cartn_z"] {
            if !columns.contains_key(name) {
                return Err(invalid(format!("required atom_site.{name} is absent")));
            }
        }
        Ok(Self {
            document,
            table_index,
            names,
            columns,
            rows,
        })
    }

    fn table(&self) -> Loop<'_> {
        match self
            .document
            .block(0)
            .expect("validated block")
            .entries()
            .nth(self.table_index)
            .expect("validated table index")
        {
            Entry::Loop(table) => table,
            _ => unreachable!("coordinate table was validated"),
        }
    }

    pub fn field(&self, row: usize, column: usize) -> Field<'_> {
        Field::cif(
            self.table()
                .value(row, column)
                .expect("resolved column and source row"),
        )
    }

    pub fn polymers(&self) -> Result<Vec<(&str, &str)>> {
        let block = self.document.block(0).expect("validated block");
        let category = block
            .category("entity_poly")
            .ok_or_else(|| invalid("polymer selector requires entity_poly metadata"))?;
        let ids = category
            .column("entity_id")
            .ok_or_else(|| invalid("entity_poly.entity_id is absent"))?;
        let types = category
            .column("type")
            .ok_or_else(|| invalid("entity_poly.type is absent"))?;
        ids.iter()
            .zip(types.iter())
            .map(|(id, kind)| {
                Ok((
                    id.as_str()
                        .ok_or_else(|| invalid("polymer entity ID is unavailable"))?,
                    kind.as_str()
                        .ok_or_else(|| invalid("polymer type is unavailable"))?,
                ))
            })
            .collect()
    }

    pub fn asym_entities(&self) -> Result<Vec<(&str, &str)>> {
        let block = self.document.block(0).expect("validated block");
        let category = block.category("struct_asym").ok_or_else(|| {
            invalid("entity selector requires label_entity_id or struct_asym metadata")
        })?;
        let chains = category
            .column("id")
            .ok_or_else(|| invalid("struct_asym.id is absent"))?;
        let entities = category
            .column("entity_id")
            .ok_or_else(|| invalid("struct_asym.entity_id is absent"))?;
        chains
            .iter()
            .zip(entities.iter())
            .map(|(chain, entity)| {
                Ok((
                    chain
                        .as_str()
                        .ok_or_else(|| invalid("struct_asym ID is unavailable"))?,
                    entity
                        .as_str()
                        .ok_or_else(|| invalid("struct_asym entity ID is unavailable"))?,
                ))
            })
            .collect()
    }

    pub fn write(&self, rows: &[usize], output: &mut dyn Write) -> Result<()> {
        let mut keep = vec![false; self.rows];
        for &row in rows {
            keep[row] = true;
        }
        let mut builder = DocumentBuilder::new();
        let block = self.document.block(0).expect("validated single block");
        let build = |error: mmcif_cif::BuildError| invalid(error.to_string());
        builder.start_block(block.name()).map_err(build)?;
        for (entry_index, entry) in block.entries().enumerate() {
            match entry {
                Entry::Pair(pair) => builder.pair(pair.tag(), pair.value()).map_err(build)?,
                Entry::Loop(table) => {
                    let tags = table.tags().collect::<Vec<_>>();
                    builder.start_loop(tags.iter().copied()).map_err(build)?;
                    for (index, value) in table.values().enumerate() {
                        if entry_index != self.table_index || keep[index / tags.len()] {
                            builder.push(value).map_err(build)?;
                        }
                    }
                }
                Entry::Frame(_) => unreachable!("save frames were rejected at input"),
            }
        }
        builder.finish().map_err(build)?.write_to(output)?;
        Ok(())
    }
}
