use std::collections::HashMap;

use clap::{Args, ValueEnum};
use rsomics_common::Result;
use serde::Serialize;

use crate::analysis::{chemistry, view::View};
use crate::field::Identifier;
use crate::invalid;
use crate::model::{Format, Handle, Namespace, Structure};

pub(crate) struct Selection {
    pub namespace: Namespace,
    pub models: Vec<String>,
    pub model_indices: Vec<usize>,
    pub chains: Vec<String>,
    pub filters: Filters,
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, ValueEnum, Serialize)]
#[serde(rename_all = "kebab-case")]
pub(crate) enum Conformers {
    #[default]
    All,
    HighestOccupancy,
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, ValueEnum, Serialize)]
#[serde(rename_all = "lowercase")]
pub(crate) enum AtomClass {
    #[default]
    All,
    Atom,
    Hetero,
    Water,
}

#[derive(Args, Clone, Debug, Serialize)]
pub(crate) struct Filters {
    /// Exact mmCIF entity ID; repeat for several
    #[arg(long)]
    pub entity: Vec<String>,
    /// Exact residue sequence text in --residue-namespace
    #[arg(long)]
    pub residue: Vec<String>,
    /// Residue ID namespace; not required when no residue filter is requested
    #[arg(long, value_enum, default_value = "author")]
    pub residue_namespace: Namespace,
    /// Exact residue/component name in the selected residue namespace
    #[arg(long)]
    pub component: Vec<String>,
    /// Exact insertion code; empty text addresses a blank PDB insertion code
    #[arg(long)]
    pub insertion: Vec<String>,
    /// Exact atom name in --atom-namespace
    #[arg(long)]
    pub atom: Vec<String>,
    #[arg(long, value_enum, default_value = "author")]
    pub atom_namespace: Namespace,
    /// Exact alternate-location text; applied before occupancy selection
    #[arg(long)]
    pub altloc: Vec<String>,
    #[arg(long, value_enum, default_value = "all")]
    pub conformers: Conformers,
    /// Exclude both hydrogen and deuterium using declared Bio element inference
    #[arg(long)]
    pub no_hydrogens: bool,
    #[arg(long, value_enum, default_value = "all")]
    pub atom_class: AtomClass,
    /// Keep only entities declared in mmCIF entity_poly metadata
    #[arg(long, conflicts_with = "non_polymer")]
    pub polymer_only: bool,
    /// Keep only entities absent from a complete mmCIF entity_poly table
    #[arg(long,conflicts_with_all=["polymer_only","polymer_type"])]
    pub non_polymer: bool,
    /// Exact entity_poly.type text, for example polypeptide(L)
    #[arg(long)]
    pub polymer_type: Vec<String>,
}

impl Default for Filters {
    fn default() -> Self {
        Self {
            entity: Vec::new(),
            residue: Vec::new(),
            residue_namespace: Namespace::Author,
            component: Vec::new(),
            insertion: Vec::new(),
            atom: Vec::new(),
            atom_namespace: Namespace::Author,
            altloc: Vec::new(),
            conformers: Conformers::All,
            no_hydrogens: false,
            atom_class: AtomClass::All,
            polymer_only: false,
            non_polymer: false,
            polymer_type: Vec::new(),
        }
    }
}

impl Filters {
    fn apply(&self, structure: &Structure, rows: Vec<usize>) -> Result<Vec<usize>> {
        let prefix = |namespace| match namespace {
            Namespace::Author => "auth",
            Namespace::Label => "label",
        };
        let mut columns = Vec::new();
        for (name, values) in [
            (
                format!("{}_seq_id", prefix(self.residue_namespace)),
                &self.residue,
            ),
            (
                format!("{}_comp_id", prefix(self.residue_namespace)),
                &self.component,
            ),
            ("pdbx_PDB_ins_code".to_owned(), &self.insertion),
            (
                format!("{}_atom_id", prefix(self.atom_namespace)),
                &self.atom,
            ),
            ("label_alt_id".to_owned(), &self.altloc),
        ] {
            if !values.is_empty() {
                let column = structure.resolve(&name);
                if matches!(column, Handle::Absent) {
                    return Err(invalid(format!(
                        "selector namespace/field {name} is absent"
                    )));
                }
                columns.push((column, values));
            }
        }
        let polymer_requested =
            self.polymer_only || self.non_polymer || !self.polymer_type.is_empty();
        let polymers = if polymer_requested {
            structure.polymers()?
        } else {
            Vec::new()
        };
        let entity = structure.resolve("label_entity_id");
        let asym =
            if (polymer_requested || !self.entity.is_empty()) && matches!(entity, Handle::Absent) {
                Some(structure.asym_entities()?)
            } else {
                None
            };
        let label_chain = structure.resolve("label_asym_id");
        let group = structure.resolve("group_PDB");
        let names = if structure.format() == Format::Pdb {
            "auth"
        } else {
            "label"
        };
        let comp = structure.resolve(&format!("{names}_comp_id"));
        let atom = structure.resolve(&format!("{names}_atom_id"));
        let element = structure.resolve("type_symbol");
        let mut kept = Vec::with_capacity(rows.len());
        for row in rows {
            if !columns.iter().all(|(column, values)| {
                values
                    .iter()
                    .any(|value| structure.field(row, *column).matches(value))
            }) {
                continue;
            }
            if polymer_requested || !self.entity.is_empty() {
                let id = if let Some(asym) = &asym {
                    let chain = structure.field(row, label_chain).value;
                    asym.iter()
                        .find(|(key, _)| Some(*key) == chain)
                        .map(|(_, entity)| *entity)
                } else {
                    structure.field(row, entity).value
                };
                let Some(id) = id else {
                    if polymer_requested {
                        return Err(invalid(format!(
                            "row {row}: polymer entity identity is unavailable"
                        )));
                    }
                    continue;
                };
                if !self.entity.is_empty() && !self.entity.iter().any(|wanted| wanted == id) {
                    continue;
                }
                let kind = polymers
                    .iter()
                    .find(|(key, _)| *key == id)
                    .map(|(_, kind)| *kind);
                if self.polymer_only && kind.is_none()
                    || self.non_polymer && kind.is_some()
                    || !self.polymer_type.is_empty()
                        && !kind.is_some_and(|k| self.polymer_type.iter().any(|want| want == k))
                {
                    continue;
                }
            }
            let hetero = structure.field(row, group).value == Some("HETATM");
            let water = matches!(structure.field(row, comp).value, Some("HOH" | "WAT"));
            if match self.atom_class {
                AtomClass::All => false,
                AtomClass::Atom => hetero,
                AtomClass::Hetero => !hetero,
                AtomClass::Water => !hetero || !water,
            } {
                continue;
            }
            if self.no_hydrogens {
                let name = structure.field(row, atom);
                let fullname = if structure.format() == Format::Pdb {
                    name.raw
                } else {
                    name.value
                };
                let inferred = chemistry::assign_element(
                    name.value.unwrap_or(""),
                    fullname.unwrap_or(""),
                    structure.field(row, element).value.unwrap_or(""),
                );
                if matches!(inferred.as_str(), "H" | "D") {
                    continue;
                }
            }
            kept.push(row);
        }
        if self.conformers == Conformers::HighestOccupancy && !kept.is_empty() {
            let mut selected = vec![false; structure.rows.len()];
            for row in View::highest_occupancy(structure, &kept)? {
                selected[row] = true;
            }
            kept.retain(|&row| selected[row]);
        }
        Ok(kept)
    }
}

#[derive(Clone, Copy, Debug, ValueEnum, Serialize)]
#[serde(rename_all = "lowercase")]
pub(crate) enum SplitBy {
    Chain,
    Model,
}

pub(crate) struct Group {
    pub id: Identifier,
    pub rows: Vec<usize>,
}

impl Selection {
    pub fn resolve(&self, structure: &Structure) -> Result<Vec<usize>> {
        let chain = if self.chains.is_empty() {
            None
        } else {
            Some(structure.chain(self.namespace)?)
        };
        let rows = structure
            .rows
            .iter()
            .enumerate()
            .filter(|(row, atom)| {
                (self.models.is_empty()
                    || self.models.iter().any(|value| {
                        structure
                            .field(*row, structure.identity.model)
                            .matches(value)
                    }))
                    && (self.model_indices.is_empty() || self.model_indices.contains(&atom.model))
                    && chain.is_none_or(|column| {
                        self.chains
                            .iter()
                            .any(|value| structure.field(*row, column).matches(value))
                    })
            })
            .map(|(row, _)| row)
            .collect::<Vec<_>>();
        let rows = self.filters.apply(structure, rows)?;
        if rows.is_empty() {
            return Err(invalid("selection retained no atoms"));
        }
        Ok(rows)
    }

    pub fn groups(&self, structure: &Structure, rows: &[usize], by: SplitBy) -> Result<Vec<Group>> {
        let handle = match by {
            SplitBy::Chain => structure.chain(self.namespace)?,
            SplitBy::Model => structure.identity.model,
        };
        let mut groups: Vec<Group> = Vec::new();
        match by {
            SplitBy::Chain => {
                let mut seen = HashMap::new();
                for &row in rows {
                    let key = structure.field(row, handle).key();
                    let next = seen.len();
                    let group = *seen.entry(key).or_insert_with(|| {
                        groups.push(Group {
                            id: key.into(),
                            rows: Vec::new(),
                        });
                        next
                    });
                    groups[group].rows.push(row);
                }
            }
            SplitBy::Model => {
                let mut seen = HashMap::new();
                for &row in rows {
                    let index = structure.rows[row].model;
                    let next = seen.len();
                    let group = *seen.entry(index).or_insert_with(|| {
                        groups.push(Group {
                            id: structure.models[index].serial.clone(),
                            rows: Vec::new(),
                        });
                        next
                    });
                    groups[group].rows.push(row);
                }
            }
        }
        Ok(groups)
    }
}
