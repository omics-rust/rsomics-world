import hashlib
import json
import pathlib
import shutil
import sys

source = pathlib.Path(sys.argv[1]).resolve()
target = pathlib.Path(__file__).resolve().parents[1] / "tests/fixtures/analysis"
target.mkdir(exist_ok=True)
manifest = []


def retain(relative, name):
    original = source / relative
    destination = target / name
    if destination.exists() and destination.read_bytes() != original.read_bytes():
        raise RuntimeError(f"refusing changed retained fixture: {destination}")
    shutil.copyfile(original, destination)
    manifest.append({"path": name, "source": relative, "sha256": hashlib.sha256(destination.read_bytes()).hexdigest()})


for prefix, suffix in [("pdb-workflow", "pdb"), ("mmcif-workflow", "cif"),
                       ("small-pdb-workflow", "pdb"), ("integrated-selected-workflow", "cif")]:
    retain(f"witness/{prefix}/split-0.{suffix}", f"{prefix}.{suffix}")
    for operation in ["selected-inspect", "geometry", "dihedrals", "contacts", "exposure", "superpose"]:
        retain(f"witness/{prefix}/{operation}/observation.json", f"{prefix}-{operation}.json")

for name in ["fit-main", "fit-reflection", "fit-rank-deficient", "pdb-workflow/superpose",
             "mmcif-workflow/superpose", "small-pdb-workflow/superpose", "integrated-selected-workflow/superpose"]:
    output = name.replace("/superpose", "-fit")
    retain(f"witness/{name}/observation.json", f"{output}-source.json")
    result = json.loads((target / f"{output}-source.json").read_text())["result"]
    (target / f"{output}.json").write_text(json.dumps({k: result[k] for k in ["reference", "moving", "reference_ids", "moving_ids"]}, indent=2) + "\n")
    manifest.append({"path": f"{output}.json", "source": f"{output}-source.json/result",
                     "sha256": hashlib.sha256((target / f"{output}.json").read_bytes()).hexdigest()})

for product, names in [
    ("geometry", ["3nir.pdb", "1a2p.pdb"]),
    ("contacts", ["1crn.pdb", "altloc.pdb"]),
    ("hsexposure", ["4hhb.pdb", "altloc.pdb"]),
    ("dihedrals", ["altloc.pdb"]),
]:
    for name in names:
        retain(f"witness/inputs/historical/rsomics-pdb-{product}/tests/golden/{name}", f"{product}-{name}")

for name in ["geometry-3nir-all-conformers", "geometry-3nir-heavy", "geometry-3nir-CA",
             "dihedrals-altloc.pdb", "hsexposure-altloc.pdb", "hsexposure-4hhb.pdb", "integrated-cutoff-boundary"]:
    retain(f"witness/{name}/observation.json", f"{name}.json")

for path in sorted((source / "witness/retained-reference-profiles").glob("*/observation.json")):
    retain(str(path.relative_to(source)), f"legacy-{path.parent.name}.json")

(target / "manifest.json").write_text(json.dumps({
    "source_run": 40644150133, "source_head": "d709ad00973dd60f1c16c340fc5a4c37474bf13f",
    "qualification_report_sha256": "5973e5223424b3a4be7de6b7b747e806b33ffc1f64274395b71f7fabdda28bb6",
    "files": manifest,
}, indent=2) + "\n")
