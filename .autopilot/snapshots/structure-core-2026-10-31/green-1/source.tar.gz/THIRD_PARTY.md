# Provenance and notices

Runtime I/O uses `mmcif-cif` exactly 0.3.1 (MIT OR Apache-2.0), not pdbtbx or
the separate mmcif model/IR/geometry ecosystem. Registry package SHA256:
27655046b8abe8e3cf3b0e637ee5937b566fee11efa8b06689aba19dc7d52e73.
Packaged source revision: 72419bac19c274e5958ae14847380664f5929ba5,
[fuyu-myk/mmcif](https://github.com/fuyu-myk/mmcif/tree/72419bac19c274e5958ae14847380664f5929ba5/crates/mmcif-cif).
Upstream notices are retained under `notices/`; Cargo.lock pins dependencies.
The parser has u32 source spans (approximately 4 GiB document limit) and 29-bit
individual cell lengths. No memory-mapped/unsafe API is used by this product.

Shared registry libraries are `rsomics-common` 0.12.3 and `rsomics-help` 0.4.0,
MIT OR Apache-2.0. The actual published common atomic/path and help CLI source
bodies were checked against the owning sources before use. Error/result envelopes,
thread flags, path-alias protection and transactional output are their contracts,
not product-local reinventions.

Behavior/format sources:

- [wwPDB PDB 3.3 coordinates](https://www.wwpdb.org/documentation/file-format-content/format33/sect9.html)
  and [bookkeeping](https://www.wwpdb.org/documentation/file-format-content/format33/sect11.html).
- [PDBx/mmCIF guide](https://mmcif.wwpdb.org/docs/user-guide/guide.html).
- Biopython 1.87, source 7a9c76cce8c6a58db791be2b12a135af210cedf2
  (Biopython/BSD-3-Clause licensing), and Gemmi 0.7.3, source
  6b9910a51c3f41bda204012bed9329aa01ba2442 (MPL-2.0 and retained upstream notices),
  are the already-executed scientific/raw-reader oracles, not runtime dependencies.
  Their original archives, licenses, wheels and captured methods remain in the
  admitted source evidence described by MERGE.md. There is no local scientific
  reexecution during product tests.

PDB 1UBQ/1A8O coordinates are public structural data; fixture inclusion does not
assert authorship of the experimental structures. Team-authored adversarial
fixtures are explicitly distinguished from those experimental records.

Native analysis source contracts and adapted data/methods are attributed to:

- Bio.PDB Atom/Entity/Polypeptide/HSExposure/vectors and SVDSuperimposer,
  Copyright (C) 2002 Thomas Hamelryck; IUPACData, Copyright 2000 Andrew Dalke;
  ic_data, Copyright 2019-22 Robert T. Miller; and the Biopython Contributors,
  Copyright 1999-2025. The pinned source is the Bio1.87 commit above. The
  Biopython/BSD-3-Clause texts are retained in notices/biopython-LICENSE.rst.
- NumPy2.3.4 contiguous f32 pairwise reduction profile from
  numpy/_core/src/umath/loops_utils.h.src, Copyright 2005-2025 NumPy Developers,
  BSD-3-Clause; notices/numpy-LICENSE.txt. This is a native private reduction,
  not a linked Python/NumPy runtime or a reexecution of the source oracle.
- nalgebra exactly0.34.2, Apache-2.0, Copyright 2020 Sébastien Crozet,
  packaged source8f117be10444d55a3924a35747f7f50e568bbe3c. Only std and fixed-size
  Matrix3/SVD are requested; no BLAS/LAPACK runtime is installed or linked.
  Its original license text is retained in notices/nalgebra-LICENSE.

Historical team-owned kernels/data are refactored as documented in MERGE.md.
Source profile reconstruction does not assert that the original authors endorse
this product, nor that source code and released compiled wheels are identical.
