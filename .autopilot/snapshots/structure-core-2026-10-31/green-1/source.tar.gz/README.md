# rsomics-structure

Private coordinate selection and analysis, with one binary and one shared
PDB/PDBx-mmCIF identity spine. The CLI contains inspect, select/split, geometry,
contacts, exposure and superpose. The ordinary torsion engine is internal: its
public adapter awaits an explicit degenerate-angle contract. This is not a
published product or the complete planned seven-command release.

## Commands

```sh
rsomics-structure --json inspect input.cif
rsomics-structure select input.cif --model 3 --chain-namespace label \
  --chain LABEL_LONG_CHAIN --output selected.cif
rsomics-structure select input.pdb --chain A --output selected.pdb
rsomics-structure --json --threads 2 select input.cif \
  --split-by chain --split-dir existing-directory
rsomics-structure --json select input.pdb --split-by model \
  --split-dir existing-directory
rsomics-structure --json geometry input.cif --polymer-only --no-hydrogens
rsomics-structure contacts input.pdb --cutoff 8 --level residue --ca-only
rsomics-structure --threads 4 exposure input.cif --radius 13 --offset 0
rsomics-structure --json superpose --points corresponding-points.json
rsomics-structure --json superpose --reference fixed.cif --moving moving.cif \
  --reference-rows 0,4,9 --moving-rows 2,5,10
```

Inputs and outputs are named files. Selection writes the input format; known
opposite-format suffixes are errors, not conversion requests. All models and
conformers remain unless explicitly filtered. Repeat `--model` or `--chain` for
several literal identities; the two filter dimensions intersect. `--model-index`
uses zero-based source model order and addresses implicit PDB models as well.

The author chain namespace is the default for chain filters and chain splitting;
unfiltered/model-only selection and model splitting require no chain namespace.
Label chains are available only when the mmCIF input supplies them.
`--chain ''` selects blank PDB chains. Literal CIF
`'?'` is text, not an unknown value; unknown/inapplicable/absent groups remain
distinct during splitting. Unfiltered selection includes every source row.

`inspect` prints an ordered population summary. `--json` returns the shared
rsomics envelope with every raw coordinate field, its state, source token form,
finite f64 coordinates, original source-row key, model and chain populations.
PDB blank occupancy/B fields stay blank, never zero. PDB label chain/residue/atom
IDs and entity identity stay absent; element guessing is not performed here.

Single destinations use `rsomics-common` atomic output. Split files are staged
and committed as one recoverable transaction. Existing destinations are restored
on commit failure. Input aliases, duplicate destinations, empty selections and
invalid namespaces fail non-zero. The split directory must already exist.
Ordinal filenames (`chain-000001.cif`, `model-000001.pdb`) are collision-safe even
for long IDs, path characters, null-looking literals and case-insensitive disks;
the JSON result maps each file to its complete group identity and source rows.

The shared `--threads` control configures independent staged split writers.
It also controls contact candidate and independent HSE queries. Parsing,
inspection, geometry reductions and single-file writing retain their sequential
contracts. No parallel speedup or resource advantage has been measured or claimed.

## Shared selection

Selection and the four analysis commands accept exact entity, residue, component,
insertion, atom and altloc filters. Repeat a flag for alternatives; different
dimensions intersect. `--residue-namespace` addresses residue/component fields;
`--atom-namespace` addresses atom fields. Neither requires the namespace when
its corresponding filter is absent.

```sh
rsomics-structure select input.cif --model 3 --entity 1 \
  --residue-namespace label --residue 3 --atom-namespace label --atom CA \
  --conformers highest-occupancy --output selected.cif
```

`--conformers all` is the raw selection default. Highest-occupancy selection
chooses strictly greater atom occupancy with first-seen ties; residue variants
follow the source builder's last-active variant, not an occupancy sum.
Raw conformer collapse uses the deposited author and label identities together;
it does not fill a missing label ID from an author ID. Rows with neither
sequence identity remain distinct rather than being merged under a null value.
`--no-hydrogens` excludes H and D. `--atom-class atom|hetero|water|all`
addresses deposited ATOM/HETATM/water identity rather than inferred polymer status.
`--polymer-only`, `--non-polymer` and `--polymer-type 'polypeptide(L)'`
use actual mmCIF entity_poly and entity/struct_asym metadata. PDB has no
qualified entity/polymer namespace and rejects those selectors.

Literal text is matched as text: quoted CIF '?' does not select true unknown
values. PDB blank fields can be addressed by empty text. Raw null/absent kinds
remain distinct in output; no identifier is recovered by guessing another
namespace. The same selected row population feeds the analysis view.

## Analysis contracts

Analysis views iterate models, then first-seen chains and their residues, as
the source hierarchy does, even when a chain reappears later in the input.
Label analysis skips mmCIF rows whose label sequence ID is inapplicable,
following the Bio parser's label-residue profile. Raw selection keeps those
rows and their original null states. A label view retaining no residues fails.

- Geometry unpacks all conformers/variants by default. Coordinates, weights,
  COM/centroid, bounding boxes and radii use the retained float32 profile;
  total mass sums original float64 IUPAC weights. Rg is the retained team NumPy
  second-moment expression, not a Bio.PDB Rg API or a GROMACS execution result.
  There is no occupancy weighting or periodic-boundary correction. Unknown
  mass fails explicitly. `--ca-only` means all ATOM CA conformers.
- Contacts use selected standard-AA heavy atoms, optionally CA only. The
  inclusive cutoff uses parsed-f32 coordinates widened to f64. Residue hits
  remove same-residue pairs and deduplicate. `--min-seq-sep` compares actual
  numeric author residue numbers within a chain, not peptide position.
- Exposure reports HSE-alpha/beta, coordination number and the CB/pseudo-CB
  angle. CA peptide connectivity tests every conformer at f32 distance<4.3
  Angstrom; calculation uses selected coordinates. HSE uses f64 vectors and
  strict radius/direction, while CN uses the f32 Atom-distance profile.
  Offset is peptide-local. Missing properties remain null (TSV NA), not zero.
- Superpose requires explicit equal nonempty correspondences. A points JSON
  object contains reference/moving Nx3 f64 arrays and equally sized
  reference_ids/moving_ids arrays. Structure row correspondences instead use
  the parsed-f32 view widened to f64. One-point, two-point and collinear fits
  are valid but need not determine a unique rotation. Output is a proper
  right-multiplying moving@rotation+translation transform, RMSD and transformed
  paired points. It does not search an alignment or write transformed structures.

`--analysis-namespace` declares the chain/residue hierarchy (author by default);
it is separate from namespace-specific selection. Both raw ID systems stay
available. Bio mmCIF analysis atom/component names follow label fields even in
an author residue hierarchy. Distances/coordinates use Angstrom, masses use
daltons and angles use radians.

JSON analysis results include resolved selectors, method/precision profile,
model indices and original input-local source rows. Rows are not atom serials
or stable keys across rewriting/reloading. Contact TSV is one row per pair;
HSE TSV is one row per residue with a JSON identity cell preserving both
namespaces. Geometry/fit TSV is model/metric/value. Analysis `-o/--output`
atomically writes TSV or a JSON result payload; stdout `--json` uses the common
rsomics envelope. Input/output aliases are rejected.

The occupied-cell index has O(n) index storage. Candidate/pair storage is O(k)
and can be quadratic for dense populations. Finite normalized cell coordinates
and outward query endpoints must lie within the explicit ±2^50 cell domain;
unsupported grid domains fail rather than invoking an unbounded pair scan.

## Coordinate profile

- mmCIF: one data block and one complete atom-site loop, with finite coordinates;
  both ID systems, raw null/text states and unknown extra atom-site columns are
  retained. Save frames, mixed/duplicate coordinate tables, empty metadata loops
  and unqualified atom-ID-linked tables such as `atom_site_anisotrop` fail loudly.
- PDB: ASCII fixed columns, original model order/serials, atom serial/name,
  chain/residue/insertion, hetero/water, altloc and optional measurements. No
  hierarchy or conformer collapse is applied. MODEL/ENDMDL, TER, NUMMDL, MASTER
  and END container/bookkeeping records are rebuilt where applicable. ANISOU
  and CONECT ranges/kinds are retained for read-only coordinate analysis; these
  algorithms do not consume anisotropic tensors or deposited bond connectivity.
  Selection/serialization rejects their unqualified editing before committing
  output. Inspect reports unqualified_write_records. SIGATM and SIGUIJ remain
  unsupported at read time; they have no admitted fixture qualification.
- Unaffected metadata is retained, not source whitespace/comment layout.
  Residue-reference/deposition metadata (for example `struct_conn`, SEQRES,
  HELIX, remarks) is not filtered or repaired into a new deposition. Cross-format
  conversion, full-deposition repair and dictionary validation are excluded.

The Rust API exports only `run_cli`. Private modules share a raw document/source,
immutable source-row keys, compact coordinates/model indices and resolved field
handles. Private residue/conformer views, chemistry, spatial indexing and analysis
modules consume that spine; they do not build a second coordinate parser or
duplicate whole per-atom identity maps. SASA, DSSP and structural alignment are
absent rather than placeholders.

## Local verification

From this owning repository on external storage:

```sh
bash scripts/guarded-cargo.sh test --locked
bash scripts/guarded-cargo.sh clippy --locked --all-targets -- -D warnings
bash scripts/guarded-cargo.sh --exec \
  /Volumes/KIOXIA/Developments/rustup-home/toolchains/1.91.0-aarch64-apple-darwin/bin/cargo-fmt \
  fmt --all -- --check
```

The guard checks physical external devices, resolved Cargo home/target, rustup,
TMPDIR, tool caches and external free space. Unrelated boot occupancy is not a
project stop condition. It uses the installed external Rust 1.91 toolchain.
Direct `cargo fmt` can select an unconfigured rustup proxy on this
host; the explicit installed formatter avoids changing global defaults.

Compact integrated tests exercise retained whole workflows, operation-specific
views, all17 historical tables as value/precision assets, selector/read-write
capabilities and failure/atomic-output behavior. Numeric bounds were fixed before
native comparison; printed legacy quantization is recorded separately. Set
`RSOMICS_STRUCTURE_EVIDENCE` to a fresh existing external directory to retain
all command records, outputs and test sandboxes instead of temporary cleanup.
`serde_json/float_roundtrip` reads the retained f32-derived source JSON exactly;
no coordinate band or numerical profile is changed to accommodate decoding.

Native four-platform CI, independent whole-product review, representative
throughput/RSS advantage and complete structural-analysis qualification remain
release gates. See [MERGE.md](MERGE.md) and [THIRD_PARTY.md](THIRD_PARTY.md).
